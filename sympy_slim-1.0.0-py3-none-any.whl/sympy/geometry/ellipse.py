from __future__ import annotations
from sympy.core.expr import Expr
from sympy.core.relational import Eq
from sympy.core import S, pi, sympify
from sympy.core.evalf import N
from sympy.core.parameters import global_parameters
from sympy.core.logic import fuzzy_bool
from sympy.core.numbers import Rational, oo
from sympy.core.sorting import ordered
from sympy.core.symbol import Dummy, uniquely_named_symbol, _symbol
from sympy.external.mpmath import prec_to_dps
from sympy.simplify.simplify import simplify
from sympy.simplify.trigsimp import trigsimp
from sympy.functions.elementary.miscellaneous import sqrt, Max
from sympy.functions.elementary.trigonometric import cos, sin
from sympy.functions.special.elliptic_integrals import elliptic_e
from .entity import GeometryEntity, GeometrySet
from .exceptions import GeometryError
from .line import Line, Segment, Ray2D, Segment2D, Line2D, LinearEntity3D
from .point import Point, Point2D, Point3D
from .util import idiff, find
from sympy.polys import DomainError, Poly, PolynomialError
from sympy.polys.polyutils import _not_a_coeff, _nsort
from sympy.solvers import solve
from sympy.solvers.solveset import linear_coeffs
from sympy.utilities.misc import filldedent, func_name
import random
x, y = [Dummy('ellipse_dummy', real=True) for i in range(2)]

class Ellipse(GeometrySet):

    def __contains__(self, o):
        if isinstance(o, Point):
            res = self.equation(x, y).subs({x: o.x, y: o.y})
            return trigsimp(simplify(res)) is S.Zero
        elif isinstance(o, Ellipse):
            return self == o
        return False

    def __eq__(self, o):
        return isinstance(o, Ellipse) and (self.center == o.center and self.hradius == o.hradius and (self.vradius == o.vradius))

    def __hash__(self):
        return super().__hash__()

    def __new__(cls, center=None, hradius=None, vradius=None, eccentricity=None, **kwargs):
        hradius = sympify(hradius)
        vradius = sympify(vradius)
        if center is None:
            center = Point(0, 0)
        else:
            if len(center) != 2:
                raise ValueError('The center of "{}" must be a two dimensional point'.format(cls))
            center = Point(center, dim=2)
        if len(list(filter(lambda x: x is not None, (hradius, vradius, eccentricity)))) != 2:
            raise ValueError(filldedent('\n                Exactly two arguments of "hradius", "vradius", and\n                "eccentricity" must not be None.'))
        if eccentricity is not None:
            eccentricity = sympify(eccentricity)
            if eccentricity.is_negative:
                raise GeometryError('Eccentricity of ellipse/circle should lie between [0, 1)')
            elif hradius is None:
                hradius = vradius / sqrt(1 - eccentricity ** 2)
            elif vradius is None:
                vradius = hradius * sqrt(1 - eccentricity ** 2)
        if hradius == vradius:
            return Circle(center, hradius, **kwargs)
        if S.Zero in (hradius, vradius):
            return Segment(Point(center[0] - hradius, center[1] - vradius), Point(center[0] + hradius, center[1] + vradius))
        if hradius.is_real is False or vradius.is_real is False:
            raise GeometryError('Invalid value encountered when computing hradius / vradius.')
        return GeometryEntity.__new__(cls, center, hradius, vradius, **kwargs)

    def _svg(self, scale_factor=1.0, fill_color='#66cc99'):
        c = N(self.center)
        h, v = (N(self.hradius), N(self.vradius))
        return '<ellipse fill="{1}" stroke="#555555" stroke-width="{0}" opacity="0.6" cx="{2}" cy="{3}" rx="{4}" ry="{5}"/>'.format(2.0 * scale_factor, fill_color, c.x, c.y, h, v)

    @property
    def ambient_dimension(self):
        return 2

    @property
    def apoapsis(self):
        return self.major * (1 + self.eccentricity)

    def arbitrary_point(self, parameter='t'):
        t = _symbol(parameter, real=True)
        if t.name in (f.name for f in self.free_symbols):
            raise ValueError(filldedent('Symbol %s already appears in object and cannot be used as a parameter.' % t.name))
        return Point(self.center.x + self.hradius * cos(t), self.center.y + self.vradius * sin(t))

    @property
    def area(self):
        return simplify(S.Pi * self.hradius * self.vradius)

    @property
    def bounds(self):
        h, v = (self.hradius, self.vradius)
        return (self.center.x - h, self.center.y - v, self.center.x + h, self.center.y + v)

    @property
    def center(self):
        return self.args[0]

    @property
    def circumference(self):
        if self.eccentricity == 1:
            return 4 * self.major
        elif self.eccentricity == 0:
            return 2 * pi * self.hradius
        else:
            return 4 * self.major * elliptic_e(self.eccentricity ** 2)

    @property
    def eccentricity(self):
        return self.focus_distance / self.major

    def encloses_point(self, p):
        p = Point(p, dim=2)
        if p in self:
            return False
        if len(self.foci) == 2:
            h1, h2 = [f.distance(p) for f in self.foci]
            test = 2 * self.major - (h1 + h2)
        else:
            test = self.radius - self.center.distance(p)
        return fuzzy_bool(test.is_positive)

    def equation(self, x='x', y='y', _slope=None):
        x = _symbol(x, real=True)
        y = _symbol(y, real=True)
        dx = x - self.center.x
        dy = y - self.center.y
        if _slope is not None:
            L = (dy - _slope * dx) ** 2
            l = (_slope * dy + dx) ** 2
            h = 1 + _slope ** 2
            b = h * self.major ** 2
            a = h * self.minor ** 2
            return l / b + L / a - 1
        else:
            t1 = (dx / self.hradius) ** 2
            t2 = (dy / self.vradius) ** 2
            return t1 + t2 - 1

    def evolute(self, x='x', y='y'):
        if len(self.args) != 3:
            raise NotImplementedError('Evolute of arbitrary Ellipse is not supported.')
        x = _symbol(x, real=True)
        y = _symbol(y, real=True)
        t1 = (self.hradius * (x - self.center.x)) ** Rational(2, 3)
        t2 = (self.vradius * (y - self.center.y)) ** Rational(2, 3)
        return t1 + t2 - (self.hradius ** 2 - self.vradius ** 2) ** Rational(2, 3)

    @property
    def foci(self):
        c = self.center
        hr, vr = (self.hradius, self.vradius)
        if hr == vr:
            return (c, c)
        fd = sqrt(self.major ** 2 - self.minor ** 2)
        if hr == self.minor:
            return (c + Point(0, -fd), c + Point(0, fd))
        elif hr == self.major:
            return (c + Point(-fd, 0), c + Point(fd, 0))

    @property
    def focus_distance(self):
        return Point.distance(self.center, self.foci[0])

    @property
    def hradius(self):
        return self.args[1]

    def intersection(self, o):
        if isinstance(o, Point):
            if o in self:
                return [o]
            else:
                return []
        elif isinstance(o, (Segment2D, Ray2D)):
            ellipse_equation = self.equation(x, y)
            result = solve([ellipse_equation, Line(o.points[0], o.points[1]).equation(x, y)], [x, y], set=True)[1]
            return list(ordered([Point(i) for i in result if i in o]))
        elif isinstance(o, Polygon):
            return o.intersection(self)
        elif isinstance(o, (Ellipse, Line2D)):
            if o == self:
                return self
            else:
                ellipse_equation = self.equation(x, y)
                return list(ordered([Point(i) for i in solve([ellipse_equation, o.equation(x, y)], [x, y], set=True)[1]]))
        elif isinstance(o, LinearEntity3D):
            raise TypeError('Entity must be two dimensional, not three dimensional')
        else:
            raise TypeError('Intersection not handled for %s' % func_name(o))

    def is_tangent(self, o):
        if isinstance(o, Point2D):
            return False
        elif isinstance(o, Ellipse):
            intersect = self.intersection(o)
            if isinstance(intersect, Ellipse):
                return True
            elif intersect:
                return all((self.tangent_lines(i)[0].equals(o.tangent_lines(i)[0]) for i in intersect))
            else:
                return False
        elif isinstance(o, Line2D):
            hit = self.intersection(o)
            if not hit:
                return False
            if len(hit) == 1:
                return True
            return hit[0].equals(hit[1])
        elif isinstance(o, (Segment2D, Ray2D)):
            intersect = self.intersection(o)
            if len(intersect) == 1:
                return o in self.tangent_lines(intersect[0])[0]
            else:
                return False
        elif isinstance(o, Polygon):
            return all((self.is_tangent(s) for s in o.sides))
        elif isinstance(o, (LinearEntity3D, Point3D)):
            raise TypeError('Entity must be two dimensional, not three dimensional')
        else:
            raise TypeError('Is_tangent not handled for %s' % func_name(o))

    @property
    def major(self):
        ab = self.args[1:3]
        if len(ab) == 1:
            return ab[0]
        a, b = ab
        o = b - a < 0
        if o == True:
            return a
        elif o == False:
            return b
        return self.hradius

    @property
    def minor(self):
        ab = self.args[1:3]
        if len(ab) == 1:
            return ab[0]
        a, b = ab
        o = a - b < 0
        if o == True:
            return a
        elif o == False:
            return b
        return self.vradius

    def normal_lines(self, p, prec=None):
        p = Point(p, dim=2)
        if True:
            rv = []
            if p.x == self.center.x:
                rv.append(Line(self.center, slope=oo))
            if p.y == self.center.y:
                rv.append(Line(self.center, slope=0))
            if rv:
                return rv
        eq = self.equation(x, y)
        dydx = idiff(eq, y, x)
        norm = -1 / dydx
        slope = Line(p, (x, y)).slope
        seq = slope - norm
        yis = solve(seq, y)[0]
        xeq = eq.subs(y, yis).as_numer_denom()[0].expand()
        if len(xeq.free_symbols) == 1:
            try:
                xsol = Poly(xeq, x).real_roots()
            except (DomainError, PolynomialError, NotImplementedError):
                xsol = _nsort(solve(xeq, x), separated=True)[0]
            points = [Point(i, solve(eq.subs(x, i), y)[0]) for i in xsol]
        else:
            raise NotImplementedError('intersections for the general ellipse are not supported')
        slopes = [norm.subs(zip((x, y), pt.args)) for pt in points]
        if prec is not None:
            points = [pt.n(prec) for pt in points]
            slopes = [i if _not_a_coeff(i) else i.n(prec) for i in slopes]
        return [Line(pt, slope=s) for pt, s in zip(points, slopes)]

    @property
    def periapsis(self):
        return self.major * (1 - self.eccentricity)

    @property
    def semilatus_rectum(self):
        return self.major * (1 - self.eccentricity ** 2)

    def auxiliary_circle(self):
        return Circle(self.center, Max(self.hradius, self.vradius))

    def director_circle(self):
        return Circle(self.center, sqrt(self.hradius ** 2 + self.vradius ** 2))

    def plot_interval(self, parameter='t'):
        t = _symbol(parameter, real=True)
        return [t, -S.Pi, S.Pi]

    def random_point(self, seed=None):
        t = _symbol('t', real=True)
        x, y = self.arbitrary_point(t).args
        if seed is not None:
            rng = random.Random(seed)
        else:
            rng = random
        r = Rational(rng.random())
        c = 2 * r - 1
        s = sqrt(1 - c ** 2)
        return Point(x.subs(cos(t), c), y.subs(sin(t), s))

    def reflect(self, line):
        if line.slope in (0, oo):
            c = self.center
            c = c.reflect(line)
            return self.func(c, -self.hradius, self.vradius)
        else:
            x, y = [uniquely_named_symbol(name, (self, line), modify=lambda s: '_' + s, real=True) for name in 'xy']
            expr = self.equation(x, y)
            p = Point(x, y).reflect(line)
            result = expr.subs(zip((x, y), p.args), simultaneous=True)
            raise NotImplementedError(filldedent('General Ellipse is not supported but the equation of the reflected Ellipse is given by the zeros of: ' + 'f(%s, %s) = %s' % (str(x), str(y), str(result))))

    def rotate(self, angle=0, pt=None):
        if self.hradius == self.vradius:
            return self.func(self.center.rotate(angle, pt), self.hradius)
        if (angle / S.Pi).is_integer:
            return super().rotate(angle, pt)
        if (2 * angle / S.Pi).is_integer:
            return self.func(self.center.rotate(angle, pt), self.vradius, self.hradius)
        raise NotImplementedError('Only rotations of pi/2 are currently supported for Ellipse.')

    def scale(self, x=1, y=1, pt=None):
        c = self.center
        if pt:
            pt = Point(pt, dim=2)
            return self.translate(*(-pt).args).scale(x, y).translate(*pt.args)
        h = self.hradius
        v = self.vradius
        return self.func(c.scale(x, y), hradius=h * x, vradius=v * y)

    def tangent_lines(self, p):
        p = Point(p, dim=2)
        if self.encloses_point(p):
            return []
        if p in self:
            delta = self.center - p
            rise = self.vradius ** 2 * delta.x
            run = -self.hradius ** 2 * delta.y
            p2 = Point(simplify(p.x + run), simplify(p.y + rise))
            return [Line(p, p2)]
        else:
            if len(self.foci) == 2:
                f1, f2 = self.foci
                maj = self.hradius
                test = 2 * maj - Point.distance(f1, p) - Point.distance(f2, p)
            else:
                test = self.radius - Point.distance(self.center, p)
            if test.is_number and test.is_positive:
                return []
            eq = self.equation(x, y)
            dydx = idiff(eq, y, x)
            slope = Line(p, Point(x, y)).slope
            tangent_points = solve([slope - dydx, eq], [x, y])
            if len(tangent_points) == 1:
                if tangent_points[0][0] == p.x or tangent_points[0][1] == p.y:
                    return [Line(p, p + Point(1, 0)), Line(p, p + Point(0, 1))]
                else:
                    return [Line(p, p + Point(0, 1)), Line(p, tangent_points[0])]
            return [Line(p, tangent_points[0]), Line(p, tangent_points[1])]

    @property
    def vradius(self):
        return self.args[2]

    def second_moment_of_area(self, point=None):
        I_xx = S.Pi * self.hradius * self.vradius ** 3 / 4
        I_yy = S.Pi * self.hradius ** 3 * self.vradius / 4
        I_xy = 0
        if point is None:
            return (I_xx, I_yy, I_xy)
        I_xx = I_xx + self.area * (point[1] - self.center.y) ** 2
        I_yy = I_yy + self.area * (point[0] - self.center.x) ** 2
        I_xy = I_xy + self.area * (point[0] - self.center.x) * (point[1] - self.center.y)
        return (I_xx, I_yy, I_xy)

    def polar_second_moment_of_area(self):
        second_moment = self.second_moment_of_area()
        return second_moment[0] + second_moment[1]

    def section_modulus(self, point=None):
        x_c, y_c = self.center
        if point is None:
            x_min, y_min, x_max, y_max = self.bounds
            y = max(y_c - y_min, y_max - y_c)
            x = max(x_c - x_min, x_max - x_c)
        else:
            point = Point2D(point)
            y = point.y - y_c
            x = point.x - x_c
        second_moment = self.second_moment_of_area()
        S_x = second_moment[0] / y
        S_y = second_moment[1] / x
        return (S_x, S_y)

class Circle(Ellipse):

    def __new__(cls, *args, **kwargs):
        evaluate = kwargs.get('evaluate', global_parameters.evaluate)
        if len(args) == 1 and isinstance(args[0], (Expr, Eq)):
            x = kwargs.get('x', 'x')
            y = kwargs.get('y', 'y')
            equation = args[0].expand()
            if isinstance(equation, Eq):
                equation = equation.lhs - equation.rhs
            x = find(x, equation)
            y = find(y, equation)
            try:
                a, b, c, d, e = linear_coeffs(equation, x ** 2, y ** 2, x, y)
            except ValueError:
                raise GeometryError('The given equation is not that of a circle.')
            if S.Zero in (a, b) or a != b:
                raise GeometryError('The given equation is not that of a circle.')
            center_x = -c / a / 2
            center_y = -d / b / 2
            r2 = center_x ** 2 + center_y ** 2 - e / a
            return Circle((center_x, center_y), sqrt(r2), evaluate=evaluate)
        else:
            c, r = (None, None)
            if len(args) == 3:
                args = [Point(a, dim=2, evaluate=evaluate) for a in args]
                t = Triangle(*args)
                if not isinstance(t, Triangle):
                    return t
                c = t.circumcenter
                r = t.circumradius
            elif len(args) == 2:
                c = Point(args[0], dim=2, evaluate=evaluate)
                r = args[1]
                try:
                    r = Point(r, 0, evaluate=evaluate).x
                except ValueError:
                    raise GeometryError('Circle with imaginary radius is not permitted')
            if not (c is None or r is None):
                if r == 0:
                    return c
                return GeometryEntity.__new__(cls, c, r, **kwargs)
            raise GeometryError('Circle.__new__ received unknown arguments')

    def _eval_evalf(self, prec=15, **options):
        pt, r = self.args
        dps = prec_to_dps(prec)
        pt = pt.evalf(n=dps, **options)
        r = r.evalf(n=dps, **options)
        return self.func(pt, r, evaluate=False)

    @property
    def circumference(self):
        return 2 * S.Pi * self.radius

    def equation(self, x='x', y='y'):
        x = _symbol(x, real=True)
        y = _symbol(y, real=True)
        t1 = (x - self.center.x) ** 2
        t2 = (y - self.center.y) ** 2
        return t1 + t2 - self.major ** 2

    def intersection(self, o):
        return Ellipse.intersection(self, o)

    @property
    def radius(self):
        return self.args[1]

    def reflect(self, line):
        c = self.center
        c = c.reflect(line)
        return self.func(c, -self.radius)

    def scale(self, x=1, y=1, pt=None):
        c = self.center
        if pt:
            pt = Point(pt, dim=2)
            return self.translate(*(-pt).args).scale(x, y).translate(*pt.args)
        c = c.scale(x, y)
        x, y = [abs(i) for i in (x, y)]
        if x == y:
            return self.func(c, x * self.radius)
        h = v = self.radius
        return Ellipse(c, hradius=h * x, vradius=v * y)

    @property
    def vradius(self):
        return abs(self.radius)
from .polygon import Polygon, Triangle