from __future__ import annotations
from sympy.functions.elementary.miscellaneous import sqrt
from sympy.core import diff
from sympy.core.containers import Tuple
from sympy.core.symbol import _symbol
from sympy.external.mpmath import prec_to_dps
from sympy.geometry.entity import GeometryEntity, GeometrySet
from sympy.geometry.point import Point
from sympy.integrals import integrate
from sympy.matrices import Matrix, rot_axis3
from sympy.utilities.iterables import is_sequence

class Curve(GeometrySet):

    def __new__(cls, function, limits):
        if not is_sequence(function) or len(function) != 2:
            raise ValueError('Function argument should be (x(t), y(t)) but got %s' % str(function))
        if not is_sequence(limits) or len(limits) != 3:
            raise ValueError('Limit argument should be (t, tmin, tmax) but got %s' % str(limits))
        return GeometryEntity.__new__(cls, Tuple(*function), Tuple(*limits))

    def __call__(self, f):
        return self.subs(self.parameter, f)

    def _eval_subs(self, old, new):
        if old == self.parameter:
            return Point(*[f.subs(old, new) for f in self.functions])

    def _eval_evalf(self, prec=15, **options):
        f, (t, a, b) = self.args
        dps = prec_to_dps(prec)
        f = tuple([i.evalf(n=dps, **options) for i in f])
        a, b = [i.evalf(n=dps, **options) for i in (a, b)]
        return self.func(f, (t, a, b))

    def arbitrary_point(self, parameter='t'):
        if parameter is None:
            return Point(*self.functions)
        tnew = _symbol(parameter, self.parameter, real=True)
        t = self.parameter
        if tnew.name != t.name and tnew.name in (f.name for f in self.free_symbols):
            raise ValueError('Symbol %s already appears in object and cannot be used as a parameter.' % tnew.name)
        return Point(*[w.subs(t, tnew) for w in self.functions])

    @property
    def free_symbols(self):
        free = set()
        for a in self.functions + self.limits[1:]:
            free |= a.free_symbols
        free = free.difference({self.parameter})
        return free

    @property
    def ambient_dimension(self):
        return len(self.args[0])

    @property
    def functions(self):
        return self.args[0]

    @property
    def limits(self):
        return self.args[1]

    @property
    def parameter(self):
        return self.args[1][0]

    @property
    def length(self):
        integrand = sqrt(sum((diff(func, self.limits[0]) ** 2 for func in self.functions)))
        return integrate(integrand, self.limits)

    def plot_interval(self, parameter='t'):
        t = _symbol(parameter, self.parameter, real=True)
        return [t] + list(self.limits[1:])

    def rotate(self, angle=0, pt=None):
        if pt:
            pt = -Point(pt, dim=2)
        else:
            pt = Point(0, 0)
        rv = self.translate(*pt.args)
        f = list(rv.functions)
        f.append(0)
        f = Matrix(1, 3, f)
        f *= rot_axis3(angle)
        rv = self.func(f[0, :2].tolist()[0], self.limits)
        pt = -pt
        return rv.translate(*pt.args)

    def scale(self, x=1, y=1, pt=None):
        if pt:
            pt = Point(pt, dim=2)
            return self.translate(*(-pt).args).scale(x, y).translate(*pt.args)
        fx, fy = self.functions
        return self.func((fx * x, fy * y), self.limits)

    def translate(self, x=0, y=0):
        fx, fy = self.functions
        return self.func((fx + x, fy + y), self.limits)