from __future__ import annotations

class GeometryError(ValueError):
    pass