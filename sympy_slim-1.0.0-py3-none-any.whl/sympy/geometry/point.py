from __future__ import annotations
import warnings
from sympy.core import S, sympify, Expr
from sympy.core.add import Add
from sympy.core.containers import Tuple
from sympy.core.numbers import Float
from sympy.core.parameters import global_parameters
from sympy.external.mpmath import prec_to_dps
from sympy.simplify.simplify import nsimplify, simplify
from sympy.geometry.exceptions import GeometryError
from sympy.functions.elementary.miscellaneous import sqrt
from sympy.functions.elementary.complexes import im
from sympy.functions.elementary.trigonometric import cos, sin
from sympy.matrices import Matrix
from sympy.matrices.expressions import Transpose
from sympy.utilities.iterables import uniq, is_sequence
from sympy.utilities.misc import filldedent, func_name, Undecidable
from .entity import GeometryEntity

class Point(GeometryEntity):
    is_Point = True

    def __new__(cls, *args, **kwargs):
        evaluate = kwargs.get('evaluate', global_parameters.evaluate)
        on_morph = kwargs.get('on_morph', 'ignore')
        coords = args[0] if len(args) == 1 else args
        if isinstance(coords, Point):
            evaluate = False
            if len(coords) == kwargs.get('dim', len(coords)):
                return coords
        if not is_sequence(coords):
            raise TypeError(filldedent('\n                Expecting sequence of coordinates, not `{}`'.format(func_name(coords))))
        if len(coords) == 0 and kwargs.get('dim', None):
            coords = (S.Zero,) * kwargs.get('dim')
        coords = Tuple(*coords)
        dim = kwargs.get('dim', len(coords))
        if len(coords) < 2:
            raise ValueError(filldedent('\n                Point requires 2 or more coordinates or\n                keyword `dim` > 1.'))
        if len(coords) != dim:
            message = 'Dimension of {} needs to be changed from {} to {}.'.format(coords, len(coords), dim)
            if on_morph == 'ignore':
                pass
            elif on_morph == 'error':
                raise ValueError(message)
            elif on_morph == 'warn':
                warnings.warn(message, stacklevel=2)
            else:
                raise ValueError(filldedent("\n                        on_morph value should be 'error',\n                        'warn' or 'ignore'."))
        if any(coords[dim:]):
            raise ValueError('Nonzero coordinates cannot be removed.')
        if any((a.is_number and im(a).is_zero is False for a in coords)):
            raise ValueError('Imaginary coordinates are not permitted.')
        if not all((isinstance(a, Expr) for a in coords)):
            raise TypeError('Coordinates must be valid SymPy expressions.')
        coords = coords[:dim] + (S.Zero,) * (dim - len(coords))
        if evaluate:
            coords = coords.xreplace({f: simplify(nsimplify(f, rational=True)) for f in coords.atoms(Float)})
        if len(coords) == 2:
            kwargs['_nocheck'] = True
            return Point2D(*coords, **kwargs)
        elif len(coords) == 3:
            kwargs['_nocheck'] = True
            return Point3D(*coords, **kwargs)
        return GeometryEntity.__new__(cls, *coords)

    def __abs__(self):
        origin = Point([0] * len(self))
        return Point.distance(origin, self)

    def __add__(self, other):
        try:
            s, o = Point._normalize_dimension(self, Point(other, evaluate=False))
        except TypeError:
            raise GeometryError("Don't know how to add {} and a Point object".format(other))
        coords = [simplify(a + b) for a, b in zip(s, o)]
        return Point(coords, evaluate=False)

    def __contains__(self, item):
        return item in self.args

    def __truediv__(self, divisor):
        divisor = sympify(divisor)
        coords = [simplify(x / divisor) for x in self.args]
        return Point(coords, evaluate=False)

    def __eq__(self, other):
        if not isinstance(other, Point) or len(self.args) != len(other.args):
            return False
        return self.args == other.args

    def __getitem__(self, key):
        return self.args[key]

    def __hash__(self):
        return hash(self.args)

    def __iter__(self):
        return self.args.__iter__()

    def __len__(self):
        return len(self.args)

    def __mul__(self, factor):
        factor = sympify(factor)
        coords = [simplify(x * factor) for x in self.args]
        return Point(coords, evaluate=False)

    def __rmul__(self, factor):
        return self.__mul__(factor)

    def __neg__(self):
        coords = [-x for x in self.args]
        return Point(coords, evaluate=False)

    def __sub__(self, other):
        return self + [-x for x in other]

    @classmethod
    def _normalize_dimension(cls, *points, **kwargs):
        dim = getattr(cls, '_ambient_dimension', None)
        dim = kwargs.get('dim', dim)
        if dim is None:
            dim = max((i.ambient_dimension for i in points))
        if all((i.ambient_dimension == dim for i in points)):
            return list(points)
        kwargs['dim'] = dim
        kwargs['on_morph'] = kwargs.get('on_morph', 'warn')
        return [Point(i, **kwargs) for i in points]

    @staticmethod
    def affine_rank(*args):
        if len(args) == 0:
            return -1
        points = Point._normalize_dimension(*[Point(i) for i in args])
        origin = points[0]
        points = [i - origin for i in points[1:]]
        m = Matrix([i.args for i in points])
        return m.rank(iszerofunc=lambda x: abs(x.n(2)) < 1e-12 if x.is_number else x.is_zero)

    @property
    def ambient_dimension(self):
        return getattr(self, '_ambient_dimension', len(self))

    @classmethod
    def are_coplanar(cls, *points):
        if len(points) <= 1:
            return True
        points = cls._normalize_dimension(*[Point(i) for i in points])
        if points[0].ambient_dimension == 2:
            return True
        points = list(uniq(points))
        return Point.affine_rank(*points) <= 2

    def distance(self, other):
        if not isinstance(other, GeometryEntity):
            try:
                other = Point(other, dim=self.ambient_dimension)
            except TypeError:
                raise TypeError('not recognized as a GeometricEntity: %s' % type(other))
        if isinstance(other, Point):
            s, p = Point._normalize_dimension(self, Point(other))
            return sqrt(Add(*((a - b) ** 2 for a, b in zip(s, p))))
        distance = getattr(other, 'distance', None)
        if distance is None:
            raise TypeError('distance between Point and %s is not defined' % type(other))
        return distance(self)

    def dot(self, p):
        if not is_sequence(p):
            p = Point(p)
        return Add(*(a * b for a, b in zip(self, p)))

    def equals(self, other):
        if not isinstance(other, Point) or len(self) != len(other):
            return False
        return all((a.equals(b) for a, b in zip(self, other)))

    def _eval_evalf(self, prec=15, **options):
        dps = prec_to_dps(prec)
        coords = [x.evalf(n=dps, **options) for x in self.args]
        return Point(*coords, evaluate=False)

    def intersection(self, other):
        if not isinstance(other, GeometryEntity):
            other = Point(other)
        if isinstance(other, Point):
            if self == other:
                return [self]
            p1, p2 = Point._normalize_dimension(self, other)
            if p1 == self and p1 == p2:
                return [self]
            return []
        return other.intersection(self)

    def is_collinear(self, *args):
        points = (self,) + args
        points = Point._normalize_dimension(*[Point(i) for i in points])
        points = list(uniq(points))
        return Point.affine_rank(*points) <= 1

    def is_concyclic(self, *args):
        points = (self,) + args
        points = Point._normalize_dimension(*[Point(i) for i in points])
        points = list(uniq(points))
        if not Point.affine_rank(*points) <= 2:
            return False
        origin = points[0]
        points = [p - origin for p in points]
        mat = Matrix([list(i) + [i.dot(i)] for i in points])
        rref, pivots = mat.rref()
        if len(origin) not in pivots:
            return True
        return False

    @property
    def is_nonzero(self):
        is_zero = self.is_zero
        if is_zero is None:
            return None
        return not is_zero

    def is_scalar_multiple(self, p):
        s, o = Point._normalize_dimension(self, Point(p))
        if s.ambient_dimension == 2:
            (x1, y1), (x2, y2) = (s.args, o.args)
            rv = (x1 * y2 - x2 * y1).equals(0)
            if rv is None:
                raise Undecidable(filldedent('Cannot determine if %s is a scalar multiple of\n                    %s' % (s, o)))
        m = Matrix([s.args, o.args])
        return m.rank() < 2

    @property
    def is_zero(self):
        nonzero = [x.is_nonzero for x in self.args]
        if any(nonzero):
            return False
        if any((x is None for x in nonzero)):
            return None
        return True

    @property
    def length(self):
        return S.Zero

    def midpoint(self, p):
        s, p = Point._normalize_dimension(self, Point(p))
        return Point([simplify((a + b) * S.Half) for a, b in zip(s, p)])

    @property
    def origin(self):
        return Point([0] * len(self), evaluate=False)

    @property
    def orthogonal_direction(self):
        dim = self.ambient_dimension
        if self[0].is_zero:
            return Point([1] + (dim - 1) * [0])
        if self[1].is_zero:
            return Point([0, 1] + (dim - 2) * [0])
        return Point([-self[1], self[0]] + (dim - 2) * [0])

    @staticmethod
    def project(a, b):
        a, b = Point._normalize_dimension(Point(a), Point(b))
        if b.is_zero:
            raise ValueError('Cannot project to the zero vector.')
        return b * (a.dot(b) / b.dot(b))

    def taxicab_distance(self, p):
        s, p = Point._normalize_dimension(self, Point(p))
        return Add(*(abs(a - b) for a, b in zip(s, p)))

    def canberra_distance(self, p):
        s, p = Point._normalize_dimension(self, Point(p))
        if self.is_zero and p.is_zero:
            raise ValueError('Cannot project to the zero vector.')
        return Add(*(abs(a - b) / (abs(a) + abs(b)) for a, b in zip(s, p)))

    @property
    def unit(self):
        return self / abs(self)

class Point2D(Point):
    _ambient_dimension = 2

    def __new__(cls, *args, _nocheck=False, **kwargs):
        if not _nocheck:
            kwargs['dim'] = 2
            args = Point(*args, **kwargs)
        return GeometryEntity.__new__(cls, *args)

    def __contains__(self, item):
        return item == self

    @property
    def bounds(self):
        return (self.x, self.y, self.x, self.y)

    def rotate(self, angle, pt=None):
        c = cos(angle)
        s = sin(angle)
        rv = self
        if pt is not None:
            pt = Point(pt, dim=2)
            rv -= pt
        x, y = rv.args
        rv = Point(c * x - s * y, s * x + c * y)
        if pt is not None:
            rv += pt
        return rv

    def scale(self, x=1, y=1, pt=None):
        if pt:
            pt = Point(pt, dim=2)
            return self.translate(*(-pt).args).scale(x, y).translate(*pt.args)
        return Point(self.x * x, self.y * y)

    def transform(self, matrix):
        if not (matrix.is_Matrix and matrix.shape == (3, 3)):
            raise ValueError('matrix must be a 3x3 matrix')
        x, y = self.args
        return Point(*(Matrix(1, 3, [x, y, 1]) * matrix).tolist()[0][:2])

    def translate(self, x=0, y=0):
        return Point(self.x + x, self.y + y)

    @property
    def coordinates(self):
        return self.args

    @property
    def x(self):
        return self.args[0]

    @property
    def y(self):
        return self.args[1]

class Point3D(Point):
    _ambient_dimension = 3

    def __new__(cls, *args, _nocheck=False, **kwargs):
        if not _nocheck:
            kwargs['dim'] = 3
            args = Point(*args, **kwargs)
        return GeometryEntity.__new__(cls, *args)

    def __contains__(self, item):
        return item == self

    @staticmethod
    def are_collinear(*points):
        return Point.is_collinear(*points)

    def direction_cosine(self, point):
        a = self.direction_ratio(point)
        b = sqrt(Add(*(i ** 2 for i in a)))
        return [(point.x - self.x) / b, (point.y - self.y) / b, (point.z - self.z) / b]

    def direction_ratio(self, point):
        return [point.x - self.x, point.y - self.y, point.z - self.z]

    def intersection(self, other):
        if not isinstance(other, GeometryEntity):
            other = Point(other, dim=3)
        if isinstance(other, Point3D):
            if self == other:
                return [self]
            return []
        return other.intersection(self)

    def scale(self, x=1, y=1, z=1, pt=None):
        if pt:
            pt = Point3D(pt)
            return self.translate(*(-pt).args).scale(x, y, z).translate(*pt.args)
        return Point3D(self.x * x, self.y * y, self.z * z)

    def transform(self, matrix):
        if not (matrix.is_Matrix and matrix.shape == (4, 4)):
            raise ValueError('matrix must be a 4x4 matrix')
        x, y, z = self.args
        m = Transpose(matrix)
        return Point3D(*(Matrix(1, 4, [x, y, z, 1]) * m).tolist()[0][:3])

    def translate(self, x=0, y=0, z=0):
        return Point3D(self.x + x, self.y + y, self.z + z)

    @property
    def coordinates(self):
        return self.args

    @property
    def x(self):
        return self.args[0]

    @property
    def y(self):
        return self.args[1]

    @property
    def z(self):
        return self.args[2]