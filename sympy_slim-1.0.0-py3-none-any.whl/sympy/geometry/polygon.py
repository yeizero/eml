from __future__ import annotations
from sympy.core import Expr, S, oo, pi, sympify
from sympy.core.evalf import N
from sympy.core.sorting import default_sort_key, ordered
from sympy.core.symbol import _symbol, Dummy, Symbol
from sympy.external.mpmath import prec_to_dps
from sympy.functions.elementary.complexes import sign
from sympy.functions.elementary.piecewise import Piecewise
from sympy.functions.elementary.trigonometric import cos, sin, tan
from .ellipse import Circle
from .entity import GeometryEntity, GeometrySet
from .exceptions import GeometryError
from .line import Line, Segment, Ray
from .point import Point
from sympy.logic import And
from sympy.matrices import Matrix
from sympy.simplify.simplify import simplify
from sympy.solvers.solvers import solve
from sympy.utilities.iterables import has_dups, has_variety, uniq, rotate_left, least_rotation
from sympy.utilities.misc import as_int, func_name
import warnings
x, y, T = [Dummy('polygon_dummy', real=True) for i in range(3)]

class Polygon(GeometrySet):
    __slots__ = ()

    def __new__(cls, *args, n=0, **kwargs):
        if n:
            args = list(args)
            if len(args) == 2:
                args.append(n)
            elif len(args) == 3:
                args.insert(2, n)
            return RegularPolygon(*args, **kwargs)
        vertices = [Point(a, dim=2, **kwargs) for a in args]
        nodup = []
        for p in vertices:
            if nodup and p == nodup[-1]:
                continue
            nodup.append(p)
        if len(nodup) > 1 and nodup[-1] == nodup[0]:
            nodup.pop()
        i = -3
        while i < len(nodup) - 3 and len(nodup) > 2:
            a, b, c = (nodup[i], nodup[i + 1], nodup[i + 2])
            if Point.is_collinear(a, b, c):
                nodup.pop(i + 1)
                if a == c:
                    nodup.pop(i)
            else:
                i += 1
        vertices = list(nodup)
        if len(vertices) > 3:
            return GeometryEntity.__new__(cls, *vertices, **kwargs)
        elif len(vertices) == 3:
            return Triangle(*vertices, **kwargs)
        elif len(vertices) == 2:
            return Segment(*vertices, **kwargs)
        else:
            return Point(*vertices, **kwargs)

    @property
    def area(self):
        area = 0
        args = self.args
        for i in range(len(args)):
            x1, y1 = args[i - 1].args
            x2, y2 = args[i].args
            area += x1 * y2 - x2 * y1
        return simplify(area) / 2

    @staticmethod
    def _is_clockwise(a, b, c):
        ba = b - a
        ca = c - a
        t_area = simplify(ba.x * ca.y - ca.x * ba.y)
        res = t_area.is_nonpositive
        if res is None:
            raise ValueError("Can't determine orientation")
        return res

    @property
    def angles(self):
        args = self.vertices
        n = len(args)
        ret = {}
        for i in range(n):
            a, b, c = (args[i - 2], args[i - 1], args[i])
            reflex_ang = Ray(b, a).angle_between(Ray(b, c))
            if self._is_clockwise(a, b, c):
                ret[b] = 2 * S.Pi - reflex_ang
            else:
                ret[b] = reflex_ang
        wrong = ((sum(ret.values()) / S.Pi - 1) / (n - 2) - 1).is_positive
        if wrong:
            two_pi = 2 * S.Pi
            for b in ret:
                ret[b] = two_pi - ret[b]
        elif wrong is None:
            raise ValueError('could not determine Polygon orientation.')
        return ret

    @property
    def ambient_dimension(self):
        return self.vertices[0].ambient_dimension

    @property
    def perimeter(self):
        p = 0
        args = self.vertices
        for i in range(len(args)):
            p += args[i - 1].distance(args[i])
        return simplify(p)

    @property
    def vertices(self):
        return list(self.args)

    @property
    def centroid(self):
        area = self.area
        if area == 0:
            raise GeometryError('Centroid is undefined for a polygon with zero area.')
        A = 1 / (6 * area)
        cx, cy = (0, 0)
        args = self.args
        for i in range(len(args)):
            x1, y1 = args[i - 1].args
            x2, y2 = args[i].args
            v = x1 * y2 - x2 * y1
            cx += v * (x1 + x2)
            cy += v * (y1 + y2)
        return Point(simplify(A * cx), simplify(A * cy))

    def second_moment_of_area(self, point=None):
        I_xx, I_yy, I_xy = (0, 0, 0)
        args = self.vertices
        for i in range(len(args)):
            x1, y1 = args[i - 1].args
            x2, y2 = args[i].args
            v = x1 * y2 - x2 * y1
            I_xx += (y1 ** 2 + y1 * y2 + y2 ** 2) * v
            I_yy += (x1 ** 2 + x1 * x2 + x2 ** 2) * v
            I_xy += (x1 * y2 + 2 * x1 * y1 + 2 * x2 * y2 + x2 * y1) * v
        A = self.area
        c_x = self.centroid[0]
        c_y = self.centroid[1]
        I_xx_c = I_xx / 12 - A * c_y ** 2
        I_yy_c = I_yy / 12 - A * c_x ** 2
        I_xy_c = I_xy / 24 - A * (c_x * c_y)
        if point is None:
            return (I_xx_c, I_yy_c, I_xy_c)
        I_xx = I_xx_c + A * (point[1] - c_y) ** 2
        I_yy = I_yy_c + A * (point[0] - c_x) ** 2
        I_xy = I_xy_c + A * ((point[0] - c_x) * (point[1] - c_y))
        return (I_xx, I_yy, I_xy)

    def first_moment_of_area(self, point=None):
        if point:
            xc, yc = self.centroid
        else:
            point = self.centroid
            xc, yc = point
        h_line = Line(point, slope=0)
        v_line = Line(point, slope=S.Infinity)
        h_poly = self.cut_section(h_line)
        v_poly = self.cut_section(v_line)
        poly_1 = h_poly[0] if h_poly[0].area <= h_poly[1].area else h_poly[1]
        poly_2 = v_poly[0] if v_poly[0].area <= v_poly[1].area else v_poly[1]
        Q_x = (poly_1.centroid.y - yc) * poly_1.area
        Q_y = (poly_2.centroid.x - xc) * poly_2.area
        return (Q_x, Q_y)

    def polar_second_moment_of_area(self):
        second_moment = self.second_moment_of_area()
        return second_moment[0] + second_moment[1]

    def section_modulus(self, point=None):
        x_c, y_c = self.centroid
        if point is None:
            x_min, y_min, x_max, y_max = self.bounds
            y = max(y_c - y_min, y_max - y_c)
            x = max(x_c - x_min, x_max - x_c)
        else:
            y = point.y - y_c
            x = point.x - x_c
        second_moment = self.second_moment_of_area()
        S_x = second_moment[0] / y
        S_y = second_moment[1] / x
        return (S_x, S_y)

    @property
    def sides(self):
        res = []
        args = self.vertices
        for i in range(-len(args), 0):
            res.append(Segment(args[i], args[i + 1]))
        return res

    @property
    def bounds(self):
        verts = self.vertices
        xs = [p.x for p in verts]
        ys = [p.y for p in verts]
        return (min(xs), min(ys), max(xs), max(ys))

    def is_convex(self):
        args = self.vertices
        cw = self._is_clockwise(args[-2], args[-1], args[0])
        for i in range(1, len(args)):
            if cw ^ self._is_clockwise(args[i - 2], args[i - 1], args[i]):
                return False
        sides = self.sides
        for i, si in enumerate(sides):
            pts = si.args
            for j in range(1 if i == len(sides) - 1 else 0, i - 1):
                sj = sides[j]
                if sj.p1 not in pts and sj.p2 not in pts:
                    hit = si.intersection(sj)
                    if hit:
                        return False
        return True

    def encloses_point(self, p):
        p = Point(p, dim=2)
        if p in self.vertices or any((p in s for s in self.sides)):
            return False
        lit = []
        for v in self.vertices:
            lit.append(v - p)
            if lit[-1].free_symbols:
                return None
        poly = Polygon(*lit)
        args = poly.args
        indices = list(range(-len(args), 1))
        if poly.is_convex():
            orientation = None
            for i in indices:
                a = args[i]
                b = args[i + 1]
                test = (-a.y * (b.x - a.x) - -a.x * (b.y - a.y)).is_negative
                if orientation is None:
                    orientation = test
                elif test is not orientation:
                    return False
            return True
        hit_odd = False
        p1x, p1y = args[0].args
        for i in indices[1:]:
            p2x, p2y = args[i].args
            if 0 > min(p1y, p2y):
                if 0 <= max(p1y, p2y):
                    if 0 <= max(p1x, p2x):
                        if p1y != p2y:
                            xinters = -p1y * (p2x - p1x) / (p2y - p1y) + p1x
                            if p1x == p2x or 0 <= xinters:
                                hit_odd = not hit_odd
            p1x, p1y = (p2x, p2y)
        return hit_odd

    def arbitrary_point(self, parameter='t'):
        t = _symbol(parameter, real=True)
        if t.name in (f.name for f in self.free_symbols):
            raise ValueError('Symbol %s already appears in object and cannot be used as a parameter.' % t.name)
        sides = []
        perimeter = self.perimeter
        perim_fraction_start = 0
        for s in self.sides:
            side_perim_fraction = s.length / perimeter
            perim_fraction_end = perim_fraction_start + side_perim_fraction
            pt = s.arbitrary_point(parameter).subs(t, (t - perim_fraction_start) / side_perim_fraction)
            sides.append((pt, And(perim_fraction_start <= t, t < perim_fraction_end)))
            perim_fraction_start = perim_fraction_end
        return Piecewise(*sides)

    def parameter_value(self, other, t):
        if not isinstance(other, GeometryEntity):
            other = Point(other, dim=self.ambient_dimension)
        if not isinstance(other, Point):
            raise ValueError('other must be a point')
        if other.free_symbols:
            raise NotImplementedError('non-numeric coordinates')
        unknown = False
        p = self.arbitrary_point(T)
        for pt, cond in p.args:
            sol = solve(pt - other, T, dict=True)
            if not sol:
                continue
            value = sol[0][T]
            if simplify(cond.subs(T, value)) == True:
                return {t: value}
            unknown = True
        if unknown:
            raise ValueError('Given point may not be on %s' % func_name(self))
        raise ValueError('Given point is not on %s' % func_name(self))

    def plot_interval(self, parameter='t'):
        t = Symbol(parameter, real=True)
        return [t, 0, 1]

    def intersection(self, o):
        intersection_result = []
        k = o.sides if isinstance(o, Polygon) else [o]
        for side in self.sides:
            for side1 in k:
                intersection_result.extend(side.intersection(side1))
        intersection_result = list(uniq(intersection_result))
        points = [entity for entity in intersection_result if isinstance(entity, Point)]
        segments = [entity for entity in intersection_result if isinstance(entity, Segment)]
        if points and segments:
            points_in_segments = list(uniq([point for point in points for segment in segments if point in segment]))
            if points_in_segments:
                for i in points_in_segments:
                    points.remove(i)
            return list(ordered(segments + points))
        else:
            return list(ordered(intersection_result))

    def cut_section(self, line):
        intersection_points = self.intersection(line)
        if not intersection_points:
            raise ValueError('This line does not intersect the polygon')
        points = list(self.vertices)
        points.append(points[0])
        eq = line.equation(x, y)
        a = eq.coeff(x)
        b = eq.coeff(y)
        upper_vertices = []
        lower_vertices = []
        prev = True
        prev_point = None
        for point in points:
            compare = eq.subs({x: point.x, y: point.y}) / b if b else eq.subs(x, point.x) / a
            if compare > 0:
                if not prev:
                    edge = Line(point, prev_point)
                    new_point = edge.intersection(line)
                    upper_vertices.append(new_point[0])
                    lower_vertices.append(new_point[0])
                upper_vertices.append(point)
                prev = True
            else:
                if prev and prev_point:
                    edge = Line(point, prev_point)
                    new_point = edge.intersection(line)
                    upper_vertices.append(new_point[0])
                    lower_vertices.append(new_point[0])
                lower_vertices.append(point)
                prev = False
            prev_point = point
        upper_polygon, lower_polygon = (None, None)
        if upper_vertices and isinstance(Polygon(*upper_vertices), Polygon):
            upper_polygon = Polygon(*upper_vertices)
        if lower_vertices and isinstance(Polygon(*lower_vertices), Polygon):
            lower_polygon = Polygon(*lower_vertices)
        return (upper_polygon, lower_polygon)

    def distance(self, o):
        if isinstance(o, Point):
            dist = oo
            for side in self.sides:
                current = side.distance(o)
                if current == 0:
                    return S.Zero
                elif current < dist:
                    dist = current
            return dist
        elif isinstance(o, Polygon) and self.is_convex() and o.is_convex():
            return self._do_poly_distance(o)
        raise NotImplementedError()

    def _do_poly_distance(self, e2):
        e1 = self
        'Tests for a possible intersection between the polygons and outputs a warning'
        e1_center = e1.centroid
        e2_center = e2.centroid
        e1_max_radius = S.Zero
        e2_max_radius = S.Zero
        for vertex in e1.vertices:
            r = Point.distance(e1_center, vertex)
            if e1_max_radius < r:
                e1_max_radius = r
        for vertex in e2.vertices:
            r = Point.distance(e2_center, vertex)
            if e2_max_radius < r:
                e2_max_radius = r
        center_dist = Point.distance(e1_center, e2_center)
        if center_dist <= e1_max_radius + e2_max_radius:
            warnings.warn('Polygons may intersect producing erroneous output', stacklevel=3)
        '\n        Find the upper rightmost vertex of e1 and the lowest leftmost vertex of e2\n        '
        e1_ymax = Point(0, -oo)
        e2_ymin = Point(0, oo)
        for vertex in e1.vertices:
            if vertex.y > e1_ymax.y or (vertex.y == e1_ymax.y and vertex.x > e1_ymax.x):
                e1_ymax = vertex
        for vertex in e2.vertices:
            if vertex.y < e2_ymin.y or (vertex.y == e2_ymin.y and vertex.x < e2_ymin.x):
                e2_ymin = vertex
        min_dist = Point.distance(e1_ymax, e2_ymin)
        '\n        Produce a dictionary with vertices of e1 as the keys and, for each vertex, the points\n        to which the vertex is connected as its value. The same is then done for e2.\n        '
        e1_connections = {}
        e2_connections = {}
        for side in e1.sides:
            if side.p1 in e1_connections:
                e1_connections[side.p1].append(side.p2)
            else:
                e1_connections[side.p1] = [side.p2]
            if side.p2 in e1_connections:
                e1_connections[side.p2].append(side.p1)
            else:
                e1_connections[side.p2] = [side.p1]
        for side in e2.sides:
            if side.p1 in e2_connections:
                e2_connections[side.p1].append(side.p2)
            else:
                e2_connections[side.p1] = [side.p2]
            if side.p2 in e2_connections:
                e2_connections[side.p2].append(side.p1)
            else:
                e2_connections[side.p2] = [side.p1]
        e1_current = e1_ymax
        e2_current = e2_ymin
        support_line = Line(Point(S.Zero, S.Zero), Point(S.One, S.Zero))
        '\n        Determine which point in e1 and e2 will be selected after e2_ymin and e1_ymax,\n        this information combined with the above produced dictionaries determines the\n        path that will be taken around the polygons\n        '
        point1 = e1_connections[e1_ymax][0]
        point2 = e1_connections[e1_ymax][1]
        angle1 = support_line.angle_between(Line(e1_ymax, point1))
        angle2 = support_line.angle_between(Line(e1_ymax, point2))
        if angle1 < angle2:
            e1_next = point1
        elif angle2 < angle1:
            e1_next = point2
        elif Point.distance(e1_ymax, point1) > Point.distance(e1_ymax, point2):
            e1_next = point2
        else:
            e1_next = point1
        point1 = e2_connections[e2_ymin][0]
        point2 = e2_connections[e2_ymin][1]
        angle1 = support_line.angle_between(Line(e2_ymin, point1))
        angle2 = support_line.angle_between(Line(e2_ymin, point2))
        if angle1 > angle2:
            e2_next = point1
        elif angle2 > angle1:
            e2_next = point2
        elif Point.distance(e2_ymin, point1) > Point.distance(e2_ymin, point2):
            e2_next = point2
        else:
            e2_next = point1
        '\n        Loop which determines the distance between anti-podal pairs and updates the\n        minimum distance accordingly. It repeats until it reaches the starting position.\n        '
        while True:
            e1_angle = support_line.angle_between(Line(e1_current, e1_next))
            e2_angle = pi - support_line.angle_between(Line(e2_current, e2_next))
            if (e1_angle < e2_angle) is True:
                support_line = Line(e1_current, e1_next)
                e1_segment = Segment(e1_current, e1_next)
                min_dist_current = e1_segment.distance(e2_current)
                if min_dist_current.evalf() < min_dist.evalf():
                    min_dist = min_dist_current
                if e1_connections[e1_next][0] != e1_current:
                    e1_current = e1_next
                    e1_next = e1_connections[e1_next][0]
                else:
                    e1_current = e1_next
                    e1_next = e1_connections[e1_next][1]
            elif (e1_angle > e2_angle) is True:
                support_line = Line(e2_next, e2_current)
                e2_segment = Segment(e2_current, e2_next)
                min_dist_current = e2_segment.distance(e1_current)
                if min_dist_current.evalf() < min_dist.evalf():
                    min_dist = min_dist_current
                if e2_connections[e2_next][0] != e2_current:
                    e2_current = e2_next
                    e2_next = e2_connections[e2_next][0]
                else:
                    e2_current = e2_next
                    e2_next = e2_connections[e2_next][1]
            else:
                support_line = Line(e1_current, e1_next)
                e1_segment = Segment(e1_current, e1_next)
                e2_segment = Segment(e2_current, e2_next)
                min1 = e1_segment.distance(e2_next)
                min2 = e2_segment.distance(e1_next)
                min_dist_current = min(min1, min2)
                if min_dist_current.evalf() < min_dist.evalf():
                    min_dist = min_dist_current
                if e1_connections[e1_next][0] != e1_current:
                    e1_current = e1_next
                    e1_next = e1_connections[e1_next][0]
                else:
                    e1_current = e1_next
                    e1_next = e1_connections[e1_next][1]
                if e2_connections[e2_next][0] != e2_current:
                    e2_current = e2_next
                    e2_next = e2_connections[e2_next][0]
                else:
                    e2_current = e2_next
                    e2_next = e2_connections[e2_next][1]
            if e1_current == e1_ymax and e2_current == e2_ymin:
                break
        return min_dist

    def _svg(self, scale_factor=1.0, fill_color='#66cc99'):
        verts = map(N, self.vertices)
        coords = ['{},{}'.format(p.x, p.y) for p in verts]
        path = 'M {} L {} z'.format(coords[0], ' L '.join(coords[1:]))
        return '<path fill-rule="evenodd" fill="{2}" stroke="#555555" stroke-width="{0}" opacity="0.6" d="{1}" />'.format(2.0 * scale_factor, path, fill_color)

    def _hashable_content(self):
        D = {}

        def ref_list(point_list):
            kee = {}
            for i, p in enumerate(ordered(set(point_list))):
                kee[p] = i
                D[i] = p
            return [kee[p] for p in point_list]
        S1 = ref_list(self.args)
        r_nor = rotate_left(S1, least_rotation(S1))
        S2 = ref_list(list(reversed(self.args)))
        r_rev = rotate_left(S2, least_rotation(S2))
        if r_nor < r_rev:
            r = r_nor
        else:
            r = r_rev
        canonical_args = [D[order] for order in r]
        return tuple(canonical_args)

    def __contains__(self, o):
        if isinstance(o, Polygon):
            return self == o
        elif isinstance(o, Segment):
            return any((o in s for s in self.sides))
        elif isinstance(o, Point):
            if o in self.vertices:
                return True
            for side in self.sides:
                if o in side:
                    return True
        return False

    def bisectors(p, prec=None):
        b = {}
        pts = list(p.args)
        pts.append(pts[0])
        cw = Polygon._is_clockwise(*pts[:3])
        if cw:
            pts = list(reversed(pts))
        for v, a in p.angles.items():
            i = pts.index(v)
            p1, p2 = Point._normalize_dimension(pts[i], pts[i + 1])
            ray = Ray(p1, p2).rotate(a / 2, v)
            dir = ray.direction
            ray = Ray(ray.p1, ray.p1 + dir / dir.distance((0, 0)))
            if prec is not None:
                ray = Ray(ray.p1, ray.p2.n(prec))
            b[v] = ray
        return b

class RegularPolygon(Polygon):
    __slots__ = ('_n', '_center', '_radius', '_rot')

    def __new__(self, c, r, n, rot=0, **kwargs):
        r, n, rot = map(sympify, (r, n, rot))
        c = Point(c, dim=2, **kwargs)
        if not isinstance(r, Expr):
            raise GeometryError('r must be an Expr object, not %s' % r)
        if n.is_Number:
            as_int(n)
            if n < 3:
                raise GeometryError('n must be a >= 3, not %s' % n)
        obj = GeometryEntity.__new__(self, c, r, n, **kwargs)
        obj._n = n
        obj._center = c
        obj._radius = r
        obj._rot = rot % (2 * S.Pi / n) if rot.is_number else rot
        return obj

    def _eval_evalf(self, prec=15, **options):
        c, r, n, a = self.args
        dps = prec_to_dps(prec)
        c, r, a = [i.evalf(n=dps, **options) for i in (c, r, a)]
        return self.func(c, r, n, a)

    @property
    def args(self):
        return (self._center, self._radius, self._n, self._rot)

    def __str__(self):
        return 'RegularPolygon(%s, %s, %s, %s)' % tuple(self.args)

    def __repr__(self):
        return 'RegularPolygon(%s, %s, %s, %s)' % tuple(self.args)

    @property
    def area(self):
        c, r, n, rot = self.args
        return sign(r) * n * self.length ** 2 / (4 * tan(pi / n))

    @property
    def length(self):
        return self.radius * 2 * sin(pi / self._n)

    @property
    def center(self):
        return self._center
    centroid = center

    @property
    def circumcenter(self):
        return self.center

    @property
    def radius(self):
        return self._radius

    @property
    def circumradius(self):
        return self.radius

    @property
    def rotation(self):
        return self._rot

    @property
    def apothem(self):
        return self.radius * cos(S.Pi / self._n)

    @property
    def inradius(self):
        return self.apothem

    @property
    def interior_angle(self):
        return (self._n - 2) * S.Pi / self._n

    @property
    def exterior_angle(self):
        return 2 * S.Pi / self._n

    @property
    def circumcircle(self):
        return Circle(self.center, self.radius)

    @property
    def incircle(self):
        return Circle(self.center, self.apothem)

    @property
    def angles(self):
        ret = {}
        ang = self.interior_angle
        for v in self.vertices:
            ret[v] = ang
        return ret

    def encloses_point(self, p):
        c = self.center
        d = Segment(c, p).length
        if d >= self.radius:
            return False
        elif d < self.inradius:
            return True
        else:
            return Polygon.encloses_point(self, p)

    def spin(self, angle):
        self._rot += angle

    def rotate(self, angle, pt=None):
        r = type(self)(*self.args)
        r._rot += angle
        return GeometryEntity.rotate(r, angle, pt)

    def scale(self, x=1, y=1, pt=None):
        if pt:
            pt = Point(pt, dim=2)
            return self.translate(*(-pt).args).scale(x, y).translate(*pt.args)
        if x != y:
            return Polygon(*self.vertices).scale(x, y)
        c, r, n, rot = self.args
        r *= x
        return self.func(c, r, n, rot)

    def reflect(self, line):
        c, r, n, rot = self.args
        v = self.vertices[0]
        d = v - c
        cc = c.reflect(line)
        vv = v.reflect(line)
        dd = vv - cc
        l1 = Ray((0, 0), dd)
        l2 = Ray((0, 0), d)
        ang = l1.closing_angle(l2)
        rot += ang
        return self.func(cc, -r, n, rot)

    @property
    def vertices(self):
        c = self._center
        r = abs(self._radius)
        rot = self._rot
        v = 2 * S.Pi / self._n
        return [Point(c.x + r * cos(k * v + rot), c.y + r * sin(k * v + rot)) for k in range(self._n)]

    def __eq__(self, o):
        if not isinstance(o, Polygon):
            return False
        elif not isinstance(o, RegularPolygon):
            return Polygon.__eq__(o, self)
        return self.args == o.args

    def __hash__(self):
        return super().__hash__()

class Triangle(Polygon):

    def __new__(cls, *args, **kwargs):
        if len(args) != 3:
            if 'sss' in kwargs:
                return _sss(*[simplify(a) for a in kwargs['sss']])
            if 'asa' in kwargs:
                return _asa(*[simplify(a) for a in kwargs['asa']])
            if 'sas' in kwargs:
                return _sas(*[simplify(a) for a in kwargs['sas']])
            msg = 'Triangle instantiates with three points or a valid keyword.'
            raise GeometryError(msg)
        vertices = [Point(a, dim=2, **kwargs) for a in args]
        nodup = []
        for p in vertices:
            if nodup and p == nodup[-1]:
                continue
            nodup.append(p)
        if len(nodup) > 1 and nodup[-1] == nodup[0]:
            nodup.pop()
        i = -3
        while i < len(nodup) - 3 and len(nodup) > 2:
            a, b, c = sorted([nodup[i], nodup[i + 1], nodup[i + 2]], key=default_sort_key)
            if Point.is_collinear(a, b, c):
                nodup[i] = a
                nodup[i + 1] = None
                nodup.pop(i + 1)
            i += 1
        vertices = list(filter(lambda x: x is not None, nodup))
        if len(vertices) == 3:
            return GeometryEntity.__new__(cls, *vertices, **kwargs)
        elif len(vertices) == 2:
            return Segment(*vertices, **kwargs)
        else:
            return Point(*vertices, **kwargs)

    @property
    def vertices(self):
        return self.args

    def is_similar(t1, t2):
        if not isinstance(t2, Polygon):
            return False
        s1_1, s1_2, s1_3 = [side.length for side in t1.sides]
        s2 = [side.length for side in t2.sides]

        def _are_similar(u1, u2, u3, v1, v2, v3):
            e1 = simplify(u1 / v1)
            e2 = simplify(u2 / v2)
            e3 = simplify(u3 / v3)
            return bool(e1 == e2) and bool(e2 == e3)
        return _are_similar(s1_1, s1_2, s1_3, *s2) or _are_similar(s1_1, s1_3, s1_2, *s2) or _are_similar(s1_2, s1_1, s1_3, *s2) or _are_similar(s1_2, s1_3, s1_1, *s2) or _are_similar(s1_3, s1_1, s1_2, *s2) or _are_similar(s1_3, s1_2, s1_1, *s2)

    def is_equilateral(self):
        return not has_variety((s.length for s in self.sides))

    def is_isosceles(self):
        return has_dups((s.length for s in self.sides))

    def is_scalene(self):
        return not has_dups((s.length for s in self.sides))

    def is_right(self):
        s = self.sides
        return Segment.is_perpendicular(s[0], s[1]) or Segment.is_perpendicular(s[1], s[2]) or Segment.is_perpendicular(s[0], s[2])

    @property
    def altitudes(self):
        s = self.sides
        v = self.vertices
        return {v[0]: s[1].perpendicular_segment(v[0]), v[1]: s[2].perpendicular_segment(v[1]), v[2]: s[0].perpendicular_segment(v[2])}

    @property
    def orthocenter(self):
        a = self.altitudes
        v = self.vertices
        return Line(a[v[0]]).intersection(Line(a[v[1]]))[0]

    @property
    def circumcenter(self):
        a, b, c = [x.perpendicular_bisector() for x in self.sides]
        return a.intersection(b)[0]

    @property
    def circumradius(self):
        return Point.distance(self.circumcenter, self.vertices[0])

    @property
    def circumcircle(self):
        return Circle(self.circumcenter, self.circumradius)

    def bisectors(self):
        s = [Line(l) for l in self.sides]
        v = self.vertices
        c = self.incenter
        l1 = Segment(v[0], Line(v[0], c).intersection(s[1])[0])
        l2 = Segment(v[1], Line(v[1], c).intersection(s[2])[0])
        l3 = Segment(v[2], Line(v[2], c).intersection(s[0])[0])
        return {v[0]: l1, v[1]: l2, v[2]: l3}

    @property
    def incenter(self):
        s = self.sides
        l = Matrix([s[i].length for i in [1, 2, 0]])
        p = sum(l)
        v = self.vertices
        x = simplify(l.dot(Matrix([vi.x for vi in v])) / p)
        y = simplify(l.dot(Matrix([vi.y for vi in v])) / p)
        return Point(x, y)

    @property
    def inradius(self):
        return simplify(2 * self.area / self.perimeter)

    @property
    def incircle(self):
        return Circle(self.incenter, self.inradius)

    @property
    def exradii(self):
        side = self.sides
        a = side[0].length
        b = side[1].length
        c = side[2].length
        s = (a + b + c) / 2
        area = self.area
        exradii = {self.sides[0]: simplify(area / (s - a)), self.sides[1]: simplify(area / (s - b)), self.sides[2]: simplify(area / (s - c))}
        return exradii

    @property
    def excenters(self):
        s = self.sides
        v = self.vertices
        a = s[1].length
        b = s[2].length
        c = s[0].length
        x = [v[0].x, v[1].x, v[2].x]
        y = [v[0].y, v[1].y, v[2].y]
        exc_coords = {'x1': simplify((-a * x[0] + b * x[1] + c * x[2]) / (-a + b + c)), 'x2': simplify((a * x[0] - b * x[1] + c * x[2]) / (a - b + c)), 'x3': simplify((a * x[0] + b * x[1] - c * x[2]) / (a + b - c)), 'y1': simplify((-a * y[0] + b * y[1] + c * y[2]) / (-a + b + c)), 'y2': simplify((a * y[0] - b * y[1] + c * y[2]) / (a - b + c)), 'y3': simplify((a * y[0] + b * y[1] - c * y[2]) / (a + b - c))}
        excenters = {s[0]: Point(exc_coords['x1'], exc_coords['y1']), s[1]: Point(exc_coords['x2'], exc_coords['y2']), s[2]: Point(exc_coords['x3'], exc_coords['y3'])}
        return excenters

    @property
    def medians(self):
        s = self.sides
        v = self.vertices
        return {v[0]: Segment(v[0], s[1].midpoint), v[1]: Segment(v[1], s[2].midpoint), v[2]: Segment(v[2], s[0].midpoint)}

    @property
    def medial(self):
        s = self.sides
        return Triangle(s[0].midpoint, s[1].midpoint, s[2].midpoint)

    @property
    def nine_point_circle(self):
        return Circle(*self.medial.vertices)

    @property
    def eulerline(self):
        if self.is_equilateral():
            return self.orthocenter
        return Line(self.orthocenter, self.circumcenter)

def rad(d):
    return d * pi / 180

def deg(r):
    return r / pi * 180

def _slope(d):
    rv = tan(rad(d))
    return rv

def _asa(d1, l, d2):
    xy = Line((0, 0), slope=_slope(d1)).intersection(Line((l, 0), slope=_slope(180 - d2)))[0]
    return Triangle((0, 0), (l, 0), xy)

def _sss(l1, l2, l3):
    c1 = Circle((0, 0), l3)
    c2 = Circle((l1, 0), l2)
    inter = [a for a in c1.intersection(c2) if a.y.is_nonnegative]
    if not inter:
        return None
    pt = inter[0]
    return Triangle((0, 0), (l1, 0), pt)

def _sas(l1, d, l2):
    p1 = Point(0, 0)
    p2 = Point(l2, 0)
    p3 = Point(cos(rad(d)) * l1, sin(rad(d)) * l1)
    return Triangle(p1, p2, p3)