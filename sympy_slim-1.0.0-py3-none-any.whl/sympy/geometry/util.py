from __future__ import annotations
from collections import deque
from math import sqrt as _sqrt
from sympy import nsimplify
from .entity import GeometryEntity
from .exceptions import GeometryError
from .point import Point, Point2D, Point3D
from sympy.core.containers import OrderedSet
from sympy.core.exprtools import factor_terms
from sympy.core.function import Function, expand_mul
from sympy.core.numbers import Float
from sympy.core.sorting import ordered
from sympy.core.symbol import Symbol
from sympy.core.singleton import S
from sympy.external.mpmath import prec_to_dps
from sympy.polys.polytools import cancel
from sympy.functions.elementary.miscellaneous import sqrt
from sympy.utilities.iterables import is_sequence

def find(x, equation):
    free = equation.free_symbols
    xs = [i for i in free if (i.name if isinstance(x, str) else i) == x]
    if not xs:
        raise ValueError('could not find %s' % x)
    if len(xs) != 1:
        raise ValueError('ambiguous %s' % x)
    return xs[0]

def _ordered_points(p):
    return tuple(sorted(p, key=lambda x: x.args))

def are_coplanar(*e):
    from .line import LinearEntity3D
    from .plane import Plane
    e = set(e)
    for i in list(e):
        if isinstance(i, Plane):
            e.remove(i)
            return all((p.is_coplanar(i) for p in e))
    if all((isinstance(i, Point3D) for i in e)):
        if len(e) < 3:
            return False
        a, b = (e.pop(), e.pop())
        for i in list(e):
            if Point3D.are_collinear(a, b, i):
                e.remove(i)
        if not e:
            return False
        else:
            p = Plane(a, b, e.pop())
            for i in e:
                if i not in p:
                    return False
            return True
    else:
        pt3d = []
        for i in e:
            if isinstance(i, Point3D):
                pt3d.append(i)
            elif isinstance(i, LinearEntity3D):
                pt3d.extend(i.args)
            elif isinstance(i, GeometryEntity):
                for p in i.args:
                    if isinstance(p, Point):
                        pt3d.append(Point3D(*p.args + (0,)))
        return are_coplanar(*pt3d)

def are_similar(e1, e2):
    if e1 == e2:
        return True
    is_similar1 = getattr(e1, 'is_similar', None)
    if is_similar1:
        return is_similar1(e2)
    is_similar2 = getattr(e2, 'is_similar', None)
    if is_similar2:
        return is_similar2(e1)
    n1 = e1.__class__.__name__
    n2 = e2.__class__.__name__
    raise GeometryError('Cannot test similarity between %s and %s' % (n1, n2))

def centroid(*args):
    from .line import Segment
    from .polygon import Polygon
    if args:
        if all((isinstance(g, Point) for g in args)):
            c = Point(0, 0)
            for g in args:
                c += g
            den = len(args)
        elif all((isinstance(g, Segment) for g in args)):
            c = Point(0, 0)
            L = 0
            for g in args:
                l = g.length
                c += g.midpoint * l
                L += l
            den = L
        elif all((isinstance(g, Polygon) for g in args)):
            c = Point(0, 0)
            A = 0
            for g in args:
                a = g.area
                c += g.centroid * a
                A += a
            den = A
        else:
            return None
        c /= den
        return c.func(*[i.simplify() for i in c.args])

def closest_points(*args):
    p = [Point2D(i) for i in set(args)]
    if len(p) < 2:
        raise ValueError('At least 2 distinct points must be given.')
    try:
        p.sort(key=lambda x: x.args)
    except TypeError:
        raise ValueError('The points could not be sorted.')
    if not all((i.is_Rational for j in p for i in j.args)):

        def hypot(x, y):
            arg = x * x + y * y
            if arg.is_Rational:
                return _sqrt(arg)
            return sqrt(arg)
    else:
        from math import hypot
    rv = [(0, 1)]
    best_dist = hypot(p[1].x - p[0].x, p[1].y - p[0].y)
    left = 0
    box = deque([0, 1])
    for i in range(2, len(p)):
        while left < i and p[i][0] - p[left][0] > best_dist:
            box.popleft()
            left += 1
        for j in box:
            d = hypot(p[i].x - p[j].x, p[i].y - p[j].y)
            if d < best_dist:
                rv = [(j, i)]
            elif d == best_dist:
                rv.append((j, i))
            else:
                continue
            best_dist = d
        box.append(i)
    return {tuple([p[i] for i in pair]) for pair in rv}

def convex_hull(*args, polygon=True):
    from .line import Segment
    from .polygon import Polygon
    p = OrderedSet()
    for e in args:
        if not isinstance(e, GeometryEntity):
            try:
                e = Point(e)
            except NotImplementedError:
                raise ValueError('%s is not a GeometryEntity and cannot be made into Point' % str(e))
        if isinstance(e, Point):
            p.add(e)
        elif isinstance(e, Segment):
            p.update(e.points)
        elif isinstance(e, Polygon):
            p.update(e.vertices)
        else:
            raise NotImplementedError('Convex hull for %s not implemented.' % type(e))
    if any((len(x) != 2 for x in p)):
        raise ValueError('Can only compute the convex hull in two dimensions')
    p = list(p)
    if len(p) == 1:
        return p[0] if polygon else (p[0], None)
    elif len(p) == 2:
        s = Segment(p[0], p[1])
        return s if polygon else (s, None)

    def _orientation(p, q, r):
        return (q.y - p.y) * (r.x - p.x) - (q.x - p.x) * (r.y - p.y)
    U = []
    L = []
    try:
        p.sort(key=lambda x: x.args)
    except TypeError:
        raise ValueError('The points could not be sorted.')
    for p_i in p:
        while len(U) > 1 and _orientation(U[-2], U[-1], p_i) <= 0:
            U.pop()
        while len(L) > 1 and _orientation(L[-2], L[-1], p_i) >= 0:
            L.pop()
        U.append(p_i)
        L.append(p_i)
    U.reverse()
    convexHull = tuple(L + U[1:-1])
    if len(convexHull) == 2:
        s = Segment(convexHull[0], convexHull[1])
        return s if polygon else (s, None)
    if polygon:
        return Polygon(*convexHull)
    else:
        U.reverse()
        return (U, L)

def farthest_points(*args):

    def rotatingCalipers(Points):
        U, L = convex_hull(*Points, **{'polygon': False})
        if L is None:
            if isinstance(U, Point):
                raise ValueError('At least two distinct points must be given.')
            yield U.args
        else:
            i = 0
            j = len(L) - 1
            while i < len(U) - 1 or j > 0:
                yield (U[i], L[j])
                if i == len(U) - 1:
                    j -= 1
                elif j == 0:
                    i += 1
                elif (U[i + 1].y - U[i].y) * (L[j].x - L[j - 1].x) > (L[j].y - L[j - 1].y) * (U[i + 1].x - U[i].x):
                    i += 1
                else:
                    j -= 1
    p = [Point2D(i) for i in set(args)]
    if not all((i.is_Rational for j in p for i in j.args)):

        def hypot(x, y):
            arg = x * x + y * y
            if arg.is_Rational:
                return _sqrt(arg)
            return sqrt(arg)
    else:
        from math import hypot
    rv = []
    diam = 0
    for pair in rotatingCalipers(args):
        h, q = _ordered_points(pair)
        d = hypot(h.x - q.x, h.y - q.y)
        if d > diam:
            rv = [(h, q)]
        elif d == diam:
            rv.append((h, q))
        else:
            continue
        diam = d
    return set(rv)

def idiff(eq, y, x, n=1):
    if is_sequence(y):
        dep = set(y)
        y = y[0]
    elif isinstance(y, Symbol):
        dep = {y}
    elif isinstance(y, Function):
        pass
    else:
        raise ValueError('expecting x-dependent symbol(s) or function(s) but got: %s' % y)
    f = {s: Function(s.name)(x) for s in eq.free_symbols if s != x and s in dep}
    if isinstance(y, Symbol):
        dydx = Function(y.name)(x).diff(x)
    else:
        dydx = y.diff(x)
    eq = eq.subs(f)
    derivs = {}
    for i in range(n):
        deq = eq.diff(x)
        b = deq.xreplace({dydx: S.Zero})
        a = (deq - b).xreplace({dydx: S.One})
        yp = factor_terms(expand_mul(cancel((-b / a).subs(derivs)), deep=False))
        if i == n - 1:
            return yp.subs([(v, k) for k, v in f.items()])
        derivs[dydx] = yp
        eq = dydx - yp
        dydx = dydx.diff(x)

def intersection(*entities, pairwise=False, **kwargs):
    if len(entities) <= 1:
        return []
    entities = list(entities)
    prec = None
    for i, e in enumerate(entities):
        if not isinstance(e, GeometryEntity):
            e = Point(e)
        d = {}
        for f in e.atoms(Float):
            prec = f._prec if prec is None else min(f._prec, prec)
            d.setdefault(f, nsimplify(f, rational=True))
        entities[i] = e.xreplace(d)
    if not pairwise:
        res = entities[0].intersection(entities[1])
        for entity in entities[2:]:
            newres = []
            for x in res:
                newres.extend(x.intersection(entity))
            res = newres
    else:
        ans = []
        for j in range(len(entities)):
            for k in range(j + 1, len(entities)):
                ans.extend(intersection(entities[j], entities[k]))
        res = list(ordered(set(ans)))
    if prec is not None:
        p = prec_to_dps(prec)
        res = [i.n(p) for i in res]
    return res