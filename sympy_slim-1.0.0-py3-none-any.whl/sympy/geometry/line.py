from __future__ import annotations
from sympy.core.containers import Tuple
from sympy.core.evalf import N
from sympy.core.expr import Expr
from sympy.core.numbers import Rational, oo, Float
from sympy.core.relational import Eq
from sympy.core.singleton import S
from sympy.core.sorting import ordered
from sympy.core.symbol import _symbol, Dummy, uniquely_named_symbol
from sympy.core.sympify import sympify
from sympy.functions.elementary.piecewise import Piecewise
from sympy.functions.elementary.trigonometric import _pi_coeff, acos, tan, atan2
from .entity import GeometryEntity, GeometrySet
from .exceptions import GeometryError
from .point import Point, Point3D
from .util import find, intersection
from sympy.logic.boolalg import And
from sympy.matrices import Matrix
from sympy.sets.sets import Intersection
from sympy.simplify.simplify import simplify
from sympy.solvers.solvers import solve
from sympy.solvers.solveset import linear_coeffs
from sympy.utilities.misc import Undecidable, filldedent
import random
t, u = [Dummy('line_dummy') for i in range(2)]

class LinearEntity(GeometrySet):

    def __new__(cls, p1, p2=None, **kwargs):
        p1, p2 = Point._normalize_dimension(p1, p2)
        if p1 == p2:
            raise ValueError('%s.__new__ requires two unique Points.' % cls.__name__)
        if len(p1) != len(p2):
            raise ValueError('%s.__new__ requires two Points of equal dimension.' % cls.__name__)
        return GeometryEntity.__new__(cls, p1, p2, **kwargs)

    def __contains__(self, other):
        result = self.contains(other)
        if result is not None:
            return result
        else:
            raise Undecidable("Cannot decide whether '%s' contains '%s'" % (self, other))

    def _span_test(self, other):
        if self.p1 == other:
            return 0
        rel_pos = other - self.p1
        d = self.direction
        if d.dot(rel_pos) > 0:
            return 1
        return -1

    @property
    def ambient_dimension(self):
        return len(self.p1)

    def angle_between(l1, l2):
        if not isinstance(l1, LinearEntity) or not isinstance(l2, LinearEntity):
            raise TypeError('Must pass only LinearEntity objects')
        v1, v2 = (l1.direction, l2.direction)
        return acos(v1.dot(v2) / (abs(v1) * abs(v2)))

    def smallest_angle_between(l1, l2):
        if not isinstance(l1, LinearEntity) or not isinstance(l2, LinearEntity):
            raise TypeError('Must pass only LinearEntity objects')
        v1, v2 = (l1.direction, l2.direction)
        return acos(abs(v1.dot(v2)) / (abs(v1) * abs(v2)))

    def arbitrary_point(self, parameter='t'):
        t = _symbol(parameter, real=True)
        if t.name in (f.name for f in self.free_symbols):
            raise ValueError(filldedent('\n                Symbol %s already appears in object\n                and cannot be used as a parameter.\n                ' % t.name))
        return self.p1 + (self.p2 - self.p1) * t

    @staticmethod
    def are_concurrent(*lines):
        common_points = Intersection(*lines)
        if common_points.is_FiniteSet and len(common_points) == 1:
            return True
        return False

    def contains(self, other):
        raise NotImplementedError()

    @property
    def direction(self):
        return self.p2 - self.p1

    def intersection(self, other):

        def intersect_parallel_rays(ray1, ray2):
            if ray1.direction.dot(ray2.direction) > 0:
                return [ray2] if ray1._span_test(ray2.p1) >= 0 else [ray1]
            else:
                st = ray1._span_test(ray2.p1)
                if st < 0:
                    return []
                elif st == 0:
                    return [ray2.p1]
                return [Segment(ray1.p1, ray2.p1)]

        def intersect_parallel_ray_and_segment(ray, seg):
            st1, st2 = (ray._span_test(seg.p1), ray._span_test(seg.p2))
            if st1 < 0 and st2 < 0:
                return []
            elif st1 >= 0 and st2 >= 0:
                return [seg]
            elif st1 >= 0:
                return [Segment(ray.p1, seg.p1)]
            else:
                return [Segment(ray.p1, seg.p2)]

        def intersect_parallel_segments(seg1, seg2):
            if seg1.contains(seg2):
                return [seg2]
            if seg2.contains(seg1):
                return [seg1]
            if seg1.direction.dot(seg2.direction) < 0:
                seg2 = Segment(seg2.p2, seg2.p1)
            if seg1._span_test(seg2.p1) < 0:
                seg1, seg2 = (seg2, seg1)
            if seg2._span_test(seg1.p2) < 0:
                return []
            return [Segment(seg2.p1, seg1.p2)]
        if not isinstance(other, GeometryEntity):
            other = Point(other, dim=self.ambient_dimension)
        if other.is_Point:
            if self.contains(other):
                return [other]
            else:
                return []
        elif isinstance(other, LinearEntity):
            pts = Point._normalize_dimension(self.p1, self.p2, other.p1, other.p2)
            rank = Point.affine_rank(*pts)
            if rank == 1:
                if isinstance(self, Line):
                    return [other]
                if isinstance(other, Line):
                    return [self]
                if isinstance(self, Ray) and isinstance(other, Ray):
                    return intersect_parallel_rays(self, other)
                if isinstance(self, Ray) and isinstance(other, Segment):
                    return intersect_parallel_ray_and_segment(self, other)
                if isinstance(self, Segment) and isinstance(other, Ray):
                    return intersect_parallel_ray_and_segment(other, self)
                if isinstance(self, Segment) and isinstance(other, Segment):
                    return intersect_parallel_segments(self, other)
            elif rank == 2:
                l1 = Line(*pts[:2])
                l2 = Line(*pts[2:])
                if l1.direction.is_scalar_multiple(l2.direction):
                    return []
                m = Matrix([l1.direction, -l2.direction]).transpose()
                v = Matrix([l2.p1 - l1.p1]).transpose()
                m_rref, pivots = m.col_insert(2, v).rref(simplify=True)
                if len(pivots) != 2:
                    raise GeometryError('Failed when solving Mx=b when M={} and b={}'.format(m, v))
                coeff = m_rref[0, 2]
                line_intersection = l1.direction * coeff + self.p1
                if isinstance(self, Line) and isinstance(other, Line):
                    return [line_intersection]
                if (isinstance(self, Line) or self.contains(line_intersection)) and other.contains(line_intersection):
                    return [line_intersection]
                if not self.atoms(Float) and (not other.atoms(Float)):
                    return []
                tu = solve(self.arbitrary_point(t) - other.arbitrary_point(u), t, u, dict=True)[0]

                def ok(p, l):
                    if isinstance(l, Line):
                        return True
                    if isinstance(l, Ray):
                        return p.is_nonnegative
                    if isinstance(l, Segment):
                        return p.is_nonnegative and (1 - p).is_nonnegative
                    raise ValueError('unexpected line type')
                if ok(tu[t], self) and ok(tu[u], other):
                    return [line_intersection]
                return []
            else:
                return []
        return other.intersection(self)

    def is_parallel(l1, l2):
        if not isinstance(l1, LinearEntity) or not isinstance(l2, LinearEntity):
            raise TypeError('Must pass only LinearEntity objects')
        return l1.direction.is_scalar_multiple(l2.direction)

    def is_perpendicular(l1, l2):
        if not isinstance(l1, LinearEntity) or not isinstance(l2, LinearEntity):
            raise TypeError('Must pass only LinearEntity objects')
        return S.Zero.equals(l1.direction.dot(l2.direction))

    def is_similar(self, other):
        l = Line(self.p1, self.p2)
        return l.contains(other)

    @property
    def length(self):
        return S.Infinity

    @property
    def p1(self):
        return self.args[0]

    @property
    def p2(self):
        return self.args[1]

    def parallel_line(self, p):
        p = Point(p, dim=self.ambient_dimension)
        return Line(p, p + self.direction)

    def perpendicular_line(self, p):
        p = Point(p, dim=self.ambient_dimension)
        if p in self:
            p = p + self.direction.orthogonal_direction
        return Line(p, self.projection(p))

    def perpendicular_segment(self, p):
        p = Point(p, dim=self.ambient_dimension)
        if p in self:
            return p
        l = self.perpendicular_line(p)
        p2, = Intersection(Line(self.p1, self.p2), l)
        return Segment(p, p2)

    @property
    def points(self):
        return (self.p1, self.p2)

    def projection(self, other):
        if not isinstance(other, GeometryEntity):
            other = Point(other, dim=self.ambient_dimension)

        def proj_point(p):
            return Point.project(p - self.p1, self.direction) + self.p1
        if isinstance(other, Point):
            return proj_point(other)
        elif isinstance(other, LinearEntity):
            p1, p2 = (proj_point(other.p1), proj_point(other.p2))
            if p1 == p2:
                return p1
            projected = other.__class__(p1, p2)
            projected = Intersection(self, projected)
            if projected.is_empty:
                return projected
            if projected.is_FiniteSet and len(projected) == 1:
                a, = projected
                return a
            if self.direction.dot(projected.direction) < 0:
                p1, p2 = projected.args
                projected = projected.func(p2, p1)
            return projected
        raise GeometryError('Do not know how to project %s onto %s' % (other, self))

    def random_point(self, seed=None):
        if seed is not None:
            rng = random.Random(seed)
        else:
            rng = random
        pt = self.arbitrary_point(t)
        if isinstance(self, Ray):
            v = abs(rng.gauss(0, 1))
        elif isinstance(self, Segment):
            v = rng.random()
        elif isinstance(self, Line):
            v = rng.gauss(0, 1)
        else:
            raise NotImplementedError('unhandled line type')
        return pt.subs(t, Rational(v))

    def bisectors(self, other):
        if not isinstance(other, LinearEntity):
            raise GeometryError('Expecting LinearEntity, not %s' % other)
        l1, l2 = (self, other)
        if l1.p1.ambient_dimension != l2.p1.ambient_dimension:
            if isinstance(l1, Line2D):
                l1, l2 = (l2, l1)
            _, p1 = Point._normalize_dimension(l1.p1, l2.p1, on_morph='ignore')
            _, p2 = Point._normalize_dimension(l1.p2, l2.p2, on_morph='ignore')
            l2 = Line(p1, p2)
        point = intersection(l1, l2)
        if not point:
            raise GeometryError('The lines do not intersect')
        else:
            pt = point[0]
            if isinstance(pt, Line):
                return [self]
        d1 = l1.direction.unit
        d2 = l2.direction.unit
        bis1 = Line(pt, pt + d1 + d2)
        bis2 = Line(pt, pt + d1 - d2)
        return [bis1, bis2]

class Line(LinearEntity):

    def __new__(cls, *args, **kwargs):
        if len(args) == 1 and isinstance(args[0], (Expr, Eq)):
            missing = uniquely_named_symbol('?', args)
            if not kwargs:
                x = 'x'
                y = 'y'
            else:
                x = kwargs.pop('x', missing)
                y = kwargs.pop('y', missing)
            if kwargs:
                raise ValueError('expecting only x and y as keywords')
            equation = args[0]
            if isinstance(equation, Eq):
                equation = equation.lhs - equation.rhs

            def find_or_missing(x):
                try:
                    return find(x, equation)
                except ValueError:
                    return missing
            x = find_or_missing(x)
            y = find_or_missing(y)
            a, b, c = linear_coeffs(equation, x, y)
            if b:
                return Line((0, -c / b), slope=-a / b)
            if a:
                return Line((-c / a, 0), slope=oo)
            raise ValueError('not found in equation: %s' % (set('xy') - {x, y}))
        elif len(args) > 0:
            p1 = args[0]
            if len(args) > 1:
                p2 = args[1]
            else:
                p2 = None
            if isinstance(p1, LinearEntity):
                if p2:
                    raise ValueError('If p1 is a LinearEntity, p2 must be None.')
                dim = len(p1.p1)
            else:
                p1 = Point(p1)
                dim = len(p1)
                if p2 is not None or (isinstance(p2, Point) and p2.ambient_dimension != dim):
                    p2 = Point(p2)
            if dim == 2:
                return Line2D(p1, p2, **kwargs)
            elif dim == 3:
                return Line3D(p1, p2, **kwargs)
            return LinearEntity.__new__(cls, p1, p2, **kwargs)

    def contains(self, other):
        if not isinstance(other, GeometryEntity):
            other = Point(other, dim=self.ambient_dimension)
        if isinstance(other, Point):
            return Point.is_collinear(other, self.p1, self.p2)
        if isinstance(other, LinearEntity):
            return Point.is_collinear(self.p1, self.p2, other.p1, other.p2)
        return False

    def distance(self, other):
        if not isinstance(other, GeometryEntity):
            other = Point(other, dim=self.ambient_dimension)
        if self.contains(other):
            return S.Zero
        return self.perpendicular_segment(other).length

    def equals(self, other):
        if not isinstance(other, Line):
            return False
        return Point.is_collinear(self.p1, other.p1, self.p2, other.p2)

    def plot_interval(self, parameter='t'):
        t = _symbol(parameter, real=True)
        return [t, -5, 5]

class Ray(LinearEntity):

    def __new__(cls, p1, p2=None, **kwargs):
        p1 = Point(p1)
        if p2 is not None:
            p1, p2 = Point._normalize_dimension(p1, Point(p2))
        dim = len(p1)
        if dim == 2:
            return Ray2D(p1, p2, **kwargs)
        elif dim == 3:
            return Ray3D(p1, p2, **kwargs)
        return LinearEntity.__new__(cls, p1, p2, **kwargs)

    def _svg(self, scale_factor=1.0, fill_color='#66cc99'):
        verts = (N(self.p1), N(self.p2))
        coords = ['{},{}'.format(p.x, p.y) for p in verts]
        path = 'M {} L {}'.format(coords[0], ' L '.join(coords[1:]))
        return '<path fill-rule="evenodd" fill="{2}" stroke="#555555" stroke-width="{0}" opacity="0.6" d="{1}" marker-start="url(#markerCircle)" marker-end="url(#markerArrow)"/>'.format(2.0 * scale_factor, path, fill_color)

    def contains(self, other):
        if not isinstance(other, GeometryEntity):
            other = Point(other, dim=self.ambient_dimension)
        if isinstance(other, Point):
            if Point.is_collinear(self.p1, self.p2, other):
                return bool((self.p2 - self.p1).dot(other - self.p1) >= S.Zero)
            return False
        elif isinstance(other, Ray):
            if Point.is_collinear(self.p1, self.p2, other.p1, other.p2):
                return bool((self.p2 - self.p1).dot(other.p2 - other.p1) > S.Zero)
            return False
        elif isinstance(other, Segment):
            return other.p1 in self and other.p2 in self
        return False

    def distance(self, other):
        if not isinstance(other, GeometryEntity):
            other = Point(other, dim=self.ambient_dimension)
        if self.contains(other):
            return S.Zero
        proj = Line(self.p1, self.p2).projection(other)
        if self.contains(proj):
            return abs(other - proj)
        else:
            return abs(other - self.source)

    def equals(self, other):
        if not isinstance(other, Ray):
            return False
        return self.source == other.source and other.p2 in self

    def plot_interval(self, parameter='t'):
        t = _symbol(parameter, real=True)
        return [t, 0, 10]

    @property
    def source(self):
        return self.p1

class Segment(LinearEntity):

    def __new__(cls, p1, p2, **kwargs):
        p1, p2 = Point._normalize_dimension(Point(p1), Point(p2))
        dim = len(p1)
        if dim == 2:
            return Segment2D(p1, p2, **kwargs)
        elif dim == 3:
            return Segment3D(p1, p2, **kwargs)
        return LinearEntity.__new__(cls, p1, p2, **kwargs)

    def contains(self, other):
        if not isinstance(other, GeometryEntity):
            other = Point(other, dim=self.ambient_dimension)
        if isinstance(other, Point):
            if Point.is_collinear(other, self.p1, self.p2):
                if isinstance(self, Segment2D):
                    vert = (1 / self.slope).equals(0)
                    if vert is False:
                        isin = (self.p1.x - other.x) * (self.p2.x - other.x) <= 0
                        if isin in (True, False):
                            return isin
                    if vert is True:
                        isin = (self.p1.y - other.y) * (self.p2.y - other.y) <= 0
                        if isin in (True, False):
                            return isin
                d1, d2 = (other - self.p1, other - self.p2)
                d = self.p2 - self.p1
                try:
                    return bool(simplify(Eq(abs(d1) + abs(d2) - abs(d), 0)))
                except TypeError:
                    raise Undecidable('Cannot determine if {} is in {}'.format(other, self))
        if isinstance(other, Segment):
            return other.p1 in self and other.p2 in self
        return False

    def equals(self, other):
        return isinstance(other, self.func) and list(ordered(self.args)) == list(ordered(other.args))

    def distance(self, other):
        if not isinstance(other, GeometryEntity):
            other = Point(other, dim=self.ambient_dimension)
        if isinstance(other, Point):
            vp1 = other - self.p1
            vp2 = other - self.p2
            dot_prod_sign_1 = self.direction.dot(vp1) >= 0
            dot_prod_sign_2 = self.direction.dot(vp2) <= 0
            if dot_prod_sign_1 and dot_prod_sign_2:
                return Line(self.p1, self.p2).distance(other)
            if dot_prod_sign_1 and (not dot_prod_sign_2):
                return abs(vp2)
            if not dot_prod_sign_1 and dot_prod_sign_2:
                return abs(vp1)
        raise NotImplementedError()

    @property
    def length(self):
        return Point.distance(self.p1, self.p2)

    @property
    def midpoint(self):
        return Point.midpoint(self.p1, self.p2)

    def perpendicular_bisector(self, p=None):
        l = self.perpendicular_line(self.midpoint)
        if p is not None:
            p2 = Point(p, dim=self.ambient_dimension)
            if p2 in l:
                return Segment(p2, self.midpoint)
        return l

    def plot_interval(self, parameter='t'):
        t = _symbol(parameter, real=True)
        return [t, 0, 1]

class LinearEntity2D(LinearEntity):

    @property
    def bounds(self):
        verts = self.points
        xs = [p.x for p in verts]
        ys = [p.y for p in verts]
        return (min(xs), min(ys), max(xs), max(ys))

    def perpendicular_line(self, p):
        p = Point(p, dim=self.ambient_dimension)
        return Line(p, p + self.direction.orthogonal_direction)

    @property
    def slope(self):
        d1, d2 = (self.p1 - self.p2).args
        if d1 == 0:
            return S.Infinity
        return simplify(d2 / d1)

class Line2D(LinearEntity2D, Line):

    def __new__(cls, p1, pt=None, slope=None, **kwargs):
        if isinstance(p1, LinearEntity):
            if pt is not None:
                raise ValueError('When p1 is a LinearEntity, pt should be None')
            p1, pt = Point._normalize_dimension(*p1.args, dim=2)
        else:
            p1 = Point(p1, dim=2)
        if pt is not None and slope is None:
            try:
                p2 = Point(pt, dim=2)
            except (NotImplementedError, TypeError, ValueError):
                raise ValueError(filldedent('\n                    The 2nd argument was not a valid Point.\n                    If it was a slope, enter it with keyword "slope".\n                    '))
        elif slope is not None and pt is None:
            slope = sympify(slope)
            if slope.is_finite is False:
                dx = 0
                dy = 1
            else:
                dx = 1
                dy = slope
            p2 = Point(p1.x + dx, p1.y + dy, evaluate=False)
        else:
            raise ValueError('A 2nd Point or keyword "slope" must be used.')
        return LinearEntity2D.__new__(cls, p1, p2, **kwargs)

    def _svg(self, scale_factor=1.0, fill_color='#66cc99'):
        verts = (N(self.p1), N(self.p2))
        coords = ['{},{}'.format(p.x, p.y) for p in verts]
        path = 'M {} L {}'.format(coords[0], ' L '.join(coords[1:]))
        return '<path fill-rule="evenodd" fill="{2}" stroke="#555555" stroke-width="{0}" opacity="0.6" d="{1}" marker-start="url(#markerReverseArrow)" marker-end="url(#markerArrow)"/>'.format(2.0 * scale_factor, path, fill_color)

    @property
    def coefficients(self):
        p1, p2 = self.points
        if p1.x == p2.x:
            return (S.One, S.Zero, -p1.x)
        elif p1.y == p2.y:
            return (S.Zero, S.One, -p1.y)
        return tuple([simplify(i) for i in (self.p1.y - self.p2.y, self.p2.x - self.p1.x, self.p1.x * self.p2.y - self.p1.y * self.p2.x)])

    def equation(self, x='x', y='y'):
        x = _symbol(x, real=True)
        y = _symbol(y, real=True)
        p1, p2 = self.points
        if p1.x == p2.x:
            return x - p1.x
        elif p1.y == p2.y:
            return y - p1.y
        a, b, c = self.coefficients
        return a * x + b * y + c

class Ray2D(LinearEntity2D, Ray):

    def __new__(cls, p1, pt=None, angle=None, **kwargs):
        p1 = Point(p1, dim=2)
        if pt is not None and angle is None:
            try:
                p2 = Point(pt, dim=2)
            except (NotImplementedError, TypeError, ValueError):
                raise ValueError(filldedent('\n                    The 2nd argument was not a valid Point; if\n                    it was meant to be an angle it should be\n                    given with keyword "angle".'))
            if p1 == p2:
                raise ValueError('A Ray requires two distinct points.')
        elif angle is not None and pt is None:
            angle = sympify(angle)
            c = _pi_coeff(angle)
            p2 = None
            if c is not None:
                if c.is_Rational:
                    if c.q == 2:
                        if c.p == 1:
                            p2 = p1 + Point(0, 1)
                        elif c.p == 3:
                            p2 = p1 + Point(0, -1)
                    elif c.q == 1:
                        if c.p == 0:
                            p2 = p1 + Point(1, 0)
                        elif c.p == 1:
                            p2 = p1 + Point(-1, 0)
                if p2 is None:
                    c *= S.Pi
            else:
                c = angle % (2 * S.Pi)
            if not p2:
                m = 2 * c / S.Pi
                left = And(1 < m, m < 3)
                x = Piecewise((-1, left), (Piecewise((0, Eq(m % 1, 0)), (1, True)), True))
                y = Piecewise((-tan(c), left), (Piecewise((1, Eq(m, 1)), (-1, Eq(m, 3)), (tan(c), True)), True))
                p2 = p1 + Point(x, y)
        else:
            raise ValueError('A 2nd point or keyword "angle" must be used.')
        return LinearEntity2D.__new__(cls, p1, p2, **kwargs)

    @property
    def xdirection(self):
        if self.p1.x < self.p2.x:
            return S.Infinity
        elif self.p1.x == self.p2.x:
            return S.Zero
        else:
            return S.NegativeInfinity

    @property
    def ydirection(self):
        if self.p1.y < self.p2.y:
            return S.Infinity
        elif self.p1.y == self.p2.y:
            return S.Zero
        else:
            return S.NegativeInfinity

    def closing_angle(r1, r2):
        if not all((isinstance(r, Ray2D) for r in (r1, r2))):
            raise TypeError('Both arguments must be Ray2D objects.')
        a1 = atan2(*list(reversed(r1.direction.args)))
        a2 = atan2(*list(reversed(r2.direction.args)))
        if a1 * a2 < 0:
            a1 = 2 * S.Pi + a1 if a1 < 0 else a1
            a2 = 2 * S.Pi + a2 if a2 < 0 else a2
        return a1 - a2

class Segment2D(LinearEntity2D, Segment):

    def __new__(cls, p1, p2, **kwargs):
        p1 = Point(p1, dim=2)
        p2 = Point(p2, dim=2)
        if p1 == p2:
            return p1
        return LinearEntity2D.__new__(cls, p1, p2, **kwargs)

    def _svg(self, scale_factor=1.0, fill_color='#66cc99'):
        verts = (N(self.p1), N(self.p2))
        coords = ['{},{}'.format(p.x, p.y) for p in verts]
        path = 'M {} L {}'.format(coords[0], ' L '.join(coords[1:]))
        return '<path fill-rule="evenodd" fill="{2}" stroke="#555555" stroke-width="{0}" opacity="0.6" d="{1}" />'.format(2.0 * scale_factor, path, fill_color)

class LinearEntity3D(LinearEntity):

    def __new__(cls, p1, p2, **kwargs):
        p1 = Point3D(p1, dim=3)
        p2 = Point3D(p2, dim=3)
        if p1 == p2:
            raise ValueError('%s.__new__ requires two unique Points.' % cls.__name__)
        return GeometryEntity.__new__(cls, p1, p2, **kwargs)
    ambient_dimension = 3

    @property
    def direction_ratio(self):
        p1, p2 = self.points
        return p1.direction_ratio(p2)

    @property
    def direction_cosine(self):
        p1, p2 = self.points
        return p1.direction_cosine(p2)

class Line3D(LinearEntity3D, Line):

    def __new__(cls, p1, pt=None, direction_ratio=(), **kwargs):
        if isinstance(p1, LinearEntity3D):
            if pt is not None:
                raise ValueError('if p1 is a LinearEntity, pt must be None.')
            p1, pt = p1.args
        else:
            p1 = Point(p1, dim=3)
        if pt is not None and len(direction_ratio) == 0:
            pt = Point(pt, dim=3)
        elif len(direction_ratio) == 3 and pt is None:
            pt = Point3D(p1.x + direction_ratio[0], p1.y + direction_ratio[1], p1.z + direction_ratio[2])
        else:
            raise ValueError('A 2nd Point or keyword "direction_ratio" must be used.')
        return LinearEntity3D.__new__(cls, p1, pt, **kwargs)

    def equation(self, x='x', y='y', z='z'):
        x, y, z, k = [_symbol(i, real=True) for i in (x, y, z, 'k')]
        p1, p2 = self.points
        d1, d2, d3 = p1.direction_ratio(p2)
        x1, y1, z1 = p1
        eqs = [-d1 * k + x - x1, -d2 * k + y - y1, -d3 * k + z - z1]
        for i, e in enumerate(eqs):
            if e.has(k):
                kk = solve(e, k)[0]
                eqs.pop(i)
                break
        return Tuple(*[i.subs(k, kk).as_numer_denom()[0] for i in eqs])

    def distance(self, other):
        from .plane import Plane
        if isinstance(other, (tuple, list)):
            try:
                other = Point3D(other)
            except ValueError:
                pass
        if isinstance(other, Point3D):
            return super().distance(other)
        if isinstance(other, Line3D):
            if self == other:
                return S.Zero
            if self.is_parallel(other):
                return super().distance(other.p1)
            self_direction = Matrix(self.direction_ratio)
            other_direction = Matrix(other.direction_ratio)
            normal = self_direction.cross(other_direction)
            plane_through_self = Plane(p1=self.p1, normal_vector=normal)
            return other.p1.distance(plane_through_self)
        if isinstance(other, Plane):
            return other.distance(self)
        msg = f'{other} has type {type(other)}, which is unsupported'
        raise NotImplementedError(msg)

class Ray3D(LinearEntity3D, Ray):

    def __new__(cls, p1, pt=None, direction_ratio=(), **kwargs):
        if isinstance(p1, LinearEntity3D):
            if pt is not None:
                raise ValueError('If p1 is a LinearEntity, pt must be None')
            p1, pt = p1.args
        else:
            p1 = Point(p1, dim=3)
        if pt is not None and len(direction_ratio) == 0:
            pt = Point(pt, dim=3)
        elif len(direction_ratio) == 3 and pt is None:
            pt = Point3D(p1.x + direction_ratio[0], p1.y + direction_ratio[1], p1.z + direction_ratio[2])
        else:
            raise ValueError(filldedent('\n                A 2nd Point or keyword "direction_ratio" must be used.\n            '))
        return LinearEntity3D.__new__(cls, p1, pt, **kwargs)

    @property
    def xdirection(self):
        if self.p1.x < self.p2.x:
            return S.Infinity
        elif self.p1.x == self.p2.x:
            return S.Zero
        else:
            return S.NegativeInfinity

    @property
    def ydirection(self):
        if self.p1.y < self.p2.y:
            return S.Infinity
        elif self.p1.y == self.p2.y:
            return S.Zero
        else:
            return S.NegativeInfinity

    @property
    def zdirection(self):
        if self.p1.z < self.p2.z:
            return S.Infinity
        elif self.p1.z == self.p2.z:
            return S.Zero
        else:
            return S.NegativeInfinity

class Segment3D(LinearEntity3D, Segment):

    def __new__(cls, p1, p2, **kwargs):
        p1 = Point(p1, dim=3)
        p2 = Point(p2, dim=3)
        if p1 == p2:
            return p1
        return LinearEntity3D.__new__(cls, p1, p2, **kwargs)