from __future__ import annotations
from sympy.core.basic import Basic
from sympy.core.containers import Tuple
from sympy.core.evalf import EvalfMixin, N
from sympy.core.numbers import oo
from sympy.core.symbol import Dummy
from sympy.core.sympify import sympify
from sympy.functions.elementary.trigonometric import cos, sin, atan
from sympy.matrices import eye
from sympy.multipledispatch import dispatch
from sympy.printing import sstr
from sympy.sets import Set, Union, FiniteSet
from sympy.sets.handlers.intersection import intersection_sets
from sympy.sets.handlers.union import union_sets
from sympy.solvers.solvers import solve
from sympy.utilities.misc import func_name
from sympy.utilities.iterables import is_sequence
ordering_of_classes = ['Point2D', 'Point3D', 'Point', 'Segment2D', 'Ray2D', 'Line2D', 'Segment3D', 'Line3D', 'Ray3D', 'Segment', 'Ray', 'Line', 'Plane', 'Triangle', 'RegularPolygon', 'Polygon', 'Circle', 'Ellipse', 'Curve', 'Parabola']
x, y = [Dummy('entity_dummy') for i in range(2)]
T = Dummy('entity_dummy', real=True)

class GeometryEntity(Basic, EvalfMixin):
    __slots__: tuple[str, ...] = ()

    def __contains__(self, other):
        if type(self) is type(other):
            return self == other
        raise NotImplementedError()

    def __getnewargs__(self):
        return tuple(self.args)

    def __ne__(self, o):
        return not self == o

    def __new__(cls, *args, **kwargs):

        def is_seq_and_not_point(a):
            if hasattr(a, 'is_Point') and a.is_Point:
                return False
            return is_sequence(a)
        args = [Tuple(*a) if is_seq_and_not_point(a) else sympify(a) for a in args]
        return Basic.__new__(cls, *args)

    def __radd__(self, a):
        return a.__add__(self)

    def __rtruediv__(self, a):
        return a.__truediv__(self)

    def __repr__(self):
        return type(self).__name__ + repr(self.args)

    def __rmul__(self, a):
        return a.__mul__(self)

    def __rsub__(self, a):
        return a.__sub__(self)

    def __str__(self):
        return type(self).__name__ + sstr(self.args)

    def _eval_subs(self, old, new):
        from sympy.geometry.point import Point, Point3D
        if is_sequence(old) or is_sequence(new):
            if isinstance(old, (Point, Point3D)) and isinstance(new, (Point, Point3D)):
                return None
            if isinstance(self, Point3D):
                old = Point3D(old)
                new = Point3D(new)
            else:
                old = Point(old)
                new = Point(new)
            return self._subs(old, new)

    def _repr_svg_(self):
        try:
            bounds = self.bounds
        except (NotImplementedError, TypeError):
            return None
        if not all((x.is_number and x.is_finite for x in bounds)):
            return None
        svg_top = '<svg xmlns="http://www.w3.org/2000/svg"\n            xmlns:xlink="http://www.w3.org/1999/xlink"\n            width="{1}" height="{2}" viewBox="{0}"\n            preserveAspectRatio="xMinYMin meet">\n            <defs>\n                <marker id="markerCircle" markerWidth="8" markerHeight="8"\n                    refx="5" refy="5" markerUnits="strokeWidth">\n                    <circle cx="5" cy="5" r="1.5" style="stroke: none; fill:#000000;"/>\n                </marker>\n                <marker id="markerArrow" markerWidth="13" markerHeight="13" refx="2" refy="4"\n                       orient="auto" markerUnits="strokeWidth">\n                    <path d="M2,2 L2,6 L6,4" style="fill: #000000;" />\n                </marker>\n                <marker id="markerReverseArrow" markerWidth="13" markerHeight="13" refx="6" refy="4"\n                       orient="auto" markerUnits="strokeWidth">\n                    <path d="M6,2 L6,6 L2,4" style="fill: #000000;" />\n                </marker>\n            </defs>'
        xmin, ymin, xmax, ymax = map(N, bounds)
        if xmin == xmax and ymin == ymax:
            xmin, ymin, xmax, ymax = (xmin - 0.5, ymin - 0.5, xmax + 0.5, ymax + 0.5)
        else:
            expand = 0.1
            widest_part = max([xmax - xmin, ymax - ymin])
            expand_amount = widest_part * expand
            xmin -= expand_amount
            ymin -= expand_amount
            xmax += expand_amount
            ymax += expand_amount
        dx = xmax - xmin
        dy = ymax - ymin
        width = min([max([100.0, dx]), 300])
        height = min([max([100.0, dy]), 300])
        scale_factor = 1.0 if max(width, height) == 0 else max(dx, dy) / max(width, height)
        try:
            svg = self._svg(scale_factor)
        except (NotImplementedError, TypeError):
            return None
        view_box = '{} {} {} {}'.format(xmin, ymin, dx, dy)
        transform = 'matrix(1,0,0,-1,0,{})'.format(ymax + ymin)
        svg_top = svg_top.format(view_box, width, height)
        return svg_top + '<g transform="{}">{}</g></svg>'.format(transform, svg)

    def _svg(self, scale_factor=1.0, fill_color='#66cc99'):
        raise NotImplementedError()

    def _sympy_(self):
        return self

    @property
    def ambient_dimension(self):
        raise NotImplementedError()

    @property
    def bounds(self):
        raise NotImplementedError()

    def encloses(self, o):
        from sympy.geometry.point import Point
        from sympy.geometry.line import Segment, Ray, Line
        from sympy.geometry.ellipse import Ellipse
        from sympy.geometry.polygon import Polygon, RegularPolygon
        if isinstance(o, Point):
            return self.encloses_point(o)
        elif isinstance(o, Segment):
            return all((self.encloses_point(x) for x in o.points))
        elif isinstance(o, (Ray, Line)):
            return False
        elif isinstance(o, Ellipse):
            return self.encloses_point(o.center) and self.encloses_point(Point(o.center.x + o.hradius, o.center.y)) and (not self.intersection(o))
        elif isinstance(o, Polygon):
            if isinstance(o, RegularPolygon):
                if not self.encloses_point(o.center):
                    return False
            return all((self.encloses_point(v) for v in o.vertices))
        raise NotImplementedError()

    def equals(self, o):
        return self == o

    def intersection(self, o):
        raise NotImplementedError()

    def is_similar(self, other):
        raise NotImplementedError()

    def reflect(self, line):
        from sympy.geometry.point import Point
        g = self
        l = line
        o = Point(0, 0)
        if l.slope.is_zero:
            v = l.args[0].y
            if not v:
                return g.scale(y=-1)
            reps = [(p, p.translate(y=2 * (v - p.y))) for p in g.atoms(Point)]
        elif l.slope is oo:
            v = l.args[0].x
            if not v:
                return g.scale(x=-1)
            reps = [(p, p.translate(x=2 * (v - p.x))) for p in g.atoms(Point)]
        else:
            if not hasattr(g, 'reflect') and (not all((isinstance(arg, Point) for arg in g.args))):
                raise NotImplementedError('reflect undefined or non-Point args in %s' % g)
            a = atan(l.slope)
            c = l.coefficients
            d = -c[-1] / c[1]
            xf = Point(x, y)
            xf = xf.translate(y=-d).rotate(-a, o).scale(y=-1).rotate(a, o).translate(y=d)
            reps = [(p, xf.xreplace({x: p.x, y: p.y})) for p in g.atoms(Point)]
        return g.xreplace(dict(reps))

    def rotate(self, angle, pt=None):
        newargs = []
        for a in self.args:
            if isinstance(a, GeometryEntity):
                newargs.append(a.rotate(angle, pt))
            else:
                newargs.append(a)
        return type(self)(*newargs)

    def scale(self, x=1, y=1, pt=None):
        from sympy.geometry.point import Point
        if pt:
            pt = Point(pt, dim=2)
            return self.translate(*(-pt).args).scale(x, y).translate(*pt.args)
        return type(self)(*[a.scale(x, y) for a in self.args])

    def translate(self, x=0, y=0):
        newargs = []
        for a in self.args:
            if isinstance(a, GeometryEntity):
                newargs.append(a.translate(x, y))
            else:
                newargs.append(a)
        return self.func(*newargs)

    def parameter_value(self, other, t):
        from sympy.geometry.point import Point
        if not isinstance(other, GeometryEntity):
            other = Point(other, dim=self.ambient_dimension)
        if not isinstance(other, Point):
            raise ValueError('other must be a point')
        sol = solve(self.arbitrary_point(T) - other, T, dict=True)
        if not sol:
            raise ValueError('Given point is not on %s' % func_name(self))
        return {t: sol[0][T]}

class GeometrySet(GeometryEntity, Set):
    __slots__ = ()

    def _contains(self, other):
        if isinstance(other, Set) and other.is_FiniteSet:
            return all((self.__contains__(i) for i in other))
        return self.__contains__(other)

@dispatch(GeometrySet, Set)
def union_sets(self, o):
    if o.is_FiniteSet:
        other_points = [p for p in o if not self._contains(p)]
        if len(other_points) == len(o):
            return None
        return Union(self, FiniteSet(*other_points))
    if self._contains(o):
        return self
    return None

@dispatch(GeometrySet, Set)
def intersection_sets(self, o):
    from sympy.geometry.point import Point
    try:
        if o.is_FiniteSet:
            inter = FiniteSet(*(p for p in o if self.contains(p)))
        else:
            inter = self.intersection(o)
    except NotImplementedError:
        return None
    points = FiniteSet(*[p for p in inter if isinstance(p, Point)])
    non_points = [p for p in inter if not isinstance(p, Point)]
    return Union(*non_points + [points])

def translate(x, y):
    rv = eye(3)
    rv[2, 0] = x
    rv[2, 1] = y
    return rv

def scale(x, y, pt=None):
    rv = eye(3)
    rv[0, 0] = x
    rv[1, 1] = y
    if pt:
        from sympy.geometry.point import Point
        pt = Point(pt, dim=2)
        tr1 = translate(*(-pt).args)
        tr2 = translate(*pt.args)
        return tr1 * rv * tr2
    return rv

def rotate(th):
    s = sin(th)
    rv = eye(3) * cos(th)
    rv[0, 1] = s
    rv[1, 0] = -s
    rv[2, 2] = 1
    return rv