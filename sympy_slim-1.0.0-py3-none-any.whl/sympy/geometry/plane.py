from __future__ import annotations
from sympy.core import Dummy, Rational, S, Symbol
from sympy.core.symbol import _symbol
from sympy.external.mpmath import prec_to_dps
from sympy.functions.elementary.trigonometric import cos, sin, acos, asin, sqrt
from .entity import GeometryEntity
from .line import Line, Ray, Segment, Line3D, LinearEntity, LinearEntity3D, Ray3D, Segment3D
from .point import Point, Point3D
from sympy.matrices import Matrix
from sympy.polys.polytools import cancel
from sympy.solvers import solve, linsolve
from sympy.utilities.iterables import uniq, is_sequence
from sympy.utilities.misc import filldedent, func_name, Undecidable
import random
x, y, z, t = [Dummy('plane_dummy') for i in range(4)]

class Plane(GeometryEntity):

    def __new__(cls, p1, a=None, b=None, **kwargs):
        p1 = Point3D(p1, dim=3)
        if a and b:
            p2 = Point(a, dim=3)
            p3 = Point(b, dim=3)
            if Point3D.are_collinear(p1, p2, p3):
                raise ValueError('Enter three non-collinear points')
            a = p1.direction_ratio(p2)
            b = p1.direction_ratio(p3)
            normal_vector = tuple(Matrix(a).cross(Matrix(b)))
        else:
            a = kwargs.pop('normal_vector', a)
            evaluate = kwargs.get('evaluate', True)
            if is_sequence(a) and len(a) == 3:
                normal_vector = Point3D(a).args if evaluate else a
            else:
                raise ValueError(filldedent('\n                    Either provide 3 3D points or a point with a\n                    normal vector expressed as a sequence of length 3'))
            if all((coord.is_zero for coord in normal_vector)):
                raise ValueError('Normal vector cannot be zero vector')
        return GeometryEntity.__new__(cls, p1, normal_vector, **kwargs)

    def __contains__(self, o):
        k = self.equation(x, y, z)
        if isinstance(o, (LinearEntity, LinearEntity3D)):
            d = Point3D(o.arbitrary_point(t))
            e = k.subs([(x, d.x), (y, d.y), (z, d.z)])
            return e.equals(0)
        try:
            o = Point(o, dim=3, strict=True)
            d = k.xreplace(dict(zip((x, y, z), o.args)))
            return d.equals(0)
        except TypeError:
            return False

    def _eval_evalf(self, prec=15, **options):
        pt, tup = self.args
        dps = prec_to_dps(prec)
        pt = pt.evalf(n=dps, **options)
        tup = tuple([i.evalf(n=dps, **options) for i in tup])
        return self.func(pt, normal_vector=tup, evaluate=False)

    def angle_between(self, o):
        if isinstance(o, LinearEntity3D):
            a = Matrix(self.normal_vector)
            b = Matrix(o.direction_ratio)
            c = a.dot(b)
            d = sqrt(sum((i ** 2 for i in self.normal_vector)))
            e = sqrt(sum((i ** 2 for i in o.direction_ratio)))
            return asin(c / (d * e))
        if isinstance(o, Plane):
            a = Matrix(self.normal_vector)
            b = Matrix(o.normal_vector)
            c = a.dot(b)
            d = sqrt(sum((i ** 2 for i in self.normal_vector)))
            e = sqrt(sum((i ** 2 for i in o.normal_vector)))
            return acos(c / (d * e))

    def arbitrary_point(self, u=None, v=None):
        circle = v is None
        if circle:
            u = _symbol(u or 't', real=True)
        else:
            u = _symbol(u or 'u', real=True)
            v = _symbol(v or 'v', real=True)
        x, y, z = self.normal_vector
        a, b, c = self.p1.args
        if x.is_zero and y.is_zero:
            x1, y1, z1 = (S.One, S.Zero, S.Zero)
        else:
            x1, y1, z1 = (-y, x, S.Zero)
        x2, y2, z2 = tuple(Matrix((x, y, z)).cross(Matrix((x1, y1, z1))))
        if circle:
            x1, y1, z1 = (w / sqrt(x1 ** 2 + y1 ** 2 + z1 ** 2) for w in (x1, y1, z1))
            x2, y2, z2 = (w / sqrt(x2 ** 2 + y2 ** 2 + z2 ** 2) for w in (x2, y2, z2))
            p = Point3D(a + x1 * cos(u) + x2 * sin(u), b + y1 * cos(u) + y2 * sin(u), c + z1 * cos(u) + z2 * sin(u))
        else:
            p = Point3D(a + x1 * u + x2 * v, b + y1 * u + y2 * v, c + z1 * u + z2 * v)
        return p

    @staticmethod
    def are_concurrent(*planes):
        planes = list(uniq(planes))
        for i in planes:
            if not isinstance(i, Plane):
                raise ValueError('All objects should be Planes but got %s' % i.func)
        if len(planes) < 2:
            return False
        planes = list(planes)
        first = planes.pop(0)
        sol = first.intersection(planes[0])
        if sol == []:
            return False
        else:
            line = sol[0]
            for i in planes[1:]:
                l = first.intersection(i)
                if not l or l[0] not in line:
                    return False
            return True

    def distance(self, o):
        if self.intersection(o) != []:
            return S.Zero
        if isinstance(o, (Segment3D, Ray3D)):
            a, b = (o.p1, o.p2)
            pi, = self.intersection(Line3D(a, b))
            if pi in o:
                return self.distance(pi)
            elif a in Segment3D(pi, b):
                return self.distance(a)
            else:
                assert isinstance(o, Segment3D) is True
                return self.distance(b)
        a = o if isinstance(o, Point3D) else o.p1
        n = Point3D(self.normal_vector).unit
        d = (a - self.p1).dot(n)
        return abs(d)

    def equals(self, o):
        if isinstance(o, Plane):
            a = self.equation()
            b = o.equation()
            return cancel(a / b).is_constant()
        else:
            return False

    def equation(self, x=None, y=None, z=None):
        coords = {x, y, z} - {None}
        if coords & self.free_symbols:
            raise ValueError('Provided symbols clash with symbols used to define the plane')
        x, y, z = [i if i else Symbol(j, real=True) for i, j in zip((x, y, z), 'xyz')]
        a = Point3D(x, y, z)
        b = self.p1.direction_ratio(a)
        c = self.normal_vector
        return sum((i * j for i, j in zip(b, c)))

    def intersection(self, o):
        if not isinstance(o, GeometryEntity):
            o = Point(o, dim=3)
        if isinstance(o, Point):
            if o in self:
                return [o]
            else:
                return []
        if isinstance(o, (LinearEntity, LinearEntity3D)):
            p1, p2 = (o.p1, o.p2)
            if isinstance(o, Segment):
                o = Segment3D(p1, p2)
            elif isinstance(o, Ray):
                o = Ray3D(p1, p2)
            elif isinstance(o, Line):
                o = Line3D(p1, p2)
            else:
                raise ValueError('unhandled linear entity: %s' % o.func)
            if o in self:
                return [o]
            else:
                a = Point3D(o.arbitrary_point(t))
                p1, n = (self.p1, Point3D(self.normal_vector))
                c = solve((a - p1).dot(n), t)
                if not c:
                    return []
                else:
                    c = [i for i in c if i.is_real is not False]
                    if len(c) > 1:
                        c = [i for i in c if i.is_real]
                    if len(c) != 1:
                        raise Undecidable('not sure which point is real')
                    p = a.subs(t, c[0])
                    if p not in o:
                        return []
                    return [p]
        if isinstance(o, Plane):
            if self.equals(o):
                return [self]
            if self.is_parallel(o):
                return []
            else:
                x, y, z = map(Dummy, 'xyz')
                a, b = (Matrix([self.normal_vector]), Matrix([o.normal_vector]))
                c = list(a.cross(b))
                d = self.equation(x, y, z)
                e = o.equation(x, y, z)
                result = list(linsolve([d, e], x, y, z))[0]
                for i in (x, y, z):
                    result = result.subs(i, 0)
                return [Line3D(Point3D(result), direction_ratio=c)]

    def is_coplanar(self, o):
        if isinstance(o, Plane):
            return not cancel(self.equation(x, y, z) / o.equation(x, y, z)).has(x, y, z)
        if isinstance(o, Point3D):
            return o in self
        elif isinstance(o, LinearEntity3D):
            return all((i in self for i in self))
        elif isinstance(o, GeometryEntity):
            return all((i == 0 for i in self.normal_vector[:2]))

    def is_parallel(self, l):
        if isinstance(l, LinearEntity3D):
            a = l.direction_ratio
            b = self.normal_vector
            return sum((i * j for i, j in zip(a, b))) == 0
        if isinstance(l, Plane):
            a = Matrix(l.normal_vector)
            b = Matrix(self.normal_vector)
            return bool(a.cross(b).is_zero_matrix)

    def is_perpendicular(self, l):
        if isinstance(l, LinearEntity3D):
            a = Matrix(l.direction_ratio)
            b = Matrix(self.normal_vector)
            if a.cross(b).is_zero_matrix:
                return True
            else:
                return False
        elif isinstance(l, Plane):
            a = Matrix(l.normal_vector)
            b = Matrix(self.normal_vector)
            if a.dot(b) == 0:
                return True
            else:
                return False
        else:
            return False

    @property
    def normal_vector(self):
        return self.args[1]

    @property
    def p1(self):
        return self.args[0]

    def parallel_plane(self, pt):
        a = self.normal_vector
        return Plane(pt, normal_vector=a)

    def perpendicular_line(self, pt):
        a = self.normal_vector
        return Line3D(pt, direction_ratio=a)

    def perpendicular_plane(self, *pts):
        if len(pts) > 2:
            raise ValueError('No more than 2 pts should be provided.')
        pts = list(pts)
        if len(pts) == 0:
            pts.append(self.p1)
        if len(pts) == 1:
            x, y, z = self.normal_vector
            if x == y == 0:
                dir = (0, 1, 0)
            else:
                dir = (0, 0, 1)
            pts.append(pts[0] + Point3D(*dir))
        p1, p2 = [Point(i, dim=3) for i in pts]
        l = Line3D(p1, p2)
        n = Line3D(p1, direction_ratio=self.normal_vector)
        if l in n:
            x, y, z = self.normal_vector
            if x == y == 0:
                p3 = Point3D(0, 1, 0)
            else:
                p3 = Point3D(0, 0, 1)
            if p3 in l:
                p3 *= 2
        else:
            p3 = p1 + Point3D(*self.normal_vector)
        return Plane(p1, p2, p3)

    def projection_line(self, line):
        if not isinstance(line, (LinearEntity, LinearEntity3D)):
            raise NotImplementedError('Enter a linear entity only')
        a, b = (self.projection(line.p1), self.projection(line.p2))
        if a == b:
            return a
        if isinstance(line, (Line, Line3D)):
            return Line3D(a, b)
        if isinstance(line, (Ray, Ray3D)):
            return Ray3D(a, b)
        if isinstance(line, (Segment, Segment3D)):
            return Segment3D(a, b)

    def projection(self, pt):
        rv = Point(pt, dim=3)
        if rv in self:
            return rv
        n = Point3D(self.normal_vector)
        d = (rv - self.p1).dot(n) / n.dot(n)
        return rv - d * n

    def random_point(self, seed=None):
        if seed is not None:
            rng = random.Random(seed)
        else:
            rng = random
        params = {x: 2 * Rational(rng.gauss(0, 1)) - 1, y: 2 * Rational(rng.gauss(0, 1)) - 1}
        return self.arbitrary_point(x, y).subs(params)

    def parameter_value(self, other, u, v=None):
        if not isinstance(other, GeometryEntity):
            other = Point(other, dim=self.ambient_dimension)
        if not isinstance(other, Point):
            raise ValueError('other must be a point')
        if other == self.p1:
            return other
        if isinstance(u, Symbol) and v is None:
            delta = self.arbitrary_point(u) - self.p1
            eq = delta - (other - self.p1).unit
            sol = solve(eq, u, dict=True)
        elif isinstance(u, Symbol) and isinstance(v, Symbol):
            pt = self.arbitrary_point(u, v)
            sol = solve(pt - other, (u, v), dict=True)
        else:
            raise ValueError('expecting 1 or 2 symbols')
        if not sol:
            raise ValueError('Given point is not on %s' % func_name(self))
        return sol[0]

    @property
    def ambient_dimension(self):
        return self.p1.ambient_dimension