from __future__ import annotations
from sympy.core import S
from sympy.core.sorting import ordered
from sympy.core.symbol import _symbol, symbols
from sympy.geometry.entity import GeometryEntity, GeometrySet
from sympy.geometry.point import Point, Point2D
from sympy.geometry.line import Line, Line2D, Ray2D, Segment2D, LinearEntity3D
from sympy.geometry.ellipse import Ellipse
from sympy.functions import sign
from sympy.simplify.simplify import simplify
from sympy.solvers.solvers import solve

class Parabola(GeometrySet):

    def __new__(cls, focus=None, directrix=None, **kwargs):
        if focus:
            focus = Point(focus, dim=2)
        else:
            focus = Point(0, 0)
        directrix = Line(directrix)
        if directrix.contains(focus):
            raise ValueError('The focus must not be a point of directrix')
        return GeometryEntity.__new__(cls, focus, directrix, **kwargs)

    @property
    def ambient_dimension(self):
        return 2

    @property
    def axis_of_symmetry(self):
        return self.directrix.perpendicular_line(self.focus)

    @property
    def directrix(self):
        return self.args[1]

    @property
    def eccentricity(self):
        return S.One

    def equation(self, x='x', y='y'):
        x = _symbol(x, real=True)
        y = _symbol(y, real=True)
        m = self.directrix.slope
        if m is S.Infinity:
            t1 = 4 * self.p_parameter * (x - self.vertex.x)
            t2 = (y - self.vertex.y) ** 2
        elif m == 0:
            t1 = 4 * self.p_parameter * (y - self.vertex.y)
            t2 = (x - self.vertex.x) ** 2
        else:
            a, b = self.focus
            c, d = self.directrix.coefficients[:2]
            t1 = (x - a) ** 2 + (y - b) ** 2
            t2 = self.directrix.equation(x, y) ** 2 / (c ** 2 + d ** 2)
        return t1 - t2

    @property
    def focal_length(self):
        distance = self.directrix.distance(self.focus)
        focal_length = distance / 2
        return focal_length

    @property
    def focus(self):
        return self.args[0]

    def intersection(self, o):
        x, y = symbols('x y', real=True)
        parabola_eq = self.equation()
        if isinstance(o, Parabola):
            if o in self:
                return [o]
            else:
                return list(ordered([Point(i) for i in solve([parabola_eq, o.equation()], [x, y], set=True)[1]]))
        elif isinstance(o, Point2D):
            if simplify(parabola_eq.subs([(x, o._args[0]), (y, o._args[1])])) == 0:
                return [o]
            else:
                return []
        elif isinstance(o, (Segment2D, Ray2D)):
            result = solve([parabola_eq, Line2D(o.points[0], o.points[1]).equation()], [x, y], set=True)[1]
            return list(ordered([Point2D(i) for i in result if i in o]))
        elif isinstance(o, (Line2D, Ellipse)):
            return list(ordered([Point2D(i) for i in solve([parabola_eq, o.equation()], [x, y], set=True)[1]]))
        elif isinstance(o, LinearEntity3D):
            raise TypeError('Entity must be two dimensional, not three dimensional')
        else:
            raise TypeError('Wrong type of argument were put')

    @property
    def p_parameter(self):
        m = self.directrix.slope
        if m is S.Infinity:
            x = self.directrix.coefficients[2]
            p = sign(self.focus.args[0] + x)
        elif m == 0:
            y = self.directrix.coefficients[2]
            p = sign(self.focus.args[1] + y)
        else:
            d = self.directrix.projection(self.focus)
            p = sign(self.focus.x - d.x)
        return p * self.focal_length

    @property
    def vertex(self):
        focus = self.focus
        m = self.directrix.slope
        if m is S.Infinity:
            vertex = Point(focus.args[0] - self.p_parameter, focus.args[1])
        elif m == 0:
            vertex = Point(focus.args[0], focus.args[1] - self.p_parameter)
        else:
            vertex = self.axis_of_symmetry.intersection(self)[0]
        return vertex