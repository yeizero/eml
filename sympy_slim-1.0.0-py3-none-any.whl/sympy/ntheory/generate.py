from __future__ import annotations
from typing import Iterator, Callable, overload, SupportsIndex, Literal
from bisect import bisect, bisect_left
from itertools import count
from array import array as _array
from sympy.core.random import randint
from sympy.external.gmpy import sqrt
from .primetest import isprime
from sympy.utilities.decorator import deprecated
from sympy.utilities.misc import as_int

def _as_int_ceiling(a) -> int:
    from sympy.functions.elementary.integers import ceiling
    return as_int(ceiling(a))

class Sieve:
    _n: int
    _list: _array[int]
    _tlist: _array[int]
    _mlist: _array[int]
    sieve_interval: int

    def __init__(self, sieve_interval: int=1000000) -> None:
        self._n = 6
        self._list = _array('L', [2, 3, 5, 7, 11, 13])
        self._tlist = _array('L', [0, 1, 1, 2, 2, 4])
        self._mlist = _array('i', [0, 1, -1, -1, 0, -1])
        if sieve_interval <= 0:
            raise ValueError('sieve_interval should be a positive integer')
        self.sieve_interval = sieve_interval
        assert all((len(i) == self._n for i in (self._list, self._tlist, self._mlist)))

    def __repr__(self) -> str:
        return '<%s sieve (%i): %i, %i, %i, ... %i, %i\n%s sieve (%i): %i, %i, %i, ... %i, %i\n%s sieve (%i): %i, %i, %i, ... %i, %i>' % ('prime', len(self._list), self._list[0], self._list[1], self._list[2], self._list[-2], self._list[-1], 'totient', len(self._tlist), self._tlist[0], self._tlist[1], self._tlist[2], self._tlist[-2], self._tlist[-1], 'mobius', len(self._mlist), self._mlist[0], self._mlist[1], self._mlist[2], self._mlist[-2], self._mlist[-1])

    def _reset(self, prime: bool | None=None, totient: bool | None=None, mobius: bool | None=None) -> None:
        if all((i is None for i in (prime, totient, mobius))):
            prime = totient = mobius = True
        if prime:
            self._list = self._list[:self._n]
        if totient:
            self._tlist = self._tlist[:self._n]
        if mobius:
            self._mlist = self._mlist[:self._n]

    def extend(self, n: int) -> None:
        n = int(n)
        self._extend(n)

    def _extend(self, n: int) -> _array[int]:
        _list = self._list
        num = _list[-1] + 1
        if n < num:
            return _list
        num2 = num ** 2
        while num2 <= n:
            _list = _list + _array('L', self._primerange(num, num2, _list))
            num, num2 = (num2, num2 ** 2)
        _list = _list + _array('L', self._primerange(num, n + 1, _list))
        self._list = _list
        return _list

    def _primerange(self, a: int, b: int, _list: _array[int]) -> Iterator[int]:
        if b % 2:
            b -= 1
        while a < b:
            block_size = min(self.sieve_interval, (b - a) // 2)
            block = [True] * block_size
            for p in _list[1:bisect(_list, sqrt(a + 2 * block_size + 1))]:
                for t in range(-(a + 1 + p) // 2 % p, block_size, p):
                    block[t] = False
            for idx, p in enumerate(block):
                if p:
                    yield (a + 2 * idx + 1)
            a += 2 * block_size

    def extend_to_no(self, i: int) -> None:
        i = as_int(i)
        self._extend_to_no(i)

    def _extend_to_no(self, i: int) -> _array[int]:
        i = as_int(i)
        _list = self._list
        while len(_list) < i:
            _list = self._extend(int(_list[-1] * 1.5))
        return _list

    def primerange(self, a: int, b: int | None=None) -> Iterator[int]:
        if b is None:
            b = _as_int_ceiling(a)
            a = 2
        else:
            a = max(2, _as_int_ceiling(a))
            b = _as_int_ceiling(b)
        if a >= b:
            return
        _list = self._extend(b)
        ai = bisect_left(_list, a)
        bi = bisect_left(_list, b)
        yield from _list[ai:bi]

    def totientrange(self, a: int, b: int) -> Iterator[int]:
        a = max(1, _as_int_ceiling(a))
        b = _as_int_ceiling(b)
        _tlist = self._tlist
        n = len(_tlist)
        if a >= b:
            return
        elif b > n:
            _tlist = _tlist + _array('L', range(n, b))
            for i in range(1, n):
                ti = _tlist[i]
                if ti == i - 1:
                    startindex = (n + i - 1) // i * i
                    for j in range(startindex, b, i):
                        _tlist[j] -= _tlist[j] // i
            for i in range(n, b):
                ti = _tlist[i]
                if ti == i:
                    for j in range(i, b, i):
                        _tlist[j] -= _tlist[j] // i
            self._tlist = _tlist
        yield from _tlist[a:b]

    def mobiusrange(self, a: int, b: int) -> Iterator[int]:
        a = max(1, _as_int_ceiling(a))
        b = _as_int_ceiling(b)
        _mlist = self._mlist
        n = len(_mlist)
        if a >= b:
            return
        elif b > n:
            _mlist = _mlist + _array('i', [0] * (b - n))
            for i in range(1, n):
                mi = _mlist[i]
                startindex = (n + i - 1) // i * i
                for j in range(startindex, b, i):
                    _mlist[j] -= mi
            for i in range(n, b):
                mi = _mlist[i]
                for j in range(2 * i, b, i):
                    _mlist[j] -= mi
            self._mlist = _mlist
        yield from _mlist[a:b]

    def search(self, n: int) -> tuple[int, int]:
        test = _as_int_ceiling(n)
        n = as_int(n)
        if n < 2:
            raise ValueError(f'n should be >= 2 but got: {n}')
        _list = self._list
        if n > _list[-1]:
            _list = self._extend(n)
        b = bisect(_list, n)
        if _list[b - 1] == test:
            return (b, b)
        else:
            return (b, b + 1)

    def __contains__(self, n: int) -> bool:
        try:
            n = as_int(n)
            assert n >= 2
        except (ValueError, AssertionError):
            return False
        if n % 2 == 0:
            return n == 2
        a, b = self.search(n)
        return a == b

    def __iter__(self) -> Iterator[int]:
        for n in count(1):
            yield self[n]

    @overload
    def __getitem__(self, n: int) -> int:
        pass

    @overload
    def __getitem__(self, n: slice) -> _array[int]:
        pass

    def __getitem__(self, n: int | slice) -> int | _array[int]:
        if isinstance(n, slice):
            _list = self._extend_to_no(n.stop)
            start = n.start if n.start is not None else 0
            if start < 1:
                raise IndexError('Sieve indices start at 1.')
            return _list[start - 1:n.stop - 1:n.step]
        else:
            if n < 1:
                raise IndexError('Sieve indices start at 1.')
            n = as_int(n)
            _list = self._extend_to_no(n)
            return _list[n - 1]
sieve = Sieve()

def prime(nth: SupportsIndex) -> int:
    n = as_int(nth)
    if n < 1:
        raise ValueError('nth must be a positive integer; prime(1) == 2')
    _list = sieve._list
    if n <= len(_list):
        return _list[n - 1]
    from sympy.functions.elementary.exponential import log
    from sympy.functions.special.error_functions import li
    if n < 1000:
        _list = sieve._extend(8 * n)
        return _list[n - 1]
    a = 2
    b = int(n * (log(n).evalf() + log(log(n)).evalf()))
    while a < b:
        mid = a + b >> 1
        if li(mid).evalf() > n:
            b = mid
        else:
            a = mid + 1
    return nextprime(a - 1, n - _primepi(a - 1))

@deprecated('The `sympy.ntheory.generate.primepi` has been moved to `sympy.functions.combinatorial.numbers.primepi`.', deprecated_since_version='1.13', active_deprecations_target='deprecated-ntheory-symbolic-functions')
def primepi(n: SupportsIndex) -> int:
    from sympy.functions.combinatorial.numbers import primepi as func_primepi
    return func_primepi(as_int(n))

def _primepi(n: int) -> int:
    if n < 2:
        return 0
    if n <= sieve._list[-1]:
        return sieve.search(n)[0]
    lim = int(sqrt(n))
    arr1 = [i + 1 >> 1 for i in range(lim + 1)]
    arr2 = [0] + [n // i + 1 >> 1 for i in range(1, lim + 1)]
    skip = [False] * (lim + 1)
    for i in range(3, lim + 1, 2):
        if skip[i]:
            continue
        p = arr1[i - 1]
        for j in range(i, lim + 1, i):
            skip[j] = True
        for j in range(1, min(n // (i * i), lim) + 1, 2):
            if skip[j]:
                continue
            st = i * j
            if st <= lim:
                arr2[j] -= arr2[st] - p
            else:
                arr2[j] -= arr1[n // st] - p
        for j in range(lim, min(lim, i * i - 1), -1):
            arr1[j] -= arr1[j // i] - p
    return arr2[1]

def nextprime(n: SupportsIndex, ith: SupportsIndex=1) -> int:
    return _nextprime(as_int(n), as_int(ith))

def _nextprime(n: int, ith: int=1) -> int:
    i = ith
    if i <= 0:
        raise ValueError('ith should be positive')
    if n < 2:
        n = 2
        i -= 1
    if n <= sieve._list[-2]:
        l, _ = sieve.search(n)
        _list = sieve._list
        if l + i - 1 < len(_list):
            return _list[l + i - 1]
        n = _list[-1]
        i += l - len(_list)
    nn = 6 * (n // 6)
    if nn == n:
        n += 1
        if isprime(n):
            i -= 1
            if not i:
                return n
        n += 4
    elif n - nn == 5:
        n += 2
        if isprime(n):
            i -= 1
            if not i:
                return n
        n += 4
    else:
        n = nn + 5
    while True:
        if isprime(n):
            i -= 1
            if not i:
                return n
        n += 2
        if isprime(n):
            i -= 1
            if not i:
                return n
        n += 4

def prevprime(n: SupportsIndex) -> int:
    n = int(_as_int_ceiling(n))
    if n < 3:
        raise ValueError('no preceding primes')
    if n < 8:
        return {3: 2, 4: 3, 5: 3, 6: 5, 7: 5}[n]
    if n <= sieve._list[-1]:
        l, u = sieve.search(n)
        if l == u:
            return sieve[l - 1]
        else:
            return sieve[l]
    nn = 6 * (n // 6)
    if n - nn <= 1:
        n = nn - 1
        if isprime(n):
            return n
        n -= 4
    else:
        n = nn + 1
    while True:
        if isprime(n):
            return n
        n -= 2
        if isprime(n):
            return n
        n -= 4

def primerange(a: SupportsIndex, b: SupportsIndex | None=None) -> Iterator[int]:
    a = as_int(a)
    if b is None:
        a, b = (2, a)
    else:
        b = as_int(b)
    yield from _primerange(a, b)

def _primerange(a: int, b: int) -> Iterator[int]:
    if a >= b:
        return
    _list = sieve._list
    largest_known_prime = _list[-1]
    if b <= largest_known_prime:
        yield from sieve.primerange(a, b)
        return
    if a <= largest_known_prime:
        yield from _list[bisect_left(_list, a):]
        a = largest_known_prime + 1
    elif a % 2:
        a -= 1
    tail = min(b, largest_known_prime ** 2)
    if a < tail:
        yield from sieve._primerange(a, tail, _list)
        a = tail
    if b <= a:
        return
    while 1:
        a = nextprime(a)
        if a < b:
            yield a
        else:
            return

def randprime(a: SupportsIndex, b: SupportsIndex) -> int | None:
    a = as_int(a)
    b = as_int(b)
    if a >= b:
        return None
    a, b = map(int, (a, b))
    n = randint(a - 1, b)
    p = nextprime(n)
    if p >= b:
        p = prevprime(b)
    if p < a:
        raise ValueError('no primes exist in the specified range')
    return p

def primorial(n: int, nth: bool=True) -> int:
    if nth:
        n = as_int(n)
    else:
        n = int(n)
    if n < 1:
        raise ValueError('primorial argument must be >= 1')
    p = 1
    if nth:
        for i in range(1, n + 1):
            p *= prime(i)
    else:
        for i in primerange(2, n + 1):
            p *= i
    return p

@overload
def cycle_length(f: Callable[[int], int], x0: int, nmax: int | None=None, values: Literal[False]=False) -> Iterator[tuple[int, int | None]]:
    pass

@overload
def cycle_length(f: Callable[[int], int], x0: int, nmax: SupportsIndex | None=None, *, values: Literal[False]=False) -> Iterator[tuple[int, int | None]]:
    pass

@overload
def cycle_length(f: Callable[[int], int], x0: int, nmax: SupportsIndex | None=None, *, values: Literal[True]) -> Iterator[int]:
    pass

def cycle_length(f: Callable[[int], int], x0: int, nmax: SupportsIndex | None=None, values: bool=False) -> Iterator[int] | Iterator[tuple[int, int | None]]:
    nmax = int(nmax or 0)
    power = lam = 1
    tortoise, hare = (x0, f(x0))
    i = 1
    if values:
        yield tortoise
    while tortoise != hare and (not nmax or i < nmax):
        i += 1
        if power == lam:
            tortoise = hare
            power *= 2
            lam = 0
        if values:
            yield hare
        hare = f(hare)
        lam += 1
    if nmax and i == nmax:
        if values:
            return
        else:
            yield (nmax, None)
            return
    if not values:
        mu = 0
        tortoise = hare = x0
        for i in range(lam):
            hare = f(hare)
        while tortoise != hare:
            tortoise = f(tortoise)
            hare = f(hare)
            mu += 1
        yield (lam, mu)

def composite(nth: SupportsIndex) -> int:
    n = as_int(nth)
    if n < 1:
        raise ValueError('nth must be a positive integer; composite(1) == 4')
    composite_arr = [4, 6, 8, 9, 10, 12, 14, 15, 16, 18]
    if n <= 10:
        return composite_arr[n - 1]
    a, b = (4, sieve._list[-1])
    if n <= b - _primepi(b) - 1:
        while a < b - 1:
            mid = a + b >> 1
            if mid - _primepi(mid) - 1 > n:
                b = mid
            else:
                a = mid
        if isprime(a):
            a -= 1
        return a
    from sympy.functions.elementary.exponential import log
    from sympy.functions.special.error_functions import li
    a = 4
    b = int(n * (log(n) + log(log(n))))
    while a < b:
        mid = a + b >> 1
        if mid - li(mid) - 1 > n:
            b = mid
        else:
            a = mid + 1
    n_composites = a - _primepi(a) - 1
    while n_composites > n:
        if not isprime(a):
            n_composites -= 1
        a -= 1
    if isprime(a):
        a -= 1
    return a

def compositepi(n: SupportsIndex) -> int:
    n = int(n)
    if n < 4:
        return 0
    return n - _primepi(n) - 1