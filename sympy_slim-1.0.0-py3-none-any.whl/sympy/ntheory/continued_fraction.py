from __future__ import annotations
import itertools
from sympy.core.exprtools import factor_terms
from sympy.core.numbers import Integer, Rational
from sympy.core.singleton import S
from sympy.core.symbol import Dummy
from sympy.core.sympify import _sympify
from sympy.utilities.misc import as_int

def continued_fraction(a) -> list:
    e = _sympify(a)
    if all((i.is_Rational for i in e.atoms())):
        if e.is_Integer:
            return continued_fraction_periodic(e, 1, 0)
        elif e.is_Rational:
            return continued_fraction_periodic(e.p, e.q, 0)
        elif e.is_Pow and e.exp is S.Half and e.base.is_Integer:
            return continued_fraction_periodic(0, 1, e.base)
        elif e.is_Mul and len(e.args) == 2 and (e.args[0].is_Rational and e.args[1].is_Pow and e.args[1].base.is_Integer and (e.args[1].exp is S.Half)):
            a, b = e.args
            return continued_fraction_periodic(0, a.q, b.base, a.p)
        else:
            p, d = e.expand().as_numer_denom()
            if d.is_Integer:
                if p.is_Rational:
                    return continued_fraction_periodic(p, d)
                if p.is_Add and len(p.args) == 2:
                    a, bc = p.args
                else:
                    a = S.Zero
                    bc = p
                if a.is_Integer:
                    b = S.NaN
                    if bc.is_Mul and len(bc.args) == 2:
                        b, c = bc.args
                    elif bc.is_Pow:
                        b = Integer(1)
                        c = bc
                    if b.is_Integer and (c.is_Pow and c.exp is S.Half and c.base.is_Integer):
                        c = c.base
                        return continued_fraction_periodic(a, d, c, b)
    raise ValueError(f'expecting a rational or quadratic irrational, not {e}')

def continued_fraction_periodic(p, q, d=0, s=1) -> list:
    from sympy.functions import sqrt, floor
    p, q, d, s = list(map(as_int, [p, q, d, s]))
    if d < 0:
        raise ValueError(f'expected non-negative for `d` but got {d}')
    if q == 0:
        raise ValueError('The denominator cannot be 0.')
    if not s:
        d = 0
    sd = sqrt(d)
    if sd.is_Integer:
        return list(continued_fraction_iterator(Rational(p + s * sd, q)))
    if q < 0:
        p, q, s = (-p, -q, -s)
    n = (p + s * sd) / q
    if n < 0:
        w = floor(-n)
        f = -n - w
        one_f = continued_fraction(1 - f)
        one_f[0] -= w + 1
        return one_f
    d *= s ** 2
    sd *= s
    if (d - p ** 2) % q:
        d *= q ** 2
        sd *= q
        p *= q
        q *= q
    terms: list[int] = []
    pq = {}
    while (p, q) not in pq:
        pq[p, q] = len(terms)
        terms.append((p + sd) // q)
        p = terms[-1] * q - p
        q = (d - p ** 2) // q
    i = pq[p, q]
    return terms[:i] + [terms[i:]]

def continued_fraction_reduce(cf):
    from sympy.solvers import solve
    period = []
    x = Dummy('x')

    def untillist(cf):
        for nxt in cf:
            if isinstance(nxt, list):
                period.extend(nxt)
                yield x
                break
            yield nxt
    a = S.Zero
    for a in continued_fraction_convergents(untillist(cf)):
        pass
    if period:
        y = Dummy('y')
        solns = solve(continued_fraction_reduce(period + [y]) - y, y)
        solns.sort()
        pure = solns[-1]
        rv = a.subs(x, pure).radsimp()
    else:
        rv = a
    if rv.is_Add:
        rv = factor_terms(rv)
        if rv.is_Mul and rv.args[0] == -1:
            rv = rv.func(*rv.args)
    return rv

def continued_fraction_iterator(x):
    from sympy.functions import floor
    while True:
        i = floor(x)
        yield i
        x -= i
        if not x:
            break
        x = 1 / x

def continued_fraction_convergents(cf):
    if isinstance(cf, list) and isinstance(cf[-1], list):
        cf = itertools.chain(cf[:-1], itertools.cycle(cf[-1]))
    p_2, q_2 = (S.Zero, S.One)
    p_1, q_1 = (S.One, S.Zero)
    for a in cf:
        p, q = (a * p_1 + p_2, a * q_1 + q_2)
        p_2, q_2 = (p_1, q_1)
        p_1, q_1 = (p, q)
        yield (p / q)