from __future__ import annotations
from typing import Literal, SupportsIndex, cast, overload, TYPE_CHECKING
from sympy.external.gmpy import MPZ, gcd, lcm, invert, sqrt, jacobi, bit_scan1, remove
from sympy.polys import Poly
from sympy.polys.domains import ZZ
from sympy.polys.galoistools import gf_crt1, gf_crt2, linear_congruence, gf_csolve
from .primetest import isprime
from .generate import primerange
from .factor_ import factorint, _perfect_power
from .modular import crt
from sympy.utilities.decorator import deprecated
from sympy.utilities.memoization import recurrence_memo
from sympy.utilities.misc import as_int
from sympy.utilities.iterables import iproduct
from sympy.core.random import _randint
from itertools import product
if TYPE_CHECKING:
    from sympy.core.expr import Expr

def n_order(a, n):
    a, n = (as_int(a), as_int(n))
    if n <= 1:
        raise ValueError('n should be an integer greater than 1')
    a = a % n
    if a == 1:
        return 1
    if gcd(a, n) != 1:
        raise ValueError('The two numbers should be relatively prime')
    a_order = 1
    for p, e in factorint(n).items():
        pe = p ** e
        pe_order = (p - 1) * p ** (e - 1)
        factors = factorint(p - 1)
        if e > 1:
            factors[p] = e - 1
        order = 1
        for px, ex in factors.items():
            x = pow(a, pe_order // px ** ex, pe)
            while x != 1:
                x = pow(x, px, pe)
                order *= px
        a_order = lcm(a_order, order)
    return int(a_order)

def _primitive_root_prime_iter(p):
    if p == 3:
        yield 2
        return
    g_min = 3 if p % 8 in [1, 7] else 2
    if p < 41:
        g = 5 if p == 23 else g_min
    else:
        v = [(p - 1) // i for i in factorint(p - 1).keys()]
        for g in range(g_min, p):
            if all((pow(g, pw, p) != 1 for pw in v)):
                break
    yield g
    for k in range(3, p, 2):
        if gcd(p - 1, k) == 1:
            yield pow(g, k, p)

def _primitive_root_prime_power_iter(p, e):
    if e == 1:
        yield from _primitive_root_prime_iter(p)
    else:
        p2 = p ** 2
        for g in _primitive_root_prime_iter(p):
            t = (g - pow(g, 2 - p, p2)) % p2
            for k in range(0, p2, p):
                if k != t:
                    yield from (g + k + m for m in range(0, p ** e, p2))

def _primitive_root_prime_power2_iter(p, e):
    for g in _primitive_root_prime_power_iter(p, e):
        if g % 2 == 1:
            yield g
        else:
            yield (g + p ** e)

def primitive_root(p, smallest=True):
    p = as_int(p)
    if p <= 1:
        raise ValueError('p should be an integer greater than 1')
    if p <= 4:
        return p - 1
    p_even = p % 2 == 0
    if not p_even:
        q = p
    elif p % 4:
        q = p // 2
    else:
        return None
    if isprime(q):
        e = 1
    else:
        m = _perfect_power(q, 3)
        if not m:
            return None
        q, e = m
        if not isprime(q):
            return None
    if not smallest:
        if p_even:
            return next(_primitive_root_prime_power2_iter(q, e))
        return next(_primitive_root_prime_power_iter(q, e))
    if p_even:
        for i in range(3, p, 2):
            if i % q and is_primitive_root(i, p):
                return i
    g = next(_primitive_root_prime_iter(q))
    if e == 1 or pow(g, q - 1, q ** 2) != 1:
        return g
    for i in range(g + 1, p):
        if i % q and is_primitive_root(i, p):
            return i

def is_primitive_root(a, p):
    a, p = (as_int(a), as_int(p))
    if p <= 1:
        raise ValueError('p should be an integer greater than 1')
    a = a % p
    if gcd(a, p) != 1:
        raise ValueError('The two numbers should be relatively prime')
    if p <= 4:
        return a == p - 1
    if p % 2:
        q = p
    elif p % 4:
        q = p // 2
    else:
        return False
    if isprime(q):
        group_order = q - 1
        factors = factorint(q - 1).keys()
    else:
        m = _perfect_power(q, 3)
        if not m:
            return False
        q, e = m
        if not isprime(q):
            return False
        group_order = q ** (e - 1) * (q - 1)
        factors = set(factorint(q - 1).keys())
        factors.add(q)
    return all((pow(a, group_order // prime, p) != 1 for prime in factors))

def _sqrt_mod_tonelli_shanks(a, p):
    s = bit_scan1(p - 1)
    t = p >> s
    if p % 3 == 2:
        d = 3
    elif p % 5 in [2, 3]:
        d = 5
    else:
        for d in primerange(7, p):
            if jacobi(p, d) == -1:
                break
        else:
            assert False
    A = pow(a, t, p)
    D = pow(d, t, p)
    m = 0
    for i in range(s):
        adm = A * pow(D, m, p) % p
        adm = pow(adm, 2 ** (s - 1 - i), p)
        if adm % p == p - 1:
            m += 2 ** i
    x = pow(a, (t + 1) // 2, p) * pow(D, m // 2, p) % p
    return x

@overload
def sqrt_mod(a: SupportsIndex, p: SupportsIndex, all_roots: Literal[False]=False) -> int | None:
    pass

@overload
def sqrt_mod(a: SupportsIndex, p: SupportsIndex, all_roots: Literal[True]) -> list[int]:
    pass

@overload
def sqrt_mod(a: SupportsIndex, p: SupportsIndex, all_roots: bool) -> int | list[int] | None:
    pass

def sqrt_mod(a: SupportsIndex, p: SupportsIndex, all_roots: bool=False) -> int | list[int] | None:
    if all_roots:
        return sorted(sqrt_mod_iter(a, p))
    p = abs(as_int(p))
    halfp = p // 2
    x = None
    for r in sqrt_mod_iter(a, p):
        if r < halfp:
            return r
        elif r > halfp:
            return p - r
        else:
            x = r
    return x

def sqrt_mod_iter(a, p, domain=int):
    a, p = (as_int(a), abs(as_int(p)))
    v = []
    pv = []
    _product = product
    for px, ex in factorint(p).items():
        if a % px:
            rx = _sqrt_mod_prime_power(a, px, ex)
        else:
            rx = _sqrt_mod1(a, px, ex)
            _product = iproduct
        if not rx:
            return
        v.append(rx)
        pv.append(px ** ex)
    if len(v) == 1:
        yield from map(domain, v[0])
    else:
        mm, e, s = gf_crt1(pv, ZZ)
        for vx in _product(*v):
            yield domain(gf_crt2(vx, pv, mm, e, s, ZZ))

def _sqrt_mod_prime_power(a, p, k):
    pk = p ** k
    a = a % pk
    if p == 2:
        if a % 8 != 1:
            return None
        if k <= 3:
            return list(range(1, pk, 2))
        r = 1
        for nx in range(3, k):
            if (r ** 2 - a >> nx) % 2:
                r += 1 << nx - 1
        h = 1 << k - 1
        return sorted([r, pk - r, (r + h) % pk, -(r + h) % pk])
    if jacobi(a, p) != 1:
        return None
    if p % 4 == 3:
        res = pow(a, (p + 1) // 4, p)
    elif p % 8 == 5:
        res = pow(a, (p + 3) // 8, p)
        if pow(res, 2, p) != a % p:
            res = res * pow(2, (p - 1) // 4, p) % p
    else:
        res = _sqrt_mod_tonelli_shanks(a, p)
    if k > 1:
        px = p
        for _ in range(k.bit_length() - 1):
            px = px ** 2
            frinv = invert(2 * res, px)
            res = (res - (res ** 2 - a) * frinv) % px
        if k & k - 1:
            frinv = invert(2 * res, pk)
            res = (res - (res ** 2 - a) * frinv) % pk
    return sorted([res, pk - res])

def _sqrt_mod1(a, p, n):
    pn = p ** n
    a = a % pn
    if a == 0:
        return range(0, pn, p ** ((n + 1) // 2))
    a, r = remove(a, p)
    if r % 2 == 1:
        return None
    res = _sqrt_mod_prime_power(a, p, n - r)
    if res is None:
        return None
    m = r // 2
    return (x for rx in res for x in range(rx * p ** m, pn, p ** (n - m)))

def is_quad_residue(a, p):
    a, p = (as_int(a), as_int(p))
    if p < 1:
        raise ValueError('p must be > 0')
    a %= p
    if a < 2 or p < 3:
        return True
    t = bit_scan1(p)
    if t:
        a_ = a % (1 << t)
        if a_:
            r = bit_scan1(a_)
            if r % 2 or a_ >> r & 6:
                return False
        p >>= t
        a %= p
        if a < 2 or p < 3:
            return True
    j = jacobi(a, p)
    if j == -1 or isprime(p):
        return j == 1
    for px, ex in factorint(p).items():
        if a % px:
            if jacobi(a, px) != 1:
                return False
        else:
            a_ = a % px ** ex
            if a_ == 0:
                continue
            a_, r = remove(a_, px)
            if r % 2 or jacobi(a_, px) != 1:
                return False
    return True

def is_nthpow_residue(a, n, m):
    a = a % m
    a, n, m = (as_int(a), as_int(n), as_int(m))
    if m <= 0:
        raise ValueError('m must be > 0')
    if n < 0:
        raise ValueError('n must be >= 0')
    if n == 0:
        if m == 1:
            return False
        return a == 1
    if a == 0:
        return True
    if n == 1:
        return True
    if n == 2:
        return is_quad_residue(a, m)
    return all((_is_nthpow_residue_bign_prime_power(a, n, p, e) for p, e in factorint(m).items()))

def _is_nthpow_residue_bign_prime_power(a, n, p, k):
    while a % p == 0:
        a %= pow(p, k)
        if not a:
            return True
        a, mu = remove(a, p)
        if mu % n:
            return False
        k -= mu
    if p != 2:
        f = p ** (k - 1) * (p - 1)
        return pow(a, f // gcd(f, n), pow(p, k)) == 1
    if n & 1:
        return True
    c = min(bit_scan1(n) + 2, k)
    return a % pow(2, c) == 1

def _nthroot_mod1(s, q, p, all_roots):
    g = next(_primitive_root_prime_iter(p))
    r = s
    for qx, ex in factorint(q).items():
        f = (p - 1) // qx ** ex
        while f % qx == 0:
            f //= qx
        z = f * invert(-f, qx)
        x = (1 + z) // qx
        t = discrete_log(p, pow(r, f, p), pow(g, f * qx, p))
        for _ in range(ex):
            r = pow(r, x, p) * pow(g, -z * t % (p - 1), p) % p
            t //= qx
    res = [r]
    h = pow(g, (p - 1) // q, p)
    hx = r
    for _ in range(q - 1):
        hx = hx * h % p
        res.append(hx)
    if all_roots:
        res.sort()
        return res
    return min(res)

def _nthroot_mod_prime_power(a, n, p, k) -> list[int]:
    if not _is_nthpow_residue_bign_prime_power(a, n, p, k):
        return []
    a_mod_p = a % p
    if a_mod_p == 0:
        base_roots = [0]
    elif (p - 1) % n == 0:
        base_roots = _nthroot_mod1(a_mod_p, n, p, all_roots=True)
    else:
        pa = n
        pb = p - 1
        b = 1
        if pa < pb:
            a_mod_p, pa, b, pb = (b, pb, a_mod_p, pa)
        while pb:
            q, pc = divmod(pa, pb)
            c = pow(b, -q, p) * a_mod_p % p
            pa, pb = (pb, pc)
            a_mod_p, b = (b, c)
        if pa == 1:
            base_roots = [a_mod_p]
        elif pa == 2:
            base_roots = sqrt_mod(a_mod_p, p, all_roots=True)
        else:
            base_roots = _nthroot_mod1(a_mod_p, pa, p, all_roots=True)
    if k == 1:
        return base_roots
    a %= p ** k
    tot_roots = set()
    for root in base_roots:
        diff = pow(root, n - 1, p) * n % p
        new_base = p
        if diff != 0:
            m_inv = invert(diff, p)
            for _ in range(k - 1):
                new_base *= p
                tmp = pow(root, n, new_base) - a
                tmp *= m_inv
                root = (root - tmp) % new_base
            tot_roots.add(root)
        else:
            roots_in_base = {root}
            for _ in range(k - 1):
                new_base *= p
                new_roots = set()
                for k_ in roots_in_base:
                    if pow(k_, n, new_base) != a % new_base:
                        continue
                    while k_ not in new_roots:
                        new_roots.add(k_)
                        k_ = (k_ + new_base // p) % new_base
                roots_in_base = new_roots
            tot_roots = tot_roots | roots_in_base
    return sorted(tot_roots)

@overload
def nthroot_mod(a: SupportsIndex, n: SupportsIndex, p: SupportsIndex, all_roots: Literal[False]=False) -> int | None:
    pass

@overload
def nthroot_mod(a: SupportsIndex, n: SupportsIndex, p: SupportsIndex, all_roots: Literal[True]) -> list[int]:
    pass

@overload
def nthroot_mod(a: SupportsIndex, n: SupportsIndex, p: SupportsIndex, all_roots: bool) -> list[int] | int | None:
    pass

def nthroot_mod(a: SupportsIndex, n: SupportsIndex, p: SupportsIndex, all_roots: bool=False) -> int | list[int] | None:
    a = a % p
    ai = as_int(a)
    ni = as_int(n)
    pi = as_int(p)
    if ni < 1:
        raise ValueError('n should be positive')
    if pi < 1:
        raise ValueError('p should be positive')
    if ni == 1:
        return [ai] if all_roots else ai
    if ni == 2:
        return sqrt_mod(ai, pi, all_roots)
    base: list[list[MPZ]] = []
    prime_power: list[MPZ] = []
    for q, e in factorint(p).items():
        tot_roots = _nthroot_mod_prime_power(ai, ni, q, e)
        if not tot_roots:
            return [] if all_roots else None
        prime_power.append(ZZ(q) ** e)
        base.append(sorted(map(ZZ, tot_roots)))
    P, E, S = gf_crt1(prime_power, ZZ)
    ret = sorted(map(int, {gf_crt2(list(c), prime_power, P, E, S, ZZ) for c in product(*base)}))
    if all_roots:
        return ret
    elif ret:
        return ret[0]
    else:
        return None

def quadratic_residues(p) -> list[int]:
    p = as_int(p)
    r = {pow(i, 2, p) for i in range(p // 2 + 1)}
    return sorted(r)

@deprecated('The `sympy.ntheory.residue_ntheory.legendre_symbol` has been moved to `sympy.functions.combinatorial.numbers.legendre_symbol`.', deprecated_since_version='1.13', active_deprecations_target='deprecated-ntheory-symbolic-functions')
def legendre_symbol(a, p):
    from sympy.functions.combinatorial.numbers import legendre_symbol as _legendre_symbol
    return _legendre_symbol(a, p)

@deprecated('The `sympy.ntheory.residue_ntheory.jacobi_symbol` has been moved to `sympy.functions.combinatorial.numbers.jacobi_symbol`.', deprecated_since_version='1.13', active_deprecations_target='deprecated-ntheory-symbolic-functions')
def jacobi_symbol(m, n):
    from sympy.functions.combinatorial.numbers import jacobi_symbol as _jacobi_symbol
    return _jacobi_symbol(m, n)

@deprecated('The `sympy.ntheory.residue_ntheory.mobius` has been moved to `sympy.functions.combinatorial.numbers.mobius`.', deprecated_since_version='1.13', active_deprecations_target='deprecated-ntheory-symbolic-functions')
def mobius(n):
    from sympy.functions.combinatorial.numbers import mobius as _mobius
    return _mobius(n)

def _discrete_log_trial_mul(n, a, b, order=None):
    a %= n
    b %= n
    if order is None:
        order = n
    x = 1
    for i in range(order):
        if x == a:
            return i
        x = x * b % n
    raise ValueError('Log does not exist')

def _discrete_log_shanks_steps(n, a, b, order=None):
    a %= n
    b %= n
    if order is None:
        order = n_order(b, n)
    m = sqrt(order) + 1
    T = {}
    x = 1
    for i in range(m):
        T[x] = i
        x = x * b % n
    z = pow(b, -m, n)
    x = a
    for i in range(m):
        if x in T:
            return i * m + T[x]
        x = x * z % n
    raise ValueError('Log does not exist')

def _discrete_log_pollard_rho(n, a, b, order=None, retries=10, rseed=None):
    a %= n
    b %= n
    if order is None:
        order = n_order(b, n)
    randint = _randint(rseed)
    for i in range(retries):
        aa = randint(1, order - 1)
        ba = randint(1, order - 1)
        xa = pow(b, aa, n) * pow(a, ba, n) % n
        c = xa % 3
        if c == 0:
            xb = a * xa % n
            ab = aa
            bb = (ba + 1) % order
        elif c == 1:
            xb = xa * xa % n
            ab = (aa + aa) % order
            bb = (ba + ba) % order
        else:
            xb = b * xa % n
            ab = (aa + 1) % order
            bb = ba
        for j in range(order):
            c = xa % 3
            if c == 0:
                xa = a * xa % n
                ba = (ba + 1) % order
            elif c == 1:
                xa = xa * xa % n
                aa = (aa + aa) % order
                ba = (ba + ba) % order
            else:
                xa = b * xa % n
                aa = (aa + 1) % order
            c = xb % 3
            if c == 0:
                xb = a * xb % n
                bb = (bb + 1) % order
            elif c == 1:
                xb = xb * xb % n
                ab = (ab + ab) % order
                bb = (bb + bb) % order
            else:
                xb = b * xb % n
                ab = (ab + 1) % order
            c = xb % 3
            if c == 0:
                xb = a * xb % n
                bb = (bb + 1) % order
            elif c == 1:
                xb = xb * xb % n
                ab = (ab + ab) % order
                bb = (bb + bb) % order
            else:
                xb = b * xb % n
                ab = (ab + 1) % order
            if xa == xb:
                r = (ba - bb) % order
                try:
                    e = invert(r, order) * (ab - aa) % order
                    if (pow(b, e, n) - a) % n == 0:
                        return e
                except ZeroDivisionError:
                    pass
                break
    raise ValueError("Pollard's Rho failed to find logarithm")

def _discrete_log_is_smooth(n: int, factorbase: list):
    factors = [0] * len(factorbase)
    for i, p in enumerate(factorbase):
        while n % p == 0:
            factors[i] += 1
            n = n // p
    if n != 1:
        return None
    return factors

def _discrete_log_index_calculus(n, a, b, order, rseed=None):
    randint = _randint(rseed)
    from math import sqrt, exp, log
    a %= n
    b %= n
    B = int(exp(0.5 * sqrt(log(n) * log(log(n))) * (1 + 1 / log(log(n)))))
    max = 5 * B * B
    factorbase = list(primerange(B))
    lf = len(factorbase)
    ordermo = order - 1
    abx = a
    for x in range(order):
        if abx == 1:
            return (order - x) % order
        relationa = _discrete_log_is_smooth(abx, factorbase)
        if relationa:
            relationa = [r % order for r in relationa] + [x]
            break
        abx = abx * b % n
    else:
        raise ValueError('Index Calculus failed')
    relations = [None] * lf
    k = 1
    kk = 0
    while k < 3 * lf and kk < max:
        x = randint(1, ordermo)
        relation = _discrete_log_is_smooth(pow(b, x, n), factorbase)
        if relation is None:
            kk += 1
            continue
        k += 1
        kk = 0
        relation += [x]
        index = lf
        for i in range(lf):
            ri = relation[i] % order
            if ri > 0 and relations[i] is not None:
                for j in range(lf + 1):
                    relation[j] = (relation[j] - ri * relations[i][j]) % order
            else:
                relation[i] = ri
            if relation[i] > 0 and index == lf:
                index = i
        if index == lf or relations[index] is not None:
            continue
        rinv = pow(relation[index], -1, order)
        for j in range(index, lf + 1):
            relation[j] = rinv * relation[j] % order
        relations[index] = relation
        for i in range(lf):
            if relationa[i] > 0 and relations[i] is not None:
                rbi = relationa[i]
                for j in range(lf + 1):
                    relationa[j] = (relationa[j] - rbi * relations[i][j]) % order
            if relationa[i] > 0:
                break
        else:
            x = (order - relationa[lf]) % order
            if pow(b, x, n) == a:
                return x
            raise ValueError('Index Calculus failed')
    raise ValueError('Index Calculus failed')

def _discrete_log_pohlig_hellman(n, a, b, order=None, order_factors=None):
    from .modular import crt
    a %= n
    b %= n
    if order is None:
        order = n_order(b, n)
    if order_factors is None:
        order_factors = factorint(order)
    l = [0] * len(order_factors)
    for i, (pi, ri) in enumerate(order_factors.items()):
        for j in range(ri):
            aj = pow(a * pow(b, -l[i], n), order // pi ** (j + 1), n)
            bj = pow(b, order // pi, n)
            cj = discrete_log(n, aj, bj, pi, True)
            l[i] += cj * pi ** j
    d, _ = crt([pi ** ri for pi, ri in order_factors.items()], l)
    return d

def discrete_log(n, a, b, order=None, prime_order=None):
    from math import sqrt, log
    n, a, b = (as_int(n), as_int(a), as_int(b))
    if n < 1:
        raise ValueError('n should be positive')
    if n == 1:
        return 0
    if order is None:
        factors = {}
        for px, kx in factorint(n).items():
            if kx > 1:
                if px in factors:
                    factors[px] += kx - 1
                else:
                    factors[px] = kx - 1
            for py, ky in factorint(px - 1).items():
                if py in factors:
                    factors[py] += ky
                else:
                    factors[py] = ky
        order = 1
        for px, kx in factors.items():
            order *= px ** kx
        order_factors = {}
        for p, e in factors.items():
            i = 0
            for _ in range(e):
                if pow(b, order // p, n) == 1:
                    order //= p
                    i += 1
                else:
                    break
            if i < e:
                order_factors[p] = e - i
    if prime_order is None:
        prime_order = isprime(order)
    if order < 1000:
        return _discrete_log_trial_mul(n, a, b, order)
    elif prime_order:
        if 4 * sqrt(log(n) * log(log(n))) < log(order) - 10:
            return _discrete_log_index_calculus(n, a, b, order)
        elif order < 1000000000000:
            return _discrete_log_shanks_steps(n, a, b, order)
        return _discrete_log_pollard_rho(n, a, b, order)
    return _discrete_log_pohlig_hellman(n, a, b, order, order_factors)

def quadratic_congruence(a, b, c, n):
    a = as_int(a)
    b = as_int(b)
    c = as_int(c)
    n = as_int(n)
    if n <= 1:
        raise ValueError('n should be an integer greater than 1')
    a %= n
    b %= n
    c %= n
    if a == 0:
        return linear_congruence(b, -c, n)
    if n == 2:
        roots = []
        if c == 0:
            roots.append(0)
        if (b + c) % 2:
            roots.append(1)
        return roots
    if gcd(2 * a, n) == 1:
        inv_a = invert(a, n)
        b *= inv_a
        c *= inv_a
        if b % 2:
            b += n
        b >>= 1
        return sorted(((i - b) % n for i in sqrt_mod_iter(b ** 2 - c, n)))
    res = set()
    for i in sqrt_mod_iter(b ** 2 - 4 * a * c, 4 * a * n):
        q, rem = divmod(i - b, 2 * a)
        if rem == 0:
            res.add(q % n)
    return sorted(res)

def _valid_expr(expr: Expr) -> list[MPZ]:
    if not expr.is_polynomial():
        raise ValueError('The expression should be a polynomial')
    polynomial = Poly(expr)
    if not polynomial.is_univariate:
        raise ValueError('The expression should be univariate')
    if not polynomial.domain == ZZ:
        raise ValueError('The expression should should have integer coefficients')
    return cast('list[MPZ]', polynomial.rep.to_list())

def polynomial_congruence(expr: Expr, m: int) -> list[MPZ]:
    coefficients = _valid_expr(expr)
    coefficients = [num % m for num in coefficients]
    rank = len(coefficients)
    if rank == 3:
        a, b, c = coefficients
        return quadratic_congruence(a, b, c, m)
    if rank == 2:
        a, b = coefficients
        return quadratic_congruence(0, a, b, m)
    if coefficients[0] == 1 and 1 + coefficients[-1] == sum(coefficients):
        return [ZZ(s) for s in nthroot_mod(-coefficients[-1], rank - 1, m, True)]
    return gf_csolve(coefficients, m)

def binomial_mod(n, m, k):
    if k < 1:
        raise ValueError('k is required to be positive')
    if n < 0 or m < 0 or m > n:
        return 0
    factorisation = factorint(k)
    residues = [_binomial_mod_prime_power(n, m, p, e) for p, e in factorisation.items()]
    return crt([p ** pw for p, pw in factorisation.items()], residues, check=False)[0]

def _binomial_mod_prime_power(n, m, p, q):
    modulo = pow(p, q)

    def up_factorial(u):
        r = q // 2
        fac = prod = 1
        if r == 1 and p == 2 or 2 * r + 1 in (p, p * p):
            if q % 2 == 1:
                r += 1
            modulo, div = (pow(p, 2 * r), pow(p, 2 * r - q))
        else:
            modulo, div = (pow(p, 2 * r + 1), pow(p, 2 * r + 1 - q))
        for j in range(1, r + 1):
            for mul in range((j - 1) * p + 1, j * p):
                fac *= mul
                fac %= modulo
            bj_ = bj(u, j, r)
            prod *= pow(fac, bj_, modulo)
            prod %= modulo
        if p == 2:
            sm = u // 2
            for j in range(1, r + 1):
                sm += j // 2 * bj(u, j, r)
            if sm % 2 == 1:
                prod *= -1
        prod %= modulo // div
        return prod % modulo

    def bj(u, j, r):
        prod = u
        for i in range(1, r + 1):
            if i != j:
                prod *= u * u - i * i
        for i in range(1, r + 1):
            if i != j:
                prod //= j * j - i * i
        return prod // j

    def up_plus_v_binom(u, v):
        prod = 1
        div = invert(factorial(v), modulo)
        for j in range(1, q):
            b = div
            for v_ in range(j * p + 1, j * p + v + 1):
                b *= v_
                b %= modulo
            aj = u
            for i in range(1, q):
                if i != j:
                    aj *= u - i
            for i in range(1, q):
                if i != j:
                    aj //= j - i
            aj //= j
            prod *= pow(b, aj, modulo)
            prod %= modulo
        return prod

    @recurrence_memo([1])
    def factorial(v, prev):
        return v * prev[-1] % modulo

    def factorial_p(n):
        u, v = divmod(n, p)
        return factorial(v) * up_factorial(u) * up_plus_v_binom(u, v) % modulo
    prod = 1
    Nj, Mj, Rj = (n, m, n - m)
    e0 = carry = eq_1 = j = 0
    while Nj:
        numerator = factorial_p(Nj % modulo)
        denominator = factorial_p(Mj % modulo) * factorial_p(Rj % modulo) % modulo
        Nj, (Mj, mj), (Rj, rj) = (Nj // p, divmod(Mj, p), divmod(Rj, p))
        carry = (mj + rj + carry) // p
        e0 += carry
        if j >= q - 1:
            eq_1 += carry
        prod *= numerator * invert(denominator, modulo)
        prod %= modulo
        j += 1
    mul = pow(1 if p == 2 and q >= 3 else -1, eq_1, modulo)
    return pow(p, e0, modulo) * mul * prod % modulo