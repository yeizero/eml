from __future__ import annotations
from typing import TYPE_CHECKING
from itertools import count
from typing import SupportsIndex, Iterable
from sympy.core.sympify import sympify
from sympy.external.gmpy import gmpy as _gmpy, gcd, jacobi, is_square as gmpy_is_square, bit_scan1, is_fermat_prp, is_euler_prp, is_selfridge_prp, is_strong_selfridge_prp, is_strong_bpsw_prp
from sympy.external.ntheory import _lucas_sequence
from sympy.utilities.misc import as_int, filldedent
if TYPE_CHECKING:
    from sympy.core.expr import Expr
MERSENNE_PRIME_EXPONENTS = (2, 3, 5, 7, 13, 17, 19, 31, 61, 89, 107, 127, 521, 607, 1279, 2203, 2281, 3217, 4253, 4423, 9689, 9941, 11213, 19937, 21701, 23209, 44497, 86243, 110503, 132049, 216091, 756839, 859433, 1257787, 1398269, 2976221, 3021377, 6972593, 13466917, 20996011, 24036583, 25964951, 30402457, 32582657, 37156667, 42643801, 43112609, 57885161, 74207281, 77232917, 82589933, 136279841)

def is_fermat_pseudoprime(n: SupportsIndex, a: SupportsIndex) -> bool:
    n, a = (as_int(n), as_int(a))
    if a == 1:
        return n == 2 or bool(n % 2)
    return is_fermat_prp(n, a)

def is_euler_pseudoprime(n: SupportsIndex, a: SupportsIndex) -> bool:
    n, a = (as_int(n), as_int(a))
    if a < 1:
        raise ValueError('a should be an integer greater than 0')
    if n < 1:
        raise ValueError('n should be an integer greater than 0')
    if n == 1:
        return False
    if a == 1:
        return n == 2 or bool(n % 2)
    if n % 2 == 0:
        return n == 2
    if gcd(n, a) != 1:
        raise ValueError('The two numbers should be relatively prime')
    return pow(a, (n - 1) // 2, n) in [1, n - 1]

def is_euler_jacobi_pseudoprime(n: SupportsIndex, a: SupportsIndex) -> bool:
    n, a = (as_int(n), as_int(a))
    if a == 1:
        return n == 2 or bool(n % 2)
    return is_euler_prp(n, a)

def is_square(n: SupportsIndex, prep: bool=True) -> bool:
    n = as_int(n)
    if prep:
        if n < 0:
            return False
        if n in (0, 1):
            return True
    return gmpy_is_square(n)

def _test(n: int, base: int, s: int, t: int) -> bool:
    b = pow(base, t, n)
    if b == 1 or b == n - 1:
        return True
    for _ in range(s - 1):
        b = pow(b, 2, n)
        if b == n - 1:
            return True
        if b == 1:
            return False
    return False

def mr(n: SupportsIndex, bases: Iterable[SupportsIndex]) -> bool:
    n = as_int(n)
    if n < 2 or (n > 2 and n % 2 == 0):
        return False
    s = bit_scan1(n - 1)
    t = n >> s
    for base in bases:
        base = as_int(base)
        if base >= n:
            base %= n
        if base >= 2:
            if not _test(n, base, s, t):
                return False
    return True

def _lucas_extrastrong_params(n: int) -> tuple[int, int, int]:
    for P in count(3):
        D = P ** 2 - 4
        j = jacobi(D, n)
        if j == -1:
            return (D, P, 1)
        elif j == 0 and D % n:
            return (0, 0, 0)
    return (0, 0, 0)

def is_lucas_prp(n: SupportsIndex) -> bool:
    n = as_int(n)
    if n < 2:
        return False
    return is_selfridge_prp(n)

def is_strong_lucas_prp(n: SupportsIndex) -> bool:
    n = as_int(n)
    if n < 2:
        return False
    return is_strong_selfridge_prp(n)

def is_extra_strong_lucas_prp(n: SupportsIndex) -> bool:
    n = as_int(n)
    if n == 2:
        return True
    if n < 2 or n % 2 == 0:
        return False
    if gmpy_is_square(n):
        return False
    D, P, Q = _lucas_extrastrong_params(n)
    if D == 0:
        return False
    s = bit_scan1(n + 1)
    k = n + 1 >> s
    U, V, _ = _lucas_sequence(n, P, Q, k)
    if U == 0 and (V == 2 or V == n - 2):
        return True
    for _ in range(1, s):
        if V == 0:
            return True
        V = (V * V - 2) % n
    return False

def proth_test(n: SupportsIndex) -> bool:
    n = as_int(n)
    if n < 3:
        raise ValueError('n is not Proth number')
    m = bit_scan1(n - 1)
    k = n >> m
    if m < k.bit_length():
        raise ValueError('n is not Proth number')
    if n % 3 == 0:
        return n == 3
    if k % 3:
        return pow(3, n >> 1, n) == n - 1
    if gmpy_is_square(n):
        return False
    for a in range(5, n):
        j = jacobi(a, n)
        if j == -1:
            return pow(a, n >> 1, n) == n - 1
        if j == 0:
            return False
    return False

def _lucas_lehmer_primality_test(p: int) -> bool:
    v = 4
    m = 2 ** p - 1
    for _ in range(p - 2):
        v = pow(v, 2, m) - 2
    return v == 0

def is_mersenne_prime(n: SupportsIndex) -> bool:
    n = as_int(n)
    if n < 1:
        return False
    if n & n + 1:
        return False
    p = n.bit_length()
    if p in MERSENNE_PRIME_EXPONENTS:
        return True
    if p < 65000000 or not isprime(p):
        return False
    result = _lucas_lehmer_primality_test(p)
    if result:
        raise ValueError(filldedent(f"\n            This Mersenne Prime, 2^{p} - 1, should\n            be added to SymPy's known values."))
    return result
_MR_BASES_32 = [15591, 2018, 166, 7429, 8064, 16045, 10503, 4399, 1949, 1295, 2776, 3620, 560, 3128, 5212, 2657, 2300, 2021, 4652, 1471, 9336, 4018, 2398, 20462, 10277, 8028, 2213, 6219, 620, 3763, 4852, 5012, 3185, 1333, 6227, 5298, 1074, 2391, 5113, 7061, 803, 1269, 3875, 422, 751, 580, 4729, 10239, 746, 2951, 556, 2206, 3778, 481, 1522, 3476, 481, 2487, 3266, 5633, 488, 3373, 6441, 3344, 17, 15105, 1490, 4154, 2036, 1882, 1813, 467, 3307, 14042, 6371, 658, 1005, 903, 737, 1887, 7447, 1888, 2848, 1784, 7559, 3400, 951, 13969, 4304, 177, 41, 19875, 3110, 13221, 8726, 571, 7043, 6943, 1199, 352, 6435, 165, 1169, 3315, 978, 233, 3003, 2562, 2994, 10587, 10030, 2377, 1902, 5354, 4447, 1555, 263, 27027, 2283, 305, 669, 1912, 601, 6186, 429, 1930, 14873, 1784, 1661, 524, 3577, 236, 2360, 6146, 2850, 55637, 1753, 4178, 8466, 222, 2579, 2743, 2031, 2226, 2276, 374, 2132, 813, 23788, 1610, 4422, 5159, 1725, 3597, 3366, 14336, 579, 165, 1375, 10018, 12616, 9816, 1371, 536, 1867, 10864, 857, 2206, 5788, 434, 8085, 17618, 727, 3639, 1595, 4944, 2129, 2029, 8195, 8344, 6232, 9183, 8126, 1870, 3296, 7455, 8947, 25017, 541, 19115, 368, 566, 5674, 411, 522, 1027, 8215, 2050, 6544, 10049, 614, 774, 2333, 3007, 35201, 4706, 1152, 1785, 1028, 1540, 3743, 493, 4474, 2521, 26845, 8354, 864, 18915, 5465, 2447, 42, 4511, 1660, 166, 1249, 6259, 2553, 304, 272, 7286, 73, 6554, 899, 2816, 5197, 13330, 7054, 2818, 3199, 811, 922, 350, 7514, 4452, 3449, 2663, 4708, 418, 1621, 1171, 3471, 88, 11345, 412, 1559, 194]

def isprime(n: SupportsIndex) -> bool:
    n = as_int(n)
    if n in [2, 3, 5]:
        return True
    if n < 2 or n % 2 == 0 or n % 3 == 0 or (n % 5 == 0):
        return False
    if n < 49:
        return True
    if n % 7 == 0 or n % 11 == 0 or n % 13 == 0 or (n % 17 == 0) or (n % 19 == 0) or (n % 23 == 0) or (n % 29 == 0) or (n % 31 == 0) or (n % 37 == 0) or (n % 41 == 0) or (n % 43 == 0) or (n % 47 == 0):
        return False
    if n < 2809:
        return True
    if n < 65077:
        return pow(2, n >> 1, n) in [1, n - 1] and n not in [8321, 31621, 42799, 49141, 49981]
    from sympy.ntheory.generate import sieve as s
    if n <= s._list[-1]:
        l, u = s.search(n)
        return l == u
    from sympy.ntheory.factor_ import factor_cache
    if (ret := factor_cache.get(n)) is not None:
        return ret == n
    if _gmpy is not None:
        return is_strong_bpsw_prp(n)
    if n < 341531:
        return mr(n, [9345883071009581737])
    if n < 4296595241:
        h = (n >> 16 ^ n) * 73244475
        h = (h >> 16 ^ h) * 73244475
        h = (h >> 16 ^ h) & 255
        return mr(n, [_MR_BASES_32[h]])
    if n < 350269456337:
        return mr(n, [4230279247111683200, 14694767155120705706, 16641139526367750375])
    if n < 55245642489451:
        return mr(n, [2, 141889084524735, 1199124725622454117, 11096072698276303650])
    if n < 7999252175582851:
        return mr(n, [2, 4130806001517, 149795463772692060, 186635894390467037, 3967304179347715805])
    if n < 585226005592931977:
        return mr(n, [2, 123635709730000, 9233062284813009, 43835965440333360, 761179012939631437, 1263739024124850375])
    if n < 18446744073709551616:
        return mr(n, [2, 325, 9375, 28178, 450775, 9780504, 1795265022])
    if n < 318665857834031151167461:
        return mr(n, [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37])
    if n < 3317044064679887385961981:
        return mr(n, [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41])
    return is_strong_bpsw_prp(n)

def is_gaussian_prime(num: Expr | complex) -> bool:
    num = sympify(num)
    _a, _b = num.as_real_imag()
    a = as_int(_a, strict=False)
    b = as_int(_b, strict=False)
    if a == 0:
        b = abs(b)
        return isprime(b) and b % 4 == 3
    elif b == 0:
        a = abs(a)
        return isprime(a) and a % 4 == 3
    return isprime(a ** 2 + b ** 2)