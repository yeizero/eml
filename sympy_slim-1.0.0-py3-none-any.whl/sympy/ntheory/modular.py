from __future__ import annotations
from math import prod
from sympy.external.gmpy import gcd, gcdext
from sympy.ntheory.primetest import isprime
from sympy.polys.domains import ZZ
from sympy.polys.galoistools import gf_crt, gf_crt1, gf_crt2
from sympy.utilities.misc import as_int

def symmetric_residue(a, m):
    if a <= m // 2:
        return a
    return a - m

def crt(m, v, symmetric=False, check=True):
    if check:
        m = list(map(as_int, m))
        v = list(map(as_int, v))
    result = gf_crt(v, m, ZZ)
    mm = prod(m)
    if check:
        if not all((v % m == result % m for v, m in zip(v, m))):
            result = solve_congruence(*list(zip(v, m)), check=False, symmetric=symmetric)
            if result is None:
                return result
            result, mm = result
    if symmetric:
        return (int(symmetric_residue(result, mm)), int(mm))
    return (int(result), int(mm))

def crt1(m):
    return gf_crt1(m, ZZ)

def crt2(m, v, mm, e, s, symmetric=False):
    result = gf_crt2(v, m, mm, e, s, ZZ)
    if symmetric:
        return (int(symmetric_residue(result, mm)), int(mm))
    return (int(result), int(mm))

def solve_congruence(*remainder_modulus_pairs, **hint):

    def combine(c1, c2):
        a1, m1 = c1
        a2, m2 = c2
        a, b, c = (m1, a2 - a1, m2)
        g = gcd(a, b, c)
        a, b, c = [i // g for i in [a, b, c]]
        if a != 1:
            g, inv_a, _ = gcdext(a, c)
            if g != 1:
                return None
            b *= inv_a
        a, m = (a1 + m1 * b, m1 * c)
        return (a, m)
    rm = remainder_modulus_pairs
    symmetric = hint.get('symmetric', False)
    if hint.get('check', True):
        rm = [(as_int(r), as_int(m)) for r, m in rm]
        uniq = {}
        for r, m in rm:
            r %= m
            if m in uniq:
                if r != uniq[m]:
                    return None
                continue
            uniq[m] = r
        rm = [(r, m) for m, r in uniq.items()]
        del uniq
        if all((isprime(m) for r, m in rm)):
            r, m = list(zip(*rm))
            return crt(m, r, symmetric=symmetric, check=False)
    rv = (0, 1)
    for rmi in rm:
        rv = combine(rv, rmi)
        if rv is None:
            break
        n, m = rv
        n = n % m
    else:
        if symmetric:
            return (symmetric_residue(n, m), m)
        return (n, m)