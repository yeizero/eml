from __future__ import annotations
from sympy.core.containers import Tuple
from sympy.core.numbers import Integer, Rational
from sympy.core.singleton import S
import sympy.polys
from math import gcd

def egyptian_fraction(r: Rational | tuple[int, int], algorithm: str='Greedy') -> list[Integer]:
    if isinstance(r, Rational):
        rat = r
    elif isinstance(r, (Tuple, tuple)) and len(r) == 2:
        rat = Rational(*r)
    else:
        raise ValueError('Value must be a Rational or tuple of ints')
    if rat <= 0:
        raise ValueError('Value must be positive')
    x, y = rat.as_numer_denom()
    if y == 1 and x == 2:
        return [Integer(i) for i in [1, 2, 3, 6]]
    if x == y + 1:
        return [S.One, y]
    prefix, rem = egypt_harmonic(rat)
    if rem == 0:
        return prefix
    x, y = (rem.p, rem.q)
    if algorithm == 'Greedy':
        postfix = egypt_greedy(x, y)
    elif algorithm == 'Graham Jewett':
        postfix = egypt_graham_jewett(x, y)
    elif algorithm == 'Takenouchi':
        postfix = egypt_takenouchi(x, y)
    elif algorithm == 'Golomb':
        postfix = egypt_golomb(x, y)
    else:
        raise ValueError('Entered invalid algorithm')
    return prefix + [Integer(i) for i in postfix]

def egypt_greedy(x: int, y: int) -> list[int]:
    if x == 1:
        return [y]
    else:
        a = -y % x
        b = y * (y // x + 1)
        c = gcd(a, b)
        if c > 1:
            num, denom = (a // c, b // c)
        else:
            num, denom = (a, b)
        return [y // x + 1] + egypt_greedy(num, denom)

def egypt_graham_jewett(x: int, y: int) -> list[int]:
    l = [y] * x
    while len(l) != len(set(l)):
        l.sort()
        for i in range(len(l) - 1):
            if l[i] == l[i + 1]:
                break
        l[i + 1] = l[i] + 1
        l.append(l[i] * (l[i] + 1))
    return sorted(l)

def egypt_takenouchi(x: int, y: int) -> list[int]:
    if x == 3:
        if y % 2 == 0:
            return [y // 2, y]
        i = (y - 1) // 2
        j = i + 1
        k = j + i
        return [j, k, j * k]
    l = [y] * x
    while len(l) != len(set(l)):
        l.sort()
        for i in range(len(l) - 1):
            if l[i] == l[i + 1]:
                break
        k = l[i]
        if k % 2 == 0:
            l[i] = l[i] // 2
            del l[i + 1]
        else:
            l[i], l[i + 1] = ((k + 1) // 2, k * (k + 1) // 2)
    return sorted(l)

def egypt_golomb(x: int, y: int) -> list[int]:
    if x == 1:
        return [y]
    xp = sympy.polys.ZZ.invert(int(x), int(y))
    rv = [xp * y]
    rv.extend(egypt_golomb((x * xp - 1) // y, xp))
    return sorted(rv)

def egypt_harmonic(r: Rational) -> tuple[list[Integer], Rational]:
    rv: list[Integer] = []
    d = S.One
    acc = S.Zero
    while acc + 1 / d <= r:
        acc += 1 / d
        rv.append(d)
        d += 1
    return (rv, r - acc)