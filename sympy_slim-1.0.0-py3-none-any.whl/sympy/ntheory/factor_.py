from __future__ import annotations
from typing import Any, Iterator, Literal, overload, SupportsIndex
from bisect import bisect_left
from collections import defaultdict, OrderedDict
from collections.abc import MutableMapping
import math
from sympy.core.containers import Dict
from sympy.core.mul import Mul
from sympy.core.numbers import Rational, Integer
from sympy.core.intfunc import num_digits
from sympy.core.power import Pow
from sympy.core.random import _randint
from sympy.core.singleton import S
from sympy.external.gmpy import SYMPY_INTS, gcd, sqrt as isqrt, sqrtrem, iroot, bit_scan1, remove
from .primetest import isprime, MERSENNE_PRIME_EXPONENTS, is_mersenne_prime
from .generate import sieve, primerange, nextprime
from .digits import digits
from sympy.utilities.decorator import deprecated
from sympy.utilities.iterables import flatten
from sympy.utilities.misc import as_int, filldedent
from .ecm import _ecm_one_factor

def smoothness(n: SupportsIndex) -> tuple[int, int]:
    if n == 1:
        return (1, 1)
    facs = factorint(n)
    return (max(facs), max((m ** facs[m] for m in facs)))

def smoothness_p(n, m=-1, power=0, visual=None):
    if visual in (1, 0):
        visual = bool(visual)
    elif visual not in (True, False):
        visual = None
    if isinstance(n, str):
        if visual:
            return n
        d = {}
        for li in n.splitlines():
            k, v = [int(i) for i in li.split('has')[0].split('=')[1].split('**')]
            d[k] = v
        if visual is not True and visual is not False:
            return d
        return smoothness_p(d, visual=False)
    elif not isinstance(n, tuple):
        facs = factorint(n, visual=False)
    if power:
        k = -1
    else:
        k = 1
    if isinstance(n, tuple):
        rv = n
    else:
        rv = (m, sorted([(f, tuple([M] + list(smoothness(f + m)))) for f, M in list(facs.items())], key=lambda x: (x[1][k], x[0])))
    if visual is False or (visual is not True and type(n) in [int, Mul]):
        return rv
    lines = []
    for dat in rv[1]:
        dat = flatten(dat)
        dat.insert(2, m)
        lines.append('p**i=%i**%i has p%+i B=%i, B-pow=%i' % tuple(dat))
    return '\n'.join(lines)

def multiplicity(p, n):
    try:
        p, n = (as_int(p), as_int(n))
    except ValueError:
        from sympy.functions.combinatorial.factorials import factorial
        if all((isinstance(i, (SYMPY_INTS, Rational)) for i in (p, n))):
            p = Rational(p)
            n = Rational(n)
            if p.q == 1:
                if n.p == 1:
                    return -multiplicity(p.p, n.q)
                return multiplicity(p.p, n.p) - multiplicity(p.p, n.q)
            elif p.p == 1:
                return multiplicity(p.q, n.q)
            else:
                like = min(multiplicity(p.p, n.p), multiplicity(p.q, n.q))
                cross = min(multiplicity(p.q, n.p), multiplicity(p.p, n.q))
                return like - cross
        elif isinstance(p, (SYMPY_INTS, Integer)) and isinstance(n, factorial) and isinstance(n.args[0], Integer) and (n.args[0] >= 0):
            return multiplicity_in_factorial(p, n.args[0])
        raise ValueError(f'expecting ints or fractions, got {p} and {n}')
    if n == 0:
        raise ValueError(f'no such integer exists: multiplicity of {n} is not-defined')
    return remove(n, p)[1]

def multiplicity_in_factorial(p, n):
    p, n = (as_int(p), as_int(n))
    if p <= 0:
        raise ValueError(f'expecting positive integer got {p}')
    if n < 0:
        raise ValueError(f'expecting non-negative integer got {n}')
    f = defaultdict(int)
    for k, v in factorint(p).items():
        f[v] = max(k, f[v])
    return min(((n + k - sum(digits(n, k))) // (k - 1) // v for v, k in f.items()))

def _perfect_power(n, next_p=2):
    if n <= 3:
        return False
    factors = {}
    g = 0
    multi = 1

    def done(n, factors, g, multi):
        g = gcd(g, multi)
        if g == 1:
            return False
        factors[n] = multi
        return (int(math.prod((p ** (e // g) for p, e in factors.items()))), int(g))
    if n <= 1000000:
        n = _factorint_small(factors, n, 1000, 1000, next_p)[0]
        if n > 1:
            return False
        g = gcd(*factors.values())
        if g == 1:
            return False
        return (math.prod((p ** (e // g) for p, e in factors.items())), int(g))
    if next_p < 3:
        g = bit_scan1(n)
        if g:
            if g == 1:
                return False
            n >>= g
            factors[2] = g
            if n == 1:
                return (2, g)
            else:
                m, _exact = iroot(n, g)
                if _exact:
                    return (int(2 * m), g)
                elif isprime(g):
                    return False
        next_p = 3
    while n & 7 == 1:
        m, _exact = iroot(n, 2)
        if _exact:
            n = m
            multi <<= 1
        else:
            break
    if n < next_p ** 3:
        return done(n, factors, g, multi)
    tf_max = n.bit_length() // 27 + 24
    if next_p < tf_max:
        for p in primerange(next_p, tf_max):
            m, t = remove(n, p)
            if t:
                n = m
                t *= multi
                _g = int(gcd(g, t))
                if _g == 1:
                    return False
                factors[p] = t
                if n == 1:
                    return (int(math.prod((p ** (e // _g) for p, e in factors.items()))), _g)
                elif g == 0 or _g < g:
                    g = _g
                    m, _exact = iroot(n ** multi, g)
                    if _exact:
                        return (int(m * math.prod((p ** (e // g) for p, e in factors.items()))), g)
                    elif isprime(g):
                        return False
        next_p = tf_max
    if n < next_p ** 3:
        return done(n, factors, g, multi)
    if g:
        prime_iter = sorted(factorint(g >> bit_scan1(g)).keys())
    else:
        prime_iter = primerange(3, int(math.log(n, next_p)) + 2)
    logn = math.log2(n)
    threshold = logn / 40
    for p in prime_iter:
        if threshold < p:
            while True:
                b = pow(2, logn / p)
                rb = int(b + 0.5)
                if abs(rb - b) < 0.01 and rb ** p == n:
                    n = rb
                    multi *= p
                    logn = math.log2(n)
                else:
                    break
        else:
            while True:
                m, _exact = iroot(n, p)
                if _exact:
                    n = m
                    multi *= p
                    logn = math.log2(n)
                else:
                    break
        if n < next_p ** (p + 2):
            break
    return done(n, factors, g, multi)

def perfect_power(n, candidates=None, big=True, factor=True):
    if n < 0:
        if candidates is None:
            pp = perfect_power(-n, big=True, factor=factor)
            if not pp:
                return False
            b, e = pp
            e2 = e & -e
            b, e = (b ** e2, e // e2)
            if e <= 1:
                return False
            if big or isprime(e):
                return (-b, e)
            for p in primerange(3, e + 1):
                if e % p == 0:
                    return (-b ** (e // p), p)
        odd_candidates = {i for i in candidates if i % 2}
        if not odd_candidates:
            return False
        pp = perfect_power(-n, odd_candidates, big, factor)
        if pp:
            return (-pp[0], pp[1])
        return False
    if isinstance(n, Rational) and (not isinstance(n, Integer)):
        p, q = (n.p, n.q)
        if p == 1:
            qq = perfect_power(q, candidates, big, factor)
            return (S.One / qq[0], qq[1]) if qq is not False else False
        if not (pp := perfect_power(p, factor=factor)):
            return False
        if not (qq := perfect_power(q, factor=factor)):
            return False
        (num_base, num_exp), (den_base, den_exp) = (pp, qq)

        def compute_tuple(exponent):
            new_num = num_base ** (num_exp // exponent)
            new_den = den_base ** (den_exp // exponent)
            return (n.func(new_num, new_den), exponent)
        if candidates:
            valid_candidates = [i for i in candidates if num_exp % i == 0 and den_exp % i == 0]
            if not valid_candidates:
                return False
            e = max(valid_candidates) if big else min(valid_candidates)
            return compute_tuple(e)
        g = math.gcd(num_exp, den_exp)
        if g == 1:
            return False
        if big:
            return compute_tuple(g)
        e = next((p for p in primerange(2, g + 1) if g % p == 0))
        return compute_tuple(e)
    if candidates is not None:
        candidates = set(candidates)
    n = as_int(n)
    if candidates is None and big:
        return _perfect_power(n)
    if n <= 3:
        return False
    logn = math.log2(n)
    max_possible = int(logn) + 2
    not_square = n % 10 in [2, 3, 7, 8]
    min_possible = 2 + not_square
    if not candidates:
        candidates = primerange(min_possible, max_possible)
    else:
        candidates = sorted([i for i in candidates if min_possible <= i < max_possible])
        if n % 2 == 0:
            e = bit_scan1(n)
            candidates = [i for i in candidates if e % i == 0]
        if big:
            candidates = reversed(candidates)
        for e in candidates:
            r, ok = iroot(n, e)
            if ok:
                return (int(r), e)
        return False

    def _factors():
        rv = 2 + n % 2
        while True:
            yield rv
            rv = nextprime(rv)
    for fac, e in zip(_factors(), candidates):
        if factor and n % fac == 0:
            e = remove(n, fac)[1]
            if e == 1:
                return False
            r, exact = iroot(n, e)
            if not exact:
                m = n // fac ** e
                rE = perfect_power(m, candidates=divisors(e, generator=True))
                if not rE:
                    return False
                else:
                    r, E = rE
                    r, e = (fac ** (e // E) * r, E)
            if not big:
                e0 = primefactors(e)
                if e0[0] != e:
                    r, e = (r ** (e // e0[0]), e0[0])
            return (int(r), e)
        if logn / e < 40:
            b = 2.0 ** (logn / e)
            if abs(int(b + 0.5) - b) > 0.01:
                continue
        r, exact = iroot(n, e)
        if exact:
            if big:
                m = perfect_power(r, big=big, factor=factor)
                if m:
                    r, e = (m[0], e * m[1])
            return (int(r), e)
    return False

class FactorCache(MutableMapping):

    def __init__(self, maxsize: int | None=None):
        self._cache: OrderedDict[int, int] = OrderedDict()
        self.maxsize = maxsize

    def __len__(self) -> int:
        return len(self._cache)

    def __contains__(self, n) -> bool:
        return n in self._cache

    def __getitem__(self, n: int) -> int:
        factor = self.get(n)
        if factor is None:
            raise KeyError(f'{n} does not exist.')
        return factor

    def __setitem__(self, n: int, factor: int):
        if not (1 < factor <= n and n % factor == 0 and isprime(factor)):
            raise ValueError(f'{factor} is not a prime factor of {n}')
        self._cache[n] = max(self._cache.get(n, 0), factor)
        if self.maxsize is not None and len(self._cache) > self.maxsize:
            self._cache.popitem(False)

    def __delitem__(self, n: int):
        if n not in self._cache:
            raise KeyError(f'{n} does not exist.')
        del self._cache[n]

    def __iter__(self):
        return self._cache.__iter__()

    def cache_clear(self) -> None:
        self._cache = OrderedDict()

    @property
    def maxsize(self) -> int | None:
        return self._maxsize

    @maxsize.setter
    def maxsize(self, value: int | None) -> None:
        if value is not None and value <= 0:
            raise ValueError('maxsize must be None or a non-negative integer.')
        self._maxsize = value
        if value is not None:
            while len(self._cache) > value:
                self._cache.popitem(False)

    def get(self, n: int, default=None):
        if n <= sieve._list[-1]:
            if sieve._list[bisect_left(sieve._list, n)] == n:
                return n
        if n in self._cache:
            self._cache.move_to_end(n)
            return self._cache[n]
        if (factors := self.get_external(n)):
            self.add(n, factors)
            return self._cache[n]
        return default

    def add(self, n: int, factors: list[int]) -> None:
        for p in sorted(factors, reverse=True):
            self[n] = p
            nz, _ = remove(n, p)
            n = int(nz)

    def get_external(self, n: int) -> list[int] | None:
        return None
factor_cache = FactorCache(maxsize=1000)

def pollard_rho(n, s=2, a=1, retries=5, seed=1234, max_steps=None, F=None):
    n = int(n)
    if n < 5:
        raise ValueError('pollard_rho should receive n > 4')
    randint = _randint(seed + retries)
    V = s
    for i in range(retries + 1):
        U = V
        if not F:
            F = lambda x: (pow(x, 2, n) + a) % n
        j = 0
        while 1:
            if max_steps and j > max_steps:
                break
            j += 1
            U = F(U)
            V = F(F(V))
            g = gcd(U - V, n)
            if g == 1:
                continue
            if g == n:
                break
            return int(g)
        V = randint(0, n - 1)
        a = randint(1, n - 3)
        F = None
    return None

def pollard_pm1(n, B=10, a=2, retries=0, seed=1234):
    n = int(n)
    if n < 4 or B < 3:
        raise ValueError('pollard_pm1 should receive n > 3 and B > 2')
    randint = _randint(seed + B)
    for i in range(retries + 1):
        aM = a
        for p in sieve.primerange(2, B + 1):
            e = int(math.log(B, p))
            aM = pow(aM, pow(p, e), n)
        g = gcd(aM - 1, n)
        if 1 < g < n:
            return int(g)
        a = randint(2, n - 2)

def _trial(factors, n, candidates, verbose=False):
    if verbose:
        factors0 = list(factors.keys())
    nfactors = len(factors)
    for d in candidates:
        if n % d == 0:
            if n != d:
                factor_cache[n] = d
            n, m = remove(n // d, d)
            factors[d] = m + 1
    if verbose:
        for k in sorted(set(factors).difference(set(factors0))):
            print(factor_msg % (k, factors[k]))
    return (int(n), len(factors) != nfactors)

def _check_termination(factors, n, limit, use_trial, use_rho, use_pm1, verbose, next_p):
    if verbose:
        print('Check for termination')
    if n == 1:
        if verbose:
            print(complete_msg)
        return True
    if n < next_p ** 2 or isprime(n):
        factor_cache[n] = n
        factors[int(n)] = 1
        if verbose:
            print(complete_msg)
        return True
    p = _perfect_power(n, next_p)
    if not p:
        return False
    base, exp = p
    if base < next_p ** 2 or isprime(base):
        factor_cache[n] = base
        factors[base] = exp
    else:
        facs = factorint(base, limit, use_trial, use_rho, use_pm1, verbose=False)
        for b, e in facs.items():
            if verbose:
                print(factor_msg % (b, e))
            factors[b] = exp * e
    if verbose:
        print(complete_msg)
    return True
trial_int_msg = 'Trial division with ints [%i ... %i] and fail_max=%i'
trial_msg = 'Trial division with primes [%i ... %i]'
rho_msg = "Pollard's rho with retries %i, max_steps %i and seed %i"
pm1_msg = "Pollard's p-1 with smoothness bound %i and seed %i"
ecm_msg = 'Elliptic Curve with B1 bound %i, B2 bound %i, num_curves %i'
factor_msg = '\t%i ** %i'
fermat_msg = 'Close factors satisfying Fermat condition found.'
complete_msg = 'Factorization is complete.'

def _factorint_small(factors, n, limit, fail_max, next_p=2):

    def done(n, d):
        if d * d <= n:
            return (n, d)
        return (n, 0)
    limit2 = limit ** 2
    threshold2 = min(n, limit2)
    if next_p < 3:
        if not n & 1:
            m = bit_scan1(n)
            factors[2] = m
            n >>= m
            threshold2 = min(n, limit2)
        next_p = 3
        if threshold2 < 9:
            return done(n, next_p)
    if next_p < 5:
        if not n % 3:
            n //= 3
            m = 1
            while not n % 3:
                n //= 3
                m += 1
                if m == 20:
                    n, mm = remove(n, 3)
                    m += mm
                    break
            factors[3] = m
            threshold2 = min(n, limit2)
        next_p = 5
        if threshold2 < 25:
            return done(n, next_p)
    p6 = next_p % 6
    next_p += (-1 if p6 < 2 else 5) - p6
    fails = 0
    while fails < fail_max:
        if n % next_p:
            fails += 1
        else:
            n //= next_p
            m = 1
            while not n % next_p:
                n //= next_p
                m += 1
                if m == 20:
                    n, mm = remove(n, next_p)
                    m += mm
                    break
            factors[next_p] = m
            fails = 0
            threshold2 = min(n, limit2)
        next_p += 2
        if threshold2 < next_p ** 2:
            return done(n, next_p)
        if n % next_p:
            fails += 1
        else:
            n //= next_p
            m = 1
            while not n % next_p:
                n //= next_p
                m += 1
                if m == 20:
                    n, mm = remove(n, next_p)
                    m += mm
                    break
            factors[next_p] = m
            fails = 0
            threshold2 = min(n, limit2)
        next_p += 4
        if threshold2 < next_p ** 2:
            return done(n, next_p)
    return done(n, next_p)

def factorint(n, limit=None, use_trial=True, use_rho=True, use_pm1=True, use_ecm=True, verbose=False, visual=None, multiple=False):
    if isinstance(n, Dict):
        n = dict(n)
    if multiple:
        fac = factorint(n, limit=limit, use_trial=use_trial, use_rho=use_rho, use_pm1=use_pm1, verbose=verbose, visual=False, multiple=False)
        factorlist = sum(([p] * fac[p] if fac[p] > 0 else [S.One / p] * -fac[p] for p in sorted(fac)), [])
        return factorlist
    factordict = {}
    if visual and (not isinstance(n, (Mul, dict))):
        factordict = factorint(n, limit=limit, use_trial=use_trial, use_rho=use_rho, use_pm1=use_pm1, verbose=verbose, visual=False)
    elif isinstance(n, Mul):
        factordict = {int(k): int(v) for k, v in n.as_powers_dict().items()}
    elif isinstance(n, dict):
        factordict = n
    if factordict and isinstance(n, (Mul, dict)):
        for key in list(factordict.keys()):
            if isprime(key):
                continue
            e = factordict.pop(key)
            d = factorint(key, limit=limit, use_trial=use_trial, use_rho=use_rho, use_pm1=use_pm1, verbose=verbose, visual=False)
            for k, v in d.items():
                if k in factordict:
                    factordict[k] += v * e
                else:
                    factordict[k] = v * e
    if visual or (type(n) is dict and visual is not True and (visual is not False)):
        if factordict == {}:
            return S.One
        if -1 in factordict:
            factordict.pop(-1)
            args = [S.NegativeOne]
        else:
            args = []
        args.extend([Pow(*i, evaluate=False) for i in sorted(factordict.items())])
        return Mul(*args, evaluate=False)
    elif isinstance(n, (dict, Mul)):
        return factordict
    assert use_trial or use_rho or use_pm1 or use_ecm
    from sympy.functions.combinatorial.factorials import factorial
    if isinstance(n, factorial):
        x = as_int(n.args[0])
        if x >= 20:
            factors = {}
            m = 2
            for p in sieve.primerange(2, x + 1):
                if m > 1:
                    m, q = (0, x // p)
                    while q != 0:
                        m += q
                        q //= p
                factors[p] = m
            if factors and verbose:
                for k in sorted(factors):
                    print(factor_msg % (k, factors[k]))
            if verbose:
                print(complete_msg)
            return factors
        else:
            n = n.func(x)
    n = as_int(n)
    if limit:
        limit = int(limit)
        use_ecm = False
    if n < 0:
        factors = factorint(-n, limit=limit, use_trial=use_trial, use_rho=use_rho, use_pm1=use_pm1, verbose=verbose, visual=False)
        factors[-1] = 1
        return factors
    if limit and limit < 2:
        if n == 1:
            return {}
        return {n: 1}
    elif n < 10:
        return [{0: 1}, {}, {2: 1}, {3: 1}, {2: 2}, {5: 1}, {2: 1, 3: 1}, {7: 1}, {2: 3}, {3: 2}][n]
    factors = {}
    if verbose:
        sn = str(n)
        if len(sn) > 50:
            print(f'Factoring {sn[:5]}..({len(sn) - 10} other digits)..{sn[-5:]}')
        else:
            print('Factoring', n)
    small = 2 ** 15
    fail_max = 600
    small = min(small, limit or small)
    if verbose:
        print(trial_int_msg % (2, small, fail_max))
    n, next_p = _factorint_small(factors, n, small, fail_max)
    if factors and verbose:
        for k in sorted(factors):
            print(factor_msg % (k, factors[k]))
    if next_p == 0:
        if n > 1:
            factors[int(n)] = 1
        if verbose:
            print(complete_msg)
        return factors
    while (p := factor_cache.get(n)):
        n, e = remove(n, p)
        factors[int(p)] = int(e)
    if limit and next_p > limit:
        if verbose:
            print('Exceeded limit:', limit)
        if _check_termination(factors, n, limit, use_trial, use_rho, use_pm1, verbose, next_p):
            return factors
        if n > 1:
            factors[int(n)] = 1
        return factors
    if _check_termination(factors, n, limit, use_trial, use_rho, use_pm1, verbose, next_p):
        return factors
    sqrt_n = isqrt(n)
    a = sqrt_n + 1
    if (n % 4 == 1) ^ a & 1:
        a += 1
    a2 = a ** 2
    b2 = a2 - n
    for _ in range(3):
        b, fermat = sqrtrem(b2)
        if not fermat:
            if verbose:
                print(fermat_msg)
            for r in [a - b, a + b]:
                facs = factorint(r, limit=limit, use_trial=use_trial, use_rho=use_rho, use_pm1=use_pm1, verbose=verbose)
                for k, v in facs.items():
                    factors[k] = factors.get(k, 0) + v
            if verbose:
                print(complete_msg)
            return factors
        b2 += a + 1 << 2
        a += 2
    low, high = (next_p, 2 * next_p)
    _limit = (limit or sqrt_n) + 1
    iteration = 0
    while 1:
        high_ = min(high, _limit)
        if use_trial:
            if verbose:
                print(trial_msg % (low, high_))
            ps = sieve.primerange(low, high_)
            n, found_trial = _trial(factors, n, ps, verbose)
            next_p = high_
            if found_trial and _check_termination(factors, n, limit, use_trial, use_rho, use_pm1, verbose, next_p):
                return factors
        else:
            found_trial = False
        if high > _limit:
            if verbose:
                print('Exceeded limit:', _limit)
            if n > 1:
                factors[int(n)] = 1
            if verbose:
                print(complete_msg)
            return factors
        if not found_trial:
            if use_pm1:
                if verbose:
                    print(pm1_msg % (low, high_))
                c = pollard_pm1(n, B=low, seed=high_)
                if c:
                    if c < next_p ** 2 or isprime(c):
                        ps = [c]
                    else:
                        ps = factorint(c, limit=limit, use_trial=use_trial, use_rho=use_rho, use_pm1=use_pm1, use_ecm=use_ecm, verbose=verbose)
                    n, _ = _trial(factors, n, ps, verbose=False)
                    if _check_termination(factors, n, limit, use_trial, use_rho, use_pm1, verbose, next_p):
                        return factors
            if use_rho:
                if verbose:
                    print(rho_msg % (1, low, high_))
                c = pollard_rho(n, retries=1, max_steps=low, seed=high_)
                if c:
                    if c < next_p ** 2 or isprime(c):
                        ps = [c]
                    else:
                        ps = factorint(c, limit=limit, use_trial=use_trial, use_rho=use_rho, use_pm1=use_pm1, use_ecm=use_ecm, verbose=verbose)
                    n, _ = _trial(factors, n, ps, verbose=False)
                    if _check_termination(factors, n, limit, use_trial, use_rho, use_pm1, verbose, next_p):
                        return factors
        iteration += 1
        if use_ecm and iteration >= 3 and (num_digits(n) >= 24):
            break
        low, high = (high, high * 2)
    B1 = 10000
    B2 = 100 * B1
    num_curves = 50
    while 1:
        if verbose:
            print(ecm_msg % (B1, B2, num_curves))
        factor = _ecm_one_factor(n, B1, B2, num_curves, seed=B1)
        if factor:
            if factor < next_p ** 2 or isprime(factor):
                ps = [factor]
            else:
                ps = factorint(factor, limit=limit, use_trial=use_trial, use_rho=use_rho, use_pm1=use_pm1, use_ecm=use_ecm, verbose=verbose)
            n, _ = _trial(factors, n, ps, verbose=False)
            if _check_termination(factors, n, limit, use_trial, use_rho, use_pm1, verbose, next_p):
                return factors
        B1 *= 5
        B2 = 100 * B1
        num_curves *= 4

def factorrat(rat, limit=None, use_trial=True, use_rho=True, use_pm1=True, verbose=False, visual=None, multiple=False):
    if multiple:
        fac = factorrat(rat, limit=limit, use_trial=use_trial, use_rho=use_rho, use_pm1=use_pm1, verbose=verbose, visual=False, multiple=False)
        factorlist = sum(([p] * fac[p] if fac[p] > 0 else [S.One / p] * -fac[p] for p, _ in sorted(fac.items(), key=lambda elem: elem[0] if elem[1] > 0 else 1 / elem[0])), [])
        return factorlist
    f = factorint(rat.p, limit=limit, use_trial=use_trial, use_rho=use_rho, use_pm1=use_pm1, verbose=verbose).copy()
    f = defaultdict(int, f)
    for p, e in factorint(rat.q, limit=limit, use_trial=use_trial, use_rho=use_rho, use_pm1=use_pm1, verbose=verbose).items():
        f[p] += -e
    if len(f) > 1 and 1 in f:
        del f[1]
    if not visual:
        return dict(f)
    else:
        if -1 in f:
            f.pop(-1)
            args = [S.NegativeOne]
        else:
            args = []
        args.extend([Pow(*i, evaluate=False) for i in sorted(f.items())])
        return Mul(*args, evaluate=False)

def primefactors(n: int, limit: int | None=None, verbose: bool=False, **kwargs: Any) -> list[int]:
    n = int(n)
    kwargs.update({'visual': None, 'multiple': False, 'limit': limit, 'verbose': verbose})
    factors = sorted(factorint(n=n, **kwargs).keys())
    s = [f for f in factors[:-1] if f not in [-1, 0, 1]]
    if factors and isprime(factors[-1]):
        s += [factors[-1]]
    return s

def _divisors(n: int, proper: bool=False) -> Iterator[int]:
    if n <= 1:
        if not proper and n:
            yield 1
        return
    factordict = factorint(n)
    ps = sorted(factordict.keys())

    def rec_gen(n=0):
        if n == len(ps):
            yield 1
        else:
            pows = [1]
            for _ in range(factordict[ps[n]]):
                pows.append(pows[-1] * ps[n])
            yield from (p * q for q in rec_gen(n + 1) for p in pows)
    if proper:
        yield from (p for p in rec_gen() if p != n)
    else:
        yield from rec_gen()

@overload
def divisors(n: int, generator: Literal[True], proper: bool=False) -> Iterator[int]:
    pass

@overload
def divisors(n: int, generator: Literal[False]=False, proper: bool=False) -> list[int]:
    pass

@overload
def divisors(n: int, generator: bool=False, proper: bool=False) -> Iterator[int] | list[int]:
    pass

def divisors(n: int, generator: bool=False, proper: bool=False) -> Iterator[int] | list[int]:
    rv = _divisors(as_int(abs(n)), proper)
    return rv if generator else sorted(rv)

def divisor_count(n: int, modulus: int=1, proper: bool=False) -> int:
    if not modulus:
        return 0
    elif modulus != 1:
        n, r = divmod(n, modulus)
        if r:
            return 0
    if n == 0:
        return 0
    n = math.prod([v + 1 for k, v in factorint(n).items() if k > 1], start=1)
    if n and proper:
        n -= 1
    return n

@overload
def proper_divisors(n: int, generator: Literal[True]) -> Iterator[int]:
    pass

@overload
def proper_divisors(n: int, generator: Literal[False]=False) -> list[int]:
    pass

@overload
def proper_divisors(n: int, generator: bool=False) -> Iterator[int] | list[int]:
    pass

def proper_divisors(n: int, generator: bool=False) -> Iterator[int] | list[int]:
    return divisors(n, generator=generator, proper=True)

def proper_divisor_count(n: int, modulus: int=1) -> int:
    return divisor_count(n, modulus=modulus, proper=True)

def _udivisors(n: int) -> Iterator[int]:
    if n <= 1:
        if n == 1:
            yield 1
        return
    factorpows = [p ** e for p, e in factorint(n).items()]
    for i in range(2 ** len(factorpows)):
        d = 1
        for k in range(i.bit_length()):
            if i & 1:
                d *= factorpows[k]
            i >>= 1
        yield d

@overload
def udivisors(n: int, generator: Literal[True]) -> Iterator[int]:
    pass

@overload
def udivisors(n: int, generator: Literal[False]=False) -> list[int]:
    pass

@overload
def udivisors(n: int, generator: bool=False) -> Iterator[int] | list[int]:
    pass

def udivisors(n: int, generator: bool=False) -> Iterator[int] | list[int]:
    rv = _udivisors(as_int(abs(n)))
    return rv if generator else sorted(rv)

def udivisor_count(n: int) -> int:
    if n == 0:
        return 0
    return 2 ** len([p for p in factorint(n) if p > 1])

def _antidivisors(n: int) -> Iterator[int]:
    if n <= 2:
        return
    for d in _divisors(n):
        y = 2 * d
        if n > y and n % y:
            yield y
    for d in _divisors(2 * n - 1):
        if n > d >= 2 and n % d:
            yield d
    for d in _divisors(2 * n + 1):
        if n > d >= 2 and n % d:
            yield d

@overload
def antidivisors(n: int, generator: Literal[True]) -> Iterator[int]:
    pass

@overload
def antidivisors(n: int, generator: Literal[False]=False) -> list[int]:
    pass

@overload
def antidivisors(n: int, generator: bool=False) -> Iterator[int] | list[int]:
    pass

def antidivisors(n: int, generator: bool=False) -> Iterator[int] | list[int]:
    rv = _antidivisors(as_int(abs(n)))
    return rv if generator else sorted(rv)

def antidivisor_count(n):
    n = as_int(abs(n))
    if n <= 2:
        return 0
    return divisor_count(2 * n - 1) + divisor_count(2 * n + 1) + divisor_count(n) - divisor_count(n, 2) - 5

@deprecated('The `sympy.ntheory.factor_.totient` has been moved to `sympy.functions.combinatorial.numbers.totient`.', deprecated_since_version='1.13', active_deprecations_target='deprecated-ntheory-symbolic-functions')
def totient(n):
    from sympy.functions.combinatorial.numbers import totient as _totient
    return _totient(n)

@deprecated('The `sympy.ntheory.factor_.reduced_totient` has been moved to `sympy.functions.combinatorial.numbers.reduced_totient`.', deprecated_since_version='1.13', active_deprecations_target='deprecated-ntheory-symbolic-functions')
def reduced_totient(n):
    from sympy.functions.combinatorial.numbers import reduced_totient as _reduced_totient
    return _reduced_totient(n)

@deprecated('The `sympy.ntheory.factor_.divisor_sigma` has been moved to `sympy.functions.combinatorial.numbers.divisor_sigma`.', deprecated_since_version='1.13', active_deprecations_target='deprecated-ntheory-symbolic-functions')
def divisor_sigma(n, k=1):
    from sympy.functions.combinatorial.numbers import divisor_sigma as func_divisor_sigma
    return func_divisor_sigma(n, k)

def _divisor_sigma(n: int, k: int=1) -> int:
    if k == 0:
        return math.prod((e + 1 for e in factorint(n).values()))
    return math.prod(((p ** (k * (e + 1)) - 1) // (p ** k - 1) for p, e in factorint(n).items()))

def core(n, t=2):
    n = as_int(n)
    t = as_int(t)
    if n <= 0:
        raise ValueError('n must be a positive integer')
    elif t <= 1:
        raise ValueError('t must be >= 2')
    else:
        y = 1
        for p, e in factorint(n).items():
            y *= p ** (e % t)
        return y

@deprecated('The `sympy.ntheory.factor_.udivisor_sigma` has been moved to `sympy.functions.combinatorial.numbers.udivisor_sigma`.', deprecated_since_version='1.13', active_deprecations_target='deprecated-ntheory-symbolic-functions')
def udivisor_sigma(n, k=1):
    from sympy.functions.combinatorial.numbers import udivisor_sigma as _udivisor_sigma
    return _udivisor_sigma(n, k)

@deprecated('The `sympy.ntheory.factor_.primenu` has been moved to `sympy.functions.combinatorial.numbers.primenu`.', deprecated_since_version='1.13', active_deprecations_target='deprecated-ntheory-symbolic-functions')
def primenu(n):
    from sympy.functions.combinatorial.numbers import primenu as _primenu
    return _primenu(n)

@deprecated('The `sympy.ntheory.factor_.primeomega` has been moved to `sympy.functions.combinatorial.numbers.primeomega`.', deprecated_since_version='1.13', active_deprecations_target='deprecated-ntheory-symbolic-functions')
def primeomega(n):
    from sympy.functions.combinatorial.numbers import primeomega as _primeomega
    return _primeomega(n)

def mersenne_prime_exponent(nth):
    n = as_int(nth)
    if n < 1:
        raise ValueError('nth must be a positive integer; mersenne_prime_exponent(1) == 2')
    if n > 51:
        raise ValueError('There are only 51 perfect numbers; nth must be less than or equal to 51')
    return MERSENNE_PRIME_EXPONENTS[n - 1]

def is_perfect(n):
    n = as_int(n)
    if n < 1:
        return False
    if n % 2 == 0:
        m = n.bit_length() + 1 >> 1
        if (1 << m - 1) * ((1 << m) - 1) != n:
            return False
        return m in MERSENNE_PRIME_EXPONENTS or is_mersenne_prime(2 ** m - 1)
    if n < 10 ** 2000:
        return False
    if n % 105 == 0:
        return False
    if all((n % m != r for m, r in [(12, 1), (468, 117), (324, 81)])):
        return False
    result = abundance(n) == 0
    if result:
        raise ValueError(filldedent('In 1888, Sylvester stated: "\n            ...a prolonged meditation on the subject has satisfied\n            me that the existence of any one such [odd perfect number]\n            -- its escape, so to say, from the complex web of conditions\n            which hem it in on all sides -- would be little short of a\n            miracle." I guess SymPy just found that miracle and it\n            factors like this: %s' % factorint(n)))
    return result

def abundance(n):
    return _divisor_sigma(n) - 2 * n

def is_abundant(n):
    n = as_int(n)
    if is_perfect(n):
        return False
    return n % 6 == 0 or bool(abundance(n) > 0)

def is_deficient(n):
    n = as_int(n)
    if is_perfect(n):
        return False
    return bool(abundance(n) < 0)

def is_amicable(m, n):
    return m != n and m + n == _divisor_sigma(m) == _divisor_sigma(n)

def is_carmichael(n):
    if n < 561:
        return False
    return n % 2 and (not isprime(n)) and all((e == 1 and (n - 1) % (p - 1) == 0 for p, e in factorint(n).items()))

def find_carmichael_numbers_in_range(x, y):
    if 0 <= x <= y:
        if x % 2 == 0:
            return [i for i in range(x + 1, y, 2) if is_carmichael(i)]
        else:
            return [i for i in range(x, y, 2) if is_carmichael(i)]
    else:
        raise ValueError('The provided range is not valid. x and y must be non-negative integers and x <= y')

def find_first_n_carmichaels(n):
    i = 561
    carmichaels = []
    while len(carmichaels) < n:
        if is_carmichael(i):
            carmichaels.append(i)
        i += 2
    return carmichaels

def dra(n, b):
    num = abs(as_int(n))
    b = as_int(b)
    if b <= 1:
        raise ValueError('Base should be an integer greater than 1')
    if num == 0:
        return 0
    return 1 + (num - 1) % (b - 1)

def drm(n, b):
    n = abs(as_int(n))
    b = as_int(b)
    if b <= 1:
        raise ValueError('Base should be an integer greater than 1')
    while n > b:
        mul = 1
        while n > 1:
            n, r = divmod(n, b)
            if r == 0:
                return 0
            mul *= r
        n = mul
    return n