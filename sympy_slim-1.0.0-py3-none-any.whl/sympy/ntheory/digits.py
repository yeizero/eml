from __future__ import annotations
from collections import defaultdict
from typing import SupportsIndex
from sympy.utilities.iterables import multiset, is_palindromic as _palindromic
from sympy.utilities.misc import as_int

def digits(n: SupportsIndex, b: SupportsIndex=10, digits: int | None=None) -> list[int]:
    b = as_int(b)
    n = as_int(n)
    if b < 2:
        raise ValueError('b must be greater than 1')
    else:
        x, y = (abs(n), [])
        while x >= b:
            x, r = divmod(x, b)
            y.append(r)
        y.append(x)
        y.append(-b if n < 0 else b)
        y.reverse()
        ndig = len(y) - 1
        if digits is not None:
            if ndig > digits:
                raise ValueError(f'For {n}, at least {ndig} digits are needed.')
            elif ndig < digits:
                y[1:1] = [0] * (digits - ndig)
        return y

def count_digits(n: SupportsIndex, b: SupportsIndex=10) -> defaultdict[int, int]:
    n = as_int(n)
    b = as_int(b)
    rv = defaultdict(int, multiset(digits(n, b)).items())
    rv.pop(b) if b in rv else rv.pop(-b)
    return rv

def is_palindromic(n: SupportsIndex, b: SupportsIndex=10) -> bool:
    return _palindromic(digits(n, b), 1)