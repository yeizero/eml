from __future__ import annotations
from math import log
from sympy.core.random import _randint
from sympy.external.gmpy import gcd, invert, sqrt
from sympy.utilities.misc import as_int
from .generate import sieve, primerange
from .primetest import isprime

class Point:

    def __init__(self, x_cord, z_cord, a_24, mod):
        self.x_cord = x_cord
        self.z_cord = z_cord
        self.a_24 = a_24
        self.mod = mod

    def __eq__(self, other):
        if self.a_24 != other.a_24 or self.mod != other.mod:
            return False
        return self.x_cord * other.z_cord % self.mod == other.x_cord * self.z_cord % self.mod

    def add(self, Q, diff):
        u = (self.x_cord - self.z_cord) * (Q.x_cord + Q.z_cord)
        v = (self.x_cord + self.z_cord) * (Q.x_cord - Q.z_cord)
        add, subt = (u + v, u - v)
        x_cord = diff.z_cord * add * add % self.mod
        z_cord = diff.x_cord * subt * subt % self.mod
        return Point(x_cord, z_cord, self.a_24, self.mod)

    def double(self):
        u = pow(self.x_cord + self.z_cord, 2, self.mod)
        v = pow(self.x_cord - self.z_cord, 2, self.mod)
        diff = u - v
        x_cord = u * v % self.mod
        z_cord = diff * (v + self.a_24 * diff) % self.mod
        return Point(x_cord, z_cord, self.a_24, self.mod)

    def mont_ladder(self, k):
        Q = self
        R = self.double()
        for i in bin(k)[3:]:
            if i == '1':
                Q = R.add(Q, self)
                R = R.double()
            else:
                R = Q.add(R, self)
                Q = Q.double()
        return Q

def _ecm_one_factor(n, B1=10000, B2=100000, max_curve=200, seed=None):
    randint = _randint(seed)
    D = min(sqrt(B2), B1 // 2 - 1)
    sieve.extend(D)
    beta = [0] * D
    S = [0] * D
    k = 1
    for p in primerange(2, B1 + 1):
        k *= pow(p, int(log(B1, p)))
    deltas_list = []
    for r in range(B1 + 2 * D, B2 + 2 * D, 4 * D):
        deltas = {abs(q - r) >> 1 for q in primerange(r - 2 * D, r + 2 * D)}
        deltas_list.append(list(deltas))
    for _ in range(max_curve):
        sigma = randint(6, n - 1)
        u = (sigma ** 2 - 5) % n
        v = 4 * sigma % n
        u_3 = pow(u, 3, n)
        try:
            a24 = pow(v - u, 3, n) * (3 * u + v) * invert(16 * u_3 * v, n) % n
        except ZeroDivisionError:
            g = gcd(2 * u_3 * v, n)
            if g == n:
                continue
            return g
        Q = Point(u_3, pow(v, 3, n), a24, n)
        Q = Q.mont_ladder(k)
        g = gcd(Q.z_cord, n)
        if g != 1 and g != n:
            return g
        elif g == n:
            continue
        S[0] = Q
        Q2 = Q.double()
        S[1] = Q2.add(Q, Q)
        beta[0] = S[0].x_cord * S[0].z_cord % n
        beta[1] = S[1].x_cord * S[1].z_cord % n
        for d in range(2, D):
            S[d] = S[d - 1].add(Q2, S[d - 2])
            beta[d] = S[d].x_cord * S[d].z_cord % n
        g = 1
        W = Q.mont_ladder(4 * D)
        T = Q.mont_ladder(B1 - 2 * D)
        R = Q.mont_ladder(B1 + 2 * D)
        for deltas in deltas_list:
            alpha = R.x_cord * R.z_cord % n
            for delta in deltas:
                f = (R.x_cord - S[delta].x_cord) * (R.z_cord + S[delta].z_cord) - alpha + beta[delta]
                g = g * f % n
            T, R = (R, R.add(W, T))
        g = gcd(n, g)
        if g != 1 and g != n:
            return g

def ecm(n, B1=10000, B2=100000, max_curve=200, seed=1234):
    from .factor_ import _perfect_power
    n = as_int(n)
    if B1 % 2 != 0 or B2 % 2 != 0:
        raise ValueError('both bounds must be even')
    TF_LIMIT = 100000
    factors = set()
    for prime in sieve.primerange(2, TF_LIMIT):
        if n % prime == 0:
            factors.add(prime)
            while n % prime == 0:
                n //= prime
    queue = []

    def check(m):
        if isprime(m):
            factors.add(m)
            return
        if (result := _perfect_power(m, TF_LIMIT)):
            return check(result[0])
        queue.append(m)
    check(n)
    while queue:
        n = queue.pop()
        factor = _ecm_one_factor(n, B1, B2, max_curve, seed)
        if factor is None:
            raise ValueError('Increase the bounds')
        check(factor)
        check(n // factor)
    return factors