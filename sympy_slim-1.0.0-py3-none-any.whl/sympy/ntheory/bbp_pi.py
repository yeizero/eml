from __future__ import annotations
from typing import TYPE_CHECKING
from sympy.utilities.misc import as_int
if TYPE_CHECKING:
    from typing import SupportsIndex

def _series(j: int, n: int, prec: int=14) -> int:
    s = 0
    D = _dn(n, prec)
    D4 = 4 * D
    d = j
    for k in range(n + 1):
        s += (pow(16, n - k, d) << D4) // d
        d += 8
    t = 0
    k = n + 1
    e = D4 - 4
    d = 8 * k + j
    while True:
        dt = (1 << e) // d
        if not dt:
            break
        t += dt
        e -= 4
        d += 8
    total = s + t
    return total

def pi_hex_digits(n: SupportsIndex, prec: int=14) -> str:
    n, prec = (as_int(n), as_int(prec))
    if n < 0:
        raise ValueError('n cannot be negative')
    if prec < 0:
        raise ValueError('prec cannot be negative')
    if prec == 0:
        return ''
    n -= 1
    a = [4, 2, 1, 1]
    j = [1, 4, 5, 6]
    D = _dn(n, prec)
    x = +(a[0] * _series(j[0], n, prec) - a[1] * _series(j[1], n, prec) - a[2] * _series(j[2], n, prec) - a[3] * _series(j[3], n, prec)) & 16 ** D - 1
    s = ('%0' + '%ix' % prec) % (x // 16 ** (D - prec))
    return s

def _dn(n: int, prec: int) -> int:
    n += 1
    return ((n + prec).bit_length() - 1) // 4 + prec + 3