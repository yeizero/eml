from __future__ import annotations
from typing import SupportsIndex, Iterable
from sympy.utilities.misc import as_int

def binomial_coefficients(n: SupportsIndex) -> dict[tuple[int, ...], int]:
    n = as_int(n)
    d: dict[tuple[int, ...], int] = {(0, n): 1, (n, 0): 1}
    a = 1
    for k in range(1, n // 2 + 1):
        a = a * (n - k + 1) // k
        d[k, n - k] = d[n - k, k] = a
    return d

def binomial_coefficients_list(n: SupportsIndex) -> list[int]:
    n = as_int(n)
    d = [1] * (n + 1)
    a = 1
    for k in range(1, n // 2 + 1):
        a = a * (n - k + 1) // k
        d[k] = d[n - k] = a
    return d

def multinomial_coefficients(m: SupportsIndex, n: SupportsIndex) -> dict[tuple[int, ...], int]:
    m = as_int(m)
    n = as_int(n)
    if not m:
        if n:
            return {}
        return {(): 1}
    if m == 2:
        return binomial_coefficients(n)
    if m >= 2 * n and n > 1:
        return dict(multinomial_coefficients_iterator(m, n))
    t = [n] + [0] * (m - 1)
    r = {tuple(t): 1}
    if n:
        j = 0
    else:
        j = m
    while j < m - 1:
        tj = t[j]
        if j:
            t[j] = 0
            t[0] = tj
        if tj > 1:
            t[j + 1] += 1
            j = 0
            start = 1
            v = 0
        else:
            j += 1
            start = j + 1
            v = r[tuple(t)]
            t[j] += 1
        for k in range(start, m):
            if t[k]:
                t[k] -= 1
                v += r[tuple(t)]
                t[k] += 1
        t[0] -= 1
        r[tuple(t)] = v * tj // (n - t[0])
    return r

def multinomial_coefficients_iterator(m: SupportsIndex, n: SupportsIndex, _tuple: type[tuple]=tuple) -> Iterable[tuple[tuple[int, ...], int]]:
    m = as_int(m)
    n = as_int(n)
    if m < 2 * n or n == 1:
        mc = multinomial_coefficients(m, n)
        yield from mc.items()
    else:
        mc = multinomial_coefficients(n, n)
        mc1 = {}
        for k, v in mc.items():
            mc1[_tuple(filter(None, k))] = v
        mc = mc1
        t = [n] + [0] * (m - 1)
        t1 = _tuple(t)
        b = _tuple(filter(None, t1))
        yield (t1, mc[b])
        if n:
            j = 0
        else:
            j = m
        while j < m - 1:
            tj = t[j]
            if j:
                t[j] = 0
                t[0] = tj
            if tj > 1:
                t[j + 1] += 1
                j = 0
            else:
                j += 1
                t[j] += 1
            t[0] -= 1
            t1 = _tuple(t)
            b = _tuple(filter(None, t1))
            yield (t1, mc[b])