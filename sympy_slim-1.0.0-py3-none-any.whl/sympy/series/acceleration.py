from __future__ import annotations
from sympy.core.numbers import Integer
from sympy.core.singleton import S
from sympy.functions.combinatorial.factorials import factorial

def richardson(A, k, n, N):
    s = S.Zero
    for j in range(0, N + 1):
        s += A.subs(k, Integer(n + j)).doit() * (n + j) ** N * S.NegativeOne ** (j + N) / (factorial(j) * factorial(N - j))
    return s

def shanks(A, k, n, m=1):
    table = [A.subs(k, Integer(j)).doit() for j in range(n + m + 2)]
    table2 = table.copy()
    for i in range(1, m + 1):
        for j in range(i, n + m + 1):
            x, y, z = (table[j - 1], table[j], table[j + 1])
            table2[j] = (z * x - y ** 2) / (z + x - 2 * y)
        table = table2.copy()
    return table[n]