from __future__ import annotations
from sympy.calculus.accumulationbounds import AccumulationBounds
from sympy.core.add import Add
from sympy.core.function import PoleError
from sympy.core.power import Pow
from sympy.core.singleton import S
from sympy.core.symbol import Dummy
from sympy.core.sympify import sympify
from sympy.functions.combinatorial.numbers import fibonacci
from sympy.functions.combinatorial.factorials import factorial, subfactorial
from sympy.functions.special.gamma_functions import gamma
from sympy.functions.elementary.complexes import Abs
from sympy.functions.elementary.miscellaneous import Max, Min
from sympy.functions.elementary.trigonometric import cos, sin
from sympy.series.limits import Limit

def difference_delta(expr, n=None, step=1):
    expr = sympify(expr)
    if n is None:
        f = expr.free_symbols
        if len(f) == 1:
            n = f.pop()
        elif len(f) == 0:
            return S.Zero
        else:
            raise ValueError('Since there is more than one variable in the expression, a variable must be supplied to take the difference of %s' % expr)
    step = sympify(step)
    if step.is_number is False or step.is_finite is False:
        raise ValueError('Step should be a finite number.')
    if hasattr(expr, '_eval_difference_delta'):
        result = expr._eval_difference_delta(n, step)
        if result:
            return result
    return expr.subs(n, n + step) - expr

def dominant(expr, n):
    terms = Add.make_args(expr.expand(func=True))
    term0 = terms[-1]
    comp = [term0]
    for t in terms[:-1]:
        r = term0 / t
        e = r.gammasimp()
        if e == r:
            e = r.factor()
        l = limit_seq(e, n)
        if l is None:
            return None
        elif l.is_zero:
            term0 = t
            comp = [term0]
        elif l not in [S.Infinity, S.NegativeInfinity]:
            comp.append(t)
    if len(comp) > 1:
        return None
    return term0

def _limit_inf(expr, n):
    try:
        return Limit(expr, n, S.Infinity).doit(deep=False)
    except (NotImplementedError, PoleError):
        return None

def _limit_seq(expr, n, trials):
    from sympy.concrete.summations import Sum
    for i in range(trials):
        if not expr.has(Sum):
            result = _limit_inf(expr, n)
            if result is not None:
                return result
        num, den = expr.as_numer_denom()
        if not den.has(n) or not num.has(n):
            result = _limit_inf(expr.doit(), n)
            if result is not None:
                return result
            return None
        num, den = (difference_delta(t.expand(), n) for t in [num, den])
        expr = (num / den).gammasimp()
        if not expr.has(Sum):
            result = _limit_inf(expr, n)
            if result is not None:
                return result
        num, den = expr.as_numer_denom()
        num = dominant(num, n)
        if num is None:
            return None
        den = dominant(den, n)
        if den is None:
            return None
        expr = (num / den).gammasimp()

def limit_seq(expr, n=None, trials=5):
    from sympy.concrete.summations import Sum
    if n is None:
        free = expr.free_symbols
        if len(free) == 1:
            n = free.pop()
        elif not free:
            return expr
        else:
            raise ValueError('Expression has more than one variable. Please specify a variable.')
    elif n not in expr.free_symbols:
        return expr
    expr = expr.rewrite(fibonacci, S.GoldenRatio)
    expr = expr.rewrite(factorial, subfactorial, gamma)
    n_ = Dummy('n', integer=True, positive=True)
    n1 = Dummy('n', odd=True, positive=True)
    n2 = Dummy('n', even=True, positive=True)
    powers = (p.as_base_exp() for p in expr.atoms(Pow))
    if any((b.is_negative and e.has(n) for b, e in powers)) or expr.has(cos, sin):
        L1 = _limit_seq(expr.xreplace({n: n1}), n1, trials)
        if L1 is not None:
            L2 = _limit_seq(expr.xreplace({n: n2}), n2, trials)
            if L1 != L2:
                if L1.is_comparable and L2.is_comparable:
                    return AccumulationBounds(Min(L1, L2), Max(L1, L2))
                else:
                    return None
    else:
        L1 = _limit_seq(expr.xreplace({n: n_}), n_, trials)
    if L1 is not None:
        return L1
    elif expr.is_Add:
        limits = [limit_seq(term, n, trials) for term in expr.args]
        if any((result is None for result in limits)):
            return None
        else:
            return Add(*limits)
    elif not expr.has(Sum):
        lim = _limit_seq(Abs(expr.xreplace({n: n_})), n_, trials)
        if lim is not None and lim.is_zero:
            return S.Zero