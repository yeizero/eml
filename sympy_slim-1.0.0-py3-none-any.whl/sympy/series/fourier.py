from __future__ import annotations
from sympy.core.numbers import oo, pi
from sympy.core.symbol import Wild
from sympy.core.expr import Expr
from sympy.core.add import Add
from sympy.core.containers import Tuple
from sympy.core.singleton import S
from sympy.core.symbol import Dummy, Symbol
from sympy.core.sympify import sympify
from sympy.functions.elementary.trigonometric import sin, cos, sinc
from sympy.series.series_class import SeriesBase
from sympy.series.sequences import SeqFormula
from sympy.sets.sets import Interval
from sympy.utilities.iterables import is_sequence
__doctest_requires__ = {('fourier_series',): ['matplotlib']}

def fourier_cos_seq(func, limits, n):
    from sympy.integrals import integrate
    x, L = (limits[0], limits[2] - limits[1])
    cos_term = cos(2 * n * pi * x / L)
    formula = 2 * cos_term * integrate(func * cos_term, limits) / L
    a0 = formula.subs(n, S.Zero) / 2
    return (a0, SeqFormula(2 * cos_term * integrate(func * cos_term, limits) / L, (n, 1, oo)))

def fourier_sin_seq(func, limits, n):
    from sympy.integrals import integrate
    x, L = (limits[0], limits[2] - limits[1])
    sin_term = sin(2 * n * pi * x / L)
    return SeqFormula(2 * sin_term * integrate(func * sin_term, limits) / L, (n, 1, oo))

def _process_limits(func, limits):

    def _find_x(func):
        free = func.free_symbols
        if len(free) == 1:
            return free.pop()
        elif not free:
            return Dummy('k')
        else:
            raise ValueError(' specify dummy variables for %s. If the function contains more than one free symbol, a dummy variable should be supplied explicitly e.g. FourierSeries(m*n**2, (n, -pi, pi))' % func)
    x, start, stop = (None, None, None)
    if limits is None:
        x, start, stop = (_find_x(func), -pi, pi)
    if is_sequence(limits, Tuple):
        if len(limits) == 3:
            x, start, stop = limits
        elif len(limits) == 2:
            x = _find_x(func)
            start, stop = limits
    if not isinstance(x, Symbol) or start is None or stop is None:
        raise ValueError('Invalid limits given: %s' % str(limits))
    unbounded = [S.NegativeInfinity, S.Infinity]
    if start in unbounded or stop in unbounded:
        raise ValueError('Both the start and end value should be bounded')
    return sympify((x, start, stop))

def finite_check(f, x, L):

    def check_fx(exprs, x):
        return x not in exprs.free_symbols

    def check_sincos(_expr, x, L):
        if isinstance(_expr, (sin, cos)):
            sincos_args = _expr.args[0]
            if sincos_args.match(a * (pi / L) * x + b) is not None:
                return True
            else:
                return False
    from sympy.simplify.fu import TR2, TR1, sincos_to_sum
    _expr = sincos_to_sum(TR2(TR1(f)))
    add_coeff = _expr.as_coeff_add()
    a = Wild('a', properties=[lambda k: k.is_Integer, lambda k: k != S.Zero])
    b = Wild('b', properties=[lambda k: x not in k.free_symbols])
    for s in add_coeff[1]:
        mul_coeffs = s.as_coeff_mul()[1]
        for t in mul_coeffs:
            if not (check_fx(t, x) or check_sincos(t, x, L)):
                return (False, f)
    return (True, _expr)

class FourierSeries(SeriesBase):

    def __new__(cls, *args):
        args = map(sympify, args)
        return Expr.__new__(cls, *args)

    @property
    def function(self):
        return self.args[0]

    @property
    def x(self):
        return self.args[1][0]

    @property
    def period(self):
        return (self.args[1][1], self.args[1][2])

    @property
    def a0(self):
        return self.args[2][0]

    @property
    def an(self):
        return self.args[2][1]

    @property
    def bn(self):
        return self.args[2][2]

    @property
    def interval(self):
        return Interval(0, oo)

    @property
    def start(self):
        return self.interval.inf

    @property
    def stop(self):
        return self.interval.sup

    @property
    def length(self):
        return oo

    @property
    def L(self):
        return abs(self.period[1] - self.period[0]) / 2

    def _eval_subs(self, old, new):
        x = self.x
        if old.has(x):
            return self

    def truncate(self, n=3):
        if n is None:
            return iter(self)
        terms = []
        for t in self:
            if len(terms) == n:
                break
            if t is not S.Zero:
                terms.append(t)
        return Add(*terms)

    def sigma_approximation(self, n=3):
        terms = [sinc(pi * i / n) * t for i, t in enumerate(self[:n]) if t is not S.Zero]
        return Add(*terms)

    def shift(self, s):
        s, x = (sympify(s), self.x)
        if x in s.free_symbols:
            raise ValueError("'%s' should be independent of %s" % (s, x))
        a0 = self.a0 + s
        sfunc = self.function + s
        return self.func(sfunc, self.args[1], (a0, self.an, self.bn))

    def shiftx(self, s):
        s, x = (sympify(s), self.x)
        if x in s.free_symbols:
            raise ValueError("'%s' should be independent of %s" % (s, x))
        an = self.an.subs(x, x + s)
        bn = self.bn.subs(x, x + s)
        sfunc = self.function.subs(x, x + s)
        return self.func(sfunc, self.args[1], (self.a0, an, bn))

    def scale(self, s):
        s, x = (sympify(s), self.x)
        if x in s.free_symbols:
            raise ValueError("'%s' should be independent of %s" % (s, x))
        an = self.an.coeff_mul(s)
        bn = self.bn.coeff_mul(s)
        a0 = self.a0 * s
        sfunc = self.args[0] * s
        return self.func(sfunc, self.args[1], (a0, an, bn))

    def scalex(self, s):
        s, x = (sympify(s), self.x)
        if x in s.free_symbols:
            raise ValueError("'%s' should be independent of %s" % (s, x))
        an = self.an.subs(x, x * s)
        bn = self.bn.subs(x, x * s)
        sfunc = self.function.subs(x, x * s)
        return self.func(sfunc, self.args[1], (self.a0, an, bn))

    def _eval_as_leading_term(self, x, logx, cdir):
        for t in self:
            if t is not S.Zero:
                return t

    def _eval_term(self, pt):
        if pt == 0:
            return self.a0
        return self.an.coeff(pt) + self.bn.coeff(pt)

    def __neg__(self):
        return self.scale(-1)

    def __add__(self, other):
        if isinstance(other, FourierSeries):
            if self.period != other.period:
                raise ValueError('Both the series should have same periods')
            x, y = (self.x, other.x)
            function = self.function + other.function.subs(y, x)
            if self.x not in function.free_symbols:
                return function
            an = self.an + other.an
            bn = self.bn + other.bn
            a0 = self.a0 + other.a0
            return self.func(function, self.args[1], (a0, an, bn))
        return Add(self, other)

    def __sub__(self, other):
        return self.__add__(-other)

class FiniteFourierSeries(FourierSeries):

    def __new__(cls, f, limits, exprs):
        f = sympify(f)
        limits = sympify(limits)
        exprs = sympify(exprs)
        if not (isinstance(exprs, Tuple) and len(exprs) == 3):
            c, e = exprs.as_coeff_add()
            from sympy.simplify.fu import TR10
            rexpr = c + Add(*[TR10(i) for i in e])
            a0, exp_ls = rexpr.expand(trig=False, power_base=False, power_exp=False, log=False).as_coeff_add()
            x = limits[0]
            L = abs(limits[2] - limits[1]) / 2
            a = Wild('a', properties=[lambda k: k.is_Integer, lambda k: k is not S.Zero])
            b = Wild('b', properties=[lambda k: x not in k.free_symbols])
            an = {}
            bn = {}
            for p in exp_ls:
                t = p.match(b * cos(a * (pi / L) * x))
                q = p.match(b * sin(a * (pi / L) * x))
                if t:
                    an[t[a]] = t[b] + an.get(t[a], S.Zero)
                elif q:
                    bn[q[a]] = q[b] + bn.get(q[a], S.Zero)
                else:
                    a0 += p
            exprs = Tuple(a0, an, bn)
        return Expr.__new__(cls, f, limits, exprs)

    @property
    def interval(self):
        _length = 1 if self.a0 else 0
        _length += max(set(self.an.keys()).union(set(self.bn.keys()))) + 1
        return Interval(0, _length)

    @property
    def length(self):
        return self.stop - self.start

    def shiftx(self, s):
        s, x = (sympify(s), self.x)
        if x in s.free_symbols:
            raise ValueError("'%s' should be independent of %s" % (s, x))
        _expr = self.truncate().subs(x, x + s)
        sfunc = self.function.subs(x, x + s)
        return self.func(sfunc, self.args[1], _expr)

    def scale(self, s):
        s, x = (sympify(s), self.x)
        if x in s.free_symbols:
            raise ValueError("'%s' should be independent of %s" % (s, x))
        _expr = self.truncate() * s
        sfunc = self.function * s
        return self.func(sfunc, self.args[1], _expr)

    def scalex(self, s):
        s, x = (sympify(s), self.x)
        if x in s.free_symbols:
            raise ValueError("'%s' should be independent of %s" % (s, x))
        _expr = self.truncate().subs(x, x * s)
        sfunc = self.function.subs(x, x * s)
        return self.func(sfunc, self.args[1], _expr)

    def _eval_term(self, pt):
        if pt == 0:
            return self.a0
        _term = self.an.get(pt, S.Zero) * cos(pt * (pi / self.L) * self.x) + self.bn.get(pt, S.Zero) * sin(pt * (pi / self.L) * self.x)
        return _term

    def __add__(self, other):
        if isinstance(other, FourierSeries):
            return other.__add__(fourier_series(self.function, self.args[1], finite=False))
        elif isinstance(other, FiniteFourierSeries):
            if self.period != other.period:
                raise ValueError('Both the series should have same periods')
            x, y = (self.x, other.x)
            function = self.function + other.function.subs(y, x)
            if self.x not in function.free_symbols:
                return function
            return fourier_series(function, limits=self.args[1])

def fourier_series(f, limits=None, finite=True):
    f = sympify(f)
    limits = _process_limits(f, limits)
    x = limits[0]
    if x not in f.free_symbols:
        return f
    if finite:
        L = abs(limits[2] - limits[1]) / 2
        is_finite, res_f = finite_check(f, x, L)
        if is_finite:
            return FiniteFourierSeries(f, limits, res_f)
    n = Dummy('n')
    center = (limits[1] + limits[2]) / 2
    if center.is_zero:
        neg_f = f.subs(x, -x)
        if f == neg_f:
            a0, an = fourier_cos_seq(f, limits, n)
            bn = SeqFormula(0, (1, oo))
            return FourierSeries(f, limits, (a0, an, bn))
        elif f == -neg_f:
            a0 = S.Zero
            an = SeqFormula(0, (1, oo))
            bn = fourier_sin_seq(f, limits, n)
            return FourierSeries(f, limits, (a0, an, bn))
    a0, an = fourier_cos_seq(f, limits, n)
    bn = fourier_sin_seq(f, limits, n)
    return FourierSeries(f, limits, (a0, an, bn))