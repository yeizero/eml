from __future__ import annotations
from collections import defaultdict
from sympy.core.numbers import nan, oo, zoo
from sympy.core.add import Add
from sympy.core.expr import Expr
from sympy.core.function import Derivative, Function, expand
from sympy.core.mul import Mul
from sympy.core.numbers import Rational
from sympy.core.relational import Eq
from sympy.sets.sets import Interval
from sympy.core.singleton import S
from sympy.core.symbol import Wild, Dummy, symbols, Symbol
from sympy.core.sympify import sympify
from sympy.discrete.convolutions import convolution
from sympy.functions.combinatorial.factorials import binomial, factorial, rf
from sympy.functions.combinatorial.numbers import bell
from sympy.functions.elementary.integers import floor, frac, ceiling
from sympy.functions.elementary.miscellaneous import Min, Max
from sympy.functions.elementary.piecewise import Piecewise
from sympy.series.limits import Limit
from sympy.series.order import Order
from sympy.series.sequences import sequence
from sympy.series.series_class import SeriesBase
from sympy.utilities.iterables import iterable

def rational_algorithm(f, x, k, order=4, full=False):
    from sympy.polys import RootSum, apart
    from sympy.integrals import integrate
    diff = f
    ds = []
    for i in range(order + 1):
        if i:
            diff = diff.diff(x)
        if diff.is_rational_function(x):
            coeff, sep = (S.Zero, S.Zero)
            terms = apart(diff, x, full=full)
            if terms.has(RootSum):
                terms = terms.doit()
            for t in Add.make_args(terms):
                num, den = t.as_numer_denom()
                if not den.has(x):
                    sep += t
                else:
                    if isinstance(den, Mul):
                        ind = den.as_independent(x)
                        den = ind[1]
                        num /= ind[0]
                    den, j = den.as_base_exp()
                    a, xterm = den.as_coeff_add(x)
                    if not a:
                        sep += t
                        continue
                    xc = xterm[0].coeff(x)
                    a /= -xc
                    num /= xc ** j
                    ak = (-1) ** j * num * binomial(j + k - 1, k).rewrite(factorial) / a ** (j + k)
                    coeff += ak
            if coeff.is_zero:
                return None
            if coeff.has(x) or coeff.has(zoo) or coeff.has(oo) or coeff.has(nan):
                return None
            for j in range(i):
                coeff = coeff / (k + j + 1)
                sep = integrate(sep, x)
                sep += (ds.pop() - sep).limit(x, 0)
            return (coeff.subs(k, k - i), sep, i)
        else:
            ds.append(diff)
    return None

def rational_independent(terms, x):
    if not terms:
        return []
    ind = terms[0:1]
    for t in terms[1:]:
        n = t.as_independent(x)[1]
        for i, term in enumerate(ind):
            d = term.as_independent(x)[1]
            q = (n / d).cancel()
            if q.is_rational_function(x):
                ind[i] += t
                break
        else:
            ind.append(t)
    return ind

def simpleDE(f, x, g, order=4):
    from sympy.solvers.solveset import linsolve
    a = symbols('a:%d' % order)

    def _makeDE(k):
        eq = f.diff(x, k) + Add(*[a[i] * f.diff(x, i) for i in range(0, k)])
        DE = g(x).diff(x, k) + Add(*[a[i] * g(x).diff(x, i) for i in range(0, k)])
        return (eq, DE)
    found = False
    for k in range(1, order + 1):
        eq, DE = _makeDE(k)
        eq = eq.expand()
        terms = eq.as_ordered_terms()
        ind = rational_independent(terms, x)
        if found or len(ind) == k:
            sol = dict(zip(a, (i for s in linsolve(ind, a[:k]) for i in s)))
            if sol:
                found = True
                DE = DE.subs(sol)
            DE = DE.as_numer_denom()[0]
            DE = DE.factor().as_coeff_mul(Derivative)[1][0]
            yield (DE.collect(Derivative(g(x))), k)

def exp_re(DE, r, k):
    RE = S.Zero
    g = DE.atoms(Function).pop()
    mini = None
    for t in Add.make_args(DE):
        coeff, d = t.as_independent(g)
        if isinstance(d, Derivative):
            j = d.derivative_count
        else:
            j = 0
        if mini is None or j < mini:
            mini = j
        RE += coeff * r(k + j)
    if mini:
        RE = RE.subs(k, k - mini)
    return RE

def hyper_re(DE, r, k):
    RE = S.Zero
    g = DE.atoms(Function).pop()
    x = g.atoms(Symbol).pop()
    mini = None
    for t in Add.make_args(DE.expand()):
        coeff, d = t.as_independent(g)
        c, v = coeff.as_independent(x)
        l = v.as_coeff_exponent(x)[1]
        if isinstance(d, Derivative):
            j = d.derivative_count
        else:
            j = 0
        RE += c * rf(k + 1 - l, j) * r(k + j - l)
        if mini is None or j - l < mini:
            mini = j - l
    RE = RE.subs(k, k - mini)
    m = Wild('m')
    return RE.collect(r(k + m))

def _transformation_a(f, x, P, Q, k, m, shift):
    f *= x ** (-shift)
    P = P.subs(k, k + shift)
    Q = Q.subs(k, k + shift)
    return (f, P, Q, m)

def _transformation_c(f, x, P, Q, k, m, scale):
    f = f.subs(x, x ** scale)
    P = P.subs(k, k / scale)
    Q = Q.subs(k, k / scale)
    m *= scale
    return (f, P, Q, m)

def _transformation_e(f, x, P, Q, k, m):
    f = f.diff(x)
    P = P.subs(k, k + 1) * (k + m + 1)
    Q = Q.subs(k, k + 1) * (k + 1)
    return (f, P, Q, m)

def _apply_shift(sol, shift):
    return [(res, cond + shift) for res, cond in sol]

def _apply_scale(sol, scale):
    return [(res, cond / scale) for res, cond in sol]

def _apply_integrate(sol, x, k):
    return [(res / ((cond + 1) * cond.as_coeff_Add()[1].coeff(k)), cond + 1) for res, cond in sol]

def _compute_formula(f, x, P, Q, k, m, k_max):
    from sympy.polys import roots
    sol = []
    for i in range(k_max + 1, k_max + m + 1):
        if (i < 0) == True:
            continue
        r = f.diff(x, i).limit(x, 0) / factorial(i)
        if r.is_zero:
            continue
        kterm = m * k + i
        res = r
        p = P.subs(k, kterm)
        q = Q.subs(k, kterm)
        c1 = p.subs(k, 1 / k).leadterm(k)[0]
        c2 = q.subs(k, 1 / k).leadterm(k)[0]
        res *= (-c1 / c2) ** k
        res *= Mul(*[rf(-r, k) ** mul for r, mul in roots(p, k).items()])
        res /= Mul(*[rf(-r, k) ** mul for r, mul in roots(q, k).items()])
        sol.append((res, kterm))
    return sol

def _rsolve_hypergeometric(f, x, P, Q, k, m):
    from sympy.polys import lcm, roots
    from sympy.integrals import integrate
    proots, qroots = (roots(P, k), roots(Q, k))
    all_roots = dict(proots)
    all_roots.update(qroots)
    scale = lcm([r.as_numer_denom()[1] for r, t in all_roots.items() if r.is_rational])
    f, P, Q, m = _transformation_c(f, x, P, Q, k, m, scale)
    qroots = roots(Q, k)
    if qroots:
        k_min = Min(*qroots.keys())
    else:
        k_min = S.Zero
    shift = k_min + m
    f, P, Q, m = _transformation_a(f, x, P, Q, k, m, shift)
    l = (x * f).limit(x, 0)
    if not isinstance(l, Limit) and l != 0:
        return None
    qroots = roots(Q, k)
    if qroots:
        k_max = Max(*qroots.keys())
    else:
        k_max = S.Zero
    ind, mp = (S.Zero, -oo)
    for i in range(k_max + m + 1):
        r = f.diff(x, i).limit(x, 0) / factorial(i)
        if r.is_finite is False:
            old_f = f
            f, P, Q, m = _transformation_a(f, x, P, Q, k, m, i)
            f, P, Q, m = _transformation_e(f, x, P, Q, k, m)
            sol, ind, mp = _rsolve_hypergeometric(f, x, P, Q, k, m)
            sol = _apply_integrate(sol, x, k)
            sol = _apply_shift(sol, i)
            ind = integrate(ind, x)
            ind += (old_f - ind).limit(x, 0)
            mp += 1
            return (sol, ind, mp)
        elif r:
            ind += r * x ** (i + shift)
            pow_x = Rational(i + shift, scale)
            if pow_x > mp:
                mp = pow_x
    ind = ind.subs(x, x ** (1 / scale))
    sol = _compute_formula(f, x, P, Q, k, m, k_max)
    sol = _apply_shift(sol, shift)
    sol = _apply_scale(sol, scale)
    return (sol, ind, mp)

def rsolve_hypergeometric(f, x, P, Q, k, m):
    result = _rsolve_hypergeometric(f, x, P, Q, k, m)
    if result is None:
        return None
    sol_list, ind, mp = result
    sol_dict = defaultdict(lambda: S.Zero)
    for res, cond in sol_list:
        j, mk = cond.as_coeff_Add()
        c = mk.coeff(k)
        if j.is_integer is False:
            res *= x ** frac(j)
            j = floor(j)
        res = res.subs(k, (k - j) / c)
        cond = Eq(k % c, j % c)
        sol_dict[cond] += res
    sol = [(res, cond) for cond, res in sol_dict.items()]
    sol.append((S.Zero, True))
    sol = Piecewise(*sol)
    if mp is -oo:
        s = S.Zero
    elif mp.is_integer is False:
        s = ceiling(mp)
    else:
        s = mp + 1
    if s < 0:
        ind += sum(sequence(sol * x ** k, (k, s, -1)))
        s = S.Zero
    return (sol, ind, s)

def _solve_hyper_RE(f, x, RE, g, k):
    terms = Add.make_args(RE)
    if len(terms) == 2:
        gs = list(RE.atoms(Function))
        P, Q = map(RE.coeff, gs)
        m = gs[1].args[0] - gs[0].args[0]
        if m < 0:
            P, Q = (Q, P)
            m = abs(m)
        return rsolve_hypergeometric(f, x, P, Q, k, m)

def _solve_explike_DE(f, x, DE, g, k):
    from sympy.solvers import rsolve
    for t in Add.make_args(DE):
        coeff, d = t.as_independent(g)
        if coeff.free_symbols:
            return
    RE = exp_re(DE, g, k)
    init = {}
    for i in range(len(Add.make_args(RE))):
        if i:
            f = f.diff(x)
        init[g(k).subs(k, i)] = f.limit(x, 0)
    sol = rsolve(RE, g(k), init)
    if sol:
        return (sol / factorial(k), S.Zero, S.Zero)

def _solve_simple(f, x, DE, g, k):
    from sympy.solvers import rsolve
    RE = hyper_re(DE, g, k)
    init = {}
    for i in range(len(Add.make_args(RE))):
        if i:
            f = f.diff(x)
        init[g(k).subs(k, i)] = f.limit(x, 0) / factorial(i)
    sol = rsolve(RE, g(k), init)
    if sol:
        return (sol, S.Zero, S.Zero)

def _transform_explike_DE(DE, g, x, order, syms):
    from sympy.solvers.solveset import linsolve
    eq = []
    highest_coeff = DE.coeff(Derivative(g(x), x, order))
    for i in range(order):
        coeff = DE.coeff(Derivative(g(x), x, i))
        coeff = (coeff / highest_coeff).expand().collect(x)
        eq.extend(Add.make_args(coeff))
    temp = []
    for e in eq:
        if e.has(x):
            break
        elif e.has(Symbol):
            temp.append(e)
    else:
        eq = temp
    if eq:
        sol = dict(zip(syms, (i for s in linsolve(eq, list(syms)) for i in s)))
        if sol:
            DE = DE.subs(sol)
            DE = DE.factor().as_coeff_mul(Derivative)[1][0]
            DE = DE.collect(Derivative(g(x)))
    return DE

def _transform_DE_RE(DE, g, k, order, syms):
    from sympy.solvers.solveset import linsolve
    RE = hyper_re(DE, g, k)
    eq = [RE.coeff(g(k + i)) for i in range(1, order)]
    sol = dict(zip(syms, (i for s in linsolve(eq, list(syms)) for i in s)))
    if sol:
        m = Wild('m')
        RE = RE.subs(sol)
        RE = RE.factor().as_numer_denom()[0].collect(g(k + m))
        RE = RE.as_coeff_mul(g)[1][0]
        for i in range(order):
            if RE.coeff(g(k + i)) and i:
                RE = RE.subs(k, k - i)
                break
    return RE

def solve_de(f, x, DE, order, g, k):
    sol = None
    syms = DE.free_symbols.difference({g, x})
    if syms:
        RE = _transform_DE_RE(DE, g, k, order, syms)
    else:
        RE = hyper_re(DE, g, k)
    if not RE.free_symbols.difference({k}):
        sol = _solve_hyper_RE(f, x, RE, g, k)
    if sol:
        return sol
    if syms:
        DE = _transform_explike_DE(DE, g, x, order, syms)
    if not DE.free_symbols.difference({x}):
        sol = _solve_explike_DE(f, x, DE, g, k)
    if sol:
        return sol

def hyper_algorithm(f, x, k, order=4):
    g = Function('g')
    des = []
    sol = None
    for DE, i in simpleDE(f, x, g, order):
        if DE is not None:
            sol = solve_de(f, x, DE, i, g, k)
        if sol:
            return sol
        if not DE.free_symbols.difference({x}):
            des.append(DE)
    for DE in des:
        sol = _solve_simple(f, x, DE, g, k)
        if sol:
            return sol

def _compute_fps(f, x, x0, dir, hyper, order, rational, full):
    if x0 in [S.Infinity, S.NegativeInfinity]:
        dir = S.One if x0 is S.Infinity else -S.One
        temp = f.subs(x, 1 / x)
        result = _compute_fps(temp, x, 0, dir, hyper, order, rational, full)
        if result is None:
            return None
        return (result[0], result[1].subs(x, 1 / x), result[2].subs(x, 1 / x))
    elif x0 or dir == -S.One:
        if dir == -S.One:
            rep = -x + x0
            rep2 = -x
            rep2b = x0
        else:
            rep = x + x0
            rep2 = x
            rep2b = -x0
        temp = f.subs(x, rep)
        result = _compute_fps(temp, x, 0, S.One, hyper, order, rational, full)
        if result is None:
            return None
        return (result[0], result[1].subs(x, rep2 + rep2b), result[2].subs(x, rep2 + rep2b))
    if f.is_polynomial(x):
        k = Dummy('k')
        ak = sequence(Coeff(f, x, k), (k, 1, oo))
        xk = sequence(x ** k, (k, 0, oo))
        ind = f.coeff(x, 0)
        return (ak, xk, ind)
    if isinstance(f, Add):
        result = False
        ak = sequence(S.Zero, (0, oo))
        ind, xk = (S.Zero, None)
        for t in Add.make_args(f):
            res = _compute_fps(t, x, 0, S.One, hyper, order, rational, full)
            if res:
                if not result:
                    result = True
                    xk = res[1]
                if res[0].start > ak.start:
                    seq = ak
                    s, f = (ak.start, res[0].start)
                else:
                    seq = res[0]
                    s, f = (res[0].start, ak.start)
                save = Add(*[z[0] * z[1] for z in zip(seq[0:f - s], xk[s:f])])
                ak += res[0]
                ind += res[2] + save
            else:
                ind += t
        if result:
            return (ak, xk, ind)
        return None
    syms = f.free_symbols.difference({x})
    f, symb = expand(f).as_independent(*syms)
    result = None
    k = Dummy('k')
    if rational:
        result = rational_algorithm(f, x, k, order, full)
    if result is None and hyper:
        result = hyper_algorithm(f, x, k, order)
    if result is None:
        return None
    from sympy.simplify.powsimp import powsimp
    if symb.is_zero:
        symb = S.One
    else:
        symb = powsimp(symb)
    ak = sequence(result[0], (k, result[2], oo))
    xk_formula = powsimp(x ** k * symb)
    xk = sequence(xk_formula, (k, 0, oo))
    ind = powsimp(result[1] * symb)
    return (ak, xk, ind)

def compute_fps(f, x, x0=0, dir=1, hyper=True, order=4, rational=True, full=False):
    f = sympify(f)
    x = sympify(x)
    if not f.has(x):
        return None
    x0 = sympify(x0)
    if dir == '+':
        dir = S.One
    elif dir == '-':
        dir = -S.One
    elif dir not in [S.One, -S.One]:
        raise ValueError("Dir must be '+' or '-'")
    else:
        dir = sympify(dir)
    return _compute_fps(f, x, x0, dir, hyper, order, rational, full)

class Coeff(Function):

    @classmethod
    def eval(cls, p, x, n):
        if p.is_polynomial(x) and n.is_integer:
            return p.coeff(x, n)

class FormalPowerSeries(SeriesBase):

    def __new__(cls, *args):
        args = map(sympify, args)
        return Expr.__new__(cls, *args)

    def __init__(self, *args):
        ak = args[4][0]
        k = ak.variables[0]
        self.ak_seq = sequence(ak.formula, (k, 1, oo))
        self.fact_seq = sequence(factorial(k), (k, 1, oo))
        self.bell_coeff_seq = self.ak_seq * self.fact_seq
        self.sign_seq = sequence((-1, 1), (k, 1, oo))

    @property
    def function(self):
        return self.args[0]

    @property
    def x(self):
        return self.args[1]

    @property
    def x0(self):
        return self.args[2]

    @property
    def dir(self):
        return self.args[3]

    @property
    def ak(self):
        return self.args[4][0]

    @property
    def xk(self):
        return self.args[4][1]

    @property
    def ind(self):
        return self.args[4][2]

    @property
    def interval(self):
        return Interval(0, oo)

    @property
    def start(self):
        return self.interval.inf

    @property
    def stop(self):
        return self.interval.sup

    @property
    def length(self):
        return oo

    @property
    def infinite(self):
        from sympy.concrete import Sum
        ak, xk = (self.ak, self.xk)
        k = ak.variables[0]
        inf_sum = Sum(ak.formula * xk.formula, (k, ak.start, ak.stop))
        return self.ind + inf_sum

    def _get_pow_x(self, term):
        xterm, pow_x = term.as_independent(self.x)[1].as_base_exp()
        if not xterm.has(self.x):
            return S.Zero
        return pow_x

    def polynomial(self, n=6):
        terms = []
        sym = self.free_symbols
        for i, t in enumerate(self):
            xp = self._get_pow_x(t)
            if xp.has(*sym):
                xp = xp.as_coeff_add(*sym)[0]
            if xp >= n:
                break
            elif xp.is_integer is True and i == n + 1:
                break
            elif t is not S.Zero:
                terms.append(t)
        return Add(*terms)

    def truncate(self, n=6):
        if n is None:
            return iter(self)
        x, x0 = (self.x, self.x0)
        pt_xk = self.xk.coeff(n)
        if x0 is S.NegativeInfinity:
            x0 = S.Infinity
        return self.polynomial(n) + Order(pt_xk, (x, x0))

    def zero_coeff(self):
        return self._eval_term(0)

    def _eval_term(self, pt):
        try:
            pt_xk = self.xk.coeff(pt)
            pt_ak = self.ak.coeff(pt).simplify()
        except IndexError:
            term = S.Zero
        else:
            term = pt_ak * pt_xk
        if self.ind:
            ind = S.Zero
            sym = self.free_symbols
            for t in Add.make_args(self.ind):
                pow_x = self._get_pow_x(t)
                if pow_x.has(*sym):
                    pow_x = pow_x.as_coeff_add(*sym)[0]
                if pt == 0 and pow_x < 1:
                    ind += t
                elif pow_x >= pt and pow_x < pt + 1:
                    ind += t
            term += ind
        return term.collect(self.x)

    def _eval_subs(self, old, new):
        x = self.x
        if old.has(x):
            return self

    def _eval_as_leading_term(self, x, logx, cdir):
        for t in self:
            if t is not S.Zero:
                return t

    def _eval_derivative(self, x):
        f = self.function.diff(x)
        ind = self.ind.diff(x)
        pow_xk = self._get_pow_x(self.xk.formula)
        ak = self.ak
        k = ak.variables[0]
        if ak.formula.has(x):
            form = []
            for e, c in ak.formula.args:
                temp = S.Zero
                for t in Add.make_args(e):
                    pow_x = self._get_pow_x(t)
                    temp += t * (pow_xk + pow_x)
                form.append((temp, c))
            form = Piecewise(*form)
            ak = sequence(form.subs(k, k + 1), (k, ak.start - 1, ak.stop))
        else:
            ak = sequence((ak.formula * pow_xk).subs(k, k + 1), (k, ak.start - 1, ak.stop))
        return self.func(f, self.x, self.x0, self.dir, (ak, self.xk, ind))

    def integrate(self, x=None, **kwargs):
        from sympy.integrals import integrate
        if x is None:
            x = self.x
        elif iterable(x):
            return integrate(self.function, x)
        f = integrate(self.function, x)
        ind = integrate(self.ind, x)
        ind += (f - ind).limit(x, 0)
        pow_xk = self._get_pow_x(self.xk.formula)
        ak = self.ak
        k = ak.variables[0]
        if ak.formula.has(x):
            form = []
            for e, c in ak.formula.args:
                temp = S.Zero
                for t in Add.make_args(e):
                    pow_x = self._get_pow_x(t)
                    temp += t / (pow_xk + pow_x + 1)
                form.append((temp, c))
            form = Piecewise(*form)
            ak = sequence(form.subs(k, k - 1), (k, ak.start + 1, ak.stop))
        else:
            ak = sequence((ak.formula / (pow_xk + 1)).subs(k, k - 1), (k, ak.start + 1, ak.stop))
        return self.func(f, self.x, self.x0, self.dir, (ak, self.xk, ind))

    def product(self, other, x=None, n=6):
        if n is None:
            return iter(self)
        other = sympify(other)
        if not isinstance(other, FormalPowerSeries):
            raise ValueError('Both series should be an instance of FormalPowerSeries class.')
        if self.dir != other.dir:
            raise ValueError('Both series should be calculated from the same direction.')
        elif self.x0 != other.x0:
            raise ValueError('Both series should be calculated about the same point.')
        elif self.x != other.x:
            raise ValueError('Both series should have the same symbol.')
        return FormalPowerSeriesProduct(self, other)

    def coeff_bell(self, n):
        inner_coeffs = [bell(n, j, tuple(self.bell_coeff_seq[:n - j + 1])) for j in range(1, n + 1)]
        k = Dummy('k')
        return sequence(tuple(inner_coeffs), (k, 1, oo))

    def compose(self, other, x=None, n=6):
        if n is None:
            return iter(self)
        other = sympify(other)
        if not isinstance(other, FormalPowerSeries):
            raise ValueError('Both series should be an instance of FormalPowerSeries class.')
        if self.dir != other.dir:
            raise ValueError('Both series should be calculated from the same direction.')
        elif self.x0 != other.x0:
            raise ValueError('Both series should be calculated about the same point.')
        elif self.x != other.x:
            raise ValueError('Both series should have the same symbol.')
        if other._eval_term(0).as_coeff_mul(other.x)[0] is not S.Zero:
            raise ValueError('The formal power series of the inner function should not have any constant coefficient term.')
        return FormalPowerSeriesCompose(self, other)

    def inverse(self, x=None, n=6):
        if n is None:
            return iter(self)
        if self._eval_term(0).is_zero:
            raise ValueError('Constant coefficient should exist for an inverse of a formal power series to exist.')
        return FormalPowerSeriesInverse(self)

    def __add__(self, other):
        other = sympify(other)
        if isinstance(other, FormalPowerSeries):
            if self.dir != other.dir:
                raise ValueError('Both series should be calculated from the same direction.')
            elif self.x0 != other.x0:
                raise ValueError('Both series should be calculated about the same point.')
            x, y = (self.x, other.x)
            f = self.function + other.function.subs(y, x)
            if self.x not in f.free_symbols:
                return f
            ak = self.ak + other.ak
            if self.ak.start > other.ak.start:
                seq = other.ak
                s, e = (other.ak.start, self.ak.start)
            else:
                seq = self.ak
                s, e = (self.ak.start, other.ak.start)
            save = Add(*[z[0] * z[1] for z in zip(seq[0:e - s], self.xk[s:e])])
            ind = self.ind + other.ind + save
            return self.func(f, x, self.x0, self.dir, (ak, self.xk, ind))
        elif not other.has(self.x):
            f = self.function + other
            ind = self.ind + other
            return self.func(f, self.x, self.x0, self.dir, (self.ak, self.xk, ind))
        return Add(self, other)

    def __radd__(self, other):
        return self.__add__(other)

    def __neg__(self):
        return self.func(-self.function, self.x, self.x0, self.dir, (-self.ak, self.xk, -self.ind))

    def __sub__(self, other):
        return self.__add__(-other)

    def __rsub__(self, other):
        return (-self).__add__(other)

    def __mul__(self, other):
        other = sympify(other)
        if other.has(self.x):
            return Mul(self, other)
        f = self.function * other
        ak = self.ak.coeff_mul(other)
        ind = self.ind * other
        return self.func(f, self.x, self.x0, self.dir, (ak, self.xk, ind))

    def __rmul__(self, other):
        return self.__mul__(other)

class FiniteFormalPowerSeries(FormalPowerSeries):

    def __init__(self, *args):
        pass

    @property
    def ffps(self):
        return self.args[0]

    @property
    def gfps(self):
        return self.args[1]

    @property
    def f(self):
        return self.ffps.function

    @property
    def g(self):
        return self.gfps.function

    @property
    def infinite(self):
        raise NotImplementedError('No infinite version for an object of FiniteFormalPowerSeries class.')

    def _eval_terms(self, n):
        raise NotImplementedError('(%s)._eval_terms()' % self)

    def _eval_term(self, pt):
        raise NotImplementedError('By the current logic, one can get termsupto a certain order, instead of getting term by term.')

    def polynomial(self, n):
        return self._eval_terms(n)

    def truncate(self, n=6):
        ffps = self.ffps
        pt_xk = ffps.xk.coeff(n)
        x, x0 = (ffps.x, ffps.x0)
        return self.polynomial(n) + Order(pt_xk, (x, x0))

    def _eval_derivative(self, x):
        raise NotImplementedError

    def integrate(self, x):
        raise NotImplementedError

class FormalPowerSeriesProduct(FiniteFormalPowerSeries):

    def __init__(self, *args):
        ffps, gfps = (self.ffps, self.gfps)
        k = ffps.ak.variables[0]
        self.coeff1 = sequence(ffps.ak.formula, (k, 0, oo))
        k = gfps.ak.variables[0]
        self.coeff2 = sequence(gfps.ak.formula, (k, 0, oo))

    @property
    def function(self):
        return self.f * self.g

    def _eval_terms(self, n):
        coeff1, coeff2 = (self.coeff1, self.coeff2)
        aks = convolution(coeff1[:n], coeff2[:n])
        terms = []
        for i in range(0, n):
            terms.append(aks[i] * self.ffps.xk.coeff(i))
        return Add(*terms)

class FormalPowerSeriesCompose(FiniteFormalPowerSeries):

    @property
    def function(self):
        f, g, x = (self.f, self.g, self.ffps.x)
        return f.subs(x, g)

    def _eval_terms(self, n):
        ffps, gfps = (self.ffps, self.gfps)
        terms = [ffps.zero_coeff()]
        for i in range(1, n):
            bell_seq = gfps.coeff_bell(i)
            seq = ffps.bell_coeff_seq * bell_seq
            terms.append(Add(*seq[:i]) / ffps.fact_seq[i - 1] * ffps.xk.coeff(i))
        return Add(*terms)

class FormalPowerSeriesInverse(FiniteFormalPowerSeries):

    def __init__(self, *args):
        ffps = self.ffps
        k = ffps.xk.variables[0]
        inv = ffps.zero_coeff()
        inv_seq = sequence(inv ** (-(k + 1)), (k, 1, oo))
        self.aux_seq = ffps.sign_seq * ffps.fact_seq * inv_seq

    @property
    def function(self):
        f = self.f
        return 1 / f

    @property
    def g(self):
        raise ValueError('Only one function is considered while performinginverse of a formal power series.')

    @property
    def gfps(self):
        raise ValueError('Only one function is considered while performinginverse of a formal power series.')

    def _eval_terms(self, n):
        ffps = self.ffps
        terms = [ffps.zero_coeff()]
        for i in range(1, n):
            bell_seq = ffps.coeff_bell(i)
            seq = self.aux_seq * bell_seq
            terms.append(Add(*seq[:i]) / ffps.fact_seq[i - 1] * ffps.xk.coeff(i))
        return Add(*terms)

def fps(f, x=None, x0=0, dir=1, hyper=True, order=4, rational=True, full=False):
    f = sympify(f)
    if x is None:
        free = f.free_symbols
        if len(free) == 1:
            x = free.pop()
        elif not free:
            return f
        else:
            raise NotImplementedError('multivariate formal power series')
    result = compute_fps(f, x, x0, dir, hyper, order, rational, full)
    if result is None:
        return f
    return FormalPowerSeries(f, x, x0, dir, result)