from __future__ import annotations
from sympy.core.expr import Expr
from sympy.core.singleton import S
from sympy.core.cache import cacheit

class SeriesBase(Expr):

    @property
    def interval(self):
        raise NotImplementedError('(%s).interval' % self)

    @property
    def start(self):
        raise NotImplementedError('(%s).start' % self)

    @property
    def stop(self):
        raise NotImplementedError('(%s).stop' % self)

    @property
    def length(self):
        raise NotImplementedError('(%s).length' % self)

    @property
    def variables(self):
        return ()

    @property
    def free_symbols(self):
        return {j for i in self.args for j in i.free_symbols}.difference(self.variables)

    @cacheit
    def term(self, pt):
        if pt < self.start or pt > self.stop:
            raise IndexError('Index %s out of bounds %s' % (pt, self.interval))
        return self._eval_term(pt)

    def _eval_term(self, pt):
        raise NotImplementedError("The _eval_term method should be added to%s to return series term so it is availablewhen 'term' calls it." % self.func)

    def _ith_point(self, i):
        if self.start is S.NegativeInfinity:
            initial = self.stop
            step = -1
        else:
            initial = self.start
            step = 1
        return initial + i * step

    def __iter__(self):
        i = 0
        while i < self.length:
            pt = self._ith_point(i)
            yield self.term(pt)
            i += 1

    def __getitem__(self, index):
        if isinstance(index, int):
            index = self._ith_point(index)
            return self.term(index)
        elif isinstance(index, slice):
            start, stop = (index.start, index.stop)
            if start is None:
                start = 0
            if stop is None:
                stop = self.length
            return [self.term(self._ith_point(i)) for i in range(start, stop, index.step or 1)]