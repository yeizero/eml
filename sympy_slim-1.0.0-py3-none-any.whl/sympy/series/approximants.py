from __future__ import annotations
from sympy.core.singleton import S
from sympy.core.symbol import Symbol
from sympy.polys.polytools import lcm
from sympy.utilities import public
from sympy import Poly
from sympy.polys.polytools import gcdex_steps
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from sympy.core.expr import Expr
    from collections.abc import Iterator

@public
def approximants(l, X=Symbol('x'), simplify=False):
    from sympy.simplify import simplify as simp
    from sympy.simplify.radsimp import denom
    p1, q1 = ([S.One], [S.Zero])
    p2, q2 = ([S.Zero], [S.One])
    while len(l):
        b = 0
        while l[b] == 0:
            b += 1
            if b == len(l):
                return
        m = [S.One / l[b]]
        for k in range(b + 1, len(l)):
            s = 0
            for j in range(b, k):
                s -= l[j + 1] * m[b - j - 1]
            m.append(s / l[b])
        l = m
        a, l[0] = (l[0], 0)
        p = [0] * max(len(p2), b + len(p1))
        q = [0] * max(len(q2), b + len(q1))
        for k in range(len(p2)):
            p[k] = a * p2[k]
        for k in range(b, b + len(p1)):
            p[k] += p1[k - b]
        for k in range(len(q2)):
            q[k] = a * q2[k]
        for k in range(b, b + len(q1)):
            q[k] += q1[k - b]
        while p[-1] == 0:
            p.pop()
        while q[-1] == 0:
            q.pop()
        p1, p2 = (p2, p)
        q1, q2 = (q2, q)
        c = 1
        for x in p:
            c = lcm(c, denom(x))
        for x in q:
            c = lcm(c, denom(x))
        out = sum((c * e * X ** k for k, e in enumerate(p))) / sum((c * e * X ** k for k, e in enumerate(q)))
        if simplify:
            yield simp(out)
        else:
            yield out
    return

@public
def pade_approximants_gcdex(f: Poly, order: int) -> Iterator[tuple[Poly, Poly]]:
    if order < 0:
        raise ValueError(f'order={order!r} must be a non-negative integer.')
    if not f.is_univariate:
        raise ValueError(f'f={f!r} must be a univariate polynomial.')
    if f.degree() > order:
        f = f.slice(0, order + 1)
    x = f.gens[0]
    remainder_monomial = Poly(x ** (order + 1), x)
    euclidean_algorithm_steps = gcdex_steps(remainder_monomial, f, gens=x)
    for _, t, r in euclidean_algorithm_steps:
        yield (r, t)

@public
def pade_approximant_gcdex(f: Poly, m: int, n: int | None=None) -> tuple[Poly, Poly]:
    if n is None:
        n = m
    if m < 0 or n < 0:
        raise ValueError(f'm={m!r} and n={n!r} must be non-negative integers.')
    if not f.is_univariate:
        raise ValueError(f'f={f!r} must be a univariate polynomial.')
    min_degree = f.EM()[0]
    if min_degree > m:
        raise ValueError(f'polynomial f={f!r} has zero of order {min_degree}, which is greater than {m}, the requested order of the numerator.')
    approximants = pade_approximants_gcdex(f, order=m + n)
    numerator, denominator = next(approximants)
    for next_numerator, next_denominator in approximants:
        if next_numerator.degree() < m:
            return (numerator, denominator)
        numerator, denominator = (next_numerator, next_denominator)
    return (numerator, denominator)

@public
def pade_approximant(f: Expr, x: Expr, x0: Expr | complex=0, m: int=6, n: int | None=None) -> Expr:
    if n is None:
        n = m
    if m < 0 or n < 0:
        raise ValueError(f'm={m!r} and n={n!r} must be non-negative integers')
    f_taylor_poly = f.subs(x, x + x0).series(x, n=m + n + 1).removeO().as_poly(gens=(x, 1 / x), field=True)
    if f_taylor_poly is None:
        raise ValueError(f'f={f!r} does not have a laurent expansion in x around x0.')
    highest_order_pole = f_taylor_poly.degree(gen=1 / x)
    if n < highest_order_pole:
        raise ValueError(f'Expression f={f!r} has pole of order {highest_order_pole}, which is greater than {n}, the requested order of the denominator.')
    f_taylor_poly = (f_taylor_poly * x ** highest_order_pole).as_poly(gens=x, field=True)
    numerator, denominator = pade_approximant_gcdex(f_taylor_poly, m, n - highest_order_pole)
    return (x ** (-highest_order_pole) * (numerator / denominator)).subs(x, x - x0)