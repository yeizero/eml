from __future__ import annotations
from sympy.core.sympify import sympify

def aseries(expr, x=None, n=6, bound=0, hir=False):
    expr = sympify(expr)
    return expr.aseries(x, n, bound, hir)