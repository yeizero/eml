from __future__ import annotations

def finite_diff(expression, variable, increment=1):
    expression = expression.expand()
    expression2 = expression.subs(variable, variable + increment)
    expression2 = expression2.expand()
    return expression2 - expression

def finite_diff_kauers(sum):
    function = sum.function
    for l in sum.limits:
        function = function.subs(l[0], l[-1] + 1)
    return function