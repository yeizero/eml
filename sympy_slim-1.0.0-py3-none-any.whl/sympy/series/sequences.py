from __future__ import annotations
from sympy.core.basic import Basic
from sympy.core.cache import cacheit
from sympy.core.containers import Tuple
from sympy.core.decorators import call_highest_priority
from sympy.core.parameters import global_parameters
from sympy.core.function import AppliedUndef, expand
from sympy.core.mul import Mul
from sympy.core.numbers import Integer
from sympy.core.relational import Eq
from sympy.core.singleton import S, Singleton
from sympy.core.sorting import ordered
from sympy.core.symbol import Dummy, Symbol, Wild
from sympy.core.sympify import sympify
from sympy.matrices import Matrix
from sympy.polys import lcm, factor
from sympy.sets.sets import Interval, Intersection
from sympy.tensor.indexed import Idx
from sympy.utilities.iterables import flatten, is_sequence, iterable

class SeqBase(Basic):
    is_commutative = True
    _op_priority = 15

    @staticmethod
    def _start_key(expr):
        try:
            start = expr.start
        except NotImplementedError:
            start = S.Infinity
        return start

    def _intersect_interval(self, other):
        interval = Intersection(self.interval, other.interval)
        return (interval.inf, interval.sup)

    @property
    def gen(self):
        raise NotImplementedError('(%s).gen' % self)

    @property
    def interval(self):
        raise NotImplementedError('(%s).interval' % self)

    @property
    def start(self):
        raise NotImplementedError('(%s).start' % self)

    @property
    def stop(self):
        raise NotImplementedError('(%s).stop' % self)

    @property
    def length(self):
        raise NotImplementedError('(%s).length' % self)

    @property
    def variables(self):
        return ()

    @property
    def free_symbols(self):
        return {j for i in self.args for j in i.free_symbols.difference(self.variables)}

    @cacheit
    def coeff(self, pt):
        if pt < self.start or pt > self.stop:
            raise IndexError('Index %s out of bounds %s' % (pt, self.interval))
        return self._eval_coeff(pt)

    def _eval_coeff(self, pt):
        raise NotImplementedError('The _eval_coeff method should be added to%s to return coefficient so it is availablewhen coeff calls it.' % self.func)

    def _ith_point(self, i):
        if self.start is S.NegativeInfinity:
            initial = self.stop
        else:
            initial = self.start
        if self.start is S.NegativeInfinity:
            step = -1
        else:
            step = 1
        return initial + i * step

    def _add(self, other):
        return None

    def _mul(self, other):
        return None

    def coeff_mul(self, other):
        return Mul(self, other)

    def __add__(self, other):
        if not isinstance(other, SeqBase):
            raise TypeError('cannot add sequence and %s' % type(other))
        return SeqAdd(self, other)

    @call_highest_priority('__add__')
    def __radd__(self, other):
        return self + other

    def __sub__(self, other):
        if not isinstance(other, SeqBase):
            raise TypeError('cannot subtract sequence and %s' % type(other))
        return SeqAdd(self, -other)

    @call_highest_priority('__sub__')
    def __rsub__(self, other):
        return -self + other

    def __neg__(self):
        return self.coeff_mul(-1)

    def __mul__(self, other):
        if not isinstance(other, SeqBase):
            raise TypeError('cannot multiply sequence and %s' % type(other))
        return SeqMul(self, other)

    @call_highest_priority('__mul__')
    def __rmul__(self, other):
        return self * other

    def __iter__(self):
        for i in range(self.length):
            pt = self._ith_point(i)
            yield self.coeff(pt)

    def __getitem__(self, index):
        if isinstance(index, int):
            index = self._ith_point(index)
            return self.coeff(index)
        elif isinstance(index, slice):
            start, stop = (index.start, index.stop)
            if start is None:
                start = 0
            if stop is None:
                stop = self.length
            return [self.coeff(self._ith_point(i)) for i in range(start, stop, index.step or 1)]

    def find_linear_recurrence(self, n, d=None, gfvar=None):
        from sympy.simplify import simplify
        x = [simplify(expand(t)) for t in self[:n]]
        lx = len(x)
        if d is None:
            r = lx // 2
        else:
            r = min(d, lx // 2)
        coeffs = []
        for l in range(1, r + 1):
            l2 = 2 * l
            mlist = []
            for k in range(l):
                mlist.append(x[k:k + l])
            m = Matrix(mlist)
            if m.det() != 0:
                y = simplify(m.LUsolve(Matrix(x[l:l2])))
                if lx == l2:
                    coeffs = flatten(y[::-1])
                    break
                mlist = []
                for k in range(l, lx - l):
                    mlist.append(x[k:k + l])
                m = Matrix(mlist)
                if m * y == Matrix(x[l2:]):
                    coeffs = flatten(y[::-1])
                    break
        if gfvar is None:
            return coeffs
        else:
            l = len(coeffs)
            if l == 0:
                return ([], None)
            else:
                n, d = (x[l - 1] * gfvar ** (l - 1), 1 - coeffs[l - 1] * gfvar ** l)
                for i in range(l - 1):
                    n += x[i] * gfvar ** i
                    for j in range(l - i - 1):
                        n -= coeffs[i] * x[j] * gfvar ** (i + j + 1)
                    d -= coeffs[i] * gfvar ** (i + 1)
                return (coeffs, simplify(factor(n) / factor(d)))

class EmptySequence(SeqBase, metaclass=Singleton):

    @property
    def interval(self):
        return S.EmptySet

    @property
    def length(self):
        return S.Zero

    def coeff_mul(self, coeff):
        return self

    def __iter__(self):
        return iter([])

class SeqExpr(SeqBase):

    @property
    def gen(self):
        return self.args[0]

    @property
    def interval(self):
        return Interval(self.args[1][1], self.args[1][2])

    @property
    def start(self):
        return self.interval.inf

    @property
    def stop(self):
        return self.interval.sup

    @property
    def length(self):
        return self.stop - self.start + 1

    @property
    def variables(self):
        return (self.args[1][0],)

class SeqPer(SeqExpr):

    def __new__(cls, periodical, limits=None):
        periodical = sympify(periodical)

        def _find_x(periodical):
            free = periodical.free_symbols
            if len(periodical.free_symbols) == 1:
                return free.pop()
            else:
                return Dummy('k')
        x, start, stop = (None, None, None)
        if limits is None:
            x, start, stop = (_find_x(periodical), 0, S.Infinity)
        if is_sequence(limits, Tuple):
            if len(limits) == 3:
                x, start, stop = limits
            elif len(limits) == 2:
                x = _find_x(periodical)
                start, stop = limits
        if not isinstance(x, (Symbol, Idx)) or start is None or stop is None:
            raise ValueError('Invalid limits given: %s' % str(limits))
        if start is S.NegativeInfinity and stop is S.Infinity:
            raise ValueError('Both the start and end valuecannot be unbounded')
        limits = sympify((x, start, stop))
        if is_sequence(periodical, Tuple):
            periodical = sympify(tuple(flatten(periodical)))
        else:
            raise ValueError('invalid period %s should be something like e.g (1, 2) ' % periodical)
        if Interval(limits[1], limits[2]) is S.EmptySet:
            return S.EmptySequence
        return Basic.__new__(cls, periodical, limits)

    @property
    def period(self):
        return len(self.gen)

    @property
    def periodical(self):
        return self.gen

    def _eval_coeff(self, pt):
        if self.start is S.NegativeInfinity:
            idx = (self.stop - pt) % self.period
        else:
            idx = (pt - self.start) % self.period
        return self.periodical[idx].subs(self.variables[0], pt)

    def _add(self, other):
        if isinstance(other, SeqPer):
            return self._combine_periodic(other, lambda a, b: a + b)

    def _mul(self, other):
        if isinstance(other, SeqPer):
            return self._combine_periodic(other, lambda a, b: a * b)

    def _combine_periodic(self, other, op):
        per1, lper1 = (self.periodical, self.period)
        per2, lper2 = (other.periodical, other.period)
        per_length = int(lcm(lper1, lper2))
        start, stop = self._intersect_interval(other)
        align_to_stop = start is S.NegativeInfinity

        def _as_int(expr):
            expr = sympify(expr)
            if expr in (S.Infinity, S.NegativeInfinity):
                return None
            if expr.is_integer is not True:
                return None
            try:
                return int(expr)
            except (TypeError, ValueError):
                return None

        def _shift(seq):
            if align_to_stop:
                if seq.start is S.NegativeInfinity:
                    shift_expr = seq.stop - stop
                    direction = 1
                else:
                    shift_expr = stop - seq.start
                    direction = -1
            elif seq.start is S.NegativeInfinity:
                shift_expr = seq.stop - start
                direction = -1
            else:
                shift_expr = start - seq.start
                direction = 1
            shift_int = _as_int(shift_expr)
            return (shift_int, direction)
        shift1, dir1 = _shift(self)
        shift2, dir2 = _shift(other)
        if shift1 is None or shift2 is None:
            return None
        v1 = self.variables[0]
        v2 = other.variables[0]
        if v1 != v2:
            per2 = [p.subs(v2, v1) for p in per2]
        new_per = []
        for x in range(per_length):
            idx1 = (shift1 + dir1 * x) % lper1
            idx2 = (shift2 + dir2 * x) % lper2
            new_per.append(op(per1[idx1], per2[idx2]))
        return SeqPer(new_per, (v1, start, stop))

    def coeff_mul(self, coeff):
        coeff = sympify(coeff)
        per = [x * coeff for x in self.periodical]
        return SeqPer(per, self.args[1])

class SeqFormula(SeqExpr):

    def __new__(cls, formula, limits=None):
        formula = sympify(formula)

        def _find_x(formula):
            free = formula.free_symbols
            if len(free) == 1:
                return free.pop()
            elif not free:
                return Dummy('k')
            else:
                raise ValueError(' specify dummy variables for %s. If the formula contains more than one free symbol, a dummy variable should be supplied explicitly e.g., SeqFormula(m*n**2, (n, 0, 5))' % formula)
        x, start, stop = (None, None, None)
        if limits is None:
            x, start, stop = (_find_x(formula), 0, S.Infinity)
        if is_sequence(limits, Tuple):
            if len(limits) == 3:
                x, start, stop = limits
            elif len(limits) == 2:
                x = _find_x(formula)
                start, stop = limits
        if not isinstance(x, (Symbol, Idx)) or start is None or stop is None:
            raise ValueError('Invalid limits given: %s' % str(limits))
        if start is S.NegativeInfinity and stop is S.Infinity:
            raise ValueError('Both the start and end value cannot be unbounded')
        limits = sympify((x, start, stop))
        if Interval(limits[1], limits[2]) is S.EmptySet:
            return S.EmptySequence
        return Basic.__new__(cls, formula, limits)

    @property
    def formula(self):
        return self.gen

    def _eval_coeff(self, pt):
        d = self.variables[0]
        return self.formula.subs(d, pt)

    def _add(self, other):
        if isinstance(other, SeqFormula):
            form1, v1 = (self.formula, self.variables[0])
            form2, v2 = (other.formula, other.variables[0])
            formula = form1 + form2.subs(v2, v1)
            start, stop = self._intersect_interval(other)
            return SeqFormula(formula, (v1, start, stop))

    def _mul(self, other):
        if isinstance(other, SeqFormula):
            form1, v1 = (self.formula, self.variables[0])
            form2, v2 = (other.formula, other.variables[0])
            formula = form1 * form2.subs(v2, v1)
            start, stop = self._intersect_interval(other)
            return SeqFormula(formula, (v1, start, stop))

    def coeff_mul(self, coeff):
        coeff = sympify(coeff)
        formula = self.formula * coeff
        return SeqFormula(formula, self.args[1])

    def expand(self, *args, **kwargs):
        return SeqFormula(expand(self.formula, *args, **kwargs), self.args[1])

class RecursiveSeq(SeqBase):

    def __new__(cls, recurrence, yn, n, initial=None, start=0):
        if not isinstance(yn, AppliedUndef):
            raise TypeError('recurrence sequence must be an applied undefined function, found `{}`'.format(yn))
        if not isinstance(n, Basic) or not n.is_symbol:
            raise TypeError('recurrence variable must be a symbol, found `{}`'.format(n))
        if yn.args != (n,):
            raise TypeError('recurrence sequence does not match symbol')
        y = yn.func
        k = Wild('k', exclude=(n,))
        degree = 0
        prev_ys = recurrence.find(y)
        for prev_y in prev_ys:
            if len(prev_y.args) != 1:
                raise TypeError('Recurrence should be in a single variable')
            shift = prev_y.args[0].match(n + k)[k]
            if not (shift.is_constant() and shift.is_integer and (shift < 0)):
                raise TypeError('Recurrence should have constant, negative, integer shifts (found {})'.format(prev_y))
            if -shift > degree:
                degree = -shift
        if not initial:
            initial = [Dummy('c_{}'.format(k)) for k in range(degree)]
        if len(initial) != degree:
            raise ValueError('Number of initial terms must equal degree')
        degree = Integer(degree)
        start = sympify(start)
        initial = Tuple(*(sympify(x) for x in initial))
        seq = Basic.__new__(cls, recurrence, yn, n, initial, start)
        seq.cache = {y(start + k): init for k, init in enumerate(initial)}
        seq.degree = degree
        return seq

    @property
    def _recurrence(self):
        return self.args[0]

    @property
    def recurrence(self):
        return Eq(self.yn, self.args[0])

    @property
    def yn(self):
        return self.args[1]

    @property
    def y(self):
        return self.yn.func

    @property
    def n(self):
        return self.args[2]

    @property
    def initial(self):
        return self.args[3]

    @property
    def start(self):
        return self.args[4]

    @property
    def stop(self):
        return S.Infinity

    @property
    def interval(self):
        return Interval(self.start, S.Infinity)

    def _eval_coeff(self, index):
        if index - self.start < len(self.cache):
            return self.cache[self.y(index)]
        for current in range(len(self.cache), index + 1):
            seq_index = self.start + current
            current_recurrence = self._recurrence.xreplace({self.n: seq_index})
            new_term = current_recurrence.xreplace(self.cache)
            self.cache[self.y(seq_index)] = new_term
        return self.cache[self.y(self.start + current)]

    def __iter__(self):
        index = self.start
        while True:
            yield self._eval_coeff(index)
            index += 1

def sequence(seq, limits=None):
    seq = sympify(seq)
    if is_sequence(seq, Tuple):
        return SeqPer(seq, limits)
    else:
        return SeqFormula(seq, limits)

class SeqExprOp(SeqBase):

    @property
    def gen(self):
        return tuple((a.gen for a in self.args))

    @property
    def interval(self):
        return Intersection(*(a.interval for a in self.args))

    @property
    def start(self):
        return self.interval.inf

    @property
    def stop(self):
        return self.interval.sup

    @property
    def variables(self):
        return tuple(flatten([a.variables for a in self.args]))

    @property
    def length(self):
        return self.stop - self.start + 1

class SeqAdd(SeqExprOp):

    def __new__(cls, *args, **kwargs):
        evaluate = kwargs.get('evaluate', global_parameters.evaluate)
        args = list(args)

        def _flatten(arg):
            if isinstance(arg, SeqBase):
                if isinstance(arg, SeqAdd):
                    return sum(map(_flatten, arg.args), [])
                else:
                    return [arg]
            if iterable(arg):
                return sum(map(_flatten, arg), [])
            raise TypeError('Input must be Sequences or  iterables of Sequences')
        args = _flatten(args)
        args = [a for a in args if a is not S.EmptySequence]
        if not args:
            return S.EmptySequence
        if Intersection(*(a.interval for a in args)) is S.EmptySet:
            return S.EmptySequence
        if evaluate:
            return SeqAdd.reduce(args)
        args = list(ordered(args, SeqBase._start_key))
        return Basic.__new__(cls, *args)

    @staticmethod
    def reduce(args):
        new_args = True
        while new_args:
            for id1, s in enumerate(args):
                new_args = False
                for id2, t in enumerate(args):
                    if id1 == id2:
                        continue
                    new_seq = s._add(t)
                    if new_seq is not None:
                        new_args = [a for a in args if a not in (s, t)]
                        new_args.append(new_seq)
                        break
                if new_args:
                    args = new_args
                    break
        if len(args) == 1:
            return args.pop()
        else:
            return SeqAdd(args, evaluate=False)

    def _eval_coeff(self, pt):
        return sum((a.coeff(pt) for a in self.args))

class SeqMul(SeqExprOp):

    def __new__(cls, *args, **kwargs):
        evaluate = kwargs.get('evaluate', global_parameters.evaluate)
        args = list(args)

        def _flatten(arg):
            if isinstance(arg, SeqBase):
                if isinstance(arg, SeqMul):
                    return sum(map(_flatten, arg.args), [])
                else:
                    return [arg]
            elif iterable(arg):
                return sum(map(_flatten, arg), [])
            raise TypeError('Input must be Sequences or  iterables of Sequences')
        args = _flatten(args)
        if not args:
            return S.EmptySequence
        if Intersection(*(a.interval for a in args)) is S.EmptySet:
            return S.EmptySequence
        if evaluate:
            return SeqMul.reduce(args)
        args = list(ordered(args, SeqBase._start_key))
        return Basic.__new__(cls, *args)

    @staticmethod
    def reduce(args):
        new_args = True
        while new_args:
            for id1, s in enumerate(args):
                new_args = False
                for id2, t in enumerate(args):
                    if id1 == id2:
                        continue
                    new_seq = s._mul(t)
                    if new_seq is not None:
                        new_args = [a for a in args if a not in (s, t)]
                        new_args.append(new_seq)
                        break
                if new_args:
                    args = new_args
                    break
        if len(args) == 1:
            return args.pop()
        else:
            return SeqMul(args, evaluate=False)

    def _eval_coeff(self, pt):
        val = 1
        for a in self.args:
            val *= a.coeff(pt)
        return val