from __future__ import annotations
from functools import reduce
from sympy.core import Basic, S, Mul, PoleError
from sympy.core.cache import cacheit
from sympy.core.function import AppliedUndef
from sympy.core.intfunc import ilcm
from sympy.core.numbers import I, oo
from sympy.core.symbol import Dummy, Wild
from sympy.core.traversal import bottom_up
from sympy.functions import log, exp, sign as _sign
from sympy.series.order import Order
from sympy.utilities.misc import debug_decorator as debug
from sympy.utilities.timeutils import timethis
timeit = timethis('gruntz')

def compare(a, b, x):
    la, lb = (log(a), log(b))
    if isinstance(a, Basic) and (isinstance(a, exp) or (a.is_Pow and a.base == S.Exp1)):
        la = a.exp
    if isinstance(b, Basic) and (isinstance(b, exp) or (b.is_Pow and b.base == S.Exp1)):
        lb = b.exp
    c = limitinf(la / lb, x)
    if c == 0:
        return '<'
    elif c.is_infinite:
        return '>'
    else:
        return '='

class SubsSet(dict):

    def __init__(self):
        self.rewrites = {}

    def __repr__(self):
        return super().__repr__() + ', ' + self.rewrites.__repr__()

    def __getitem__(self, key):
        if key not in self:
            self[key] = Dummy()
        return dict.__getitem__(self, key)

    def do_subs(self, e):
        for expr, var in self.items():
            e = e.xreplace({var: expr})
        return e

    def meets(self, s2):
        return set(self.keys()).intersection(list(s2.keys())) != set()

    def union(self, s2, exps=None):
        res = self.copy()
        tr = {}
        for expr, var in s2.items():
            if expr in self:
                if exps:
                    exps = exps.xreplace({var: res[expr]})
                tr[var] = res[expr]
            else:
                res[expr] = var
        for var, rewr in s2.rewrites.items():
            res.rewrites[var] = rewr.xreplace(tr)
        return (res, exps)

    def copy(self):
        r = SubsSet()
        r.rewrites = self.rewrites.copy()
        for expr, var in self.items():
            r[expr] = var
        return r

@debug
def mrv(e, x):
    from sympy.simplify.powsimp import powsimp
    e = powsimp(e, deep=True, combine='exp')
    if not isinstance(e, Basic):
        raise TypeError('e should be an instance of Basic')
    if not e.has(x):
        return (SubsSet(), e)
    elif e == x:
        s = SubsSet()
        return (s, s[x])
    elif e.is_Mul or e.is_Add:
        i, d = e.as_independent(x)
        if d.func != e.func:
            s, expr = mrv(d, x)
            return (s, e.func(i, expr))
        a, b = d.as_two_terms()
        s1, e1 = mrv(a, x)
        s2, e2 = mrv(b, x)
        return mrv_max1(s1, s2, e.func(i, e1, e2), x)
    elif e.is_Pow and e.base != S.Exp1:
        e1 = S.One
        while e.is_Pow:
            b1 = e.base
            e1 *= e.exp
            e = b1
        if b1 == 1:
            return (SubsSet(), b1)
        if e1.has(x):
            return mrv(exp(e1 * log(b1)), x)
        else:
            s, expr = mrv(b1, x)
            return (s, expr ** e1)
    elif isinstance(e, log):
        s, expr = mrv(e.args[0], x)
        return (s, log(expr))
    elif isinstance(e, exp) or (e.is_Pow and e.base == S.Exp1):
        if isinstance(e.exp, log):
            return mrv(e.exp.args[0], x)
        li = limitinf(e.exp, x)
        if any((_.is_infinite for _ in Mul.make_args(li))):
            s1 = SubsSet()
            e1 = s1[e]
            s2, e2 = mrv(e.exp, x)
            su = s1.union(s2)[0]
            su.rewrites[e1] = exp(e2)
            return mrv_max3(s1, e1, s2, exp(e2), su, e1, x)
        else:
            s, expr = mrv(e.exp, x)
            return (s, exp(expr))
    elif isinstance(e, AppliedUndef):
        raise ValueError('MRV set computation for UndefinedFunction is not allowed')
    elif e.is_Function:
        l = [mrv(a, x) for a in e.args]
        l2 = [s for s, _ in l if s != SubsSet()]
        if len(l2) != 1:
            raise NotImplementedError('MRV set computation for functions in several variables not implemented.')
        s, ss = (l2[0], SubsSet())
        args = [ss.do_subs(x[1]) for x in l]
        return (s, e.func(*args))
    elif e.is_Derivative:
        raise NotImplementedError('MRV set computation for derivatives not implemented yet.')
    raise NotImplementedError("Don't know how to calculate the mrv of '%s'" % e)

def mrv_max3(f, expsf, g, expsg, union, expsboth, x):
    if not isinstance(f, SubsSet):
        raise TypeError('f should be an instance of SubsSet')
    if not isinstance(g, SubsSet):
        raise TypeError('g should be an instance of SubsSet')
    if f == SubsSet():
        return (g, expsg)
    elif g == SubsSet():
        return (f, expsf)
    elif f.meets(g):
        return (union, expsboth)
    c = compare(list(f.keys())[0], list(g.keys())[0], x)
    if c == '>':
        return (f, expsf)
    elif c == '<':
        return (g, expsg)
    else:
        if c != '=':
            raise ValueError('c should be =')
        return (union, expsboth)

def mrv_max1(f, g, exps, x):
    u, b = f.union(g, exps)
    return mrv_max3(f, g.do_subs(exps), g, f.do_subs(exps), u, b, x)

@debug
@cacheit
@timeit
def sign(e, x):
    if not isinstance(e, Basic):
        raise TypeError('e should be an instance of Basic')
    if e.is_positive:
        return 1
    elif e.is_negative:
        return -1
    elif e.is_zero:
        return 0
    elif not e.has(x):
        from sympy.simplify import logcombine
        e = logcombine(e)
        return _sign(e)
    elif e == x:
        return 1
    elif e.is_Mul:
        a, b = e.as_two_terms()
        sa = sign(a, x)
        if not sa:
            return 0
        return sa * sign(b, x)
    elif isinstance(e, exp):
        return 1
    elif e.is_Pow:
        if e.base == S.Exp1:
            return 1
        s = sign(e.base, x)
        if s == 1:
            return 1
        if e.exp.is_Integer:
            return s ** e.exp
    elif isinstance(e, log) and e.args[0].is_positive:
        return sign(e.args[0] - 1, x)
    c0, e0 = mrv_leadterm(e, x)
    return sign(c0, x)

@debug
@timeit
@cacheit
def limitinf(e, x):
    old = e
    if not e.has(x):
        return e
    from sympy.simplify.powsimp import powdenest
    from sympy.calculus.util import AccumBounds
    if e.has(Order):
        e = e.expand().removeO()
    if not x.is_positive or x.is_integer:
        p = Dummy('p', positive=True)
        e = e.subs(x, p)
        x = p
    e = e.rewrite('tractable', deep=True, limitvar=x)
    e = powdenest(e)
    if isinstance(e, AccumBounds):
        if mrv_leadterm(e.min, x) != mrv_leadterm(e.max, x):
            raise NotImplementedError
        c0, e0 = mrv_leadterm(e.min, x)
    else:
        c0, e0 = mrv_leadterm(e, x)
    sig = sign(e0, x)
    if sig == 1:
        return S.Zero
    elif sig == -1:
        if c0.match(I * Wild('a', exclude=[I])):
            return c0 * oo
        s = sign(c0, x)
        if s == 0:
            raise ValueError('Leading term should not be 0')
        return s * oo
    elif sig == 0:
        if c0 == old:
            c0 = c0.cancel()
        return limitinf(c0, x)
    else:
        raise ValueError('{} could not be evaluated'.format(sig))

def moveup2(s, x):
    r = SubsSet()
    for expr, var in s.items():
        r[expr.xreplace({x: exp(x)})] = var
    for var, expr in s.rewrites.items():
        r.rewrites[var] = s.rewrites[var].xreplace({x: exp(x)})
    return r

def moveup(l, x):
    return [e.xreplace({x: exp(x)}) for e in l]

@debug
@timeit
@cacheit
def mrv_leadterm(e, x):
    Omega = SubsSet()
    if not e.has(x):
        return (e, S.Zero)
    if Omega == SubsSet():
        Omega, exps = mrv(e, x)
    if not Omega:
        return (exps, S.Zero)
    if x in Omega:
        Omega_up = moveup2(Omega, x)
        exps_up = moveup([exps], x)[0]
        Omega = Omega_up
        exps = exps_up
    w = Dummy('w', positive=True)
    f, logw = rewrite(exps, Omega, x, w)
    f = f.replace(lambda f: f.is_Pow and f.has(x), lambda f: exp(log(f.base) * f.exp))
    try:
        lt = f.leadterm(w, logx=logw)
    except (NotImplementedError, PoleError, ValueError):
        n0 = 1
        _series = Order(1)
        incr = S.One
        while _series.is_Order:
            _series = f._eval_nseries(w, n=n0 + incr, logx=logw, cdir=0)
            incr *= 2
        series = _series.expand().removeO()
        try:
            lt = series.leadterm(w, logx=logw)
        except (NotImplementedError, PoleError, ValueError):
            lt = f.as_coeff_exponent(w)
            if lt[0].has(w):
                base = f.as_base_exp()[0].as_coeff_exponent(w)
                ex = f.as_base_exp()[1]
                lt = (base[0] ** ex, base[1] * ex)
    return (lt[0].subs(log(w), logw), lt[1])

def build_expression_tree(Omega, rewrites):

    class Node:

        def __init__(self):
            self.before = []
            self.expr = None
            self.var = None

        def ht(self):
            return reduce(lambda x, y: x + y, [x.ht() for x in self.before], 1)
    nodes = {}
    for expr, v in Omega:
        n = Node()
        n.var = v
        n.expr = expr
        nodes[v] = n
    for _, v in Omega:
        if v in rewrites:
            n = nodes[v]
            r = rewrites[v]
            for _, v2 in Omega:
                if r.has(v2):
                    n.before.append(nodes[v2])
    return nodes

@debug
@timeit
def rewrite(e, Omega, x, wsym):
    from sympy import AccumBounds
    if not isinstance(Omega, SubsSet):
        raise TypeError('Omega should be an instance of SubsSet')
    if len(Omega) == 0:
        raise ValueError('Length cannot be 0')
    for t in Omega.keys():
        if not isinstance(t, exp):
            raise ValueError('Value should be exp')
    rewrites = Omega.rewrites
    Omega = list(Omega.items())
    nodes = build_expression_tree(Omega, rewrites)
    Omega.sort(key=lambda x: nodes[x[1]].ht(), reverse=True)
    for g, _ in Omega:
        sig = sign(g.exp, x)
        if sig != 1 and sig != -1 and (not sig.has(AccumBounds)):
            raise NotImplementedError('Result depends on the sign of %s' % sig)
    if sig == 1:
        wsym = 1 / wsym
    O2 = []
    denominators = []
    for f, var in Omega:
        c = limitinf(f.exp / g.exp, x)
        if c.is_Rational:
            denominators.append(c.q)
        arg = f.exp
        if var in rewrites:
            if not isinstance(rewrites[var], exp):
                raise ValueError('Value should be exp')
            arg = rewrites[var].args[0]
        O2.append((var, exp(arg - c * g.exp) * wsym ** c))
    from sympy.simplify.powsimp import powsimp
    f = powsimp(e, deep=True, combine='exp')
    for a, b in O2:
        f = f.xreplace({a: b})
    for _, var in Omega:
        assert not f.has(var)
    logw = g.exp
    if sig == 1:
        logw = -logw
    exponent = reduce(ilcm, denominators, 1)
    f = f.subs({wsym: wsym ** exponent})
    logw /= exponent
    f = bottom_up(f, lambda w: getattr(w, 'normal', lambda: w)())
    return (f, logw)

def gruntz(e, z, z0, dir='+'):
    if not z.is_symbol:
        raise NotImplementedError('Second argument must be a Symbol')
    r = None
    if z0 in (oo, I * oo):
        e0 = e
    elif z0 in (-oo, -I * oo):
        e0 = e.subs(z, -z)
    elif str(dir) == '-':
        e0 = e.subs(z, z0 - 1 / z)
    elif str(dir) == '+':
        e0 = e.subs(z, z0 + 1 / z)
    else:
        raise NotImplementedError("dir must be '+' or '-'")
    r = limitinf(e0, z)
    return r.rewrite('intractable', deep=True)