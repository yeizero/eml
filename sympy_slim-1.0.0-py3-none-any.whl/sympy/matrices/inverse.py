from __future__ import annotations
from typing import TYPE_CHECKING
from sympy.polys.matrices.exceptions import DMNonInvertibleMatrixError
from sympy.polys.domains import EX
from .exceptions import MatrixError, NonSquareMatrixError, NonInvertibleMatrixError
from .utilities import _iszero
if TYPE_CHECKING:
    from typing import TypeVar, Callable
    from sympy.core.expr import Expr
    from sympy.matrices.matrixbase import MatrixBase
    Tmat = TypeVar('Tmat', bound=MatrixBase)

def _pinv_full_rank(M):
    if M.is_zero_matrix:
        return M.H
    if M.rows >= M.cols:
        return M.H.multiply(M).inv().multiply(M.H)
    else:
        return M.H.multiply(M.multiply(M.H).inv())

def _pinv_rank_decomposition(M):
    if M.is_zero_matrix:
        return M.H
    B, C = M.rank_decomposition()
    Bp = _pinv_full_rank(B)
    Cp = _pinv_full_rank(C)
    return Cp.multiply(Bp)

def _pinv_diagonalization(M):
    if M.is_zero_matrix:
        return M.H
    A = M
    AH = M.H
    try:
        if M.rows >= M.cols:
            P, D = AH.multiply(A).diagonalize(normalize=True)
            D_pinv = D.applyfunc(lambda x: 0 if _iszero(x) else 1 / x)
            return P.multiply(D_pinv).multiply(P.H).multiply(AH)
        else:
            P, D = A.multiply(AH).diagonalize(normalize=True)
            D_pinv = D.applyfunc(lambda x: 0 if _iszero(x) else 1 / x)
            return AH.multiply(P).multiply(D_pinv).multiply(P.H)
    except MatrixError:
        raise NotImplementedError('pinv for rank-deficient matrices where diagonalization of A.H*A fails is not supported yet.')

def _pinv(M, method='RD'):
    if M.is_zero_matrix:
        return M.H
    if method == 'RD':
        return _pinv_rank_decomposition(M)
    elif method == 'ED':
        return _pinv_diagonalization(M)
    else:
        raise ValueError('invalid pinv method %s' % repr(method))

def _verify_invertible(M, iszerofunc=_iszero):
    if not M.is_square:
        raise NonSquareMatrixError('A Matrix must be square to invert.')
    d = M.det(method='berkowitz')
    zero = d.equals(0)
    if zero is None:
        ok = M.rref(simplify=True)[0]
        zero = any((iszerofunc(ok[j, j]) for j in range(ok.rows)))
    if zero:
        raise NonInvertibleMatrixError('Matrix det == 0; not invertible.')
    return d

def _inv_ADJ(M, iszerofunc=_iszero):
    d = M.det()
    if iszerofunc(d):
        raise NonInvertibleMatrixError('Matrix det == 0; not invertible.')
    return M.adjugate() / d

def _inv_GE(M, iszerofunc=_iszero):
    from .dense import Matrix
    if not M.is_square:
        raise NonSquareMatrixError('A Matrix must be square to invert.')
    big = Matrix.hstack(M.as_mutable(), Matrix.eye(M.rows))
    red = big.rref(iszerofunc=iszerofunc, simplify=True)[0]
    if any((iszerofunc(red[j, j]) for j in range(red.rows))):
        raise NonInvertibleMatrixError('Matrix det == 0; not invertible.')
    return M._new(red[:, big.rows:])

def _inv_LU(M, iszerofunc=_iszero):
    if not M.is_square:
        raise NonSquareMatrixError('A Matrix must be square to invert.')
    return M.LUsolve(M.eye(M.rows), iszerofunc=_iszero)

def _inv_CH(M, iszerofunc=_iszero):
    _verify_invertible(M, iszerofunc=iszerofunc)
    return M.cholesky_solve(M.eye(M.rows))

def _inv_LDL(M, iszerofunc=_iszero):
    _verify_invertible(M, iszerofunc=iszerofunc)
    return M.LDLsolve(M.eye(M.rows))

def _inv_QR(M, iszerofunc=_iszero):
    _verify_invertible(M, iszerofunc=iszerofunc)
    return M.QRsolve(M.eye(M.rows))

def _try_DM(M, use_EX=False):
    dM = M.to_DM()
    K = dM.domain
    if not use_EX and K.is_EXRAW:
        return None
    elif K.is_EXRAW:
        return dM.convert_to(EX)
    else:
        return dM

def _use_exact_domain(dom):
    if dom.is_RR or dom.is_CC:
        return False
    else:
        return not dom.is_Exact

def _inv_DM(dM, cancel=True):
    m, n = dM.shape
    dom = dM.domain
    if m != n:
        raise NonSquareMatrixError('A Matrix must be square to invert.')
    use_exact = _use_exact_domain(dom)
    if use_exact:
        dom_exact = dom.get_exact()
        dM = dM.convert_to(dom_exact)
    else:
        dom_exact = None
    try:
        dMi, den = dM.inv_den()
    except DMNonInvertibleMatrixError:
        raise NonInvertibleMatrixError('Matrix det == 0; not invertible.')
    if dom_exact is not None:
        dMi = dMi.convert_to(dom)
        den = dom.convert_from(den, dom_exact)
    if cancel:
        if not dMi.domain.is_Field:
            dMi = dMi.to_field()
        Mi = (dMi / den).to_Matrix()
    else:
        Mi = dMi.to_Matrix() / dMi.domain.to_sympy(den)
    return Mi

def _inv_block(M: MatrixBase, iszerofunc: Callable[[Expr], bool | None]=_iszero) -> MatrixBase:
    from sympy.matrices.expressions.blockmatrix import BlockMatrix
    i = M.shape[0]
    if i <= 20:
        return M.inv(method='LU', iszerofunc=_iszero)
    A = M[:i // 2, :i // 2]
    B = M[:i // 2, i // 2:]
    C = M[i // 2:, :i // 2]
    D = M[i // 2:, i // 2:]
    try:
        D_inv = _inv_block(D)
    except NonInvertibleMatrixError:
        return M.inv(method='LU', iszerofunc=_iszero)
    B_D_i = B * D_inv
    BDC = B_D_i * C
    A_n = A - BDC
    try:
        A_n = _inv_block(A_n)
    except NonInvertibleMatrixError:
        return M.inv(method='LU', iszerofunc=_iszero)
    B_n = -A_n * B_D_i
    dc = D_inv * C
    C_n = -dc * A_n
    D_n = D_inv + dc * -B_n
    nn = BlockMatrix([[A_n, B_n], [C_n, D_n]]).as_explicit()
    return nn

def _inv(M: Tmat, method: str | None=None, iszerofunc: Callable[[Expr], bool | None]=_iszero, try_block_diag: bool=False) -> Tmat:
    from sympy.matrices import SparseMatrix
    if not M.is_square:
        raise NonSquareMatrixError('A Matrix must be square to invert.')
    if try_block_diag:
        blocks = M.get_diag_blocks()
        r = []
        for block in blocks:
            r.append(block.inv(method=method, iszerofunc=iszerofunc))
        return M.diag(*r)
    if method is None and iszerofunc is _iszero:
        dM = _try_DM(M, use_EX=False)
    elif method in ('DM', 'DMNC'):
        dM = _try_DM(M, use_EX=True)
    else:
        dM = None
    if method is None:
        if isinstance(M, SparseMatrix):
            method = 'LDL'
        else:
            method = 'GE'
    if dM is not None:
        rv = _inv_DM(dM)
    elif method == 'DMNC':
        rv = _inv_DM(dM, cancel=False)
    elif method == 'GE':
        rv = M.inverse_GE(iszerofunc=iszerofunc)
    elif method == 'LU':
        rv = M.inverse_LU(iszerofunc=iszerofunc)
    elif method == 'ADJ':
        rv = M.inverse_ADJ(iszerofunc=iszerofunc)
    elif method == 'CH':
        rv = M.inverse_CH(iszerofunc=iszerofunc)
    elif method == 'LDL':
        rv = M.inverse_LDL(iszerofunc=iszerofunc)
    elif method == 'QR':
        rv = M.inverse_QR(iszerofunc=iszerofunc)
    elif method == 'BLOCK':
        rv = M.inverse_BLOCK(iszerofunc=iszerofunc)
    else:
        raise ValueError('Inversion method unrecognized')
    return M._new(rv)