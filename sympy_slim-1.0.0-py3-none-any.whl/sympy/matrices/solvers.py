from __future__ import annotations
from typing import TYPE_CHECKING, overload
from sympy.core.function import expand_mul
from sympy.core.symbol import Dummy, uniquely_named_symbol, symbols
from sympy.utilities.iterables import numbered_symbols
from .exceptions import ShapeError, NonSquareMatrixError, NonInvertibleMatrixError
from .eigen import _fuzzy_positive_definite
from .utilities import _get_intermediate_simp, _iszero
if TYPE_CHECKING:
    from typing import TypeVar, Literal
    from sympy.matrices.matrixbase import MatrixBase
    Tmat = TypeVar('Tmat', bound=MatrixBase)

def _diagonal_solve(M, rhs):
    if not M.is_diagonal():
        raise TypeError('Matrix should be diagonal')
    if rhs.rows != M.rows:
        raise TypeError('Size mismatch')
    return M._new(rhs.rows, rhs.cols, lambda i, j: rhs[i, j] / M[i, i])

def _lower_triangular_solve(M, rhs):
    from .dense import MutableDenseMatrix
    if not M.is_square:
        raise NonSquareMatrixError('Matrix must be square.')
    if rhs.rows != M.rows:
        raise ShapeError('Matrices size mismatch.')
    if not M.is_lower:
        raise ValueError('Matrix must be lower triangular.')
    dps = _get_intermediate_simp()
    X = MutableDenseMatrix.zeros(M.rows, rhs.cols)
    for j in range(rhs.cols):
        for i in range(M.rows):
            if M[i, i] == 0:
                raise TypeError('Matrix must be non-singular.')
            X[i, j] = dps((rhs[i, j] - sum((M[i, k] * X[k, j] for k in range(i)))) / M[i, i])
    return M._new(X)

def _lower_triangular_solve_sparse(M, rhs):
    if not M.is_square:
        raise NonSquareMatrixError('Matrix must be square.')
    if rhs.rows != M.rows:
        raise ShapeError('Matrices size mismatch.')
    if not M.is_lower:
        raise ValueError('Matrix must be lower triangular.')
    dps = _get_intermediate_simp()
    rows = [[] for i in range(M.rows)]
    for i, j, v in M.row_list():
        if i > j:
            rows[i].append((j, v))
    X = rhs.as_mutable()
    for j in range(rhs.cols):
        for i in range(rhs.rows):
            for u, v in rows[i]:
                X[i, j] -= v * X[u, j]
            X[i, j] = dps(X[i, j] / M[i, i])
    return M._new(X)

def _upper_triangular_solve(M, rhs):
    from .dense import MutableDenseMatrix
    if not M.is_square:
        raise NonSquareMatrixError('Matrix must be square.')
    if rhs.rows != M.rows:
        raise ShapeError('Matrix size mismatch.')
    if not M.is_upper:
        raise TypeError('Matrix is not upper triangular.')
    dps = _get_intermediate_simp()
    X = MutableDenseMatrix.zeros(M.rows, rhs.cols)
    for j in range(rhs.cols):
        for i in reversed(range(M.rows)):
            if M[i, i] == 0:
                raise ValueError('Matrix must be non-singular.')
            X[i, j] = dps((rhs[i, j] - sum((M[i, k] * X[k, j] for k in range(i + 1, M.rows)))) / M[i, i])
    return M._new(X)

def _upper_triangular_solve_sparse(M, rhs):
    if not M.is_square:
        raise NonSquareMatrixError('Matrix must be square.')
    if rhs.rows != M.rows:
        raise ShapeError('Matrix size mismatch.')
    if not M.is_upper:
        raise TypeError('Matrix is not upper triangular.')
    dps = _get_intermediate_simp()
    rows = [[] for i in range(M.rows)]
    for i, j, v in M.row_list():
        if i < j:
            rows[i].append((j, v))
    X = rhs.as_mutable()
    for j in range(rhs.cols):
        for i in reversed(range(rhs.rows)):
            for u, v in reversed(rows[i]):
                X[i, j] -= v * X[u, j]
            X[i, j] = dps(X[i, j] / M[i, i])
    return M._new(X)

def _cholesky_solve(M: Tmat, rhs: MatrixBase) -> Tmat:
    if M.rows < M.cols:
        raise NotImplementedError('Under-determined System. Try M.gauss_jordan_solve(rhs)')
    hermitian = True
    reform = False
    if M.is_symmetric():
        hermitian = False
    elif not M.is_hermitian:
        reform = True
    if reform or _fuzzy_positive_definite(M) is False:
        H = M.H
        M = H.multiply(M)
        rhs = H.multiply(rhs)
        hermitian = not M.is_symmetric()
    L = M.cholesky(hermitian=hermitian)
    Y = L.lower_triangular_solve(rhs)
    if hermitian:
        return L.H.upper_triangular_solve(Y)
    else:
        return L.T.upper_triangular_solve(Y)

def _LDLsolve(M: Tmat, rhs: MatrixBase) -> Tmat:
    if M.rows < M.cols:
        raise NotImplementedError('Under-determined System. Try M.gauss_jordan_solve(rhs)')
    hermitian = True
    reform = False
    if M.is_symmetric():
        hermitian = False
    elif not M.is_hermitian:
        reform = True
    if reform or _fuzzy_positive_definite(M) is False:
        H = M.H
        M = H.multiply(M)
        rhs = H.multiply(rhs)
        hermitian = not M.is_symmetric()
    L, D = M.LDLdecomposition(hermitian=hermitian)
    Y = L.lower_triangular_solve(rhs)
    Z = D.diagonal_solve(Y)
    if hermitian:
        return L.H.upper_triangular_solve(Z)
    else:
        return L.T.upper_triangular_solve(Z)

def _LUsolve(M, rhs, iszerofunc=_iszero):
    if rhs.rows != M.rows:
        raise ShapeError('``M`` and ``rhs`` must have the same number of rows.')
    m = M.rows
    n = M.cols
    if m < n:
        raise NotImplementedError('Underdetermined systems not supported.')
    try:
        A, perm = M.LUdecomposition_Simple(iszerofunc=iszerofunc, rankcheck=True)
    except ValueError:
        raise NonInvertibleMatrixError('Matrix det == 0; not invertible.')
    dps = _get_intermediate_simp()
    b = rhs.permute_rows(perm).as_mutable()
    for i in range(m):
        for j in range(min(i, n)):
            scale = A[i, j]
            b.zip_row_op(i, j, lambda x, y: dps(x - scale * y))
    if m > n:
        for i in range(n, m):
            for j in range(b.cols):
                if not iszerofunc(b[i, j]):
                    raise ValueError('The system is inconsistent.')
        b = b[0:n, :]
    for i in range(n - 1, -1, -1):
        for j in range(i + 1, n):
            scale = A[i, j]
            b.zip_row_op(i, j, lambda x, y: dps(x - scale * y))
        scale = A[i, i]
        b.row_op(i, lambda x, _: dps(scale ** (-1) * x))
    return rhs.__class__(b)

def _QRsolve(M, b):
    dps = _get_intermediate_simp(expand_mul, expand_mul)
    Q, R = M.QRdecomposition()
    y = Q.T * b
    x = []
    n = R.rows
    for j in range(n - 1, -1, -1):
        tmp = y[j, :]
        for k in range(j + 1, n):
            tmp -= R[j, k] * x[n - 1 - k]
        tmp = dps(tmp)
        x.append(tmp / R[j, j])
    return M.vstack(*x[::-1])

@overload
def _gauss_jordan_solve(M: Tmat, B: Tmat, freevar: Literal[False]=False) -> tuple[Tmat, Tmat]:
    pass

@overload
def _gauss_jordan_solve(M: Tmat, B: Tmat, freevar: Literal[True]) -> tuple[Tmat, Tmat, list[int]]:
    pass

@overload
def _gauss_jordan_solve(M: Tmat, B: Tmat, freevar: bool) -> tuple[Tmat, Tmat] | tuple[Tmat, Tmat, list[int]]:
    pass

def _gauss_jordan_solve(M: Tmat, B: Tmat, freevar: bool=False) -> tuple[Tmat, Tmat] | tuple[Tmat, Tmat, list[int]]:
    from sympy.matrices import Matrix, zeros
    cls = M.__class__
    aug = M.hstack(M.copy(), B.copy())
    B_cols = B.cols
    row, col = aug[:, :-B_cols].shape
    A, pivots_t = aug.rref(simplify=True)
    A, v = (A[:, :-B_cols], A[:, -B_cols:])
    pivots = list(filter(lambda p: p < col, pivots_t))
    rank = len(pivots)
    free_var_index = [c for c in range(A.cols) if c not in pivots]
    permutation = Matrix(pivots + free_var_index).T
    if not v[rank:, :].is_zero_matrix:
        raise ValueError('Linear system has no solution')
    name = uniquely_named_symbol('tau', [aug], compare=lambda i: str(i).rstrip('1234567890'), modify=lambda s: '_' + s).name
    gen = numbered_symbols(name)
    tau = cls._new([next(gen) for k in range((col - rank) * B_cols)]).reshape(col - rank, B_cols)
    V = A[:rank, free_var_index]
    vt = v[:rank, :]
    free_sol = tau.vstack(vt - V * tau, tau)
    sol = zeros(col, B_cols)
    for k in range(col):
        sol[permutation[k], :] = free_sol[k, :]
    sol = cls._as_type(sol)
    if freevar:
        return (sol, tau, free_var_index)
    else:
        return (sol, tau)

def _pinv_solve(M: Tmat, B: Tmat, arbitrary_matrix: Tmat | None=None) -> Tmat:
    from sympy.matrices import eye
    A = M
    A_pinv = M.pinv()
    if arbitrary_matrix is None:
        rows, cols = (A.cols, B.cols)
        w = symbols('w:{}_:{}'.format(rows, cols), cls=Dummy)
        arbitrary_matrix = M._new(cols, rows, w).T
    return A_pinv.multiply(B) + (eye(A.cols) - A_pinv.multiply(A)).multiply(arbitrary_matrix)

def _cramer_solve(M, rhs, det_method='laplace'):
    from .dense import zeros

    def entry(i, j):
        return rhs[i, sol] if j == col else M[i, j]
    if det_method == 'bird':
        from .determinant import _det_bird
        det = _det_bird
    elif det_method == 'laplace':
        from .determinant import _det_laplace
        det = _det_laplace
    elif isinstance(det_method, str):
        det = lambda matrix: matrix.det(method=det_method)
    else:
        det = det_method
    det_M = det(M)
    x = zeros(*rhs.shape)
    for sol in range(rhs.shape[1]):
        for col in range(rhs.shape[0]):
            x[col, sol] = det(M.__class__(*M.shape, entry)) / det_M
    return M.__class__(x)

def _solve(M, rhs, method='GJ'):
    if method in ('GJ', 'GE'):
        try:
            soln, param = M.gauss_jordan_solve(rhs)
            if param:
                raise NonInvertibleMatrixError('Matrix det == 0; not invertible. Try ``M.gauss_jordan_solve(rhs)`` to obtain a parametric solution.')
        except ValueError:
            raise NonInvertibleMatrixError('Matrix det == 0; not invertible.')
        return soln
    elif method == 'LU':
        return M.LUsolve(rhs)
    elif method == 'CH':
        return M.cholesky_solve(rhs)
    elif method == 'QR':
        return M.QRsolve(rhs)
    elif method == 'LDL':
        return M.LDLsolve(rhs)
    elif method == 'PINV':
        return M.pinv_solve(rhs)
    elif method == 'CRAMER':
        return M.cramer_solve(rhs)
    else:
        return M.inv(method=method).multiply(rhs)

def _solve_least_squares(M: Tmat, rhs: Tmat, method: str='CH') -> Tmat:
    if method == 'CH':
        return M.cholesky_solve(rhs)
    elif method == 'QR':
        return M.QRsolve(rhs)
    elif method == 'LDL':
        return M.LDLsolve(rhs)
    elif method == 'PINV':
        return M.pinv_solve(rhs)
    else:
        t = M.H
        return (t * M).solve(t * rhs, method=method)