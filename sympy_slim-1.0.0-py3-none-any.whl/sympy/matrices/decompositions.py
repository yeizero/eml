from __future__ import annotations
from typing import TYPE_CHECKING
import copy
from sympy.core import S
from sympy.core.function import expand_mul
from sympy.functions.elementary.miscellaneous import Min, sqrt
from sympy.functions.elementary.complexes import sign
from .exceptions import NonSquareMatrixError, NonPositiveDefiniteMatrixError
from .utilities import _get_intermediate_simp, _iszero
from .determinant import _find_reasonable_pivot_naive
if TYPE_CHECKING:
    from typing import Callable, TypeVar
    from sympy.core.expr import Expr
    from sympy.matrices.matrixbase import MatrixBase
    from sympy.matrices.sparse import SparseMatrix
    Tmat = TypeVar('Tmat', bound=MatrixBase)

def _rank_decomposition(M: Tmat, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False) -> tuple[Tmat, Tmat]:
    F, pivot_cols = M.rref(simplify=simplify, iszerofunc=iszerofunc, pivots=True)
    rank = len(pivot_cols)
    C = M.extract(range(M.rows), pivot_cols)
    F = F[:rank, :]
    return (C, F)

def _liupc(M):
    R = [[] for r in range(M.rows)]
    for r, c, _ in M.row_list():
        if c <= r:
            R[r].append(c)
    inf = len(R)
    parent = [inf] * M.rows
    virtual = [inf] * M.rows
    for r in range(M.rows):
        for c in R[r][:-1]:
            while virtual[c] < r:
                t = virtual[c]
                virtual[c] = r
                c = t
            if virtual[c] == inf:
                parent[c] = virtual[c] = r
    return (R, parent)

def _row_structure_symbolic_cholesky(M):
    R, parent = M.liupc()
    inf = len(R)
    Lrow = copy.deepcopy(R)
    for k in range(M.rows):
        for j in R[k]:
            while j != inf and j != k:
                Lrow[k].append(j)
                j = parent[j]
        Lrow[k] = sorted(set(Lrow[k]))
    return Lrow

def _cholesky(M: Tmat, hermitian: bool=True) -> Tmat:
    from .dense import MutableDenseMatrix
    if not M.is_square:
        raise NonSquareMatrixError('Matrix must be square.')
    if hermitian and (not M.is_hermitian):
        raise ValueError('Matrix must be Hermitian.')
    if not hermitian and (not M.is_symmetric()):
        raise ValueError('Matrix must be symmetric.')
    L = MutableDenseMatrix.zeros(M.rows, M.rows)
    if hermitian:
        for i in range(M.rows):
            for j in range(i):
                L[i, j] = 1 / L[j, j] * (M[i, j] - sum((L[i, k] * L[j, k].conjugate() for k in range(j))))
            Lii2 = M[i, i] - sum((L[i, k] * L[i, k].conjugate() for k in range(i)))
            if Lii2.is_positive is False:
                raise NonPositiveDefiniteMatrixError('Matrix must be positive-definite')
            L[i, i] = sqrt(Lii2)
    else:
        for i in range(M.rows):
            for j in range(i):
                L[i, j] = 1 / L[j, j] * (M[i, j] - sum((L[i, k] * L[j, k] for k in range(j))))
            L[i, i] = sqrt(M[i, i] - sum((L[i, k] ** 2 for k in range(i))))
    return M._as_type(L)

def _cholesky_sparse(M, hermitian=True):
    from .dense import MutableDenseMatrix
    if not M.is_square:
        raise NonSquareMatrixError('Matrix must be square.')
    if hermitian and (not M.is_hermitian):
        raise ValueError('Matrix must be Hermitian.')
    if not hermitian and (not M.is_symmetric()):
        raise ValueError('Matrix must be symmetric.')
    dps = _get_intermediate_simp(expand_mul, expand_mul)
    Crowstruc = M.row_structure_symbolic_cholesky()
    C = MutableDenseMatrix.zeros(M.rows)
    for i in range(len(Crowstruc)):
        for j in Crowstruc[i]:
            if i != j:
                C[i, j] = M[i, j]
                summ = 0
                for p1 in Crowstruc[i]:
                    if p1 < j:
                        for p2 in Crowstruc[j]:
                            if p2 < j:
                                if p1 == p2:
                                    if hermitian:
                                        summ += C[i, p1] * C[j, p1].conjugate()
                                    else:
                                        summ += C[i, p1] * C[j, p1]
                            else:
                                break
                        else:
                            break
                C[i, j] = dps((C[i, j] - summ) / C[j, j])
            else:
                C[j, j] = M[j, j]
                summ = 0
                for k in Crowstruc[j]:
                    if k < j:
                        if hermitian:
                            summ += C[j, k] * C[j, k].conjugate()
                        else:
                            summ += C[j, k] ** 2
                    else:
                        break
                Cjj2 = dps(C[j, j] - summ)
                if hermitian and Cjj2.is_positive is False:
                    raise NonPositiveDefiniteMatrixError('Matrix must be positive-definite')
                C[j, j] = sqrt(Cjj2)
    return M._new(C)

def _LDLdecomposition(M: Tmat, hermitian: bool=True) -> tuple[Tmat, Tmat]:
    from .dense import MutableDenseMatrix
    if not M.is_square:
        raise NonSquareMatrixError('Matrix must be square.')
    if hermitian and (not M.is_hermitian):
        raise ValueError('Matrix must be Hermitian.')
    if not hermitian and (not M.is_symmetric()):
        raise ValueError('Matrix must be symmetric.')
    D = MutableDenseMatrix.zeros(M.rows, M.rows)
    L = MutableDenseMatrix.eye(M.rows)
    if hermitian:
        for i in range(M.rows):
            for j in range(i):
                L[i, j] = 1 / D[j, j] * (M[i, j] - sum((L[i, k] * L[j, k].conjugate() * D[k, k] for k in range(j))))
            D[i, i] = M[i, i] - sum((L[i, k] * L[i, k].conjugate() * D[k, k] for k in range(i)))
            if D[i, i].is_positive is False:
                raise NonPositiveDefiniteMatrixError('Matrix must be positive-definite')
    else:
        for i in range(M.rows):
            for j in range(i):
                L[i, j] = 1 / D[j, j] * (M[i, j] - sum((L[i, k] * L[j, k] * D[k, k] for k in range(j))))
            D[i, i] = M[i, i] - sum((L[i, k] ** 2 * D[k, k] for k in range(i)))
    return (M._as_type(L), M._as_type(D))

def _LDLdecomposition_sparse(M, hermitian=True):
    from .dense import MutableDenseMatrix
    if not M.is_square:
        raise NonSquareMatrixError('Matrix must be square.')
    if hermitian and (not M.is_hermitian):
        raise ValueError('Matrix must be Hermitian.')
    if not hermitian and (not M.is_symmetric()):
        raise ValueError('Matrix must be symmetric.')
    dps = _get_intermediate_simp(expand_mul, expand_mul)
    Lrowstruc = M.row_structure_symbolic_cholesky()
    L = MutableDenseMatrix.eye(M.rows)
    D = MutableDenseMatrix.zeros(M.rows, M.cols)
    for i in range(len(Lrowstruc)):
        for j in Lrowstruc[i]:
            if i != j:
                L[i, j] = M[i, j]
                summ = 0
                for p1 in Lrowstruc[i]:
                    if p1 < j:
                        for p2 in Lrowstruc[j]:
                            if p2 < j:
                                if p1 == p2:
                                    if hermitian:
                                        summ += L[i, p1] * L[j, p1].conjugate() * D[p1, p1]
                                    else:
                                        summ += L[i, p1] * L[j, p1] * D[p1, p1]
                            else:
                                break
                    else:
                        break
                L[i, j] = dps((L[i, j] - summ) / D[j, j])
            else:
                D[i, i] = M[i, i]
                summ = 0
                for k in Lrowstruc[i]:
                    if k < i:
                        if hermitian:
                            summ += L[i, k] * L[i, k].conjugate() * D[k, k]
                        else:
                            summ += L[i, k] ** 2 * D[k, k]
                    else:
                        break
                D[i, i] = dps(D[i, i] - summ)
                if hermitian and D[i, i].is_positive is False:
                    raise NonPositiveDefiniteMatrixError('Matrix must be positive-definite')
    return (M._new(L), M._new(D))

def _LUdecomposition(M, iszerofunc=_iszero, simpfunc=None, rankcheck=False):
    combined, p = M.LUdecomposition_Simple(iszerofunc=iszerofunc, simpfunc=simpfunc, rankcheck=rankcheck)

    def entry_L(i, j):
        if i < j:
            return M.zero
        elif i == j:
            return M.one
        elif j < combined.cols:
            return combined[i, j]
        return M.zero

    def entry_U(i, j):
        return M.zero if i > j else combined[i, j]
    L = M._new(combined.rows, combined.rows, entry_L)
    U = M._new(combined.rows, combined.cols, entry_U)
    return (L, U, p)

def _LUdecomposition_Simple(M, iszerofunc=_iszero, simpfunc=None, rankcheck=False):
    if rankcheck:
        pass
    if S.Zero in M.shape:
        return (M.zeros(M.rows, M.cols), [])
    dps = _get_intermediate_simp()
    lu = M.as_mutable()
    row_swaps = []
    pivot_col = 0
    for pivot_row in range(0, lu.rows - 1):
        iszeropivot = True
        while pivot_col != M.cols and iszeropivot:
            sub_col = (lu[r, pivot_col] for r in range(pivot_row, M.rows))
            pivot_row_offset, pivot_value, is_assumed_non_zero, ind_simplified_pairs = _find_reasonable_pivot_naive(sub_col, iszerofunc, simpfunc)
            iszeropivot = pivot_value is None
            if iszeropivot:
                pivot_col += 1
        if rankcheck and pivot_col != pivot_row:
            raise ValueError('Rank of matrix is strictly less than number of rows or columns. Pass keyword argument rankcheck=False to compute the LU decomposition of this matrix.')
        candidate_pivot_row = None if pivot_row_offset is None else pivot_row + pivot_row_offset
        if candidate_pivot_row is None and iszeropivot:
            return (lu, row_swaps)
        for offset, val in ind_simplified_pairs:
            lu[pivot_row + offset, pivot_col] = val
        if pivot_row != candidate_pivot_row:
            row_swaps.append([pivot_row, candidate_pivot_row])
            lu[pivot_row, 0:pivot_row], lu[candidate_pivot_row, 0:pivot_row] = (lu[candidate_pivot_row, 0:pivot_row], lu[pivot_row, 0:pivot_row])
            lu[pivot_row, pivot_col:lu.cols], lu[candidate_pivot_row, pivot_col:lu.cols] = (lu[candidate_pivot_row, pivot_col:lu.cols], lu[pivot_row, pivot_col:lu.cols])
        start_col = pivot_col + 1
        for row in range(pivot_row + 1, lu.rows):
            lu[row, pivot_row] = dps(lu[row, pivot_col] / lu[pivot_row, pivot_col])
            for c in range(start_col, lu.cols):
                lu[row, c] = dps(lu[row, c] - lu[row, pivot_row] * lu[pivot_row, c])
        if pivot_row != pivot_col:
            for row in range(pivot_row + 1, lu.rows):
                lu[row, pivot_col] = M.zero
        pivot_col += 1
        if pivot_col == lu.cols:
            return (lu, row_swaps)
    if rankcheck:
        if iszerofunc(lu[Min(lu.rows, lu.cols) - 1, Min(lu.rows, lu.cols) - 1]):
            raise ValueError('Rank of matrix is strictly less than number of rows or columns. Pass keyword argument rankcheck=False to compute the LU decomposition of this matrix.')
    return (lu, row_swaps)

def _LUdecompositionFF(M: MatrixBase) -> tuple[SparseMatrix, SparseMatrix, SparseMatrix, MatrixBase]:
    from sympy.matrices import SparseMatrix
    zeros = SparseMatrix.zeros
    eye = SparseMatrix.eye
    n, m = (M.rows, M.cols)
    U, L, P = (M.as_mutable(), eye(n), eye(n))
    DD = zeros(n, n)
    oldpivot = 1
    for k in range(n - 1):
        if U[k, k] == 0:
            for kpivot in range(k + 1, n):
                if U[kpivot, k]:
                    break
            else:
                raise ValueError('Matrix is not full rank')
            U[k, k:], U[kpivot, k:] = (U[kpivot, k:], U[k, k:])
            L[k, :k], L[kpivot, :k] = (L[kpivot, :k], L[k, :k])
            P[k, :], P[kpivot, :] = (P[kpivot, :], P[k, :])
        L[k, k] = Ukk = U[k, k]
        DD[k, k] = oldpivot * Ukk
        for i in range(k + 1, n):
            L[i, k] = Uik = U[i, k]
            for j in range(k + 1, m):
                U[i, j] = (Ukk * U[i, j] - U[k, j] * Uik) / oldpivot
            U[i, k] = 0
        oldpivot = Ukk
    DD[n - 1, n - 1] = oldpivot
    return (P, L, DD, U)

def _singular_value_decomposition(A: Tmat) -> tuple[Tmat, Tmat, Tmat]:
    AH = A.H
    m, n = A.shape
    if m >= n:
        V, S = (AH * A).diagonalize()
        ranked: list[int] = []
        for i, x in enumerate(S.diagonal().flat()):
            if not x.is_zero:
                ranked.append(i)
        V = V[:, ranked]
        Singular_vals = [sqrt(S[i, i]) for i in range(S.rows) if i in ranked]
        S = S.diag(*Singular_vals)
        V, _ = V.QRdecomposition()
        U = A * V * S.inv()
    else:
        U, S = (A * AH).diagonalize()
        ranked = []
        for i, x in enumerate(S.diagonal().flat()):
            if not x.is_zero:
                ranked.append(i)
        U = U[:, ranked]
        Singular_vals = [sqrt(S[i, i]) for i in range(S.rows) if i in ranked]
        S = S.diag(*Singular_vals)
        U, _ = U.QRdecomposition()
        V = AH * U * S.inv()
    return (U, S, V)

def _QRdecomposition_optional(M, normalize=True):

    def dot(u, v):
        return u.dot(v, hermitian=True)
    dps = _get_intermediate_simp(expand_mul, expand_mul)
    A = M.as_mutable()
    ranked = []
    Q = A
    R = A.zeros(A.cols)
    for j in range(A.cols):
        for i in range(j):
            z = Q[:, i].is_zero_matrix
            if z is True:
                continue
            norm = dps(dot(Q[:, i], Q[:, i]))
            if z is None and norm.equals(0):
                continue
            R[i, j] = dot(Q[:, i], Q[:, j]) / norm
            R[i, j] = dps(R[i, j])
            Q[:, j] -= Q[:, i] * R[i, j]
        Q[:, j] = dps(Q[:, j])
        z = Q[:, j].is_zero_matrix
        if z is True or dps(dot(Q[:, j], Q[:, j])).equals(0):
            continue
        ranked.append(j)
        R[j, j] = M.one
    Q = Q.extract(range(Q.rows), ranked)
    R = R.extract(ranked, range(R.cols))
    if normalize:
        for i in range(Q.cols):
            norm = Q[:, i].norm()
            Q[:, i] /= norm
            R[i, :] *= norm
    return (M.__class__(Q), M.__class__(R))

def _QRdecomposition(M):
    return _QRdecomposition_optional(M, normalize=True)

def _upper_hessenberg_decomposition(A):
    M = A.as_mutable()
    if not M.is_square:
        raise NonSquareMatrixError('Matrix must be square.')
    n = M.cols
    P = M.eye(n)
    H = M
    for j in range(n - 2):
        u = H[j + 1:, j]
        if u[1:, :].is_zero_matrix:
            continue
        if sign(u[0]) != 0:
            u[0] = u[0] + sign(u[0]) * u.norm()
        else:
            u[0] = u[0] + u.norm()
        v = u / u.norm()
        H[j + 1:, :] = H[j + 1:, :] - 2 * v * (v.H * H[j + 1:, :])
        H[:, j + 1:] = H[:, j + 1:] - H[:, j + 1:] * (2 * v) * v.H
        P[:, j + 1:] = P[:, j + 1:] - P[:, j + 1:] * (2 * v) * v.H
    return (H, P)