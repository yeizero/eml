from __future__ import annotations
from typing import TYPE_CHECKING, overload
from collections import defaultdict
from collections.abc import Iterable, Sequence
from inspect import isfunction
from functools import reduce
from sympy.assumptions.refine import refine
from sympy.core import SympifyError, Add
from sympy.core.basic import Atom, Basic
from sympy.core.kind import UndefinedKind
from sympy.core.numbers import Integer, Float
from sympy.core.mod import Mod
from sympy.core.symbol import Symbol, Dummy
from sympy.core.sympify import sympify, _sympify
from sympy.core.function import diff
from sympy.external.mpmath import _matrix as _mpmath_matrix
from sympy.polys import cancel
from sympy.functions.elementary.complexes import Abs, re, im
from sympy.printing import sstr
from sympy.functions.elementary.miscellaneous import Max, Min, sqrt
from sympy.functions.special.tensor_functions import KroneckerDelta, LeviCivita
from sympy.core.singleton import S
from sympy.printing.defaults import Printable
from sympy.printing.str import StrPrinter
from sympy.functions.elementary.exponential import exp, log
from sympy.functions.combinatorial.factorials import binomial, factorial
from collections.abc import Callable
from sympy.utilities.iterables import reshape
from sympy.core.power import Pow
from sympy.core.symbol import uniquely_named_symbol
from .utilities import _dotprodsimp, _simplify as _utilities_simplify
from sympy.polys.polytools import Poly
from sympy.utilities.iterables import flatten, is_sequence
from sympy.utilities.misc import as_int, filldedent
from sympy.core.decorators import call_highest_priority
from sympy.core.logic import fuzzy_and
from sympy.tensor.array import NDimArray
from sympy.utilities.iterables import NotIterable
from .utilities import _get_intermediate_simp_bool
from .kind import MatrixKind
from .exceptions import MatrixError, ShapeError, NonSquareMatrixError, NonInvertibleMatrixError
from .utilities import _iszero, _is_zero_after_expand_mul
from .determinant import _find_reasonable_pivot, _find_reasonable_pivot_naive, _adjugate, _charpoly, _cofactor, _cofactor_matrix, _per, _det, _det_bareiss, _det_berkowitz, _det_bird, _det_laplace, _det_LU, _minor, _minor_submatrix
from .reductions import _is_echelon, _echelon_form, _rank, _rref
from .solvers import _diagonal_solve, _lower_triangular_solve, _upper_triangular_solve, _cholesky_solve, _LDLsolve, _LUsolve, _QRsolve, _gauss_jordan_solve, _pinv_solve, _cramer_solve, _solve, _solve_least_squares
from .inverse import _pinv, _inv_ADJ, _inv_GE, _inv_LU, _inv_CH, _inv_LDL, _inv_QR, _inv, _inv_block
from .subspaces import _columnspace, _nullspace, _rowspace, _orthogonalize
from .eigen import _eigenvals, _eigenvects, _bidiagonalize, _bidiagonal_decomposition, _is_diagonalizable, _diagonalize, _is_positive_definite, _is_positive_semidefinite, _is_negative_definite, _is_negative_semidefinite, _is_indefinite, _jordan_form, _left_eigenvects, _singular_values
from .decompositions import _rank_decomposition, _cholesky, _LDLdecomposition, _LUdecomposition, _LUdecomposition_Simple, _LUdecompositionFF, _singular_value_decomposition, _QRdecomposition, _upper_hessenberg_decomposition
from .graph import _connected_components, _connected_components_decomposition, _strongly_connected_components, _strongly_connected_components_decomposition
if TYPE_CHECKING:
    from sympy.core.expr import Expr
    from abc import ABCMeta, abstractmethod
else:
    from abc import abstractmethod
    ABCMeta = type
if TYPE_CHECKING:
    from typing import Literal, TypeVar, Iterator, Mapping, Any
    from typing_extensions import Self
    from sympy.combinatorics import Permutation
    from sympy.logic.boolalg import Boolean
    from sympy.integrals.integrals import SymbolLimits
    from sympy.matrices.expressions.matexpr import MatrixExpr
    from sympy.matrices.expressions.permutation import PermutationMatrix
    from sympy.matrices.expressions.blockmatrix import BlockDiagMatrix, BlockMatrix
    Tmat = TypeVar('Tmat', bound='MatrixBase')
    Tbasic = TypeVar('Tbasic', bound=Basic)
    SExpr = Expr | complex
    SBasic = Basic | complex
    Slice = slice | list[int]
__doctest_requires__ = {('MatrixBase.is_indefinite', 'MatrixBase.is_positive_definite', 'MatrixBase.is_positive_semidefinite', 'MatrixBase.is_negative_definite', 'MatrixBase.is_negative_semidefinite'): ['matplotlib']}

class MatrixBase(Printable):
    _op_priority = 10.01
    __array_priority__ = 11
    is_Matrix = True
    _class_priority = 3
    zero = S.Zero
    one = S.One
    _diff_wrt: bool = True
    _simplify = None
    if TYPE_CHECKING:

        @property
        def rows(self) -> int:
            pass

        @property
        def cols(self) -> int:
            pass

    @overload
    @classmethod
    def _sympify(cls, expr: SExpr, /) -> Expr:
        pass

    @overload
    @classmethod
    def _sympify(cls, expr: Poly, /) -> Poly:
        pass

    @classmethod
    def _sympify(cls, expr: SExpr | Poly, /) -> Expr | Poly:
        if isinstance(expr, Poly):
            return expr
        return sympify(expr)

    @overload
    @classmethod
    def _new(cls, rows: int, cols: int, mat: Sequence[SExpr], /, copy: bool=False) -> Self:
        pass

    @overload
    @classmethod
    def _new(cls, rows: int, cols: int, func: Callable[[int, int], SExpr], /) -> Self:
        pass

    @overload
    @classmethod
    def _new(cls, mat: Sequence[Sequence[SExpr]] | Self, /) -> Self:
        pass

    @overload
    @classmethod
    def _new(cls, /) -> Self:
        pass

    @overload
    @classmethod
    def _new(cls, elements: Sequence[SExpr], /) -> Self:
        pass

    @classmethod
    @abstractmethod
    def _new(cls, *args, **kwargs) -> Self:
        raise NotImplementedError('Subclasses must implement this.')

    @classmethod
    def _as_type(cls, mat: MatrixBase) -> Self:
        if not isinstance(mat, cls):
            mat = cls._new(mat)
        return mat

    def as_explicit(self) -> Self:
        return self

    def __eq__(self, other):
        raise NotImplementedError('Subclasses must implement this.')

    @overload
    def __getitem__(self, key: tuple[int, int], /) -> Expr:
        pass

    @overload
    def __getitem__(self, key: tuple[int, Slice], /) -> Self:
        pass

    @overload
    def __getitem__(self, key: tuple[Slice, int], /) -> Self:
        pass

    @overload
    def __getitem__(self, key: tuple[Slice, Slice], /) -> Self:
        pass

    @overload
    def __getitem__(self, key: int, /) -> Expr:
        pass

    @overload
    def __getitem__(self, key: slice, /) -> list[Expr]:
        pass

    @abstractmethod
    def __getitem__(self, key: tuple[int | Slice, int | Slice] | int | slice, /) -> Expr | Self | list[Expr]:
        raise NotImplementedError('Subclasses must implement this.')

    @property
    def shape(self) -> tuple[int, int]:
        return (self.rows, self.cols)

    def _eval_col_del(self, col: int, /) -> Self:

        def entry(i, j):
            return self[i, j] if j < col else self[i, j + 1]
        return self._new(self.rows, self.cols - 1, entry)

    def _eval_col_insert(self, pos: int, other: Self, /) -> Self:

        def entry(i, j):
            if j < pos:
                return self[i, j]
            elif pos <= j < pos + other.cols:
                return other[i, j - pos]
            return self[i, j - other.cols]
        return self._new(self.rows, self.cols + other.cols, entry)

    def _eval_col_join(self, other: Self, /) -> Self:
        rows = self.rows

        def entry(i, j):
            if i < rows:
                return self[i, j]
            return other[i - rows, j]
        return classof(self, other)._new(self.rows + other.rows, self.cols, entry)

    def _eval_extract(self, rowsList: Sequence[int], colsList: Sequence[int], /) -> Self:
        mat = self.flat()
        cols = self.cols
        indices = (i * cols + j for i in rowsList for j in colsList)
        return self._new(len(rowsList), len(colsList), [mat[i] for i in indices])

    def _eval_get_diag_blocks(self) -> list[Self]:
        sub_blocks: list[Self] = []

        def recurse_sub_blocks(M: Self) -> None:
            for i in range(1, M.shape[0] + 1):
                if i == 1:
                    to_the_right = M[0, i:]
                    to_the_bottom = M[i:, 0]
                else:
                    to_the_right = M[:i, i:]
                    to_the_bottom = M[i:, :i]
                if any(to_the_right) or any(to_the_bottom):
                    continue
                sub_blocks.append(M[:i, :i])
                if M.shape != M[:i, :i].shape:
                    recurse_sub_blocks(M[i:, i:])
                return
        recurse_sub_blocks(self)
        return sub_blocks

    def _eval_row_del(self, row: int, /) -> Self:

        def entry(i, j):
            return self[i, j] if i < row else self[i + 1, j]
        return self._new(self.rows - 1, self.cols, entry)

    def _eval_row_insert(self, pos: int, other: Self, /) -> Self:
        entries = self.flat()
        insert_pos = pos * self.cols
        entries[insert_pos:insert_pos] = other.flat()
        return self._new(self.rows + other.rows, self.cols, entries)

    def _eval_row_join(self, other: Self, /) -> Self:
        cols = self.cols

        def entry(i, j):
            if j < cols:
                return self[i, j]
            return other[i, j - cols]
        return classof(self, other)._new(self.rows, self.cols + other.cols, entry)

    def _eval_tolist(self) -> list[list[Expr]]:
        return [self[i, :].flat() for i in range(self.rows)]

    def _eval_todok(self) -> dict[tuple[int, int], Expr]:
        dok = {}
        rows, cols = self.shape
        for i in range(rows):
            for j in range(cols):
                val = self[i, j]
                if val != self.zero:
                    dok[i, j] = val
        return dok

    @classmethod
    def _eval_from_dok(cls, rows: int, cols: int, dok: dict[tuple[int, int], Expr], /) -> Self:
        out_flat: list[Expr] = [cls.zero] * (rows * cols)
        for (i, j), val in dok.items():
            out_flat[i * cols + j] = val
        return cls._new(rows, cols, out_flat)

    def _eval_vec(self) -> Self:
        rows = self.rows

        def entry(n, _):
            j = n // rows
            i = n - j * rows
            return self[i, j]
        return self._new(len(self), 1, entry)

    def _eval_vech(self, diagonal: bool) -> Self:
        c = self.cols
        v = []
        if diagonal:
            for j in range(c):
                for i in range(j, c):
                    v.append(self[i, j])
        else:
            for j in range(c):
                for i in range(j + 1, c):
                    v.append(self[i, j])
        return self._new(len(v), 1, v)

    def col_del(self, col: int, /) -> Self:
        if col < 0:
            col += self.cols
        if not 0 <= col < self.cols:
            raise IndexError('Column {} is out of range.'.format(col))
        return self._eval_col_del(col)

    def col_insert(self, pos: int, other: Self, /) -> Self:
        if not self:
            return self._new(other)
        pos = as_int(pos)
        if pos < 0:
            pos = self.cols + pos
        if pos < 0:
            pos = 0
        elif pos > self.cols:
            pos = self.cols
        if self.rows != other.rows:
            raise ShapeError('The matrices have incompatible number of rows ({} and {})'.format(self.rows, other.rows))
        return self._eval_col_insert(pos, other)

    def col_join(self, other: Self, /) -> Self:
        if self.rows == 0 and self.cols != other.cols:
            return self._new(0, other.cols, []).col_join(other)
        if self.cols != other.cols:
            raise ShapeError('The matrices have incompatible number of columns ({} and {})'.format(self.cols, other.cols))
        return self._eval_col_join(other)

    def col(self, j: int, /) -> Self:
        return self[:, j]

    def extract(self, rowsList: Sequence[int], colsList: Sequence[int], /) -> Self:
        if not is_sequence(rowsList) or not is_sequence(colsList):
            raise TypeError('rowsList and colsList must be iterable')
        if rowsList and all((isinstance(i, bool) for i in rowsList)):
            rowsList = [index for index, item in enumerate(rowsList) if item]
        if colsList and all((isinstance(i, bool) for i in colsList)):
            colsList = [index for index, item in enumerate(colsList) if item]
        rowsList = [a2idx(k, self.rows) for k in rowsList]
        colsList = [a2idx(k, self.cols) for k in colsList]
        return self._eval_extract(rowsList, colsList)

    def get_diag_blocks(self) -> list[Self]:
        return self._eval_get_diag_blocks()

    @classmethod
    def hstack(cls, *args: Self) -> Self:
        if len(args) == 0:
            return cls._new()
        kls = type(args[0])
        return reduce(kls.row_join, args)

    def reshape(self, rows: int, cols: int) -> Self:
        if self.rows * self.cols != rows * cols:
            raise ValueError('Invalid reshape parameters %d %d' % (rows, cols))
        dok = {divmod(i * self.cols + j, cols): v for (i, j), v in self.todok().items()}
        return self._eval_from_dok(rows, cols, dok)

    def row_del(self, row: int, /) -> Self:
        if row < 0:
            row += self.rows
        if not 0 <= row < self.rows:
            raise IndexError('Row {} is out of range.'.format(row))
        return self._eval_row_del(row)

    def row_insert(self, pos: int, other: Self, /) -> Self:
        if not self:
            return self._new(other)
        pos = as_int(pos)
        if pos < 0:
            pos = self.rows + pos
        if pos < 0:
            pos = 0
        elif pos > self.rows:
            pos = self.rows
        if self.cols != other.cols:
            raise ShapeError('The matrices have incompatible number of columns ({} and {})'.format(self.cols, other.cols))
        return self._eval_row_insert(pos, other)

    def row_join(self, other: Self) -> Self:
        if self.cols == 0 and self.rows != other.rows:
            return self._new(other.rows, 0, []).row_join(other)
        if self.rows != other.rows:
            raise ShapeError('The matrices have incompatible number of rows ({} and {})'.format(self.rows, other.rows))
        return self._eval_row_join(other)

    def diagonal(self, k: int=0) -> Self:
        k = as_int(k)
        rv = [self[r, r + k] for r in range(max(0, -k), min(self.rows, self.cols - k))]
        return self._new(1, len(rv), rv)

    def row(self, i: int, /) -> Self:
        return self[i, :]

    def todok(self) -> dict[tuple[int, int], Expr]:
        return self._eval_todok()

    @classmethod
    def from_dok(cls, rows: int, cols: int, dok: dict[tuple[int, int], Expr], /) -> Self:
        dok = {ij: cls._sympify(val) for ij, val in dok.items()}
        return cls._eval_from_dok(rows, cols, dok)

    def tolist(self) -> list[list[Expr]]:
        if not self.rows:
            return []
        if not self.cols:
            return [[] for _ in range(self.rows)]
        return self._eval_tolist()

    def todod(M) -> dict[int, dict[int, Expr]]:
        rowsdict = {}
        Mlol = M.tolist()
        for i, Mi in enumerate(Mlol):
            row = {j: Mij for j, Mij in enumerate(Mi) if Mij}
            if row:
                rowsdict[i] = row
        return rowsdict

    def vec(self) -> Self:
        return self._eval_vec()

    def vech(self, diagonal: bool=True, check_symmetry: bool=True) -> Self:
        if not self.is_square:
            raise NonSquareMatrixError
        if check_symmetry and (not self.is_symmetric()):
            raise ValueError('The matrix is not symmetric.')
        return self._eval_vech(diagonal)

    @classmethod
    def vstack(cls, *args: Self) -> Self:
        if len(args) == 0:
            return cls._new()
        kls = type(args[0])
        return reduce(kls.col_join, args)

    @classmethod
    def _eval_diag(cls, rows: int, cols: int, diag_dict: dict[tuple[int, int], SExpr], /) -> Self:

        def entry(i, j):
            return diag_dict[i, j]
        return cls._new(rows, cols, entry)

    @classmethod
    def _eval_eye(cls, rows: int, cols: int) -> Self:
        vals: list[Expr] = [cls.zero] * (rows * cols)
        vals[::cols + 1] = [cls.one] * min(rows, cols)
        return cls._new(rows, cols, vals, copy=False)

    @classmethod
    def _eval_jordan_block(cls, size: int, eigenvalue: SExpr, band: Literal['upper', 'lower']='upper') -> Self:
        if band == 'lower':

            def entry(i, j):
                if i == j:
                    return eigenvalue
                elif j + 1 == i:
                    return cls.one
                return cls.zero
        else:

            def entry(i, j):
                if i == j:
                    return eigenvalue
                elif i + 1 == j:
                    return cls.one
                return cls.zero
        return cls._new(size, size, entry)

    @classmethod
    def _eval_ones(cls, rows, cols) -> Self:

        def entry(i, j):
            return cls.one
        return cls._new(rows, cols, entry)

    @classmethod
    def _eval_zeros(cls, rows, cols) -> Self:
        return cls._new(rows, cols, [cls.zero] * (rows * cols), copy=False)

    @classmethod
    def _eval_wilkinson(cls, n) -> tuple[Self, Self]:

        def entry(i, j):
            return cls.one if i + 1 == j else cls.zero
        D = cls._new(2 * n + 1, 2 * n + 1, entry)
        wminus = cls.diag(list(range(-n, n + 1)), unpack=True) + D + D.T
        wplus = abs(cls.diag(list(range(-n, n + 1)), unpack=True)) + D + D.T
        return (wminus, cls._as_type(wplus))

    @overload
    @classmethod
    def diag(kls, *args: SExpr | Sequence[SExpr] | MatrixBase, strict: bool=False, unpack: bool=True, rows: int | None=None, cols: int | None=None, cls: None=None) -> Self:
        pass

    @overload
    @classmethod
    def diag(kls, *args: SExpr | Sequence[SExpr] | MatrixBase, strict: bool=False, unpack: bool=True, rows: int | None=None, cols: int | None=None, cls: type[Tmat]) -> Tmat:
        pass

    @classmethod
    def diag(kls, *args: SExpr | Sequence[SExpr] | MatrixBase, strict: bool=False, unpack: bool=True, rows: int | None=None, cols: int | None=None, cls: type[Tmat] | None=None) -> Self | Tmat:
        from sympy.matrices.matrixbase import MatrixBase
        from sympy.matrices.dense import Matrix
        from sympy.matrices import SparseMatrix
        klass = cls if cls is not None else kls
        args2: tuple[SExpr | list[SExpr] | MatrixBase, ...]
        if unpack and len(args) == 1 and is_sequence(args[0]) and (not isinstance(args[0], MatrixBase)):
            args2 = args[0]
        else:
            args2 = args
        diag_entries: dict[tuple[int, int], SExpr] = defaultdict(int)
        rmax = cmax = 0
        for m in args2:
            if isinstance(m, list):
                if strict:
                    _ = Matrix(m)
                    r, c = _.shape
                    m2 = _.tolist()
                else:
                    r, c, smat = SparseMatrix._handle_creation_inputs(m)
                    for (i, j), _ in smat.items():
                        diag_entries[i + rmax, j + cmax] = _
                    m2 = []
            elif isinstance(m, MatrixBase):
                r, c = m.shape
                m2 = m.tolist()
            else:
                diag_entries[rmax, cmax] = m
                rmax += 1
                cmax += 1
                continue
            for i, mi in enumerate(m2):
                for j, _ in enumerate(mi):
                    diag_entries[i + rmax, j + cmax] = _
            rmax += r
            cmax += c
        if rows is None:
            rows, cols = (cols, rows)
        if rows is None:
            rows, cols = (rmax, cmax)
        else:
            cols = rows if cols is None else cols
        if rows < rmax or cols < cmax:
            raise ValueError(filldedent('\n                The constructed matrix is {} x {} but a size of {} x {}\n                was specified.'.format(rmax, cmax, rows, cols)))
        return klass._eval_diag(rows, cols, diag_entries)

    @overload
    @classmethod
    def eye(kls, rows: int, cols: int | None=None, *, cls: None=None) -> Self:
        pass

    @overload
    @classmethod
    def eye(kls, rows: int, cols: int | None=None, *, cls: type[Tmat]) -> Tmat:
        pass

    @classmethod
    def eye(kls, rows: int, cols: int | None=None, *, cls: type[Tmat] | None=None) -> Self | Tmat:
        if cols is None:
            cols2 = rows
        else:
            cols2 = cols
        if rows < 0 or cols2 < 0:
            raise ValueError('Cannot create a {} x {} matrix. Both dimensions must be positive'.format(rows, cols2))
        klass = cls if cls is not None else kls
        rows, cols2 = (as_int(rows), as_int(cols2))
        return klass._eval_eye(rows, cols2)

    @overload
    @classmethod
    def jordan_block(kls, size: int | None=None, eigenvalue: SExpr | None=None, *, band: Literal['upper', 'lower']='upper', cls: None=None, eigenval: SExpr | None=None) -> Self:
        pass

    @overload
    @classmethod
    def jordan_block(kls, size: int | None=None, eigenvalue: SExpr | None=None, *, band: Literal['upper', 'lower']='upper', cls: type[Tmat], eigenval: SExpr | None=None) -> Tmat:
        pass

    @classmethod
    def jordan_block(kls, size: int | None=None, eigenvalue: SExpr | None=None, *, band: Literal['upper', 'lower']='upper', cls: type[Tmat] | None=None, eigenval: SExpr | None=None) -> Self | Tmat:
        klass = cls if cls is not None else kls
        if eigenvalue is not None:
            if eigenval is not None and eigenvalue != eigenval:
                raise ValueError("Cannot supply both 'eigenvalue' and 'eigenval'")
            e = eigenvalue
        elif eigenval is not None:
            e = eigenval
        else:
            raise ValueError('Must supply an eigenvalue')
        if size is None:
            raise ValueError('Must supply a matrix size')
        else:
            size2 = as_int(size)
        return klass._eval_jordan_block(size2, e, band)

    @overload
    @classmethod
    def ones(kls, rows: int, cols: int | None=None, *, cls: None=None) -> Self:
        pass

    @overload
    @classmethod
    def ones(kls, rows: int, cols: int | None=None, *, cls: type[Tmat]) -> Tmat:
        pass

    @classmethod
    def ones(kls, rows: int, cols: int | None=None, *, cls: type[Tmat] | None=None) -> Self | Tmat:
        if cols is None:
            cols = rows
        klass = cls if cls is not None else kls
        rows, cols = (as_int(rows), as_int(cols))
        return klass._eval_ones(rows, cols)

    @overload
    @classmethod
    def zeros(kls, rows: int, cols: int | None=None, *, cls: None=None) -> Self:
        pass

    @overload
    @classmethod
    def zeros(kls, rows: int, cols: int | None=None, *, cls: type[Tmat]) -> Tmat:
        pass

    @classmethod
    def zeros(kls, rows: int, cols: int | None=None, *, cls: type[Tmat] | None=None) -> Self | Tmat:
        if cols is None:
            cols = rows
        if rows < 0 or cols < 0:
            raise ValueError('Cannot create a {} x {} matrix. Both dimensions must be positive'.format(rows, cols))
        klass = cls if cls is not None else kls
        rows, cols = (as_int(rows), as_int(cols))
        return klass._eval_zeros(rows, cols)

    @classmethod
    def companion(kls, poly: Poly) -> Self:
        poly = kls._sympify(poly)
        if not isinstance(poly, Poly):
            raise ValueError('{} must be a Poly instance.'.format(poly))
        if not poly.is_monic:
            raise ValueError('{} must be a monic polynomial.'.format(poly))
        if not poly.is_univariate:
            raise ValueError('{} must be a univariate polynomial.'.format(poly))
        size = poly.degree()
        if size < 1:
            raise ValueError(f'{poly} must have degree not less than 1.')
        assert isinstance(size, int)
        coeffs = poly.all_coeffs()

        def entry(i, j):
            if j == size - 1:
                return -coeffs[-1 - i]
            elif i == j + 1:
                return kls.one
            return kls.zero
        return kls._new(size, size, entry)

    @overload
    @classmethod
    def wilkinson(kls, n: int, *, cls: None=None) -> tuple[Self, Self]:
        pass

    @overload
    @classmethod
    def wilkinson(kls, n: int, *, cls: type[Tmat]) -> tuple[Tmat, Tmat]:
        pass

    @classmethod
    def wilkinson(kls, n: int, *, cls: type[Tmat] | None=None) -> tuple[Self, Self] | tuple[Tmat, Tmat]:
        klass = kls if cls is None else cls
        n = as_int(n)
        return klass._eval_wilkinson(n)

    def _eval_iter_values(self) -> Iterator[Expr]:
        return (i for i in self if i is not S.Zero)

    def _eval_values(self) -> list[Expr]:
        return list(self.iter_values())

    def _eval_iter_items(self) -> Iterator[tuple[tuple[int, int], Expr]]:
        for i in range(self.rows):
            for j in range(self.cols):
                if self[i, j]:
                    yield ((i, j), self[i, j])

    @overload
    def _eval_atoms(self) -> set[Basic]:
        pass

    @overload
    def _eval_atoms(self, *types: Tbasic | type[Tbasic]) -> set[Tbasic]:
        pass

    def _eval_atoms(self, *types: Tbasic | type[Tbasic]) -> set[Basic] | set[Tbasic]:
        values = self.values()
        if len(values) < self.rows * self.cols:
            values.append(S.Zero)
        return set().union(*[v.atoms(*types) for v in values])

    def _eval_free_symbols(self) -> set[Basic]:
        return set().union(*(i.free_symbols for i in set(self.values())))

    def _eval_has(self, *patterns: SExpr | Basic | type[Basic]) -> bool:
        return any((a.has(*patterns) for a in self.iter_values()))

    def _eval_is_symbolic(self) -> bool:
        return self.has(Symbol)

    def _eval_is_matrix_hermitian(self, simpfunc: Callable[[Expr], Expr]) -> bool | None:
        herm = lambda i, j: simpfunc(self[i, j] - self[j, i].adjoint()).is_zero
        return fuzzy_and((herm(i, j) for (i, j), v in self.iter_items()))

    def _eval_is_zero_matrix(self) -> bool | None:
        return fuzzy_and((v.is_zero for v in self.iter_values()))

    def _eval_is_Identity(self) -> bool:
        one = self.one
        zero = self.zero
        ident = lambda i, j, v: v is one if i == j else v is zero
        return all((ident(i, j, v) for (i, j), v in self.iter_items()))

    def _eval_is_diagonal(self) -> bool | None:
        return fuzzy_and((v.is_zero for (i, j), v in self.iter_items() if i != j))

    def _eval_is_lower(self) -> bool:
        return all((v.is_zero for (i, j), v in self.iter_items() if i < j))

    def _eval_is_upper(self) -> bool:
        return all((v.is_zero for (i, j), v in self.iter_items() if i > j))

    def _eval_is_lower_hessenberg(self) -> bool:
        return all((v.is_zero for (i, j), v in self.iter_items() if i + 1 < j))

    def _eval_is_upper_hessenberg(self) -> bool:
        return all((v.is_zero for (i, j), v in self.iter_items() if i > j + 1))

    def _eval_is_symmetric(self, simpfunc) -> bool | None:
        sym = lambda i, j: simpfunc(self[i, j] - self[j, i]).is_zero
        return fuzzy_and((sym(i, j) for (i, j), _ in self.iter_items()))

    def _eval_is_anti_symmetric(self, simpfunc) -> bool | None:
        anti = lambda i, j: simpfunc(self[i, j] + self[j, i]).is_zero
        return fuzzy_and((anti(i, j) for (i, j), _ in self.iter_items()))

    def _has_positive_diagonals(self) -> bool | None:
        diagonal_entries = (self[i, i] for i in range(self.rows))
        return fuzzy_and((x.is_positive for x in diagonal_entries))

    def _has_nonnegative_diagonals(self) -> bool | None:
        diagonal_entries = (self[i, i] for i in range(self.rows))
        return fuzzy_and((x.is_nonnegative for x in diagonal_entries))

    @overload
    def atoms(self) -> set[Basic]:
        pass

    @overload
    def atoms(self, *types: Tbasic | type[Tbasic]) -> set[Tbasic]:
        pass

    def atoms(self, *types: Tbasic | type[Tbasic]) -> set[Basic] | set[Tbasic]:
        types = tuple((t if isinstance(t, type) else type(t) for t in types))
        if not types:
            return self._eval_atoms(Atom)
        else:
            return self._eval_atoms(*types)

    @property
    def free_symbols(self) -> set[Basic]:
        return self._eval_free_symbols()

    def has(self, *patterns: SExpr | Basic | type[Basic]) -> bool:
        return self._eval_has(*patterns)

    def is_anti_symmetric(self, simplify: bool | Callable[[Expr], Expr]=True) -> bool | None:
        simpfunc: Callable[[Any], Any]
        if not isfunction(simplify):
            simpfunc = _utilities_simplify if simplify else lambda x: x
        else:
            simpfunc = simplify
        if not self.is_square:
            return False
        return self._eval_is_anti_symmetric(simpfunc)

    def is_diagonal(self) -> bool | None:
        return self._eval_is_diagonal()

    @property
    def is_weakly_diagonally_dominant(self) -> bool | None:
        if not self.is_square:
            return False
        rows, cols = self.shape

        def test_row(i):
            summation = self.zero
            for j in range(cols):
                if i != j:
                    summation += Abs(self[i, j])
            return (Abs(self[i, i]) - summation).is_nonnegative
        return fuzzy_and((test_row(i) for i in range(rows)))

    @property
    def is_strongly_diagonally_dominant(self) -> bool | None:
        if not self.is_square:
            return False
        rows, cols = self.shape

        def test_row(i):
            summation = self.zero
            for j in range(cols):
                if i != j:
                    summation += Abs(self[i, j])
            return (Abs(self[i, i]) - summation).is_positive
        return fuzzy_and((test_row(i) for i in range(rows)))

    @property
    def is_hermitian(self) -> bool | None:
        if not self.is_square:
            return False
        return self._eval_is_matrix_hermitian(_utilities_simplify)

    @property
    def is_Identity(self) -> bool:
        if not self.is_square:
            return False
        return self._eval_is_Identity()

    @property
    def is_lower_hessenberg(self) -> bool:
        return self._eval_is_lower_hessenberg()

    @property
    def is_lower(self) -> bool:
        return self._eval_is_lower()

    @property
    def is_square(self) -> bool:
        return self.rows == self.cols

    def is_symbolic(self) -> bool:
        return self._eval_is_symbolic()

    def is_symmetric(self, simplify: Callable[[Expr], Expr] | bool=True) -> bool | None:
        simpfunc: Callable[[Any], Any]
        if not isfunction(simplify):
            simpfunc = _utilities_simplify if simplify else lambda x: x
        else:
            simpfunc = simplify
        if not self.is_square:
            return False
        return self._eval_is_symmetric(simpfunc)

    @property
    def is_upper_hessenberg(self) -> bool:
        return self._eval_is_upper_hessenberg()

    @property
    def is_upper(self) -> bool:
        return self._eval_is_upper()

    @property
    def is_zero_matrix(self) -> bool | None:
        return self._eval_is_zero_matrix()

    def values(self) -> list[Expr]:
        return self._eval_values()

    def iter_values(self) -> Iterator[Expr]:
        return self._eval_iter_values()

    def iter_items(self) -> Iterator[tuple[tuple[int, int], Expr]]:
        return self._eval_iter_items()

    def _eval_adjoint(self) -> Self:
        return self.transpose().applyfunc(lambda x: x.adjoint())

    def _eval_applyfunc(self, f: Callable[[Expr], Expr]) -> Self:
        cols = self.cols
        size = self.rows * self.cols
        dok = self.todok()
        valmap = {v: f(v) for v in dok.values()}
        if len(dok) < size and (fzero := f(S.Zero)) is not S.Zero:
            out_flat = [fzero] * size
            for (i, j), v in dok.items():
                out_flat[i * cols + j] = valmap[v]
            out = self._new(self.rows, self.cols, out_flat)
        else:
            fdok = {ij: valmap[v] for ij, v in dok.items()}
            out = self.from_dok(self.rows, self.cols, fdok)
        return out

    def _eval_as_real_imag(self) -> tuple[Self, Self]:
        return (self.applyfunc(re), self.applyfunc(im))

    def _eval_conjugate(self) -> Self:
        return self.applyfunc(lambda x: x.conjugate())

    def _eval_permute_cols(self, perm) -> Self:
        mapping = list(perm)

        def entry(i, j):
            return self[i, mapping[j]]
        return self._new(self.rows, self.cols, entry)

    def _eval_permute_rows(self, perm) -> Self:
        mapping = list(perm)

        def entry(i, j):
            return self[mapping[i], j]
        return self._new(self.rows, self.cols, entry)

    def _eval_trace(self) -> Expr:
        return Add(*(self[i, i] for i in range(self.rows)))

    def _eval_transpose(self) -> Self:
        return self._new(self.cols, self.rows, lambda i, j: self[j, i])

    def adjoint(self) -> Self:
        return self._eval_adjoint()

    def applyfunc(self, f: Callable[[Expr], Expr]) -> Self:
        if not callable(f):
            raise TypeError('`f` must be callable.')
        return self._eval_applyfunc(f)

    def as_real_imag(self, deep: bool=True, **hints: Any) -> tuple[Self, Self]:
        return self._eval_as_real_imag()

    def conjugate(self) -> Self:
        return self._eval_conjugate()

    def doit(self, **hints) -> Self:
        return self.applyfunc(lambda x: x.doit(**hints))

    def evalf(self, n: int=15, subs: Mapping[SExpr, SExpr] | None=None, maxn: int=100, chop: bool | int=False, strict: bool=False, quad: Literal['osc'] | str | None=None, verbose: bool=False) -> Self:
        f = lambda i: i.evalf(n, subs=subs, maxn=maxn, chop=chop, strict=strict, quad=quad, verbose=verbose)
        return self.applyfunc(f)

    def n(self, n: int=15, subs: Mapping[SExpr, SExpr] | None=None, maxn: int=100, chop: bool | int=False, strict: bool=False, quad: Literal['osc'] | str | None=None, verbose: bool=False) -> Self:
        return self.evalf(n, subs=subs, maxn=maxn, chop=chop, strict=strict, quad=quad, verbose=verbose)

    def expand(self, deep: bool=True, modulus: int | None=None, power_base: bool=True, power_exp: bool=True, mul: bool=True, log: bool=True, multinomial: bool=True, basic: bool=True, **hints: Any) -> Self:
        return self.applyfunc(lambda x: x.expand(deep, modulus, power_base, power_exp, mul, log, multinomial, basic, **hints))

    @property
    def H(self) -> Self:
        return self.adjoint()

    def permute(self, perm: list[int] | list[list[int]] | Permutation, orientation: Literal['rows', 'cols']='rows', direction: Literal['forward', 'backward']='forward') -> Self:
        from sympy.combinatorics import Permutation
        if direction == 'forwards':
            direction = 'forward'
        if direction == 'backwards':
            direction = 'backward'
        if orientation == 'columns':
            orientation = 'cols'
        if direction not in ('forward', 'backward'):
            raise TypeError("direction='{}' is an invalid kwarg. Try 'forward' or 'backward'".format(direction))
        if orientation not in ('rows', 'cols'):
            raise TypeError("orientation='{}' is an invalid kwarg. Try 'rows' or 'cols'".format(orientation))
        if not isinstance(perm, (Permutation, Iterable)):
            raise ValueError('{} must be a list, a list of lists, or a SymPy permutation object.'.format(perm))
        max_index = self.rows if orientation == 'rows' else self.cols
        if not all((0 <= t <= max_index for t in flatten(list(perm)))):
            raise IndexError('`swap` indices out of range.')
        if perm and (not isinstance(perm, Permutation)) and isinstance(perm[0], Iterable):
            if direction == 'forward':
                perm = list(reversed(perm))
            perm = Permutation(perm, size=max_index + 1)
        else:
            perm = Permutation(perm, size=max_index + 1)
        if orientation == 'rows':
            return self._eval_permute_rows(perm)
        if orientation == 'cols':
            return self._eval_permute_cols(perm)

    def permute_cols(self, swaps: list[int] | list[list[int]] | Permutation, direction: Literal['forward', 'backward']='forward') -> Self:
        return self.permute(swaps, orientation='cols', direction=direction)

    def permute_rows(self, swaps: list[int] | list[list[int]] | Permutation, direction: Literal['forward', 'backward']='forward') -> Self:
        return self.permute(swaps, orientation='rows', direction=direction)

    def refine(self, assumptions: Boolean | bool=True) -> Self:
        return self.applyfunc(lambda x: refine(x, assumptions))

    def replace(self, F, G, map: bool=False, simultaneous: bool=True, exact=None):
        kwargs = {'map': map, 'simultaneous': simultaneous, 'exact': exact}
        if map:
            d = {}

            def func(eij):
                eij, dij = eij.replace(F, G, **kwargs)
                d.update(dij)
                return eij
            M = self.applyfunc(func)
            return (M, d)
        else:
            return self.applyfunc(lambda i: i.replace(F, G, **kwargs))

    def rot90(self, k: int=1) -> Self:
        mod = k % 4
        if mod == 0:
            return self
        elif mod == 1:
            return self[::-1, :].T
        elif mod == 2:
            return self[::-1, ::-1]
        elif mod == 3:
            return self[:, ::-1].T
        else:
            assert False

    def simplify(self, **kwargs: Any) -> Self:
        return self.applyfunc(lambda x: x.simplify(**kwargs))

    @overload
    def subs(self, arg1: Mapping[SBasic, SBasic], arg2: None=None, **kwargs: Any) -> Self:
        pass

    @overload
    def subs(self, arg1: Iterable[tuple[SBasic, SBasic]], arg2: None=None, **kwargs: Any) -> Self:
        pass

    @overload
    def subs(self, arg1: SBasic, arg2: SBasic, **kwargs: Any) -> Self:
        pass

    def subs(self, arg1: Mapping[SBasic, SBasic] | Iterable[tuple[SBasic, SBasic]] | SBasic, arg2: SBasic | None=None, **kwargs: Any) -> Self:
        if arg2 is None and (not isinstance(arg1, (dict, set))) and iter(arg1) and (not is_sequence(arg1)):
            arg1 = list(arg1)
        return self.applyfunc(lambda x: x.subs(arg1, arg2, **kwargs))

    def trace(self) -> Expr:
        if self.rows != self.cols:
            raise NonSquareMatrixError()
        return self._eval_trace()

    def transpose(self) -> Self:
        return self._eval_transpose()

    @property
    def T(self) -> Self:
        return self.transpose()

    @property
    def C(self) -> Self:
        return self.conjugate()

    def xreplace(self, rule: Mapping[SBasic, SBasic]) -> Self:
        return self.applyfunc(lambda x: x.xreplace(rule))

    def _eval_simplify(self, **kwargs: Any) -> Self:
        return self.applyfunc(lambda x: x.simplify(**kwargs))

    def _eval_trigsimp(self, **opts: Any) -> Self:
        from sympy.simplify.trigsimp import trigsimp
        return self.applyfunc(lambda x: trigsimp(x, **opts))

    def upper_triangular(self, k: int=0) -> Self:

        def entry(i, j):
            return self[i, j] if i + k <= j else self.zero
        return self._new(self.rows, self.cols, entry)

    def lower_triangular(self, k: int=0) -> Self:

        def entry(i, j):
            return self[i, j] if i + k >= j else self.zero
        return self._new(self.rows, self.cols, entry)

    def _eval_Abs(self) -> Self:
        return self._new(self.rows, self.cols, lambda i, j: Abs(self[i, j]))

    def _eval_add(self, other: Self) -> Self:
        return self._new(self.rows, self.cols, lambda i, j: self[i, j] + other[i, j])

    def _eval_matrix_mul(self, other: MatrixBase) -> Self:

        def entry(i, j):
            vec = [self[i, k] * other[k, j] for k in range(self.cols)]
            try:
                return Add(*vec)
            except (TypeError, SympifyError):
                return reduce(lambda a, b: a + b, vec)
        return self._new(self.rows, other.cols, entry)

    def _eval_matrix_mul_elementwise(self, other: MatrixBase) -> Self:
        return self._new(self.rows, self.cols, lambda i, j: self[i, j] * other[i, j])

    def _eval_matrix_rmul(self, other: MatrixBase) -> Self:

        def entry(i, j):
            return sum((other[i, k] * self[k, j] for k in range(other.cols)))
        return self._new(other.rows, self.cols, entry)

    def _eval_pow_by_recursion(self, num: int) -> Self:
        if num == 1:
            return self
        if num % 2 == 1:
            a, b = (self, self._eval_pow_by_recursion(num - 1))
        else:
            a = b = self._eval_pow_by_recursion(num // 2)
        return a.multiply(b)

    def _eval_pow_by_cayley(self, exp: int) -> Self:
        from sympy.discrete.recurrences import linrec_coeffs
        row = self.shape[0]
        p = self.charpoly()
        coeffs = (-p).all_coeffs()[1:]
        coeffs = linrec_coeffs(coeffs, exp)
        new_mat = self.eye(row)
        ans = self.zeros(row)
        for i in range(row):
            ans += coeffs[i] * new_mat
            new_mat *= self
        return ans

    def _eval_pow_by_recursion_dotprodsimp(self, num: int, prevsimp: list[bool] | None=None) -> Self:
        if prevsimp is None:
            prevsimp = [True] * len(self)
        if num == 1:
            return self
        if num % 2 == 1:
            a, b = (self, self._eval_pow_by_recursion_dotprodsimp(num - 1, prevsimp=prevsimp))
        else:
            a = b = self._eval_pow_by_recursion_dotprodsimp(num // 2, prevsimp=prevsimp)
        m = a.multiply(b, dotprodsimp=False)
        lenm = len(m)
        elems: list[Expr] = []
        for i in range(lenm):
            if prevsimp[i]:
                ei, prevsimp[i] = _dotprodsimp(m[i], withsimp=True)
            else:
                ei = m[i]
            elems.append(ei)
        return self._new(m.rows, m.cols, elems)

    def _eval_scalar_mul(self, other: SExpr) -> Self:
        return self._new(self.rows, self.cols, lambda i, j: self[i, j] * other)

    def _eval_scalar_rmul(self, other: SExpr) -> Self:
        return self._new(self.rows, self.cols, lambda i, j: other * self[i, j])

    def _eval_Mod(self, other: Expr) -> Self:
        return self._new(self.rows, self.cols, lambda i, j: Mod(self[i, j], other))

    def __abs__(self) -> Self:
        return self._eval_Abs()

    @call_highest_priority('__radd__')
    def __add__(self: Tmat, other: Tmat) -> Tmat:
        other_mat, _ = _coerce_operand(self, other)
        if not isinstance(other_mat, MatrixBase):
            return NotImplemented
        if self.shape != other_mat.shape:
            raise ShapeError(f'Matrix size mismatch: {self.shape} + {other.shape}.')
        a, b = (self, other_mat)
        if a.__class__ != classof(a, b):
            b, a = (a, b)
        return a._eval_add(b)

    @call_highest_priority('__rtruediv__')
    def __truediv__(self, other):
        return self * (self.one / other)

    @call_highest_priority('__rmatmul__')
    def __matmul__(self, other):
        self, other, T = _unify_with_other(self, other)
        if T != 'is_matrix':
            return NotImplemented
        return self.__mul__(other)

    def __mod__(self, other) -> Self:
        return self.applyfunc(lambda x: x % other)

    @overload
    def __mul__(self, other: Self) -> Self:
        pass

    @overload
    def __mul__(self, other: MatrixBase) -> MatrixBase:
        pass

    @overload
    def __mul__(self, other: Expr) -> MatrixBase:
        pass

    @call_highest_priority('__rmul__')
    def __mul__(self, other: MatrixBase | Expr) -> MatrixBase | Expr:
        return self.multiply(other)

    @overload
    def multiply(self, other: Self, dotprodsimp: bool | None=None) -> Self:
        pass

    @overload
    def multiply(self, other: MatrixBase, dotprodsimp: bool | None=None) -> MatrixBase:
        pass

    @overload
    def multiply(self, other: Expr, dotprodsimp: bool | None=None) -> Expr:
        pass

    def multiply(self, other: MatrixBase | Expr, dotprodsimp: bool | None=None) -> MatrixBase | Expr:
        isimpbool = _get_intermediate_simp_bool(False, dotprodsimp)
        self, other, T = _unify_with_other(self, other)
        if isinstance(other, MatrixBase):
            if self.shape[1] != other.shape[0]:
                raise ShapeError(f'Matrix size mismatch: {self.shape} * {other.shape}.')
            m = self._eval_matrix_mul(other)
            if isimpbool:
                m = m._new(m.rows, m.cols, [_dotprodsimp(e) for e in m.flat()])
            return m
        elif T == 'possible_scalar':
            try:
                return self._eval_scalar_mul(other)
            except TypeError:
                return NotImplemented
        else:
            return NotImplemented

    def multiply_elementwise(self, other: MatrixBase) -> Self:
        if self.shape != other.shape:
            raise ShapeError('Matrix shapes must agree {} != {}'.format(self.shape, other.shape))
        return self._eval_matrix_mul_elementwise(other)

    def __neg__(self) -> Self:
        return self._eval_scalar_mul(-1)

    @call_highest_priority('__rpow__')
    def __pow__(self, exp: SExpr) -> MatrixBase | MatrixExpr:
        return self.pow(exp)

    @overload
    def pow(self, exp: int | Integer, method: str | None=None) -> Self:
        pass

    @overload
    def pow(self, exp: SExpr, method: str | None=None) -> MatrixBase | MatrixExpr:
        pass

    def pow(self, exp: SExpr, method: str | None=None) -> MatrixBase | MatrixExpr:
        if method is not None and method not in ['multiply', 'mulsimp', 'jordan', 'cayley']:
            raise TypeError('No such method')
        if self.rows != self.cols:
            raise NonSquareMatrixError()
        a = self
        jordan_pow = getattr(a, '_matrix_pow_by_jordan_blocks', None)
        exp = sympify(exp)
        if exp.is_zero:
            return a._new(a.rows, a.cols, lambda i, j: int(i == j))
        if exp == 1:
            return a
        diagonal = getattr(a, 'is_diagonal', None)
        if diagonal is not None and diagonal():
            return a._new(a.rows, a.cols, lambda i, j: a[i, j] ** exp if i == j else 0)
        if exp.is_Number and exp % 1 == 0:
            if a.rows == 1:
                return a._new([[a[0] ** exp]])
            if exp < 0:
                exp = -exp
                a = a.inv()
        if method == 'jordan' and jordan_pow is not None:
            return jordan_pow(exp)
        elif method == 'cayley':
            if not isinstance(exp, Integer):
                raise ValueError('cayley method is only valid for integer powers')
            return a._eval_pow_by_cayley(exp.p)
        elif method == 'mulsimp':
            if not isinstance(exp, Integer):
                raise ValueError('mulsimp method is only valid for integer powers')
            return a._eval_pow_by_recursion_dotprodsimp(exp.p)
        elif method == 'multiply':
            if not isinstance(exp, Integer):
                raise ValueError('multiply method is only valid for integer powers')
            return a._eval_pow_by_recursion(exp.p)
        elif method is None and isinstance(exp, (Integer, Float)) and (exp % 1 == 0):
            if isinstance(exp, Float):
                expi = Integer(exp)
            else:
                expi = exp
            if a.rows == 2 and expi > 100000 and (jordan_pow is not None):
                return jordan_pow(expi)
            elif _get_intermediate_simp_bool(True, None):
                return a._eval_pow_by_recursion_dotprodsimp(expi.p)
            elif expi > 10000:
                return a._eval_pow_by_cayley(expi.p)
            else:
                return a._eval_pow_by_recursion(expi.p)
        if jordan_pow:
            try:
                return jordan_pow(exp)
            except NonInvertibleMatrixError:
                if exp.is_integer is False or exp.is_nonnegative is False:
                    raise
        from sympy.matrices.expressions import MatPow
        return MatPow(a, exp)

    @call_highest_priority('__add__')
    def __radd__(self, other: MatrixBase) -> MatrixBase:
        return self.__add__(other)

    @call_highest_priority('__matmul__')
    def __rmatmul__(self, other: MatrixBase) -> MatrixBase:
        self, other, T = _unify_with_other(self, other)
        if T != 'is_matrix':
            return NotImplemented
        return self.__rmul__(other)

    @call_highest_priority('__mul__')
    def __rmul__(self, other: MatrixBase | SExpr) -> MatrixBase:
        return self.rmultiply(other)

    def rmultiply(self, other: MatrixBase | SExpr, dotprodsimp: bool | None=None) -> MatrixBase:
        isimpbool = _get_intermediate_simp_bool(False, dotprodsimp)
        self, other_mat, T = _unify_with_other(self, other)
        if isinstance(other_mat, MatrixBase):
            if self.shape[0] != other_mat.shape[1]:
                raise ShapeError('Matrix size mismatch.')
            m = self._eval_matrix_rmul(other_mat)
            if isimpbool:
                return m._new(m.rows, m.cols, [_dotprodsimp(e) for e in m.flat()])
            return m
        elif T == 'possible_scalar':
            try:
                return self._eval_scalar_rmul(other_mat)
            except TypeError:
                return NotImplemented
        else:
            return NotImplemented

    @call_highest_priority('__sub__')
    def __rsub__(self, a: MatrixBase) -> MatrixBase:
        return -self + a

    @call_highest_priority('__rsub__')
    def __sub__(self: Tmat, a: Tmat) -> Tmat:
        return self + -a

    def _eval_det_bareiss(self, iszerofunc=_is_zero_after_expand_mul) -> Expr:
        return _det_bareiss(self, iszerofunc=iszerofunc)

    def _eval_det_berkowitz(self) -> Expr:
        return _det_berkowitz(self)

    def _eval_det_lu(self, iszerofunc=_iszero, simpfunc=None) -> Expr:
        return _det_LU(self, iszerofunc=iszerofunc, simpfunc=simpfunc)

    def _eval_det_bird(self) -> Expr:
        return _det_bird(self)

    def _eval_det_laplace(self) -> Expr:
        return _det_laplace(self)

    def _eval_determinant(self) -> Expr:
        return _det(self)

    def adjugate(self, method: str='berkowitz') -> Self:
        return _adjugate(self, method=method)

    def charpoly(self, x: str | Expr='lambda', simplify=_utilities_simplify) -> Poly:
        return _charpoly(self, x=x, simplify=simplify)

    def cofactor(self, i, j, method: str='berkowitz') -> Expr:
        return _cofactor(self, i, j, method=method)

    def cofactor_matrix(self, method: str='berkowitz') -> Self:
        return _cofactor_matrix(self, method=method)

    def det(self, method: str='bareiss', iszerofunc=None) -> Expr:
        return _det(self, method=method, iszerofunc=iszerofunc)

    def per(self) -> Expr:
        return _per(self)

    def minor(self, i, j, method: str='berkowitz') -> Expr:
        return _minor(self, i, j, method=method)

    def minor_submatrix(self, i, j) -> Self:
        return _minor_submatrix(self, i, j)
    _find_reasonable_pivot.__doc__ = _find_reasonable_pivot.__doc__
    _find_reasonable_pivot_naive.__doc__ = _find_reasonable_pivot_naive.__doc__
    _eval_det_bareiss.__doc__ = _det_bareiss.__doc__
    _eval_det_berkowitz.__doc__ = _det_berkowitz.__doc__
    _eval_det_bird.__doc__ = _det_bird.__doc__
    _eval_det_laplace.__doc__ = _det_laplace.__doc__
    _eval_det_lu.__doc__ = _det_LU.__doc__
    _eval_determinant.__doc__ = _det.__doc__
    adjugate.__doc__ = _adjugate.__doc__
    charpoly.__doc__ = _charpoly.__doc__
    cofactor.__doc__ = _cofactor.__doc__
    cofactor_matrix.__doc__ = _cofactor_matrix.__doc__
    det.__doc__ = _det.__doc__
    per.__doc__ = _per.__doc__
    minor.__doc__ = _minor.__doc__
    minor_submatrix.__doc__ = _minor_submatrix.__doc__

    @overload
    def echelon_form(self, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, with_pivots: Literal[False]=False) -> Self:
        pass

    @overload
    def echelon_form(self, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, with_pivots: Literal[True]) -> tuple[Self, tuple[int]]:
        pass

    def echelon_form(self, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, with_pivots: bool=False) -> Self | tuple[Self, tuple[int]]:
        return _echelon_form(self, iszerofunc=iszerofunc, simplify=simplify, with_pivots=with_pivots)

    @property
    def is_echelon(self) -> bool:
        return _is_echelon(self)

    def rank(self, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False) -> int:
        return _rank(self, iszerofunc=iszerofunc, simplify=simplify)

    def rref_rhs(self, rhs: Self) -> tuple[Self, Self]:
        r, _ = _rref(self.hstack(self, self.eye(self.rows), rhs))
        return (r[:, :self.cols], r[:, -rhs.cols:])

    @overload
    def rref(self, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, pivots: Literal[True]=True, normalize_last: bool=True) -> tuple[Self, tuple[int]]:
        pass

    @overload
    def rref(self, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, pivots: Literal[False], normalize_last: bool=True) -> Self:
        pass

    def rref(self, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, pivots: bool=True, normalize_last: bool=True) -> Self | tuple[Self, tuple[int]]:
        return _rref(self, iszerofunc=iszerofunc, simplify=simplify, pivots=pivots, normalize_last=normalize_last)
    echelon_form.__doc__ = _echelon_form.__doc__
    is_echelon.__doc__ = _is_echelon.__doc__
    rank.__doc__ = _rank.__doc__
    rref.__doc__ = _rref.__doc__

    def _normalize_op_args(self, op: str, col: int | None, k: SExpr | None, col1: int | None, col2: int | None, error_str: str='col') -> tuple[str, int, int, int, int]:
        if op not in ['n->kn', 'n<->m', 'n->n+km']:
            raise ValueError("Unknown {} operation '{}'. Valid col operations are 'n->kn', 'n<->m', 'n->n+km'".format(error_str, op))
        self_cols = self.cols if error_str == 'col' else self.rows
        if op == 'n->kn':
            col = col if col is not None else col1
            if col is None or k is None:
                raise ValueError("For a {0} operation 'n->kn' you must provide the kwargs `{0}` and `k`".format(error_str))
            if not 0 <= col < self_cols:
                raise ValueError("This matrix does not have a {} '{}'".format(error_str, col))
        elif op == 'n<->m':
            cols = {col, k, col1, col2}.difference([None])
            if len(cols) > 2:
                cols = {col, col1, col2}.difference([None])
            if len(cols) != 2:
                raise ValueError("For a {0} operation 'n<->m' you must provide the kwargs `{0}1` and `{0}2`".format(error_str))
            col1, col2 = cols
            if not 0 <= col1 < self_cols:
                raise ValueError("This matrix does not have a {} '{}'".format(error_str, col1))
            if not 0 <= col2 < self_cols:
                raise ValueError("This matrix does not have a {} '{}'".format(error_str, col2))
        elif op == 'n->n+km':
            col = col1 if col is None else col
            col2 = col1 if col2 is None else col2
            if col is None or col2 is None or k is None:
                raise ValueError("For a {0} operation 'n->n+km' you must provide the kwargs `{0}`, `k`, and `{0}2`".format(error_str))
            if col == col2:
                raise ValueError("For a {0} operation 'n->n+km' `{0}` and `{0}2` must be different.".format(error_str))
            if not 0 <= col < self_cols:
                raise ValueError("This matrix does not have a {} '{}'".format(error_str, col))
            if not 0 <= col2 < self_cols:
                raise ValueError("This matrix does not have a {} '{}'".format(error_str, col2))
        else:
            raise ValueError('invalid operation %s' % repr(op))
        return (op, col, k, col1, col2)

    def _eval_col_op_multiply_col_by_const(self, col: int, k: SExpr) -> Self:

        def entry(i, j):
            if j == col:
                return k * self[i, j]
            return self[i, j]
        return self._new(self.rows, self.cols, entry)

    def _eval_col_op_swap(self, col1: int, col2: int) -> Self:

        def entry(i, j):
            if j == col1:
                return self[i, col2]
            elif j == col2:
                return self[i, col1]
            return self[i, j]
        return self._new(self.rows, self.cols, entry)

    def _eval_col_op_add_multiple_to_other_col(self, col: int, k: SExpr, col2: int) -> Self:

        def entry(i, j):
            if j == col:
                return self[i, j] + k * self[i, col2]
            return self[i, j]
        return self._new(self.rows, self.cols, entry)

    def _eval_row_op_swap(self, row1: int, row2: int) -> Self:

        def entry(i, j):
            if i == row1:
                return self[row2, j]
            elif i == row2:
                return self[row1, j]
            return self[i, j]
        return self._new(self.rows, self.cols, entry)

    def _eval_row_op_multiply_row_by_const(self, row: int, k: SExpr) -> Self:

        def entry(i, j):
            if i == row:
                return k * self[i, j]
            return self[i, j]
        return self._new(self.rows, self.cols, entry)

    def _eval_row_op_add_multiple_to_other_row(self, row: int, k: SExpr, row2: int) -> Self:

        def entry(i, j):
            if i == row:
                return self[i, j] + k * self[row2, j]
            return self[i, j]
        return self._new(self.rows, self.cols, entry)

    def elementary_col_op(self, op: str='n->kn', col: int | None=None, k: SExpr | None=None, col1: int | None=None, col2: int | None=None) -> Self:
        op, col, k, col1, col2 = self._normalize_op_args(op, col, k, col1, col2, 'col')
        if op == 'n->kn':
            return self._eval_col_op_multiply_col_by_const(col, k)
        elif op == 'n<->m':
            return self._eval_col_op_swap(col1, col2)
        elif op == 'n->n+km':
            return self._eval_col_op_add_multiple_to_other_col(col, k, col2)
        else:
            raise ValueError(f'invalid operation {op!r}')

    def elementary_row_op(self, op: str='n->kn', row: int | None=None, k: SExpr | None=None, row1: int | None=None, row2: int | None=None) -> Self:
        op, row, k, row1, row2 = self._normalize_op_args(op, row, k, row1, row2, 'row')
        if op == 'n->kn':
            return self._eval_row_op_multiply_row_by_const(row, k)
        elif op == 'n<->m':
            return self._eval_row_op_swap(row1, row2)
        elif op == 'n->n+km':
            return self._eval_row_op_add_multiple_to_other_row(row, k, row2)
        else:
            raise ValueError(f'invalid operation {op!r}')

    def columnspace(self, simplify: bool | Callable[[Expr], Expr]=False) -> list[Self]:
        return _columnspace(self, simplify=simplify)

    def nullspace(self, simplify: bool | Callable[[Expr], Expr]=False, iszerofunc=_iszero) -> list[Self]:
        return _nullspace(self, simplify=simplify, iszerofunc=iszerofunc)

    def rowspace(self, simplify: bool | Callable[[Expr], Expr]=False) -> list[Self]:
        return _rowspace(self, simplify=simplify)

    def orthogonalize(cls, *vecs: Self, **kwargs) -> list[Self]:
        return _orthogonalize(cls, *vecs, **kwargs)
    columnspace.__doc__ = _columnspace.__doc__
    nullspace.__doc__ = _nullspace.__doc__
    rowspace.__doc__ = _rowspace.__doc__
    orthogonalize.__doc__ = _orthogonalize.__doc__
    orthogonalize = classmethod(orthogonalize)

    def eigenvals(self, error_when_incomplete: bool=True, **flags) -> dict[Expr, int]:
        return _eigenvals(self, error_when_incomplete=error_when_incomplete, **flags)

    def eigenvects(self, error_when_incomplete: bool=True, iszerofunc: Callable[[Expr], bool | None]=_iszero, **flags) -> list[tuple[Expr, int, list[Self]]]:
        return _eigenvects(self, error_when_incomplete=error_when_incomplete, iszerofunc=iszerofunc, **flags)

    def is_diagonalizable(self, reals_only: bool=False, **kwargs) -> bool:
        return _is_diagonalizable(self, reals_only=reals_only, **kwargs)

    def diagonalize(self, reals_only: bool=False, sort: bool=False, normalize: bool=False) -> tuple[Self, Self]:
        return _diagonalize(self, reals_only=reals_only, sort=sort, normalize=normalize)

    def bidiagonalize(self, upper: bool=True) -> Self:
        return _bidiagonalize(self, upper=upper)

    def bidiagonal_decomposition(self, upper: bool=True) -> tuple[Self, Self, Self]:
        return _bidiagonal_decomposition(self, upper=upper)

    @property
    def is_positive_definite(self) -> bool | None:
        return _is_positive_definite(self)

    @property
    def is_positive_semidefinite(self) -> bool | None:
        return _is_positive_semidefinite(self)

    @property
    def is_negative_definite(self) -> bool | None:
        return _is_negative_definite(self)

    @property
    def is_negative_semidefinite(self) -> bool | None:
        return _is_negative_semidefinite(self)

    @property
    def is_indefinite(self) -> bool | None:
        return _is_indefinite(self)

    @overload
    def jordan_form(self: Tmat, calc_transform: Literal[True]=True, *, chop: bool=False) -> tuple[Tmat, Tmat]:
        pass

    @overload
    def jordan_form(self: Tmat, calc_transform: Literal[False], *, chop: bool=False) -> Tmat:
        pass

    def jordan_form(self: Tmat, calc_transform: bool=True, *, chop: bool=False) -> tuple[Tmat, Tmat] | Tmat:
        return _jordan_form(self, calc_transform=calc_transform, chop=chop)

    def left_eigenvects(self, **flags: Any) -> list[tuple[Expr, int, list[Self]]]:
        return _left_eigenvects(self, **flags)

    def singular_values(self) -> list[Expr]:
        return _singular_values(self)
    eigenvals.__doc__ = _eigenvals.__doc__
    eigenvects.__doc__ = _eigenvects.__doc__
    is_diagonalizable.__doc__ = _is_diagonalizable.__doc__
    diagonalize.__doc__ = _diagonalize.__doc__
    is_positive_definite.__doc__ = _is_positive_definite.__doc__
    is_positive_semidefinite.__doc__ = _is_positive_semidefinite.__doc__
    is_negative_definite.__doc__ = _is_negative_definite.__doc__
    is_negative_semidefinite.__doc__ = _is_negative_semidefinite.__doc__
    is_indefinite.__doc__ = _is_indefinite.__doc__
    jordan_form.__doc__ = _jordan_form.__doc__
    left_eigenvects.__doc__ = _left_eigenvects.__doc__
    singular_values.__doc__ = _singular_values.__doc__
    bidiagonalize.__doc__ = _bidiagonalize.__doc__
    bidiagonal_decomposition.__doc__ = _bidiagonal_decomposition.__doc__

    def diff(self, *args: Expr | int | tuple[Expr, int], evaluate: bool=True) -> Self:
        from sympy.tensor.array.array_derivatives import ArrayDerivative
        deriv = ArrayDerivative(self, *args, evaluate=evaluate)
        if not isinstance(self, Basic) and evaluate:
            return deriv.as_mutable()
        return deriv

    def _eval_derivative(self, arg: Expr) -> Self:
        return self.applyfunc(lambda x: x.diff(arg))

    def integrate(self, *args: SymbolLimits, **kwargs):
        return self.applyfunc(lambda x: x.integrate(*args, **kwargs))

    def jacobian(self, X: MatrixBase | list[Expr]) -> Self:
        if not isinstance(X, MatrixBase):
            X = self._new(X)
        if self.shape[0] == 1:
            m = self.shape[1]
        elif self.shape[1] == 1:
            m = self.shape[0]
        else:
            raise TypeError('``self`` must be a row or a column matrix')
        if X.shape[0] == 1:
            n = X.shape[1]
        elif X.shape[1] == 1:
            n = X.shape[0]
        else:
            raise TypeError('X must be a row or a column matrix')
        return self._new(m, n, lambda j, i: self[j].diff(X[i]))

    def limit(self, x: Expr, xlim: Expr, dir: str='+') -> Self:
        return self.applyfunc(lambda e: e.limit(x, xlim, dir))

    def berkowitz_charpoly(self, x: str | Expr=Dummy('lambda'), simplify: Callable[[Expr], Expr]=_utilities_simplify) -> Poly:
        return self.charpoly(x=x)

    def berkowitz_det(self) -> Expr:
        return self.det(method='berkowitz')

    def berkowitz_eigenvals(self, **flags: Any) -> dict[Expr, int]:
        return self.eigenvals(**flags)

    def berkowitz_minors(self) -> tuple[Expr]:
        sign, minors = (self.one, [])
        for poly in self.berkowitz():
            minors.append(sign * poly[-1])
            sign = -sign
        return tuple(minors)

    def berkowitz(self) -> tuple[tuple[Expr], ...]:
        from sympy.matrices import zeros
        berk = ((S.One,),)
        if not self:
            return berk
        if not self.is_square:
            raise NonSquareMatrixError()
        A, N = (self, self.rows)
        transforms: list[int | MatrixBase] = [0] * (N - 1)
        for n in range(N, 1, -1):
            T, k = (zeros(n + 1, n), n - 1)
            R, C = (-A[k, :k], A[:k, k])
            A, a = (A[:k, :k], -A[k, k])
            items = [C]
            for i in range(0, n - 2):
                items.append(A * items[i])
            items2 = [self.one, a] + [(R * B)[0, 0] for B in items]
            for i in range(n):
                T[i:, i] = items2[:n - i + 1]
            transforms[k - 1] = T
        polys: list[MatrixBase] = [self._new([self.one, -A[0, 0]])]
        for i, T in enumerate(transforms):
            polys.append(T * polys[i])
        return berk + tuple(((p[0, 0],) for p in polys))

    def cofactorMatrix(self, method: str='berkowitz') -> Self:
        return self.cofactor_matrix(method=method)

    def det_bareis(self) -> Expr:
        return _det_bareiss(self)

    def det_LU_decomposition(self) -> Expr:
        return self.det(method='lu')

    def jordan_cell(self, eigenval: SExpr, n: int) -> Self:
        return self.jordan_block(n, eigenval)

    def jordan_cells(self, calc_transformation: bool=True) -> tuple[Self, list[Self]]:
        P, J = self.jordan_form()
        return (P, J.get_diag_blocks())

    def minorEntry(self, i: int, j: int, method: str='berkowitz') -> Expr:
        return self.minor(i, j, method=method)

    def minorMatrix(self, i: int, j: int) -> Self:
        return self.minor_submatrix(i, j)

    def permuteBkwd(self, perm: list[int] | list[list[int]] | Permutation) -> Self:
        return self.permute_rows(perm, direction='backward')

    def permuteFwd(self, perm: list[int] | list[list[int]] | Permutation) -> Self:
        return self.permute_rows(perm, direction='forward')

    @property
    def kind(self) -> MatrixKind:
        elem_kinds = {e.kind for e in self.flat()}
        if len(elem_kinds) == 1:
            elemkind, = elem_kinds
        else:
            elemkind = UndefinedKind
        return MatrixKind(elemkind)

    def flat(self) -> list[Expr]:
        return [self[i, j] for i in range(self.rows) for j in range(self.cols)]

    def __array__(self, dtype=object, copy=None):
        if copy is not None and (not copy):
            raise TypeError('Cannot implement copy=False when converting Matrix to ndarray')
        from .dense import matrix2numpy
        return matrix2numpy(self, dtype=dtype)

    def __len__(self) -> int:
        return self.rows * self.cols

    def _matrix_pow_by_jordan_blocks(self, num) -> Self:
        from sympy.matrices import diag, MutableMatrix

        def jordan_cell_power(jc, n):
            N = jc.shape[0]
            l = jc[0, 0]
            if l.is_zero:
                if N == 1 and n.is_nonnegative:
                    jc[0, 0] = l ** n
                elif not (n.is_integer and n.is_nonnegative):
                    raise NonInvertibleMatrixError('Non-invertible matrix can only be raised to a nonnegative integer')
                else:
                    for i in range(N):
                        jc[0, i] = KroneckerDelta(i, n)
            else:
                for i in range(N):
                    bn = binomial(n, i)
                    if isinstance(bn, binomial):
                        bn = bn._eval_expand_func()
                    jc[0, i] = l ** (n - i) * bn
            for i in range(N):
                for j in range(1, N - i):
                    jc[j, i + j] = jc[j - 1, i + j - 1]
        P, J = self.jordan_form()
        jordan_cells = J.get_diag_blocks()
        jordan_cells2 = [MutableMatrix(j) for j in jordan_cells]
        for j in jordan_cells2:
            jordan_cell_power(j, num)
        return self._as_type(P.multiply(diag(*jordan_cells2)).multiply(P.inv()))

    def __str__(self):
        if S.Zero in self.shape:
            return 'Matrix(%s, %s, [])' % (self.rows, self.cols)
        return 'Matrix(%s)' % str(self.tolist())

    def _format_str(self, printer=None) -> str:
        if not printer:
            printer = StrPrinter()
        if S.Zero in self.shape:
            return 'Matrix(%s, %s, [])' % (self.rows, self.cols)
        if self.rows == 1:
            return 'Matrix([%s])' % self.table(printer, rowsep=',\n')
        return 'Matrix([\n%s])' % self.table(printer, rowsep=',\n')

    @classmethod
    def irregular(cls, ntop: int, *matrices: Self) -> Self:
        ntop = as_int(ntop)
        b = [i.as_explicit() if hasattr(i, 'as_explicit') else i for i in matrices]
        q = list(range(len(b)))
        dat = [i.rows for i in b]
        active = [q.pop(0) for _ in range(ntop)]
        cols = sum((b[i].cols for i in active))
        rows = []
        while any(dat):
            r = []
            for a, j in enumerate(active):
                r.extend(b[j][-dat[j], :].flat())
                dat[j] -= 1
                if dat[j] == 0 and q:
                    active[a] = q.pop(0)
            if len(r) != cols:
                raise ValueError(filldedent('\n                    Matrices provided do not appear to fill\n                    the space completely.'))
            rows.append(r)
        return cls._new(rows)

    @classmethod
    def _handle_ndarray(cls, arg: Any) -> tuple[int, int, list[Expr]]:
        arr = arg.__array__()
        if len(arr.shape) == 2:
            rows, cols = (arr.shape[0], arr.shape[1])
            flat_list = [cls._sympify(i) for i in arr.ravel()]
            return (rows, cols, flat_list)
        elif len(arr.shape) == 1:
            flat_list = [cls._sympify(i) for i in arr]
            return (arr.shape[0], 1, flat_list)
        else:
            raise NotImplementedError('SymPy supports just 1D and 2D matrices')

    @classmethod
    def _handle_creation_inputs(cls, *args, **kwargs):
        from sympy.matrices import SparseMatrix
        from sympy.matrices.expressions.matexpr import MatrixSymbol
        from sympy.matrices.expressions.blockmatrix import BlockMatrix
        flat_list = None
        if len(args) == 1:
            [arg1] = args
            if isinstance(arg1, SparseMatrix):
                return (arg1.rows, arg1.cols, flatten(arg1.tolist()))
            elif isinstance(arg1, MatrixBase):
                return (arg1.rows, arg1.cols, arg1.flat())
            elif isinstance(arg1, Basic) and arg1.is_Matrix:
                return (arg1.rows, arg1.cols, arg1.as_explicit().flat())
            elif isinstance(args[0], _mpmath_matrix):
                M = args[0]
                flat_list = [cls._sympify(x) for x in M]
                return (M.rows, M.cols, flat_list)
            elif hasattr(args[0], '__array__'):
                return cls._handle_ndarray(args[0])
            elif is_sequence(args[0]) and (not isinstance(args[0], DeferredVector)):
                dat = list(args[0])
                ismat = lambda i: isinstance(i, MatrixBase) and (evaluate or isinstance(i, (BlockMatrix, MatrixSymbol)))
                raw = lambda i: is_sequence(i) and (not ismat(i))
                evaluate = kwargs.get('evaluate', True)
                if evaluate:

                    def make_explicit(x):
                        if isinstance(x, BlockMatrix):
                            return x.as_explicit()
                        elif isinstance(x, MatrixSymbol) and all((_.is_Integer for _ in x.shape)):
                            return x.as_explicit()
                        else:
                            return x

                    def make_explicit_row(row):
                        if isinstance(row, (list, tuple)):
                            return [make_explicit(x) for x in row]
                        else:
                            return make_explicit(row)
                    if isinstance(dat, (list, tuple)):
                        dat = [make_explicit_row(row) for row in dat]
                if len(dat) == 0:
                    rows = cols = 0
                    flat_list = []
                elif all((raw(i) for i in dat)) and len(dat[0]) == 0:
                    if not all((len(i) == 0 for i in dat)):
                        raise ValueError('mismatched dimensions')
                    rows = len(dat)
                    cols = 0
                    flat_list = []
                elif not any((raw(i) or ismat(i) for i in dat)):
                    flat_list = [cls._sympify(i) for i in dat]
                    rows = len(flat_list)
                    cols = 1 if rows else 0
                elif evaluate and all((ismat(i) for i in dat)):
                    ncol = {i.cols for i in dat if any(i.shape)}
                    if ncol:
                        if len(ncol) != 1:
                            raise ValueError('mismatched dimensions')
                        flat_list = [_ for i in dat for r in i.tolist() for _ in r]
                        cols = ncol.pop()
                        rows = len(flat_list) // cols
                    else:
                        rows = cols = 0
                        flat_list = []
                elif evaluate and any((ismat(i) for i in dat)):
                    ncol = set()
                    flat_list = []
                    for i in dat:
                        if ismat(i):
                            flat_list.extend([k for j in i.tolist() for k in j])
                            if any(i.shape):
                                ncol.add(i.cols)
                        elif raw(i):
                            if i:
                                ncol.add(len(i))
                                flat_list.extend([cls._sympify(ij) for ij in i])
                        else:
                            ncol.add(1)
                            flat_list.append(i)
                        if len(ncol) > 1:
                            raise ValueError('mismatched dimensions')
                    cols = ncol.pop()
                    rows = len(flat_list) // cols
                else:
                    flat_list = []
                    ncol = set()
                    rows = cols = 0
                    for row in dat:
                        if not is_sequence(row) and (not getattr(row, 'is_Matrix', False)):
                            raise ValueError('expecting list of lists')
                        if hasattr(row, '__array__'):
                            if 0 in row.shape:
                                continue
                        if evaluate and all((ismat(i) for i in row)):
                            r, c, flatT = cls._handle_creation_inputs([i.T for i in row])
                            T = reshape(flatT, [c])
                            flat = [T[i][j] for j in range(c) for i in range(r)]
                            r, c = (c, r)
                        else:
                            r = 1
                            if getattr(row, 'is_Matrix', False):
                                c = 1
                                flat = [row]
                            else:
                                c = len(row)
                                flat = [cls._sympify(i) for i in row]
                        ncol.add(c)
                        if len(ncol) > 1:
                            raise ValueError('mismatched dimensions')
                        flat_list.extend(flat)
                        rows += r
                    cols = ncol.pop() if ncol else 0
        elif len(args) == 3:
            rows = as_int(args[0])
            cols = as_int(args[1])
            if rows < 0 or cols < 0:
                raise ValueError('Cannot create a {} x {} matrix. Both dimensions must be positive'.format(rows, cols))
            if len(args) == 3 and isinstance(args[2], Callable):
                op = args[2]
                flat_list = []
                for i in range(rows):
                    flat_list.extend([cls._sympify(op(cls._sympify(i), cls._sympify(j))) for j in range(cols)])
            elif len(args) == 3 and is_sequence(args[2]):
                flat_list = args[2]
                if len(flat_list) != rows * cols:
                    raise ValueError('List length should be equal to rows*columns')
                flat_list = [cls._sympify(i) for i in flat_list]
        elif len(args) == 0:
            rows = cols = 0
            flat_list = []
        else:
            raise TypeError('Need 0, 1 or 3 arguments')
        if flat_list is None:
            raise TypeError(filldedent('\n                Data type not understood; expecting list of lists\n                or lists of values.'))
        return (rows, cols, flat_list)

    def add(self, b: Self) -> Self:
        return self + b

    def condition_number(self) -> Expr:
        if not self:
            return self.zero
        singularvalues = self.singular_values()
        return Max(*singularvalues) / Min(*singularvalues)

    def copy(self) -> Self:
        return self._new(self.rows, self.cols, self.flat())

    def cross(self, b: MatrixExpr) -> Self:
        from sympy.matrices.expressions.matexpr import MatrixExpr
        if not isinstance(b, (MatrixBase, MatrixExpr)):
            raise TypeError('{} must be a Matrix, not {}.'.format(b, type(b)))
        if not self.rows * self.cols == b.rows * b.cols == 3:
            raise ShapeError('Dimensions incorrect for cross product: %s x %s' % ((self.rows, self.cols), (b.rows, b.cols)))
        else:
            return self._new(self.rows, self.cols, (self[1] * b[2] - self[2] * b[1], self[2] * b[0] - self[0] * b[2], self[0] * b[1] - self[1] * b[0]))

    def hat(self) -> Self:
        if self.shape != (3, 1):
            raise ShapeError('Dimensions incorrect, expected (3, 1), got ' + str(self.shape))
        else:
            x, y, z = self.flat()
            return self._new(3, 3, (0, -z, y, z, 0, -x, -y, x, 0))

    def vee(self) -> Self:
        if self.shape != (3, 3):
            raise ShapeError('Dimensions incorrect, expected (3, 3), got ' + str(self.shape))
        elif not self.is_anti_symmetric():
            raise ValueError('Matrix is not skew-symmetric')
        else:
            return self._new(3, 1, (self[2, 1], self[0, 2], self[1, 0]))

    @property
    def D(self) -> Self:
        from sympy.physics.matrices import mgamma
        if self.rows != 4:
            raise AttributeError
        return self.H * self._as_type(mgamma(0))

    def dot(self, b: MatrixBase | Expr, hermitian: bool | None=None, conjugate_convention: str | None=None) -> Expr:
        from .dense import Matrix
        if not isinstance(b, MatrixBase):
            if is_sequence(b):
                if len(b) != self.cols and len(b) != self.rows:
                    raise ShapeError('Dimensions incorrect for dot product: %s, %s' % (self.shape, len(b)))
                return self.dot(Matrix(b))
            else:
                raise TypeError('`b` must be an ordered iterable or Matrix, not %s.' % type(b))
        if 1 not in self.shape or 1 not in b.shape:
            raise ShapeError
        if len(self) != len(b):
            raise ShapeError('Dimensions incorrect for dot product: %s, %s' % (self.shape, b.shape))
        mat = self
        n = len(mat)
        if mat.shape != (1, n):
            mat = mat.reshape(1, n)
        if b.shape != (n, 1):
            b = b.reshape(n, 1)
        if conjugate_convention is not None and hermitian is None:
            hermitian = True
        if hermitian and conjugate_convention is None:
            conjugate_convention = 'maths'
        if hermitian == True:
            if conjugate_convention in ('maths', 'left', 'math'):
                mat = mat.conjugate()
            elif conjugate_convention in ('physics', 'right'):
                b = b.conjugate()
            else:
                raise ValueError('Unknown conjugate_convention was entered. conjugate_convention must be one of the following: math, maths, left, physics or right.')
        return (mat * b)[0]

    def dual(self) -> MatrixBase:
        from sympy.matrices import zeros
        M, n = (self[:, :], self.rows)
        work = zeros(n)
        if self.is_symmetric():
            return work
        for i in range(1, n):
            for j in range(1, n):
                acum = S.Zero
                for k in range(1, n):
                    acum += LeviCivita(i, j, 0, k) * M[0, k]
                work[i, j] = acum
                work[j, i] = -acum
        for l in range(1, n):
            acum = S.Zero
            for a in range(1, n):
                for b in range(1, n):
                    acum += LeviCivita(0, l, a, b) * M[a, b]
            acum /= 2
            work[0, l] = -acum
            work[l, 0] = acum
        return work

    def _eval_matrix_exp_jblock(self) -> Self:
        size = self.rows
        l = self[0, 0]
        exp_l = exp(l)
        bands = {i: exp_l / factorial(i) for i in range(size)}
        from .sparsetools import banded
        return self._as_type(banded(size, bands))

    def analytic_func(self, f, x) -> Self:
        f, x = (_sympify(f), _sympify(x))
        if not self.is_square:
            raise NonSquareMatrixError
        if not x.is_symbol:
            raise ValueError('{} must be a symbol.'.format(x))
        if x not in f.free_symbols:
            raise ValueError('{} must be a parameter of {}.'.format(x, f))
        if x in self.free_symbols:
            raise ValueError('{} must not be a parameter of {}.'.format(x, self))
        eigen = self.eigenvals()
        max_mul = max(eigen.values())
        derivative = {}
        dd = f
        for ii in range(max_mul - 1):
            dd = diff(dd, x)
            derivative[ii + 1] = dd
        n = self.shape[0]
        r: list[list[Expr]] = [[S.Zero] * n for _ in range(n)]
        f_val = [S.Zero] * n
        row = 0
        for i in eigen:
            mul = eigen[i]
            f_val[row] = f.subs(x, i)
            if f_val[row].is_number and (not f_val[row].is_complex):
                raise ValueError('Cannot evaluate the function because the function {} is not analytic at the given eigenvalue {}'.format(f, f_val[row]))
            val = S.One
            for a in range(n):
                r[row][a] = val
                val *= i
            if mul > 1:
                coe = [1] * n
                deri = 1
                while mul > 1:
                    row = row + 1
                    mul -= 1
                    d_i = derivative[deri].subs(x, i)
                    if d_i.is_number and (not d_i.is_complex):
                        raise ValueError('Cannot evaluate the function because the derivative {} is not analytic at the given eigenvalue {}'.format(derivative[deri], d_i))
                    f_val[row] = d_i
                    for a in range(n):
                        if a - deri + 1 <= 0:
                            r[row][a] = S.Zero
                            coe[a] = 0
                            continue
                        coe[a] = coe[a] * (a - deri + 1)
                        r[row][a] = coe[a] * pow(i, a - deri)
                    deri += 1
            row += 1
        c = self._new(r).solve(self._new(f_val))
        ans = self.zeros(n)
        pre = self.eye(n)
        for i2 in range(n):
            ans = ans + c[i2] * pre
            pre *= self
        return ans

    def exp(self):
        if not self.is_square:
            raise NonSquareMatrixError('Exponentiation is valid only for square matrices')
        try:
            P, J = self.jordan_form()
            cells = J.get_diag_blocks()
        except MatrixError:
            raise NotImplementedError('Exponentiation is implemented only for matrices for which the Jordan normal form can be computed')
        blocks = [cell._eval_matrix_exp_jblock() for cell in cells]
        eJ = self.diag(*blocks)
        ret = P.multiply(eJ, dotprodsimp=None).multiply(P.inv(), dotprodsimp=None)
        if all((value.is_real for value in self.values())):
            return self._as_type(re(ret))
        else:
            return self._as_type(ret)

    def _eval_matrix_log_jblock(self) -> Self:
        size = self.rows
        l = self[0, 0]
        if l.is_zero:
            raise MatrixError('Could not take logarithm or reciprocal for the given eigenvalue {}'.format(l))
        bands = {0: log(l)}
        for i in range(1, size):
            bands[i] = -(-l) ** (-i) / i
        from .sparsetools import banded
        return self._as_type(banded(size, bands))

    def log(self, simplify: Callable[[Self], Self] | Literal[False]=cancel) -> Self:
        if not self.is_square:
            raise NonSquareMatrixError('Logarithm is valid only for square matrices')
        try:
            if simplify:
                P, J = simplify(self).jordan_form()
            else:
                P, J = self.jordan_form()
            cells = J.get_diag_blocks()
        except MatrixError:
            raise NotImplementedError('Logarithm is implemented only for matrices for which the Jordan normal form can be computed')
        blocks = [cell._eval_matrix_log_jblock() for cell in cells]
        eJ = self.diag(*blocks)
        if simplify:
            ret = simplify(P * eJ * simplify(P.inv()))
            ret = self._new(ret)
        else:
            ret = P * eJ * P.inv()
        return ret

    def is_nilpotent(self) -> bool:
        if not self:
            return True
        if not self.is_square:
            raise NonSquareMatrixError('Nilpotency is valid only for square matrices')
        x = uniquely_named_symbol('x', self, modify=lambda s: '_' + s)
        p = self.charpoly(x)
        if p.args[0] == x ** self.rows:
            return True
        return False

    def key2bounds(self, keys: tuple[int | slice, int | slice]) -> tuple[int, int, int, int]:
        i, j = keys
        if isinstance(i, slice):
            if not self.rows:
                rlo = rhi = 0
            else:
                rlo, rhi = i.indices(self.rows)[:2]
        else:
            rlo = a2idx(i, self.rows)
            rhi = rlo + 1
        if isinstance(j, slice):
            if not self.cols:
                clo = chi = 0
            else:
                clo, chi = j.indices(self.cols)[:2]
        else:
            clo = a2idx(j, self.cols)
            chi = clo + 1
        return (rlo, rhi, clo, chi)

    def key2ij(self, key: int | slice | tuple[int | slice, int | slice]) -> tuple[int, int]:
        if is_sequence(key):
            if not len(key) == 2:
                raise TypeError('key must be a sequence of length 2')
            return [a2idx(i, n) if not isinstance(i, slice) else i for i, n in zip(key, self.shape)]
        elif isinstance(key, slice):
            return key.indices(len(self))[:2]
        else:
            return divmod(a2idx(key, len(self)), self.cols)

    def normalized(self, iszerofunc: Callable[[Expr], bool | None]=_iszero) -> Self:
        if self.rows != 1 and self.cols != 1:
            raise ShapeError('A Matrix must be a vector to normalize.')
        norm = self.norm()
        if iszerofunc(norm):
            out = self.zeros(self.rows, self.cols)
        else:
            out = self.applyfunc(lambda i: i / norm)
        return out

    def norm(self, ord: int | str | None=2) -> Expr:
        vals = list(self.values()) or [S.Zero]
        if S.One in self.shape:
            if ord == 2:
                return sqrt(Add(*(abs(i) ** 2 for i in vals)))
            elif ord == 1:
                return Add(*(abs(i) for i in vals))
            elif ord is S.Infinity:
                return Max(*[abs(i) for i in vals])
            elif ord is S.NegativeInfinity:
                return Min(*[abs(i) for i in vals])
            try:
                return Pow(Add(*(abs(i) ** ord for i in vals)), S.One / ord)
            except (NotImplementedError, TypeError):
                raise ValueError('Expected order to be Number, Symbol, oo')
        elif ord == 1:
            m = self.applyfunc(abs)
            return Max(*[sum(m.col(i).flat()) for i in range(m.cols)])
        elif ord == 2:
            return Max(*self.singular_values())
        elif ord == -2:
            return Min(*self.singular_values())
        elif ord is S.Infinity:
            m = self.applyfunc(abs)
            return Max(*[sum(m.row(i).flat()) for i in range(m.rows)])
        elif ord is None or (isinstance(ord, str) and ord.lower() in ['f', 'fro', 'frobenius', 'vector']):
            return self.vec().norm(ord=2)
        else:
            raise NotImplementedError('Matrix Norms under development')

    def print_nonzero(self, symb: str='X') -> None:
        s = []
        for i in range(self.rows):
            line = []
            for j in range(self.cols):
                if self[i, j] == 0:
                    line.append(' ')
                else:
                    line.append(str(symb))
            s.append('[%s]' % ''.join(line))
        print('\n'.join(s))

    def project(self, v: MatrixBase) -> MatrixBase:
        return v * (self.dot(v) / v.dot(v))

    def table(self, printer, rowstart: str='[', rowend: str=']', rowsep: str='\n', colsep: str=', ', align: str='right'):
        if S.Zero in self.shape:
            return '[]'
        table: list[list[str]] = []
        maxlen = [0] * self.cols
        for i in range(self.rows):
            table.append([])
            for j in range(self.cols):
                s = printer._print(self[i, j])
                table[-1].append(s)
                maxlen[j] = max(len(s), maxlen[j])
        align = {'left': 'ljust', 'right': 'rjust', 'center': 'center', '<': 'ljust', '>': 'rjust', '^': 'center'}[align]
        res = [''] * len(table)
        for i, row in enumerate(table):
            for j, elem in enumerate(row):
                row[j] = getattr(elem, align)(maxlen[j])
            res[i] = rowstart + colsep.join(row) + rowend
        return rowsep.join(res)

    def rank_decomposition(self, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False) -> tuple[Self, Self]:
        return _rank_decomposition(self, iszerofunc=iszerofunc, simplify=simplify)

    @abstractmethod
    def cholesky(self, hermitian: bool=True) -> Self:
        raise NotImplementedError('This function is implemented in DenseMatrix or SparseMatrix')

    @abstractmethod
    def LDLdecomposition(self, hermitian: bool=True) -> tuple[Self, Self]:
        raise NotImplementedError('This function is implemented in DenseMatrix or SparseMatrix')

    def LUdecomposition(self, iszerofunc: Callable[[Expr], bool | None]=_iszero, simpfunc: Callable[[Expr], Expr] | None=None, rankcheck: bool=False) -> tuple[Self, Self, list[list[int]]]:
        return _LUdecomposition(self, iszerofunc=iszerofunc, simpfunc=simpfunc, rankcheck=rankcheck)

    def LUdecomposition_Simple(self, iszerofunc: Callable[[Expr], bool | None]=_iszero, simpfunc: Callable[[Expr], Expr] | None=None, rankcheck: bool=False) -> tuple[Self, list[list[int]]]:
        return _LUdecomposition_Simple(self, iszerofunc=iszerofunc, simpfunc=simpfunc, rankcheck=rankcheck)

    def LUdecompositionFF(self) -> tuple[Self, Self, Self, Self]:
        P, L, D, U = _LUdecompositionFF(self)
        return (self._as_type(P), self._as_type(L), self._as_type(D), self._as_type(U))

    def singular_value_decomposition(self) -> tuple[Self, Self, Self]:
        return _singular_value_decomposition(self)

    def QRdecomposition(self) -> tuple[Self, Self]:
        return _QRdecomposition(self)

    def upper_hessenberg_decomposition(self) -> tuple[Self, Self]:
        return _upper_hessenberg_decomposition(self)

    def diagonal_solve(self, rhs) -> Self:
        return _diagonal_solve(self, rhs)

    @abstractmethod
    def lower_triangular_solve(self, rhs: MatrixBase) -> Self:
        raise NotImplementedError('This function is implemented in DenseMatrix or SparseMatrix')

    @abstractmethod
    def upper_triangular_solve(self, rhs: MatrixBase) -> Self:
        raise NotImplementedError('This function is implemented in DenseMatrix or SparseMatrix')

    def cholesky_solve(self, rhs) -> Self:
        return _cholesky_solve(self, rhs)

    def LDLsolve(self, rhs) -> Self:
        return _LDLsolve(self, rhs)

    def LUsolve(self, rhs, iszerofunc=_iszero) -> Self:
        return _LUsolve(self, rhs, iszerofunc=iszerofunc)

    def QRsolve(self, b) -> Self:
        return _QRsolve(self, b)

    @overload
    def gauss_jordan_solve(self, B: MatrixBase, freevar: Literal[False]=False) -> tuple[Self, Self]:
        pass

    @overload
    def gauss_jordan_solve(self, B: MatrixBase, freevar: Literal[True]) -> tuple[Self, Self, list[int]]:
        pass

    def gauss_jordan_solve(self, B, freevar: bool=False) -> tuple[Self, Self] | tuple[Self, Self, list[int]]:
        return _gauss_jordan_solve(self, B, freevar=freevar)

    def pinv_solve(self, B, arbitrary_matrix=None) -> Self:
        return _pinv_solve(self, B, arbitrary_matrix=arbitrary_matrix)

    def cramer_solve(self, rhs: Self, det_method: str='laplace') -> Self:
        return _cramer_solve(self, rhs, det_method=det_method)

    def solve(self, rhs: Self, method: str='GJ') -> Self:
        return _solve(self, rhs, method=method)

    def solve_least_squares(self, rhs: Self, method: str='CH') -> Self:
        return _solve_least_squares(self, rhs, method=method)

    def pinv(self, method: str='RD') -> Self:
        return _pinv(self, method=method)

    def inverse_ADJ(self, iszerofunc: Callable[[Expr], bool | None]=_iszero) -> Self:
        return _inv_ADJ(self, iszerofunc=iszerofunc)

    def inverse_BLOCK(self, iszerofunc: Callable[[Expr], bool | None]=_iszero) -> Self:
        return self._as_type(_inv_block(self, iszerofunc=iszerofunc))

    def inverse_GE(self, iszerofunc=_iszero) -> Self:
        return _inv_GE(self, iszerofunc=iszerofunc)

    def inverse_LU(self, iszerofunc=_iszero) -> Self:
        return _inv_LU(self, iszerofunc=iszerofunc)

    def inverse_CH(self, iszerofunc=_iszero) -> Self:
        return _inv_CH(self, iszerofunc=iszerofunc)

    def inverse_LDL(self, iszerofunc=_iszero) -> Self:
        return _inv_LDL(self, iszerofunc=iszerofunc)

    def inverse_QR(self, iszerofunc=_iszero) -> Self:
        return _inv_QR(self, iszerofunc=iszerofunc)

    def inv(self, method: str | None=None, iszerofunc: Callable[[Expr], bool | None]=_iszero, try_block_diag: bool=False) -> Self:
        return _inv(self, method=method, iszerofunc=iszerofunc, try_block_diag=try_block_diag)

    def connected_components(self) -> list[list[int]]:
        return _connected_components(self)

    def connected_components_decomposition(self) -> tuple[PermutationMatrix, BlockDiagMatrix]:
        return _connected_components_decomposition(self)

    def strongly_connected_components(self) -> list[list[int]]:
        return _strongly_connected_components(self)

    def strongly_connected_components_decomposition(self, lower: bool=True) -> tuple[PermutationMatrix, BlockMatrix]:
        return _strongly_connected_components_decomposition(self, lower=lower)
    _sage_ = Basic._sage_
    rank_decomposition.__doc__ = _rank_decomposition.__doc__
    cholesky.__doc__ = _cholesky.__doc__
    LDLdecomposition.__doc__ = _LDLdecomposition.__doc__
    LUdecomposition.__doc__ = _LUdecomposition.__doc__
    LUdecomposition_Simple.__doc__ = _LUdecomposition_Simple.__doc__
    LUdecompositionFF.__doc__ = _LUdecompositionFF.__doc__
    singular_value_decomposition.__doc__ = _singular_value_decomposition.__doc__
    QRdecomposition.__doc__ = _QRdecomposition.__doc__
    upper_hessenberg_decomposition.__doc__ = _upper_hessenberg_decomposition.__doc__
    diagonal_solve.__doc__ = _diagonal_solve.__doc__
    lower_triangular_solve.__doc__ = _lower_triangular_solve.__doc__
    upper_triangular_solve.__doc__ = _upper_triangular_solve.__doc__
    cholesky_solve.__doc__ = _cholesky_solve.__doc__
    LDLsolve.__doc__ = _LDLsolve.__doc__
    LUsolve.__doc__ = _LUsolve.__doc__
    QRsolve.__doc__ = _QRsolve.__doc__
    gauss_jordan_solve.__doc__ = _gauss_jordan_solve.__doc__
    pinv_solve.__doc__ = _pinv_solve.__doc__
    cramer_solve.__doc__ = _cramer_solve.__doc__
    solve.__doc__ = _solve.__doc__
    solve_least_squares.__doc__ = _solve_least_squares.__doc__
    pinv.__doc__ = _pinv.__doc__
    inverse_ADJ.__doc__ = _inv_ADJ.__doc__
    inverse_GE.__doc__ = _inv_GE.__doc__
    inverse_LU.__doc__ = _inv_LU.__doc__
    inverse_CH.__doc__ = _inv_CH.__doc__
    inverse_LDL.__doc__ = _inv_LDL.__doc__
    inverse_QR.__doc__ = _inv_QR.__doc__
    inverse_BLOCK.__doc__ = _inv_block.__doc__
    inv.__doc__ = _inv.__doc__
    connected_components.__doc__ = _connected_components.__doc__
    connected_components_decomposition.__doc__ = _connected_components_decomposition.__doc__
    strongly_connected_components.__doc__ = _strongly_connected_components.__doc__
    strongly_connected_components_decomposition.__doc__ = _strongly_connected_components_decomposition.__doc__

def _convert_matrix(typ, mat):
    from sympy.matrices.matrixbase import MatrixBase
    if getattr(mat, 'is_Matrix', False) and (not isinstance(mat, MatrixBase)):
        return typ(*mat.shape, list(mat))
    else:
        return typ(mat)

def _has_matrix_shape(other):
    shape = getattr(other, 'shape', None)
    if shape is None:
        return False
    return isinstance(shape, tuple) and len(shape) == 2

def _has_rows_cols(other):
    return hasattr(other, 'rows') and hasattr(other, 'cols')

def _coerce_operand(self, other: Any) -> tuple[None, Literal['invalid_type']] | tuple[MatrixBase, Literal['is_matrix']] | tuple[Expr, Literal['possible_scalar']]:
    if isinstance(other, NDimArray):
        return (None, 'invalid_type')
    is_Matrix = getattr(other, 'is_Matrix', None)
    if is_Matrix:
        return (other, 'is_matrix')
    if is_Matrix is None:
        if _has_matrix_shape(other) or _has_rows_cols(other):
            return (_convert_matrix(type(self), other), 'is_matrix')
    if not isinstance(other, Iterable):
        return (other, 'possible_scalar')
    return (None, 'invalid_type')

def classof(A: Tmat, B: Tmat) -> type[Tmat]:
    priority_A = getattr(A, '_class_priority', None)
    priority_B = getattr(B, '_class_priority', None)
    if None not in (priority_A, priority_B):
        if A._class_priority > B._class_priority:
            return A.__class__
        else:
            return B.__class__
    try:
        import numpy
    except ImportError:
        pass
    else:
        if isinstance(A, numpy.ndarray):
            return B.__class__
        if isinstance(B, numpy.ndarray):
            return A.__class__
    raise TypeError('Incompatible classes %s, %s' % (A.__class__, B.__class__))

@overload
def _unify_with_other(self: Tmat, other: Tmat) -> tuple[Tmat, Tmat, Literal['is_matrix']]:
    pass

@overload
def _unify_with_other(self: Tmat, other: SExpr) -> tuple[Tmat, Expr, Literal['possible_scalar']]:
    pass

def _unify_with_other(self: MatrixBase, other: Any) -> tuple[MatrixBase, MatrixBase | Expr, str]:
    other, T = _coerce_operand(self, other)
    if isinstance(other, MatrixBase):
        typ = classof(self, other)
        if typ != self.__class__:
            self = _convert_matrix(typ, self)
        if typ != other.__class__:
            other = _convert_matrix(typ, other)
    return (self, other, T)

def a2idx(j, n=None):
    if not isinstance(j, int):
        jindex = getattr(j, '__index__', None)
        if jindex is not None:
            j = jindex()
        else:
            raise IndexError('Invalid index a[%r]' % (j,))
    if n is not None:
        if j < 0:
            j += n
        if not (j >= 0 and j < n):
            raise IndexError('Index out of range: a[%s]' % (j,))
    return int(j)

class DeferredVector(Symbol, NotIterable):

    def __getitem__(self, i):
        if i == -0:
            i = 0
        if i < 0:
            raise IndexError('DeferredVector index out of range')
        component_name = '%s[%d]' % (self.name, i)
        return Symbol(component_name)

    def __str__(self):
        return sstr(self)

    def __repr__(self):
        return "DeferredVector('%s')" % self.name