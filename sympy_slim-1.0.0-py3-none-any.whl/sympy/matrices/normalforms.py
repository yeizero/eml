from __future__ import annotations
from sympy.polys.domains.integerring import ZZ
from sympy.polys.polytools import Poly
from sympy.polys.matrices import DomainMatrix
from sympy.polys.matrices.normalforms import smith_normal_form as _snf, is_smith_normal_form as _is_snf, smith_normal_decomp as _snd, invariant_factors as _invf, hermite_normal_form as _hnf

def _to_domain(m, domain=None):
    ring = getattr(m, 'ring', None)
    m = m.applyfunc(lambda e: e.as_expr() if isinstance(e, Poly) else e)
    dM = DomainMatrix.from_Matrix(m)
    domain = domain or ring
    if domain is not None:
        dM = dM.convert_to(domain)
    return dM

def smith_normal_form(m, domain=None):
    dM = _to_domain(m, domain)
    return _snf(dM).to_Matrix()

def is_smith_normal_form(m, domain=None):
    dM = _to_domain(m, domain)
    return _is_snf(dM)

def smith_normal_decomp(m, domain=None):
    dM = _to_domain(m, domain)
    a, s, t = _snd(dM)
    return (a.to_Matrix(), s.to_Matrix(), t.to_Matrix())

def invariant_factors(m, domain=None):
    dM = _to_domain(m, domain)
    factors = _invf(dM)
    factors = tuple((dM.domain.to_sympy(f) for f in factors))
    if hasattr(m, 'ring'):
        if m.ring.is_PolynomialRing:
            K = m.ring
            to_poly = lambda f: Poly(f, K.symbols, domain=K.domain)
            factors = tuple((to_poly(f) for f in factors))
    return factors

def hermite_normal_form(A, *, D=None, check_rank=False):
    if D is not None and (not ZZ.of_type(D)):
        D = ZZ(int(D))
    return _hnf(A._rep, D=D, check_rank=check_rank).to_Matrix()