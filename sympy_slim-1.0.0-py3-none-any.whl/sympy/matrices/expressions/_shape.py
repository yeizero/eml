from __future__ import annotations
from sympy.core.relational import Eq
from sympy.core.numbers import Integer
from sympy.logic.boolalg import Boolean, And
from sympy.matrices.expressions.matexpr import MatrixExpr
from sympy.matrices.exceptions import ShapeError
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from sympy.core.expr import Expr

def is_matadd_valid(*args: MatrixExpr) -> Boolean:
    rows, cols = zip(*(arg.shape for arg in args))
    return And(*(Eq(i, j) for i, j in zip(rows[:-1], rows[1:])), *(Eq(i, j) for i, j in zip(cols[:-1], cols[1:])))

def is_matmul_valid(*args: MatrixExpr | Expr) -> Boolean:
    rows, cols = zip(*(arg.shape for arg in args if isinstance(arg, MatrixExpr)))
    return And(*(Eq(i, j) for i, j in zip(cols[:-1], rows[1:])))

def is_square(arg: MatrixExpr, /) -> Boolean:
    return Eq(arg.rows, arg.cols)

def validate_matadd_integer(*args: MatrixExpr) -> None:
    rows, cols = zip(*(x.shape for x in args))
    if len(set(filter(lambda x: isinstance(x, (int, Integer)), rows))) > 1:
        raise ShapeError(f'Matrices have mismatching shape: {rows}')
    if len(set(filter(lambda x: isinstance(x, (int, Integer)), cols))) > 1:
        raise ShapeError(f'Matrices have mismatching shape: {cols}')

def validate_matmul_integer(*args: MatrixExpr) -> None:
    for A, B in zip(args[:-1], args[1:]):
        i, j = (A.cols, B.rows)
        if isinstance(i, (int, Integer)) and isinstance(j, (int, Integer)) and (i != j):
            raise ShapeError('Matrices are not aligned', i, j)