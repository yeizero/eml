from __future__ import annotations
from sympy.core.sympify import _sympify
from sympy.matrices.expressions import MatrixExpr
from sympy.core.numbers import I
from sympy.core.singleton import S
from sympy.functions.elementary.exponential import exp
from sympy.functions.elementary.miscellaneous import sqrt

class DFT(MatrixExpr):

    def __new__(cls, n):
        n = _sympify(n)
        cls._check_dim(n)
        obj = super().__new__(cls, n)
        return obj
    n = property(lambda self: self.args[0])
    shape = property(lambda self: (self.n, self.n))

    def _entry(self, i, j, **kwargs):
        w = exp(-2 * S.Pi * I / self.n)
        return w ** (i * j) / sqrt(self.n)

    def _eval_inverse(self):
        return IDFT(self.n)

class IDFT(DFT):

    def _entry(self, i, j, **kwargs):
        w = exp(-2 * S.Pi * I / self.n)
        return w ** (-i * j) / sqrt(self.n)

    def _eval_inverse(self):
        return DFT(self.n)