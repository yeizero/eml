from __future__ import annotations
from .matexpr import MatrixExpr
from sympy.core.function import FunctionClass, Lambda
from sympy.core.symbol import Dummy
from sympy.core.sympify import _sympify, sympify
from sympy.matrices import Matrix
from sympy.functions.elementary.complexes import re, im

class FunctionMatrix(MatrixExpr):

    def __new__(cls, rows, cols, lamda):
        rows, cols = (_sympify(rows), _sympify(cols))
        cls._check_dim(rows)
        cls._check_dim(cols)
        lamda = sympify(lamda)
        if not isinstance(lamda, (FunctionClass, Lambda)):
            raise ValueError('{} should be compatible with SymPy function classes.'.format(lamda))
        if 2 not in lamda.nargs:
            raise ValueError('{} should be able to accept 2 arguments.'.format(lamda))
        if not isinstance(lamda, Lambda):
            i, j = (Dummy('i'), Dummy('j'))
            lamda = Lambda((i, j), lamda(i, j))
        return super().__new__(cls, rows, cols, lamda)

    @property
    def shape(self):
        return self.args[0:2]

    @property
    def lamda(self):
        return self.args[2]

    def _entry(self, i, j, **kwargs):
        return self.lamda(i, j)

    def _eval_trace(self):
        from sympy.matrices.expressions.trace import Trace
        from sympy.concrete.summations import Sum
        return Trace(self).rewrite(Sum).doit()

    def _eval_as_real_imag(self):
        return (re(Matrix(self)), im(Matrix(self)))