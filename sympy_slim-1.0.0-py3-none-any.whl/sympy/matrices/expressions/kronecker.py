from __future__ import annotations
from functools import reduce
from math import prod
from sympy.core import Mul, sympify
from sympy.functions import adjoint
from sympy.matrices.exceptions import ShapeError
from sympy.matrices.expressions.matexpr import MatrixExpr
from sympy.matrices.expressions.transpose import transpose
from sympy.matrices.expressions.special import Identity
from sympy.matrices.matrixbase import MatrixBase
from sympy.strategies import canon, condition, distribute, do_one, exhaust, flatten, typed, unpack
from sympy.strategies.traverse import bottom_up
from sympy.utilities import sift
from .matadd import MatAdd
from .matmul import MatMul
from .matpow import MatPow

def kronecker_product(*matrices):
    if not matrices:
        raise TypeError('Empty Kronecker product is undefined')
    if len(matrices) == 1:
        return matrices[0]
    else:
        return KroneckerProduct(*matrices).doit()

class KroneckerProduct(MatrixExpr):
    is_KroneckerProduct = True

    def __new__(cls, *args, check=True):
        args = list(map(sympify, args))
        if all((a.is_Identity for a in args)):
            ret = Identity(prod((a.rows for a in args)))
            if all((isinstance(a, MatrixBase) for a in args)):
                return ret.as_explicit()
            else:
                return ret
        if check:
            validate(*args)
        return super().__new__(cls, *args)

    @property
    def shape(self):
        rows, cols = self.args[0].shape
        for mat in self.args[1:]:
            rows *= mat.rows
            cols *= mat.cols
        return (rows, cols)

    def _entry(self, i, j, **kwargs):
        result = 1
        for mat in reversed(self.args):
            i, m = divmod(i, mat.rows)
            j, n = divmod(j, mat.cols)
            result *= mat[m, n]
        return result

    def _eval_adjoint(self):
        return KroneckerProduct(*list(map(adjoint, self.args))).doit()

    def _eval_conjugate(self):
        return KroneckerProduct(*[a.conjugate() for a in self.args]).doit()

    def _eval_transpose(self):
        return KroneckerProduct(*list(map(transpose, self.args))).doit()

    def _eval_trace(self):
        from .trace import trace
        return Mul(*[trace(a) for a in self.args])

    def _eval_determinant(self):
        from .determinant import det, Determinant
        if not all((a.is_square for a in self.args)):
            return Determinant(self)
        m = self.rows
        return Mul(*[det(a) ** (m / a.rows) for a in self.args])

    def _eval_inverse(self):
        try:
            return KroneckerProduct(*[a.inverse() for a in self.args])
        except ShapeError:
            from sympy.matrices.expressions.inverse import Inverse
            return Inverse(self)

    def structurally_equal(self, other):
        return isinstance(other, KroneckerProduct) and self.shape == other.shape and (len(self.args) == len(other.args)) and all((a.shape == b.shape for a, b in zip(self.args, other.args)))

    def has_matching_shape(self, other):
        return isinstance(other, KroneckerProduct) and self.cols == other.rows and (len(self.args) == len(other.args)) and all((a.cols == b.rows for a, b in zip(self.args, other.args)))

    def _eval_expand_kroneckerproduct(self, **hints):
        return flatten(canon(typed({KroneckerProduct: distribute(KroneckerProduct, MatAdd)}))(self))

    def _kronecker_add(self, other):
        if self.structurally_equal(other):
            return self.__class__(*[a + b for a, b in zip(self.args, other.args)])
        else:
            return self + other

    def _kronecker_mul(self, other):
        if self.has_matching_shape(other):
            return self.__class__(*[a * b for a, b in zip(self.args, other.args)])
        else:
            return self * other

    def doit(self, **hints):
        deep = hints.get('deep', True)
        if deep:
            args = [arg.doit(**hints) for arg in self.args]
        else:
            args = self.args
        return canonicalize(KroneckerProduct(*args))

def validate(*args):
    if not all((arg.is_Matrix for arg in args)):
        raise TypeError('Mix of Matrix and Scalar symbols')

def extract_commutative(kron):
    c_part = []
    nc_part = []
    for arg in kron.args:
        c, nc = arg.args_cnc()
        c_part.extend(c)
        nc_part.append(Mul._from_args(nc))
    c_part = Mul(*c_part)
    if c_part != 1:
        return c_part * KroneckerProduct(*nc_part)
    return kron

def matrix_kronecker_product(*matrices):
    if not all((isinstance(m, MatrixBase) for m in matrices)):
        raise TypeError('Sequence of Matrices expected, got: %s' % repr(matrices))
    matrix_expansion = matrices[-1]
    for mat in reversed(matrices[:-1]):
        rows = mat.rows
        cols = mat.cols
        for i in range(rows):
            start = matrix_expansion * mat[i * cols]
            for j in range(cols - 1):
                start = start.row_join(matrix_expansion * mat[i * cols + j + 1])
            if i == 0:
                next = start
            else:
                next = next.col_join(start)
        matrix_expansion = next
    MatrixClass = max(matrices, key=lambda M: M._class_priority).__class__
    if isinstance(matrix_expansion, MatrixClass):
        return matrix_expansion
    else:
        return MatrixClass(matrix_expansion)

def explicit_kronecker_product(kron):
    if not all((isinstance(m, MatrixBase) for m in kron.args)):
        return kron
    return matrix_kronecker_product(*kron.args)
rules = (unpack, explicit_kronecker_product, flatten, extract_commutative)
canonicalize = exhaust(condition(lambda x: isinstance(x, KroneckerProduct), do_one(*rules)))

def _kronecker_dims_key(expr):
    if isinstance(expr, KroneckerProduct):
        return tuple((a.shape for a in expr.args))
    else:
        return (0,)

def kronecker_mat_add(expr):
    args = sift(expr.args, _kronecker_dims_key)
    nonkrons = args.pop((0,), None)
    if not args:
        return expr
    krons = [reduce(lambda x, y: x._kronecker_add(y), group) for group in args.values()]
    if not nonkrons:
        return MatAdd(*krons)
    else:
        return MatAdd(*krons) + nonkrons

def kronecker_mat_mul(expr):
    factor, matrices = expr.as_coeff_matrices()
    i = 0
    while i < len(matrices) - 1:
        A, B = matrices[i:i + 2]
        if isinstance(A, KroneckerProduct) and isinstance(B, KroneckerProduct):
            matrices[i] = A._kronecker_mul(B)
            matrices.pop(i + 1)
        else:
            i += 1
    return factor * MatMul(*matrices)

def kronecker_mat_pow(expr):
    if isinstance(expr.base, KroneckerProduct) and all((a.is_square for a in expr.base.args)):
        return KroneckerProduct(*[MatPow(a, expr.exp) for a in expr.base.args])
    else:
        return expr

def combine_kronecker(expr):

    def haskron(expr):
        return isinstance(expr, MatrixExpr) and expr.has(KroneckerProduct)
    rule = exhaust(bottom_up(exhaust(condition(haskron, typed({MatAdd: kronecker_mat_add, MatMul: kronecker_mat_mul, MatPow: kronecker_mat_pow})))))
    result = rule(expr)
    doit = getattr(result, 'doit', None)
    if doit is not None:
        return doit()
    else:
        return result