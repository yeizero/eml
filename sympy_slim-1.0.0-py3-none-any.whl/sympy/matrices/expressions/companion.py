from __future__ import annotations
from sympy.core.singleton import S
from sympy.core.sympify import _sympify
from sympy.polys.polytools import Poly
from .matexpr import MatrixExpr

class CompanionMatrix(MatrixExpr):

    def __new__(cls, poly):
        poly = _sympify(poly)
        if not isinstance(poly, Poly):
            raise ValueError('{} must be a Poly instance.'.format(poly))
        if not poly.is_monic:
            raise ValueError('{} must be a monic polynomial.'.format(poly))
        if not poly.is_univariate:
            raise ValueError('{} must be a univariate polynomial.'.format(poly))
        if not poly.degree() >= 1:
            raise ValueError('{} must have degree not less than 1.'.format(poly))
        return super().__new__(cls, poly)

    @property
    def shape(self):
        poly = self.args[0]
        size = poly.degree()
        return (size, size)

    def _entry(self, i, j):
        if j == self.cols - 1:
            return -self.args[0].all_coeffs()[-1 - i]
        elif i == j + 1:
            return S.One
        return S.Zero

    def as_explicit(self):
        from sympy.matrices.immutable import ImmutableDenseMatrix
        return ImmutableDenseMatrix.companion(self.args[0])