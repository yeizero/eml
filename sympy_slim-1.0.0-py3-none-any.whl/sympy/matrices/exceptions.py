from __future__ import annotations

class MatrixError(Exception):
    pass

class ShapeError(ValueError, MatrixError):
    pass

class NonSquareMatrixError(ShapeError):
    pass

class NonInvertibleMatrixError(ValueError, MatrixError):
    pass

class NonPositiveDefiniteMatrixError(ValueError, MatrixError):
    pass