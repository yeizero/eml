from __future__ import annotations
from typing import TYPE_CHECKING
from sympy.utilities.iterables import flatten, connected_components, strongly_connected_components
from .exceptions import NonSquareMatrixError
if TYPE_CHECKING:
    from sympy.matrices.matrixbase import MatrixBase
    from sympy.matrices.expressions.permutation import PermutationMatrix
    from sympy.matrices.expressions.blockmatrix import BlockDiagMatrix, BlockMatrix

def _connected_components(M: MatrixBase) -> list[list[int]]:
    if not M.is_square:
        raise NonSquareMatrixError
    V = range(M.rows)
    E = sorted(M.todok().keys())
    return connected_components((V, E))

def _strongly_connected_components(M) -> list[list[int]]:
    if not M.is_square:
        raise NonSquareMatrixError
    rep = getattr(M, '_rep', None)
    if rep is not None:
        return rep.scc()
    V = range(M.rows)
    E = sorted(M.todok().keys())
    return strongly_connected_components((V, E))

def _connected_components_decomposition(M: MatrixBase) -> tuple[PermutationMatrix, BlockDiagMatrix]:
    from sympy.combinatorics.permutations import Permutation
    from sympy.matrices.expressions.blockmatrix import BlockDiagMatrix
    from sympy.matrices.expressions.permutation import PermutationMatrix
    iblocks = M.connected_components()
    p = Permutation(flatten(iblocks))
    P = PermutationMatrix(p)
    blocks = []
    for b in iblocks:
        blocks.append(M[b, b])
    B = BlockDiagMatrix(*blocks)
    return (P, B)

def _strongly_connected_components_decomposition(M, lower: bool=True) -> tuple[PermutationMatrix, BlockMatrix]:
    from sympy.combinatorics.permutations import Permutation
    from sympy.matrices.expressions.blockmatrix import BlockMatrix
    from sympy.matrices.expressions.permutation import PermutationMatrix
    iblocks = M.strongly_connected_components()
    if not lower:
        iblocks = list(reversed(iblocks))
    p = Permutation(flatten(iblocks))
    P = PermutationMatrix(p)
    rows = []
    for a in iblocks:
        cols = []
        for b in iblocks:
            cols.append(M[a, b])
        rows.append(cols)
    B = BlockMatrix(rows)
    return (P, B)