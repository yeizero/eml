from __future__ import annotations
from collections.abc import Callable
from sympy.core.containers import Dict
from sympy.utilities.exceptions import sympy_deprecation_warning
from sympy.utilities.iterables import is_sequence
from sympy.utilities.misc import as_int
from .matrixbase import MatrixBase
from .repmatrix import MutableRepMatrix, RepMatrix
from .utilities import _iszero
from .decompositions import _liupc, _row_structure_symbolic_cholesky, _cholesky_sparse, _LDLdecomposition_sparse
from .solvers import _lower_triangular_solve_sparse, _upper_triangular_solve_sparse

class SparseRepMatrix(RepMatrix):

    @classmethod
    def _handle_creation_inputs(cls, *args, **kwargs):
        if len(args) == 1 and isinstance(args[0], MatrixBase):
            rows = args[0].rows
            cols = args[0].cols
            smat = args[0].todok()
            return (rows, cols, smat)
        smat = {}
        if len(args) == 2 and args[0] is None:
            args = [None, None, args[1]]
        if len(args) == 3:
            r, c, arg3 = args
            if r is c is None:
                rows = cols = None
            elif None in (r, c):
                raise ValueError('Pass rows=None and no cols for autosizing.')
            else:
                rows, cols = (as_int(args[0]), as_int(args[1]))
            if isinstance(arg3, Callable):
                op = arg3
                if rows is None or cols is None:
                    raise ValueError('{} and {} must be integers for this specification.'.format(rows, cols))
                row_indices = [cls._sympify(i) for i in range(rows)]
                col_indices = [cls._sympify(j) for j in range(cols)]
                for i in row_indices:
                    for j in col_indices:
                        value = cls._sympify(op(i, j))
                        if value != cls.zero:
                            smat[i, j] = value
                return (rows, cols, smat)
            elif isinstance(arg3, (dict, Dict)):

                def update(i, j, v):
                    if v:
                        if (i, j) in smat and v != smat[i, j]:
                            raise ValueError('There is a collision at {} for {} and {}.'.format((i, j), v, smat[i, j]))
                        smat[i, j] = v
                for (r, c), v in arg3.items():
                    if isinstance(v, MatrixBase):
                        for (i, j), vv in v.todok().items():
                            update(r + i, c + j, vv)
                    elif isinstance(v, (list, tuple)):
                        _, _, smat = cls._handle_creation_inputs(v, **kwargs)
                        for i, j in smat:
                            update(r + i, c + j, smat[i, j])
                    else:
                        v = cls._sympify(v)
                        update(r, c, cls._sympify(v))
            elif is_sequence(arg3):
                flat = not any((is_sequence(i) for i in arg3))
                if not flat:
                    _, _, smat = cls._handle_creation_inputs(arg3, **kwargs)
                else:
                    flat_list = arg3
                    if len(flat_list) != rows * cols:
                        raise ValueError('The length of the flat list ({}) does not match the specified size ({} * {}).'.format(len(flat_list), rows, cols))
                    for i in range(rows):
                        for j in range(cols):
                            value = flat_list[i * cols + j]
                            value = cls._sympify(value)
                            if value != cls.zero:
                                smat[i, j] = value
            if rows is None:
                keys = smat.keys()
                rows = max((r for r, _ in keys)) + 1 if keys else 0
                cols = max((c for _, c in keys)) + 1 if keys else 0
            else:
                for i, j in smat.keys():
                    if i and i >= rows or (j and j >= cols):
                        raise ValueError('The location {} is out of the designated range[{}, {}]x[{}, {}]'.format((i, j), 0, rows - 1, 0, cols - 1))
            return (rows, cols, smat)
        elif len(args) == 1 and isinstance(args[0], (list, tuple)):
            v = args[0]
            c = 0
            for i, row in enumerate(v):
                if not isinstance(row, (list, tuple)):
                    row = [row]
                for j, vv in enumerate(row):
                    if vv != cls.zero:
                        smat[i, j] = cls._sympify(vv)
                c = max(c, len(row))
            rows = len(v) if c else 0
            cols = c
            return (rows, cols, smat)
        else:
            rows, cols, mat = super()._handle_creation_inputs(*args)
            for i in range(rows):
                for j in range(cols):
                    value = mat[cols * i + j]
                    if value != cls.zero:
                        smat[i, j] = value
            return (rows, cols, smat)

    @property
    def _smat(self):
        sympy_deprecation_warning('\n            The private _smat attribute of SparseMatrix is deprecated. Use the\n            .todok() method instead.\n            ', deprecated_since_version='1.9', active_deprecations_target='deprecated-private-matrix-attributes')
        return self.todok()

    def _eval_inverse(self, **kwargs):
        return self.inv(method=kwargs.get('method', 'LDL'), iszerofunc=kwargs.get('iszerofunc', _iszero), try_block_diag=kwargs.get('try_block_diag', False))

    def applyfunc(self, f):
        if not callable(f):
            raise TypeError('`f` must be callable.')
        dok = {}
        for k, v in self.todok().items():
            fv = f(v)
            if fv != 0:
                dok[k] = fv
        return self.from_dok(self.rows, self.cols, dok)

    def as_immutable(self):
        from .immutable import ImmutableSparseMatrix
        return ImmutableSparseMatrix(self)

    def as_mutable(self):
        return MutableSparseMatrix(self)

    def col_list(self):
        return [tuple(k + (self[k],)) for k in sorted(self.todok().keys(), key=lambda k: list(reversed(k)))]

    def nnz(self):
        return len(self.todok())

    def row_list(self):
        return [tuple(k + (self[k],)) for k in sorted(self.todok().keys(), key=list)]

    def scalar_multiply(self, scalar):
        return scalar * self

    def solve_least_squares(self, rhs, method='LDL'):
        t = self.T
        return (t * self).inv(method=method) * t * rhs

    def solve(self, rhs, method='LDL'):
        if not self.is_square:
            if self.rows < self.cols:
                raise ValueError('Under-determined system.')
            elif self.rows > self.cols:
                raise ValueError('For over-determined system, M, having more rows than columns, try M.solve_least_squares(rhs).')
        return self.inv(method=method).multiply(rhs)
    RL = property(row_list, None, None, 'Alternate faster representation')
    CL = property(col_list, None, None, 'Alternate faster representation')

    def liupc(self):
        return _liupc(self)

    def row_structure_symbolic_cholesky(self):
        return _row_structure_symbolic_cholesky(self)

    def cholesky(self, hermitian=True):
        return _cholesky_sparse(self, hermitian=hermitian)

    def LDLdecomposition(self, hermitian=True):
        return _LDLdecomposition_sparse(self, hermitian=hermitian)

    def lower_triangular_solve(self, rhs):
        return _lower_triangular_solve_sparse(self, rhs)

    def upper_triangular_solve(self, rhs):
        return _upper_triangular_solve_sparse(self, rhs)
    liupc.__doc__ = _liupc.__doc__
    row_structure_symbolic_cholesky.__doc__ = _row_structure_symbolic_cholesky.__doc__
    cholesky.__doc__ = _cholesky_sparse.__doc__
    LDLdecomposition.__doc__ = _LDLdecomposition_sparse.__doc__
    lower_triangular_solve.__doc__ = lower_triangular_solve.__doc__
    upper_triangular_solve.__doc__ = upper_triangular_solve.__doc__

class MutableSparseMatrix(SparseRepMatrix, MutableRepMatrix):

    @classmethod
    def _new(cls, *args, **kwargs):
        rows, cols, smat = cls._handle_creation_inputs(*args, **kwargs)
        rep = cls._smat_to_DomainMatrix(rows, cols, smat)
        return cls._fromrep(rep)
SparseMatrix = MutableSparseMatrix