from __future__ import annotations
from typing import TYPE_CHECKING, overload
if TYPE_CHECKING:
    from typing import Literal, Callable, TypeVar
    from sympy.core.expr import Expr
    from sympy.matrices.matrixbase import MatrixBase
    Tmat = TypeVar('Tmat', bound=MatrixBase)
from types import FunctionType
from sympy.polys.polyerrors import CoercionFailed
from sympy.polys.domains import ZZ, QQ
from .utilities import _get_intermediate_simp, _iszero, _dotprodsimp, _simplify
from .determinant import _find_reasonable_pivot
if TYPE_CHECKING:
    from typing import Any

def _row_reduce_list(mat, rows, cols, one, iszerofunc, simpfunc, normalize_last=True, normalize=True, zero_above=True):

    def get_col(i):
        return mat[i::cols]

    def row_swap(i, j):
        mat[i * cols:(i + 1) * cols], mat[j * cols:(j + 1) * cols] = (mat[j * cols:(j + 1) * cols], mat[i * cols:(i + 1) * cols])

    def cross_cancel(a, i, b, j):
        q = (j - i) * cols
        for p in range(i * cols, (i + 1) * cols):
            mat[p] = isimp(a * mat[p] - b * mat[p + q])
    isimp = _get_intermediate_simp(_dotprodsimp)
    piv_row, piv_col = (0, 0)
    pivot_cols = []
    swaps = []
    while piv_col < cols and piv_row < rows:
        pivot_offset, pivot_val, assumed_nonzero, newly_determined = _find_reasonable_pivot(get_col(piv_col)[piv_row:], iszerofunc, simpfunc)
        for offset, val in newly_determined:
            offset += piv_row
            mat[offset * cols + piv_col] = val
        if pivot_offset is None:
            piv_col += 1
            continue
        pivot_cols.append(piv_col)
        if pivot_offset != 0:
            row_swap(piv_row, pivot_offset + piv_row)
            swaps.append((piv_row, pivot_offset + piv_row))
        if normalize_last is False or not pivot_val.is_commutative:
            i, j = (piv_row, piv_col)
            mat[i * cols + j] = one
            for p in range(i * cols + j + 1, (i + 1) * cols):
                mat[p] = isimp(pivot_val ** (-1) * mat[p])
            pivot_val = one
        for row in range(rows):
            if row == piv_row:
                continue
            if zero_above is False and row < piv_row:
                continue
            val = mat[row * cols + piv_col]
            if iszerofunc(val):
                continue
            cross_cancel(pivot_val, row, val, piv_row)
        piv_row += 1
    if normalize_last is True and normalize is True:
        for piv_i, piv_j in enumerate(pivot_cols):
            pivot_val = mat[piv_i * cols + piv_j]
            mat[piv_i * cols + piv_j] = one
            for p in range(piv_i * cols + piv_j + 1, (piv_i + 1) * cols):
                mat[p] = isimp(pivot_val ** (-1) * mat[p])
    return (mat, tuple(pivot_cols), tuple(swaps))

def _row_reduce(M, iszerofunc, simpfunc, normalize_last=True, normalize=True, zero_above=True):
    mat, pivot_cols, swaps = _row_reduce_list(list(M), M.rows, M.cols, M.one, iszerofunc, simpfunc, normalize_last=normalize_last, normalize=normalize, zero_above=zero_above)
    return (M._new(M.rows, M.cols, mat), pivot_cols, swaps)

def _is_echelon(M, iszerofunc=_iszero):
    if M.rows <= 0 or M.cols <= 0:
        return True
    zeros_below = all((iszerofunc(t) for t in M[1:, 0]))
    if iszerofunc(M[0, 0]):
        return zeros_below and _is_echelon(M[:, 1:], iszerofunc)
    return zeros_below and _is_echelon(M[1:, 1:], iszerofunc)

@overload
def _echelon_form(M: Tmat, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, with_pivots: Literal[False]=False) -> Tmat:
    pass

@overload
def _echelon_form(M: Tmat, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, with_pivots: Literal[True]) -> tuple[Tmat, tuple[int]]:
    pass

@overload
def _echelon_form(M: Tmat, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, with_pivots: bool=False) -> Tmat | tuple[Tmat, tuple[int]]:
    pass

def _echelon_form(M: Tmat, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, with_pivots: bool=False) -> Tmat | tuple[Tmat, tuple[int]]:
    simpfunc = simplify if isinstance(simplify, FunctionType) else _simplify
    mat, pivots, _ = _row_reduce(M, iszerofunc, simpfunc, normalize_last=True, normalize=False, zero_above=False)
    if with_pivots:
        return (mat, pivots)
    return mat

def _rank(M, iszerofunc=_iszero, simplify=False):

    def _permute_complexity_right(M, iszerofunc):

        def complexity(i):
            return sum((1 if iszerofunc(e) is None else 0 for e in M[:, i]))
        complex = [(complexity(i), i) for i in range(M.cols)]
        perm = [j for i, j in sorted(complex)]
        return (M.permute(perm, orientation='cols'), perm)
    simpfunc = simplify if isinstance(simplify, FunctionType) else _simplify
    if M.rows <= 0 or M.cols <= 0:
        return 0
    if M.rows <= 1 or M.cols <= 1:
        zeros = [iszerofunc(x) for x in M]
        if False in zeros:
            return 1
    if M.rows == 2 and M.cols == 2:
        zeros = [iszerofunc(x) for x in M]
        if False not in zeros and None not in zeros:
            return 0
        d = M.det()
        if iszerofunc(d) and False in zeros:
            return 1
        if iszerofunc(d) is False:
            return 2
    mat, _ = _permute_complexity_right(M, iszerofunc=iszerofunc)
    _, pivots, _ = _row_reduce(mat, iszerofunc, simpfunc, normalize_last=True, normalize=False, zero_above=False)
    return len(pivots)

def _to_DM_ZZ_QQ(M):
    if not hasattr(M, '_rep'):
        return None
    rep = M._rep
    K = rep.domain
    if K.is_ZZ:
        return rep
    elif K.is_QQ:
        try:
            return rep.convert_to(ZZ)
        except CoercionFailed:
            return rep
    else:
        if not all((e.is_Rational for e in M)):
            return None
        try:
            return rep.convert_to(ZZ)
        except CoercionFailed:
            return rep.convert_to(QQ)

def _rref_dm(dM):
    K = dM.domain
    if K.is_ZZ:
        dM_rref, den, pivots = dM.rref_den(keep_domain=False)
        dM_rref = dM_rref.to_field() / den
    elif K.is_QQ:
        dM_rref, pivots = dM.rref()
    else:
        assert False
    M_rref = dM_rref.to_Matrix()
    return (M_rref, pivots)

@overload
def _rref(M: Tmat, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, pivots: Literal[False], normalize_last: bool=True) -> Tmat:
    pass

@overload
def _rref(M: Tmat, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, pivots: Literal[True]=True, normalize_last: bool=True) -> tuple[Tmat, tuple[int]]:
    pass

@overload
def _rref(M: Tmat, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, pivots: bool=True, normalize_last: bool=True) -> Tmat | tuple[Tmat, tuple[int]]:
    pass

def _rref(M: Tmat, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, pivots: bool=True, normalize_last: bool=True) -> Tmat | tuple[Tmat, tuple[int]]:
    dM = _to_DM_ZZ_QQ(M)
    if dM is not None:
        mat, pivot_cols = _rref_dm(dM)
    else:
        if isinstance(simplify, FunctionType):
            simpfunc: Callable[[Any], Any] = simplify
        else:
            simpfunc = _simplify
        mat, pivot_cols, _ = _row_reduce(M, iszerofunc, simpfunc, normalize_last, normalize=True, zero_above=True)
    if pivots:
        return (mat, pivot_cols)
    else:
        return mat