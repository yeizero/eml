from __future__ import annotations
from collections import defaultdict
from collections.abc import Iterable
from inspect import isfunction
from functools import reduce
from sympy.assumptions.refine import refine
from sympy.core import SympifyError, Add
from sympy.core.basic import Atom
from sympy.core.decorators import call_highest_priority
from sympy.core.logic import fuzzy_and, FuzzyBool
from sympy.core.numbers import Integer
from sympy.core.mod import Mod
from sympy.core.singleton import S
from sympy.core.symbol import Symbol
from sympy.core.sympify import sympify
from sympy.functions.elementary.complexes import Abs, re, im
from sympy.utilities.exceptions import sympy_deprecation_warning
from .utilities import _dotprodsimp, _simplify
from sympy.polys.polytools import Poly
from sympy.utilities.iterables import flatten, is_sequence
from sympy.utilities.misc import as_int, filldedent
from sympy.tensor.array import NDimArray
from .utilities import _get_intermediate_simp_bool
from .exceptions import MatrixError, ShapeError, NonSquareMatrixError, NonInvertibleMatrixError, NonPositiveDefiniteMatrixError
_DEPRECATED_MIXINS = ('MatrixShaping', 'MatrixSpecial', 'MatrixProperties', 'MatrixOperations', 'MatrixArithmetic', 'MatrixCommon', 'MatrixDeterminant', 'MatrixReductions', 'MatrixSubspaces', 'MatrixEigen', 'MatrixCalculus', 'MatrixDeprecated')

class _MatrixDeprecatedMeta(type):

    def __instancecheck__(cls, instance):
        sympy_deprecation_warning(f'\n            Checking whether an object is an instance of {cls.__name__} is\n            deprecated.\n\n            Use `isinstance(obj, Matrix)` instead of `isinstance(obj, {cls.__name__})`.\n            ', deprecated_since_version='1.13', active_deprecations_target='deprecated-matrix-mixins', stacklevel=3)
        from sympy.matrices.matrixbase import MatrixBase
        from sympy.matrices.matrices import MatrixDeterminant, MatrixReductions, MatrixSubspaces, MatrixEigen, MatrixCalculus, MatrixDeprecated
        all_mixins = (MatrixRequired, MatrixShaping, MatrixSpecial, MatrixProperties, MatrixOperations, MatrixArithmetic, MatrixCommon, MatrixDeterminant, MatrixReductions, MatrixSubspaces, MatrixEigen, MatrixCalculus, MatrixDeprecated)
        if cls in all_mixins and isinstance(instance, MatrixBase):
            return True
        else:
            return super().__instancecheck__(instance)

class MatrixRequired(metaclass=_MatrixDeprecatedMeta):
    rows: int
    cols: int
    _simplify = None

    def __init_subclass__(cls, **kwargs):
        if cls.__name__ not in _DEPRECATED_MIXINS:
            sympy_deprecation_warning(f'\n                Inheriting from the Matrix mixin classes is deprecated.\n\n                The class {cls.__name__} is subclassing a deprecated mixin.\n                ', deprecated_since_version='1.13', active_deprecations_target='deprecated-matrix-mixins', stacklevel=3)
        super().__init_subclass__(**kwargs)

    @classmethod
    def _new(cls, *args, **kwargs):
        raise NotImplementedError('Subclasses must implement this.')

    def __eq__(self, other):
        raise NotImplementedError('Subclasses must implement this.')

    def __getitem__(self, key):
        raise NotImplementedError('Subclasses must implement this.')

    def __len__(self):
        raise NotImplementedError('Subclasses must implement this.')

    @property
    def shape(self):
        raise NotImplementedError('Subclasses must implement this.')

class MatrixShaping(MatrixRequired):

    def _eval_col_del(self, col):

        def entry(i, j):
            return self[i, j] if j < col else self[i, j + 1]
        return self._new(self.rows, self.cols - 1, entry)

    def _eval_col_insert(self, pos, other):

        def entry(i, j):
            if j < pos:
                return self[i, j]
            elif pos <= j < pos + other.cols:
                return other[i, j - pos]
            return self[i, j - other.cols]
        return self._new(self.rows, self.cols + other.cols, entry)

    def _eval_col_join(self, other):
        rows = self.rows

        def entry(i, j):
            if i < rows:
                return self[i, j]
            return other[i - rows, j]
        return classof(self, other)._new(self.rows + other.rows, self.cols, entry)

    def _eval_extract(self, rowsList, colsList):
        mat = list(self)
        cols = self.cols
        indices = (i * cols + j for i in rowsList for j in colsList)
        return self._new(len(rowsList), len(colsList), [mat[i] for i in indices])

    def _eval_get_diag_blocks(self):
        sub_blocks = []

        def recurse_sub_blocks(M):
            for i in range(1, M.shape[0] + 1):
                if i == 1:
                    to_the_right = M[0, i:]
                    to_the_bottom = M[i:, 0]
                else:
                    to_the_right = M[:i, i:]
                    to_the_bottom = M[i:, :i]
                if any(to_the_right) or any(to_the_bottom):
                    continue
                sub_blocks.append(M[:i, :i])
                if M.shape != M[:i, :i].shape:
                    recurse_sub_blocks(M[i:, i:])
                return
        recurse_sub_blocks(self)
        return sub_blocks

    def _eval_row_del(self, row):

        def entry(i, j):
            return self[i, j] if i < row else self[i + 1, j]
        return self._new(self.rows - 1, self.cols, entry)

    def _eval_row_insert(self, pos, other):
        entries = list(self)
        insert_pos = pos * self.cols
        entries[insert_pos:insert_pos] = list(other)
        return self._new(self.rows + other.rows, self.cols, entries)

    def _eval_row_join(self, other):
        cols = self.cols

        def entry(i, j):
            if j < cols:
                return self[i, j]
            return other[i, j - cols]
        return classof(self, other)._new(self.rows, self.cols + other.cols, entry)

    def _eval_tolist(self):
        return [list(self[i, :]) for i in range(self.rows)]

    def _eval_todok(self):
        dok = {}
        rows, cols = self.shape
        for i in range(rows):
            for j in range(cols):
                val = self[i, j]
                if val != self.zero:
                    dok[i, j] = val
        return dok

    def _eval_vec(self):
        rows = self.rows

        def entry(n, _):
            j = n // rows
            i = n - j * rows
            return self[i, j]
        return self._new(len(self), 1, entry)

    def _eval_vech(self, diagonal):
        c = self.cols
        v = []
        if diagonal:
            for j in range(c):
                for i in range(j, c):
                    v.append(self[i, j])
        else:
            for j in range(c):
                for i in range(j + 1, c):
                    v.append(self[i, j])
        return self._new(len(v), 1, v)

    def col_del(self, col):
        if col < 0:
            col += self.cols
        if not 0 <= col < self.cols:
            raise IndexError('Column {} is out of range.'.format(col))
        return self._eval_col_del(col)

    def col_insert(self, pos, other):
        if not self:
            return type(self)(other)
        pos = as_int(pos)
        if pos < 0:
            pos = self.cols + pos
        if pos < 0:
            pos = 0
        elif pos > self.cols:
            pos = self.cols
        if self.rows != other.rows:
            raise ShapeError('The matrices have incompatible number of rows ({} and {})'.format(self.rows, other.rows))
        return self._eval_col_insert(pos, other)

    def col_join(self, other):
        if self.rows == 0 and self.cols != other.cols:
            return self._new(0, other.cols, []).col_join(other)
        if self.cols != other.cols:
            raise ShapeError('The matrices have incompatible number of columns ({} and {})'.format(self.cols, other.cols))
        return self._eval_col_join(other)

    def col(self, j):
        return self[:, j]

    def extract(self, rowsList, colsList):
        if not is_sequence(rowsList) or not is_sequence(colsList):
            raise TypeError('rowsList and colsList must be iterable')
        if rowsList and all((isinstance(i, bool) for i in rowsList)):
            rowsList = [index for index, item in enumerate(rowsList) if item]
        if colsList and all((isinstance(i, bool) for i in colsList)):
            colsList = [index for index, item in enumerate(colsList) if item]
        rowsList = [a2idx(k, self.rows) for k in rowsList]
        colsList = [a2idx(k, self.cols) for k in colsList]
        return self._eval_extract(rowsList, colsList)

    def get_diag_blocks(self):
        return self._eval_get_diag_blocks()

    @classmethod
    def hstack(cls, *args):
        if len(args) == 0:
            return cls._new()
        kls = type(args[0])
        return reduce(kls.row_join, args)

    def reshape(self, rows, cols):
        if self.rows * self.cols != rows * cols:
            raise ValueError('Invalid reshape parameters %d %d' % (rows, cols))
        return self._new(rows, cols, lambda i, j: self[i * cols + j])

    def row_del(self, row):
        if row < 0:
            row += self.rows
        if not 0 <= row < self.rows:
            raise IndexError('Row {} is out of range.'.format(row))
        return self._eval_row_del(row)

    def row_insert(self, pos, other):
        if not self:
            return self._new(other)
        pos = as_int(pos)
        if pos < 0:
            pos = self.rows + pos
        if pos < 0:
            pos = 0
        elif pos > self.rows:
            pos = self.rows
        if self.cols != other.cols:
            raise ShapeError('The matrices have incompatible number of columns ({} and {})'.format(self.cols, other.cols))
        return self._eval_row_insert(pos, other)

    def row_join(self, other):
        if self.cols == 0 and self.rows != other.rows:
            return self._new(other.rows, 0, []).row_join(other)
        if self.rows != other.rows:
            raise ShapeError('The matrices have incompatible number of rows ({} and {})'.format(self.rows, other.rows))
        return self._eval_row_join(other)

    def diagonal(self, k=0):
        rv = []
        k = as_int(k)
        r = 0 if k > 0 else -k
        c = 0 if r else k
        while True:
            if r == self.rows or c == self.cols:
                break
            rv.append(self[r, c])
            r += 1
            c += 1
        if not rv:
            raise ValueError(filldedent('\n            The %s diagonal is out of range [%s, %s]' % (k, 1 - self.rows, self.cols - 1)))
        return self._new(1, len(rv), rv)

    def row(self, i):
        return self[i, :]

    @property
    def shape(self):
        return (self.rows, self.cols)

    def todok(self):
        return self._eval_todok()

    def tolist(self):
        if not self.rows:
            return []
        if not self.cols:
            return [[] for i in range(self.rows)]
        return self._eval_tolist()

    def todod(M):
        rowsdict = {}
        Mlol = M.tolist()
        for i, Mi in enumerate(Mlol):
            row = {j: Mij for j, Mij in enumerate(Mi) if Mij}
            if row:
                rowsdict[i] = row
        return rowsdict

    def vec(self):
        return self._eval_vec()

    def vech(self, diagonal=True, check_symmetry=True):
        if not self.is_square:
            raise NonSquareMatrixError
        if check_symmetry and (not self.is_symmetric()):
            raise ValueError('The matrix is not symmetric.')
        return self._eval_vech(diagonal)

    @classmethod
    def vstack(cls, *args):
        if len(args) == 0:
            return cls._new()
        kls = type(args[0])
        return reduce(kls.col_join, args)

class MatrixSpecial(MatrixRequired):

    @classmethod
    def _eval_diag(cls, rows, cols, diag_dict):

        def entry(i, j):
            return diag_dict[i, j]
        return cls._new(rows, cols, entry)

    @classmethod
    def _eval_eye(cls, rows, cols):
        vals = [cls.zero] * (rows * cols)
        vals[::cols + 1] = [cls.one] * min(rows, cols)
        return cls._new(rows, cols, vals, copy=False)

    @classmethod
    def _eval_jordan_block(cls, size: int, eigenvalue, band='upper'):
        if band == 'lower':

            def entry(i, j):
                if i == j:
                    return eigenvalue
                elif j + 1 == i:
                    return cls.one
                return cls.zero
        else:

            def entry(i, j):
                if i == j:
                    return eigenvalue
                elif i + 1 == j:
                    return cls.one
                return cls.zero
        return cls._new(size, size, entry)

    @classmethod
    def _eval_ones(cls, rows, cols):

        def entry(i, j):
            return cls.one
        return cls._new(rows, cols, entry)

    @classmethod
    def _eval_zeros(cls, rows, cols):
        return cls._new(rows, cols, [cls.zero] * (rows * cols), copy=False)

    @classmethod
    def _eval_wilkinson(cls, n):

        def entry(i, j):
            return cls.one if i + 1 == j else cls.zero
        D = cls._new(2 * n + 1, 2 * n + 1, entry)
        wminus = cls.diag(list(range(-n, n + 1)), unpack=True) + D + D.T
        wplus = abs(cls.diag(list(range(-n, n + 1)), unpack=True)) + D + D.T
        return (wminus, wplus)

    @classmethod
    def diag(kls, *args, strict=False, unpack=True, rows=None, cols=None, **kwargs):
        from sympy.matrices.matrixbase import MatrixBase
        from sympy.matrices.dense import Matrix
        from sympy.matrices import SparseMatrix
        klass = kwargs.get('cls', kls)
        if unpack and len(args) == 1 and is_sequence(args[0]) and (not isinstance(args[0], MatrixBase)):
            args = args[0]
        diag_entries = defaultdict(int)
        rmax = cmax = 0
        for m in args:
            if isinstance(m, list):
                if strict:
                    _ = Matrix(m)
                    r, c = _.shape
                    m = _.tolist()
                else:
                    r, c, smat = SparseMatrix._handle_creation_inputs(m)
                    for (i, j), _ in smat.items():
                        diag_entries[i + rmax, j + cmax] = _
                    m = []
            elif hasattr(m, 'shape'):
                r, c = m.shape
                m = m.tolist()
            else:
                diag_entries[rmax, cmax] = m
                rmax += 1
                cmax += 1
                continue
            for i, mi in enumerate(m):
                for j, _ in enumerate(mi):
                    diag_entries[i + rmax, j + cmax] = _
            rmax += r
            cmax += c
        if rows is None:
            rows, cols = (cols, rows)
        if rows is None:
            rows, cols = (rmax, cmax)
        else:
            cols = rows if cols is None else cols
        if rows < rmax or cols < cmax:
            raise ValueError(filldedent('\n                The constructed matrix is {} x {} but a size of {} x {}\n                was specified.'.format(rmax, cmax, rows, cols)))
        return klass._eval_diag(rows, cols, diag_entries)

    @classmethod
    def eye(kls, rows, cols=None, **kwargs):
        if cols is None:
            cols = rows
        if rows < 0 or cols < 0:
            raise ValueError('Cannot create a {} x {} matrix. Both dimensions must be positive'.format(rows, cols))
        klass = kwargs.get('cls', kls)
        rows, cols = (as_int(rows), as_int(cols))
        return klass._eval_eye(rows, cols)

    @classmethod
    def jordan_block(kls, size=None, eigenvalue=None, *, band='upper', **kwargs):
        klass = kwargs.pop('cls', kls)
        eigenval = kwargs.get('eigenval', None)
        if eigenvalue is None and eigenval is None:
            raise ValueError('Must supply an eigenvalue')
        elif eigenvalue != eigenval and None not in (eigenval, eigenvalue):
            raise ValueError("Inconsistent values are given: 'eigenval'={}, 'eigenvalue'={}".format(eigenval, eigenvalue))
        elif eigenval is not None:
            eigenvalue = eigenval
        if size is None:
            raise ValueError('Must supply a matrix size')
        size = as_int(size)
        return klass._eval_jordan_block(size, eigenvalue, band)

    @classmethod
    def ones(kls, rows, cols=None, **kwargs):
        if cols is None:
            cols = rows
        klass = kwargs.get('cls', kls)
        rows, cols = (as_int(rows), as_int(cols))
        return klass._eval_ones(rows, cols)

    @classmethod
    def zeros(kls, rows, cols=None, **kwargs):
        if cols is None:
            cols = rows
        if rows < 0 or cols < 0:
            raise ValueError('Cannot create a {} x {} matrix. Both dimensions must be positive'.format(rows, cols))
        klass = kwargs.get('cls', kls)
        rows, cols = (as_int(rows), as_int(cols))
        return klass._eval_zeros(rows, cols)

    @classmethod
    def companion(kls, poly):
        poly = kls._sympify(poly)
        if not isinstance(poly, Poly):
            raise ValueError('{} must be a Poly instance.'.format(poly))
        if not poly.is_monic:
            raise ValueError('{} must be a monic polynomial.'.format(poly))
        if not poly.is_univariate:
            raise ValueError('{} must be a univariate polynomial.'.format(poly))
        size = poly.degree()
        if not size >= 1:
            raise ValueError('{} must have degree not less than 1.'.format(poly))
        coeffs = poly.all_coeffs()

        def entry(i, j):
            if j == size - 1:
                return -coeffs[-1 - i]
            elif i == j + 1:
                return kls.one
            return kls.zero
        return kls._new(size, size, entry)

    @classmethod
    def wilkinson(kls, n, **kwargs):
        klass = kwargs.get('cls', kls)
        n = as_int(n)
        return klass._eval_wilkinson(n)

class MatrixProperties(MatrixRequired):

    def _eval_atoms(self, *types):
        result = set()
        for i in self:
            result.update(i.atoms(*types))
        return result

    def _eval_free_symbols(self):
        return set().union(*(i.free_symbols for i in self if i))

    def _eval_has(self, *patterns):
        return any((a.has(*patterns) for a in self))

    def _eval_is_anti_symmetric(self, simpfunc):
        if not all((simpfunc(self[i, j] + self[j, i]).is_zero for i in range(self.rows) for j in range(self.cols))):
            return False
        return True

    def _eval_is_diagonal(self):
        for i in range(self.rows):
            for j in range(self.cols):
                if i != j and self[i, j]:
                    return False
        return True

    def _eval_is_matrix_hermitian(self, simpfunc):
        mat = self._new(self.rows, self.cols, lambda i, j: simpfunc(self[i, j] - self[j, i].conjugate()))
        return mat.is_zero_matrix

    def _eval_is_Identity(self) -> FuzzyBool:

        def dirac(i, j):
            if i == j:
                return 1
            return 0
        return all((self[i, j] == dirac(i, j) for i in range(self.rows) for j in range(self.cols)))

    def _eval_is_lower_hessenberg(self):
        return all((self[i, j].is_zero for i in range(self.rows) for j in range(i + 2, self.cols)))

    def _eval_is_lower(self):
        return all((self[i, j].is_zero for i in range(self.rows) for j in range(i + 1, self.cols)))

    def _eval_is_symbolic(self):
        return self.has(Symbol)

    def _eval_is_symmetric(self, simpfunc):
        mat = self._new(self.rows, self.cols, lambda i, j: simpfunc(self[i, j] - self[j, i]))
        return mat.is_zero_matrix

    def _eval_is_zero_matrix(self):
        if any((i.is_zero == False for i in self)):
            return False
        if any((i.is_zero is None for i in self)):
            return None
        return True

    def _eval_is_upper_hessenberg(self):
        return all((self[i, j].is_zero for i in range(2, self.rows) for j in range(min(self.cols, i - 1))))

    def _eval_values(self):
        return [i for i in self if not i.is_zero]

    def _has_positive_diagonals(self):
        diagonal_entries = (self[i, i] for i in range(self.rows))
        return fuzzy_and((x.is_positive for x in diagonal_entries))

    def _has_nonnegative_diagonals(self):
        diagonal_entries = (self[i, i] for i in range(self.rows))
        return fuzzy_and((x.is_nonnegative for x in diagonal_entries))

    def atoms(self, *types):
        types = tuple((t if isinstance(t, type) else type(t) for t in types))
        if not types:
            types = (Atom,)
        return self._eval_atoms(*types)

    @property
    def free_symbols(self):
        return self._eval_free_symbols()

    def has(self, *patterns):
        return self._eval_has(*patterns)

    def is_anti_symmetric(self, simplify=True):
        simpfunc = simplify
        if not isfunction(simplify):
            simpfunc = _simplify if simplify else lambda x: x
        if not self.is_square:
            return False
        return self._eval_is_anti_symmetric(simpfunc)

    def is_diagonal(self):
        return self._eval_is_diagonal()

    @property
    def is_weakly_diagonally_dominant(self):
        if not self.is_square:
            return False
        rows, cols = self.shape

        def test_row(i):
            summation = self.zero
            for j in range(cols):
                if i != j:
                    summation += Abs(self[i, j])
            return (Abs(self[i, i]) - summation).is_nonnegative
        return fuzzy_and((test_row(i) for i in range(rows)))

    @property
    def is_strongly_diagonally_dominant(self):
        if not self.is_square:
            return False
        rows, cols = self.shape

        def test_row(i):
            summation = self.zero
            for j in range(cols):
                if i != j:
                    summation += Abs(self[i, j])
            return (Abs(self[i, i]) - summation).is_positive
        return fuzzy_and((test_row(i) for i in range(rows)))

    @property
    def is_hermitian(self):
        if not self.is_square:
            return False
        return self._eval_is_matrix_hermitian(_simplify)

    @property
    def is_Identity(self) -> FuzzyBool:
        if not self.is_square:
            return False
        return self._eval_is_Identity()

    @property
    def is_lower_hessenberg(self):
        return self._eval_is_lower_hessenberg()

    @property
    def is_lower(self):
        return self._eval_is_lower()

    @property
    def is_square(self):
        return self.rows == self.cols

    def is_symbolic(self):
        return self._eval_is_symbolic()

    def is_symmetric(self, simplify=True):
        simpfunc = simplify
        if not isfunction(simplify):
            simpfunc = _simplify if simplify else lambda x: x
        if not self.is_square:
            return False
        return self._eval_is_symmetric(simpfunc)

    @property
    def is_upper_hessenberg(self):
        return self._eval_is_upper_hessenberg()

    @property
    def is_upper(self):
        return all((self[i, j].is_zero for i in range(1, self.rows) for j in range(min(i, self.cols))))

    @property
    def is_zero_matrix(self):
        return self._eval_is_zero_matrix()

    def values(self):
        return self._eval_values()

class MatrixOperations(MatrixRequired):

    def _eval_adjoint(self):
        return self.transpose().conjugate()

    def _eval_applyfunc(self, f):
        out = self._new(self.rows, self.cols, [f(x) for x in self])
        return out

    def _eval_as_real_imag(self):
        return (self.applyfunc(re), self.applyfunc(im))

    def _eval_conjugate(self):
        return self.applyfunc(lambda x: x.conjugate())

    def _eval_permute_cols(self, perm):
        mapping = list(perm)

        def entry(i, j):
            return self[i, mapping[j]]
        return self._new(self.rows, self.cols, entry)

    def _eval_permute_rows(self, perm):
        mapping = list(perm)

        def entry(i, j):
            return self[mapping[i], j]
        return self._new(self.rows, self.cols, entry)

    def _eval_trace(self):
        return sum((self[i, i] for i in range(self.rows)))

    def _eval_transpose(self):
        return self._new(self.cols, self.rows, lambda i, j: self[j, i])

    def adjoint(self):
        return self._eval_adjoint()

    def applyfunc(self, f):
        if not callable(f):
            raise TypeError('`f` must be callable.')
        return self._eval_applyfunc(f)

    def as_real_imag(self, deep=True, **hints):
        return self._eval_as_real_imag()

    def conjugate(self):
        return self._eval_conjugate()

    def doit(self, **hints):
        return self.applyfunc(lambda x: x.doit(**hints))

    def evalf(self, n=15, subs=None, maxn=100, chop=False, strict=False, quad=None, verbose=False):
        options = {'subs': subs, 'maxn': maxn, 'chop': chop, 'strict': strict, 'quad': quad, 'verbose': verbose}
        return self.applyfunc(lambda i: i.evalf(n, **options))

    def expand(self, deep=True, modulus=None, power_base=True, power_exp=True, mul=True, log=True, multinomial=True, basic=True, **hints):
        return self.applyfunc(lambda x: x.expand(deep, modulus, power_base, power_exp, mul, log, multinomial, basic, **hints))

    @property
    def H(self):
        return self.T.C

    def permute(self, perm, orientation='rows', direction='forward'):
        from sympy.combinatorics import Permutation
        if direction == 'forwards':
            direction = 'forward'
        if direction == 'backwards':
            direction = 'backward'
        if orientation == 'columns':
            orientation = 'cols'
        if direction not in ('forward', 'backward'):
            raise TypeError("direction='{}' is an invalid kwarg. Try 'forward' or 'backward'".format(direction))
        if orientation not in ('rows', 'cols'):
            raise TypeError("orientation='{}' is an invalid kwarg. Try 'rows' or 'cols'".format(orientation))
        if not isinstance(perm, (Permutation, Iterable)):
            raise ValueError('{} must be a list, a list of lists, or a SymPy permutation object.'.format(perm))
        max_index = self.rows if orientation == 'rows' else self.cols
        if not all((0 <= t <= max_index for t in flatten(list(perm)))):
            raise IndexError('`swap` indices out of range.')
        if perm and (not isinstance(perm, Permutation)) and isinstance(perm[0], Iterable):
            if direction == 'forward':
                perm = list(reversed(perm))
            perm = Permutation(perm, size=max_index + 1)
        else:
            perm = Permutation(perm, size=max_index + 1)
        if orientation == 'rows':
            return self._eval_permute_rows(perm)
        if orientation == 'cols':
            return self._eval_permute_cols(perm)

    def permute_cols(self, swaps, direction='forward'):
        return self.permute(swaps, orientation='cols', direction=direction)

    def permute_rows(self, swaps, direction='forward'):
        return self.permute(swaps, orientation='rows', direction=direction)

    def refine(self, assumptions=True):
        return self.applyfunc(lambda x: refine(x, assumptions))

    def replace(self, F, G, map=False, simultaneous=True, exact=None):
        return self.applyfunc(lambda x: x.replace(F, G, map=map, simultaneous=simultaneous, exact=exact))

    def rot90(self, k=1):
        mod = k % 4
        if mod == 0:
            return self
        if mod == 1:
            return self[::-1, :].T
        if mod == 2:
            return self[::-1, ::-1]
        if mod == 3:
            return self[:, ::-1].T

    def simplify(self, **kwargs):
        return self.applyfunc(lambda x: x.simplify(**kwargs))

    def subs(self, *args, **kwargs):
        if len(args) == 1 and (not isinstance(args[0], (dict, set))) and iter(args[0]) and (not is_sequence(args[0])):
            args = (list(args[0]),)
        return self.applyfunc(lambda x: x.subs(*args, **kwargs))

    def trace(self):
        if self.rows != self.cols:
            raise NonSquareMatrixError()
        return self._eval_trace()

    def transpose(self):
        return self._eval_transpose()

    @property
    def T(self):
        return self.transpose()

    @property
    def C(self):
        return self.conjugate()

    def n(self, *args, **kwargs):
        return self.evalf(*args, **kwargs)

    def xreplace(self, rule):
        return self.applyfunc(lambda x: x.xreplace(rule))

    def _eval_simplify(self, **kwargs):
        return MatrixOperations.simplify(self, **kwargs)

    def _eval_trigsimp(self, **opts):
        from sympy.simplify.trigsimp import trigsimp
        return self.applyfunc(lambda x: trigsimp(x, **opts))

    def upper_triangular(self, k=0):

        def entry(i, j):
            return self[i, j] if i + k <= j else self.zero
        return self._new(self.rows, self.cols, entry)

    def lower_triangular(self, k=0):

        def entry(i, j):
            return self[i, j] if i + k >= j else self.zero
        return self._new(self.rows, self.cols, entry)

class MatrixArithmetic(MatrixRequired):
    _op_priority = 10.01

    def _eval_Abs(self):
        return self._new(self.rows, self.cols, lambda i, j: Abs(self[i, j]))

    def _eval_add(self, other):
        return self._new(self.rows, self.cols, lambda i, j: self[i, j] + other[i, j])

    def _eval_matrix_mul(self, other):

        def entry(i, j):
            vec = [self[i, k] * other[k, j] for k in range(self.cols)]
            try:
                return Add(*vec)
            except (TypeError, SympifyError):
                return reduce(lambda a, b: a + b, vec)
        return self._new(self.rows, other.cols, entry)

    def _eval_matrix_mul_elementwise(self, other):
        return self._new(self.rows, self.cols, lambda i, j: self[i, j] * other[i, j])

    def _eval_matrix_rmul(self, other):

        def entry(i, j):
            return sum((other[i, k] * self[k, j] for k in range(other.cols)))
        return self._new(other.rows, self.cols, entry)

    def _eval_pow_by_recursion(self, num):
        if num == 1:
            return self
        if num % 2 == 1:
            a, b = (self, self._eval_pow_by_recursion(num - 1))
        else:
            a = b = self._eval_pow_by_recursion(num // 2)
        return a.multiply(b)

    def _eval_pow_by_cayley(self, exp):
        from sympy.discrete.recurrences import linrec_coeffs
        row = self.shape[0]
        p = self.charpoly()
        coeffs = (-p).all_coeffs()[1:]
        coeffs = linrec_coeffs(coeffs, exp)
        new_mat = self.eye(row)
        ans = self.zeros(row)
        for i in range(row):
            ans += coeffs[i] * new_mat
            new_mat *= self
        return ans

    def _eval_pow_by_recursion_dotprodsimp(self, num, prevsimp=None):
        if prevsimp is None:
            prevsimp = [True] * len(self)
        if num == 1:
            return self
        if num % 2 == 1:
            a, b = (self, self._eval_pow_by_recursion_dotprodsimp(num - 1, prevsimp=prevsimp))
        else:
            a = b = self._eval_pow_by_recursion_dotprodsimp(num // 2, prevsimp=prevsimp)
        m = a.multiply(b, dotprodsimp=False)
        lenm = len(m)
        elems = [None] * lenm
        for i in range(lenm):
            if prevsimp[i]:
                elems[i], prevsimp[i] = _dotprodsimp(m[i], withsimp=True)
            else:
                elems[i] = m[i]
        return m._new(m.rows, m.cols, elems)

    def _eval_scalar_mul(self, other):
        return self._new(self.rows, self.cols, lambda i, j: self[i, j] * other)

    def _eval_scalar_rmul(self, other):
        return self._new(self.rows, self.cols, lambda i, j: other * self[i, j])

    def _eval_Mod(self, other):
        return self._new(self.rows, self.cols, lambda i, j: Mod(self[i, j], other))

    def __abs__(self):
        return self._eval_Abs()

    @call_highest_priority('__radd__')
    def __add__(self, other):
        if isinstance(other, NDimArray):
            return NotImplemented
        other = _matrixify(other)
        if hasattr(other, 'shape'):
            if self.shape != other.shape:
                raise ShapeError('Matrix size mismatch: %s + %s' % (self.shape, other.shape))
        if getattr(other, 'is_Matrix', False):
            a, b = (self, other)
            if a.__class__ != classof(a, b):
                b, a = (a, b)
            return a._eval_add(b)
        if getattr(other, 'is_MatrixLike', False):
            return MatrixArithmetic._eval_add(self, other)
        raise TypeError('cannot add %s and %s' % (type(self), type(other)))

    @call_highest_priority('__rtruediv__')
    def __truediv__(self, other):
        return self * (self.one / other)

    @call_highest_priority('__rmatmul__')
    def __matmul__(self, other):
        other = _matrixify(other)
        if not getattr(other, 'is_Matrix', False) and (not getattr(other, 'is_MatrixLike', False)):
            return NotImplemented
        return self.__mul__(other)

    def __mod__(self, other):
        return self.applyfunc(lambda x: x % other)

    @call_highest_priority('__rmul__')
    def __mul__(self, other):
        return self.multiply(other)

    def multiply(self, other, dotprodsimp=None):
        isimpbool = _get_intermediate_simp_bool(False, dotprodsimp)
        other = _matrixify(other)
        if hasattr(other, 'shape') and len(other.shape) == 2 and (getattr(other, 'is_Matrix', True) or getattr(other, 'is_MatrixLike', True)):
            if self.shape[1] != other.shape[0]:
                raise ShapeError('Matrix size mismatch: %s * %s.' % (self.shape, other.shape))
        if getattr(other, 'is_Matrix', False):
            m = self._eval_matrix_mul(other)
            if isimpbool:
                return m._new(m.rows, m.cols, [_dotprodsimp(e) for e in m])
            return m
        if getattr(other, 'is_MatrixLike', False):
            return MatrixArithmetic._eval_matrix_mul(self, other)
        if not isinstance(other, Iterable):
            try:
                return self._eval_scalar_mul(other)
            except TypeError:
                pass
        return NotImplemented

    def multiply_elementwise(self, other):
        if self.shape != other.shape:
            raise ShapeError('Matrix shapes must agree {} != {}'.format(self.shape, other.shape))
        return self._eval_matrix_mul_elementwise(other)

    def __neg__(self):
        return self._eval_scalar_mul(-1)

    @call_highest_priority('__rpow__')
    def __pow__(self, exp):
        return self.pow(exp)

    def pow(self, exp, method=None):
        if method is not None and method not in ['multiply', 'mulsimp', 'jordan', 'cayley']:
            raise TypeError('No such method')
        if self.rows != self.cols:
            raise NonSquareMatrixError()
        a = self
        jordan_pow = getattr(a, '_matrix_pow_by_jordan_blocks', None)
        exp = sympify(exp)
        if exp.is_zero:
            return a._new(a.rows, a.cols, lambda i, j: int(i == j))
        if exp == 1:
            return a
        diagonal = getattr(a, 'is_diagonal', None)
        if diagonal is not None and diagonal():
            return a._new(a.rows, a.cols, lambda i, j: a[i, j] ** exp if i == j else 0)
        if exp.is_Number and exp % 1 == 0:
            if a.rows == 1:
                return a._new([[a[0] ** exp]])
            if exp < 0:
                exp = -exp
                a = a.inv()
        if method == 'jordan':
            try:
                return jordan_pow(exp)
            except MatrixError:
                if method == 'jordan':
                    raise
        elif method == 'cayley':
            if not exp.is_Number or exp % 1 != 0:
                raise ValueError('cayley method is only valid for integer powers')
            return a._eval_pow_by_cayley(exp)
        elif method == 'mulsimp':
            if not exp.is_Number or exp % 1 != 0:
                raise ValueError('mulsimp method is only valid for integer powers')
            return a._eval_pow_by_recursion_dotprodsimp(exp)
        elif method == 'multiply':
            if not exp.is_Number or exp % 1 != 0:
                raise ValueError('multiply method is only valid for integer powers')
            return a._eval_pow_by_recursion(exp)
        elif method is None and exp.is_Number and (exp % 1 == 0):
            if exp.is_Float:
                exp = Integer(exp)
            if a.rows == 2 and exp > 100000:
                return jordan_pow(exp)
            elif _get_intermediate_simp_bool(True, None):
                return a._eval_pow_by_recursion_dotprodsimp(exp)
            elif exp > 10000:
                return a._eval_pow_by_cayley(exp)
            else:
                return a._eval_pow_by_recursion(exp)
        if jordan_pow:
            try:
                return jordan_pow(exp)
            except NonInvertibleMatrixError:
                if exp.is_integer is False or exp.is_nonnegative is False:
                    raise
        from sympy.matrices.expressions import MatPow
        return MatPow(a, exp)

    @call_highest_priority('__add__')
    def __radd__(self, other):
        return self + other

    @call_highest_priority('__matmul__')
    def __rmatmul__(self, other):
        other = _matrixify(other)
        if not getattr(other, 'is_Matrix', False) and (not getattr(other, 'is_MatrixLike', False)):
            return NotImplemented
        return self.__rmul__(other)

    @call_highest_priority('__mul__')
    def __rmul__(self, other):
        return self.rmultiply(other)

    def rmultiply(self, other, dotprodsimp=None):
        isimpbool = _get_intermediate_simp_bool(False, dotprodsimp)
        other = _matrixify(other)
        if hasattr(other, 'shape') and len(other.shape) == 2 and (getattr(other, 'is_Matrix', True) or getattr(other, 'is_MatrixLike', True)):
            if self.shape[0] != other.shape[1]:
                raise ShapeError('Matrix size mismatch.')
        if getattr(other, 'is_Matrix', False):
            m = self._eval_matrix_rmul(other)
            if isimpbool:
                return m._new(m.rows, m.cols, [_dotprodsimp(e) for e in m])
            return m
        if getattr(other, 'is_MatrixLike', False):
            return MatrixArithmetic._eval_matrix_rmul(self, other)
        if not isinstance(other, Iterable):
            try:
                return self._eval_scalar_rmul(other)
            except TypeError:
                pass
        return NotImplemented

    @call_highest_priority('__sub__')
    def __rsub__(self, a):
        return -self + a

    @call_highest_priority('__rsub__')
    def __sub__(self, a):
        return self + -a

class MatrixCommon(MatrixArithmetic, MatrixOperations, MatrixProperties, MatrixSpecial, MatrixShaping):
    _diff_wrt: bool = True

class _MinimalMatrix:
    is_MatrixLike = True
    _sympify = staticmethod(sympify)
    _class_priority = 3
    zero = S.Zero
    one = S.One
    is_Matrix = True
    is_MatrixExpr = False

    @classmethod
    def _new(cls, *args, **kwargs):
        return cls(*args, **kwargs)

    def __init__(self, rows, cols=None, mat=None, copy=False):
        if isfunction(mat):
            mat = [mat(i, j) for i in range(rows) for j in range(cols)]
        if cols is None and mat is None:
            mat = rows
        rows, cols = getattr(mat, 'shape', (rows, cols))
        try:
            if cols is None and mat is None:
                mat = rows
            cols = len(mat[0])
            rows = len(mat)
            mat = [x for l in mat for x in l]
        except (IndexError, TypeError):
            pass
        self.mat = tuple((self._sympify(x) for x in mat))
        self.rows, self.cols = (rows, cols)
        if self.rows is None or self.cols is None:
            raise NotImplementedError('Cannot initialize matrix with given parameters')

    def __getitem__(self, key):

        def _normalize_slices(row_slice, col_slice):
            if not isinstance(row_slice, slice):
                row_slice = slice(row_slice, row_slice + 1, None)
            row_slice = slice(*row_slice.indices(self.rows))
            if not isinstance(col_slice, slice):
                col_slice = slice(col_slice, col_slice + 1, None)
            col_slice = slice(*col_slice.indices(self.cols))
            return (row_slice, col_slice)

        def _coord_to_index(i, j):
            return i * self.cols + j
        if isinstance(key, tuple):
            i, j = key
            if isinstance(i, slice) or isinstance(j, slice):
                i, j = _normalize_slices(i, j)
                rowsList, colsList = (list(range(self.rows))[i], list(range(self.cols))[j])
                indices = (i * self.cols + j for i in rowsList for j in colsList)
                return self._new(len(rowsList), len(colsList), [self.mat[i] for i in indices])
            key = _coord_to_index(i, j)
        return self.mat[key]

    def __eq__(self, other):
        try:
            classof(self, other)
        except TypeError:
            return False
        return self.shape == other.shape and list(self) == list(other)

    def __len__(self):
        return self.rows * self.cols

    def __repr__(self):
        return '_MinimalMatrix({}, {}, {})'.format(self.rows, self.cols, self.mat)

    @property
    def shape(self):
        return (self.rows, self.cols)

class _CastableMatrix:

    def as_mutable(self):
        return self

    def as_immutable(self):
        return self

class _MatrixWrapper:
    is_Matrix = False
    is_MatrixLike = True

    def __init__(self, mat, shape):
        self.mat = mat
        self.shape = shape
        self.rows, self.cols = shape

    def __getitem__(self, key):
        if isinstance(key, tuple):
            return sympify(self.mat.__getitem__(key))
        return sympify(self.mat.__getitem__((key // self.rows, key % self.cols)))

    def __iter__(self):
        mat = self.mat
        cols = self.cols
        return iter((sympify(mat[r, c]) for r in range(self.rows) for c in range(cols)))

def _matrixify(mat):
    if getattr(mat, 'is_Matrix', False) or getattr(mat, 'is_MatrixLike', False):
        return mat
    if not (getattr(mat, 'is_Matrix', True) or getattr(mat, 'is_MatrixLike', True)):
        return mat
    shape = None
    if hasattr(mat, 'shape'):
        if len(mat.shape) == 2:
            shape = mat.shape
    elif hasattr(mat, 'rows') and hasattr(mat, 'cols'):
        shape = (mat.rows, mat.cols)
    if shape:
        return _MatrixWrapper(mat, shape)
    return mat

def a2idx(j, n=None):
    if not isinstance(j, int):
        jindex = getattr(j, '__index__', None)
        if jindex is not None:
            j = jindex()
        else:
            raise IndexError('Invalid index a[%r]' % (j,))
    if n is not None:
        if j < 0:
            j += n
        if not (j >= 0 and j < n):
            raise IndexError('Index out of range: a[%s]' % (j,))
    return int(j)

def classof(A, B):
    priority_A = getattr(A, '_class_priority', None)
    priority_B = getattr(B, '_class_priority', None)
    if None not in (priority_A, priority_B):
        if A._class_priority > B._class_priority:
            return A.__class__
        else:
            return B.__class__
    try:
        import numpy
    except ImportError:
        pass
    else:
        if isinstance(A, numpy.ndarray):
            return B.__class__
        if isinstance(B, numpy.ndarray):
            return A.__class__
    raise TypeError('Incompatible classes %s, %s' % (A.__class__, B.__class__))