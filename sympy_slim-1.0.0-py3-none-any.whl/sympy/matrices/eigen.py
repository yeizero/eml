from __future__ import annotations
from typing import TYPE_CHECKING, overload
from types import FunctionType
from collections import Counter
from sympy.core.expr import Expr
from sympy.core.sorting import default_sort_key
from sympy.core.evalf import DEFAULT_MAXPREC, PrecisionExhausted
from sympy.core.logic import fuzzy_and, fuzzy_or
from sympy.core.numbers import AlgebraicNumber, Float
from sympy.core.symbol import Dummy
from sympy.core.sympify import _sympify
from sympy.external.mpmath import prec_to_dps, local_workprec
from sympy.functions.elementary.miscellaneous import sqrt
from sympy.polys import roots, CRootOf, ZZ, QQ, EX
from sympy.polys.matrices import DomainMatrix
from sympy.polys.matrices.eigen import dom_eigenvects, dom_eigenvects_to_sympy
from sympy.polys.factortools import dup_factor_list
from sympy.polys.polytools import gcd, Poly
from .exceptions import MatrixError, NonSquareMatrixError
from .determinant import _find_reasonable_pivot
from .utilities import _iszero, _simplify
if TYPE_CHECKING:
    from typing import TypeVar, Callable, Any, Literal
    from sympy.matrices.matrixbase import MatrixBase
    Tmat = TypeVar('Tmat', bound=MatrixBase)
__doctest_requires__ = {('_is_indefinite', '_is_negative_definite', '_is_negative_semidefinite', '_is_positive_definite', '_is_positive_semidefinite'): ['matplotlib']}

def _eigenvals_eigenvects_mpmath(M):
    norm2 = lambda v: mp.sqrt(sum((i ** 2 for i in v)))
    v1 = None
    prec_orig = max((x._prec for x in M.atoms(Float)))
    eps = 2 ** (-prec_orig)
    prec = prec_orig
    to_expr = lambda e: Expr._from_mpmath(e, prec_orig)
    while prec < DEFAULT_MAXPREC:
        with local_workprec(prec) as mp:
            A = mp.matrix(M.evalf(n=prec_to_dps(prec)))
            E, ER = mp.eig(A)
            v2 = norm2([i for e in E for i in (mp.re(e), mp.im(e))])
            if v1 is not None and mp.fabs(v1 - v2) < eps:
                E = [to_expr(e) for e in E]
                ER = [[to_expr(e) for e in row] for row in ER.transpose().tolist()]
                return (E, ER)
            v1 = v2
        prec *= 2
    raise PrecisionExhausted

def _eigenvals_mpmath(M, multiple=False):
    result, _ = _eigenvals_eigenvects_mpmath(M)
    if multiple:
        return result
    return dict(Counter(result))

def _eigenvects_mpmath(M):
    from sympy import ImmutableMatrix
    E, ER = _eigenvals_eigenvects_mpmath(M)
    grouped_eigenvects = {}
    result = []
    for i in range(M.rows):
        eigenval = _sympify(E[i])
        eigenvect = ImmutableMatrix(ER[i])
        if eigenval in grouped_eigenvects:
            grouped_eigenvects[eigenval].append(eigenvect)
        else:
            grouped_eigenvects[eigenval] = [eigenvect]
    for eigenval, eigenvects in grouped_eigenvects.items():
        result.append((eigenval, len(eigenvects), eigenvects))
    return result

@overload
def _eigenvals(M, error_when_incomplete: bool=True, *, simplify: Callable[[Expr], Expr] | bool=False, multiple: Literal[False]=False, rational: bool=False, **flags: Any) -> dict[Expr, int]:
    pass

@overload
def _eigenvals(M, error_when_incomplete: bool=True, *, simplify: Callable[[Expr], Expr] | bool=False, multiple: Literal[True], rational: bool=False, **flags: Any) -> list[Expr]:
    pass

def _eigenvals(M, error_when_incomplete: bool=True, *, simplify: Callable[[Expr], Expr] | bool=False, multiple: bool=False, rational: bool=False, **flags: Any) -> dict[Expr, int] | list[Expr]:
    if not M:
        if multiple:
            return []
        return {}
    if not M.is_square:
        raise NonSquareMatrixError('{} must be a square matrix.'.format(M))
    if rational:
        from sympy.simplify import nsimplify
        M = M.applyfunc(lambda x: nsimplify(x, rational=True) if x.has(Float) else x)
    if M._rep.domain not in (ZZ, QQ):
        if all((x.is_number for x in M)) and M.has(Float):
            return _eigenvals_mpmath(M, multiple=multiple)
    if multiple:
        return _eigenvals_list(M, error_when_incomplete=error_when_incomplete, simplify=simplify, **flags)
    return _eigenvals_dict(M, error_when_incomplete=error_when_incomplete, simplify=simplify, **flags)
eigenvals_error_message = 'It is not always possible to express the eigenvalues of a matrix ' + 'of size 5x5 or higher in radicals. ' + 'We have CRootOf, but domains other than the rationals are not ' + 'currently supported. ' + 'If there are no symbols in the matrix, ' + 'it should still be possible to compute numeric approximations ' + 'of the eigenvalues using ' + 'M.evalf().eigenvals() or M.charpoly().nroots().'

def _eigenvals_list(M: MatrixBase, error_when_incomplete: bool=True, simplify: Callable[[Expr], Expr] | bool=False, **flags) -> list[Expr]:
    vals_dict = _eigenvals_dict(M, error_when_incomplete, simplify, **flags)
    vals = []
    for val, mult in vals_dict.items():
        vals.extend([val] * mult)
    return vals

def _eigenvals_dict(M: MatrixBase, error_when_incomplete: bool=True, simplify: Callable[[Expr], Expr] | bool=False, **flags: Any) -> dict[Expr, int]:
    iblocks = M.strongly_connected_components()
    all_eigs: dict[Expr, int] = {}
    expanded_eigs: dict[Expr, Expr] = {}
    is_dom = M._rep.domain in (ZZ, QQ)
    for b in iblocks:
        if is_dom and len(b) == 1:
            index = b[0]
            val = M[index, index]
            all_eigs[val] = all_eigs.get(val, 0) + 1
            continue
        block = M[b, b]
        if isinstance(simplify, FunctionType):
            charpoly = block.charpoly(simplify=simplify)
        else:
            charpoly = block.charpoly()
        factors = charpoly.factor_list()[1]
        for factor, multiplicity in factors:
            eigs = roots(factor, multiple=False, **flags)
            degree = int(factor.degree())
            if sum(eigs.values()) != degree:
                try:
                    eigs = dict(factor.all_roots(multiple=False))
                except NotImplementedError:
                    if error_when_incomplete:
                        raise MatrixError(eigenvals_error_message)
                    else:
                        eigs = {}
            for k, v in eigs.items():
                k_expanded = k.expand()
                if k_expanded in expanded_eigs:
                    k = expanded_eigs[k_expanded]
                else:
                    expanded_eigs[k_expanded] = k
                v_total = v * multiplicity
                if k in all_eigs:
                    all_eigs[k] += v_total
                else:
                    all_eigs[k] = v_total
    if not simplify:
        return all_eigs
    if not isinstance(simplify, FunctionType):
        simplify = _simplify
    return {simplify(key): value for key, value in all_eigs.items()}

def _eigenspace(M: Tmat, eigenval: Expr, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False) -> list[Tmat]:
    m = M._as_type(M - M.eye(M.rows) * eigenval)
    ret = m.nullspace(iszerofunc=iszerofunc)
    if len(ret) == 0 and simplify:
        ret = m.nullspace(iszerofunc=iszerofunc, simplify=True)
    if len(ret) == 0:
        raise NotImplementedError("Can't evaluate eigenvector for eigenvalue {}".format(eigenval))
    return ret

def _eigenvects_DOM(M: Tmat, **kwargs) -> list[tuple[Expr, int, list[Tmat]]] | None:
    DOM = DomainMatrix.from_Matrix(M, field=True, extension=True)
    DOM = DOM.to_dense()
    if DOM.domain != EX:
        rational, algebraic = dom_eigenvects(DOM)
        eigenvects = dom_eigenvects_to_sympy(rational, algebraic, M.__class__, **kwargs)
        eigenvects = sorted(eigenvects, key=lambda x: default_sort_key(x[0]))
        return eigenvects
    return None

def _eigenvects_sympy(M: Tmat, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=True, **flags: Any) -> list[tuple[Expr, int, list[Tmat]]]:
    eigenvals = M.eigenvals(rational=False, **flags)
    for x in eigenvals:
        if x.has(CRootOf):
            raise MatrixError('Eigenvector computation is not implemented if the matrix have eigenvalues in CRootOf form')
    eigenvals_sorted = sorted(eigenvals.items(), key=default_sort_key)
    ret = []
    for val, mult in eigenvals_sorted:
        vects = _eigenspace(M, val, iszerofunc=iszerofunc, simplify=simplify)
        ret.append((val, mult, vects))
    return ret

def _eigenvects(M: Tmat, error_when_incomplete: bool=True, iszerofunc: Callable[[Expr], bool | None]=_iszero, simplify: bool | Callable[[Expr], Expr]=False, *, chop: bool | int=False, **flags: Any) -> list[tuple[Expr, int, list[Tmat]]]:
    primitive = simplify is not False
    if not isinstance(simplify, FunctionType):
        simpfunc = _simplify if simplify else lambda x: x
    else:
        simpfunc = simplify
    has_floats = M.has(Float)
    if has_floats:
        if all((x.is_number for x in M.iter_values())):
            return _eigenvects_mpmath(M)
        from sympy.simplify import nsimplify
        M = M.applyfunc(lambda x: nsimplify(x, rational=True))
    ret = _eigenvects_DOM(M)
    if ret is None:
        ret = _eigenvects_sympy(M, iszerofunc, simplify=simplify, **flags)
    if primitive:

        def denom_clean(l: list[Tmat]) -> list[Tmat]:
            return [(v / gcd(v.flat())).applyfunc(simpfunc) for v in l]
        ret = [(val, mult, denom_clean(es)) for val, mult, es in ret]
    if has_floats:
        ret = [(val.evalf(chop=chop), mult, [v.evalf(chop=chop) for v in es]) for val, mult, es in ret]
    return ret

def _is_diagonalizable_with_eigen(M: MatrixBase, reals_only: bool=False) -> tuple[bool, list]:
    if not M.is_square:
        return (False, [])
    eigenvecs = M.eigenvects(simplify=True)
    for val, mult, basis in eigenvecs:
        if reals_only and (not val.is_real):
            return (False, eigenvecs)
        if mult != len(basis):
            return (False, eigenvecs)
    return (True, eigenvecs)

def _is_diagonalizable(M, reals_only=False, **kwargs) -> bool:
    if not M.is_square:
        return False
    if all((e.is_real for e in M)) and M.is_symmetric():
        return True
    if all((e.is_complex for e in M)) and M.is_hermitian:
        return True
    return _is_diagonalizable_with_eigen(M, reals_only=reals_only)[0]

def _householder_vector(x):
    if not x.cols == 1:
        raise ValueError('Input must be a column matrix')
    v = x.copy()
    v_plus = x.copy()
    v_minus = x.copy()
    q = x[0, 0] / abs(x[0, 0])
    norm_x = x.norm()
    v_plus[0, 0] = x[0, 0] + q * norm_x
    v_minus[0, 0] = x[0, 0] - q * norm_x
    if x[1:, 0].norm() == 0:
        bet = 0
        v[0, 0] = 1
    else:
        if v_plus.norm() <= v_minus.norm():
            v = v_plus
        else:
            v = v_minus
        v = v / v[0]
        bet = 2 / v.norm() ** 2
    return (v, bet)

def _bidiagonal_decmp_hholder(M):
    m = M.rows
    n = M.cols
    A = M.as_mutable()
    U, V = (A.eye(m), A.eye(n))
    for i in range(min(m, n)):
        v, bet = _householder_vector(A[i:, i])
        hh_mat = A.eye(m - i) - bet * v * v.H
        A[i:, i:] = hh_mat * A[i:, i:]
        temp = A.eye(m)
        temp[i:, i:] = hh_mat
        U = U * temp
        if i + 1 <= n - 2:
            v, bet = _householder_vector(A[i, i + 1:].T)
            hh_mat = A.eye(n - i - 1) - bet * v * v.H
            A[i:, i + 1:] = A[i:, i + 1:] * hh_mat
            temp = A.eye(n)
            temp[i + 1:, i + 1:] = hh_mat
            V = temp * V
    return (U, A, V)

def _eval_bidiag_hholder(M):
    m = M.rows
    n = M.cols
    A = M.as_mutable()
    for i in range(min(m, n)):
        v, bet = _householder_vector(A[i:, i])
        hh_mat = A.eye(m - i) - bet * v * v.H
        A[i:, i:] = hh_mat * A[i:, i:]
        if i + 1 <= n - 2:
            v, bet = _householder_vector(A[i, i + 1:].T)
            hh_mat = A.eye(n - i - 1) - bet * v * v.H
            A[i:, i + 1:] = A[i:, i + 1:] * hh_mat
    return A

def _bidiagonal_decomposition(M, upper=True):
    if not isinstance(upper, bool):
        raise ValueError('upper must be a boolean')
    if upper:
        return _bidiagonal_decmp_hholder(M)
    X = _bidiagonal_decmp_hholder(M.H)
    return (X[2].H, X[1].H, X[0].H)

def _bidiagonalize(M, upper=True):
    if not isinstance(upper, bool):
        raise ValueError('upper must be a boolean')
    if upper:
        return _eval_bidiag_hholder(M)
    return _eval_bidiag_hholder(M.H).H

def _diagonalize(M, reals_only=False, sort=False, normalize=False):
    if not M.is_square:
        raise NonSquareMatrixError()
    is_diagonalizable, eigenvecs = _is_diagonalizable_with_eigen(M, reals_only=reals_only)
    if not is_diagonalizable:
        raise MatrixError('Matrix is not diagonalizable')
    if sort:
        eigenvecs = sorted(eigenvecs, key=default_sort_key)
    p_cols, diag = ([], [])
    for val, mult, basis in eigenvecs:
        diag += [val] * mult
        p_cols += basis
    if normalize:
        p_cols = [v / v.norm() for v in p_cols]
    return (M.hstack(*p_cols), M.diag(*diag))

def _fuzzy_positive_definite(M):
    positive_diagonals = M._has_positive_diagonals()
    if positive_diagonals is False:
        return False
    if positive_diagonals and M.is_strongly_diagonally_dominant:
        return True
    return None

def _fuzzy_positive_semidefinite(M):
    nonnegative_diagonals = M._has_nonnegative_diagonals()
    if nonnegative_diagonals is False:
        return False
    if nonnegative_diagonals and M.is_weakly_diagonally_dominant:
        return True
    return None

def _is_positive_definite(M):
    if not M.is_hermitian:
        if not M.is_square:
            return False
        M = M + M.H
    fuzzy = _fuzzy_positive_definite(M)
    if fuzzy is not None:
        return fuzzy
    return _is_positive_definite_GE(M)

def _is_positive_semidefinite(M):
    if not M.is_hermitian:
        if not M.is_square:
            return False
        M = M + M.H
    fuzzy = _fuzzy_positive_semidefinite(M)
    if fuzzy is not None:
        return fuzzy
    return _is_positive_semidefinite_cholesky(M)

def _is_negative_definite(M):
    return _is_positive_definite(-M)

def _is_negative_semidefinite(M):
    return _is_positive_semidefinite(-M)

def _is_indefinite(M):
    if M.is_hermitian:
        eigen = M.eigenvals()
        args1 = [x.is_positive for x in eigen.keys()]
        any_positive = fuzzy_or(args1)
        args2 = [x.is_negative for x in eigen.keys()]
        any_negative = fuzzy_or(args2)
        return fuzzy_and([any_positive, any_negative])
    elif M.is_square:
        return (M + M.H).is_indefinite
    return False

def _is_positive_definite_GE(M):
    M = M.as_mutable()
    size = M.rows
    for i in range(size):
        is_positive = M[i, i].is_positive
        if is_positive is not True:
            return is_positive
        for j in range(i + 1, size):
            M[j, i + 1:] = M[i, i] * M[j, i + 1:] - M[j, i] * M[i, i + 1:]
    return True

def _is_positive_semidefinite_cholesky(M):
    M = M.as_mutable()
    for k in range(M.rows):
        diags = [M[i, i] for i in range(k, M.rows)]
        pivot, pivot_val, nonzero, _ = _find_reasonable_pivot(diags)
        if nonzero:
            return None
        if pivot is None:
            for i in range(k + 1, M.rows):
                for j in range(k, M.cols):
                    iszero = M[i, j].is_zero
                    if iszero is None:
                        return None
                    elif iszero is False:
                        return False
            return True
        assert pivot_val is not None
        if M[k, k].is_negative or pivot_val.is_negative:
            return False
        elif not (M[k, k].is_nonnegative and pivot_val.is_nonnegative):
            return None
        if pivot > 0:
            M.col_swap(k, k + pivot)
            M.row_swap(k, k + pivot)
        M[k, k] = sqrt(M[k, k])
        M[k, k + 1:] /= M[k, k]
        M[k + 1:, k + 1:] -= M[k, k + 1:].H * M[k, k + 1:]
    return M[-1, -1].is_nonnegative
_doc_positive_definite = 'Finds out the definiteness of a matrix.\n\n    Explanation\n    ===========\n\n    A square real matrix $A$ is:\n\n    - A positive definite matrix if $x^T A x > 0$\n      for all non-zero real vectors $x$.\n    - A positive semidefinite matrix if $x^T A x \\geq 0$\n      for all non-zero real vectors $x$.\n    - A negative definite matrix if $x^T A x < 0$\n      for all non-zero real vectors $x$.\n    - A negative semidefinite matrix if $x^T A x \\leq 0$\n      for all non-zero real vectors $x$.\n    - An indefinite matrix if there exists non-zero real vectors\n      $x, y$ with $x^T A x > 0 > y^T A y$.\n\n    A square complex matrix $A$ is:\n\n    - A positive definite matrix if $\\text{re}(x^H A x) > 0$\n      for all non-zero complex vectors $x$.\n    - A positive semidefinite matrix if $\\text{re}(x^H A x) \\geq 0$\n      for all non-zero complex vectors $x$.\n    - A negative definite matrix if $\\text{re}(x^H A x) < 0$\n      for all non-zero complex vectors $x$.\n    - A negative semidefinite matrix if $\\text{re}(x^H A x) \\leq 0$\n      for all non-zero complex vectors $x$.\n    - An indefinite matrix if there exists non-zero complex vectors\n      $x, y$ with $\\text{re}(x^H A x) > 0 > \\text{re}(y^H A y)$.\n\n    A matrix need not be symmetric or hermitian to be positive definite.\n\n    - A real non-symmetric matrix is positive definite if and only if\n      $\\frac{A + A^T}{2}$ is positive definite.\n    - A complex non-hermitian matrix is positive definite if and only if\n      $\\frac{A + A^H}{2}$ is positive definite.\n\n    And this extension can apply for all the definitions above.\n\n    However, for complex cases, you can restrict the definition of\n    $\\text{re}(x^H A x) > 0$ to $x^H A x > 0$ and require the matrix\n    to be hermitian.\n    But we do not present this restriction for computation because you\n    can check ``M.is_hermitian`` independently with this and use\n    the same procedure.\n\n    Examples\n    ========\n\n    An example of symmetric positive definite matrix:\n\n    .. plot::\n        :context: reset\n        :format: doctest\n        :include-source: True\n\n        >>> from sympy import Matrix, symbols\n        >>> from sympy.plotting import plot3d\n        >>> a, b = symbols(\'a b\')\n        >>> x = Matrix([a, b])\n\n        >>> A = Matrix([[1, 0], [0, 1]])\n        >>> A.is_positive_definite\n        True\n        >>> A.is_positive_semidefinite\n        True\n\n        >>> p = plot3d((x.T*A*x)[0, 0], (a, -1, 1), (b, -1, 1))\n\n    An example of symmetric positive semidefinite matrix:\n\n    .. plot::\n        :context: close-figs\n        :format: doctest\n        :include-source: True\n\n        >>> A = Matrix([[1, -1], [-1, 1]])\n        >>> A.is_positive_definite\n        False\n        >>> A.is_positive_semidefinite\n        True\n\n        >>> p = plot3d((x.T*A*x)[0, 0], (a, -1, 1), (b, -1, 1))\n\n    An example of symmetric negative definite matrix:\n\n    .. plot::\n        :context: close-figs\n        :format: doctest\n        :include-source: True\n\n        >>> A = Matrix([[-1, 0], [0, -1]])\n        >>> A.is_negative_definite\n        True\n        >>> A.is_negative_semidefinite\n        True\n        >>> A.is_indefinite\n        False\n\n        >>> p = plot3d((x.T*A*x)[0, 0], (a, -1, 1), (b, -1, 1))\n\n    An example of symmetric indefinite matrix:\n\n    .. plot::\n        :context: close-figs\n        :format: doctest\n        :include-source: True\n\n        >>> A = Matrix([[1, 2], [2, -1]])\n        >>> A.is_indefinite\n        True\n\n        >>> p = plot3d((x.T*A*x)[0, 0], (a, -1, 1), (b, -1, 1))\n\n    An example of non-symmetric positive definite matrix.\n\n    .. plot::\n        :context: close-figs\n        :format: doctest\n        :include-source: True\n\n        >>> A = Matrix([[1, 2], [-2, 1]])\n        >>> A.is_positive_definite\n        True\n        >>> A.is_positive_semidefinite\n        True\n\n        >>> p = plot3d((x.T*A*x)[0, 0], (a, -1, 1), (b, -1, 1))\n\n    Notes\n    =====\n\n    Although some people trivialize the definition of positive definite\n    matrices only for symmetric or hermitian matrices, this restriction\n    is not correct because it does not classify all instances of\n    positive definite matrices from the definition $x^T A x > 0$ or\n    $\\text{re}(x^H A x) > 0$.\n\n    For instance, ``Matrix([[1, 2], [-2, 1]])`` presented in\n    the example above is an example of real positive definite matrix\n    that is not symmetric.\n\n    However, since the following formula holds true;\n\n    .. math::\n        \\text{re}(x^H A x) > 0 \\iff\n        \\text{re}(x^H \\frac{A + A^H}{2} x) > 0\n\n    We can classify all positive definite matrices that may or may not\n    be symmetric or hermitian by transforming the matrix to\n    $\\frac{A + A^T}{2}$ or $\\frac{A + A^H}{2}$\n    (which is guaranteed to be always real symmetric or complex\n    hermitian) and we can defer most of the studies to symmetric or\n    hermitian positive definite matrices.\n\n    But it is a different problem for the existence of Cholesky\n    decomposition. Because even though a non symmetric or a non\n    hermitian matrix can be positive definite, Cholesky or LDL\n    decomposition does not exist because the decompositions require the\n    matrix to be symmetric or hermitian.\n\n    References\n    ==========\n\n    .. [1] https://en.wikipedia.org/wiki/Definiteness_of_a_matrix#Eigenvalues\n\n    .. [2] https://mathworld.wolfram.com/PositiveDefiniteMatrix.html\n\n    .. [3] Johnson, C. R. "Positive Definite Matrices." Amer.\n        Math. Monthly 77, 259-264 1970.\n    '
_is_positive_definite.__doc__ = _doc_positive_definite
_is_positive_semidefinite.__doc__ = _doc_positive_definite
_is_negative_definite.__doc__ = _doc_positive_definite
_is_negative_semidefinite.__doc__ = _doc_positive_definite
_is_indefinite.__doc__ = _doc_positive_definite

def _blocks_from_nullity_chain(d):
    mid = [2 * d[n] - d[n - 1] - d[n + 1] for n in range(1, len(d) - 1)]
    end = [d[-1] - d[-2]] if len(d) > 1 else [d[0]]
    return mid + end

@overload
def _jordan_form(M: Tmat, calc_transform: Literal[True]=True, *, chop: bool=False) -> tuple[Tmat, Tmat]:
    pass

@overload
def _jordan_form(M: Tmat, calc_transform: Literal[False], *, chop: bool=False) -> Tmat:
    pass

@overload
def _jordan_form(M: Tmat, calc_transform: bool=True, *, chop: bool=False) -> tuple[Tmat, Tmat] | Tmat:
    pass

def _jordan_form(M: Tmat, calc_transform: bool=True, *, chop: bool=False) -> tuple[Tmat, Tmat] | Tmat:
    if not M.is_square:
        raise NonSquareMatrixError('Only square matrices have Jordan forms')
    mat = M
    has_floats = M.has(Float)
    if has_floats:
        try:
            max_prec = max((term._prec for term in M.values() if isinstance(term, Float)))
        except ValueError:
            max_prec = 53
        max_dps = max(prec_to_dps(max_prec), 15)
    else:
        max_dps = -1

    def restore_floats1(arg: Tmat) -> Tmat:
        return arg.evalf(n=max_dps, chop=chop) if has_floats else arg

    def restore_floats2(arg1: Tmat, arg2: Tmat) -> tuple[Tmat, Tmat]:
        return (restore_floats1(arg1), restore_floats1(arg2))
    mat_cache: dict[tuple[Expr, int], Tmat] = {}

    def eig_mat(val: Expr, pow: int) -> Tmat:
        if (val, pow) in mat_cache:
            return mat_cache[val, pow]
        if (val, pow - 1) in mat_cache:
            mat_cache[val, pow] = mat_cache[val, pow - 1].multiply(mat_cache[val, 1], dotprodsimp=None)
        else:
            mat_cache[val, pow] = (mat - val * M.eye(M.rows)).pow(pow)
        return mat_cache[val, pow]

    def nullity_chain(val, algebraic_multiplicity):
        cols = M.cols
        ret = [0]
        nullity = cols - eig_mat(val, 1).rank()
        i = 2
        while nullity != ret[-1]:
            ret.append(nullity)
            if nullity == algebraic_multiplicity:
                break
            nullity = cols - eig_mat(val, i).rank()
            i += 1
            if nullity < ret[-1] or nullity > algebraic_multiplicity:
                raise MatrixError('SymPy had encountered an inconsistent result while computing Jordan block: {}'.format(M))
        return ret

    def pick_vec(small_basis, big_basis):
        if len(small_basis) == 0:
            return big_basis[0]
        for v in big_basis:
            _, pivots = M.hstack(*small_basis + [v]).echelon_form(with_pivots=True)
            if pivots[-1] == len(small_basis):
                return v
    if has_floats:
        from sympy.simplify import nsimplify
        mat = mat.applyfunc(lambda x: nsimplify(x, rational=True))
    has_rationals = all((num.is_number and num.is_rational for num in list(mat.iter_values())))
    if has_rationals:
        if calc_transform:
            P, J = _jordan_form_rational_matrix(mat, calc_transform=True)
            return restore_floats2(P, J)
        else:
            J = _jordan_form_rational_matrix(mat, calc_transform=False)
            return restore_floats1(J)
    eigs = mat.eigenvals()
    for x in eigs:
        if x.has(CRootOf):
            raise MatrixError('Jordan normal form is not implemented if the matrix have eigenvalues in CRootOf form')
    if len(eigs.keys()) == mat.cols:
        blocks = sorted(eigs.keys(), key=default_sort_key)
        jordan_mat = mat.diag(*blocks)
        if not calc_transform:
            return restore_floats1(jordan_mat)
        jordan_basis = [eig_mat(eig, 1).nullspace()[0] for eig in blocks]
        basis_mat = mat.hstack(*jordan_basis)
        return restore_floats2(basis_mat, jordan_mat)
    block_structure = []
    for eig in sorted(eigs.keys(), key=default_sort_key):
        algebraic_multiplicity = eigs[eig]
        chain = nullity_chain(eig, algebraic_multiplicity)
        block_sizes = _blocks_from_nullity_chain(chain)
        size_nums = [(i + 1, num) for i, num in enumerate(block_sizes)]
        size_nums.reverse()
        block_structure.extend([(eig, size) for size, num in size_nums for _ in range(num)])
    jordan_form_size = sum((size for eig, size in block_structure))
    if jordan_form_size != M.rows:
        raise MatrixError('SymPy had encountered an inconsistent result while computing Jordan block. : {}'.format(M))
    blocks2 = (mat.jordan_block(size=size, eigenvalue=eig) for eig, size in block_structure)
    jordan_mat = mat.diag(*blocks2)
    if not calc_transform:
        return restore_floats1(jordan_mat)
    jordan_basis = []
    for eig in sorted(eigs.keys(), key=default_sort_key):
        eig_basis: list[Tmat] = []
        for block_eig, size in block_structure:
            if block_eig != eig:
                continue
            null_big = eig_mat(eig, size).nullspace()
            null_small = eig_mat(eig, size - 1).nullspace()
            vec = pick_vec(null_small + eig_basis, null_big)
            new_vecs = [eig_mat(eig, i).multiply(vec, dotprodsimp=None) for i in range(size)]
            eig_basis.extend(new_vecs)
            jordan_basis.extend(reversed(new_vecs))
    basis_mat = mat.hstack(*jordan_basis)
    return restore_floats2(basis_mat, jordan_mat)

def _jordan_form_rational_matrix(M, calc_transform):
    dM = DomainMatrix.from_Matrix(M, field=True)

    def char_mat(algebraic_num):
        field = domain.algebraic_field(algebraic_num)
        mat_char = dM.convert_to(field) - dM.eye(M.shape, field) * field.unit
        return mat_char

    def factors_to_eigenvals():
        eigenvals_by_factor = {}
        for base, exp in factors:
            eigenvals = []
            if len(base) == 2:
                eigenvals.append(domain.to_sympy(-base[1] / base[0]))
            else:
                minpoly = Poly.from_list(base, l, domain=domain)
                roots_found = list(roots(minpoly.as_expr(), l, quartics=False, cubics=False))
                degree = minpoly.degree()
                if len(roots_found) != degree:
                    roots_found = minpoly.all_roots(multiple=True)
                eigenvals.extend(roots_found)
            eigenvals_by_factor[tuple(base), exp] = eigenvals
        return eigenvals_by_factor

    def get_alg_number(factor):
        minpoly = Poly.from_list(factor, l, domain=domain)
        algebraic_num = AlgebraicNumber((minpoly, eigenvals_by_factor[factor, multiplicity][0]), alias='a')
        return algebraic_num
    nullspace_cache = {}

    def nullity_chain(fac, algebraic_multiplicity):
        ret = [0]
        algebraic_num = get_alg_number(fac)
        mat_char = char_mat(algebraic_num)
        mat_pow = mat_char
        vecs = mat_pow.nullspace()
        nullity = vecs.shape[0]
        if algebraic_multiplicity == nullity:
            nullspace_cache[fac] = vecs
        while nullity != ret[-1]:
            ret.append(nullity)
            if nullity == algebraic_multiplicity:
                break
            mat_pow = mat_pow * mat_char
            nullity = mat_pow.nullspace().shape[0]
        return ret

    def pick_vec(small_basis, eig_basis, big_basis):
        if len(eig_basis) == 0 and small_basis.shape[0] == 0:
            return big_basis[0, :].transpose()
        small_basis = small_basis.transpose()
        for i in range(big_basis.shape[0]):
            v = big_basis[i, :].transpose()
            if len(eig_basis) != 0:
                _, pivots = DomainMatrix.hstack(small_basis, *eig_basis, v).rref()
            else:
                _, pivots = DomainMatrix.hstack(small_basis, v).rref()
            if pivots[-1] == small_basis.shape[1] + len(eig_basis):
                return v
    charpoly = dM.charpoly()
    domain = dM.domain
    l = Dummy('lambda')
    _, factors = dup_factor_list(charpoly, domain)
    eigenvals_by_factor = factors_to_eigenvals()
    block_structure = {}
    for fac, multiplicity in eigenvals_by_factor:
        if multiplicity == 1:
            block_sizes = [1]
        else:
            nullity = nullity_chain(fac, multiplicity)
            block_sizes = _blocks_from_nullity_chain(nullity)
        size_nums = [(i + 1, num) for i, num in enumerate(block_sizes)]
        size_nums.reverse()
        eigen_vals = eigenvals_by_factor[fac, multiplicity]
        for r in eigen_vals:
            for size, num in size_nums:
                block_structure.setdefault(r, []).extend([size] * num)
    jordan_form_size = sum((size for sizes in block_structure.values() for size in sizes))
    assert jordan_form_size == M.rows
    blocks2 = (M.jordan_block(size=size, eigenvalue=eig) for eig, sizes in block_structure.items() for size in sizes)
    jordan_mat = M.diag(*blocks2)
    if not calc_transform:
        return jordan_mat
    jordan_basis = []
    for (factor, multiplicity), eigen_vals in eigenvals_by_factor.items():
        if factor in nullspace_cache or multiplicity == 1:
            algebraic_num = None
            if factor not in nullspace_cache or len(factor) != 2:
                algebraic_num = get_alg_number(factor)
            if factor not in nullspace_cache:
                vects = char_mat(algebraic_num).nullspace()
            else:
                vects = nullspace_cache[factor]
            mat = vects.to_Matrix().T
            if len(factor) == 2:
                vect_lists = [mat]
            else:
                vect_lists = [mat.xreplace({algebraic_num: val}) for val in eigen_vals]
            jordan_basis.extend(vect_lists)
        else:
            genvecs_per_size = {}
            eig_basis = []
            algebraic_num = get_alg_number(factor)
            char_matrix = char_mat(algebraic_num)
            for index, size in enumerate(block_structure.get(eigen_vals[0], [])):
                null_big = char_matrix.pow(size).nullspace()
                null_small = char_matrix.pow(size - 1).nullspace()
                vec = pick_vec(null_small, eig_basis, null_big)
                mat_pow = char_matrix
                new_vecs = [DomainMatrix.eye(M.shape, domain) * vec]
                if size > 1:
                    new_vecs.append(mat_pow * vec)
                for _ in range(2, size):
                    mat_pow *= char_matrix
                    new_vecs.append(mat_pow * vec)
                eig_basis.extend(new_vecs)
                genvecs_per_size[factor, size, index] = new_vecs
            for eig in eigen_vals:
                for index, size in enumerate(block_structure.get(eigen_vals[0], [])):
                    genvecs = genvecs_per_size[factor, size, index]
                    if len(factor) != 2:
                        genvecs = [vects.to_Matrix().xreplace({algebraic_num: eig}) for vects in genvecs]
                    else:
                        genvecs = [vects.to_Matrix() for vects in genvecs]
                    jordan_basis.extend(reversed(genvecs))
    basis_mat = M.hstack(*jordan_basis)
    return (basis_mat, jordan_mat)

def _left_eigenvects(M, **flags):
    eigs = M.transpose().eigenvects(**flags)
    return [(val, mult, [l.transpose() for l in basis]) for val, mult, basis in eigs]

def _singular_values(M):
    if M.rows >= M.cols:
        valmultpairs = M.H.multiply(M).eigenvals()
    else:
        valmultpairs = M.multiply(M.H).eigenvals()
    vals = []
    for k, v in valmultpairs.items():
        vals += [sqrt(k)] * v
    if len(vals) < M.cols:
        vals += [M.zero] * (M.cols - len(vals))
    vals.sort(reverse=True, key=default_sort_key)
    return vals