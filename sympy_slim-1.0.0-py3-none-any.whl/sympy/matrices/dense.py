from __future__ import annotations
from typing import TYPE_CHECKING
import random
from sympy.core.basic import Basic
from sympy.core.singleton import S
from sympy.core.symbol import Symbol
from sympy.core.sympify import sympify
from sympy.functions.elementary.trigonometric import cos, sin
from sympy.utilities.decorator import doctest_depends_on
from sympy.utilities.exceptions import sympy_deprecation_warning
from sympy.utilities.iterables import is_sequence
from .exceptions import ShapeError
from .decompositions import _cholesky, _LDLdecomposition
from .matrixbase import MatrixBase
from .repmatrix import MutableRepMatrix, RepMatrix
from .solvers import _lower_triangular_solve, _upper_triangular_solve
if TYPE_CHECKING:
    from typing_extensions import Self
__doctest_requires__ = {('symarray',): ['numpy']}

def _iszero(x):
    return x.is_zero

class DenseMatrix(RepMatrix):
    is_MatrixExpr: bool = False
    _op_priority = 10.01
    _class_priority = 4

    @property
    def _mat(self):
        sympy_deprecation_warning('\n            The private _mat attribute of Matrix is deprecated. Use the\n            .flat() method instead.\n            ', deprecated_since_version='1.9', active_deprecations_target='deprecated-private-matrix-attributes')
        return self.flat()

    def _eval_inverse(self, **kwargs):
        return self.inv(method=kwargs.get('method', 'GE'), iszerofunc=kwargs.get('iszerofunc', _iszero), try_block_diag=kwargs.get('try_block_diag', False))

    def as_immutable(self):
        from .immutable import ImmutableDenseMatrix as cls
        return cls._fromrep(self._rep.copy())

    def as_mutable(self):
        return Matrix(self)

    def cholesky(self, hermitian=True):
        return _cholesky(self, hermitian=hermitian)

    def LDLdecomposition(self, hermitian: bool=True) -> tuple[Self, Self]:
        return _LDLdecomposition(self, hermitian=hermitian)

    def lower_triangular_solve(self, rhs):
        return _lower_triangular_solve(self, rhs)

    def upper_triangular_solve(self, rhs):
        return _upper_triangular_solve(self, rhs)
    cholesky.__doc__ = _cholesky.__doc__
    LDLdecomposition.__doc__ = _LDLdecomposition.__doc__
    lower_triangular_solve.__doc__ = _lower_triangular_solve.__doc__
    upper_triangular_solve.__doc__ = _upper_triangular_solve.__doc__

def _force_mutable(x):
    if getattr(x, 'is_Matrix', False):
        return x.as_mutable()
    elif isinstance(x, Basic):
        return x
    elif hasattr(x, '__array__'):
        a = x.__array__()
        if len(a.shape) == 0:
            return sympify(a)
        return Matrix(x)
    return x

class MutableDenseMatrix(DenseMatrix, MutableRepMatrix):

    def simplify(self, **kwargs) -> None:
        from sympy.simplify.simplify import simplify as _simplify
        for (i, j), element in self.todok().items():
            self[i, j] = _simplify(element, **kwargs)
MutableMatrix = MutableDenseMatrix
Matrix = MutableDenseMatrix

def list2numpy(l, dtype=object):
    from numpy import empty
    a = empty(len(l), dtype)
    for i, s in enumerate(l):
        a[i] = s
    return a

def matrix2numpy(m, dtype=object):
    from numpy import empty
    a = empty(m.shape, dtype)
    for i in range(m.rows):
        for j in range(m.cols):
            a[i, j] = m[i, j]
    return a

def rot_givens(i, j, theta, dim=3):
    if not isinstance(dim, int) or dim < 2:
        raise ValueError('dim must be an integer bigger than one, got {}.'.format(dim))
    if i == j:
        raise ValueError('i and j must be different, got ({}, {})'.format(i, j))
    for ij in [i, j]:
        if not isinstance(ij, int) or ij < 0 or ij > dim - 1:
            raise ValueError('i and j must be integers between 0 and {}, got i={} and j={}.'.format(dim - 1, i, j))
    theta = sympify(theta)
    c = cos(theta)
    s = sin(theta)
    M = eye(dim)
    M[i, i] = c
    M[j, j] = c
    M[i, j] = s
    M[j, i] = -s
    return M

def rot_axis3(theta):
    return rot_givens(0, 1, theta, dim=3)

def rot_axis2(theta):
    return rot_givens(2, 0, theta, dim=3)

def rot_axis1(theta):
    return rot_givens(1, 2, theta, dim=3)

def rot_ccw_axis3(theta):
    return rot_givens(1, 0, theta, dim=3)

def rot_ccw_axis2(theta):
    return rot_givens(0, 2, theta, dim=3)

def rot_ccw_axis1(theta):
    return rot_givens(2, 1, theta, dim=3)

@doctest_depends_on(modules=('numpy',))
def symarray(prefix, shape, **kwargs):
    from numpy import empty, ndindex
    arr = empty(shape, dtype=object)
    for index in ndindex(shape):
        arr[index] = Symbol('%s_%s' % (prefix, '_'.join(map(str, index))), **kwargs)
    return arr

def casoratian(seqs, n, zero=True):
    seqs = list(map(sympify, seqs))
    if not zero:
        f = lambda i, j: seqs[j].subs(n, n + i)
    else:
        f = lambda i, j: seqs[j].subs(n, i)
    k = len(seqs)
    return Matrix(k, k, f).det()

def eye(*args, **kwargs):
    return Matrix.eye(*args, **kwargs)

def diag(*values, strict=True, unpack=False, **kwargs):
    return Matrix.diag(*values, strict=strict, unpack=unpack, **kwargs)

def GramSchmidt(vlist, orthonormal=False):
    return MutableDenseMatrix.orthogonalize(*vlist, normalize=orthonormal, rankcheck=True)

def hessian(f, varlist, constraints=()):
    if isinstance(varlist, MatrixBase):
        if 1 not in varlist.shape:
            raise ShapeError('`varlist` must be a column or row vector.')
        if varlist.cols == 1:
            varlist = varlist.T
        varlist = varlist.tolist()[0]
    if is_sequence(varlist):
        n = len(varlist)
        if not n:
            raise ShapeError('`len(varlist)` must not be zero.')
    else:
        raise ValueError('Improper variable list in hessian function')
    if not getattr(f, 'diff'):
        raise ValueError('Function `f` (%s) is not differentiable' % f)
    m = len(constraints)
    N = m + n
    out = zeros(N)
    for k, g in enumerate(constraints):
        if not getattr(g, 'diff'):
            raise ValueError('Function `f` (%s) is not differentiable' % f)
        for i in range(n):
            out[k, i + m] = g.diff(varlist[i])
    for i in range(n):
        for j in range(i, n):
            out[i + m, j + m] = f.diff(varlist[i]).diff(varlist[j])
    for i in range(N):
        for j in range(i + 1, N):
            out[j, i] = out[i, j]
    return out

def jordan_cell(eigenval, n):
    return Matrix.jordan_block(size=n, eigenvalue=eigenval)

def matrix_multiply_elementwise(A, B):
    return A.multiply_elementwise(B)

def ones(*args, **kwargs):
    if 'c' in kwargs:
        kwargs['cols'] = kwargs.pop('c')
    return Matrix.ones(*args, **kwargs)

def randMatrix(r, c=None, min=0, max=99, seed=None, symmetric=False, percent=100, prng=None):
    prng = prng or random.Random(seed)
    if c is None:
        c = r
    if symmetric and r != c:
        raise ValueError('For symmetric matrices, r must equal c, but %i != %i' % (r, c))
    ij = range(r * c)
    if percent != 100:
        ij = prng.sample(ij, int(len(ij) * percent // 100))
    m = zeros(r, c)
    if not symmetric:
        for ijk in ij:
            i, j = divmod(ijk, c)
            m[i, j] = prng.randint(min, max)
    else:
        for ijk in ij:
            i, j = divmod(ijk, c)
            if i <= j:
                m[i, j] = m[j, i] = prng.randint(min, max)
    return m

def wronskian(functions, var, method='bareiss'):
    functions = [sympify(f) for f in functions]
    n = len(functions)
    if n == 0:
        return S.One
    W = Matrix(n, n, lambda i, j: functions[i].diff(var, j))
    return W.det(method)

def zeros(*args, **kwargs):
    if 'c' in kwargs:
        kwargs['cols'] = kwargs.pop('c')
    return Matrix.zeros(*args, **kwargs)