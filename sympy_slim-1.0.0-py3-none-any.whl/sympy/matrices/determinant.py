from __future__ import annotations
from typing import TYPE_CHECKING
from types import FunctionType
from sympy.core.add import Add
from sympy.core.cache import cacheit
from sympy.core.numbers import Float, Integer
from sympy.core.singleton import S
from sympy.core.symbol import uniquely_named_symbol
from sympy.core.mul import Mul
from sympy.polys import PurePoly, cancel
from sympy.functions.combinatorial.numbers import nC
from sympy.polys.matrices.domainmatrix import DomainMatrix
from sympy.polys.matrices.ddm import DDM
from .exceptions import NonSquareMatrixError
from .utilities import _get_intermediate_simp, _get_intermediate_simp_bool, _iszero, _is_zero_after_expand_mul, _dotprodsimp, _simplify
if TYPE_CHECKING:
    from typing import Callable, Iterable
    from sympy.core.expr import Expr
    from sympy.matrices.matrixbase import MatrixBase

def _find_reasonable_pivot(col: Iterable[Expr], iszerofunc: Callable[[Expr], bool | None]=_iszero, simpfunc: Callable[[Expr], Expr]=_simplify) -> tuple[int | None, Expr | None, bool, list[tuple[int, Expr]]]:
    newly_determined: list[tuple[int, Expr]] = []
    col = list(col)
    if all((isinstance(x, (Float, Integer)) for x in col)) and any((isinstance(x, Float) for x in col)):
        col_abs = [abs(x) for x in col]
        max_value = max(col_abs)
        if iszerofunc(max_value):
            if max_value != 0:
                newly_determined = [(i, S.Zero) for i, x in enumerate(col) if x != 0]
            return (None, None, False, newly_determined)
        index = col_abs.index(max_value)
        return (index, col[index], False, newly_determined)
    possible_zeros = []
    for i, x in enumerate(col):
        is_zero = iszerofunc(x)
        if is_zero == False:
            return (i, x, False, newly_determined)
        possible_zeros.append(is_zero)
    if all(possible_zeros):
        return (None, None, False, newly_determined)
    for i, x in enumerate(col):
        if possible_zeros[i] is not None:
            continue
        simped = simpfunc(x)
        is_zero = iszerofunc(simped)
        if is_zero in (True, False):
            newly_determined.append((i, simped))
        if is_zero == False:
            return (i, simped, False, newly_determined)
        possible_zeros[i] = is_zero
    if all(possible_zeros):
        return (None, None, False, newly_determined)
    for i, x in enumerate(col):
        if possible_zeros[i] is not None:
            continue
        if x.equals(S.Zero):
            possible_zeros[i] = True
            newly_determined.append((i, S.Zero))
    if all(possible_zeros):
        return (None, None, False, newly_determined)
    i = possible_zeros.index(None)
    return (i, col[i], True, newly_determined)

def _find_reasonable_pivot_naive(col: Iterable[Expr], iszerofunc: Callable[[Expr], bool | None]=_iszero, simpfunc: Callable[[Expr], Expr] | None=_simplify) -> tuple[int | None, Expr | None, bool, list[tuple[int, Expr]]]:
    indeterminates = []
    for i, col_val in enumerate(col):
        col_val_is_zero = iszerofunc(col_val)
        if col_val_is_zero == False:
            return (i, col_val, False, [])
        elif col_val_is_zero is None:
            indeterminates.append((i, col_val))
    if len(indeterminates) == 0:
        return (None, None, False, [])
    if simpfunc is None:
        return (indeterminates[0][0], indeterminates[0][1], True, [])
    newly_determined = []
    for i, col_val in indeterminates:
        tmp_col_val = simpfunc(col_val)
        if id(col_val) != id(tmp_col_val):
            newly_determined.append((i, tmp_col_val))
            if iszerofunc(tmp_col_val) == False:
                return (i, tmp_col_val, False, newly_determined)
    return (indeterminates[0][0], indeterminates[0][1], True, newly_determined)

def _berkowitz_toeplitz_matrix(M):
    if M.rows == 0 and M.cols == 0:
        return M._new(1, 1, [M.one])
    a, R = (M[0, 0], M[0, 1:])
    C, A = (M[1:, 0], M[1:, 1:])
    diags = [C]
    for i in range(M.rows - 2):
        diags.append(A.multiply(diags[i], dotprodsimp=None))
    diags = [(-R).multiply(d, dotprodsimp=None)[0, 0] for d in diags]
    diags = [M.one, -a] + diags

    def entry(i, j):
        if j > i:
            return M.zero
        return diags[i - j]
    toeplitz = M._new(M.cols + 1, M.rows, entry)
    return (A, toeplitz)

def _berkowitz_vector(M):
    if M.rows == 0 and M.cols == 0:
        return M._new(1, 1, [M.one])
    elif M.rows == 1 and M.cols == 1:
        return M._new(2, 1, [M.one, -M[0, 0]])
    submat, toeplitz = _berkowitz_toeplitz_matrix(M)
    return toeplitz.multiply(_berkowitz_vector(submat), dotprodsimp=None)

def _adjugate(M, method='berkowitz'):
    return M.cofactor_matrix(method=method).transpose()

def _charpoly(M, x: str | Expr='lambda', simplify: Callable[[Expr], Expr]=_simplify) -> PurePoly:
    if not M.is_square:
        raise NonSquareMatrixError()
    dM = M.to_DM()
    K = dM.domain
    cp = dM.charpoly()
    x = uniquely_named_symbol(x, [M], modify=lambda s: '_' + s)
    if K.is_EXRAW or simplify is not _simplify:
        berk_vector = [K.to_sympy(c) for c in cp]
        berk_vector = [simplify(a) for a in berk_vector]
        p = PurePoly(berk_vector, x)
    else:
        p = PurePoly(cp, x, domain=K)
    return p

def _cofactor(M, i, j, method='berkowitz'):
    if not M.is_square or M.rows < 1:
        raise NonSquareMatrixError()
    return S.NegativeOne ** ((i + j) % 2) * M.minor(i, j, method)

def _cofactor_matrix(M, method='berkowitz'):
    if not M.is_square:
        raise NonSquareMatrixError()
    return M._new(M.rows, M.cols, lambda i, j: M.cofactor(i, j, method))

def _per(M):
    import itertools
    m, n = M.shape
    if m == 0 or n == 0:
        return S.One
    if m > n:
        M = M.T
        m, n = (n, m)
    s = list(range(n))
    subsets = []
    for i in range(1, m + 1):
        subsets += list(map(list, itertools.combinations(s, i)))
    perm = 0
    for subset in subsets:
        prod = 1
        sub_len = len(subset)
        for i in range(m):
            prod *= sum((M[i, j] for j in subset))
        perm += prod * S.NegativeOne ** sub_len * nC(n - sub_len, m - sub_len)
    perm *= S.NegativeOne ** m
    return perm.simplify()

def _det_DOM(M):
    DOM = DomainMatrix.from_Matrix(M, field=True, extension=True)
    K = DOM.domain
    return K.to_sympy(DOM.det())

def _det(M, method='bareiss', iszerofunc=None):
    method = method.lower()
    if method == 'bareis':
        method = 'bareiss'
    elif method == 'det_lu':
        method = 'lu'
    if method not in ('bareiss', 'berkowitz', 'lu', 'domain-ge', 'bird', 'laplace'):
        raise ValueError("Determinant method '%s' unrecognized" % method)
    if iszerofunc is None:
        if method == 'bareiss':
            iszerofunc = _is_zero_after_expand_mul
        elif method == 'lu':
            iszerofunc = _iszero
    elif not isinstance(iszerofunc, FunctionType):
        raise ValueError("Zero testing method '%s' unrecognized" % iszerofunc)
    n = M.rows
    if n == M.cols:
        if n == 0:
            return M.one
        elif n == 1:
            return M[0, 0]
        elif n == 2:
            m = M[0, 0] * M[1, 1] - M[0, 1] * M[1, 0]
            return _get_intermediate_simp(_dotprodsimp)(m)
        elif n == 3:
            m = M[0, 0] * M[1, 1] * M[2, 2] + M[0, 1] * M[1, 2] * M[2, 0] + M[0, 2] * M[1, 0] * M[2, 1] - M[0, 2] * M[1, 1] * M[2, 0] - M[0, 0] * M[1, 2] * M[2, 1] - M[0, 1] * M[1, 0] * M[2, 2]
            return _get_intermediate_simp(_dotprodsimp)(m)
    dets = []
    for b in M.strongly_connected_components():
        if method == 'domain-ge':
            det = _det_DOM(M[b, b])
        elif method == 'bareiss':
            det = M[b, b]._eval_det_bareiss(iszerofunc=iszerofunc)
        elif method == 'berkowitz':
            det = M[b, b]._eval_det_berkowitz()
        elif method == 'lu':
            det = M[b, b]._eval_det_lu(iszerofunc=iszerofunc)
        elif method == 'bird':
            det = M[b, b]._eval_det_bird()
        elif method == 'laplace':
            det = M[b, b]._eval_det_laplace()
        else:
            assert False
        dets.append(det)
    return Mul(*dets)

def _det_bareiss(M: MatrixBase, iszerofunc: Callable[[Expr], bool | None]=_is_zero_after_expand_mul) -> Expr:

    def bareiss(mat: MatrixBase, cumm: Expr=S.One):
        if mat.rows == 0:
            return mat.one
        elif mat.rows == 1:
            return mat[0, 0]
        pivot_pos, pivot_val, _, _ = _find_reasonable_pivot(mat[:, 0].flat(), iszerofunc=iszerofunc)
        if pivot_pos is None or pivot_val is None:
            return mat.zero
        sign = (-1) ** (pivot_pos % 2)
        rows = [i for i in range(mat.rows) if i != pivot_pos]
        cols = list(range(mat.cols))
        tmp_mat = mat.extract(rows, cols)

        def entry(i, j):
            ret = (pivot_val * tmp_mat[i, j + 1] - mat[pivot_pos, j + 1] * tmp_mat[i, 0]) / cumm
            if _get_intermediate_simp_bool(True):
                return _dotprodsimp(ret)
            elif not ret.is_Atom:
                return cancel(ret)
            return ret
        return sign * bareiss(M._new(mat.rows - 1, mat.cols - 1, entry), pivot_val)
    if not M.is_square:
        raise NonSquareMatrixError()
    if M.rows == 0:
        return M.one
    return bareiss(M)

def _det_berkowitz(M):
    if not M.is_square:
        raise NonSquareMatrixError()
    if M.rows == 0:
        return M.one
    berk_vector = _berkowitz_vector(M)
    return (-1) ** (len(berk_vector) - 1) * berk_vector[-1]

def _det_LU(M, iszerofunc=_iszero, simpfunc=None):
    if not M.is_square:
        raise NonSquareMatrixError()
    if M.rows == 0:
        return M.one
    lu, row_swaps = M.LUdecomposition_Simple(iszerofunc=iszerofunc, simpfunc=simpfunc)
    if iszerofunc(lu[lu.rows - 1, lu.rows - 1]):
        return M.zero
    det = -M.one if len(row_swaps) % 2 else M.one
    for k in range(lu.rows):
        det *= lu[k, k]
    return det

@cacheit
def __det_laplace(M):
    n = M.shape[0]
    if n == 1:
        return M[0]
    elif n == 2:
        return M[0, 0] * M[1, 1] - M[0, 1] * M[1, 0]
    else:
        minor = lambda i: __det_laplace(M.minor_submatrix(0, i))
        return Add(*((-1) ** i * M[0, i] * minor(i) for i in range(n)))

def _det_laplace(M):
    if not M.is_square:
        raise NonSquareMatrixError()
    if M.shape[0] == 0:
        return M.one
    return __det_laplace(M.as_immutable())

def _det_bird(M):

    def mu(X):
        n = X.shape[0]
        zero = X.domain.zero
        total = zero
        diag_sums = [zero]
        for i in reversed(range(1, n)):
            total -= X[i][i]
            diag_sums.append(total)
        diag_sums = diag_sums[::-1]
        elems = [[zero] * i + [diag_sums[i]] + X_i[i + 1:] for i, X_i in enumerate(X)]
        return DDM(elems, X.shape, X.domain)
    Mddm = M._rep.to_ddm()
    n = M.shape[0]
    if n == 0:
        return M.one
    Fn1 = Mddm
    for _ in range(n - 1):
        Fn1 = mu(Fn1).matmul(Mddm)
    detA = Fn1[0][0]
    if n % 2 == 0:
        detA = -detA
    return Mddm.domain.to_sympy(detA)

def _minor(M, i, j, method='berkowitz'):
    if not M.is_square:
        raise NonSquareMatrixError()
    return M.minor_submatrix(i, j).det(method=method)

def _minor_submatrix(M, i, j):
    if i < 0:
        i += M.rows
    if j < 0:
        j += M.cols
    if not 0 <= i < M.rows or not 0 <= j < M.cols:
        raise ValueError('`i` and `j` must satisfy 0 <= i < ``M.rows`` (%d)' % M.rows + 'and 0 <= j < ``M.cols`` (%d).' % M.cols)
    rows = [a for a in range(M.rows) if a != i]
    cols = [a for a in range(M.cols) if a != j]
    return M.extract(rows, cols)