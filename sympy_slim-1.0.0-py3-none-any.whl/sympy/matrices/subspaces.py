from __future__ import annotations
from typing import TYPE_CHECKING
from .utilities import _iszero
if TYPE_CHECKING:
    from typing import TypeVar
    from sympy.matrices.matrixbase import MatrixBase
    Tmat = TypeVar('Tmat', bound=MatrixBase)

def _columnspace(M: Tmat, simplify=False) -> list[Tmat]:
    reduced, pivots = M.echelon_form(simplify=simplify, with_pivots=True)
    return [M.col(i) for i in pivots]

def _nullspace(M, simplify=False, iszerofunc=_iszero):
    reduced, pivots = M.rref(iszerofunc=iszerofunc, simplify=simplify)
    free_vars = [i for i in range(M.cols) if i not in pivots]
    basis = []
    for free_var in free_vars:
        vec = [M.zero] * M.cols
        vec[free_var] = M.one
        for piv_row, piv_col in enumerate(pivots):
            vec[piv_col] -= reduced[piv_row, free_var]
        basis.append(vec)
    return [M._new(M.cols, 1, b) for b in basis]

def _rowspace(M, simplify=False):
    reduced, pivots = M.echelon_form(simplify=simplify, with_pivots=True)
    return [reduced.row(i) for i in range(len(pivots))]

def _orthogonalize(cls, *vecs, normalize=False, rankcheck=False):
    from .decompositions import _QRdecomposition_optional
    if not vecs:
        return []
    all_row_vecs = vecs[0].rows == 1
    vecs = [x.vec() for x in vecs]
    M = cls.hstack(*vecs)
    Q, R = _QRdecomposition_optional(M, normalize=normalize)
    if rankcheck and Q.cols < len(vecs):
        raise ValueError('GramSchmidt: vector set not linearly independent')
    ret = []
    for i in range(Q.cols):
        if all_row_vecs:
            col = cls(Q[:, i].T)
        else:
            col = cls(Q[:, i])
        ret.append(col)
    return ret