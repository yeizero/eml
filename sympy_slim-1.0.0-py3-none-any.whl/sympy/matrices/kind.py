from __future__ import annotations
from sympy.core.kind import Kind, _NumberKind, NumberKind
from sympy.core.mul import Mul

class MatrixKind(Kind):

    def __new__(cls, element_kind=NumberKind):
        obj = super().__new__(cls, element_kind)
        obj.element_kind = element_kind
        return obj

    def __repr__(self):
        return 'MatrixKind(%s)' % self.element_kind

@Mul._kind_dispatcher.register(_NumberKind, MatrixKind)
def num_mat_mul(k1, k2):
    if not isinstance(k2, MatrixKind):
        k1, k2 = (k2, k1)
    elemk = Mul._kind_dispatcher(k1, k2.element_kind)
    return MatrixKind(elemk)

@Mul._kind_dispatcher.register(MatrixKind, MatrixKind)
def mat_mat_mul(k1, k2):
    elemk = Mul._kind_dispatcher(k1.element_kind, k2.element_kind)
    return MatrixKind(elemk)