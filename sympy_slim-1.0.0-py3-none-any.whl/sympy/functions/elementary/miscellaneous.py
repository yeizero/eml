from __future__ import annotations
from sympy.core import S, sympify, NumberKind
from sympy.utilities.iterables import sift
from sympy.core.add import Add
from sympy.core.containers import Tuple
from sympy.core.operations import LatticeOp, ShortCircuit
from sympy.core.function import Application, Lambda, ArgumentIndexError, DefinedFunction
from sympy.core.expr import Expr
from sympy.core.exprtools import factor_terms
from sympy.core.mod import Mod
from sympy.core.mul import Mul
from sympy.core.numbers import Rational
from sympy.core.power import Pow
from sympy.core.relational import Eq, Relational
from sympy.core.singleton import Singleton
from sympy.core.sorting import ordered
from sympy.core.symbol import Dummy
from sympy.core.rules import Transform
from sympy.core.logic import fuzzy_and, fuzzy_or, _torf
from sympy.core.traversal import walk
from sympy.core.numbers import Integer
from sympy.logic.boolalg import And, Or

def _minmax_as_Piecewise(op, *args):
    from sympy.functions.elementary.piecewise import Piecewise
    ec = []
    for i, a in enumerate(args):
        c = [Relational(a, args[j], op) for j in range(i + 1, len(args))]
        ec.append((a, And(*c)))
    return Piecewise(*ec)

class IdentityFunction(Lambda, metaclass=Singleton):
    _symbol = Dummy('x')

    @property
    def signature(self):
        return Tuple(self._symbol)

    @property
    def expr(self):
        return self._symbol
Id = S.IdentityFunction

def sqrt(arg, evaluate=None):
    return Pow(arg, S.Half, evaluate=evaluate)

def cbrt(arg, evaluate=None):
    return Pow(arg, Rational(1, 3), evaluate=evaluate)

def root(arg, n, k=0, evaluate=None):
    n = sympify(n)
    if k:
        return Mul(Pow(arg, S.One / n, evaluate=evaluate), S.NegativeOne ** (2 * k / n), evaluate=evaluate)
    return Pow(arg, 1 / n, evaluate=evaluate)

def real_root(arg, n=None, evaluate=None):
    from sympy.functions.elementary.complexes import Abs, im, sign
    from sympy.functions.elementary.piecewise import Piecewise
    if n is not None:
        return Piecewise((root(arg, n, evaluate=evaluate), Or(Eq(n, S.One), Eq(n, S.NegativeOne))), (Mul(sign(arg), root(Abs(arg), n, evaluate=evaluate), evaluate=evaluate), And(Eq(im(arg), S.Zero), Eq(Mod(n, 2), S.One))), (root(arg, n, evaluate=evaluate), True))
    rv = sympify(arg)
    n1pow = Transform(lambda x: -(-x.base) ** x.exp, lambda x: x.is_Pow and x.base.is_negative and x.exp.is_Rational and (x.exp.p == 1) and x.exp.q % 2)
    return rv.xreplace(n1pow)

class MinMaxBase(Expr, LatticeOp):

    def __new__(cls, *args, **assumptions):
        from sympy.core.parameters import global_parameters
        evaluate = assumptions.pop('evaluate', global_parameters.evaluate)
        args = (sympify(arg) for arg in args)
        if evaluate:
            try:
                args = frozenset(cls._new_args_filter(args))
            except ShortCircuit:
                return cls.zero
            args = cls._collapse_arguments(args, **assumptions)
            args = cls._find_localzeros(args, **assumptions)
        args = frozenset(args)
        if not args:
            return cls.identity
        if len(args) == 1:
            return list(args).pop()
        obj = Expr.__new__(cls, *ordered(args), **assumptions)
        obj._argset = args
        return obj

    @classmethod
    def _collapse_arguments(cls, args, **assumptions):
        if not args:
            return args
        args = list(ordered(args))
        if cls == Min:
            other = Max
        else:
            other = Min
        if args[0].is_number:
            sifted = mins, maxs = ([], [])
            for i in args:
                for v in walk(i, Min, Max):
                    if v.args[0].is_comparable:
                        sifted[isinstance(v, Max)].append(v)
            small = Min.identity
            for i in mins:
                v = i.args[0]
                if v.is_number and (v < small) == True:
                    small = v
            big = Max.identity
            for i in maxs:
                v = i.args[0]
                if v.is_number and (v > big) == True:
                    big = v
            if cls == Min:
                for arg in args:
                    if not arg.is_number:
                        break
                    if (arg < small) == True:
                        small = arg
            elif cls == Max:
                for arg in args:
                    if not arg.is_number:
                        break
                    if (arg > big) == True:
                        big = arg
            T = None
            if cls == Min:
                if small != Min.identity:
                    other = Max
                    T = small
            elif big != Max.identity:
                other = Min
                T = big
            if T is not None:
                for i in range(len(args)):
                    a = args[i]
                    if isinstance(a, other):
                        a0 = a.args[0]
                        if (a0 > T if other == Max else a0 < T) == True:
                            args[i] = cls.identity

        def do(ai, a):
            if not isinstance(ai, (Min, Max)):
                return ai
            cond = a in ai.args
            if not cond:
                return ai.func(*[do(i, a) for i in ai.args], evaluate=False)
            if isinstance(ai, cls):
                return ai.func(*[do(i, a) for i in ai.args if i != a], evaluate=False)
            return a
        for i, a in enumerate(args):
            args[i + 1:] = [do(ai, a) for ai in args[i + 1:]]

        def factor_minmax(args):
            is_other = lambda arg: isinstance(arg, other)
            other_args, remaining_args = sift(args, is_other, binary=True)
            if not other_args:
                return args
            arg_sets = [set(arg.args) for arg in other_args]
            common = set.intersection(*arg_sets)
            if not common:
                return args
            new_other_args = list(common)
            arg_sets_diff = [arg_set - common for arg_set in arg_sets]
            if all(arg_sets_diff):
                other_args_diff = [other(*s, evaluate=False) for s in arg_sets_diff]
                new_other_args.append(cls(*other_args_diff, evaluate=False))
            other_args_factored = other(*new_other_args, evaluate=False)
            return remaining_args + [other_args_factored]
        if len(args) > 1:
            args = factor_minmax(args)
        return args

    @classmethod
    def _new_args_filter(cls, arg_sequence):
        for arg in arg_sequence:
            if not isinstance(arg, Expr) or arg.is_extended_real is False or (arg.is_number and (not arg.is_comparable)):
                raise ValueError("The argument '%s' is not comparable." % arg)
            if arg == cls.zero:
                raise ShortCircuit(arg)
            elif arg == cls.identity:
                continue
            elif arg.func == cls:
                yield from arg.args
            else:
                yield arg

    @classmethod
    def _find_localzeros(cls, values, **options):
        localzeros = set()
        for v in values:
            is_newzero = True
            localzeros_ = list(localzeros)
            for z in localzeros_:
                if id(v) == id(z):
                    is_newzero = False
                else:
                    con = cls._is_connected(v, z)
                    if con:
                        is_newzero = False
                        if con is True or con == cls:
                            localzeros.remove(z)
                            localzeros.update([v])
            if is_newzero:
                localzeros.update([v])
        return localzeros

    @classmethod
    def _is_connected(cls, x, y):
        for i in range(2):
            if x == y:
                return True
            t, f = (Max, Min)
            for op in '><':
                for j in range(2):
                    try:
                        if op == '>':
                            v = x >= y
                        else:
                            v = x <= y
                    except TypeError:
                        return False
                    if not v.is_Relational:
                        return t if v else f
                    t, f = (f, t)
                    x, y = (y, x)
                x, y = (y, x)
            x = factor_terms(x - y)
            y = S.Zero
        return False

    def _eval_derivative(self, s):
        i = 0
        l = []
        for a in self.args:
            i += 1
            da = a.diff(s)
            if da.is_zero:
                continue
            try:
                df = self.fdiff(i)
            except ArgumentIndexError:
                df = super().fdiff(i)
            l.append(df * da)
        return Add(*l)

    def _eval_rewrite_as_Abs(self, *args, **kwargs):
        from sympy.functions.elementary.complexes import Abs
        s = (args[0] + self.func(*args[1:])) / 2
        d = abs(args[0] - self.func(*args[1:])) / 2
        return (s + d if isinstance(self, Max) else s - d).rewrite(Abs)

    def evalf(self, n=15, **options):
        return self.func(*[a.evalf(n, **options) for a in self.args])

    def n(self, *args, **kwargs):
        return self.evalf(*args, **kwargs)
    _eval_is_algebraic = lambda s: _torf((i.is_algebraic for i in s.args))
    _eval_is_antihermitian = lambda s: _torf((i.is_antihermitian for i in s.args))
    _eval_is_commutative = lambda s: _torf((i.is_commutative for i in s.args))
    _eval_is_complex = lambda s: _torf((i.is_complex for i in s.args))
    _eval_is_composite = lambda s: _torf((i.is_composite for i in s.args))
    _eval_is_even = lambda s: _torf((i.is_even for i in s.args))
    _eval_is_finite = lambda s: _torf((i.is_finite for i in s.args))
    _eval_is_hermitian = lambda s: _torf((i.is_hermitian for i in s.args))
    _eval_is_imaginary = lambda s: _torf((i.is_imaginary for i in s.args))
    _eval_is_infinite = lambda s: _torf((i.is_infinite for i in s.args))
    _eval_is_integer = lambda s: _torf((i.is_integer for i in s.args))
    _eval_is_irrational = lambda s: _torf((i.is_irrational for i in s.args))
    _eval_is_negative = lambda s: _torf((i.is_negative for i in s.args))
    _eval_is_noninteger = lambda s: _torf((i.is_noninteger for i in s.args))
    _eval_is_nonnegative = lambda s: _torf((i.is_nonnegative for i in s.args))
    _eval_is_nonpositive = lambda s: _torf((i.is_nonpositive for i in s.args))
    _eval_is_nonzero = lambda s: _torf((i.is_nonzero for i in s.args))
    _eval_is_odd = lambda s: _torf((i.is_odd for i in s.args))
    _eval_is_polar = lambda s: _torf((i.is_polar for i in s.args))
    _eval_is_positive = lambda s: _torf((i.is_positive for i in s.args))
    _eval_is_prime = lambda s: _torf((i.is_prime for i in s.args))
    _eval_is_rational = lambda s: _torf((i.is_rational for i in s.args))
    _eval_is_real = lambda s: _torf((i.is_real for i in s.args))
    _eval_is_extended_real = lambda s: _torf((i.is_extended_real for i in s.args))
    _eval_is_transcendental = lambda s: _torf((i.is_transcendental for i in s.args))
    _eval_is_zero = lambda s: _torf((i.is_zero for i in s.args))

class Max(MinMaxBase, Application):
    zero = S.Infinity
    identity = S.NegativeInfinity

    def fdiff(self, argindex):
        from sympy.functions.special.delta_functions import Heaviside
        n = len(self.args)
        if 0 < argindex and argindex <= n:
            argindex -= 1
            if n == 2:
                return Heaviside(self.args[argindex] - self.args[1 - argindex])
            newargs = tuple([self.args[i] for i in range(n) if i != argindex])
            return Heaviside(self.args[argindex] - Max(*newargs))
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Heaviside(self, *args, **kwargs):
        from sympy.functions.special.delta_functions import Heaviside
        return Add(*[j * Mul(*[Heaviside(j - i) for i in args if i != j]) for j in args])

    def _eval_rewrite_as_Piecewise(self, *args, **kwargs):
        return _minmax_as_Piecewise('>=', *args)

    def _eval_is_positive(self):
        return fuzzy_or((a.is_positive for a in self.args))

    def _eval_is_nonnegative(self):
        return fuzzy_or((a.is_nonnegative for a in self.args))

    def _eval_is_negative(self):
        return fuzzy_and((a.is_negative for a in self.args))

class Min(MinMaxBase, Application):
    zero = S.NegativeInfinity
    identity = S.Infinity

    def fdiff(self, argindex):
        from sympy.functions.special.delta_functions import Heaviside
        n = len(self.args)
        if 0 < argindex and argindex <= n:
            argindex -= 1
            if n == 2:
                return Heaviside(self.args[1 - argindex] - self.args[argindex])
            newargs = tuple([self.args[i] for i in range(n) if i != argindex])
            return Heaviside(Min(*newargs) - self.args[argindex])
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Heaviside(self, *args, **kwargs):
        from sympy.functions.special.delta_functions import Heaviside
        return Add(*[j * Mul(*[Heaviside(i - j) for i in args if i != j]) for j in args])

    def _eval_rewrite_as_Piecewise(self, *args, **kwargs):
        return _minmax_as_Piecewise('<=', *args)

    def _eval_is_positive(self):
        return fuzzy_and((a.is_positive for a in self.args))

    def _eval_is_nonnegative(self):
        return fuzzy_and((a.is_nonnegative for a in self.args))

    def _eval_is_negative(self):
        return fuzzy_or((a.is_negative for a in self.args))

class Rem(DefinedFunction):
    kind = NumberKind

    @classmethod
    def eval(cls, p, q):
        if q.is_zero:
            raise ZeroDivisionError('Division by zero')
        if p is S.NaN or q is S.NaN or p.is_finite is False or (q.is_finite is False):
            return S.NaN
        if p is S.Zero or p in (q, -q) or (p.is_integer and q == 1):
            return S.Zero
        if q.is_Number:
            if p.is_Number:
                return p - Integer(p / q) * q