from __future__ import annotations
from math import prod
from collections import defaultdict
from typing import Callable
from sympy.core import S, Symbol, Add, Dummy
from sympy.core.cache import cacheit
from sympy.core.containers import Dict
from sympy.core.expr import Expr
from sympy.core.function import ArgumentIndexError, DefinedFunction, expand_mul
from sympy.core.logic import fuzzy_not
from sympy.core.mul import Mul
from sympy.core.numbers import E, I, pi, oo, Rational, Integer
from sympy.core.relational import Eq, is_le, is_gt, is_lt
from sympy.external.gmpy import SYMPY_INTS, remove, lcm, legendre, jacobi, kronecker, fibonacci as _ifib
from sympy.external.mpmath import local_workprec, eulernum, bernfrac
from sympy.functions.combinatorial.factorials import binomial, factorial, subfactorial
from sympy.functions.elementary.exponential import log
from sympy.functions.elementary.piecewise import Piecewise
from sympy.ntheory.factor_ import factorint, _divisor_sigma, is_carmichael, find_carmichael_numbers_in_range, find_first_n_carmichaels
from sympy.ntheory.generate import _primepi
from sympy.ntheory.partitions_ import _partition, _partition_rec
from sympy.ntheory.primetest import isprime, is_square
from sympy.polys.appellseqs import bernoulli_poly, euler_poly, genocchi_poly
from sympy.polys.polytools import cancel
from sympy.utilities.enumerative import MultisetPartitionTraverser
from sympy.utilities.exceptions import sympy_deprecation_warning
from sympy.utilities.iterables import multiset, multiset_derangements, iterable
from sympy.utilities.memoization import recurrence_memo
from sympy.utilities.misc import as_int

def _product(a, b):
    return prod(range(a, b + 1))
_sym = Symbol('x')

class carmichael(DefinedFunction):

    @staticmethod
    def is_perfect_square(n):
        sympy_deprecation_warning('\nis_perfect_square is just a wrapper around sympy.ntheory.primetest.is_square\nso use that directly instead.\n        ', deprecated_since_version='1.11', active_deprecations_target='deprecated-carmichael-static-methods')
        return is_square(n)

    @staticmethod
    def divides(p, n):
        sympy_deprecation_warning('\n        divides can be replaced by directly testing n % p == 0.\n        ', deprecated_since_version='1.11', active_deprecations_target='deprecated-carmichael-static-methods')
        return n % p == 0

    @staticmethod
    def is_prime(n):
        sympy_deprecation_warning('\nis_prime is just a wrapper around sympy.ntheory.primetest.isprime so use that\ndirectly instead.\n        ', deprecated_since_version='1.11', active_deprecations_target='deprecated-carmichael-static-methods')
        return isprime(n)

    @staticmethod
    def is_carmichael(n):
        sympy_deprecation_warning('\nis_carmichael is just a wrapper around sympy.ntheory.factor_.is_carmichael so use that\ndirectly instead.\n        ', deprecated_since_version='1.13', active_deprecations_target='deprecated-ntheory-symbolic-functions')
        return is_carmichael(n)

    @staticmethod
    def find_carmichael_numbers_in_range(x, y):
        sympy_deprecation_warning('\nfind_carmichael_numbers_in_range is just a wrapper around sympy.ntheory.factor_.find_carmichael_numbers_in_range so use that\ndirectly instead.\n        ', deprecated_since_version='1.13', active_deprecations_target='deprecated-ntheory-symbolic-functions')
        return find_carmichael_numbers_in_range(x, y)

    @staticmethod
    def find_first_n_carmichaels(n):
        sympy_deprecation_warning('\nfind_first_n_carmichaels is just a wrapper around sympy.ntheory.factor_.find_first_n_carmichaels so use that\ndirectly instead.\n        ', deprecated_since_version='1.13', active_deprecations_target='deprecated-ntheory-symbolic-functions')
        return find_first_n_carmichaels(n)

class fibonacci(DefinedFunction):

    @staticmethod
    def _fib(n):
        return _ifib(n)

    @staticmethod
    @recurrence_memo([None, S.One, _sym])
    def _fibpoly(n, prev):
        return (prev[-2] + _sym * prev[-1]).expand()

    @classmethod
    def eval(cls, n, sym=None):
        if n is S.Infinity:
            return S.Infinity
        if n.is_Integer:
            if sym is None:
                n = int(n)
                if n < 0:
                    return S.NegativeOne ** (n + 1) * fibonacci(-n)
                else:
                    return Integer(cls._fib(n))
            else:
                if n < 1:
                    raise ValueError('Fibonacci polynomials are defined only for positive integer indices.')
                return cls._fibpoly(n).subs(_sym, sym)

    def _eval_rewrite_as_tractable(self, n, **kwargs):
        from sympy.functions import sqrt, cos
        return (S.GoldenRatio ** n - cos(S.Pi * n) / S.GoldenRatio ** n) / sqrt(5)

    def _eval_rewrite_as_sqrt(self, n, **kwargs):
        from sympy.functions.elementary.miscellaneous import sqrt
        return 2 ** (-n) * sqrt(5) * ((1 + sqrt(5)) ** n - (-sqrt(5) + 1) ** n) / 5

    def _eval_rewrite_as_GoldenRatio(self, n, **kwargs):
        return (S.GoldenRatio ** n - 1 / (-S.GoldenRatio) ** n) / (2 * S.GoldenRatio - 1)

class lucas(DefinedFunction):

    @classmethod
    def eval(cls, n):
        if n is S.Infinity:
            return S.Infinity
        if n.is_Integer:
            return fibonacci(n + 1) + fibonacci(n - 1)

    def _eval_rewrite_as_sqrt(self, n, **kwargs):
        from sympy.functions.elementary.miscellaneous import sqrt
        return 2 ** (-n) * ((1 + sqrt(5)) ** n + (-sqrt(5) + 1) ** n)

class tribonacci(DefinedFunction):

    @staticmethod
    @recurrence_memo([S.Zero, S.One, S.One])
    def _trib(n, prev):
        return prev[-3] + prev[-2] + prev[-1]

    @staticmethod
    @recurrence_memo([S.Zero, S.One, _sym ** 2])
    def _tribpoly(n, prev):
        return (prev[-3] + _sym * prev[-2] + _sym ** 2 * prev[-1]).expand()

    @classmethod
    def eval(cls, n, sym=None):
        if n is S.Infinity:
            return S.Infinity
        if n.is_Integer:
            n = int(n)
            if n < 0:
                raise ValueError('Tribonacci polynomials are defined only for non-negative integer indices.')
            if sym is None:
                return Integer(cls._trib(n))
            else:
                return cls._tribpoly(n).subs(_sym, sym)

    def _eval_rewrite_as_sqrt(self, n, **kwargs):
        from sympy.functions.elementary.miscellaneous import cbrt, sqrt
        w = (-1 + S.ImaginaryUnit * sqrt(3)) / 2
        a = (1 + cbrt(19 + 3 * sqrt(33)) + cbrt(19 - 3 * sqrt(33))) / 3
        b = (1 + w * cbrt(19 + 3 * sqrt(33)) + w ** 2 * cbrt(19 - 3 * sqrt(33))) / 3
        c = (1 + w ** 2 * cbrt(19 + 3 * sqrt(33)) + w * cbrt(19 - 3 * sqrt(33))) / 3
        Tn = a ** (n + 1) / ((a - b) * (a - c)) + b ** (n + 1) / ((b - a) * (b - c)) + c ** (n + 1) / ((c - a) * (c - b))
        return Tn

    def _eval_rewrite_as_TribonacciConstant(self, n, **kwargs):
        from sympy.functions.elementary.integers import floor
        from sympy.functions.elementary.miscellaneous import cbrt, sqrt
        b = cbrt(586 + 102 * sqrt(33))
        Tn = 3 * b * S.TribonacciConstant ** n / (b ** 2 - 2 * b + 4)
        return floor(Tn + S.Half)

class bernoulli(DefinedFunction):
    args: tuple[Integer]

    @staticmethod
    def _calc_bernoulli(n):
        s = 0
        a = int(binomial(n + 3, n - 6))
        for j in range(1, n // 6 + 1):
            s += a * bernoulli(n - 6 * j)
            a *= _product(n - 6 - 6 * j + 1, n - 6 * j)
            a //= _product(6 * j + 4, 6 * j + 9)
        if n % 6 == 4:
            s = -Rational(n + 3, 6) - s
        else:
            s = Rational(n + 3, 3) - s
        return s / binomial(n + 3, n)
    _cache = {0: S.One, 1: Rational(1, 2), 2: Rational(1, 6), 4: Rational(-1, 30)}
    _highest = {0: 0, 1: 1, 2: 2, 4: 4}

    @classmethod
    def eval(cls, n, x=None):
        if x is S.One:
            return cls(n)
        elif n.is_zero:
            return S.One
        elif n.is_integer is False or n.is_nonnegative is False:
            if x is not None and x.is_Integer and x.is_nonpositive:
                return S.NaN
            return
        elif x is None:
            if n is S.One:
                return S.Half
            elif n.is_odd and (n - 1).is_positive:
                return S.Zero
            elif n.is_Number:
                n = int(n)
                if n > 500:
                    p, q = bernfrac(n)
                    return Rational(int(p), int(q))
                case = n % 6
                highest_cached = cls._highest[case]
                if n <= highest_cached:
                    return cls._cache[n]
                for i in range(highest_cached + 6, n + 6, 6):
                    b = cls._calc_bernoulli(i)
                    cls._cache[i] = b
                    cls._highest[case] = i
                return b
        elif n.is_Number:
            return bernoulli_poly(n, x)

    def _eval_rewrite_as_zeta(self, n, x=1, **kwargs):
        from sympy.functions.special.zeta_functions import zeta
        return Piecewise((1, Eq(n, 0)), (-n * zeta(1 - n, x), True))

    def _eval_evalf(self, prec):
        if not all((x.is_number for x in self.args)):
            return
        n = self.args[0]._to_mpmath(prec)
        x = (self.args[1] if len(self.args) > 1 else S.One)._to_mpmath(prec)
        with local_workprec(prec) as mp:
            if n == 0:
                res = mp.mpf(1)
            elif n == 1:
                res = mp.fsub(x, mp.mpf(0.5))
            elif mp.isint(n) and n >= 0:
                res = mp.bernoulli(n) if x == 1 else mp.bernpoly(n, x)
            else:
                res = mp.fmul(mp.fneg(n), mp.zeta(mp.fsub(1, n), x))
        return Expr._from_mpmath(res, prec)

class bell(DefinedFunction):

    @staticmethod
    @recurrence_memo([1, 1])
    def _bell(n, prev):
        s = 1
        a = 1
        for k in range(1, n):
            a = a * (n - k) // k
            s += a * prev[k]
        return s

    @staticmethod
    @recurrence_memo([S.One, _sym])
    def _bell_poly(n, prev):
        s = 1
        a = 1
        for k in range(2, n + 1):
            a = a * (n - k + 1) // (k - 1)
            s += a * prev[k - 1]
        return expand_mul(_sym * s)

    @staticmethod
    def _bell_incomplete_poly(n, k, symbols):
        if n == 0 and k == 0:
            return S.One
        elif n == 0 or k == 0:
            return S.Zero
        s = S.Zero
        a = S.One
        for m in range(1, n - k + 2):
            s += a * bell._bell_incomplete_poly(n - m, k - 1, symbols) * symbols[m - 1]
            a = a * (n - m) / m
        return expand_mul(s)

    @classmethod
    def eval(cls, n, k_sym=None, symbols=None):
        if n is S.Infinity:
            if k_sym is None:
                return S.Infinity
            else:
                raise ValueError('Bell polynomial is not defined')
        if n.is_negative or n.is_integer is False:
            raise ValueError('a non-negative integer expected')
        if n.is_Integer and n.is_nonnegative:
            if k_sym is None:
                return Integer(cls._bell(int(n)))
            elif symbols is None:
                return cls._bell_poly(int(n)).subs(_sym, k_sym)
            else:
                r = cls._bell_incomplete_poly(int(n), int(k_sym), symbols)
                return r

    def _eval_rewrite_as_Sum(self, n, k_sym=None, symbols=None, **kwargs):
        from sympy.concrete.summations import Sum
        if k_sym is not None or symbols is not None:
            return self
        if not n.is_nonnegative:
            return self
        k = Dummy('k', integer=True, nonnegative=True)
        return 1 / E * Sum(k ** n / factorial(k), (k, 0, S.Infinity))

class harmonic(DefinedFunction):
    harmonic_cache: dict[Integer, Callable[[int], Rational]] = {}

    @classmethod
    def eval(cls, n, m=None):
        from sympy.functions.special.zeta_functions import zeta
        if m is S.One:
            return cls(n)
        if m is None:
            m = S.One
        if n.is_zero:
            return S.Zero
        elif m.is_zero:
            return n
        elif n is S.Infinity:
            if m.is_negative:
                return S.NaN
            elif is_le(m, S.One):
                return S.Infinity
            elif is_gt(m, S.One):
                return zeta(m)
        elif m.is_Integer and m.is_nonpositive:
            return (bernoulli(1 - m, n + 1) - bernoulli(1 - m)) / (1 - m)
        elif n.is_Integer:
            if n.is_negative and (m.is_integer is False or m.is_nonpositive is False):
                return S.ComplexInfinity if m is S.One else S.NaN
            if n.is_nonnegative:
                if m.is_Integer:
                    if m not in cls.harmonic_cache:

                        @recurrence_memo([0])
                        def f(n, prev):
                            return prev[-1] + S.One / n ** m
                        cls.harmonic_cache[m] = f
                    return cls.harmonic_cache[m](int(n))
                return Add(*(k ** (-m) for k in range(1, int(n) + 1)))

    def _eval_rewrite_as_polygamma(self, n, m=S.One, **kwargs):
        from sympy.functions.special.gamma_functions import gamma, polygamma
        if m.is_integer and m.is_positive:
            return Piecewise((polygamma(0, n + 1) + S.EulerGamma, Eq(m, 1)), (S.NegativeOne ** m * (polygamma(m - 1, 1) - polygamma(m - 1, n + 1)) / gamma(m), True))

    def _eval_rewrite_as_digamma(self, n, m=1, **kwargs):
        from sympy.functions.special.gamma_functions import polygamma
        return self.rewrite(polygamma)

    def _eval_rewrite_as_trigamma(self, n, m=1, **kwargs):
        from sympy.functions.special.gamma_functions import polygamma
        return self.rewrite(polygamma)

    def _eval_rewrite_as_Sum(self, n, m=None, **kwargs):
        from sympy.concrete.summations import Sum
        k = Dummy('k', integer=True)
        if m is None:
            m = S.One
        return Sum(k ** (-m), (k, 1, n))

    def _eval_rewrite_as_zeta(self, n, m=S.One, **kwargs):
        from sympy.functions.special.zeta_functions import zeta
        from sympy.functions.special.gamma_functions import digamma
        return Piecewise((digamma(n + 1) + S.EulerGamma, Eq(m, 1)), (zeta(m) - zeta(m, n + 1), True))

    def _eval_expand_func(self, **hints):
        from sympy.concrete.summations import Sum
        n = self.args[0]
        m = self.args[1] if len(self.args) == 2 else 1
        if m == S.One:
            if n.is_Add:
                off = n.args[0]
                nnew = n - off
                if off.is_Integer and off.is_positive:
                    result = [S.One / (nnew + i) for i in range(off, 0, -1)] + [harmonic(nnew)]
                    return Add(*result)
                elif off.is_Integer and off.is_negative:
                    result = [-S.One / (nnew + i) for i in range(0, off, -1)] + [harmonic(nnew)]
                    return Add(*result)
            if n.is_Rational:
                p, q = n.as_numer_denom()
                u = p // q
                p = p - u * q
                if u.is_nonnegative and p.is_positive and q.is_positive and (p < q):
                    from sympy.functions.elementary.exponential import log
                    from sympy.functions.elementary.integers import floor
                    from sympy.functions.elementary.trigonometric import sin, cos, cot
                    k = Dummy('k')
                    t1 = q * Sum(1 / (q * k + p), (k, 0, u))
                    t2 = 2 * Sum(cos(2 * pi * p * k / S(q)) * log(sin(pi * k / S(q))), (k, 1, floor((q - 1) / S(2))))
                    t3 = pi / 2 * cot(pi * p / q) + log(2 * q)
                    return t1 + t2 - t3
        return self

    def _eval_rewrite_as_tractable(self, n, m=1, limitvar=None, **kwargs):
        from sympy.functions.special.zeta_functions import zeta
        from sympy.functions.special.gamma_functions import polygamma
        pg = self.rewrite(polygamma)
        if not isinstance(pg, harmonic):
            return pg.rewrite('tractable', deep=True)
        arg = m - S.One
        if arg.is_nonzero:
            return (zeta(m) - zeta(m, n + 1)).rewrite('tractable', deep=True)

    def _eval_evalf(self, prec):
        if not all((x.is_number for x in self.args)):
            return
        n = self.args[0]._to_mpmath(prec)
        m = (self.args[1] if len(self.args) > 1 else S.One)._to_mpmath(prec)
        with local_workprec(prec) as mp:
            if mp.isint(n) and n < 0:
                return S.NaN
            if m == 1:
                res = mp.harmonic(n)
            else:
                res = mp.fsub(mp.zeta(m), mp.zeta(m, mp.fadd(n, 1)))
        return Expr._from_mpmath(res, prec)

    def fdiff(self, argindex=1):
        from sympy.functions.special.zeta_functions import zeta
        if len(self.args) == 2:
            n, m = self.args
        else:
            n, m = self.args + (1,)
        if argindex == 1:
            return m * zeta(m + 1, n + 1)
        else:
            raise ArgumentIndexError

class euler(DefinedFunction):

    @classmethod
    def eval(cls, n, x=None):
        if n.is_zero:
            return S.One
        elif n is S.NegativeOne:
            if x is None:
                return S.Pi / 2
            from sympy.functions.special.gamma_functions import digamma
            return digamma((x + 1) / 2) - digamma(x / 2)
        elif n.is_integer is False or n.is_nonnegative is False:
            return
        elif x is None:
            if n.is_odd and n.is_positive:
                return S.Zero
            elif n.is_Number:
                n = n._to_mpmath(53)
                res = eulernum(n, exact=True)
                return Integer(res)
        elif n.is_Number:
            from sympy.core.evalf import pure_complex
            n = int(n)
            reim = pure_complex(x, or_real=True)
            if reim and all((a.is_Float or a.is_Integer for a in reim)) and any((a.is_Float for a in reim)):
                prec = min([a._prec for a in reim if a.is_Float])
                with local_workprec(prec) as mp:
                    res = mp.eulerpoly(n, x)
                return Expr._from_mpmath(res, prec)
            return euler_poly(n, x)

    def _eval_rewrite_as_Sum(self, n, x=None, **kwargs):
        from sympy.concrete.summations import Sum
        if x is None and n.is_even:
            k = Dummy('k', integer=True)
            j = Dummy('j', integer=True)
            n = n / 2
            Em = S.ImaginaryUnit * Sum(Sum(binomial(k, j) * (S.NegativeOne ** j * (k - 2 * j) ** (2 * n + 1)) / (2 ** k * S.ImaginaryUnit ** k * k), (j, 0, k)), (k, 1, 2 * n + 1))
            return Em
        if x:
            k = Dummy('k', integer=True)
            return Sum(binomial(n, k) * euler(k) / 2 ** k * (x - S.Half) ** (n - k), (k, 0, n))

    def _eval_rewrite_as_genocchi(self, n, x=None, **kwargs):
        if x is None:
            return Piecewise((S.Pi / 2, Eq(n, -1)), (-2 ** n * genocchi(n + 1, S.Half) / (n + 1), True))
        from sympy.functions.special.gamma_functions import digamma
        return Piecewise((digamma((x + 1) / 2) - digamma(x / 2), Eq(n, -1)), (-genocchi(n + 1, x) / (n + 1), True))

    def _eval_evalf(self, prec):
        if not all((i.is_number for i in self.args)):
            return
        m, x = (self.args[0], None) if len(self.args) == 1 else self.args
        m = m._to_mpmath(prec)
        if x is not None:
            x = x._to_mpmath(prec)
        with local_workprec(prec) as mp:
            if mp.isint(m) and m >= 0:
                res = mp.eulernum(m) if x is None else mp.eulerpoly(m, x)
            else:
                if m == -1:
                    if x is None:
                        res = mp.pi
                    else:
                        res = mp.fsub(mp.digamma(mp.fdiv(mp.fadd(x, 1), 2)), mp.digamma(mp.fdiv(x, 2)))
                else:
                    y = 0.5 if x is None else x
                    res = mp.fmul(2, mp.fsub(mp.zeta(mp.fneg(m), y), mp.fmul(mp.power(2, mp.fadd(m, 1)), mp.zeta(mp.fneg(m), mp.fdiv(mp.fadd(y, 1), 2)))))
                if x is None:
                    res = mp.fmul(res, mp.power(2, m))
        return Expr._from_mpmath(res, prec)

class catalan(DefinedFunction):

    @classmethod
    def eval(cls, n):
        from sympy.functions.special.gamma_functions import gamma
        if n.is_Integer and n.is_nonnegative or (n.is_noninteger and n.is_negative):
            return 4 ** n * gamma(n + S.Half) / (gamma(S.Half) * gamma(n + 2))
        if n.is_integer and n.is_negative:
            if (n + 1).is_negative:
                return S.Zero
            if (n + 1).is_zero:
                return Rational(-1, 2)

    def fdiff(self, argindex=1):
        from sympy.functions.elementary.exponential import log
        from sympy.functions.special.gamma_functions import polygamma
        n = self.args[0]
        return catalan(n) * (polygamma(0, n + S.Half) - polygamma(0, n + 2) + log(4))

    def _eval_rewrite_as_binomial(self, n, **kwargs):
        return binomial(2 * n, n) / (n + 1)

    def _eval_rewrite_as_factorial(self, n, **kwargs):
        return factorial(2 * n) / (factorial(n + 1) * factorial(n))

    def _eval_rewrite_as_gamma(self, n, piecewise=True, **kwargs):
        from sympy.functions.special.gamma_functions import gamma
        return 4 ** n * gamma(n + S.Half) / (gamma(S.Half) * gamma(n + 2))

    def _eval_rewrite_as_hyper(self, n, **kwargs):
        from sympy.functions.special.hyper import hyper
        return hyper([1 - n, -n], [2], 1)

    def _eval_rewrite_as_Product(self, n, **kwargs):
        from sympy.concrete.products import Product
        if not (n.is_integer and n.is_nonnegative):
            return self
        k = Dummy('k', integer=True, positive=True)
        return Product((n + k) / k, (k, 2, n))

    def _eval_is_integer(self):
        if self.args[0].is_integer and self.args[0].is_nonnegative:
            return True

    def _eval_is_positive(self):
        if self.args[0].is_nonnegative:
            return True

    def _eval_is_composite(self):
        if self.args[0].is_integer and (self.args[0] - 3).is_positive:
            return True

    def _eval_evalf(self, prec):
        from sympy.functions.special.gamma_functions import gamma
        if self.args[0].is_number:
            return self.rewrite(gamma)._eval_evalf(prec)

class genocchi(DefinedFunction):

    @classmethod
    def eval(cls, n, x=None):
        if x is S.One:
            return cls(n)
        elif n.is_integer is False or n.is_nonnegative is False:
            return
        elif x is None:
            if n.is_odd and (n - 1).is_positive:
                return S.Zero
            elif n.is_Number:
                return 2 * (1 - S(2) ** n) * bernoulli(n)
        elif n.is_Number:
            return genocchi_poly(n, x)

    def _eval_rewrite_as_bernoulli(self, n, x=1, **kwargs):
        if x == 1 and n.is_integer and n.is_nonnegative:
            return 2 * (1 - S(2) ** n) * bernoulli(n)
        return 2 * (bernoulli(n, x) - 2 ** n * bernoulli(n, (x + 1) / 2))

    def _eval_rewrite_as_dirichlet_eta(self, n, x=1, **kwargs):
        from sympy.functions.special.zeta_functions import dirichlet_eta
        return -2 * n * dirichlet_eta(1 - n, x)

    def _eval_is_integer(self):
        if len(self.args) > 1 and self.args[1] != 1:
            return
        n = self.args[0]
        if n.is_integer and n.is_nonnegative:
            return True

    def _eval_is_negative(self):
        if len(self.args) > 1 and self.args[1] != 1:
            return
        n = self.args[0]
        if n.is_integer and n.is_nonnegative:
            if n.is_odd:
                return fuzzy_not((n - 1).is_positive)
            return (n / 2).is_odd

    def _eval_is_positive(self):
        if len(self.args) > 1 and self.args[1] != 1:
            return
        n = self.args[0]
        if n.is_integer and n.is_nonnegative:
            if n.is_zero or n.is_odd:
                return False
            return (n / 2).is_even

    def _eval_is_even(self):
        if len(self.args) > 1 and self.args[1] != 1:
            return
        n = self.args[0]
        if n.is_integer and n.is_nonnegative:
            if n.is_even:
                return n.is_zero
            return (n - 1).is_positive

    def _eval_is_odd(self):
        if len(self.args) > 1 and self.args[1] != 1:
            return
        n = self.args[0]
        if n.is_integer and n.is_nonnegative:
            if n.is_even:
                return fuzzy_not(n.is_zero)
            return fuzzy_not((n - 1).is_positive)

    def _eval_is_prime(self):
        if len(self.args) > 1 and self.args[1] != 1:
            return
        n = self.args[0]
        return (n - 8).is_zero

    def _eval_evalf(self, prec):
        if all((i.is_number for i in self.args)):
            return self.rewrite(bernoulli)._eval_evalf(prec)

class andre(DefinedFunction):

    @classmethod
    def eval(cls, n):
        if n is S.NaN:
            return S.NaN
        elif n is S.Infinity:
            return S.Infinity
        if n.is_zero:
            return S.One
        elif n == -1:
            return -log(2)
        elif n == -2:
            return -2 * S.Catalan
        elif n.is_Integer:
            if n.is_nonnegative and n.is_even:
                return abs(euler(n))
            elif n.is_odd:
                from sympy.functions.special.zeta_functions import zeta
                m = -n - 1
                return I ** m * Rational(1 - 2 ** m, 4 ** m) * zeta(-n)

    def _eval_rewrite_as_zeta(self, s, **kwargs):
        from sympy.functions.elementary.trigonometric import cos
        from sympy.functions.special.gamma_functions import gamma
        from sympy.functions.special.zeta_functions import zeta
        return 2 * gamma(s + 1) / (2 * pi) ** (s + 1) * (zeta(s + 1, S.One / 4) - cos(pi * s) * zeta(s + 1, S(3) / 4))

    def _eval_rewrite_as_polylog(self, s, **kwargs):
        from sympy.functions.special.zeta_functions import polylog
        return (-I) ** (s + 1) * polylog(-s, I) + I ** (s + 1) * polylog(-s, -I)

    def _eval_is_integer(self):
        n = self.args[0]
        if n.is_integer and n.is_nonnegative:
            return True

    def _eval_is_positive(self):
        if self.args[0].is_nonnegative:
            return True

    def _eval_evalf(self, prec):
        if not self.args[0].is_number:
            return
        s = self.args[0]._to_mpmath(prec + 12)
        with local_workprec(prec + 12) as mp:
            s2 = mp.fdiv(s, 2)
            sp, cp = (mp.sinpi(s2), mp.cospi(s2))
            res = mp.fmul(2, mp.dirichlet(mp.fneg(s), (mp.fneg(sp), cp, sp, mp.fneg(cp))))
        return Expr._from_mpmath(res, prec)

class partition(DefinedFunction):
    is_integer = True
    is_nonnegative = True

    @classmethod
    def eval(cls, n):
        if n.is_integer is False:
            raise TypeError('n should be an integer')
        if n.is_negative is True:
            return S.Zero
        if n.is_zero is True or n is S.One:
            return S.One
        if n.is_Integer is True:
            return S(_partition(as_int(n)))

    def _eval_is_positive(self):
        if self.args[0].is_nonnegative is True:
            return True

    def _eval_Mod(self, q):
        n = self.args[0]
        for p, rem in [(5, 4), (7, 5), (11, 6)]:
            if q == p and n % q == rem:
                return S.Zero

class divisor_sigma(DefinedFunction):
    is_integer = True
    is_positive = True

    @classmethod
    def eval(cls, n, k=S.One):
        if n.is_integer is False:
            raise TypeError('n should be an integer')
        if n.is_positive is False:
            raise ValueError('n should be a positive integer')
        if k.is_integer is False:
            raise TypeError('k should be an integer')
        if k.is_nonnegative is False:
            raise ValueError('k should be a nonnegative integer')
        if n.is_prime is True:
            return 1 + n ** k
        if n is S.One:
            return S.One
        if n.is_Integer is True:
            if k.is_zero is True:
                return Mul(*[e + 1 for e in factorint(n).values()])
            if k.is_Integer is True:
                return S(_divisor_sigma(as_int(n), as_int(k)))
            if k.is_zero is False:
                return Mul(*[cancel((p ** (k * (e + 1)) - 1) / (p ** k - 1)) for p, e in factorint(n).items()])

class udivisor_sigma(DefinedFunction):
    is_integer = True
    is_positive = True

    @classmethod
    def eval(cls, n, k=S.One):
        if n.is_integer is False:
            raise TypeError('n should be an integer')
        if n.is_positive is False:
            raise ValueError('n should be a positive integer')
        if k.is_integer is False:
            raise TypeError('k should be an integer')
        if k.is_nonnegative is False:
            raise ValueError('k should be a nonnegative integer')
        if n.is_prime is True:
            return 1 + n ** k
        if n.is_Integer:
            return Mul(*[1 + p ** (k * e) for p, e in factorint(n).items()])

class legendre_symbol(DefinedFunction):
    is_integer = True
    is_prime = False

    @classmethod
    def eval(cls, a, p):
        if a.is_integer is False:
            raise TypeError('a should be an integer')
        if p.is_integer is False:
            raise TypeError('p should be an integer')
        if p.is_prime is False or p.is_odd is False:
            raise ValueError('p should be an odd prime integer')
        if (a % p).is_zero is True:
            return S.Zero
        if a is S.One:
            return S.One
        if a.is_Integer is True and p.is_Integer is True:
            return S(legendre(as_int(a), as_int(p)))

class jacobi_symbol(DefinedFunction):
    is_integer = True
    is_prime = False

    @classmethod
    def eval(cls, m, n):
        if m.is_integer is False:
            raise TypeError('m should be an integer')
        if n.is_integer is False:
            raise TypeError('n should be an integer')
        if n.is_positive is False or n.is_odd is False:
            raise ValueError('n should be an odd positive integer')
        if m is S.One or n is S.One:
            return S.One
        if (m % n).is_zero is True:
            return S.Zero
        if m.is_Integer is True and n.is_Integer is True:
            return S(jacobi(as_int(m), as_int(n)))

class kronecker_symbol(DefinedFunction):
    is_integer = True
    is_prime = False

    @classmethod
    def eval(cls, a, n):
        if a.is_integer is False:
            raise TypeError('a should be an integer')
        if n.is_integer is False:
            raise TypeError('n should be an integer')
        if a is S.One or n is S.One:
            return S.One
        if a.is_Integer is True and n.is_Integer is True:
            return S(kronecker(as_int(a), as_int(n)))

class mobius(DefinedFunction):
    is_integer = True
    is_prime = False

    @classmethod
    def eval(cls, n):
        if n.is_integer is False:
            raise TypeError('n should be an integer')
        if n.is_positive is False:
            raise ValueError('n should be a positive integer')
        if n.is_prime is True:
            return S.NegativeOne
        if n is S.One:
            return S.One
        result = None
        for m, e in (_.as_base_exp() for _ in Mul.make_args(n)):
            if m.is_integer is True and m.is_positive is True and (e.is_integer is True) and (e.is_positive is True):
                lt = is_lt(S.One, e)
                if lt is True:
                    result = S.Zero
                elif m.is_Integer is True:
                    factors = factorint(m)
                    if any((v > 1 for v in factors.values())):
                        result = S.Zero
                    elif lt is False:
                        s = S.NegativeOne if len(factors) % 2 else S.One
                        if result is None:
                            result = s
                        else:
                            result *= s
            else:
                return
        return result

class primenu(DefinedFunction):
    is_integer = True
    is_nonnegative = True

    @classmethod
    def eval(cls, n):
        if n.is_integer is False:
            raise TypeError('n should be an integer')
        if n.is_positive is False:
            raise ValueError('n should be a positive integer')
        if n.is_prime is True:
            return S.One
        if n is S.One:
            return S.Zero
        if n.is_Integer is True:
            return S(len(factorint(n)))

class primeomega(DefinedFunction):
    is_integer = True
    is_nonnegative = True

    @classmethod
    def eval(cls, n):
        if n.is_integer is False:
            raise TypeError('n should be an integer')
        if n.is_positive is False:
            raise ValueError('n should be a positive integer')
        if n.is_prime is True:
            return S.One
        if n is S.One:
            return S.Zero
        if n.is_Integer is True:
            return S(sum(factorint(n).values()))

class totient(DefinedFunction):
    is_integer = True
    is_positive = True

    @classmethod
    def eval(cls, n):
        if n.is_integer is False:
            raise TypeError('n should be an integer')
        if n.is_positive is False:
            raise ValueError('n should be a positive integer')
        if n is S.One:
            return S.One
        if n.is_prime is True:
            return n - 1
        if isinstance(n, Dict):
            return S(prod((p ** (k - 1) * (p - 1) for p, k in n.items())))
        if n.is_Integer is True:
            return S(prod((p ** (k - 1) * (p - 1) for p, k in factorint(n).items())))

class reduced_totient(DefinedFunction):
    is_integer = True
    is_positive = True

    @classmethod
    def eval(cls, n):
        if n.is_integer is False:
            raise TypeError('n should be an integer')
        if n.is_positive is False:
            raise ValueError('n should be a positive integer')
        if n is S.One:
            return S.One
        if n.is_prime is True:
            return n - 1
        if isinstance(n, Dict):
            t = 1
            if 2 in n:
                t = 1 << n[2] - 2 if 2 < n[2] else n[2]
            return S(lcm(int(t), *(int(p - 1) * int(p) ** int(k - 1) for p, k in n.items() if p != 2)))
        if n.is_Integer is True:
            n, t = remove(int(n), 2)
            if not t:
                t = 1
            elif 2 < t:
                t = 1 << t - 2
            return S(lcm(t, *((p - 1) * p ** (k - 1) for p, k in factorint(n).items())))

class primepi(DefinedFunction):
    is_integer = True
    is_nonnegative = True

    @classmethod
    def eval(cls, n):
        if n is S.Infinity:
            return S.Infinity
        if n is S.NegativeInfinity:
            return S.Zero
        if n.is_real is False:
            raise TypeError('n should be a real')
        if is_lt(n, S(2)) is True:
            return S.Zero
        try:
            n = int(n)
        except TypeError:
            return
        return S(_primepi(n))

class _MultisetHistogram(tuple):
    __slots__ = ()
_N = -1
_ITEMS = -2
_M = slice(None, _ITEMS)

def _multiset_histogram(n):
    if isinstance(n, dict):
        if not all((isinstance(v, int) and v >= 0 for v in n.values())):
            raise ValueError
        tot = sum(n.values())
        items = sum((1 for k in n if n[k] > 0))
        return _MultisetHistogram([n[k] for k in n if n[k] > 0] + [items, tot])
    else:
        n = list(n)
        s = set(n)
        lens = len(s)
        lenn = len(n)
        if lens == lenn:
            n = [1] * lenn + [lenn, lenn]
            return _MultisetHistogram(n)
        m = dict(zip(s, range(lens)))
        d = dict(zip(range(lens), (0,) * lens))
        for i in n:
            d[m[i]] += 1
        return _multiset_histogram(d)

def nP(n, k=None, replacement=False):
    if k is not None and k < 0:
        raise ValueError('k cannot be negative')
    try:
        n = as_int(n)
    except ValueError:
        return Integer(_nP(_multiset_histogram(n), k, replacement))
    return Integer(_nP(n, k, replacement))

@cacheit
def _nP(n, k=None, replacement=False):
    if k == 0:
        return 1
    if isinstance(n, SYMPY_INTS):
        if k is None:
            return sum((_nP(n, i, replacement) for i in range(n + 1)))
        elif replacement:
            return n ** k
        elif k > n:
            return 0
        elif k == n:
            return factorial(k)
        elif k == 1:
            return n
        else:
            return _product(n - k + 1, n)
    elif isinstance(n, _MultisetHistogram):
        if k is None:
            return sum((_nP(n, i, replacement) for i in range(n[_N] + 1)))
        elif replacement:
            return n[_ITEMS] ** k
        elif k == n[_N]:
            return factorial(k) / prod([factorial(i) for i in n[_M] if i > 1])
        elif k > n[_N]:
            return 0
        elif k == 1:
            return n[_ITEMS]
        else:
            tot = 0
            n = list(n)
            for i in range(len(n[_M])):
                if not n[i]:
                    continue
                n[_N] -= 1
                if n[i] == 1:
                    n[i] = 0
                    n[_ITEMS] -= 1
                    tot += _nP(_MultisetHistogram(n), k - 1)
                    n[_ITEMS] += 1
                    n[i] = 1
                else:
                    n[i] -= 1
                    tot += _nP(_MultisetHistogram(n), k - 1)
                    n[i] += 1
                n[_N] += 1
            return tot

@cacheit
def _AOP_product(n):
    n = list(n)
    ord = sum(n)
    need = (ord + 2) // 2
    rv = [1] * (n.pop() + 1)
    rv.extend((0,) * (need - len(rv)))
    rv = rv[:need]
    while n:
        ni = n.pop()
        N = ni + 1
        was = rv[:]
        for i in range(1, min(N, len(rv))):
            rv[i] += rv[i - 1]
        for i in range(N, need):
            rv[i] += rv[i - 1] - was[i - N]
    rev = list(reversed(rv))
    if ord % 2:
        rv = rv + rev
    else:
        rv[-1:] = rev
    d = defaultdict(int)
    for i, r in enumerate(rv):
        d[i] = r
    return d

def nC(n, k=None, replacement=False):
    if isinstance(n, SYMPY_INTS):
        if k is None:
            if not replacement:
                return 2 ** n
            return sum((nC(n, i, replacement) for i in range(n + 1)))
        if k < 0:
            raise ValueError('k cannot be negative')
        if replacement:
            return binomial(n + k - 1, k)
        return binomial(n, k)
    if isinstance(n, _MultisetHistogram):
        N = n[_N]
        if k is None:
            if not replacement:
                return prod((m + 1 for m in n[_M]))
            return sum((nC(n, i, replacement) for i in range(N + 1)))
        elif replacement:
            return nC(n[_ITEMS], k, replacement)
        elif k in (1, N - 1):
            return n[_ITEMS]
        elif k in (0, N):
            return 1
        return _AOP_product(tuple(n[_M]))[k]
    else:
        return nC(_multiset_histogram(n), k, replacement)

def _eval_stirling1(n, k):
    if n == k == 0:
        return S.One
    if 0 in (n, k):
        return S.Zero
    if n == k:
        return S.One
    elif k == n - 1:
        return binomial(n, 2)
    elif k == n - 2:
        return (3 * n - 1) * binomial(n, 3) / 4
    elif k == n - 3:
        return binomial(n, 2) * binomial(n, 4)
    return _stirling1(n, k)

@cacheit
def _stirling1(n, k):
    row = [0, 1] + [0] * (k - 1)
    for i in range(2, n + 1):
        for j in range(min(k, i), 0, -1):
            row[j] = (i - 1) * row[j] + row[j - 1]
    return Integer(row[k])

def _eval_stirling2(n, k):
    if n == k == 0:
        return S.One
    if 0 in (n, k):
        return S.Zero
    if n == k:
        return S.One
    elif k == n - 1:
        return binomial(n, 2)
    elif k == 1:
        return S.One
    elif k == 2:
        return Integer(2 ** (n - 1) - 1)
    return _stirling2(n, k)

@cacheit
def _stirling2(n, k):
    row = [0, 1] + [0] * (k - 1)
    for i in range(2, n + 1):
        for j in range(min(k, i), 0, -1):
            row[j] = j * row[j] + row[j - 1]
    return Integer(row[k])

def stirling(n, k, d=None, kind=2, signed=False):
    n = as_int(n)
    k = as_int(k)
    if n < 0:
        raise ValueError('n must be nonnegative')
    if k > n:
        return S.Zero
    if d:
        return _eval_stirling2(n - d + 1, k - d + 1)
    elif signed:
        return S.NegativeOne ** (n - k) * _eval_stirling1(n, k)
    if kind == 1:
        return _eval_stirling1(n, k)
    elif kind == 2:
        return _eval_stirling2(n, k)
    else:
        raise ValueError('kind must be 1 or 2, not %s' % k)

@cacheit
def _nT(n, k):
    if k > n or k < 0:
        return 0
    if k in (1, n):
        return 1
    if k == 0:
        return 0
    if k == 2:
        return n // 2
    d = n - k
    if d <= 3:
        return d
    if 3 * k >= n:
        tot = _partition_rec(d)
        if d - k > 0:
            tot -= sum(_partition_rec.fetch_item(slice(d - k)))
        return tot
    p = [1] * d
    for i in range(2, k + 1):
        for m in range(i + 1, d):
            p[m] += p[m - i]
        d -= 1
    return 1 + sum(p[1 - k:])

def nT(n, k=None):
    if isinstance(n, SYMPY_INTS):
        if k is None:
            return partition(n)
        if isinstance(k, SYMPY_INTS):
            n = as_int(n)
            k = as_int(k)
            return Integer(_nT(n, k))
    if not isinstance(n, _MultisetHistogram):
        try:
            u = len(set(n))
            if u <= 1:
                return nT(len(n), k)
            elif u == len(n):
                n = range(u)
            raise TypeError
        except TypeError:
            n = _multiset_histogram(n)
    N = n[_N]
    if k is None and N == 1:
        return 1
    if k in (1, N):
        return 1
    if k == 2 or (N == 2 and k is None):
        m, r = divmod(N, 2)
        rv = sum((nC(n, i) for i in range(1, m + 1)))
        if not r:
            rv -= nC(n, m) // 2
        if k is None:
            rv += 1
        return rv
    if N == n[_ITEMS]:
        if k is None:
            return bell(N)
        return stirling(N, k)
    m = MultisetPartitionTraverser()
    if k is None:
        return m.count_partitions(n[_M])
    tot = 0
    for discard in m.enum_range(n[_M], k - 1, k):
        tot += 1
    return tot

class motzkin(DefinedFunction):

    @staticmethod
    def is_motzkin(n):
        try:
            n = as_int(n)
        except ValueError:
            return False
        if n > 0:
            if n in (1, 2):
                return True
            tn1 = 1
            tn = 2
            i = 3
            while tn < n:
                a = ((2 * i + 1) * tn + (3 * i - 3) * tn1) / (i + 2)
                i += 1
                tn1 = tn
                tn = a
            if tn == n:
                return True
            else:
                return False
        else:
            return False

    @staticmethod
    def find_motzkin_numbers_in_range(x, y):
        if 0 <= x <= y:
            motzkins = []
            if x <= 1 <= y:
                motzkins.append(1)
            tn1 = 1
            tn = 2
            i = 3
            while tn <= y:
                if tn >= x:
                    motzkins.append(tn)
                a = ((2 * i + 1) * tn + (3 * i - 3) * tn1) / (i + 2)
                i += 1
                tn1 = tn
                tn = int(a)
            return motzkins
        else:
            raise ValueError('The provided range is not valid. This condition should satisfy x <= y')

    @staticmethod
    def find_first_n_motzkins(n):
        try:
            n = as_int(n)
        except ValueError:
            raise ValueError('The provided number must be a positive integer')
        if n < 0:
            raise ValueError('The provided number must be a positive integer')
        motzkins = [1]
        if n >= 1:
            motzkins.append(1)
        tn1 = 1
        tn = 2
        i = 3
        while i <= n:
            motzkins.append(tn)
            a = ((2 * i + 1) * tn + (3 * i - 3) * tn1) / (i + 2)
            i += 1
            tn1 = tn
            tn = int(a)
        return motzkins

    @staticmethod
    @recurrence_memo([S.One, S.One])
    def _motzkin(n, prev):
        return ((2 * n + 1) * prev[-1] + (3 * n - 3) * prev[-2]) // (n + 2)

    @classmethod
    def eval(cls, n):
        try:
            n = as_int(n)
        except ValueError:
            raise ValueError('The provided number must be a positive integer')
        if n < 0:
            raise ValueError('The provided number must be a positive integer')
        return Integer(cls._motzkin(n - 1))

def nD(i=None, brute=None, *, n=None, m=None):
    from sympy.integrals.integrals import integrate
    from sympy.functions.special.polynomials import laguerre
    from sympy.abc import x

    def ok(x):
        if not isinstance(x, SYMPY_INTS):
            raise TypeError('expecting integer values')
        if x < 0:
            raise ValueError('value must not be negative')
        return True
    if (i, n, m).count(None) != 2:
        raise ValueError('enter only 1 of i, n, or m')
    if i is not None:
        if isinstance(i, SYMPY_INTS):
            raise TypeError('items must be a list or dictionary')
        if not i:
            return S.Zero
        if type(i) is not dict:
            s = list(i)
            ms = multiset(s)
        elif type(i) is dict:
            all((ok(_) for _ in i.values()))
            ms = {k: v for k, v in i.items() if v}
            s = None
        if not ms:
            return S.Zero
        N = sum(ms.values())
        counts = multiset(ms.values())
        nkey = len(ms)
    elif n is not None:
        ok(n)
        if not n:
            return S.Zero
        return subfactorial(n)
    elif m is not None:
        if isinstance(m, dict):
            all((ok(i) and ok(j) for i, j in m.items()))
            counts = {k: v for k, v in m.items() if k * v}
        elif iterable(m) or isinstance(m, str):
            m = list(m)
            all((ok(i) for i in m))
            counts = multiset([i for i in m if i])
        else:
            raise TypeError('expecting iterable')
        if not counts:
            return S.Zero
        N = sum((k * v for k, v in counts.items()))
        nkey = sum(counts.values())
        s = None
    big = int(max(counts))
    if big == 1:
        return subfactorial(nkey)
    nval = len(counts)
    if big * 2 > N:
        return S.Zero
    if big * 2 == N:
        if nkey == 2 and nval == 1:
            return S.One
        if nkey - 1 == big:
            return factorial(big)
    if N < 9 and brute is None or brute:
        if s is None:
            s = []
            i = 0
            for m, v in counts.items():
                for j in range(v):
                    s.extend([i] * m)
                    i += 1
        return Integer(sum((1 for i in multiset_derangements(s))))
    from sympy.functions.elementary.exponential import exp
    return Integer(abs(integrate(exp(-x) * Mul(*[laguerre(i, x) ** m for i, m in counts.items()]), (x, 0, oo))))