from __future__ import annotations
from sympy.core.add import Add
from sympy.core.cache import cacheit
from sympy.core.function import ArgumentIndexError, expand_mul, DefinedFunction
from sympy.core.logic import fuzzy_not
from sympy.core.numbers import pi, I, Integer
from sympy.core.relational import Eq
from sympy.core.singleton import S
from sympy.core.symbol import Dummy
from sympy.core.sympify import sympify
from sympy.functions.combinatorial.numbers import bernoulli, factorial, genocchi, harmonic
from sympy.functions.elementary.complexes import re, unpolarify, Abs, polar_lift
from sympy.functions.elementary.exponential import log, exp_polar, exp
from sympy.functions.elementary.integers import ceiling, floor
from sympy.functions.elementary.miscellaneous import sqrt
from sympy.functions.elementary.piecewise import Piecewise
from sympy.polys.polytools import Poly

class lerchphi(DefinedFunction):

    def _eval_expand_func(self, **hints):
        z, s, a = self.args
        if z == 1:
            return zeta(s, a)
        if s.is_Integer and s <= 0:
            t = Dummy('t')
            p = Poly((t + a) ** (-s), t)
            start = 1 / (1 - t)
            res = S.Zero
            for c in reversed(p.all_coeffs()):
                res += c * start
                start = t * start.diff(t)
            return res.subs(t, z)
        if a.is_Rational:
            add = S.Zero
            mul = S.One
            if a > 1:
                n = floor(a)
                if n == a:
                    n -= 1
                a -= n
                mul = z ** (-n)
                add = Add(*[-z ** (k - n) / (a + k) ** s for k in range(n)])
            elif a <= 0:
                n = floor(-a) + 1
                a += n
                mul = z ** n
                add = Add(*[z ** (n - 1 - k) / (a - k - 1) ** s for k in range(n)])
            m, n = S([a.p, a.q])
            zet = exp_polar(2 * pi * I / n)
            root = z ** (1 / n)
            up_zet = unpolarify(zet)
            addargs = []
            for k in range(n):
                p = polylog(s, zet ** k * root)
                if isinstance(p, polylog):
                    p = p._eval_expand_func(**hints)
                addargs.append(p / (up_zet ** k * root) ** m)
            return add + mul * n ** (s - 1) * Add(*addargs)
        if isinstance(z, exp) and (z.args[0] / (pi * I)).is_Rational or z in [-1, I, -I]:
            if z == -1:
                p, q = S([1, 2])
            elif z == I:
                p, q = S([1, 4])
            elif z == -I:
                p, q = S([-1, 4])
            else:
                arg = z.args[0] / (2 * pi * I)
                p, q = S([arg.p, arg.q])
            return Add(*[exp(2 * pi * I * k * p / q) / q ** s * zeta(s, (k + a) / q) for k in range(q)])
        return lerchphi(z, s, a)

    def fdiff(self, argindex=1):
        z, s, a = self.args
        if argindex == 3:
            return -s * lerchphi(z, s + 1, a)
        elif argindex == 1:
            return (lerchphi(z, s - 1, a) - a * lerchphi(z, s, a)) / z
        else:
            raise ArgumentIndexError

    def _eval_rewrite_helper(self, target):
        res = self._eval_expand_func()
        if res.has(target):
            return res
        else:
            return self

    def _eval_rewrite_as_zeta(self, z, s, a, **kwargs):
        return self._eval_rewrite_helper(zeta)

    def _eval_rewrite_as_polylog(self, z, s, a, **kwargs):
        return self._eval_rewrite_helper(polylog)

class polylog(DefinedFunction):

    @classmethod
    def eval(cls, s, z):
        if z.is_number:
            if z is S.One:
                return zeta(s)
            elif z is S.NegativeOne:
                return -dirichlet_eta(s)
            elif z is S.Zero:
                return S.Zero
            elif s == 2:
                dilogtable = _dilogtable()
                if z in dilogtable:
                    return dilogtable[z]
        if z.is_zero:
            return S.Zero
        zone = z.equals(S.One)
        if zone:
            return zeta(s)
        elif zone is False:
            if s is S.Zero:
                return z / (1 - z)
            elif s is S.NegativeOne:
                return z / (1 - z) ** 2
            if s.is_zero:
                return z / (1 - z)
        if z.has(exp_polar, polar_lift) and (zone or (Abs(z) <= S.One) == True):
            return cls(s, unpolarify(z))

    def fdiff(self, argindex=1):
        s, z = self.args
        if argindex == 2:
            return polylog(s - 1, z) / z
        raise ArgumentIndexError

    def _eval_rewrite_as_lerchphi(self, s, z, **kwargs):
        return z * lerchphi(z, s, 1)

    def _eval_expand_func(self, **hints):
        s, z = self.args
        if s == 1:
            return -log(1 - z)
        if s.is_Integer and s <= 0:
            u = Dummy('u')
            start = u / (1 - u)
            for _ in range(-s):
                start = u * start.diff(u)
            return expand_mul(start).subs(u, z)
        return polylog(s, z)

    def _eval_is_zero(self):
        z = self.args[1]
        if z.is_zero:
            return True

    def _eval_nseries(self, x, n, logx, cdir=0):
        from sympy.series.order import Order
        nu, z = self.args
        z0 = z.subs(x, 0)
        if z0 is S.NaN:
            z0 = z.limit(x, 0, dir='-' if re(cdir).is_negative else '+')
        if z0.is_zero:
            try:
                _, exp = z.leadterm(x)
            except (ValueError, NotImplementedError):
                return self
            if exp.is_positive:
                newn = ceiling(n / exp)
                o = Order(x ** n, x)
                r = z._eval_nseries(x, n, logx, cdir).removeO()
                if r is S.Zero:
                    return o
                term = r
                s = [term]
                for k in range(2, newn):
                    term *= r
                    s.append(term / k ** nu)
                return Add(*s) + o
        return super(polylog, self)._eval_nseries(x, n, logx, cdir)

class zeta(DefinedFunction):

    @classmethod
    def eval(cls, s, a=None):
        if a is S.One:
            return cls(s)
        elif s is S.NaN or a is S.NaN:
            return S.NaN
        elif s is S.One:
            return S.ComplexInfinity
        elif s is S.Infinity:
            return S.One
        elif a is S.Infinity:
            return S.Zero
        sint = s.is_Integer
        if a is None:
            a = S.One
        if sint and s.is_nonpositive:
            return bernoulli(1 - s, a) / (s - 1)
        elif a is S.One:
            if sint and s.is_even:
                return -(2 * pi * I) ** s * bernoulli(s) / (2 * factorial(s))
        elif sint and a.is_Integer and a.is_positive:
            return cls(s) - harmonic(a - 1, s)
        elif a.is_Integer and a.is_nonpositive and (s.is_integer is False or s.is_nonpositive is False):
            return S.NaN

    def _eval_rewrite_as_bernoulli(self, s, a=1, **kwargs):
        if a == 1 and s.is_integer and s.is_nonnegative and s.is_even:
            return -(2 * pi * I) ** s * bernoulli(s) / (2 * factorial(s))
        return bernoulli(1 - s, a) / (s - 1)

    def _eval_rewrite_as_dirichlet_eta(self, s, a=1, **kwargs):
        if a != 1:
            return self
        s = self.args[0]
        return dirichlet_eta(s) / (1 - 2 ** (1 - s))

    def _eval_rewrite_as_lerchphi(self, s, a=1, **kwargs):
        return lerchphi(1, s, a)

    def _eval_is_finite(self):
        return fuzzy_not((self.args[0] - 1).is_zero)

    def _eval_expand_func(self, **hints):
        s = self.args[0]
        a = self.args[1] if len(self.args) > 1 else S.One
        if a.is_integer:
            if a.is_positive:
                return zeta(s) - harmonic(a - 1, s)
            if a.is_nonpositive and (s.is_integer is False or s.is_nonpositive is False):
                return S.NaN
        return self

    def fdiff(self, argindex=1):
        if len(self.args) == 2:
            s, a = self.args
        else:
            s, a = self.args + (1,)
        if argindex == 2:
            return -s * zeta(s + 1, a)
        else:
            raise ArgumentIndexError

    def _eval_as_leading_term(self, x, logx, cdir):
        if len(self.args) == 2:
            s, a = self.args
        else:
            s, a = self.args + (S.One,)
        try:
            c, e = a.leadterm(x)
        except NotImplementedError:
            return self
        if e.is_negative and (not s.is_positive):
            raise NotImplementedError
        return super(zeta, self)._eval_as_leading_term(x, logx=logx, cdir=cdir)

class dirichlet_eta(DefinedFunction):

    @classmethod
    def eval(cls, s, a=None):
        if a is S.One:
            return cls(s)
        if a is None:
            if s == 1:
                return log(2)
            z = zeta(s)
            if not z.has(zeta):
                return (1 - 2 ** (1 - s)) * z
            return
        elif s == 1:
            from sympy.functions.special.gamma_functions import digamma
            return log(2) - digamma(a) + digamma((a + 1) / 2)
        z1 = zeta(s, a)
        z2 = zeta(s, (a + 1) / 2)
        if not z1.has(zeta) and (not z2.has(zeta)):
            return z1 - 2 ** (1 - s) * z2

    def _eval_rewrite_as_zeta(self, s, a=1, **kwargs):
        from sympy.functions.special.gamma_functions import digamma
        if a == 1:
            return Piecewise((log(2), Eq(s, 1)), ((1 - 2 ** (1 - s)) * zeta(s), True))
        return Piecewise((log(2) - digamma(a) + digamma((a + 1) / 2), Eq(s, 1)), (zeta(s, a) - 2 ** (1 - s) * zeta(s, (a + 1) / 2), True))

    def _eval_rewrite_as_genocchi(self, s, a=S.One, **kwargs):
        from sympy.functions.special.gamma_functions import digamma
        return Piecewise((log(2) - digamma(a) + digamma((a + 1) / 2), Eq(s, 1)), (genocchi(1 - s, a) / (2 * (s - 1)), True))

    def _eval_evalf(self, prec):
        if all((i.is_number for i in self.args)):
            return self.rewrite(zeta)._eval_evalf(prec)

class riemann_xi(DefinedFunction):

    @classmethod
    def eval(cls, s):
        from sympy.functions.special.gamma_functions import gamma
        z = zeta(s)
        if s in (S.Zero, S.One):
            return S.Half
        if not isinstance(z, zeta):
            return s * (s - 1) * gamma(s / 2) * z / (2 * pi ** (s / 2))

    def _eval_rewrite_as_zeta(self, s, **kwargs):
        from sympy.functions.special.gamma_functions import gamma
        return s * (s - 1) * gamma(s / 2) * zeta(s) / (2 * pi ** (s / 2))

class stieltjes(DefinedFunction):

    @classmethod
    def eval(cls, n, a=None):
        if a is not None:
            a = sympify(a)
            if a is S.NaN:
                return S.NaN
            if a.is_Integer and a.is_nonpositive:
                return S.ComplexInfinity
        if n.is_Number:
            if n is S.NaN:
                return S.NaN
            elif n < 0 or not n.is_Integer:
                return S.ComplexInfinity
            elif n is S.Zero and a in [None, 1]:
                return S.EulerGamma
        if n.is_extended_negative:
            return S.ComplexInfinity
        if n.is_zero and a in [None, 1]:
            return S.EulerGamma
        if n.is_integer == False:
            return S.ComplexInfinity

@cacheit
def _dilogtable():
    return {S.Half: pi ** 2 / 12 - log(2) ** 2 / 2, Integer(2): pi ** 2 / 4 - I * pi * log(2), -(sqrt(5) - 1) / 2: -pi ** 2 / 15 + log((sqrt(5) - 1) / 2) ** 2 / 2, -(sqrt(5) + 1) / 2: -pi ** 2 / 10 - log((sqrt(5) + 1) / 2) ** 2, (3 - sqrt(5)) / 2: pi ** 2 / 15 - log((sqrt(5) - 1) / 2) ** 2, (sqrt(5) - 1) / 2: pi ** 2 / 10 - log((sqrt(5) - 1) / 2) ** 2, I: I * S.Catalan - pi ** 2 / 48, -I: -I * S.Catalan - pi ** 2 / 48, 1 - I: pi ** 2 / 16 - I * S.Catalan - pi * I / 4 * log(2), 1 + I: pi ** 2 / 16 + I * S.Catalan + pi * I / 4 * log(2), (1 - I) / 2: -log(2) ** 2 / 8 + pi * I * log(2) / 8 + 5 * pi ** 2 / 96 - I * S.Catalan}