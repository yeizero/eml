from __future__ import annotations
from collections import Counter
from sympy.core import S, Mod
from sympy.core.add import Add
from sympy.core.expr import Expr
from sympy.core.function import DefinedFunction, Derivative, ArgumentIndexError
from sympy.core.containers import Tuple
from sympy.core.mul import Mul
from sympy.core.numbers import I, pi, oo, zoo
from sympy.core.parameters import global_parameters
from sympy.core.relational import Ne
from sympy.core.sorting import default_sort_key
from sympy.core.symbol import Dummy
from sympy.external.gmpy import lcm
from sympy.external.mpmath import local_workprec
from sympy.functions import sqrt, exp, log, sin, cos, asin, atan, sinh, cosh, asinh, acosh, atanh, acoth
from sympy.functions import factorial, RisingFactorial
from sympy.functions.elementary.complexes import Abs, re, unpolarify
from sympy.functions.elementary.exponential import exp_polar
from sympy.functions.elementary.integers import ceiling
from sympy.functions.elementary.piecewise import Piecewise
from sympy.logic.boolalg import And, Or
from sympy import ordered

class TupleArg(Tuple):

    def as_leading_term(self, *x, logx=None, cdir=0):
        return TupleArg(*[f.as_leading_term(*x, logx=logx, cdir=cdir) for f in self.args])

    def limit(self, x, xlim, dir='+'):
        from sympy.series.limits import limit
        return TupleArg(*[limit(f, x, xlim, dir) for f in self.args])

def _prep_tuple(v):
    return TupleArg(*[unpolarify(x) for x in v])

class TupleParametersBase(DefinedFunction):
    is_commutative = True

    def _eval_derivative(self, s):
        try:
            res = 0
            if self.args[0].has(s) or self.args[1].has(s):
                for i, p in enumerate(self._diffargs):
                    m = self._diffargs[i].diff(s)
                    if m != 0:
                        res += self.fdiff((1, i)) * m
            return res + self.fdiff(3) * self.args[2].diff(s)
        except (ArgumentIndexError, NotImplementedError):
            return Derivative(self, s)

class hyper(TupleParametersBase):

    def __new__(cls, ap, bq, z, **kwargs):
        if kwargs.pop('evaluate', global_parameters.evaluate):
            ca = Counter(Tuple(*ap))
            cb = Counter(Tuple(*bq))
            common = ca & cb
            arg = ap, bq = ([], [])
            for i, c in enumerate((ca, cb)):
                c -= common
                for k in ordered(c):
                    arg[i].extend([k] * c[k])
        else:
            ap = list(ordered(ap))
            bq = list(ordered(bq))
        return super().__new__(cls, _prep_tuple(ap), _prep_tuple(bq), z, **kwargs)

    @classmethod
    def eval(cls, ap, bq, z):
        if len(ap) <= len(bq) or (len(ap) == len(bq) + 1 and (Abs(z) <= 1) == True):
            nz = unpolarify(z)
            if z != nz:
                return hyper(ap, bq, nz)

    def fdiff(self, argindex=3):
        if argindex != 3:
            raise ArgumentIndexError(self, argindex)
        nap = Tuple(*[a + 1 for a in self.ap])
        nbq = Tuple(*[b + 1 for b in self.bq])
        fac = Mul(*self.ap) / Mul(*self.bq)
        return fac * hyper(nap, nbq, self.argument)

    def _eval_expand_func(self, **hints):
        from sympy.functions.special.gamma_functions import gamma
        from sympy.simplify.hyperexpand import hyperexpand
        if len(self.ap) == 2 and len(self.bq) == 1 and (self.argument == 1):
            a, b = self.ap
            c = self.bq[0]
            return gamma(c) * gamma(c - a - b) / gamma(c - a) / gamma(c - b)
        return hyperexpand(self)

    def _eval_rewrite_as_Sum(self, ap, bq, z, **kwargs):
        from sympy.concrete.summations import Sum
        n = Dummy('n', integer=True)
        rfap = [RisingFactorial(a, n) for a in ap]
        rfbq = [RisingFactorial(b, n) for b in bq]
        coeff = Mul(*rfap) / Mul(*rfbq)
        return Piecewise((Sum(coeff * z ** n / factorial(n), (n, 0, oo)), self.convergence_statement), (self, True))

    def _eval_as_leading_term(self, x, logx, cdir):
        arg = self.args[2]
        x0 = arg.subs(x, 0)
        if x0 is S.NaN:
            x0 = arg.limit(x, 0, dir='-' if re(cdir).is_negative else '+')
        if x0 is S.Zero:
            return S.One
        return super()._eval_as_leading_term(x, logx=logx, cdir=cdir)

    def _eval_nseries(self, x, n, logx, cdir=0):
        from sympy.series.order import Order
        arg = self.args[2]
        x0 = arg.limit(x, 0)
        ap = self.args[0]
        bq = self.args[1]
        if not (arg == x and x0 == 0):
            from sympy.simplify.hyperexpand import hyperexpand
            return hyperexpand(super()._eval_nseries(x, n, logx))
        terms = []
        for i in range(n):
            num = Mul(*[RisingFactorial(a, i) for a in ap])
            den = Mul(*[RisingFactorial(b, i) for b in bq])
            terms.append(num / den * arg ** i / factorial(i))
        return Add(*terms) + Order(x ** n, x)

    @property
    def argument(self):
        return self.args[2]

    @property
    def ap(self):
        return Tuple(*self.args[0])

    @property
    def bq(self):
        return Tuple(*self.args[1])

    @property
    def _diffargs(self):
        return self.ap + self.bq

    @property
    def eta(self):
        return sum(self.ap) - sum(self.bq)

    @property
    def radius_of_convergence(self):
        if any((a.is_integer and (a <= 0) == True for a in self.ap + self.bq)):
            aints = [a for a in self.ap if a.is_Integer and (a <= 0) == True]
            bints = [a for a in self.bq if a.is_Integer and (a <= 0) == True]
            if len(aints) < len(bints):
                return S.Zero
            popped = False
            for b in bints:
                cancelled = False
                while aints:
                    a = aints.pop()
                    if a >= b:
                        cancelled = True
                        break
                    popped = True
                if not cancelled:
                    return S.Zero
            if aints or popped:
                return oo
        if len(self.ap) == len(self.bq) + 1:
            return S.One
        elif len(self.ap) <= len(self.bq):
            return oo
        else:
            return S.Zero

    @property
    def convergence_statement(self):
        R = self.radius_of_convergence
        if R == 0:
            return False
        if R == oo:
            return True
        e = self.eta
        z = self.argument
        c1 = And(re(e) < 0, abs(z) <= 1)
        c2 = And(0 <= re(e), re(e) < 1, abs(z) <= 1, Ne(z, 1))
        c3 = And(re(e) >= 1, abs(z) < 1)
        return Or(c1, c2, c3)

    def _eval_simplify(self, **kwargs):
        from sympy.simplify.hyperexpand import hyperexpand
        return hyperexpand(self)

class meijerg(TupleParametersBase):

    def __new__(cls, *args, **kwargs):
        if len(args) == 5:
            args = [(args[0], args[1]), (args[2], args[3]), args[4]]
        if len(args) != 3:
            raise TypeError("args must be either as, as', bs, bs', z or as, bs, z")

        def tr(p):
            if len(p) != 2:
                raise TypeError('wrong argument')
            p = [list(ordered(i)) for i in p]
            return TupleArg(_prep_tuple(p[0]), _prep_tuple(p[1]))
        arg0, arg1 = (tr(args[0]), tr(args[1]))
        if Tuple(arg0, arg1).has(oo, zoo, -oo):
            raise ValueError('G-function parameters must be finite')
        if any(((a - b).is_Integer and a - b > 0 for a in arg0[0] for b in arg1[0])):
            raise ValueError('no parameter a1, ..., an may differ from any b1, ..., bm by a positive integer')
        return super().__new__(cls, arg0, arg1, args[2], **kwargs)

    def fdiff(self, argindex=3):
        if argindex != 3:
            return self._diff_wrt_parameter(argindex[1])
        if len(self.an) >= 1:
            a = list(self.an)
            a[0] -= 1
            G = meijerg(a, self.aother, self.bm, self.bother, self.argument)
            return 1 / self.argument * ((self.an[0] - 1) * self + G)
        elif len(self.bm) >= 1:
            b = list(self.bm)
            b[0] += 1
            G = meijerg(self.an, self.aother, b, self.bother, self.argument)
            return 1 / self.argument * (self.bm[0] * self - G)
        else:
            return S.Zero

    def _diff_wrt_parameter(self, idx):
        an = list(self.an)
        ap = list(self.aother)
        bm = list(self.bm)
        bq = list(self.bother)
        if idx < len(an):
            an.pop(idx)
        else:
            idx -= len(an)
            if idx < len(ap):
                ap.pop(idx)
            else:
                idx -= len(ap)
                if idx < len(bm):
                    bm.pop(idx)
                else:
                    bq.pop(idx - len(bm))
        pairs1 = []
        pairs2 = []
        for l1, l2, pairs in [(an, bq, pairs1), (ap, bm, pairs2)]:
            while l1:
                x = l1.pop()
                found = None
                for i, y in enumerate(l2):
                    if not Mod((x - y).simplify(), 1):
                        found = i
                        break
                if found is None:
                    raise NotImplementedError('Derivative not expressible as G-function?')
                y = l2[i]
                l2.pop(i)
                pairs.append((x, y))
        res = log(self.argument) * self
        for a, b in pairs1:
            sign = 1
            n = a - b
            base = b
            if n < 0:
                sign = -1
                n = b - a
                base = a
            for k in range(n):
                res -= sign * meijerg(self.an + (base + k + 1,), self.aother, self.bm, self.bother + (base + k + 0,), self.argument)
        for a, b in pairs2:
            sign = 1
            n = b - a
            base = a
            if n < 0:
                sign = -1
                n = a - b
                base = b
            for k in range(n):
                res -= sign * meijerg(self.an, self.aother + (base + k + 1,), self.bm + (base + k + 0,), self.bother, self.argument)
        return res

    def get_period(self):

        def compute(l):
            for i, b in enumerate(l):
                if not b.is_Rational:
                    return oo
                for j in range(i + 1, len(l)):
                    if not Mod((b - l[j]).simplify(), 1):
                        return oo
            return lcm(*(x.q for x in l))
        beta = compute(self.bm)
        alpha = compute(self.an)
        p, q = (len(self.ap), len(self.bq))
        if p == q:
            if oo in (alpha, beta):
                return oo
            return 2 * pi * lcm(alpha, beta)
        elif p < q:
            return 2 * pi * beta
        else:
            return 2 * pi * alpha

    def _eval_expand_func(self, **hints):
        from sympy.simplify.hyperexpand import hyperexpand
        return hyperexpand(self)

    def _eval_evalf(self, prec):
        znum = self.argument._eval_evalf(prec)
        if znum.has(exp_polar):
            znum, branch = znum.as_coeff_mul(exp_polar)
            if len(branch) != 1:
                return
            branch = branch[0].args[0] / I
        else:
            branch = S.Zero
        n = ceiling(abs(branch / pi)) + 1
        znum = znum ** (S.One / n) * exp(I * branch / n)
        try:
            [z, r, ap, bq] = [arg._to_mpmath(prec) for arg in [znum, 1 / n, self.args[0], self.args[1]]]
        except ValueError:
            return
        with local_workprec(prec) as ctx:
            v = ctx.meijerg(ap, bq, z, r)
            v_expr = Expr._from_mpmath(v, prec)
        return v_expr

    def _eval_as_leading_term(self, x, logx, cdir):
        from sympy.simplify.hyperexpand import hyperexpand
        return hyperexpand(self).as_leading_term(x, logx=logx, cdir=cdir)

    def integrand(self, s):
        from sympy.functions.special.gamma_functions import gamma
        return self.argument ** s * Mul(*(gamma(b - s) for b in self.bm)) * Mul(*(gamma(1 - a + s) for a in self.an)) / Mul(*(gamma(1 - b + s) for b in self.bother)) / Mul(*(gamma(a - s) for a in self.aother))

    @property
    def argument(self):
        return self.args[2]

    @property
    def an(self):
        return Tuple(*self.args[0][0])

    @property
    def ap(self):
        return Tuple(*self.args[0][0] + self.args[0][1])

    @property
    def aother(self):
        return Tuple(*self.args[0][1])

    @property
    def bm(self):
        return Tuple(*self.args[1][0])

    @property
    def bq(self):
        return Tuple(*self.args[1][0] + self.args[1][1])

    @property
    def bother(self):
        return Tuple(*self.args[1][1])

    @property
    def _diffargs(self):
        return self.ap + self.bq

    @property
    def nu(self):
        return sum(self.bq) - sum(self.ap)

    @property
    def delta(self):
        return len(self.bm) + len(self.an) - S(len(self.ap) + len(self.bq)) / 2

    @property
    def is_number(self):
        return not self.free_symbols

class HyperRep(DefinedFunction):

    @classmethod
    def eval(cls, *args):
        newargs = tuple(map(unpolarify, args[:-1])) + args[-1:]
        if args != newargs:
            return cls(*newargs)

    @classmethod
    def _expr_small(cls, x):
        raise NotImplementedError

    @classmethod
    def _expr_small_minus(cls, x):
        raise NotImplementedError

    @classmethod
    def _expr_big(cls, x, n):
        raise NotImplementedError

    @classmethod
    def _expr_big_minus(cls, x, n):
        raise NotImplementedError

    def _eval_rewrite_as_nonrep(self, *args, **kwargs):
        x, n = self.args[-1].extract_branch_factor(allow_half=True)
        minus = False
        newargs = self.args[:-1] + (x,)
        if not n.is_Integer:
            minus = True
            n -= S.Half
        newerargs = newargs + (n,)
        if minus:
            small = self._expr_small_minus(*newargs)
            big = self._expr_big_minus(*newerargs)
        else:
            small = self._expr_small(*newargs)
            big = self._expr_big(*newerargs)
        if big == small:
            return small
        return Piecewise((big, abs(x) > 1), (small, True))

    def _eval_rewrite_as_nonrepsmall(self, *args, **kwargs):
        x, n = self.args[-1].extract_branch_factor(allow_half=True)
        args = self.args[:-1] + (x,)
        if not n.is_Integer:
            return self._expr_small_minus(*args)
        return self._expr_small(*args)

class HyperRep_power1(HyperRep):

    @classmethod
    def _expr_small(cls, a, x):
        return (1 - x) ** a

    @classmethod
    def _expr_small_minus(cls, a, x):
        return (1 + x) ** a

    @classmethod
    def _expr_big(cls, a, x, n):
        if a.is_integer:
            return cls._expr_small(a, x)
        return (x - 1) ** a * exp((2 * n - 1) * pi * I * a)

    @classmethod
    def _expr_big_minus(cls, a, x, n):
        if a.is_integer:
            return cls._expr_small_minus(a, x)
        return (1 + x) ** a * exp(2 * n * pi * I * a)

class HyperRep_power2(HyperRep):

    @classmethod
    def _expr_small(cls, a, x):
        return 2 ** (2 * a - 1) * (1 + sqrt(1 - x)) ** (1 - 2 * a)

    @classmethod
    def _expr_small_minus(cls, a, x):
        return 2 ** (2 * a - 1) * (1 + sqrt(1 + x)) ** (1 - 2 * a)

    @classmethod
    def _expr_big(cls, a, x, n):
        sgn = -1
        if n.is_odd:
            sgn = 1
            n -= 1
        return 2 ** (2 * a - 1) * (1 + sgn * I * sqrt(x - 1)) ** (1 - 2 * a) * exp(-2 * n * pi * I * a)

    @classmethod
    def _expr_big_minus(cls, a, x, n):
        sgn = 1
        if n.is_odd:
            sgn = -1
        return sgn * 2 ** (2 * a - 1) * (sqrt(1 + x) + sgn) ** (1 - 2 * a) * exp(-2 * pi * I * a * n)

class HyperRep_log1(HyperRep):

    @classmethod
    def _expr_small(cls, x):
        return log(1 - x)

    @classmethod
    def _expr_small_minus(cls, x):
        return log(1 + x)

    @classmethod
    def _expr_big(cls, x, n):
        return log(x - 1) + (2 * n - 1) * pi * I

    @classmethod
    def _expr_big_minus(cls, x, n):
        return log(1 + x) + 2 * n * pi * I

class HyperRep_atanh(HyperRep):

    @classmethod
    def _expr_small(cls, x):
        return atanh(sqrt(x)) / sqrt(x)

    def _expr_small_minus(cls, x):
        return atan(sqrt(x)) / sqrt(x)

    def _expr_big(cls, x, n):
        if n.is_even:
            return (acoth(sqrt(x)) + I * pi / 2) / sqrt(x)
        else:
            return (acoth(sqrt(x)) - I * pi / 2) / sqrt(x)

    def _expr_big_minus(cls, x, n):
        if n.is_even:
            return atan(sqrt(x)) / sqrt(x)
        else:
            return (atan(sqrt(x)) - pi) / sqrt(x)

class HyperRep_asin1(HyperRep):

    @classmethod
    def _expr_small(cls, z):
        return asin(sqrt(z)) / sqrt(z)

    @classmethod
    def _expr_small_minus(cls, z):
        return asinh(sqrt(z)) / sqrt(z)

    @classmethod
    def _expr_big(cls, z, n):
        return S.NegativeOne ** n * ((S.Half - n) * pi / sqrt(z) + I * acosh(sqrt(z)) / sqrt(z))

    @classmethod
    def _expr_big_minus(cls, z, n):
        return S.NegativeOne ** n * (asinh(sqrt(z)) / sqrt(z) + n * pi * I / sqrt(z))

class HyperRep_asin2(HyperRep):

    @classmethod
    def _expr_small(cls, z):
        return HyperRep_asin1._expr_small(z) / HyperRep_power1._expr_small(S.Half, z)

    @classmethod
    def _expr_small_minus(cls, z):
        return HyperRep_asin1._expr_small_minus(z) / HyperRep_power1._expr_small_minus(S.Half, z)

    @classmethod
    def _expr_big(cls, z, n):
        return HyperRep_asin1._expr_big(z, n) / HyperRep_power1._expr_big(S.Half, z, n)

    @classmethod
    def _expr_big_minus(cls, z, n):
        return HyperRep_asin1._expr_big_minus(z, n) / HyperRep_power1._expr_big_minus(S.Half, z, n)

class HyperRep_sqrts1(HyperRep):

    @classmethod
    def _expr_small(cls, a, z):
        return ((1 - sqrt(z)) ** (2 * a) + (1 + sqrt(z)) ** (2 * a)) / 2

    @classmethod
    def _expr_small_minus(cls, a, z):
        return (1 + z) ** a * cos(2 * a * atan(sqrt(z)))

    @classmethod
    def _expr_big(cls, a, z, n):
        if n.is_even:
            return ((sqrt(z) + 1) ** (2 * a) * exp(2 * pi * I * n * a) + (sqrt(z) - 1) ** (2 * a) * exp(2 * pi * I * (n - 1) * a)) / 2
        else:
            n -= 1
            return ((sqrt(z) - 1) ** (2 * a) * exp(2 * pi * I * a * (n + 1)) + (sqrt(z) + 1) ** (2 * a) * exp(2 * pi * I * a * n)) / 2

    @classmethod
    def _expr_big_minus(cls, a, z, n):
        if n.is_even:
            return (1 + z) ** a * exp(2 * pi * I * n * a) * cos(2 * a * atan(sqrt(z)))
        else:
            return (1 + z) ** a * exp(2 * pi * I * n * a) * cos(2 * a * atan(sqrt(z)) - 2 * pi * a)

class HyperRep_sqrts2(HyperRep):

    @classmethod
    def _expr_small(cls, a, z):
        return sqrt(z) * ((1 - sqrt(z)) ** (2 * a) - (1 + sqrt(z)) ** (2 * a)) / 2

    @classmethod
    def _expr_small_minus(cls, a, z):
        return sqrt(z) * (1 + z) ** a * sin(2 * a * atan(sqrt(z)))

    @classmethod
    def _expr_big(cls, a, z, n):
        if n.is_even:
            return sqrt(z) / 2 * ((sqrt(z) - 1) ** (2 * a) * exp(2 * pi * I * a * (n - 1)) - (sqrt(z) + 1) ** (2 * a) * exp(2 * pi * I * a * n))
        else:
            n -= 1
            return sqrt(z) / 2 * ((sqrt(z) - 1) ** (2 * a) * exp(2 * pi * I * a * (n + 1)) - (sqrt(z) + 1) ** (2 * a) * exp(2 * pi * I * a * n))

    def _expr_big_minus(cls, a, z, n):
        if n.is_even:
            return (1 + z) ** a * exp(2 * pi * I * n * a) * sqrt(z) * sin(2 * a * atan(sqrt(z)))
        else:
            return (1 + z) ** a * exp(2 * pi * I * n * a) * sqrt(z) * sin(2 * a * atan(sqrt(z)) - 2 * pi * a)

class HyperRep_log2(HyperRep):

    @classmethod
    def _expr_small(cls, z):
        return log(S.Half + sqrt(1 - z) / 2)

    @classmethod
    def _expr_small_minus(cls, z):
        return log(S.Half + sqrt(1 + z) / 2)

    @classmethod
    def _expr_big(cls, z, n):
        if n.is_even:
            return (n - S.Half) * pi * I + log(sqrt(z) / 2) + I * asin(1 / sqrt(z))
        else:
            return (n - S.Half) * pi * I + log(sqrt(z) / 2) - I * asin(1 / sqrt(z))

    def _expr_big_minus(cls, z, n):
        if n.is_even:
            return pi * I * n + log(S.Half + sqrt(1 + z) / 2)
        else:
            return pi * I * n + log(sqrt(1 + z) / 2 - S.Half)

class HyperRep_cosasin(HyperRep):

    @classmethod
    def _expr_small(cls, a, z):
        return cos(2 * a * asin(sqrt(z)))

    @classmethod
    def _expr_small_minus(cls, a, z):
        return cosh(2 * a * asinh(sqrt(z)))

    @classmethod
    def _expr_big(cls, a, z, n):
        return cosh(2 * a * acosh(sqrt(z)) + a * pi * I * (2 * n - 1))

    @classmethod
    def _expr_big_minus(cls, a, z, n):
        return cosh(2 * a * asinh(sqrt(z)) + 2 * a * pi * I * n)

class HyperRep_sinasin(HyperRep):

    @classmethod
    def _expr_small(cls, a, z):
        return sqrt(z) / sqrt(1 - z) * sin(2 * a * asin(sqrt(z)))

    @classmethod
    def _expr_small_minus(cls, a, z):
        return -sqrt(z) / sqrt(1 + z) * sinh(2 * a * asinh(sqrt(z)))

    @classmethod
    def _expr_big(cls, a, z, n):
        return -1 / sqrt(1 - 1 / z) * sinh(2 * a * acosh(sqrt(z)) + a * pi * I * (2 * n - 1))

    @classmethod
    def _expr_big_minus(cls, a, z, n):
        return -1 / sqrt(1 + 1 / z) * sinh(2 * a * asinh(sqrt(z)) + 2 * a * pi * I * n)

class appellf1(DefinedFunction):

    @classmethod
    def eval(cls, a, b1, b2, c, x, y):
        if default_sort_key(b1) > default_sort_key(b2):
            b1, b2 = (b2, b1)
            x, y = (y, x)
            return cls(a, b1, b2, c, x, y)
        elif b1 == b2 and default_sort_key(x) > default_sort_key(y):
            x, y = (y, x)
            return cls(a, b1, b2, c, x, y)
        if x == 0 and y == 0:
            return S.One

    def fdiff(self, argindex=5):
        a, b1, b2, c, x, y = self.args
        if argindex == 5:
            return a * b1 / c * appellf1(a + 1, b1 + 1, b2, c + 1, x, y)
        elif argindex == 6:
            return a * b2 / c * appellf1(a + 1, b1, b2 + 1, c + 1, x, y)
        elif argindex in (1, 2, 3, 4):
            return Derivative(self, self.args[argindex - 1])
        else:
            raise ArgumentIndexError(self, argindex)