from __future__ import annotations
from sympy.core import S
from sympy.core.expr import Expr
from sympy.core.function import DefinedFunction, ArgumentIndexError
from sympy.core.symbol import Dummy, uniquely_named_symbol
from sympy.external.mpmath import local_workprec
from sympy.functions.special.gamma_functions import gamma, digamma
from sympy.functions.combinatorial.numbers import catalan
from sympy.functions.elementary.complexes import conjugate

class beta(DefinedFunction):
    unbranched = True

    def fdiff(self, argindex):
        x, y = self.args
        if argindex == 1:
            return beta(x, y) * (digamma(x) - digamma(x + y))
        elif argindex == 2:
            return beta(x, y) * (digamma(y) - digamma(x + y))
        else:
            raise ArgumentIndexError(self, argindex)

    @classmethod
    def eval(cls, x, y=None):
        if y is None:
            return beta(x, x)
        if x.is_Number and y.is_Number:
            return beta(x, y, evaluate=False).doit()

    def doit(self, **hints):
        x = xold = self.args[0]
        single_argument = len(self.args) == 1
        y = yold = self.args[0] if single_argument else self.args[1]
        if hints.get('deep', True):
            x = x.doit(**hints)
            y = y.doit(**hints)
        if y.is_zero or x.is_zero:
            return S.ComplexInfinity
        if y is S.One:
            return 1 / x
        if x is S.One:
            return 1 / y
        if y == x + 1:
            return 1 / (x * y * catalan(x))
        s = x + y
        if s.is_integer and s.is_negative and (x.is_integer is False) and (y.is_integer is False):
            return S.Zero
        if x == xold and y == yold and (not single_argument):
            return self
        return beta(x, y)

    def _eval_expand_func(self, **hints):
        x, y = self.args
        return gamma(x) * gamma(y) / gamma(x + y)

    def _eval_is_real(self):
        return self.args[0].is_real and self.args[1].is_real

    def _eval_conjugate(self):
        return self.func(self.args[0].conjugate(), self.args[1].conjugate())

    def _eval_rewrite_as_gamma(self, x, y, piecewise=True, **kwargs):
        return self._eval_expand_func(**kwargs)

    def _eval_rewrite_as_Integral(self, x, y, **kwargs):
        from sympy.integrals.integrals import Integral
        t = Dummy(uniquely_named_symbol('t', [x, y]).name)
        return Integral(t ** (x - 1) * (1 - t) ** (y - 1), (t, 0, 1))

class betainc(DefinedFunction):
    nargs = 4
    unbranched = True

    def fdiff(self, argindex):
        a, b, x1, x2 = self.args
        if argindex == 3:
            return -(1 - x1) ** (b - 1) * x1 ** (a - 1)
        elif argindex == 4:
            return (1 - x2) ** (b - 1) * x2 ** (a - 1)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_evalf(self, prec):
        a, b, x1, x2 = [a._to_mpmath(prec) for a in self.args]
        with local_workprec(prec) as ctx:
            res = ctx.betainc(a, b, x1, x2, 0)
            if isinstance(res, int):
                res = ctx.mpf(res)
        return Expr._from_mpmath(res, prec)

    def _eval_is_real(self):
        if all((arg.is_real for arg in self.args)):
            return True

    def _eval_conjugate(self):
        return self.func(*map(conjugate, self.args))

    def _eval_rewrite_as_Integral(self, a, b, x1, x2, **kwargs):
        from sympy.integrals.integrals import Integral
        t = Dummy(uniquely_named_symbol('t', [a, b, x1, x2]).name)
        return Integral(t ** (a - 1) * (1 - t) ** (b - 1), (t, x1, x2))

    def _eval_rewrite_as_hyper(self, a, b, x1, x2, **kwargs):
        from sympy.functions.special.hyper import hyper
        return (x2 ** a * hyper((a, 1 - b), (a + 1,), x2) - x1 ** a * hyper((a, 1 - b), (a + 1,), x1)) / a

class betainc_regularized(DefinedFunction):
    nargs = 4
    unbranched = True

    def __new__(cls, a, b, x1, x2):
        return super().__new__(cls, a, b, x1, x2)

    def _eval_evalf(self, prec):
        a, b, x1, x2 = [a._to_mpmath(prec) for a in self.args]
        with local_workprec(prec) as ctx:
            res = ctx.betainc(a, b, x1, x2, 1)
            if isinstance(res, int):
                res = ctx.mpf(res)
        return Expr._from_mpmath(res, prec)

    def fdiff(self, argindex):
        a, b, x1, x2 = self.args
        if argindex == 3:
            return -(1 - x1) ** (b - 1) * x1 ** (a - 1) / beta(a, b)
        elif argindex == 4:
            return (1 - x2) ** (b - 1) * x2 ** (a - 1) / beta(a, b)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_is_real(self):
        if all((arg.is_real for arg in self.args)):
            return True

    def _eval_conjugate(self):
        return self.func(*map(conjugate, self.args))

    def _eval_rewrite_as_Integral(self, a, b, x1, x2, **kwargs):
        from sympy.integrals.integrals import Integral
        t = Dummy(uniquely_named_symbol('t', [a, b, x1, x2]).name)
        integrand = t ** (a - 1) * (1 - t) ** (b - 1)
        expr = Integral(integrand, (t, x1, x2))
        return expr / Integral(integrand, (t, 0, 1))

    def _eval_rewrite_as_hyper(self, a, b, x1, x2, **kwargs):
        from sympy.functions.special.hyper import hyper
        expr = (x2 ** a * hyper((a, 1 - b), (a + 1,), x2) - x1 ** a * hyper((a, 1 - b), (a + 1,), x1)) / a
        return expr / beta(a, b)