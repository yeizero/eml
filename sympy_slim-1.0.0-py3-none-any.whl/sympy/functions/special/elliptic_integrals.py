from __future__ import annotations
from sympy.core import S, pi, I, Rational
from sympy.core.function import DefinedFunction, ArgumentIndexError
from sympy.core.symbol import Dummy, uniquely_named_symbol
from sympy.functions.elementary.complexes import sign
from sympy.functions.elementary.hyperbolic import atanh
from sympy.functions.elementary.miscellaneous import sqrt
from sympy.functions.elementary.trigonometric import sin, tan
from sympy.functions.special.gamma_functions import gamma
from sympy.functions.special.hyper import hyper, meijerg

class elliptic_k(DefinedFunction):

    @classmethod
    def eval(cls, m):
        if m.is_zero:
            return pi * S.Half
        elif m is S.Half:
            return 8 * pi ** Rational(3, 2) / gamma(Rational(-1, 4)) ** 2
        elif m is S.One:
            return S.ComplexInfinity
        elif m is S.NegativeOne:
            return gamma(Rational(1, 4)) ** 2 / (4 * sqrt(2 * pi))
        elif m in (S.Infinity, S.NegativeInfinity, I * S.Infinity, I * S.NegativeInfinity, S.ComplexInfinity):
            return S.Zero

    def fdiff(self, argindex=1):
        m = self.args[0]
        return (elliptic_e(m) - (1 - m) * elliptic_k(m)) / (2 * m * (1 - m))

    def _eval_conjugate(self):
        m = self.args[0]
        if (m.is_real and (m - 1).is_positive) is False:
            return self.func(m.conjugate())

    def _eval_nseries(self, x, n, logx, cdir=0):
        from sympy.simplify import hyperexpand
        return hyperexpand(self.rewrite(hyper)._eval_nseries(x, n=n, logx=logx))

    def _eval_rewrite_as_hyper(self, m, **kwargs):
        return pi * S.Half * hyper((S.Half, S.Half), (S.One,), m)

    def _eval_rewrite_as_meijerg(self, m, **kwargs):
        return meijerg(((S.Half, S.Half), []), ((S.Zero,), (S.Zero,)), -m) / 2

    def _eval_is_zero(self):
        m = self.args[0]
        if m.is_infinite:
            return True

    def _eval_rewrite_as_Integral(self, *args, **kwargs):
        from sympy.integrals.integrals import Integral
        t = Dummy(uniquely_named_symbol('t', args).name)
        m = self.args[0]
        return Integral(1 / sqrt(1 - m * sin(t) ** 2), (t, 0, pi / 2))

class elliptic_f(DefinedFunction):

    @classmethod
    def eval(cls, z, m):
        if z.is_zero:
            return S.Zero
        if m.is_zero:
            return z
        k = 2 * z / pi
        if k.is_integer:
            return k * elliptic_k(m)
        elif m in (S.Infinity, S.NegativeInfinity):
            return S.Zero
        elif z.could_extract_minus_sign():
            return -elliptic_f(-z, m)

    def fdiff(self, argindex=1):
        z, m = self.args
        fm = sqrt(1 - m * sin(z) ** 2)
        if argindex == 1:
            return 1 / fm
        elif argindex == 2:
            return elliptic_e(z, m) / (2 * m * (1 - m)) - elliptic_f(z, m) / (2 * m) - sin(2 * z) / (4 * (1 - m) * fm)
        raise ArgumentIndexError(self, argindex)

    def _eval_conjugate(self):
        z, m = self.args
        if (m.is_real and (m - 1).is_positive) is False:
            return self.func(z.conjugate(), m.conjugate())

    def _eval_rewrite_as_Integral(self, *args, **kwargs):
        from sympy.integrals.integrals import Integral
        t = Dummy(uniquely_named_symbol('t', args).name)
        z, m = (self.args[0], self.args[1])
        return Integral(1 / sqrt(1 - m * sin(t) ** 2), (t, 0, z))

    def _eval_is_zero(self):
        z, m = self.args
        if z.is_zero:
            return True
        if m.is_extended_real and m.is_infinite:
            return True

class elliptic_e(DefinedFunction):

    @classmethod
    def eval(cls, m, z=None):
        if z is not None:
            z, m = (m, z)
            k = 2 * z / pi
            if m.is_zero:
                return z
            if z.is_zero:
                return S.Zero
            elif k.is_integer:
                return k * elliptic_e(m)
            elif m in (S.Infinity, S.NegativeInfinity):
                return S.ComplexInfinity
            elif z.could_extract_minus_sign():
                return -elliptic_e(-z, m)
        elif m.is_zero:
            return pi / 2
        elif m is S.One:
            return S.One
        elif m is S.Infinity:
            return I * S.Infinity
        elif m is S.NegativeInfinity:
            return S.Infinity
        elif m is S.ComplexInfinity:
            return S.ComplexInfinity

    def fdiff(self, argindex=1):
        if len(self.args) == 2:
            z, m = self.args
            if argindex == 1:
                return sqrt(1 - m * sin(z) ** 2)
            elif argindex == 2:
                return (elliptic_e(z, m) - elliptic_f(z, m)) / (2 * m)
        else:
            m = self.args[0]
            if argindex == 1:
                return (elliptic_e(m) - elliptic_k(m)) / (2 * m)
        raise ArgumentIndexError(self, argindex)

    def _eval_conjugate(self):
        if len(self.args) == 2:
            z, m = self.args
            if (m.is_real and (m - 1).is_positive) is False:
                return self.func(z.conjugate(), m.conjugate())
        else:
            m = self.args[0]
            if (m.is_real and (m - 1).is_positive) is False:
                return self.func(m.conjugate())

    def _eval_nseries(self, x, n, logx, cdir=0):
        from sympy.simplify import hyperexpand
        if len(self.args) == 1:
            return hyperexpand(self.rewrite(hyper)._eval_nseries(x, n=n, logx=logx))
        return super()._eval_nseries(x, n=n, logx=logx)

    def _eval_rewrite_as_hyper(self, *args, **kwargs):
        if len(args) == 1:
            m = args[0]
            return pi / 2 * hyper((Rational(-1, 2), S.Half), (S.One,), m)

    def _eval_rewrite_as_meijerg(self, *args, **kwargs):
        if len(args) == 1:
            m = args[0]
            return -meijerg(((S.Half, Rational(3, 2)), []), ((S.Zero,), (S.Zero,)), -m) / 4

    def _eval_rewrite_as_Integral(self, *args, **kwargs):
        from sympy.integrals.integrals import Integral
        z, m = (pi / 2, self.args[0]) if len(self.args) == 1 else self.args
        t = Dummy(uniquely_named_symbol('t', args).name)
        return Integral(sqrt(1 - m * sin(t) ** 2), (t, 0, z))

class elliptic_pi(DefinedFunction):

    @classmethod
    def eval(cls, n, m, z=None):
        if z is not None:
            z, m = (m, z)
            if n.is_zero:
                return elliptic_f(z, m)
            elif n is S.One:
                return elliptic_f(z, m) + (sqrt(1 - m * sin(z) ** 2) * tan(z) - elliptic_e(z, m)) / (1 - m)
            k = 2 * z / pi
            if k.is_integer:
                return k * elliptic_pi(n, m)
            elif m.is_zero:
                return atanh(sqrt(n - 1) * tan(z)) / sqrt(n - 1)
            elif n == m:
                return elliptic_f(z, n) - elliptic_pi(1, z, n) + tan(z) / sqrt(1 - n * sin(z) ** 2)
            elif n in (S.Infinity, S.NegativeInfinity):
                return S.Zero
            elif m in (S.Infinity, S.NegativeInfinity):
                return S.Zero
            elif z.could_extract_minus_sign():
                return -elliptic_pi(n, -z, m)
            if n.is_zero:
                return elliptic_f(z, m)
            if m.is_extended_real and m.is_infinite or (n.is_extended_real and n.is_infinite):
                return S.Zero
        else:
            if n.is_zero:
                return elliptic_k(m)
            elif n is S.One:
                return S.ComplexInfinity
            elif m.is_zero:
                return pi / (2 * sqrt(1 - n))
            elif m == S.One:
                return S.NegativeInfinity / sign(n - 1)
            elif n == m:
                return elliptic_e(n) / (1 - n)
            elif n in (S.Infinity, S.NegativeInfinity):
                return S.Zero
            elif m in (S.Infinity, S.NegativeInfinity):
                return S.Zero
            if n.is_zero:
                return elliptic_k(m)
            if m.is_extended_real and m.is_infinite or (n.is_extended_real and n.is_infinite):
                return S.Zero

    def _eval_conjugate(self):
        if len(self.args) == 3:
            n, z, m = self.args
            if (n.is_real and (n - 1).is_positive) is False and (m.is_real and (m - 1).is_positive) is False:
                return self.func(n.conjugate(), z.conjugate(), m.conjugate())
        else:
            n, m = self.args
            return self.func(n.conjugate(), m.conjugate())

    def fdiff(self, argindex=1):
        if len(self.args) == 3:
            n, z, m = self.args
            fm, fn = (sqrt(1 - m * sin(z) ** 2), 1 - n * sin(z) ** 2)
            if argindex == 1:
                return (elliptic_e(z, m) + (m - n) * elliptic_f(z, m) / n + (n ** 2 - m) * elliptic_pi(n, z, m) / n - n * fm * sin(2 * z) / (2 * fn)) / (2 * (m - n) * (n - 1))
            elif argindex == 2:
                return 1 / (fm * fn)
            elif argindex == 3:
                return (elliptic_e(z, m) / (m - 1) + elliptic_pi(n, z, m) - m * sin(2 * z) / (2 * (m - 1) * fm)) / (2 * (n - m))
        else:
            n, m = self.args
            if argindex == 1:
                return (elliptic_e(m) + (m - n) * elliptic_k(m) / n + (n ** 2 - m) * elliptic_pi(n, m) / n) / (2 * (m - n) * (n - 1))
            elif argindex == 2:
                return (elliptic_e(m) / (m - 1) + elliptic_pi(n, m)) / (2 * (n - m))
        raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Integral(self, *args, **kwargs):
        from sympy.integrals.integrals import Integral
        if len(self.args) == 2:
            n, m, z = (self.args[0], self.args[1], pi / 2)
        else:
            n, z, m = self.args
        t = Dummy(uniquely_named_symbol('t', args).name)
        return Integral(1 / ((1 - n * sin(t) ** 2) * sqrt(1 - m * sin(t) ** 2)), (t, 0, z))