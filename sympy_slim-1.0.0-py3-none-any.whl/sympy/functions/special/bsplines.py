from __future__ import annotations
from sympy.core import S, sympify
from sympy.core.symbol import Dummy, symbols
from sympy.functions import Piecewise, piecewise_fold
from sympy.logic.boolalg import And
from sympy.sets.sets import Interval
from functools import lru_cache

def _ivl(cond, x):
    if isinstance(cond, And) and len(cond.args) == 2:
        a, b = cond.args
        if a.lts == x:
            a, b = (b, a)
        return (a.lts, b.gts)
    raise TypeError('unexpected cond type: %s' % cond)

def _add_splines(c, b1, d, b2, x):
    if S.Zero in (b1, c):
        rv = piecewise_fold(d * b2)
    elif S.Zero in (b2, d):
        rv = piecewise_fold(c * b1)
    else:
        new_args = []
        p1 = piecewise_fold(c * b1)
        p2 = piecewise_fold(d * b2)
        p2args = list(p2.args[:-1])
        for arg in p1.args[:-1]:
            expr = arg.expr
            cond = arg.cond
            lower = _ivl(cond, x)[0]
            for i, arg2 in enumerate(p2args):
                expr2 = arg2.expr
                cond2 = arg2.cond
                lower_2, upper_2 = _ivl(cond2, x)
                if cond2 == cond:
                    expr += expr2
                    del p2args[i]
                    break
                elif lower_2 < lower and upper_2 <= lower:
                    new_args.append(arg2)
                    del p2args[i]
                    break
            new_args.append((expr, cond))
        new_args.extend(p2args)
        new_args.append((0, True))
        rv = Piecewise(*new_args, evaluate=False)
    return rv.expand()

@lru_cache(maxsize=128)
def bspline_basis(d, knots, n, x):
    xvar = x
    x = Dummy()
    knots = tuple((sympify(k) for k in knots))
    d = int(d)
    n = int(n)
    n_knots = len(knots)
    n_intervals = n_knots - 1
    if n + d + 1 > n_intervals:
        raise ValueError('n + d + 1 must not exceed len(knots) - 1')
    if d == 0:
        result = Piecewise((S.One, Interval(knots[n], knots[n + 1]).contains(x)), (0, True))
    elif d > 0:
        denom = knots[n + d + 1] - knots[n + 1]
        if denom != S.Zero:
            B = (knots[n + d + 1] - x) / denom
            b2 = bspline_basis(d - 1, knots, n + 1, x)
        else:
            b2 = B = S.Zero
        denom = knots[n + d] - knots[n]
        if denom != S.Zero:
            A = (x - knots[n]) / denom
            b1 = bspline_basis(d - 1, knots, n, x)
        else:
            b1 = A = S.Zero
        result = _add_splines(A, b1, B, b2, x)
    else:
        raise ValueError('degree must be non-negative: %r' % n)
    return result.xreplace({x: xvar})

def bspline_basis_set(d, knots, x):
    n_splines = len(knots) - d - 1
    return [bspline_basis(d, tuple(knots), i, x) for i in range(n_splines)]

def interpolating_spline(d, x, X, Y):
    from sympy.solvers.solveset import linsolve
    from sympy.matrices.dense import Matrix
    d = sympify(d)
    if not (d.is_Integer and d.is_positive):
        raise ValueError('Spline degree must be a positive integer, not %s.' % d)
    if len(X) != len(Y):
        raise ValueError('Number of X and Y coordinates must be the same.')
    if len(X) < d + 1:
        raise ValueError('Degree must be less than the number of control points.')
    if not all((a < b for a, b in zip(X, X[1:]))):
        raise ValueError('The x-coordinates must be strictly increasing.')
    X = [sympify(i) for i in X]
    if d.is_odd:
        j = (d + 1) // 2
        interior_knots = X[j:-j]
    else:
        j = d // 2
        interior_knots = [(a + b) / 2 for a, b in zip(X[j:-j - 1], X[j + 1:-j])]
    knots = [X[0]] * (d + 1) + list(interior_knots) + [X[-1]] * (d + 1)
    basis = bspline_basis_set(d, knots, x)
    A = [[b.subs(x, v) for b in basis] for v in X]
    coeff = linsolve((Matrix(A), Matrix(Y)), symbols('c0:{}'.format(len(X)), cls=Dummy))
    coeff = list(coeff)[0]
    intervals = {c for b in basis for e, c in b.args if c != True}
    intervals = sorted(intervals, key=lambda c: _ivl(c, x))
    basis_dicts = [{c: e for e, c in b.args} for b in basis]
    spline = []
    for i in intervals:
        piece = sum([c * d.get(i, S.Zero) for c, d in zip(coeff, basis_dicts)], S.Zero)
        spline.append((piece, i))
    return Piecewise(*spline)