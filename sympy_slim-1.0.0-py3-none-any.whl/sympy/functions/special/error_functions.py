from __future__ import annotations
from sympy.core import EulerGamma
from sympy.core.add import Add
from sympy.core.cache import cacheit
from sympy.core.function import DefinedFunction, ArgumentIndexError, expand_mul
from sympy.core.logic import fuzzy_or
from sympy.core.numbers import I, pi, Rational, Integer
from sympy.core.relational import is_eq
from sympy.core.power import Pow
from sympy.core.singleton import S
from sympy.core.symbol import Dummy, uniquely_named_symbol
from sympy.core.sympify import sympify
from sympy.functions.combinatorial.factorials import factorial, factorial2, RisingFactorial
from sympy.functions.elementary.complexes import polar_lift, re, unpolarify
from sympy.functions.elementary.integers import ceiling, floor
from sympy.functions.elementary.miscellaneous import sqrt, root
from sympy.functions.elementary.exponential import exp, log, exp_polar
from sympy.functions.elementary.hyperbolic import cosh, sinh
from sympy.functions.elementary.trigonometric import cos, sin, sinc
from sympy.functions.special.hyper import hyper, meijerg

def real_to_real_as_real_imag(self, deep=True, **hints):
    if self.args[0].is_extended_real:
        if deep:
            hints['complex'] = False
            return (self.expand(deep, **hints), S.Zero)
        else:
            return (self, S.Zero)
    if deep:
        x, y = self.args[0].expand(deep, **hints).as_real_imag()
    else:
        x, y = self.args[0].as_real_imag()
    re = (self.func(x + I * y) + self.func(x - I * y)) / 2
    im = (self.func(x + I * y) - self.func(x - I * y)) / (2 * I)
    return (re, im)

class erf(DefinedFunction):
    unbranched = True

    def fdiff(self, argindex=1):
        if argindex == 1:
            return 2 * exp(-self.args[0] ** 2) / sqrt(pi)
        else:
            raise ArgumentIndexError(self, argindex)

    def inverse(self, argindex=1):
        return erfinv

    @classmethod
    def eval(cls, arg):
        if arg.is_Number:
            if arg is S.NaN:
                return S.NaN
            elif arg is S.Infinity:
                return S.One
            elif arg is S.NegativeInfinity:
                return S.NegativeOne
            elif arg.is_zero:
                return S.Zero
        if isinstance(arg, erfinv):
            return arg.args[0]
        if isinstance(arg, erfcinv):
            return S.One - arg.args[0]
        if arg.is_zero:
            return S.Zero
        if isinstance(arg, erf2inv) and arg.args[0].is_zero:
            return arg.args[1]
        t = arg.extract_multiplicatively(I)
        if t in (S.Infinity, S.NegativeInfinity):
            return arg
        if arg.could_extract_minus_sign():
            return -cls(-arg)

    @staticmethod
    @cacheit
    def taylor_term(n, x, *previous_terms):
        if n < 0 or n % 2 == 0:
            return S.Zero
        else:
            x = sympify(x)
            k = floor((n - 1) / S(2))
            if len(previous_terms) > 2:
                return -previous_terms[-2] * x ** 2 * (n - 2) / (n * k)
            else:
                return 2 * S.NegativeOne ** k * x ** n / (n * factorial(k) * sqrt(pi))

    def _eval_conjugate(self):
        return self.func(self.args[0].conjugate())

    def _eval_is_real(self):
        if self.args[0].is_extended_real is True:
            return True

    def _eval_is_imaginary(self):
        if self.args[0].is_imaginary is True:
            return True

    def _eval_is_finite(self):
        z = self.args[0]
        return fuzzy_or([z.is_finite, z.is_extended_real])

    def _eval_is_zero(self):
        if self.args[0].is_extended_real is True:
            return self.args[0].is_zero

    def _eval_is_positive(self):
        if self.args[0].is_extended_real is True:
            return self.args[0].is_extended_positive

    def _eval_is_negative(self):
        if self.args[0].is_extended_real is True:
            return self.args[0].is_extended_negative

    def _eval_rewrite_as_uppergamma(self, z, **kwargs):
        from sympy.functions.special.gamma_functions import uppergamma
        return sqrt(z ** 2) / z * (S.One - uppergamma(S.Half, z ** 2) / sqrt(pi))

    def _eval_rewrite_as_fresnels(self, z, **kwargs):
        arg = (S.One - I) * z / sqrt(pi)
        return (S.One + I) * (fresnelc(arg) - I * fresnels(arg))

    def _eval_rewrite_as_fresnelc(self, z, **kwargs):
        arg = (S.One - I) * z / sqrt(pi)
        return (S.One + I) * (fresnelc(arg) - I * fresnels(arg))

    def _eval_rewrite_as_meijerg(self, z, **kwargs):
        return z / sqrt(pi) * meijerg([S.Half], [], [0], [Rational(-1, 2)], z ** 2)

    def _eval_rewrite_as_hyper(self, z, **kwargs):
        return 2 * z / sqrt(pi) * hyper([S.Half], [3 * S.Half], -z ** 2)

    def _eval_rewrite_as_expint(self, z, **kwargs):
        return sqrt(z ** 2) / z - z * expint(S.Half, z ** 2) / sqrt(pi)

    def _eval_rewrite_as_tractable(self, z, limitvar=None, **kwargs):
        from sympy.series.limits import limit
        if limitvar:
            lim = limit(z, limitvar, S.Infinity)
            if lim is S.NegativeInfinity:
                return S.NegativeOne + _erfs(-z) * exp(-z ** 2)
        return S.One - _erfs(z) * exp(-z ** 2)

    def _eval_rewrite_as_erfc(self, z, **kwargs):
        return S.One - erfc(z)

    def _eval_rewrite_as_erfi(self, z, **kwargs):
        return -I * erfi(I * z)

    def _eval_as_leading_term(self, x, logx, cdir):
        arg = self.args[0].as_leading_term(x, logx=logx, cdir=cdir)
        arg0 = arg.subs(x, 0)
        if arg0 is S.ComplexInfinity:
            arg0 = arg.limit(x, 0, dir='-' if cdir == -1 else '+')
        if x in arg.free_symbols and arg0.is_zero:
            return 2 * arg / sqrt(pi)
        else:
            return self.func(arg0)

    def _eval_aseries(self, n, args0, x, logx):
        from sympy.series.order import Order
        point = args0[0]
        if point in [S.Infinity, S.NegativeInfinity]:
            z = self.args[0]
            try:
                _, ex = z.leadterm(x)
            except (ValueError, NotImplementedError):
                return self
            ex = -ex
            if ex.is_positive:
                newn = ceiling(n / ex)
                s = [S.NegativeOne ** k * factorial2(2 * k - 1) / (z ** (2 * k + 1) * 2 ** k) for k in range(newn)] + [Order(1 / z ** newn, x)]
                return S.One - exp(-z ** 2) / sqrt(pi) * Add(*s)
        return super(erf, self)._eval_aseries(n, args0, x, logx)
    as_real_imag = real_to_real_as_real_imag

class erfc(DefinedFunction):
    unbranched = True

    def fdiff(self, argindex=1):
        if argindex == 1:
            return -2 * exp(-self.args[0] ** 2) / sqrt(pi)
        else:
            raise ArgumentIndexError(self, argindex)

    def inverse(self, argindex=1):
        return erfcinv

    @classmethod
    def eval(cls, arg):
        if arg.is_Number:
            if arg is S.NaN:
                return S.NaN
            elif arg is S.Infinity:
                return S.Zero
            elif arg.is_zero:
                return S.One
        if isinstance(arg, erfinv):
            return S.One - arg.args[0]
        if isinstance(arg, erfcinv):
            return arg.args[0]
        if arg.is_zero:
            return S.One
        t = arg.extract_multiplicatively(I)
        if t in (S.Infinity, S.NegativeInfinity):
            return -arg
        if arg.could_extract_minus_sign():
            return 2 - cls(-arg)

    @staticmethod
    @cacheit
    def taylor_term(n, x, *previous_terms):
        if n == 0:
            return S.One
        elif n < 0 or n % 2 == 0:
            return S.Zero
        else:
            x = sympify(x)
            k = floor((n - 1) / S(2))
            if len(previous_terms) > 2:
                return -previous_terms[-2] * x ** 2 * (n - 2) / (n * k)
            else:
                return -2 * S.NegativeOne ** k * x ** n / (n * factorial(k) * sqrt(pi))

    def _eval_conjugate(self):
        return self.func(self.args[0].conjugate())

    def _eval_is_real(self):
        if self.args[0].is_extended_real is True:
            return True
        if self.args[0].is_imaginary is True:
            return False

    def _eval_rewrite_as_tractable(self, z, limitvar=None, **kwargs):
        return self.rewrite(erf).rewrite('tractable', deep=True, limitvar=limitvar)

    def _eval_rewrite_as_erf(self, z, **kwargs):
        return S.One - erf(z)

    def _eval_rewrite_as_erfi(self, z, **kwargs):
        return S.One + I * erfi(I * z)

    def _eval_rewrite_as_fresnels(self, z, **kwargs):
        arg = (S.One - I) * z / sqrt(pi)
        return S.One - (S.One + I) * (fresnelc(arg) - I * fresnels(arg))

    def _eval_rewrite_as_fresnelc(self, z, **kwargs):
        arg = (S.One - I) * z / sqrt(pi)
        return S.One - (S.One + I) * (fresnelc(arg) - I * fresnels(arg))

    def _eval_rewrite_as_meijerg(self, z, **kwargs):
        return S.One - z / sqrt(pi) * meijerg([S.Half], [], [0], [Rational(-1, 2)], z ** 2)

    def _eval_rewrite_as_hyper(self, z, **kwargs):
        return S.One - 2 * z / sqrt(pi) * hyper([S.Half], [3 * S.Half], -z ** 2)

    def _eval_rewrite_as_uppergamma(self, z, **kwargs):
        from sympy.functions.special.gamma_functions import uppergamma
        return S.One - sqrt(z ** 2) / z * (S.One - uppergamma(S.Half, z ** 2) / sqrt(pi))

    def _eval_rewrite_as_expint(self, z, **kwargs):
        return S.One - sqrt(z ** 2) / z + z * expint(S.Half, z ** 2) / sqrt(pi)

    def _eval_expand_func(self, **hints):
        return self.rewrite(erf)

    def _eval_as_leading_term(self, x, logx, cdir):
        arg = self.args[0].as_leading_term(x, logx=logx, cdir=cdir)
        arg0 = arg.subs(x, 0)
        if arg0 is S.ComplexInfinity:
            arg0 = arg.limit(x, 0, dir='-' if cdir == -1 else '+')
        if arg0.is_zero:
            return S.One
        else:
            return self.func(arg0)
    as_real_imag = real_to_real_as_real_imag

    def _eval_aseries(self, n, args0, x, logx):
        return S.One - erf(*self.args)._eval_aseries(n, args0, x, logx)

class erfi(DefinedFunction):
    unbranched = True

    def fdiff(self, argindex=1):
        if argindex == 1:
            return 2 * exp(self.args[0] ** 2) / sqrt(pi)
        else:
            raise ArgumentIndexError(self, argindex)

    @classmethod
    def eval(cls, z):
        if z.is_Number:
            if z is S.NaN:
                return S.NaN
            elif z.is_zero:
                return S.Zero
            elif z is S.Infinity:
                return S.Infinity
        if z.is_zero:
            return S.Zero
        if z.could_extract_minus_sign():
            return -cls(-z)
        nz = z.extract_multiplicatively(I)
        if nz is not None:
            if nz is S.Infinity:
                return I
            if isinstance(nz, erfinv):
                return I * nz.args[0]
            if isinstance(nz, erfcinv):
                return I * (S.One - nz.args[0])
            if isinstance(nz, erf2inv) and nz.args[0].is_zero:
                return I * nz.args[1]

    @staticmethod
    @cacheit
    def taylor_term(n, x, *previous_terms):
        if n < 0 or n % 2 == 0:
            return S.Zero
        else:
            x = sympify(x)
            k = floor((n - 1) / S(2))
            if len(previous_terms) > 2:
                return previous_terms[-2] * x ** 2 * (n - 2) / (n * k)
            else:
                return 2 * x ** n / (n * factorial(k) * sqrt(pi))

    def _eval_conjugate(self):
        return self.func(self.args[0].conjugate())

    def _eval_is_extended_real(self):
        return self.args[0].is_extended_real

    def _eval_is_zero(self):
        return self.args[0].is_zero

    def _eval_rewrite_as_tractable(self, z, limitvar=None, **kwargs):
        return self.rewrite(erf).rewrite('tractable', deep=True, limitvar=limitvar)

    def _eval_rewrite_as_erf(self, z, **kwargs):
        return -I * erf(I * z)

    def _eval_rewrite_as_erfc(self, z, **kwargs):
        return I * erfc(I * z) - I

    def _eval_rewrite_as_fresnels(self, z, **kwargs):
        arg = (S.One + I) * z / sqrt(pi)
        return (S.One - I) * (fresnelc(arg) - I * fresnels(arg))

    def _eval_rewrite_as_fresnelc(self, z, **kwargs):
        arg = (S.One + I) * z / sqrt(pi)
        return (S.One - I) * (fresnelc(arg) - I * fresnels(arg))

    def _eval_rewrite_as_meijerg(self, z, **kwargs):
        return z / sqrt(pi) * meijerg([S.Half], [], [0], [Rational(-1, 2)], -z ** 2)

    def _eval_rewrite_as_hyper(self, z, **kwargs):
        return 2 * z / sqrt(pi) * hyper([S.Half], [3 * S.Half], z ** 2)

    def _eval_rewrite_as_uppergamma(self, z, **kwargs):
        from sympy.functions.special.gamma_functions import uppergamma
        return sqrt(-z ** 2) / z * (uppergamma(S.Half, -z ** 2) / sqrt(pi) - S.One)

    def _eval_rewrite_as_expint(self, z, **kwargs):
        return sqrt(-z ** 2) / z - z * expint(S.Half, -z ** 2) / sqrt(pi)

    def _eval_expand_func(self, **hints):
        return self.rewrite(erf)
    as_real_imag = real_to_real_as_real_imag

    def _eval_as_leading_term(self, x, logx, cdir):
        arg = self.args[0].as_leading_term(x, logx=logx, cdir=cdir)
        arg0 = arg.subs(x, 0)
        if x in arg.free_symbols and arg0.is_zero:
            return 2 * arg / sqrt(pi)
        elif arg0.is_finite:
            return self.func(arg0)
        return self.func(arg)

    def _eval_aseries(self, n, args0, x, logx):
        from sympy.series.order import Order
        point = args0[0]
        if point is S.Infinity:
            z = self.args[0]
            s = [factorial2(2 * k - 1) / (2 ** k * z ** (2 * k + 1)) for k in range(n)] + [Order(1 / z ** n, x)]
            return -I + exp(z ** 2) / sqrt(pi) * Add(*s)
        return super(erfi, self)._eval_aseries(n, args0, x, logx)

class erf2(DefinedFunction):

    def fdiff(self, argindex):
        x, y = self.args
        if argindex == 1:
            return -2 * exp(-x ** 2) / sqrt(pi)
        elif argindex == 2:
            return 2 * exp(-y ** 2) / sqrt(pi)
        else:
            raise ArgumentIndexError(self, argindex)

    @classmethod
    def eval(cls, x, y):
        chk = (S.Infinity, S.NegativeInfinity, S.Zero)
        if x is S.NaN or y is S.NaN:
            return S.NaN
        elif x == y:
            return S.Zero
        elif x in chk or y in chk:
            return erf(y) - erf(x)
        if isinstance(y, erf2inv) and y.args[0] == x:
            return y.args[1]
        if x.is_zero or y.is_zero or (x.is_extended_real and x.is_infinite) or (y.is_extended_real and y.is_infinite):
            return erf(y) - erf(x)
        sign_x = x.could_extract_minus_sign()
        sign_y = y.could_extract_minus_sign()
        if sign_x and sign_y:
            return -cls(-x, -y)
        elif sign_x or sign_y:
            return erf(y) - erf(x)

    def _eval_conjugate(self):
        return self.func(self.args[0].conjugate(), self.args[1].conjugate())

    def _eval_is_extended_real(self):
        return self.args[0].is_extended_real and self.args[1].is_extended_real

    def _eval_rewrite_as_erf(self, x, y, **kwargs):
        return erf(y) - erf(x)

    def _eval_rewrite_as_erfc(self, x, y, **kwargs):
        return erfc(x) - erfc(y)

    def _eval_rewrite_as_erfi(self, x, y, **kwargs):
        return I * (erfi(I * x) - erfi(I * y))

    def _eval_rewrite_as_fresnels(self, x, y, **kwargs):
        return erf(y).rewrite(fresnels) - erf(x).rewrite(fresnels)

    def _eval_rewrite_as_fresnelc(self, x, y, **kwargs):
        return erf(y).rewrite(fresnelc) - erf(x).rewrite(fresnelc)

    def _eval_rewrite_as_meijerg(self, x, y, **kwargs):
        return erf(y).rewrite(meijerg) - erf(x).rewrite(meijerg)

    def _eval_rewrite_as_hyper(self, x, y, **kwargs):
        return erf(y).rewrite(hyper) - erf(x).rewrite(hyper)

    def _eval_rewrite_as_uppergamma(self, x, y, **kwargs):
        from sympy.functions.special.gamma_functions import uppergamma
        return sqrt(y ** 2) / y * (S.One - uppergamma(S.Half, y ** 2) / sqrt(pi)) - sqrt(x ** 2) / x * (S.One - uppergamma(S.Half, x ** 2) / sqrt(pi))

    def _eval_rewrite_as_expint(self, x, y, **kwargs):
        return erf(y).rewrite(expint) - erf(x).rewrite(expint)

    def _eval_expand_func(self, **hints):
        return self.rewrite(erf)

    def _eval_is_zero(self):
        return is_eq(*self.args)

class erfinv(DefinedFunction):

    def fdiff(self, argindex=1):
        if argindex == 1:
            return sqrt(pi) * exp(self.func(self.args[0]) ** 2) * S.Half
        else:
            raise ArgumentIndexError(self, argindex)

    def inverse(self, argindex=1):
        return erf

    @classmethod
    def eval(cls, z):
        if z is S.NaN:
            return S.NaN
        elif z is S.NegativeOne:
            return S.NegativeInfinity
        elif z.is_zero:
            return S.Zero
        elif z is S.One:
            return S.Infinity
        if isinstance(z, erf) and z.args[0].is_extended_real:
            return z.args[0]
        if z.is_zero:
            return S.Zero
        nz = z.extract_multiplicatively(-1)
        if nz is not None and (isinstance(nz, erf) and nz.args[0].is_extended_real):
            return -nz.args[0]

    def _eval_rewrite_as_erfcinv(self, z, **kwargs):
        return erfcinv(1 - z)

    def _eval_is_zero(self):
        return self.args[0].is_zero

class erfcinv(DefinedFunction):

    def fdiff(self, argindex=1):
        if argindex == 1:
            return -sqrt(pi) * exp(self.func(self.args[0]) ** 2) * S.Half
        else:
            raise ArgumentIndexError(self, argindex)

    def inverse(self, argindex=1):
        return erfc

    @classmethod
    def eval(cls, z):
        if z is S.NaN:
            return S.NaN
        elif z.is_zero:
            return S.Infinity
        elif z is S.One:
            return S.Zero
        elif z == 2:
            return S.NegativeInfinity
        if z.is_zero:
            return S.Infinity

    def _eval_rewrite_as_erfinv(self, z, **kwargs):
        return erfinv(1 - z)

    def _eval_evalf(self, prec):
        return self.rewrite(erfinv)._eval_evalf(prec)

    def _eval_is_zero(self):
        return (self.args[0] - 1).is_zero

    def _eval_is_infinite(self):
        z = self.args[0]
        return fuzzy_or([z.is_zero, is_eq(z, Integer(2))])

class erf2inv(DefinedFunction):

    def fdiff(self, argindex):
        x, y = self.args
        if argindex == 1:
            return exp(self.func(x, y) ** 2 - x ** 2)
        elif argindex == 2:
            return sqrt(pi) * S.Half * exp(self.func(x, y) ** 2)
        else:
            raise ArgumentIndexError(self, argindex)

    @classmethod
    def eval(cls, x, y):
        if x is S.NaN or y is S.NaN:
            return S.NaN
        elif x.is_zero and y.is_zero:
            return S.Zero
        elif x.is_zero and y is S.One:
            return S.Infinity
        elif x is S.One and y.is_zero:
            return S.One
        elif x.is_zero:
            return erfinv(y)
        elif x is S.Infinity:
            return erfcinv(-y)
        elif y.is_zero:
            return x
        elif y is S.Infinity:
            return erfinv(x)
        if x.is_zero:
            if y.is_zero:
                return S.Zero
            else:
                return erfinv(y)
        if y.is_zero:
            return x

    def _eval_is_zero(self):
        x, y = self.args
        if x.is_zero and y.is_zero:
            return True

class Ei(DefinedFunction):

    @classmethod
    def eval(cls, z):
        if z.is_zero:
            return S.NegativeInfinity
        elif z is S.Infinity:
            return S.Infinity
        elif z is S.NegativeInfinity:
            return S.Zero
        if z.is_zero:
            return S.NegativeInfinity
        nz, n = z.extract_branch_factor()
        if n:
            return Ei(nz) + 2 * I * pi * n

    def fdiff(self, argindex=1):
        arg = unpolarify(self.args[0])
        if argindex == 1:
            return exp(arg) / arg
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_evalf(self, prec):
        if (self.args[0] / polar_lift(-1)).is_positive:
            return super()._eval_evalf(prec) + (I * pi)._eval_evalf(prec)
        return super()._eval_evalf(prec)

    def _eval_rewrite_as_uppergamma(self, z, **kwargs):
        from sympy.functions.special.gamma_functions import uppergamma
        return -uppergamma(0, polar_lift(-1) * z) - I * pi

    def _eval_rewrite_as_expint(self, z, **kwargs):
        return -expint(1, polar_lift(-1) * z) - I * pi

    def _eval_rewrite_as_li(self, z, **kwargs):
        if isinstance(z, log):
            return li(z.args[0])
        return li(exp(z))

    def _eval_rewrite_as_Si(self, z, **kwargs):
        if z.is_negative:
            return Shi(z) + Chi(z) - I * pi
        else:
            return Shi(z) + Chi(z)
    _eval_rewrite_as_Ci = _eval_rewrite_as_Si
    _eval_rewrite_as_Chi = _eval_rewrite_as_Si
    _eval_rewrite_as_Shi = _eval_rewrite_as_Si

    def _eval_rewrite_as_tractable(self, z, limitvar=None, **kwargs):
        return exp(z) * _eis(z)

    def _eval_rewrite_as_Integral(self, z, **kwargs):
        from sympy.integrals.integrals import Integral
        t = Dummy(uniquely_named_symbol('t', [z]).name)
        return Integral(S.Exp1 ** t / t, (t, S.NegativeInfinity, z))

    def _eval_as_leading_term(self, x, logx, cdir):
        from sympy import re
        x0 = self.args[0].limit(x, 0)
        arg = self.args[0].as_leading_term(x, cdir=cdir)
        cdir = arg.dir(x, cdir)
        if x0.is_zero:
            c, e = arg.as_coeff_exponent(x)
            logx = log(x) if logx is None else logx
            return log(c) + e * logx + EulerGamma - (I * pi if re(cdir).is_negative else S.Zero)
        return super()._eval_as_leading_term(x, logx=logx, cdir=cdir)

    def _eval_nseries(self, x, n, logx, cdir=0):
        x0 = self.args[0].limit(x, 0)
        if x0.is_zero:
            f = self._eval_rewrite_as_Si(*self.args)
            return f._eval_nseries(x, n, logx)
        return super()._eval_nseries(x, n, logx)

    def _eval_aseries(self, n, args0, x, logx):
        from sympy.series.order import Order
        point = args0[0]
        if point in (S.Infinity, S.NegativeInfinity):
            z = self.args[0]
            s = [factorial(k) / z ** k for k in range(n)] + [Order(1 / z ** n, x)]
            return exp(z) / z * Add(*s)
        return super(Ei, self)._eval_aseries(n, args0, x, logx)

class expint(DefinedFunction):

    @classmethod
    def eval(cls, nu, z):
        from sympy.functions.special.gamma_functions import gamma, uppergamma
        nu2 = unpolarify(nu)
        if nu != nu2:
            return expint(nu2, z)
        if nu.is_Integer and nu <= 0 or (not nu.is_Integer and (2 * nu).is_Integer):
            return unpolarify(expand_mul(z ** (nu - 1) * uppergamma(1 - nu, z)))
        z, n = z.extract_branch_factor()
        if n is S.Zero:
            return
        if nu.is_integer:
            if not nu > 0:
                return
            return expint(nu, z) - 2 * pi * I * n * S.NegativeOne ** (nu - 1) / factorial(nu - 1) * unpolarify(z) ** (nu - 1)
        else:
            return (exp(2 * I * pi * nu * n) - 1) * z ** (nu - 1) * gamma(1 - nu) + expint(nu, z)

    def fdiff(self, argindex):
        nu, z = self.args
        if argindex == 1:
            return -z ** (nu - 1) * meijerg([], [1, 1], [0, 0, 1 - nu], [], z)
        elif argindex == 2:
            return -expint(nu - 1, z)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_uppergamma(self, nu, z, **kwargs):
        from sympy.functions.special.gamma_functions import uppergamma
        return z ** (nu - 1) * uppergamma(1 - nu, z)

    def _eval_rewrite_as_Ei(self, nu, z, **kwargs):
        if nu == 1:
            return -Ei(z * exp_polar(-I * pi)) - I * pi
        elif nu.is_Integer and nu > 1:
            x = -unpolarify(z)
            return x ** (nu - 1) / factorial(nu - 1) * E1(z).rewrite(Ei) + exp(x) / factorial(nu - 1) * Add(*[factorial(nu - k - 2) * x ** k for k in range(nu - 1)])
        else:
            return self

    def _eval_expand_func(self, **hints):
        return self.rewrite(Ei).rewrite(expint, **hints)

    def _eval_rewrite_as_Si(self, nu, z, **kwargs):
        if nu != 1:
            return self
        return Shi(z) - Chi(z)
    _eval_rewrite_as_Ci = _eval_rewrite_as_Si
    _eval_rewrite_as_Chi = _eval_rewrite_as_Si
    _eval_rewrite_as_Shi = _eval_rewrite_as_Si

    def _eval_nseries(self, x, n, logx, cdir=0):
        if not self.args[0].has(x):
            nu = self.args[0]
            if nu == 1:
                f = self._eval_rewrite_as_Si(*self.args)
                return f._eval_nseries(x, n, logx)
            elif nu.is_Integer and nu > 1:
                f = self._eval_rewrite_as_Ei(*self.args)
                return f._eval_nseries(x, n, logx)
        return super()._eval_nseries(x, n, logx)

    def _eval_aseries(self, n, args0, x, logx):
        from sympy.series.order import Order
        point = args0[1]
        nu = self.args[0]
        if point is S.Infinity:
            z = self.args[1]
            s = [S.NegativeOne ** k * RisingFactorial(nu, k) / z ** k for k in range(n)] + [Order(1 / z ** n, x)]
            return exp(-z) / z * Add(*s)
        return super(expint, self)._eval_aseries(n, args0, x, logx)

    def _eval_rewrite_as_Integral(self, *args, **kwargs):
        from sympy.integrals.integrals import Integral
        n, x = self.args
        t = Dummy(uniquely_named_symbol('t', args).name)
        return Integral(t ** (-n) * exp(-t * x), (t, 1, S.Infinity))

def E1(z):
    return expint(1, z)

class li(DefinedFunction):

    @classmethod
    def eval(cls, z):
        if z.is_zero:
            return S.Zero
        elif z is S.One:
            return S.NegativeInfinity
        elif z is S.Infinity:
            return S.Infinity
        if z.is_zero:
            return S.Zero

    def fdiff(self, argindex=1):
        arg = self.args[0]
        if argindex == 1:
            return S.One / log(arg)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_conjugate(self):
        z = self.args[0]
        if not z.is_extended_negative:
            return self.func(z.conjugate())

    def _eval_rewrite_as_Li(self, z, **kwargs):
        return Li(z) + li(2)

    def _eval_rewrite_as_Ei(self, z, **kwargs):
        return Ei(log(z))

    def _eval_rewrite_as_uppergamma(self, z, **kwargs):
        from sympy.functions.special.gamma_functions import uppergamma
        return -uppergamma(0, -log(z)) + S.Half * (log(log(z)) - log(S.One / log(z))) - log(-log(z))

    def _eval_rewrite_as_Si(self, z, **kwargs):
        return Ci(I * log(z)) - I * Si(I * log(z)) - S.Half * (log(S.One / log(z)) - log(log(z))) - log(I * log(z))
    _eval_rewrite_as_Ci = _eval_rewrite_as_Si

    def _eval_rewrite_as_Shi(self, z, **kwargs):
        return Chi(log(z)) - Shi(log(z)) - S.Half * (log(S.One / log(z)) - log(log(z)))
    _eval_rewrite_as_Chi = _eval_rewrite_as_Shi

    def _eval_rewrite_as_hyper(self, z, **kwargs):
        return log(z) * hyper((1, 1), (2, 2), log(z)) + S.Half * (log(log(z)) - log(S.One / log(z))) + EulerGamma

    def _eval_rewrite_as_meijerg(self, z, **kwargs):
        return -log(-log(z)) - S.Half * (log(S.One / log(z)) - log(log(z))) - meijerg(((), (1,)), ((0, 0), ()), -log(z))

    def _eval_rewrite_as_tractable(self, z, limitvar=None, **kwargs):
        return z * _eis(log(z))

    def _eval_nseries(self, x, n, logx, cdir=0):
        z = self.args[0]
        s = [log(z) ** k / (factorial(k) * k) for k in range(1, n)]
        return EulerGamma + log(log(z)) + Add(*s)

    def _eval_is_zero(self):
        z = self.args[0]
        if z.is_zero:
            return True

class Li(DefinedFunction):

    @classmethod
    def eval(cls, z):
        if z is S.Infinity:
            return S.Infinity
        elif z == S(2):
            return S.Zero

    def fdiff(self, argindex=1):
        arg = self.args[0]
        if argindex == 1:
            return S.One / log(arg)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_evalf(self, prec):
        return self.rewrite(li)._eval_evalf(prec)

    def _eval_rewrite_as_li(self, z, **kwargs):
        return li(z) - li(2)

    def _eval_rewrite_as_tractable(self, z, limitvar=None, **kwargs):
        return self.rewrite(li).rewrite('tractable', deep=True)

    def _eval_nseries(self, x, n, logx, cdir=0):
        f = self._eval_rewrite_as_li(*self.args)
        return f._eval_nseries(x, n, logx)

class TrigonometricIntegral(DefinedFunction):

    @classmethod
    def eval(cls, z):
        if z is S.Zero:
            return cls._atzero
        elif z is S.Infinity:
            return cls._atinf()
        elif z is S.NegativeInfinity:
            return cls._atneginf()
        if z.is_zero:
            return cls._atzero
        nz = z.extract_multiplicatively(polar_lift(I))
        if nz is None and cls._trigfunc(0) == 0:
            nz = z.extract_multiplicatively(I)
        if nz is not None:
            return cls._Ifactor(nz, 1)
        nz = z.extract_multiplicatively(polar_lift(-I))
        if nz is not None:
            return cls._Ifactor(nz, -1)
        nz = z.extract_multiplicatively(polar_lift(-1))
        if nz is None and cls._trigfunc(0) == 0:
            nz = z.extract_multiplicatively(-1)
        if nz is not None:
            return cls._minusfactor(nz)
        nz, n = z.extract_branch_factor()
        if n == 0 and nz == z:
            return
        return 2 * pi * I * n * cls._trigfunc(0) + cls(nz)

    def fdiff(self, argindex=1):
        arg = unpolarify(self.args[0])
        if argindex == 1:
            return self._trigfunc(arg) / arg
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Ei(self, z, **kwargs):
        return self._eval_rewrite_as_expint(z).rewrite(Ei)

    def _eval_rewrite_as_uppergamma(self, z, **kwargs):
        from sympy.functions.special.gamma_functions import uppergamma
        return self._eval_rewrite_as_expint(z).rewrite(uppergamma)

    def _eval_nseries(self, x, n, logx, cdir=0):
        if self.args[0].subs(x, 0) != 0:
            return super()._eval_nseries(x, n, logx)
        baseseries = self._trigfunc(x)._eval_nseries(x, n, logx)
        if self._trigfunc(0) != 0:
            baseseries -= 1
        baseseries = baseseries.replace(Pow, lambda t, n: t ** n / n, simultaneous=False)
        if self._trigfunc(0) != 0:
            baseseries += EulerGamma + log(x)
        return baseseries.subs(x, self.args[0])._eval_nseries(x, n, logx)

class Si(TrigonometricIntegral):
    _trigfunc = sin
    _atzero = S.Zero

    @classmethod
    def _atinf(cls):
        return pi * S.Half

    @classmethod
    def _atneginf(cls):
        return -pi * S.Half

    @classmethod
    def _minusfactor(cls, z):
        return -Si(z)

    @classmethod
    def _Ifactor(cls, z, sign):
        return I * Shi(z) * sign

    def _eval_rewrite_as_expint(self, z, **kwargs):
        return pi / 2 + (E1(polar_lift(I) * z) - E1(polar_lift(-I) * z)) / 2 / I

    def _eval_rewrite_as_Integral(self, z, **kwargs):
        from sympy.integrals.integrals import Integral
        t = Dummy(uniquely_named_symbol('t', [z]).name)
        return Integral(sinc(t), (t, 0, z))
    _eval_rewrite_as_sinc = _eval_rewrite_as_Integral

    def _eval_as_leading_term(self, x, logx, cdir):
        arg = self.args[0].as_leading_term(x, logx=logx, cdir=cdir)
        arg0 = arg.subs(x, 0)
        if arg0 is S.NaN:
            arg0 = arg.limit(x, 0, dir='-' if re(cdir).is_negative else '+')
        if arg0.is_zero:
            return arg
        elif not arg0.is_infinite:
            return self.func(arg0)
        else:
            return self

    def _eval_aseries(self, n, args0, x, logx):
        from sympy.series.order import Order
        point = args0[0]
        if point is S.Infinity:
            z = self.args[0]
            p = [S.NegativeOne ** k * factorial(2 * k) / z ** (2 * k + 1) for k in range(n // 2 + 1)] + [Order(1 / z ** n, x)]
            q = [S.NegativeOne ** k * factorial(2 * k + 1) / z ** (2 * (k + 1)) for k in range(n // 2)] + [Order(1 / z ** n, x)]
            return pi / 2 - cos(z) * Add(*p) - sin(z) * Add(*q)
        return super(Si, self)._eval_aseries(n, args0, x, logx)

    def _eval_is_zero(self):
        z = self.args[0]
        if z.is_zero:
            return True

class Ci(TrigonometricIntegral):
    _trigfunc = cos
    _atzero = S.ComplexInfinity

    @classmethod
    def _atinf(cls):
        return S.Zero

    @classmethod
    def _atneginf(cls):
        return I * pi

    @classmethod
    def _minusfactor(cls, z):
        return Ci(z) + I * pi

    @classmethod
    def _Ifactor(cls, z, sign):
        return Chi(z) + I * pi / 2 * sign

    def _eval_rewrite_as_expint(self, z, **kwargs):
        return -(E1(polar_lift(I) * z) + E1(polar_lift(-I) * z)) / 2

    def _eval_rewrite_as_Integral(self, z, **kwargs):
        from sympy.integrals.integrals import Integral
        t = Dummy(uniquely_named_symbol('t', [z]).name)
        return S.EulerGamma + log(z) - Integral((1 - cos(t)) / t, (t, 0, z))

    def _eval_as_leading_term(self, x, logx, cdir):
        arg = self.args[0].as_leading_term(x, logx=logx, cdir=cdir)
        arg0 = arg.subs(x, 0)
        if arg0 is S.NaN:
            arg0 = arg.limit(x, 0, dir='-' if re(cdir).is_negative else '+')
        if arg0.is_zero:
            c, e = arg.as_coeff_exponent(x)
            logx = log(x) if logx is None else logx
            return log(c) + e * logx + EulerGamma
        elif arg0.is_finite:
            return self.func(arg0)
        else:
            return self

    def _eval_aseries(self, n, args0, x, logx):
        from sympy.series.order import Order
        point = args0[0]
        if point in (S.Infinity, S.NegativeInfinity):
            z = self.args[0]
            p = [S.NegativeOne ** k * factorial(2 * k) / z ** (2 * k + 1) for k in range(n // 2 + 1)] + [Order(1 / z ** n, x)]
            q = [S.NegativeOne ** k * factorial(2 * k + 1) / z ** (2 * (k + 1)) for k in range(n // 2)] + [Order(1 / z ** n, x)]
            result = sin(z) * Add(*p) - cos(z) * Add(*q)
            if point is S.NegativeInfinity:
                result += I * pi
            return result
        return super(Ci, self)._eval_aseries(n, args0, x, logx)

class Shi(TrigonometricIntegral):
    _trigfunc = sinh
    _atzero = S.Zero

    @classmethod
    def _atinf(cls):
        return S.Infinity

    @classmethod
    def _atneginf(cls):
        return S.NegativeInfinity

    @classmethod
    def _minusfactor(cls, z):
        return -Shi(z)

    @classmethod
    def _Ifactor(cls, z, sign):
        return I * Si(z) * sign

    def _eval_rewrite_as_expint(self, z, **kwargs):
        return (E1(z) - E1(exp_polar(I * pi) * z)) / 2 - I * pi / 2

    def _eval_is_zero(self):
        z = self.args[0]
        if z.is_zero:
            return True

    def _eval_as_leading_term(self, x, logx, cdir):
        arg = self.args[0].as_leading_term(x)
        arg0 = arg.subs(x, 0)
        if arg0 is S.NaN:
            arg0 = arg.limit(x, 0, dir='-' if re(cdir).is_negative else '+')
        if arg0.is_zero:
            return arg
        elif not arg0.is_infinite:
            return self.func(arg0)
        else:
            return self

class Chi(TrigonometricIntegral):
    _trigfunc = cosh
    _atzero = S.ComplexInfinity

    @classmethod
    def _atinf(cls):
        return S.Infinity

    @classmethod
    def _atneginf(cls):
        return S.Infinity

    @classmethod
    def _minusfactor(cls, z):
        return Chi(z) + I * pi

    @classmethod
    def _Ifactor(cls, z, sign):
        return Ci(z) + I * pi / 2 * sign

    def _eval_rewrite_as_expint(self, z, **kwargs):
        return -I * pi / 2 - (E1(z) + E1(exp_polar(I * pi) * z)) / 2

    def _eval_as_leading_term(self, x, logx, cdir):
        arg = self.args[0].as_leading_term(x, logx=logx, cdir=cdir)
        arg0 = arg.subs(x, 0)
        if arg0 is S.NaN:
            arg0 = arg.limit(x, 0, dir='-' if re(cdir).is_negative else '+')
        if arg0.is_zero:
            c, e = arg.as_coeff_exponent(x)
            logx = log(x) if logx is None else logx
            return log(c) + e * logx + EulerGamma
        elif arg0.is_finite:
            return self.func(arg0)
        else:
            return self

class FresnelIntegral(DefinedFunction):
    unbranched = True

    @classmethod
    def eval(cls, z):
        if z is S.Infinity:
            return S.Half
        if z.is_zero:
            return S.Zero
        prefact = S.One
        newarg = z
        changed = False
        nz = newarg.extract_multiplicatively(-1)
        if nz is not None:
            prefact = -prefact
            newarg = nz
            changed = True
        nz = newarg.extract_multiplicatively(I)
        if nz is not None:
            prefact = cls._sign * I * prefact
            newarg = nz
            changed = True
        if changed:
            return prefact * cls(newarg)

    def fdiff(self, argindex=1):
        if argindex == 1:
            return self._trigfunc(S.Half * pi * self.args[0] ** 2)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_is_extended_real(self):
        return self.args[0].is_extended_real
    _eval_is_finite = _eval_is_extended_real

    def _eval_is_zero(self):
        return self.args[0].is_zero

    def _eval_conjugate(self):
        return self.func(self.args[0].conjugate())
    as_real_imag = real_to_real_as_real_imag

class fresnels(FresnelIntegral):
    _trigfunc = sin
    _sign = -S.One

    @staticmethod
    @cacheit
    def taylor_term(n, x, *previous_terms):
        if n < 0:
            return S.Zero
        else:
            x = sympify(x)
            if len(previous_terms) > 1:
                p = previous_terms[-1]
                return -pi ** 2 * x ** 4 * (4 * n - 1) / (8 * n * (2 * n + 1) * (4 * n + 3)) * p
            else:
                return x ** 3 * (-x ** 4) ** n * (S(2) ** (-2 * n - 1) * pi ** (2 * n + 1)) / ((4 * n + 3) * factorial(2 * n + 1))

    def _eval_rewrite_as_erf(self, z, **kwargs):
        return (S.One + I) / 4 * (erf((S.One + I) / 2 * sqrt(pi) * z) - I * erf((S.One - I) / 2 * sqrt(pi) * z))

    def _eval_rewrite_as_hyper(self, z, **kwargs):
        return pi * z ** 3 / 6 * hyper([Rational(3, 4)], [Rational(3, 2), Rational(7, 4)], -pi ** 2 * z ** 4 / 16)

    def _eval_rewrite_as_meijerg(self, z, **kwargs):
        return pi * z ** Rational(9, 4) / (sqrt(2) * (z ** 2) ** Rational(3, 4) * (-z) ** Rational(3, 4)) * meijerg([], [1], [Rational(3, 4)], [Rational(1, 4), 0], -pi ** 2 * z ** 4 / 16)

    def _eval_rewrite_as_Integral(self, z, **kwargs):
        from sympy.integrals.integrals import Integral
        t = Dummy(uniquely_named_symbol('t', [z]).name)
        return Integral(sin(pi * t ** 2 / 2), (t, 0, z))

    def _eval_as_leading_term(self, x, logx, cdir):
        from sympy.series.order import Order
        arg = self.args[0].as_leading_term(x, logx=logx, cdir=cdir)
        arg0 = arg.subs(x, 0)
        if arg0 is S.ComplexInfinity:
            arg0 = arg.limit(x, 0, dir='-' if re(cdir).is_negative else '+')
        if arg0.is_zero:
            return pi * arg ** 3 / 6
        elif arg0 in [S.Infinity, S.NegativeInfinity]:
            s = 1 if arg0 is S.Infinity else -1
            return s * S.Half + Order(x, x)
        else:
            return self.func(arg0)

    def _eval_aseries(self, n, args0, x, logx):
        from sympy.series.order import Order
        point = args0[0]
        if point in [S.Infinity, -S.Infinity]:
            z = self.args[0]
            p = [S.NegativeOne ** k * factorial(4 * k + 1) / (2 ** (2 * k + 2) * z ** (4 * k + 3) * 2 ** (2 * k) * factorial(2 * k)) for k in range(0, n) if 4 * k + 3 < n]
            q = [1 / (2 * z)] + [S.NegativeOne ** k * factorial(4 * k - 1) / (2 ** (2 * k + 1) * z ** (4 * k + 1) * 2 ** (2 * k - 1) * factorial(2 * k - 1)) for k in range(1, n) if 4 * k + 1 < n]
            p = [-sqrt(2 / pi) * t for t in p]
            q = [-sqrt(2 / pi) * t for t in q]
            s = 1 if point is S.Infinity else -1
            return s * S.Half + (sin(z ** 2) * Add(*p) + cos(z ** 2) * Add(*q)).subs(x, sqrt(2 / pi) * x) + Order(1 / z ** n, x)
        return super()._eval_aseries(n, args0, x, logx)

class fresnelc(FresnelIntegral):
    _trigfunc = cos
    _sign = S.One

    @staticmethod
    @cacheit
    def taylor_term(n, x, *previous_terms):
        if n < 0:
            return S.Zero
        else:
            x = sympify(x)
            if len(previous_terms) > 1:
                p = previous_terms[-1]
                return -pi ** 2 * x ** 4 * (4 * n - 3) / (8 * n * (2 * n - 1) * (4 * n + 1)) * p
            else:
                return x * (-x ** 4) ** n * (S(2) ** (-2 * n) * pi ** (2 * n)) / ((4 * n + 1) * factorial(2 * n))

    def _eval_rewrite_as_erf(self, z, **kwargs):
        return (S.One - I) / 4 * (erf((S.One + I) / 2 * sqrt(pi) * z) + I * erf((S.One - I) / 2 * sqrt(pi) * z))

    def _eval_rewrite_as_hyper(self, z, **kwargs):
        return z * hyper([Rational(1, 4)], [S.Half, Rational(5, 4)], -pi ** 2 * z ** 4 / 16)

    def _eval_rewrite_as_meijerg(self, z, **kwargs):
        return pi * z ** Rational(3, 4) / (sqrt(2) * root(z ** 2, 4) * root(-z, 4)) * meijerg([], [1], [Rational(1, 4)], [Rational(3, 4), 0], -pi ** 2 * z ** 4 / 16)

    def _eval_rewrite_as_Integral(self, z, **kwargs):
        from sympy.integrals.integrals import Integral
        t = Dummy(uniquely_named_symbol('t', [z]).name)
        return Integral(cos(pi * t ** 2 / 2), (t, 0, z))

    def _eval_as_leading_term(self, x, logx, cdir):
        from sympy.series.order import Order
        arg = self.args[0].as_leading_term(x, logx=logx, cdir=cdir)
        arg0 = arg.subs(x, 0)
        if arg0 is S.ComplexInfinity:
            arg0 = arg.limit(x, 0, dir='-' if re(cdir).is_negative else '+')
        if arg0.is_zero:
            return arg
        elif arg0 in [S.Infinity, S.NegativeInfinity]:
            s = 1 if arg0 is S.Infinity else -1
            return s * S.Half + Order(x, x)
        else:
            return self.func(arg0)

    def _eval_aseries(self, n, args0, x, logx):
        from sympy.series.order import Order
        point = args0[0]
        if point in [S.Infinity, -S.Infinity]:
            z = self.args[0]
            p = [S.NegativeOne ** k * factorial(4 * k + 1) / (2 ** (2 * k + 2) * z ** (4 * k + 3) * 2 ** (2 * k) * factorial(2 * k)) for k in range(n) if 4 * k + 3 < n]
            q = [1 / (2 * z)] + [S.NegativeOne ** k * factorial(4 * k - 1) / (2 ** (2 * k + 1) * z ** (4 * k + 1) * 2 ** (2 * k - 1) * factorial(2 * k - 1)) for k in range(1, n) if 4 * k + 1 < n]
            p = [-sqrt(2 / pi) * t for t in p]
            q = [sqrt(2 / pi) * t for t in q]
            s = 1 if point is S.Infinity else -1
            return s * S.Half + (cos(z ** 2) * Add(*p) + sin(z ** 2) * Add(*q)).subs(x, sqrt(2 / pi) * x) + Order(1 / z ** n, x)
        return super()._eval_aseries(n, args0, x, logx)

class _erfs(DefinedFunction):

    @classmethod
    def eval(cls, arg):
        if arg.is_zero:
            return S.One

    def _eval_aseries(self, n, args0, x, logx):
        from sympy.series.order import Order
        point = args0[0]
        if point is S.Infinity:
            z = self.args[0]
            l = [1 / sqrt(pi) * factorial(2 * k) * (-S(4)) ** (-k) / factorial(k) * (1 / z) ** (2 * k + 1) for k in range(n)]
            o = Order(1 / z ** (2 * n + 1), x)
            return Add(*l)._eval_nseries(x, n, logx) + o
        t = point.extract_multiplicatively(I)
        if t is S.Infinity:
            z = self.args[0]
            l = [1 / sqrt(pi) * factorial(2 * k) * (-S(4)) ** (-k) / factorial(k) * (1 / z) ** (2 * k + 1) for k in range(n)]
            o = Order(1 / z ** (2 * n + 1), x)
            return Add(*l)._eval_nseries(x, n, logx) + o
        return super()._eval_aseries(n, args0, x, logx)

    def fdiff(self, argindex=1):
        if argindex == 1:
            z = self.args[0]
            return -2 / sqrt(pi) + 2 * z * _erfs(z)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_intractable(self, z, **kwargs):
        return (S.One - erf(z)) * exp(z ** 2)

class _eis(DefinedFunction):

    def _eval_aseries(self, n, args0, x, logx):
        from sympy.series.order import Order
        if args0[0] not in (S.Infinity, S.NegativeInfinity):
            return super()._eval_aseries(n, args0, x, logx)
        z = self.args[0]
        l = [factorial(k) * (1 / z) ** (k + 1) for k in range(n)]
        o = Order(1 / z ** (n + 1), x)
        return Add(*l)._eval_nseries(x, n, logx) + o

    def fdiff(self, argindex=1):
        if argindex == 1:
            z = self.args[0]
            return S.One / z - _eis(z)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_intractable(self, z, **kwargs):
        return exp(-z) * Ei(z)

    def _eval_as_leading_term(self, x, logx, cdir):
        x0 = self.args[0].limit(x, 0)
        if x0.is_zero:
            f = self._eval_rewrite_as_intractable(*self.args)
            return f._eval_as_leading_term(x, logx=logx, cdir=cdir)
        return super()._eval_as_leading_term(x, logx=logx, cdir=cdir)

    def _eval_nseries(self, x, n, logx, cdir=0):
        x0 = self.args[0].limit(x, 0)
        if x0.is_zero:
            f = self._eval_rewrite_as_intractable(*self.args)
            return f._eval_nseries(x, n, logx)
        return super()._eval_nseries(x, n, logx)