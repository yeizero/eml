from __future__ import annotations
from sympy.core.expr import Expr
from sympy.core.function import DefinedFunction, ArgumentIndexError
from sympy.core.numbers import I, pi
from sympy.core.singleton import S
from sympy.core.symbol import Dummy
from sympy.functions import assoc_legendre
from sympy.functions.combinatorial.factorials import factorial
from sympy.functions.elementary.complexes import Abs, conjugate
from sympy.functions.elementary.exponential import exp
from sympy.functions.elementary.miscellaneous import sqrt
from sympy.functions.elementary.trigonometric import sin, cos, cot
from sympy.external.mpmath import local_workprec
_x = Dummy('x')

class Ynm(DefinedFunction):

    @classmethod
    def eval(cls, n, m, theta, phi):
        if m.could_extract_minus_sign():
            m = -m
            return S.NegativeOne ** m * exp(-2 * I * m * phi) * Ynm(n, m, theta, phi)
        if theta.could_extract_minus_sign():
            theta = -theta
            return Ynm(n, m, theta, phi)
        if phi.could_extract_minus_sign():
            phi = -phi
            return exp(-2 * I * m * phi) * Ynm(n, m, theta, phi)

    def _eval_expand_func(self, **hints):
        n, m, theta, phi = self.args
        rv = sqrt((2 * n + 1) / (4 * pi) * factorial(n - m) / factorial(n + m)) * exp(I * m * phi) * assoc_legendre(n, m, cos(theta))
        return rv.subs(sqrt(-cos(theta) ** 2 + 1), sin(theta))

    def fdiff(self, argindex=4):
        if argindex == 1:
            raise ArgumentIndexError(self, argindex)
        elif argindex == 2:
            raise ArgumentIndexError(self, argindex)
        elif argindex == 3:
            n, m, theta, phi = self.args
            return m * cot(theta) * Ynm(n, m, theta, phi) + sqrt((n - m) * (n + m + 1)) * exp(-I * phi) * Ynm(n, m + 1, theta, phi)
        elif argindex == 4:
            n, m, theta, phi = self.args
            return I * m * Ynm(n, m, theta, phi)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_polynomial(self, n, m, theta, phi, **kwargs):
        return self.expand(func=True)

    def _eval_rewrite_as_sin(self, n, m, theta, phi, **kwargs):
        return self.rewrite(cos)

    def _eval_rewrite_as_cos(self, n, m, theta, phi, **kwargs):
        from sympy.simplify import simplify, trigsimp
        term = simplify(self.expand(func=True))
        term = term.xreplace({Abs(sin(theta)): sin(theta)})
        return simplify(trigsimp(term))

    def _eval_conjugate(self):
        n, m, theta, phi = self.args
        return S.NegativeOne ** m * self.func(n, -m, theta, phi)

    def as_real_imag(self, deep=True, **hints):
        n, m, theta, phi = self.args
        re = sqrt((2 * n + 1) / (4 * pi) * factorial(n - m) / factorial(n + m)) * cos(m * phi) * assoc_legendre(n, m, cos(theta))
        im = sqrt((2 * n + 1) / (4 * pi) * factorial(n - m) / factorial(n + m)) * sin(m * phi) * assoc_legendre(n, m, cos(theta))
        return (re, im)

    def _eval_evalf(self, prec):
        n = self.args[0]._to_mpmath(prec)
        m = self.args[1]._to_mpmath(prec)
        theta = self.args[2]._to_mpmath(prec)
        phi = self.args[3]._to_mpmath(prec)
        with local_workprec(prec) as ctx:
            res = ctx.spherharm(n, m, theta, phi)
        return Expr._from_mpmath(res, prec)

def Ynm_c(n, m, theta, phi):
    return conjugate(Ynm(n, m, theta, phi))

class Znm(DefinedFunction):

    @classmethod
    def eval(cls, n, m, theta, phi):
        if m.is_positive:
            zz = (Ynm(n, m, theta, phi) + Ynm_c(n, m, theta, phi)) / sqrt(2)
            return zz
        elif m.is_zero:
            return Ynm(n, m, theta, phi)
        elif m.is_negative:
            zz = (Ynm(n, m, theta, phi) - Ynm_c(n, m, theta, phi)) / (sqrt(2) * I)
            return zz