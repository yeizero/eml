from __future__ import annotations
from sympy.core import Rational
from sympy.core.function import DefinedFunction, ArgumentIndexError
from sympy.core.singleton import S
from sympy.core.symbol import Dummy
from sympy.functions.combinatorial.factorials import binomial, factorial, RisingFactorial
from sympy.functions.elementary.complexes import re
from sympy.functions.elementary.exponential import exp
from sympy.functions.elementary.integers import floor
from sympy.functions.elementary.miscellaneous import sqrt
from sympy.functions.elementary.trigonometric import cos, sec
from sympy.functions.special.gamma_functions import gamma
from sympy.functions.special.hyper import hyper
from sympy.polys.orthopolys import chebyshevt_poly, chebyshevu_poly, gegenbauer_poly, hermite_poly, hermite_prob_poly, jacobi_poly, laguerre_poly, legendre_poly
_x = Dummy('x')

class OrthogonalPolynomial(DefinedFunction):

    @classmethod
    def _eval_at_order(cls, n, x):
        if n.is_integer and n >= 0:
            return cls._ortho_poly(int(n), _x).subs(_x, x)

    def _eval_conjugate(self):
        return self.func(self.args[0], self.args[1].conjugate())

class jacobi(OrthogonalPolynomial):

    @classmethod
    def eval(cls, n, a, b, x):
        if a == b:
            if a == Rational(-1, 2):
                return RisingFactorial(S.Half, n) / factorial(n) * chebyshevt(n, x)
            elif a.is_zero:
                return legendre(n, x)
            elif a == S.Half:
                return RisingFactorial(3 * S.Half, n) / factorial(n + 1) * chebyshevu(n, x)
            else:
                return RisingFactorial(a + 1, n) / RisingFactorial(2 * a + 1, n) * gegenbauer(n, a + S.Half, x)
        elif b == -a:
            return gamma(n + a + 1) / gamma(n + 1) * (1 + x) ** (a / 2) / (1 - x) ** (a / 2) * assoc_legendre(n, -a, x)
        if not n.is_Number:
            if x.could_extract_minus_sign():
                return S.NegativeOne ** n * jacobi(n, b, a, -x)
            if x.is_zero:
                return 2 ** (-n) * gamma(a + n + 1) / (gamma(a + 1) * factorial(n)) * hyper([-b - n, -n], [a + 1], -1)
            if x == S.One:
                return RisingFactorial(a + 1, n) / factorial(n)
            elif x is S.Infinity:
                if n.is_positive:
                    if (a + b + 2 * n).is_integer:
                        raise ValueError('Error. a + b + 2*n should not be an integer.')
                    return RisingFactorial(a + b + n + 1, n) * S.Infinity
        else:
            return jacobi_poly(n, a, b, x)

    def fdiff(self, argindex=4):
        from sympy.concrete.summations import Sum
        if argindex == 1:
            raise ArgumentIndexError(self, argindex)
        elif argindex == 2:
            n, a, b, x = self.args
            k = Dummy('k')
            f1 = 1 / (a + b + n + k + 1)
            f2 = (a + b + 2 * k + 1) * RisingFactorial(b + k + 1, n - k) / ((n - k) * RisingFactorial(a + b + k + 1, n - k))
            return Sum(f1 * (jacobi(n, a, b, x) + f2 * jacobi(k, a, b, x)), (k, 0, n - 1))
        elif argindex == 3:
            n, a, b, x = self.args
            k = Dummy('k')
            f1 = 1 / (a + b + n + k + 1)
            f2 = (-1) ** (n - k) * ((a + b + 2 * k + 1) * RisingFactorial(a + k + 1, n - k) / ((n - k) * RisingFactorial(a + b + k + 1, n - k)))
            return Sum(f1 * (jacobi(n, a, b, x) + f2 * jacobi(k, a, b, x)), (k, 0, n - 1))
        elif argindex == 4:
            n, a, b, x = self.args
            return S.Half * (a + b + n + 1) * jacobi(n - 1, a + 1, b + 1, x)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Sum(self, n, a, b, x, **kwargs):
        from sympy.concrete.summations import Sum
        if n.is_negative or n.is_integer is False:
            raise ValueError('Error: n should be a non-negative integer.')
        k = Dummy('k')
        kern = RisingFactorial(-n, k) * RisingFactorial(a + b + n + 1, k) * RisingFactorial(a + k + 1, n - k) / factorial(k) * ((1 - x) / 2) ** k
        return 1 / factorial(n) * Sum(kern, (k, 0, n))

    def _eval_rewrite_as_polynomial(self, n, a, b, x, **kwargs):
        return self._eval_rewrite_as_Sum(n, a, b, x, **kwargs)

    def _eval_conjugate(self):
        n, a, b, x = self.args
        return self.func(n, a.conjugate(), b.conjugate(), x.conjugate())

def jacobi_normalized(n, a, b, x):
    nfactor = S(2) ** (a + b + 1) * (gamma(n + a + 1) * gamma(n + b + 1)) / (2 * n + a + b + 1) / (factorial(n) * gamma(n + a + b + 1))
    return jacobi(n, a, b, x) / sqrt(nfactor)

class gegenbauer(OrthogonalPolynomial):

    @classmethod
    def eval(cls, n, a, x):
        if n.is_negative:
            return S.Zero
        if a == S.Half:
            return legendre(n, x)
        elif a == S.One:
            return chebyshevu(n, x)
        elif a == S.NegativeOne:
            return S.Zero
        if not n.is_Number:
            if x == S.NegativeOne:
                if (re(a) > S.Half) == True:
                    return S.ComplexInfinity
                else:
                    return cos(S.Pi * (a + n)) * sec(S.Pi * a) * gamma(2 * a + n) / (gamma(2 * a) * gamma(n + 1))
            if x.could_extract_minus_sign():
                return S.NegativeOne ** n * gegenbauer(n, a, -x)
            if x.is_zero:
                return 2 ** n * sqrt(S.Pi) * gamma(a + S.Half * n) / (gamma((1 - n) / 2) * gamma(n + 1) * gamma(a))
            if x == S.One:
                return gamma(2 * a + n) / (gamma(2 * a) * gamma(n + 1))
            elif x is S.Infinity:
                if n.is_positive:
                    return RisingFactorial(a, n) * S.Infinity
        else:
            return gegenbauer_poly(n, a, x)

    def fdiff(self, argindex=3):
        from sympy.concrete.summations import Sum
        if argindex == 1:
            raise ArgumentIndexError(self, argindex)
        elif argindex == 2:
            n, a, x = self.args
            k = Dummy('k')
            factor1 = 2 * (1 + (-1) ** (n - k)) * (k + a) / ((k + n + 2 * a) * (n - k))
            factor2 = 2 * (k + 1) / ((k + 2 * a) * (2 * k + 2 * a + 1)) + 2 / (k + n + 2 * a)
            kern = factor1 * gegenbauer(k, a, x) + factor2 * gegenbauer(n, a, x)
            return Sum(kern, (k, 0, n - 1))
        elif argindex == 3:
            n, a, x = self.args
            return 2 * a * gegenbauer(n - 1, a + 1, x)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Sum(self, n, a, x, **kwargs):
        from sympy.concrete.summations import Sum
        k = Dummy('k')
        kern = (-1) ** k * RisingFactorial(a, n - k) * (2 * x) ** (n - 2 * k) / (factorial(k) * factorial(n - 2 * k))
        return Sum(kern, (k, 0, floor(n / 2)))

    def _eval_rewrite_as_polynomial(self, n, a, x, **kwargs):
        return self._eval_rewrite_as_Sum(n, a, x, **kwargs)

    def _eval_conjugate(self):
        n, a, x = self.args
        return self.func(n, a.conjugate(), x.conjugate())

class chebyshevt(OrthogonalPolynomial):
    _ortho_poly = staticmethod(chebyshevt_poly)

    @classmethod
    def eval(cls, n, x):
        if not n.is_Number:
            if x.could_extract_minus_sign():
                return S.NegativeOne ** n * chebyshevt(n, -x)
            if n.could_extract_minus_sign():
                return chebyshevt(-n, x)
            if x.is_zero:
                return cos(S.Half * S.Pi * n)
            if x == S.One:
                return S.One
            elif x is S.Infinity:
                return S.Infinity
        elif n.is_negative:
            return cls._eval_at_order(-n, x)
        else:
            return cls._eval_at_order(n, x)

    def fdiff(self, argindex=2):
        if argindex == 1:
            raise ArgumentIndexError(self, argindex)
        elif argindex == 2:
            n, x = self.args
            return n * chebyshevu(n - 1, x)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Sum(self, n, x, **kwargs):
        from sympy.concrete.summations import Sum
        k = Dummy('k')
        kern = binomial(n, 2 * k) * (x ** 2 - 1) ** k * x ** (n - 2 * k)
        return Sum(kern, (k, 0, floor(n / 2)))

    def _eval_rewrite_as_polynomial(self, n, x, **kwargs):
        return self._eval_rewrite_as_Sum(n, x, **kwargs)

class chebyshevu(OrthogonalPolynomial):
    _ortho_poly = staticmethod(chebyshevu_poly)

    @classmethod
    def eval(cls, n, x):
        if not n.is_Number:
            if x.could_extract_minus_sign():
                return S.NegativeOne ** n * chebyshevu(n, -x)
            if n.could_extract_minus_sign():
                if n == S.NegativeOne:
                    return S.Zero
                elif not (-n - 2).could_extract_minus_sign():
                    return -chebyshevu(-n - 2, x)
            if x.is_zero:
                return cos(S.Half * S.Pi * n)
            if x == S.One:
                return S.One + n
            elif x is S.Infinity:
                return S.Infinity
        elif n.is_negative:
            if n == S.NegativeOne:
                return S.Zero
            else:
                return -cls._eval_at_order(-n - 2, x)
        else:
            return cls._eval_at_order(n, x)

    def fdiff(self, argindex=2):
        if argindex == 1:
            raise ArgumentIndexError(self, argindex)
        elif argindex == 2:
            n, x = self.args
            return ((n + 1) * chebyshevt(n + 1, x) - x * chebyshevu(n, x)) / (x ** 2 - 1)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Sum(self, n, x, **kwargs):
        from sympy.concrete.summations import Sum
        k = Dummy('k')
        kern = S.NegativeOne ** k * factorial(n - k) * (2 * x) ** (n - 2 * k) / (factorial(k) * factorial(n - 2 * k))
        return Sum(kern, (k, 0, floor(n / 2)))

    def _eval_rewrite_as_polynomial(self, n, x, **kwargs):
        return self._eval_rewrite_as_Sum(n, x, **kwargs)

class chebyshevt_root(DefinedFunction):

    @classmethod
    def eval(cls, n, k):
        if not (0 <= k and k < n):
            raise ValueError('must have 0 <= k < n, got k = %s and n = %s' % (k, n))
        return cos(S.Pi * (2 * k + 1) / (2 * n))

class chebyshevu_root(DefinedFunction):

    @classmethod
    def eval(cls, n, k):
        if not (0 <= k and k < n):
            raise ValueError('must have 0 <= k < n, got k = %s and n = %s' % (k, n))
        return cos(S.Pi * (k + 1) / (n + 1))

class legendre(OrthogonalPolynomial):
    _ortho_poly = staticmethod(legendre_poly)

    @classmethod
    def eval(cls, n, x):
        if not n.is_Number:
            if x.could_extract_minus_sign():
                return S.NegativeOne ** n * legendre(n, -x)
            if n.could_extract_minus_sign() and (not (-n - 1).could_extract_minus_sign()):
                return legendre(-n - S.One, x)
            if x.is_zero:
                return sqrt(S.Pi) / (gamma(S.Half - n / 2) * gamma(S.One + n / 2))
            elif x == S.One:
                return S.One
            elif x is S.Infinity:
                return S.Infinity
        else:
            if n.is_negative:
                n = -n - S.One
            return cls._eval_at_order(n, x)

    def fdiff(self, argindex=2):
        if argindex == 1:
            raise ArgumentIndexError(self, argindex)
        elif argindex == 2:
            n, x = self.args
            return n / (x ** 2 - 1) * (x * legendre(n, x) - legendre(n - 1, x))
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Sum(self, n, x, **kwargs):
        from sympy.concrete.summations import Sum
        k = Dummy('k')
        kern = S.NegativeOne ** k * binomial(n, k) ** 2 * ((1 + x) / 2) ** (n - k) * ((1 - x) / 2) ** k
        return Sum(kern, (k, 0, n))

    def _eval_rewrite_as_polynomial(self, n, x, **kwargs):
        return self._eval_rewrite_as_Sum(n, x, **kwargs)

class assoc_legendre(DefinedFunction):

    @classmethod
    def _eval_at_order(cls, n, m):
        P = legendre_poly(n, _x, polys=True).diff((_x, m))
        return S.NegativeOne ** m * (1 - _x ** 2) ** Rational(m, 2) * P.as_expr()

    @classmethod
    def eval(cls, n, m, x):
        if m.could_extract_minus_sign():
            return S.NegativeOne ** (-m) * (factorial(m + n) / factorial(n - m)) * assoc_legendre(n, -m, x)
        if m == 0:
            return legendre(n, x)
        if x == 0:
            return 2 ** m * sqrt(S.Pi) / (gamma((1 - m - n) / 2) * gamma(1 - (m - n) / 2))
        if n.is_Number and m.is_Number and n.is_integer and m.is_integer:
            if n.is_negative:
                raise ValueError('%s : 1st index must be nonnegative integer (got %r)' % (cls, n))
            if abs(m) > n:
                raise ValueError("%s : abs('2nd index') must be <= '1st index' (got %r, %r)" % (cls, n, m))
            return cls._eval_at_order(int(n), abs(int(m))).subs(_x, x)

    def fdiff(self, argindex=3):
        if argindex == 1:
            raise ArgumentIndexError(self, argindex)
        elif argindex == 2:
            raise ArgumentIndexError(self, argindex)
        elif argindex == 3:
            n, m, x = self.args
            return 1 / (x ** 2 - 1) * (x * n * assoc_legendre(n, m, x) - (m + n) * assoc_legendre(n - 1, m, x))
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Sum(self, n, m, x, **kwargs):
        from sympy.concrete.summations import Sum
        k = Dummy('k')
        kern = factorial(2 * n - 2 * k) / (2 ** n * factorial(n - k) * factorial(k) * factorial(n - 2 * k - m)) * S.NegativeOne ** k * x ** (n - m - 2 * k)
        return (1 - x ** 2) ** (m / 2) * Sum(kern, (k, 0, floor((n - m) * S.Half)))

    def _eval_rewrite_as_polynomial(self, n, m, x, **kwargs):
        return self._eval_rewrite_as_Sum(n, m, x, **kwargs)

    def _eval_conjugate(self):
        n, m, x = self.args
        return self.func(n, m.conjugate(), x.conjugate())

class hermite(OrthogonalPolynomial):
    _ortho_poly = staticmethod(hermite_poly)

    @classmethod
    def eval(cls, n, x):
        if not n.is_Number:
            if x.could_extract_minus_sign():
                return S.NegativeOne ** n * hermite(n, -x)
            if x.is_zero:
                return 2 ** n * sqrt(S.Pi) / gamma((S.One - n) / 2)
            elif x is S.Infinity:
                return S.Infinity
        elif n.is_negative:
            raise ValueError('The index n must be nonnegative integer (got %r)' % n)
        else:
            return cls._eval_at_order(n, x)

    def fdiff(self, argindex=2):
        if argindex == 1:
            raise ArgumentIndexError(self, argindex)
        elif argindex == 2:
            n, x = self.args
            return 2 * n * hermite(n - 1, x)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Sum(self, n, x, **kwargs):
        from sympy.concrete.summations import Sum
        k = Dummy('k')
        kern = S.NegativeOne ** k / (factorial(k) * factorial(n - 2 * k)) * (2 * x) ** (n - 2 * k)
        return factorial(n) * Sum(kern, (k, 0, floor(n / 2)))

    def _eval_rewrite_as_polynomial(self, n, x, **kwargs):
        return self._eval_rewrite_as_Sum(n, x, **kwargs)

    def _eval_rewrite_as_hermite_prob(self, n, x, **kwargs):
        return sqrt(2) ** n * hermite_prob(n, x * sqrt(2))

class hermite_prob(OrthogonalPolynomial):
    _ortho_poly = staticmethod(hermite_prob_poly)

    @classmethod
    def eval(cls, n, x):
        if not n.is_Number:
            if x.could_extract_minus_sign():
                return S.NegativeOne ** n * hermite_prob(n, -x)
            if x.is_zero:
                return sqrt(S.Pi) / gamma((S.One - n) / 2)
            elif x is S.Infinity:
                return S.Infinity
        elif n.is_negative:
            ValueError('n must be a nonnegative integer, not %r' % n)
        else:
            return cls._eval_at_order(n, x)

    def fdiff(self, argindex=2):
        if argindex == 2:
            n, x = self.args
            return n * hermite_prob(n - 1, x)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Sum(self, n, x, **kwargs):
        from sympy.concrete.summations import Sum
        k = Dummy('k')
        kern = (-S.Half) ** k * x ** (n - 2 * k) / (factorial(k) * factorial(n - 2 * k))
        return factorial(n) * Sum(kern, (k, 0, floor(n / 2)))

    def _eval_rewrite_as_polynomial(self, n, x, **kwargs):
        return self._eval_rewrite_as_Sum(n, x, **kwargs)

    def _eval_rewrite_as_hermite(self, n, x, **kwargs):
        return sqrt(2) ** (-n) * hermite(n, x / sqrt(2))

class laguerre(OrthogonalPolynomial):
    _ortho_poly = staticmethod(laguerre_poly)

    @classmethod
    def eval(cls, n, x):
        if n.is_integer is False:
            raise ValueError('Error: n should be an integer.')
        if not n.is_Number:
            if n.could_extract_minus_sign() and (not (-n - 1).could_extract_minus_sign()):
                return exp(x) * laguerre(-n - 1, -x)
            if x.is_zero:
                return S.One
            elif x is S.NegativeInfinity:
                return S.Infinity
            elif x is S.Infinity:
                return S.NegativeOne ** n * S.Infinity
        elif n.is_negative:
            return exp(x) * laguerre(-n - 1, -x)
        else:
            return cls._eval_at_order(n, x)

    def fdiff(self, argindex=2):
        if argindex == 1:
            raise ArgumentIndexError(self, argindex)
        elif argindex == 2:
            n, x = self.args
            return -assoc_laguerre(n - 1, 1, x)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Sum(self, n, x, **kwargs):
        from sympy.concrete.summations import Sum
        if n.is_negative:
            return exp(x) * self._eval_rewrite_as_Sum(-n - 1, -x, **kwargs)
        if n.is_integer is False:
            raise ValueError('Error: n should be an integer.')
        k = Dummy('k')
        kern = RisingFactorial(-n, k) / factorial(k) ** 2 * x ** k
        return Sum(kern, (k, 0, n))

    def _eval_rewrite_as_polynomial(self, n, x, **kwargs):
        return self._eval_rewrite_as_Sum(n, x, **kwargs)

class assoc_laguerre(OrthogonalPolynomial):

    @classmethod
    def eval(cls, n, alpha, x):
        if alpha.is_zero:
            return laguerre(n, x)
        if not n.is_Number:
            if x.is_zero:
                return binomial(n + alpha, alpha)
            elif x is S.Infinity and n > 0:
                return S.NegativeOne ** n * S.Infinity
            elif x is S.NegativeInfinity and n > 0:
                return S.Infinity
        elif n.is_negative:
            raise ValueError('The index n must be nonnegative integer (got %r)' % n)
        else:
            return laguerre_poly(n, x, alpha)

    def fdiff(self, argindex=3):
        from sympy.concrete.summations import Sum
        if argindex == 1:
            raise ArgumentIndexError(self, argindex)
        elif argindex == 2:
            n, alpha, x = self.args
            k = Dummy('k')
            return Sum(assoc_laguerre(k, alpha, x) / (n - alpha), (k, 0, n - 1))
        elif argindex == 3:
            n, alpha, x = self.args
            return -assoc_laguerre(n - 1, alpha + 1, x)
        else:
            raise ArgumentIndexError(self, argindex)

    def _eval_rewrite_as_Sum(self, n, alpha, x, **kwargs):
        from sympy.concrete.summations import Sum
        if n.is_negative or n.is_integer is False:
            raise ValueError('Error: n should be a non-negative integer.')
        k = Dummy('k')
        kern = RisingFactorial(-n, k) / (gamma(k + alpha + 1) * factorial(k)) * x ** k
        return gamma(n + alpha + 1) / factorial(n) * Sum(kern, (k, 0, n))

    def _eval_rewrite_as_polynomial(self, n, alpha, x, **kwargs):
        return self._eval_rewrite_as_Sum(n, alpha, x, **kwargs)

    def _eval_conjugate(self):
        n, alpha, x = self.args
        return self.func(n, alpha.conjugate(), x.conjugate())