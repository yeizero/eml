from __future__ import annotations
from sympy.core.function import DefinedFunction, ArgumentIndexError
from sympy.functions.elementary.miscellaneous import sqrt
from sympy.functions.elementary.trigonometric import sin, cos

class MathieuBase(DefinedFunction):
    unbranched = True

    def _eval_conjugate(self):
        a, q, z = self.args
        return self.func(a.conjugate(), q.conjugate(), z.conjugate())

class mathieus(MathieuBase):

    def fdiff(self, argindex=1):
        if argindex == 3:
            a, q, z = self.args
            return mathieusprime(a, q, z)
        else:
            raise ArgumentIndexError(self, argindex)

    @classmethod
    def eval(cls, a, q, z):
        if q.is_Number and q.is_zero:
            return sin(sqrt(a) * z)
        if z.could_extract_minus_sign():
            return -cls(a, q, -z)

class mathieuc(MathieuBase):

    def fdiff(self, argindex=1):
        if argindex == 3:
            a, q, z = self.args
            return mathieucprime(a, q, z)
        else:
            raise ArgumentIndexError(self, argindex)

    @classmethod
    def eval(cls, a, q, z):
        if q.is_Number and q.is_zero:
            return cos(sqrt(a) * z)
        if z.could_extract_minus_sign():
            return cls(a, q, -z)

class mathieusprime(MathieuBase):

    def fdiff(self, argindex=1):
        if argindex == 3:
            a, q, z = self.args
            return (2 * q * cos(2 * z) - a) * mathieus(a, q, z)
        else:
            raise ArgumentIndexError(self, argindex)

    @classmethod
    def eval(cls, a, q, z):
        if q.is_Number and q.is_zero:
            return sqrt(a) * cos(sqrt(a) * z)
        if z.could_extract_minus_sign():
            return cls(a, q, -z)

class mathieucprime(MathieuBase):

    def fdiff(self, argindex=1):
        if argindex == 3:
            a, q, z = self.args
            return (2 * q * cos(2 * z) - a) * mathieuc(a, q, z)
        else:
            raise ArgumentIndexError(self, argindex)

    @classmethod
    def eval(cls, a, q, z):
        if q.is_Number and q.is_zero:
            return -sqrt(a) * sin(sqrt(a) * z)
        if z.could_extract_minus_sign():
            return -cls(a, q, -z)