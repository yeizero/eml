from __future__ import annotations
from math import prod
from sympy.core import S, Integer
from sympy.core.function import DefinedFunction
from sympy.core.logic import fuzzy_not
from sympy.core.relational import Ne
from sympy.core.sorting import default_sort_key
from sympy.external.gmpy import SYMPY_INTS
from sympy.functions.combinatorial.factorials import factorial
from sympy.functions.elementary.piecewise import Piecewise
from sympy.utilities.iterables import has_dups

def Eijk(*args, **kwargs):
    return LeviCivita(*args, **kwargs)

def eval_levicivita(*args):
    n = len(args)
    return prod((prod((args[j] - args[i] for j in range(i + 1, n))) / factorial(i) for i in range(n)))

class LeviCivita(DefinedFunction):
    is_integer = True

    @classmethod
    def eval(cls, *args):
        if all((isinstance(a, (SYMPY_INTS, Integer)) for a in args)):
            return eval_levicivita(*args)
        if has_dups(args):
            return S.Zero

    def doit(self, **hints):
        return eval_levicivita(*self.args)

class KroneckerDelta(DefinedFunction):
    is_integer = True

    @classmethod
    def eval(cls, i, j, delta_range=None):
        if delta_range is not None:
            dinf, dsup = delta_range
            if (dinf - i > 0) == True:
                return S.Zero
            if (dinf - j > 0) == True:
                return S.Zero
            if (dsup - i < 0) == True:
                return S.Zero
            if (dsup - j < 0) == True:
                return S.Zero
        diff = i - j
        if diff.is_zero:
            return S.One
        elif fuzzy_not(diff.is_zero):
            return S.Zero
        if i.assumptions0.get('below_fermi') and j.assumptions0.get('above_fermi'):
            return S.Zero
        if j.assumptions0.get('below_fermi') and i.assumptions0.get('above_fermi'):
            return S.Zero
        if default_sort_key(j) < default_sort_key(i):
            if delta_range:
                return cls(j, i, delta_range)
            else:
                return cls(j, i)

    @property
    def delta_range(self):
        if len(self.args) > 2:
            return self.args[2]

    def _eval_power(self, expt):
        if expt.is_positive:
            return self
        if expt.is_negative and expt is not S.NegativeOne:
            return 1 / self

    @property
    def is_above_fermi(self):
        if self.args[0].assumptions0.get('below_fermi'):
            return False
        if self.args[1].assumptions0.get('below_fermi'):
            return False
        return True

    @property
    def is_below_fermi(self):
        if self.args[0].assumptions0.get('above_fermi'):
            return False
        if self.args[1].assumptions0.get('above_fermi'):
            return False
        return True

    @property
    def is_only_above_fermi(self):
        return (self.args[0].assumptions0.get('above_fermi') or self.args[1].assumptions0.get('above_fermi')) or False

    @property
    def is_only_below_fermi(self):
        return (self.args[0].assumptions0.get('below_fermi') or self.args[1].assumptions0.get('below_fermi')) or False

    @property
    def indices_contain_equal_information(self):
        if self.args[0].assumptions0.get('below_fermi') and self.args[1].assumptions0.get('below_fermi'):
            return True
        if self.args[0].assumptions0.get('above_fermi') and self.args[1].assumptions0.get('above_fermi'):
            return True
        return self.is_below_fermi and self.is_above_fermi

    @property
    def preferred_index(self):
        if self._get_preferred_index():
            return self.args[1]
        else:
            return self.args[0]

    @property
    def killable_index(self):
        if self._get_preferred_index():
            return self.args[0]
        else:
            return self.args[1]

    def _get_preferred_index(self):
        if not self.is_above_fermi:
            if self.args[0].assumptions0.get('below_fermi'):
                return 0
            else:
                return 1
        elif not self.is_below_fermi:
            if self.args[0].assumptions0.get('above_fermi'):
                return 0
            else:
                return 1
        else:
            return 0

    @property
    def indices(self):
        return self.args[0:2]

    def _eval_rewrite_as_Piecewise(self, *args, **kwargs):
        i, j = args
        return Piecewise((0, Ne(i, j)), (1, True))