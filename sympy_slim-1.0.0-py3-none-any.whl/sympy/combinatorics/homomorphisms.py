from __future__ import annotations
from collections import defaultdict
import itertools
from sympy.combinatorics.coset_table import modified_coset_enumeration_r
from sympy.combinatorics.fp_groups import FpGroup, FpSubgroup, simplify_presentation
from sympy.combinatorics.free_groups import FreeGroup
from sympy.combinatorics.perm_groups import PermutationGroup
from sympy.core.intfunc import igcd
from sympy.functions.combinatorial.numbers import totient
from sympy.core.singleton import S

class GroupHomomorphism:

    def __init__(self, domain, codomain, images):
        self.domain = domain
        self.codomain = codomain
        self.images = images
        self._inverses = None
        self._kernel = None
        self._image = None
        self._surjective_cert = None
        self._surjective_cert_computed = False
        self._factorization = None

    def _invs(self):
        image = self.image()
        inverses = {}
        for k in list(self.images.keys()):
            v = self.images[k]
            if not (v in inverses or v.is_identity):
                inverses[v] = k
        if isinstance(self.codomain, PermutationGroup):
            gens = image.strong_gens
        else:
            gens = image.generators
        dtype = type(self.domain.identity)
        for g in gens:
            if g in inverses or g.is_identity:
                continue
            if isinstance(self.codomain, PermutationGroup):
                parts = image._strong_gens_slp[g][::-1]
            else:
                parts = g
            w = dtype.prod((inverses[s] if s in inverses else inverses[s ** (-1)] ** (-1) for s in parts))
            inverses[g] = w
        return inverses

    def invert(self, g):
        from sympy.combinatorics import Permutation
        from sympy.combinatorics.free_groups import FreeGroupElement
        if isinstance(g, (Permutation, FreeGroupElement)):
            if isinstance(self.codomain, FpGroup):
                g = self.codomain.reduce(g)
            if self._inverses is None:
                self._inverses = self._invs()
            image = self.image()
            w = self.domain.identity
            if isinstance(self.codomain, PermutationGroup):
                if g not in image:
                    raise ValueError('Given element is not in the image of the homomorphism.')
                gens = image.generator_product(g)[::-1]
                dtype = type(w)
                return dtype.prod(itertools.chain([w], (self._inverses[s] if s in self._inverses else self._inverses[s ** (-1)] ** (-1) for s in gens if not s.is_identity)))
            else:
                current_coset = 0
                im_gens = list(self._inverses)
                C = modified_coset_enumeration_r(self.codomain, im_gens)
                dtype = type(w)
                factors = []
                preimages = list(self._inverses.values())
                temp_symbols = [gen.array_form[0][0] for gen in C._grp.generators]
                transl_map = dict(zip(temp_symbols, preimages))
                symbol_to_group_gen = {gen.array_form[0][0]: gen for gen in self.codomain.generators}
                for s, exp in g.array_form:
                    t = symbol_to_group_gen[s]
                    if exp < 0:
                        j = C.A_dict[t ** (-1)]
                    else:
                        j = C.A_dict[t]
                    for _ in range(abs(exp)):
                        word_intermediate = C.P[current_coset][j]
                        if word_intermediate is not None:
                            factors.extend((transl_map[s] ** exp for s, exp in word_intermediate.array_form))
                        current_coset = C.table[current_coset][j]
                if current_coset != 0:
                    raise ValueError('Given element is not in the image of the homomorphism.')
                return dtype.prod(factors)
        elif isinstance(g, list):
            return [self.invert(e) for e in g]

    def kernel(self):
        if self._kernel is None:
            self._kernel = self._compute_kernel()
        return self._kernel

    def _compute_kernel(self):
        G = self.domain
        H = self.codomain
        Ginf = G.order() is S.Infinity
        if Ginf and isinstance(H, (FpGroup, FreeGroup, PermutationGroup)):
            perm_codomain = isinstance(H, PermutationGroup)
            if isinstance(H, FreeGroup):
                H = FpGroup(H, [])
            preimages = self._is_surjective_cert()
            if preimages is not None:
                if perm_codomain:
                    perm_gens = H.generators
                    fp_group = H.presentation(eliminate_gens=False)
                    if isinstance(fp_group, FreeGroup):
                        return G
                    symbol_to_preimage = {g.ext_rep[0]: preimages[perm_g] for g, perm_g in zip(fp_group.generators, perm_gens)}
                else:
                    symbol_to_preimage = {g.ext_rep[0]: preimages[g] for g in H.generators}

                def _lift_to_domain(word):
                    dtype = type(G.identity)
                    if perm_codomain and isinstance(word, type(H.identity)):
                        factors = H.generator_product(word, original=True)[::-1]
                        return dtype.prod((preimages[s] if s in preimages else preimages[s ** (-1)] ** (-1) for s in factors if not s.is_identity))
                    return dtype.prod((symbol_to_preimage[symbol] ** power for symbol, power in word.array_form))
                kernel_gens = []
                relators = fp_group.relators if perm_codomain else H.relators
                for relator in relators:
                    word = _lift_to_domain(relator)
                    if not word.is_identity:
                        kernel_gens.append(word)
                for generator in G.generators:
                    lifted_image = _lift_to_domain(self.images[generator])
                    word = generator * lifted_image ** (-1)
                    if not word.is_identity:
                        kernel_gens.append(word)
                return FpSubgroup(G, kernel_gens, normal=True)
            else:
                return self.factor()[0].kernel()
        if Ginf:
            raise NotImplementedError('Kernel computation is not implemented for this group type')
        if isinstance(G, FpGroup):
            P, T = G._to_perm_group()
            perm_images = {g: self(T.invert(g)) for g in P.generators}
            perm_hom = GroupHomomorphism(P, H, perm_images)
            perm_kernel = perm_hom._compute_kernel()
            kernel_gens = T.invert(perm_kernel.generators)
            return FpSubgroup(G, kernel_gens, normal=True)
        if isinstance(G, PermutationGroup):
            return G.subgroup_search(lambda g: self(g).is_identity)
        raise NotImplementedError('Kernel computation is not implemented for this group type')

    def image(self):
        if self._image is None:
            values = list(set(self.images.values()))
            if isinstance(self.codomain, PermutationGroup):
                self._image = self.codomain.subgroup(values)
            else:
                self._image = FpSubgroup(self.codomain, values)
        return self._image

    def _apply(self, elem):
        if elem not in self.domain:
            if isinstance(elem, (list, tuple)):
                return [self._apply(e) for e in elem]
            raise ValueError('The supplied element does not belong to the domain')
        if elem.is_identity:
            return self.codomain.identity
        else:
            images = self.images
            value = self.codomain.identity
            if isinstance(self.domain, PermutationGroup):
                gens = self.domain.generator_product(elem, original=True)
                for g in gens:
                    if g in self.images:
                        value = images[g] * value
                    else:
                        value = images[g ** (-1)] ** (-1) * value
            else:
                i = 0
                for _, p in elem.array_form:
                    if p < 0:
                        g = elem[i] ** (-1)
                    else:
                        g = elem[i]
                    value = value * images[g] ** p
                    i += abs(p)
        return value

    def __call__(self, elem):
        return self._apply(elem)

    def is_injective(self):
        return self.kernel().order() == 1

    def _is_surjective_cert(self):
        if not self._surjective_cert_computed:
            preimages = None
            try:
                preimages = {g: self.invert(g) for g in self.codomain.generators}
            except ValueError:
                pass
            self._surjective_cert = preimages
            self._surjective_cert_computed = True
        return self._surjective_cert

    def is_surjective(self):
        return self._is_surjective_cert() is not None

    def is_isomorphism(self):
        return self.is_injective() and self.is_surjective()

    def is_trivial(self):
        return self.image().order() == 1

    def factor(self):
        if self._factorization is not None:
            return self._factorization
        if isinstance(self.codomain, PermutationGroup):
            image = self.image()
            surj = homomorphism(self.domain, image, self.domain.generators, [self.images[g] for g in self.domain.generators], check=False)
            inj = homomorphism(image, self.codomain, image.generators, image.generators)
            self._factorization = (surj, inj)
            return self._factorization
        if not isinstance(self.codomain, (FpGroup, FreeGroup)):
            raise NotImplementedError('Factorization is implemented only for permutation, finitely presented, and free codomains')
        if isinstance(self.codomain, FpGroup):
            codomain = self.codomain
        else:
            codomain = FpGroup(self.codomain, [])
        image_gens = list(dict.fromkeys(self.images.values()))
        image_group, image_inclusion = codomain.subgroup(image_gens, homomorphism=True)
        surj_images = [image_inclusion.invert(self.images[g]) for g in self.domain.generators]
        surj = homomorphism(self.domain, image_group, self.domain.generators, surj_images, check=False)
        inj = homomorphism(image_group, self.codomain, image_group.generators, image_inclusion(image_group.generators), check=False)
        self._factorization = (surj, inj)
        return self._factorization

    def compose(self, other):
        if not other.image().is_subgroup(self.domain):
            raise ValueError('The image of `other` must be a subgroup of the domain of `self`')
        images = {g: self(other(g)) for g in other.images}
        return GroupHomomorphism(other.domain, self.codomain, images)

    def restrict_to(self, H):
        if not isinstance(H, PermutationGroup) or not H.is_subgroup(self.domain):
            raise ValueError('Given H is not a subgroup of the domain')
        domain = H
        images = {g: self(g) for g in H.generators}
        return GroupHomomorphism(domain, self.codomain, images)

    def invert_subgroup(self, H):
        if not H.is_subgroup(self.image()):
            raise ValueError('Given H is not a subgroup of the image')
        gens = []
        P = PermutationGroup(self.image().identity)
        for h in H.generators:
            h_i = self.invert(h)
            if h_i not in P:
                gens.append(h_i)
                P = PermutationGroup(gens)
            for k in self.kernel().generators:
                if k * h_i not in P:
                    gens.append(k * h_i)
                    P = PermutationGroup(gens)
        return P

def homomorphism(domain, codomain, gens, images=(), check=True):
    if not isinstance(domain, (PermutationGroup, FpGroup, FreeGroup)):
        raise TypeError('The domain must be a group')
    if not isinstance(codomain, (PermutationGroup, FpGroup, FreeGroup)):
        raise TypeError('The codomain must be a group')
    generators = domain.generators
    if not all((g in generators for g in gens)):
        raise ValueError("The supplied generators must be a subset of the domain's generators")
    if not all((g in codomain for g in images)):
        raise ValueError('The images must be elements of the codomain')
    if images and len(images) != len(gens):
        raise ValueError('The number of images must be equal to the number of generators')
    gens = list(gens)
    images = list(images)
    images.extend([codomain.identity] * (len(generators) - len(images)))
    gens.extend([g for g in generators if g not in gens])
    images = dict(zip(gens, images))
    if check and (not _check_homomorphism(domain, codomain, images)):
        raise ValueError('The given images do not define a homomorphism')
    return GroupHomomorphism(domain, codomain, images)

def _check_homomorphism(domain, codomain, images):
    pres = domain if hasattr(domain, 'relators') else domain.presentation()
    rels = pres.relators
    gens = pres.generators
    symbols = [g.ext_rep[0] for g in gens]
    symbols_to_domain_generators = dict(zip(symbols, domain.generators))
    identity = codomain.identity
    dtype = type(identity)

    def _image(r):
        return dtype.prod((images[symbols_to_domain_generators[symbol]] ** power for symbol, power in r.array_form))
    for r in rels:
        if isinstance(codomain, FpGroup):
            s = codomain.equals(_image(r), identity)
            if s is None:
                success = codomain.make_confluent()
                s = codomain.equals(_image(r), identity)
                if s is None and (not success):
                    raise RuntimeError("Can't determine if the images define a homomorphism. Try increasing the maximum number of rewriting rules (group._rewriting_system.set_max(new_value); the current value is stored in group._rewriting_system.maxeqns)")
        else:
            s = _image(r).is_identity
        if not s:
            return False
    return True

def orbit_homomorphism(group, omega):
    from sympy.combinatorics import Permutation
    from sympy.combinatorics.named_groups import SymmetricGroup
    codomain = SymmetricGroup(len(omega))
    identity = codomain.identity
    omega = list(omega)
    images = {g: identity * Permutation([omega.index(o ^ g) for o in omega]) for g in group.generators}
    group._schreier_sims(base=omega)
    H = GroupHomomorphism(group, codomain, images)
    if len(group.basic_stabilizers) > len(omega):
        H._kernel = group.basic_stabilizers[len(omega)]
    else:
        H._kernel = PermutationGroup([group.identity])
    return H

def block_homomorphism(group, blocks):
    from sympy.combinatorics import Permutation
    from sympy.combinatorics.named_groups import SymmetricGroup
    n = len(blocks)
    m = 0
    p = []
    b = [None] * n
    for i in range(n):
        if blocks[i] == i:
            p.append(i)
            b[i] = m
            m += 1
    for i in range(n):
        b[i] = b[blocks[i]]
    codomain = SymmetricGroup(m)
    identity = range(m)
    images = {g: Permutation([b[p[i] ^ g] for i in identity]) for g in group.generators}
    H = GroupHomomorphism(group, codomain, images)
    return H

def group_isomorphism(G, H, isomorphism=True):
    if not isinstance(G, (PermutationGroup, FpGroup)):
        raise TypeError('The group must be a PermutationGroup or an FpGroup')
    if not isinstance(H, (PermutationGroup, FpGroup)):
        raise TypeError('The group must be a PermutationGroup or an FpGroup')
    if isinstance(G, FpGroup) and isinstance(H, FpGroup):
        G = simplify_presentation(G)
        H = simplify_presentation(H)
        if G.generators == H.generators and G.relators.sort() == H.relators.sort():
            if not isomorphism:
                return True
            return (True, homomorphism(G, H, G.generators, H.generators))
    _H = H
    g_order = G.order()
    h_order = H.order()
    if g_order is S.Infinity:
        raise NotImplementedError('Isomorphism methods are not implemented for infinite groups.')
    if isinstance(H, FpGroup):
        if h_order is S.Infinity:
            raise NotImplementedError('Isomorphism methods are not implemented for infinite groups.')
        _H, h_isomorphism = H._to_perm_group()
    if g_order != h_order or G.is_abelian != H.is_abelian:
        if not isomorphism:
            return False
        return (False, None)
    if not isomorphism:
        n = g_order
        if igcd(n, totient(n)) == 1:
            return True
    gens = list(G.generators)
    if isinstance(G, PermutationGroup):
        diz_gen = defaultdict(list)
        diz_imm = defaultdict(list)
        for g in gens:
            diz_gen[g.order()].append(g)
        for el in _H.generate():
            j = el.order()
            if j in diz_gen:
                diz_imm[j].append(el)
        lista = []
        for key, g in diz_gen.items():
            sublist = list(itertools.permutations(diz_imm[key], len(g)))
            lista.append(sublist)
        all_matches = itertools.product(*lista)
        for m in all_matches:
            images = []
            for i in range(len(diz_gen)):
                images.extend(m[i])
            _images = dict(zip(gens, images))
            if _check_homomorphism(G, _H, _images):
                if isinstance(H, FpGroup):
                    images = h_isomorphism.invert(images)
                T = homomorphism(G, H, G.generators, images, check=False)
                if T.is_isomorphism():
                    if not isomorphism:
                        return True
                    return (True, T)
        if not isomorphism:
            return False
        return (False, None)
    else:
        for subset in itertools.permutations(_H.generate(), len(gens)):
            images = list(subset)
            images.extend([_H.identity] * (len(G.generators) - len(images)))
            _images = dict(zip(gens, images))
            if _check_homomorphism(G, _H, _images):
                if isinstance(H, FpGroup):
                    images = h_isomorphism.invert(images)
                T = homomorphism(G, H, G.generators, images, check=False)
                if T.is_isomorphism():
                    if not isomorphism:
                        return True
                    return (True, T)
        if not isomorphism:
            return False
        return (False, None)

def is_isomorphic(G, H):
    return group_isomorphism(G, H, isomorphism=False)