from __future__ import annotations
import random
from collections import defaultdict
from collections.abc import Iterable
from functools import reduce
from sympy.core.parameters import global_parameters
from sympy.core.basic import Atom
from sympy.core.expr import Expr
from sympy.core.numbers import int_valued
from sympy.core.numbers import Integer
from sympy.core.sympify import _sympify
from sympy.matrices import zeros
from sympy.polys.polytools import lcm
from sympy.printing.repr import srepr
from sympy.utilities.iterables import flatten, has_variety, has_dups, runs, is_sequence
from sympy.utilities.misc import as_int
from sympy.external.gmpy import factorial
from sympy.multipledispatch import dispatch

def _af_rmul(a, b):
    return [a[i] for i in b]

def _af_rmuln(*abc):
    a = abc
    m = len(a)
    if m == 3:
        p0, p1, p2 = a
        return [p0[p1[i]] for i in p2]
    if m == 4:
        p0, p1, p2, p3 = a
        return [p0[p1[p2[i]]] for i in p3]
    if m == 5:
        p0, p1, p2, p3, p4 = a
        return [p0[p1[p2[p3[i]]]] for i in p4]
    if m == 6:
        p0, p1, p2, p3, p4, p5 = a
        return [p0[p1[p2[p3[p4[i]]]]] for i in p5]
    if m == 7:
        p0, p1, p2, p3, p4, p5, p6 = a
        return [p0[p1[p2[p3[p4[p5[i]]]]]] for i in p6]
    if m == 8:
        p0, p1, p2, p3, p4, p5, p6, p7 = a
        return [p0[p1[p2[p3[p4[p5[p6[i]]]]]]] for i in p7]
    if m == 1:
        return a[0][:]
    if m == 2:
        a, b = a
        return [a[i] for i in b]
    if m == 0:
        raise ValueError('String must not be empty')
    p0 = _af_rmuln(*a[:m // 2])
    p1 = _af_rmuln(*a[m // 2:])
    return [p0[i] for i in p1]

def _af_parity(pi):
    n = len(pi)
    a = [0] * n
    c = 0
    for j in range(n):
        if a[j] == 0:
            c += 1
            a[j] = 1
            i = j
            while pi[i] != j:
                i = pi[i]
                a[i] = 1
    return (n - c) % 2

def _af_invert(a):
    inv_form = [0] * len(a)
    for i, ai in enumerate(a):
        inv_form[ai] = i
    return inv_form

def _af_pow(a, n):
    if n == 0:
        return list(range(len(a)))
    if n < 0:
        return _af_pow(_af_invert(a), -n)
    if n == 1:
        return a[:]
    elif n == 2:
        b = [a[i] for i in a]
    elif n == 3:
        b = [a[a[i]] for i in a]
    elif n == 4:
        b = [a[a[a[i]]] for i in a]
    else:
        b = list(range(len(a)))
        while 1:
            if n & 1:
                b = [b[i] for i in a]
                n -= 1
                if not n:
                    break
            if n % 4 == 0:
                a = [a[a[a[i]]] for i in a]
                n = n // 4
            elif n % 2 == 0:
                a = [a[i] for i in a]
                n = n // 2
    return b

def _af_commutes_with(a, b):
    return not any((a[b[i]] != b[a[i]] for i in range(len(a) - 1)))

class Cycle(dict):

    def __missing__(self, arg):
        return as_int(arg)

    def __iter__(self):
        yield from self.list()

    def __call__(self, *other):
        rv = Cycle(*other)
        for k, v in zip(list(self.keys()), [rv[self[k]] for k in self.keys()]):
            rv[k] = v
        return rv

    def list(self, size=None):
        if not self and size is None:
            raise ValueError('must give size for empty Cycle')
        if size is not None:
            big = max([i for i in self.keys() if self[i] != i] + [-1])
            size = max(size, big + 1)
        else:
            size = self.size
        return [self[i] for i in range(size)]

    def __repr__(self):
        if not self:
            return 'Cycle()'
        cycles = Permutation(self).cyclic_form
        s = ''.join((str(tuple(c)) for c in cycles))
        big = self.size - 1
        if not any((i == big for c in cycles for i in c)):
            s += '(%s)' % big
        return 'Cycle%s' % s

    def __str__(self):
        if not self:
            return '()'
        cycles = Permutation(self).cyclic_form
        s = ''.join((str(tuple(c)) for c in cycles))
        big = self.size - 1
        if not any((i == big for c in cycles for i in c)):
            s += '(%s)' % big
        s = s.replace(',', '')
        return s

    def __init__(self, *args):
        if not args:
            return
        if len(args) == 1:
            if isinstance(args[0], Permutation):
                for c in args[0].cyclic_form:
                    self.update(self(*c))
                return
            elif isinstance(args[0], Cycle):
                for k, v in args[0].items():
                    self[k] = v
                return
        args = [as_int(a) for a in args]
        if any((i < 0 for i in args)):
            raise ValueError('negative integers are not allowed in a cycle.')
        if has_dups(args):
            raise ValueError('All elements must be unique in a cycle.')
        for i in range(-len(args), 0):
            self[args[i]] = args[i + 1]

    @property
    def size(self):
        if not self:
            return 0
        return max(self.keys()) + 1

    def copy(self):
        return Cycle(self)

class Permutation(Atom):
    is_Permutation = True
    _array_form = None
    _cyclic_form = None
    _cycle_structure = None
    _size = None
    _rank = None

    def __new__(cls, *args, size=None, **kwargs):
        if size is not None:
            size = int(size)
        ok = True
        if not args:
            return cls._af_new(list(range(size or 0)))
        elif len(args) > 1:
            return cls._af_new(Cycle(*args).list(size))
        if len(args) == 1:
            a = args[0]
            if isinstance(a, cls):
                if size is None or size == a.size:
                    return a
                return cls(a.array_form, size=size)
            if isinstance(a, Cycle):
                return cls._af_new(a.list(size))
            if not is_sequence(a):
                if size is not None and a + 1 > size:
                    raise ValueError('size is too small when max is %s' % a)
                return cls._af_new(list(range(a + 1)))
            if has_variety((is_sequence(ai) for ai in a)):
                ok = False
        else:
            ok = False
        if not ok:
            raise ValueError('Permutation argument must be a list of ints, a list of lists, Permutation or Cycle.')
        args = list(args[0])
        is_cycle = args and is_sequence(args[0])
        if is_cycle:
            args = [[int(i) for i in c] for c in args]
        else:
            args = [int(i) for i in args]
        temp = flatten(args)
        if has_dups(temp) and (not is_cycle):
            raise ValueError('there were repeated elements.')
        temp = set(temp)
        if not is_cycle:
            if temp != set(range(len(temp))):
                raise ValueError('Integers 0 through %s must be present.' % max(temp))
            if size is not None and temp and (max(temp) + 1 > size):
                raise ValueError('max element should not exceed %s' % (size - 1))
        if is_cycle:
            c = Cycle()
            for ci in args:
                c = c(*ci)
            aform = c.list()
        else:
            aform = list(args)
        if size and size > len(aform):
            aform.extend(list(range(len(aform), size)))
        return cls._af_new(aform)

    @classmethod
    def _af_new(cls, perm):
        p = super().__new__(cls)
        p._array_form = perm
        p._size = len(perm)
        return p

    def copy(self):
        return self.__class__(self.array_form)

    def __getnewargs__(self):
        return (self.array_form,)

    def _hashable_content(self):
        return tuple(self.array_form)

    @property
    def array_form(self):
        return self._array_form[:]

    def list(self, size=None):
        if not self and size is None:
            raise ValueError('must give size for empty Cycle')
        rv = self.array_form
        if size is not None:
            if size > self.size:
                rv.extend(list(range(self.size, size)))
            else:
                i = self.size - 1
                while rv:
                    if rv[-1] != i:
                        break
                    rv.pop()
                    i -= 1
        return rv

    @property
    def cyclic_form(self):
        if self._cyclic_form is not None:
            return [cycle[:] for cycle in self._cyclic_form]
        array_form = self.array_form
        unchecked = [True] * len(array_form)
        cyclic_form = []
        for i in range(len(array_form)):
            if unchecked[i]:
                cycle = []
                cycle.append(i)
                unchecked[i] = False
                j = i
                while unchecked[array_form[j]]:
                    j = array_form[j]
                    cycle.append(j)
                    unchecked[j] = False
                if len(cycle) > 1:
                    cyclic_form.append(cycle)
        self._cyclic_form = [cycle[:] for cycle in cyclic_form]
        return cyclic_form

    @property
    def full_cyclic_form(self):
        need = set(range(self.size)) - set(flatten(self.cyclic_form))
        rv = self.cyclic_form + [[i] for i in need]
        rv.sort()
        return rv

    @property
    def size(self):
        return self._size

    def support(self):
        a = self.array_form
        return [i for i, e in enumerate(a) if e != i]

    def __add__(self, other):
        rank = (self.rank() + other) % self.cardinality
        rv = self.unrank_lex(self.size, rank)
        rv._rank = rank
        return rv

    def __sub__(self, other):
        return self.__add__(-other)

    @staticmethod
    def rmul(*args):
        rv = args[0]
        for i in range(1, len(args)):
            rv = args[i] * rv
        return rv

    @classmethod
    def prod(cls, perms: Iterable['Permutation']) -> 'Permutation':
        perms = list(perms)
        if not perms:
            return cls([])
        return cls.rmul(*reversed(perms))

    @classmethod
    def rmul_with_af(cls, *args):
        a = [x._array_form for x in args]
        rv = cls._af_new(_af_rmuln(*a))
        return rv

    def mul_inv(self, other):
        a = _af_invert(self._array_form)
        b = other._array_form
        return self._af_new(_af_rmul(a, b))

    def __rmul__(self, other):
        cls = type(self)
        return cls(other) * self

    def __mul__(self, other):
        from sympy.combinatorics.perm_groups import PermutationGroup, Coset
        if isinstance(other, PermutationGroup):
            return Coset(self, other, dir='-')
        a = self.array_form
        b = other.array_form
        if not b:
            perm = a
        else:
            b.extend(list(range(len(b), len(a))))
            perm = [b[i] for i in a] + b[len(a):]
        return self._af_new(perm)

    def commutes_with(self, other):
        a = self.array_form
        b = other.array_form
        return _af_commutes_with(a, b)

    def __pow__(self, n):
        if isinstance(n, Permutation):
            raise NotImplementedError('p**p is not defined; do you mean p^p (conjugate)?')
        n = int(n)
        return self._af_new(_af_pow(self.array_form, n))

    def __rxor__(self, i):
        if int_valued(i):
            return self(i)
        else:
            raise NotImplementedError('i^p = p(i) when i is an integer, not %s.' % i)

    def __xor__(self, h):
        if self.size != h.size:
            raise ValueError('The permutations must be of equal size.')
        a = [None] * self.size
        h = h._array_form
        p = self._array_form
        for i in range(self.size):
            a[h[i]] = h[p[i]]
        return self._af_new(a)

    def transpositions(self):
        a = self.cyclic_form
        res = []
        for x in a:
            nx = len(x)
            if nx == 2:
                res.append(tuple(x))
            elif nx > 2:
                first = x[0]
                res.extend(((first, y) for y in x[nx - 1:0:-1]))
        return res

    @classmethod
    def from_sequence(self, i, key=None):
        ic = list(zip(i, list(range(len(i)))))
        if key:
            ic.sort(key=lambda x: key(x[0]))
        else:
            ic.sort()
        return ~Permutation([i[1] for i in ic])

    def __invert__(self):
        return self._af_new(_af_invert(self._array_form))

    def __iter__(self):
        yield from self.array_form

    def __repr__(self):
        return srepr(self)

    def __call__(self, *i):
        if len(i) == 1:
            i = i[0]
            if not isinstance(i, Iterable):
                i = as_int(i)
                if i < 0 or i >= self.size:
                    raise TypeError('{} should be an integer between 0 and {}'.format(i, self.size - 1))
                return self._array_form[i]
            if len(i) != self.size:
                raise TypeError('{} should have the length {}.'.format(i, self.size))
            return [i[j] for j in self._array_form]
        return self * Permutation(Cycle(*i), size=self.size)

    def atoms(self):
        return set(self.array_form)

    def apply(self, i):
        i = _sympify(i)
        if i.is_integer is False:
            raise NotImplementedError('{} should be an integer.'.format(i))
        n = self.size
        if (i < 0) == True or (i >= n) == True:
            raise NotImplementedError('{} should be an integer between 0 and {}'.format(i, n - 1))
        if i.is_Integer:
            return Integer(self._array_form[i])
        return AppliedPermutation(self, i)

    def next_lex(self):
        perm = self.array_form[:]
        n = len(perm)
        i = n - 2
        while perm[i + 1] < perm[i]:
            i -= 1
        if i == -1:
            return None
        else:
            j = n - 1
            while perm[j] < perm[i]:
                j -= 1
            perm[j], perm[i] = (perm[i], perm[j])
            i += 1
            j = n - 1
            while i < j:
                perm[j], perm[i] = (perm[i], perm[j])
                i += 1
                j -= 1
        return self._af_new(perm)

    @classmethod
    def unrank_nonlex(self, n, r):

        def _unrank1(n, r, a):
            if n > 0:
                a[n - 1], a[r % n] = (a[r % n], a[n - 1])
                _unrank1(n - 1, r // n, a)
        id_perm = list(range(n))
        n = int(n)
        r = r % factorial(n)
        _unrank1(n, r, id_perm)
        return self._af_new(id_perm)

    def rank_nonlex(self, inv_perm=None):

        def _rank1(n, perm, inv_perm):
            if n == 1:
                return 0
            s = perm[n - 1]
            t = inv_perm[n - 1]
            perm[n - 1], perm[t] = (perm[t], s)
            inv_perm[n - 1], inv_perm[s] = (inv_perm[s], t)
            return s + n * _rank1(n - 1, perm, inv_perm)
        if inv_perm is None:
            inv_perm = (~self).array_form
        if not inv_perm:
            return 0
        perm = self.array_form[:]
        r = _rank1(len(perm), perm, inv_perm)
        return r

    def next_nonlex(self):
        r = self.rank_nonlex()
        if r == factorial(self.size) - 1:
            return None
        return self.unrank_nonlex(self.size, r + 1)

    def rank(self):
        if self._rank is not None:
            return self._rank
        rank = 0
        rho = self.array_form[:]
        n = self.size - 1
        size = n + 1
        psize = int(factorial(n))
        for j in range(size - 1):
            rank += rho[j] * psize
            for i in range(j + 1, size):
                if rho[i] > rho[j]:
                    rho[i] -= 1
            psize //= n
            n -= 1
        self._rank = rank
        return rank

    @property
    def cardinality(self):
        return int(factorial(self.size))

    def parity(self):
        if self._cyclic_form is not None:
            return (self.size - self.cycles) % 2
        return _af_parity(self.array_form)

    @property
    def is_even(self):
        return not self.is_odd

    @property
    def is_odd(self):
        return bool(self.parity() % 2)

    @property
    def is_Singleton(self):
        return self.size == 1

    @property
    def is_Empty(self):
        return self.size == 0

    @property
    def is_identity(self):
        return self.is_Identity

    @property
    def is_Identity(self):
        af = self.array_form
        return not af or all((i == af[i] for i in range(self.size)))

    def ascents(self):
        a = self.array_form
        pos = [i for i in range(len(a) - 1) if a[i] < a[i + 1]]
        return pos

    def descents(self):
        a = self.array_form
        pos = [i for i in range(len(a) - 1) if a[i] > a[i + 1]]
        return pos

    def max(self) -> int:
        a = self.array_form
        if not a:
            return 0
        return max((_a for i, _a in enumerate(a) if _a != i))

    def min(self) -> int:
        a = self.array_form
        if not a:
            return 0
        return min((_a for i, _a in enumerate(a) if _a != i))

    def inversions(self):
        inversions = 0
        a = self.array_form
        n = len(a)
        if n < 130:
            for i in range(n - 1):
                b = a[i]
                for c in a[i + 1:]:
                    if b > c:
                        inversions += 1
        else:
            k = 1
            right = 0
            arr = a[:]
            temp = a[:]
            while k < n:
                i = 0
                while i + k < n:
                    right = i + k * 2 - 1
                    if right >= n:
                        right = n - 1
                    inversions += _merge(arr, temp, i, i + k, right)
                    i = i + k * 2
                k = k * 2
        return inversions

    def commutator(self, x):
        a = self.array_form
        b = x.array_form
        n = len(a)
        if len(b) != n:
            raise ValueError('The permutations must be of equal size.')
        inva = [None] * n
        for i in range(n):
            inva[a[i]] = i
        invb = [None] * n
        for i in range(n):
            invb[b[i]] = i
        return self._af_new([a[b[inva[i]]] for i in invb])

    def signature(self):
        if self.is_even:
            return 1
        return -1

    def order(self):
        return reduce(lcm, [len(cycle) for cycle in self.cyclic_form], 1)

    def length(self):
        return len(self.support())

    @property
    def cycle_structure(self):
        if self._cycle_structure:
            rv = self._cycle_structure
        else:
            rv = defaultdict(int)
            singletons = self.size
            for c in self.cyclic_form:
                rv[len(c)] += 1
                singletons -= len(c)
            if singletons:
                rv[1] = singletons
            self._cycle_structure = rv
        return dict(rv)

    @property
    def cycles(self):
        return len(self.full_cyclic_form)

    def index(self):
        a = self.array_form
        return sum((j for j in range(len(a) - 1) if a[j] > a[j + 1]))

    def runs(self):
        return runs(self.array_form)

    def inversion_vector(self):
        self_array_form = self.array_form
        n = len(self_array_form)
        inversion_vector = [0] * (n - 1)
        for i in range(n - 1):
            val = 0
            for j in range(i + 1, n):
                if self_array_form[j] < self_array_form[i]:
                    val += 1
            inversion_vector[i] = val
        return inversion_vector

    def rank_trotterjohnson(self):
        if self.array_form == [] or self.is_Identity:
            return 0
        if self.array_form == [1, 0]:
            return 1
        perm = self.array_form
        n = self.size
        rank = 0
        for j in range(1, n):
            k = 1
            i = 0
            while perm[i] != j:
                if perm[i] < j:
                    k += 1
                i += 1
            j1 = j + 1
            if rank % 2 == 0:
                rank = j1 * rank + j1 - k
            else:
                rank = j1 * rank + k - 1
        return rank

    @classmethod
    def unrank_trotterjohnson(cls, size, rank):
        perm = [0] * size
        r2 = 0
        n = factorial(size)
        pj = 1
        for j in range(2, size + 1):
            pj *= j
            r1 = rank * pj // n
            k = r1 - j * r2
            if r2 % 2 == 0:
                for i in range(j - 1, j - k - 1, -1):
                    perm[i] = perm[i - 1]
                perm[j - k - 1] = j - 1
            else:
                for i in range(j - 1, k, -1):
                    perm[i] = perm[i - 1]
                perm[k] = j - 1
            r2 = r1
        return cls._af_new(perm)

    def next_trotterjohnson(self):
        pi = self.array_form[:]
        n = len(pi)
        st = 0
        rho = pi[:]
        done = False
        m = n - 1
        while m > 0 and (not done):
            d = rho.index(m)
            for i in range(d, m):
                rho[i] = rho[i + 1]
            par = _af_parity(rho[:m])
            if par == 1:
                if d == m:
                    m -= 1
                else:
                    pi[st + d], pi[st + d + 1] = (pi[st + d + 1], pi[st + d])
                    done = True
            elif d == 0:
                m -= 1
                st += 1
            else:
                pi[st + d], pi[st + d - 1] = (pi[st + d - 1], pi[st + d])
                done = True
        if m == 0:
            return None
        return self._af_new(pi)

    def get_precedence_matrix(self):
        m = zeros(self.size)
        perm = self.array_form
        for i in range(m.rows):
            for j in range(i + 1, m.cols):
                m[perm[i], perm[j]] = 1
        return m

    def get_precedence_distance(self, other):
        if self.size != other.size:
            raise ValueError('The permutations must be of equal size.')
        self_prec_mat = self.get_precedence_matrix()
        other_prec_mat = other.get_precedence_matrix()
        n_prec = 0
        for i in range(self.size):
            for j in range(self.size):
                if i == j:
                    continue
                if self_prec_mat[i, j] * other_prec_mat[i, j] == 1:
                    n_prec += 1
        d = self.size * (self.size - 1) // 2 - n_prec
        return d

    def get_adjacency_matrix(self):
        m = zeros(self.size)
        perm = self.array_form
        for i in range(self.size - 1):
            m[perm[i], perm[i + 1]] = 1
        return m

    def get_adjacency_distance(self, other):
        if self.size != other.size:
            raise ValueError('The permutations must be of the same size.')
        self_adj_mat = self.get_adjacency_matrix()
        other_adj_mat = other.get_adjacency_matrix()
        n_adj = 0
        for i in range(self.size):
            for j in range(self.size):
                if i == j:
                    continue
                if self_adj_mat[i, j] * other_adj_mat[i, j] == 1:
                    n_adj += 1
        d = self.size - n_adj - 1
        return d

    def get_positional_distance(self, other):
        a = self.array_form
        b = other.array_form
        if len(a) != len(b):
            raise ValueError('The permutations must be of the same size.')
        return sum((abs(a[i] - b[i]) for i in range(len(a))))

    @classmethod
    def josephus(cls, m, n, s=1):
        from collections import deque
        m -= 1
        Q = deque(list(range(n)))
        perm = []
        while len(Q) > max(s, 1):
            for dp in range(m):
                Q.append(Q.popleft())
            perm.append(Q.popleft())
        perm.extend(list(Q))
        return cls(perm)

    @classmethod
    def from_inversion_vector(cls, inversion):
        size = len(inversion)
        N = list(range(size + 1))
        perm = []
        try:
            for k in range(size):
                val = N[inversion[k]]
                perm.append(val)
                N.remove(val)
        except IndexError:
            raise ValueError('The inversion vector is not valid.')
        perm.extend(N)
        return cls._af_new(perm)

    @classmethod
    def random(cls, n):
        perm_array = list(range(n))
        random.shuffle(perm_array)
        return cls._af_new(perm_array)

    @classmethod
    def unrank_lex(cls, size, rank):
        perm_array = [0] * size
        psize = 1
        for i in range(size):
            new_psize = psize * (i + 1)
            d = rank % new_psize // psize
            rank -= d * psize
            perm_array[size - i - 1] = d
            for j in range(size - i, size):
                if perm_array[j] > d - 1:
                    perm_array[j] += 1
            psize = new_psize
        return cls._af_new(perm_array)

    def resize(self, n):
        aform = self.array_form
        l = len(aform)
        if n > l:
            aform += list(range(l, n))
            return Permutation._af_new(aform)
        elif n < l:
            cyclic_form = self.full_cyclic_form
            new_cyclic_form = []
            for cycle in cyclic_form:
                cycle_min = min(cycle)
                cycle_max = max(cycle)
                if cycle_min <= n - 1:
                    if cycle_max > n - 1:
                        raise ValueError('The permutation cannot be resized to {} because the cycle {} may break.'.format(n, tuple(cycle)))
                    new_cyclic_form.append(cycle)
            return Permutation(new_cyclic_form)
        return self
    print_cyclic = None

def _merge(arr, temp, left, mid, right):
    i = k = left
    j = mid
    inv_count = 0
    while i < mid and j <= right:
        if arr[i] < arr[j]:
            temp[k] = arr[i]
            k += 1
            i += 1
        else:
            temp[k] = arr[j]
            k += 1
            j += 1
            inv_count += mid - i
    while i < mid:
        temp[k] = arr[i]
        k += 1
        i += 1
    if j <= right:
        k += right - j + 1
        j += right - j + 1
        arr[left:k + 1] = temp[left:k + 1]
    else:
        arr[left:right + 1] = temp[left:right + 1]
    return inv_count
Perm = Permutation
_af_new = Perm._af_new

class AppliedPermutation(Expr):

    def __new__(cls, perm, x, evaluate=None):
        if evaluate is None:
            evaluate = global_parameters.evaluate
        perm = _sympify(perm)
        x = _sympify(x)
        if not isinstance(perm, Permutation):
            raise ValueError('{} must be a Permutation instance.'.format(perm))
        if evaluate:
            if x.is_Integer:
                return perm.apply(x)
        obj = super().__new__(cls, perm, x)
        return obj

@dispatch(Permutation, Permutation)
def _eval_is_eq(lhs, rhs):
    if lhs._size != rhs._size:
        return None
    return lhs._array_form == rhs._array_form