from __future__ import annotations
from sympy.combinatorics.group_constructs import DirectProduct
from sympy.combinatorics.perm_groups import PermutationGroup
from sympy.combinatorics.permutations import Permutation
_af_new = Permutation._af_new

def AbelianGroup(*cyclic_orders):
    groups = []
    degree = 0
    order = 1
    for size in cyclic_orders:
        degree += size
        order *= size
        groups.append(CyclicGroup(size))
    G = DirectProduct(*groups)
    G._is_abelian = True
    G._degree = degree
    G._order = order
    return G

def AlternatingGroup(n):
    if n == 1:
        G = PermutationGroup([Permutation([0])])
    elif n == 2:
        G = PermutationGroup([Permutation([0, 1])])
    else:
        a = list(range(n))
        a[0], a[1], a[2] = (a[1], a[2], a[0])
        gen1 = a
        if n % 2:
            a = list(range(1, n))
            a.append(0)
            gen2 = a
        else:
            a = list(range(2, n))
            a.append(1)
            a.insert(0, 0)
            gen2 = a
        gens = [gen1, gen2]
        if gen1 == gen2:
            gens = gens[:1]
        G = PermutationGroup([_af_new(a) for a in gens], dups=False)
    set_alternating_group_properties(G, n, n)
    G._is_alt = True
    return G

def set_alternating_group_properties(G, n, degree):
    if n < 3:
        G._order = 1
    if n < 4:
        G._is_abelian = True
        G._is_nilpotent = True
    else:
        G._is_abelian = False
        G._is_nilpotent = False
    if n < 5:
        G._is_solvable = True
    else:
        G._is_solvable = False
    G._degree = degree
    if n == 2:
        G._is_transitive = False
    else:
        G._is_transitive = True
    G._is_dihedral = False

def CyclicGroup(n):
    a = list(range(1, n))
    a.append(0)
    gen = _af_new(a)
    G = PermutationGroup([gen])
    G._is_abelian = True
    G._is_nilpotent = True
    G._is_solvable = True
    G._degree = n
    G._is_transitive = True
    G._order = n
    G._is_dihedral = n == 2
    return G

def DihedralGroup(n):
    if n == 1:
        return PermutationGroup([Permutation([1, 0])])
    if n == 2:
        return PermutationGroup([Permutation([1, 0, 3, 2]), Permutation([2, 3, 0, 1]), Permutation([3, 2, 1, 0])])
    a = list(range(1, n))
    a.append(0)
    gen1 = _af_new(a)
    a = list(range(n))
    a.reverse()
    gen2 = _af_new(a)
    G = PermutationGroup([gen1, gen2])
    if n & n - 1 == 0:
        G._is_nilpotent = True
    else:
        G._is_nilpotent = False
    G._is_dihedral = True
    G._is_abelian = False
    G._is_solvable = True
    G._degree = n
    G._is_transitive = True
    G._order = 2 * n
    return G

def SymmetricGroup(n):
    if n == 1:
        G = PermutationGroup([Permutation([0])])
    elif n == 2:
        G = PermutationGroup([Permutation([1, 0])])
    else:
        a = list(range(1, n))
        a.append(0)
        gen1 = _af_new(a)
        a = list(range(n))
        a[0], a[1] = (a[1], a[0])
        gen2 = _af_new(a)
        G = PermutationGroup([gen1, gen2])
    set_symmetric_group_properties(G, n, n)
    G._is_sym = True
    return G

def set_symmetric_group_properties(G, n, degree):
    if n < 3:
        G._is_abelian = True
        G._is_nilpotent = True
    else:
        G._is_abelian = False
        G._is_nilpotent = False
    if n < 5:
        G._is_solvable = True
    else:
        G._is_solvable = False
    G._degree = degree
    G._is_transitive = True
    G._is_dihedral = n in [2, 3]

def RubikGroup(n):
    from sympy.combinatorics.generators import rubik
    if n <= 1:
        raise ValueError('Invalid cube. n has to be greater than 1')
    return PermutationGroup(rubik(n))