from __future__ import annotations
from sympy.core import Basic, Dict, sympify, Tuple
from sympy.core.numbers import Integer
from sympy.core.sorting import default_sort_key
from sympy.core.sympify import _sympify
from sympy.functions.combinatorial.numbers import bell
from sympy.matrices import zeros
from sympy.sets.sets import FiniteSet, Union
from sympy.utilities.iterables import flatten, group
from sympy.utilities.misc import as_int
from collections import defaultdict

class Partition(FiniteSet):
    _rank = None
    _partition = None

    def __new__(cls, *partition):
        args = []
        dups = False
        for arg in partition:
            if isinstance(arg, list):
                as_set = set(arg)
                if len(as_set) < len(arg):
                    dups = True
                    break
                arg = as_set
            args.append(_sympify(arg))
        if not all((isinstance(part, FiniteSet) for part in args)):
            raise ValueError('Each argument to Partition should be a list, set, or a FiniteSet')
        U = Union(*args)
        if dups or len(U) < sum((len(arg) for arg in args)):
            raise ValueError('Partition contained duplicate elements.')
        obj = FiniteSet.__new__(cls, *args)
        obj.members = tuple(U)
        obj.size = len(U)
        return obj

    def sort_key(self, order=None):
        if order is None:
            members = self.members
        else:
            members = tuple(sorted(self.members, key=lambda w: default_sort_key(w, order)))
        return tuple(map(default_sort_key, (self.size, members, self.rank)))

    @property
    def partition(self):
        if self._partition is None:
            self._partition = sorted([sorted(p, key=default_sort_key) for p in self.args])
        return [part[:] for part in self._partition]

    def __add__(self, other):
        other = as_int(other)
        offset = self.rank + other
        result = RGS_unrank(offset % RGS_enum(self.size), self.size)
        return Partition.from_rgs(result, self.members)

    def __sub__(self, other):
        return self.__add__(-other)

    def __le__(self, other):
        return self.sort_key() <= sympify(other).sort_key()

    def __lt__(self, other):
        return self.sort_key() < sympify(other).sort_key()

    @property
    def rank(self):
        if self._rank is not None:
            return self._rank
        self._rank = RGS_rank(self.RGS)
        return self._rank

    @property
    def RGS(self):
        rgs = {}
        partition = self.partition
        for i, part in enumerate(partition):
            for j in part:
                rgs[j] = i
        return tuple([rgs[i] for i in sorted([i for p in partition for i in p], key=default_sort_key)])

    @classmethod
    def from_rgs(self, rgs, elements):
        if len(rgs) != len(elements):
            raise ValueError('mismatch in rgs and element lengths')
        max_elem = max(rgs) + 1
        partition = [[] for i in range(max_elem)]
        for j, i in enumerate(rgs):
            partition[i].append(elements[j])
        if not all((p for p in partition)):
            raise ValueError('some blocks of the partition were empty.')
        return Partition(*partition)

class IntegerPartition(Basic):
    _dict = None
    _keys = None

    def __new__(cls, partition, integer=None):
        if integer is not None:
            integer, partition = (partition, integer)
        if isinstance(partition, (dict, Dict)):
            _ = []
            for k, v in sorted(partition.items(), reverse=True):
                if not v:
                    continue
                k, v = (as_int(k), as_int(v))
                _.extend([k] * v)
            partition = tuple(_)
        else:
            partition = tuple(sorted(map(as_int, partition), reverse=True))
        sum_ok = False
        if integer is None:
            integer = sum(partition)
            sum_ok = True
        else:
            integer = as_int(integer)
        if not sum_ok and sum(partition) != integer:
            raise ValueError('Partition did not add to %s' % integer)
        if any((i < 1 for i in partition)):
            raise ValueError('All integer summands must be greater than one')
        obj = Basic.__new__(cls, Integer(integer), Tuple(*partition))
        obj.partition = list(partition)
        obj.integer = integer
        return obj

    def prev_lex(self):
        d = defaultdict(int)
        d.update(self.as_dict())
        keys = self._keys
        if keys == [1]:
            return IntegerPartition({self.integer: 1})
        if keys[-1] != 1:
            d[keys[-1]] -= 1
            if keys[-1] == 2:
                d[1] = 2
            else:
                d[keys[-1] - 1] = d[1] = 1
        else:
            d[keys[-2]] -= 1
            left = d[1] + keys[-2]
            new = keys[-2]
            d[1] = 0
            while left:
                new -= 1
                if left - new >= 0:
                    d[new] += left // new
                    left -= d[new] * new
        return IntegerPartition(self.integer, d)

    def next_lex(self):
        d = defaultdict(int)
        d.update(self.as_dict())
        key = self._keys
        a = key[-1]
        if a == self.integer:
            d.clear()
            d[1] = self.integer
        elif a == 1:
            if d[a] > 1:
                d[a + 1] += 1
                d[a] -= 2
            else:
                b = key[-2]
                d[b + 1] += 1
                d[1] = (d[b] - 1) * b
                d[b] = 0
        elif d[a] > 1:
            if len(key) == 1:
                d.clear()
                d[a + 1] = 1
                d[1] = self.integer - a - 1
            else:
                a1 = a + 1
                d[a1] += 1
                d[1] = d[a] * a - a1
                d[a] = 0
        else:
            b = key[-2]
            b1 = b + 1
            d[b1] += 1
            need = d[b] * b + d[a] * a - b1
            d[a] = d[b] = 0
            d[1] = need
        return IntegerPartition(self.integer, d)

    def as_dict(self):
        if self._dict is None:
            groups = group(self.partition, multiple=False)
            self._keys = [g[0] for g in groups]
            self._dict = dict(groups)
        return self._dict.copy()

    @property
    def conjugate(self):
        j = 1
        temp_arr = list(self.partition) + [0]
        k = temp_arr[0]
        b = [0] * k
        while k > 0:
            while k > temp_arr[j]:
                b[k - 1] = j
                k -= 1
            j += 1
        return b

    def __lt__(self, other):
        return list(reversed(self.partition)) < list(reversed(other.partition))

    def __le__(self, other):
        return list(reversed(self.partition)) <= list(reversed(other.partition))

    def as_ferrers(self, char='#'):
        return '\n'.join([char * i for i in self.partition])

    def __str__(self):
        return str(list(self.partition))

def random_integer_partition(n, seed=None):
    from sympy.core.random import _randint
    n = as_int(n)
    if n < 1:
        raise ValueError('n must be a positive integer')
    randint = _randint(seed)
    partition = []
    while n > 0:
        k = randint(1, n)
        mult = randint(1, n // k)
        partition.append((k, mult))
        n -= k * mult
    partition.sort(reverse=True)
    partition = flatten([[k] * m for k, m in partition])
    return partition

def RGS_generalized(m):
    d = zeros(m + 1)
    for i in range(m + 1):
        d[0, i] = 1
    for i in range(1, m + 1):
        for j in range(m):
            if j <= m - i:
                d[i, j] = j * d[i - 1, j] + d[i - 1, j + 1]
            else:
                d[i, j] = 0
    return d

def RGS_enum(m):
    if m < 1:
        return 0
    elif m == 1:
        return 1
    else:
        return bell(m)

def RGS_unrank(rank, m):
    if m < 1:
        raise ValueError('The superset size must be >= 1')
    if rank < 0 or RGS_enum(m) <= rank:
        raise ValueError('Invalid arguments')
    L = [1] * (m + 1)
    j = 1
    D = RGS_generalized(m)
    for i in range(2, m + 1):
        v = D[m - i, j]
        cr = j * v
        if cr <= rank:
            L[i] = j + 1
            rank -= cr
            j += 1
        else:
            L[i] = int(rank / v + 1)
            rank %= v
    return [x - 1 for x in L[1:]]

def RGS_rank(rgs):
    rgs_size = len(rgs)
    rank = 0
    D = RGS_generalized(rgs_size)
    for i in range(1, rgs_size):
        n = len(rgs[i + 1:])
        m = max(rgs[0:i])
        rank += D[n, m + 1] * rgs[i]
    return rank