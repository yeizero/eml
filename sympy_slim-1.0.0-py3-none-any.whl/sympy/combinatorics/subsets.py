from __future__ import annotations
from itertools import combinations
from sympy.combinatorics.graycode import GrayCode

class Subset:
    _rank_binary = None
    _rank_lex = None
    _rank_graycode = None
    _subset = None
    _superset = None

    def __new__(cls, subset, superset):
        if len(subset) > len(superset):
            raise ValueError('Invalid arguments have been provided. The superset must be larger than the subset.')
        for elem in subset:
            if elem not in superset:
                raise ValueError('The superset provided is invalid as it does not contain the element {}'.format(elem))
        obj = object.__new__(cls)
        obj._subset = subset
        obj._superset = superset
        return obj

    def __eq__(self, other):
        if not isinstance(other, Subset):
            return NotImplemented
        return self.subset == other.subset and self.superset == other.superset

    def iterate_binary(self, k):
        bin_list = Subset.bitlist_from_subset(self.subset, self.superset)
        n = (int(''.join(bin_list), 2) + k) % 2 ** self.superset_size
        bits = f'{n:b}'.rjust(self.superset_size, '0')
        return Subset.subset_from_bitlist(self.superset, bits)

    def next_binary(self):
        return self.iterate_binary(1)

    def prev_binary(self):
        return self.iterate_binary(-1)

    def next_lexicographic(self):
        i = self.superset_size - 1
        indices = Subset.subset_indices(self.subset, self.superset)
        if i in indices:
            if i - 1 in indices:
                indices.remove(i - 1)
            else:
                indices.remove(i)
                i = i - 1
                while i >= 0 and i not in indices:
                    i = i - 1
                if i >= 0:
                    indices.remove(i)
                    indices.append(i + 1)
        else:
            while i not in indices and i >= 0:
                i = i - 1
            indices.append(i + 1)
        ret_set = []
        super_set = self.superset
        for i in indices:
            ret_set.append(super_set[i])
        return Subset(ret_set, super_set)

    def prev_lexicographic(self):
        i = self.superset_size - 1
        indices = Subset.subset_indices(self.subset, self.superset)
        while i >= 0 and i not in indices:
            i = i - 1
        if i == 0 or i - 1 in indices:
            indices.remove(i)
        else:
            if i >= 0:
                indices.remove(i)
                indices.append(i - 1)
            indices.append(self.superset_size - 1)
        ret_set = []
        super_set = self.superset
        for i in indices:
            ret_set.append(super_set[i])
        return Subset(ret_set, super_set)

    def iterate_graycode(self, k):
        unranked_code = GrayCode.unrank(self.superset_size, (self.rank_gray + k) % self.cardinality)
        return Subset.subset_from_bitlist(self.superset, unranked_code)

    def next_gray(self):
        return self.iterate_graycode(1)

    def prev_gray(self):
        return self.iterate_graycode(-1)

    @property
    def rank_binary(self):
        if self._rank_binary is None:
            self._rank_binary = int(''.join(Subset.bitlist_from_subset(self.subset, self.superset)), 2)
        return self._rank_binary

    @property
    def rank_lexicographic(self):
        if self._rank_lex is None:

            def _ranklex(self, subset_index, i, n):
                if subset_index == [] or i > n:
                    return 0
                if i in subset_index:
                    subset_index.remove(i)
                    return 1 + _ranklex(self, subset_index, i + 1, n)
                return 2 ** (n - i - 1) + _ranklex(self, subset_index, i + 1, n)
            indices = Subset.subset_indices(self.subset, self.superset)
            self._rank_lex = _ranklex(self, indices, 0, self.superset_size)
        return self._rank_lex

    @property
    def rank_gray(self):
        if self._rank_graycode is None:
            bits = Subset.bitlist_from_subset(self.subset, self.superset)
            self._rank_graycode = GrayCode(len(bits), start=bits).rank
        return self._rank_graycode

    @property
    def subset(self):
        return self._subset[:]

    @property
    def size(self):
        return len(self.subset)

    @property
    def superset(self):
        return self._superset[:]

    @property
    def superset_size(self):
        return len(self.superset)

    @property
    def cardinality(self):
        return 2 ** self.superset_size

    @classmethod
    def subset_from_bitlist(self, super_set, bitlist):
        if len(super_set) != len(bitlist):
            raise ValueError('The sizes of the lists are not equal')
        ret_set = []
        for i in range(len(bitlist)):
            if bitlist[i] == '1':
                ret_set.append(super_set[i])
        return Subset(ret_set, super_set)

    @classmethod
    def bitlist_from_subset(self, subset, superset):
        bitlist = ['0'] * len(superset)
        if isinstance(subset, Subset):
            subset = subset.subset
        for i in Subset.subset_indices(subset, superset):
            bitlist[i] = '1'
        return ''.join(bitlist)

    @classmethod
    def unrank_binary(self, rank, superset):
        bits = f'{rank:b}'.rjust(len(superset), '0')
        return Subset.subset_from_bitlist(superset, bits)

    @classmethod
    def unrank_gray(self, rank, superset):
        graycode_bitlist = GrayCode.unrank(len(superset), rank)
        return Subset.subset_from_bitlist(superset, graycode_bitlist)

    @classmethod
    def subset_indices(self, subset, superset):
        a, b = (superset, subset)
        sb = set(b)
        d = {}
        for i, ai in enumerate(a):
            if ai in sb:
                d[ai] = i
                sb.remove(ai)
                if not sb:
                    break
        else:
            return []
        return [d[bi] for bi in b]

def ksubsets(superset, k):
    return combinations(superset, k)