from __future__ import annotations
import math
from sympy.core import S
from sympy.core.basic import Basic
from sympy.core.function import Function
from sympy.core.numbers import Integer

class SchurNumber(Function):

    @classmethod
    def eval(cls, k):
        if k.is_Number:
            if k is S.Infinity:
                return S.Infinity
            if k.is_zero:
                return S.Zero
            if not k.is_integer or k.is_negative:
                raise ValueError('k should be a positive integer')
            first_known_schur_numbers = {1: 1, 2: 4, 3: 13, 4: 44, 5: 160}
            if k <= 5:
                return Integer(first_known_schur_numbers[k])

    def lower_bound(self):
        f_ = self.args[0]
        if f_ == 6:
            return Integer(536)
        if f_ == 7:
            return Integer(1680)
        if f_.is_Integer:
            return 3 * self.func(f_ - 1).lower_bound() - 1
        return (3 ** f_ - 1) / 2

def _schur_subsets_number(n):
    if n is S.Infinity:
        raise ValueError('Input must be finite')
    if n <= 0:
        raise ValueError('n must be a non-zero positive integer.')
    elif n <= 3:
        min_k = 1
    else:
        min_k = math.ceil(math.log(2 * n + 1, 3))
    return Integer(min_k)

def schur_partition(n):
    if isinstance(n, Basic) and (not n.is_Number):
        raise ValueError('Input value must be a number')
    number_of_subsets = _schur_subsets_number(n)
    if n == 1:
        sum_free_subsets = [[1]]
    elif n == 2:
        sum_free_subsets = [[1, 2]]
    elif n == 3:
        sum_free_subsets = [[1, 2, 3]]
    else:
        sum_free_subsets = [[1, 4], [2, 3]]
    while len(sum_free_subsets) < number_of_subsets:
        sum_free_subsets = _generate_next_list(sum_free_subsets, n)
        missed_elements = [3 * k + 1 for k in range(len(sum_free_subsets), (n - 1) // 3 + 1)]
        sum_free_subsets[-1] += missed_elements
    return sum_free_subsets

def _generate_next_list(current_list, n):
    new_list = []
    for item in current_list:
        temp_1 = [number * 3 for number in item if number * 3 <= n]
        temp_2 = [number * 3 - 1 for number in item if number * 3 - 1 <= n]
        new_item = temp_1 + temp_2
        new_list.append(new_item)
    last_list = [3 * k + 1 for k in range(len(current_list) + 1) if 3 * k + 1 <= n]
    new_list.append(last_list)
    current_list = new_list
    return current_list