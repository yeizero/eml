from __future__ import annotations
from typing import Iterator, Any, TypeVar
from sympy.core import Basic, Integer
import random
T = TypeVar('T')

class GrayCode(Basic):
    _skip = False
    _current = 0
    _rank = None

    def __new__(cls: type[GrayCode], n: int, *args: Any, **kw_args: Any) -> GrayCode:
        if n < 1 or int(n) != n:
            raise ValueError('Gray code dimension must be a positive integer, not %i' % n)
        n = Integer(n)
        args = (n,) + args
        obj = Basic.__new__(cls, *args)
        if 'start' in kw_args:
            obj._current = kw_args['start']
            if len(obj._current) > n:
                raise ValueError('Gray code start has length %i but should not be greater than %i' % (len(obj._current), n))
        elif 'rank' in kw_args:
            if int(kw_args['rank']) != kw_args['rank']:
                raise ValueError('Gray code rank must be a positive integer, not %i' % kw_args['rank'])
            obj._rank = int(kw_args['rank']) % obj.selections
            obj._current = obj.unrank(n, obj._rank)
        return obj

    def next(self, delta: int=1) -> GrayCode:
        return GrayCode(self.n, rank=(self.rank + delta) % self.selections)

    @property
    def selections(self):
        return 2 ** self.n

    @property
    def n(self):
        return self.args[0]

    def generate_gray(self, **hints: Any) -> Iterator[str]:
        bits = self.n
        start = None
        if 'start' in hints:
            start = hints['start']
        elif 'rank' in hints:
            start = GrayCode.unrank(self.n, hints['rank'])
        if start is not None:
            self._current = start
        current = self.current
        graycode_bin = gray_to_bin(current)
        if len(graycode_bin) > self.n:
            raise ValueError('Gray code start has length %i but should not be greater than %i' % (len(graycode_bin), bits))
        self._current = int(current, 2)
        graycode_int = int(''.join(graycode_bin), 2)
        for i in range(graycode_int, 1 << bits):
            if self._skip:
                self._skip = False
            else:
                yield self.current
            bbtc = i ^ i + 1
            gbtc = bbtc ^ bbtc >> 1
            self._current = self._current ^ gbtc
        self._current = 0

    def skip(self):
        self._skip = True

    @property
    def rank(self):
        if self._rank is None:
            self._rank = int(gray_to_bin(self.current), 2)
        return self._rank

    @property
    def current(self):
        rv = self._current or '0'
        if not isinstance(rv, str):
            rv = f'{rv:b}'
        return rv.rjust(self.n, '0')

    @classmethod
    def unrank(cls, n: int | Basic, rank: int) -> str:

        def _unrank(k, n):
            if n == 1:
                return str(k % 2)
            m = 2 ** (n - 1)
            if k < m:
                return '0' + _unrank(k, n - 1)
            return '1' + _unrank(m - k % m - 1, n - 1)
        return _unrank(rank, n)

def random_bitstring(n: int) -> str:
    return ''.join([random.choice('01') for i in range(n)])

def gray_to_bin(bin_list: str) -> str:
    b = [bin_list[0]]
    for i in range(1, len(bin_list)):
        b += str(int(b[i - 1] != bin_list[i]))
    return ''.join(b)

def bin_to_gray(bin_list: str) -> str:
    b = [bin_list[0]]
    for i in range(1, len(bin_list)):
        b += str(int(bin_list[i]) ^ int(bin_list[i - 1]))
    return ''.join(b)

def get_subset_from_bitstring(super_set: list[T], bitstring: str) -> list[T]:
    if len(super_set) != len(bitstring):
        raise ValueError('The sizes of the lists are not equal')
    return [super_set[i] for i, j in enumerate(bitstring) if bitstring[i] == '1']

def graycode_subsets(gray_code_set: list[T]) -> Iterator[list[T]]:
    for bitstring in list(GrayCode(len(gray_code_set)).generate_gray()):
        yield get_subset_from_bitstring(gray_code_set, bitstring)