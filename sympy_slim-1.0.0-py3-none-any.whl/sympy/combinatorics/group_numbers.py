from __future__ import annotations
from itertools import chain, combinations
from sympy.external.gmpy import gcd
from sympy.ntheory.factor_ import factorint
from sympy.utilities.misc import as_int

def _is_nilpotent_number(factors: dict) -> bool:
    for p in factors.keys():
        for q, e in factors.items():
            m = 1
            for _ in range(e):
                m = m * q % p
                if m == 1:
                    return False
    return True

def is_nilpotent_number(n) -> bool:
    n = as_int(n)
    if n <= 0:
        raise ValueError('n must be a positive integer, not %i' % n)
    return _is_nilpotent_number(factorint(n))

def is_abelian_number(n) -> bool:
    n = as_int(n)
    if n <= 0:
        raise ValueError('n must be a positive integer, not %i' % n)
    factors = factorint(n)
    return all((e < 3 for e in factors.values())) and _is_nilpotent_number(factors)

def is_cyclic_number(n) -> bool:
    n = as_int(n)
    if n <= 0:
        raise ValueError('n must be a positive integer, not %i' % n)
    factors = factorint(n)
    return all((e == 1 for e in factors.values())) and _is_nilpotent_number(factors)

def _holder_formula(prime_factors):
    F = {p for p in prime_factors if all((q % p != 1 for q in prime_factors))}
    M = prime_factors - F
    s = 0
    powerset = chain.from_iterable((combinations(M, r) for r in range(len(M) + 1)))
    for ps in powerset:
        ps = set(ps)
        prod = 1
        for p in M - ps:
            c = len([q for q in F | ps if q % p == 1])
            prod *= (p ** c - 1) // (p - 1)
            if not prod:
                break
        s += prod
    return s

def groups_count(n):
    n = as_int(n)
    if n <= 0:
        raise ValueError('n must be a positive integer, not %i' % n)
    factors = factorint(n)
    if len(factors) == 1:
        p, e = list(factors.items())[0]
        if p == 2:
            A000679 = [1, 1, 2, 5, 14, 51, 267, 2328, 56092, 10494213, 49487367289]
            if e < len(A000679):
                return A000679[e]
        if p == 3:
            A090091 = [1, 1, 2, 5, 15, 67, 504, 9310, 1396077, 5937876645]
            if e < len(A090091):
                return A090091[e]
        if e <= 2:
            return e
        if e == 3:
            return 5
        if e == 4:
            return 15
        if e == 5:
            return 61 + 2 * p + 2 * gcd(p - 1, 3) + gcd(p - 1, 4)
        if e == 6:
            return 3 * p ** 2 + 39 * p + 344 + 24 * gcd(p - 1, 3) + 11 * gcd(p - 1, 4) + 2 * gcd(p - 1, 5)
        if e == 7:
            if p == 5:
                return 34297
            return 3 * p ** 5 + 12 * p ** 4 + 44 * p ** 3 + 170 * p ** 2 + 707 * p + 2455 + (4 * p ** 2 + 44 * p + 291) * gcd(p - 1, 3) + (p ** 2 + 19 * p + 135) * gcd(p - 1, 4) + (3 * p + 31) * gcd(p - 1, 5) + 4 * gcd(p - 1, 7) + 5 * gcd(p - 1, 8) + gcd(p - 1, 9)
    if any((e > 1 for e in factors.values())):
        small = {12: 5, 18: 5, 20: 5, 24: 15, 28: 4, 36: 14, 40: 14, 44: 4, 45: 2, 48: 52, 50: 5, 52: 5, 54: 15, 56: 13, 60: 13, 63: 4, 68: 5, 72: 50, 75: 3, 76: 4, 80: 52, 84: 15, 88: 12, 90: 10, 92: 4}
        if n in small:
            return small[n]
        raise ValueError('Number of groups of order n is unknown or not implemented')
    if len(factors) == 2:
        p, q = sorted(factors.keys())
        return 2 if q % p == 1 else 1
    return _holder_formula(set(factors.keys()))