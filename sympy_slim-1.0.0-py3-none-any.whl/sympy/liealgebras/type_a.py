from __future__ import annotations
from sympy.liealgebras.cartan_type import Standard_Cartan
from sympy.core.backend import eye

class TypeA(Standard_Cartan):

    def __new__(cls, n):
        if n < 1:
            raise ValueError('n cannot be less than 1')
        return Standard_Cartan.__new__(cls, 'A', n)

    def dimension(self):
        return self.n + 1

    def basic_root(self, i, j):
        n = self.n
        root = [0] * (n + 1)
        root[i] = 1
        root[j] = -1
        return root

    def simple_root(self, i):
        return self.basic_root(i - 1, i)

    def positive_roots(self):
        n = self.n
        posroots = {}
        k = 0
        for i in range(0, n):
            for j in range(i + 1, n + 1):
                k += 1
                posroots[k] = self.basic_root(i, j)
        return posroots

    def highest_root(self):
        return self.basic_root(0, self.n)

    def roots(self):
        n = self.n
        return n * (n + 1)

    def cartan_matrix(self):
        n = self.n
        m = 2 * eye(n)
        for i in range(1, n - 1):
            m[i, i + 1] = -1
            m[i, i - 1] = -1
        m[0, 1] = -1
        m[n - 1, n - 2] = -1
        return m

    def basis(self):
        n = self.n
        return n ** 2 - 1

    def lie_algebra(self):
        n = self.n
        return 'su(' + str(n + 1) + ')'

    def dynkin_diagram(self):
        n = self.n
        diag = '---'.join(('0' for i in range(1, n + 1))) + '\n'
        diag += '   '.join((str(i) for i in range(1, n + 1)))
        return diag