from __future__ import annotations
from .cartan_type import CartanType

def CartanMatrix(ct):
    return CartanType(ct).cartan_matrix()