from __future__ import annotations
from .cartan_type import Standard_Cartan
from sympy.core.backend import eye

class TypeC(Standard_Cartan):

    def __new__(cls, n):
        if n < 3:
            raise ValueError('n cannot be less than 3')
        return Standard_Cartan.__new__(cls, 'C', n)

    def dimension(self):
        n = self.n
        return n

    def basic_root(self, i, j):
        n = self.n
        root = [0] * n
        root[i] = 1
        root[j] = -1
        return root

    def simple_root(self, i):
        n = self.n
        if i < n:
            return self.basic_root(i - 1, i)
        else:
            root = [0] * self.n
            root[n - 1] = 2
            return root

    def positive_roots(self):
        n = self.n
        posroots = {}
        k = 0
        for i in range(0, n - 1):
            for j in range(i + 1, n):
                k += 1
                posroots[k] = self.basic_root(i, j)
                k += 1
                root = self.basic_root(i, j)
                root[j] = 1
                posroots[k] = root
        for i in range(0, n):
            k += 1
            root = [0] * n
            root[i] = 2
            posroots[k] = root
        return posroots

    def roots(self):
        n = self.n
        return 2 * n ** 2

    def cartan_matrix(self):
        n = self.n
        m = 2 * eye(n)
        for i in range(1, n - 1):
            m[i, i + 1] = -1
            m[i, i - 1] = -1
        m[0, 1] = -1
        m[n - 1, n - 2] = -2
        return m

    def basis(self):
        n = self.n
        return n * (2 * n + 1)

    def lie_algebra(self):
        n = self.n
        return 'sp(' + str(2 * n) + ')'

    def dynkin_diagram(self):
        n = self.n
        diag = '---'.join(('0' for i in range(1, n))) + '=<=0\n'
        diag += '   '.join((str(i) for i in range(1, n + 1)))
        return diag