from __future__ import annotations
from .cartan_type import CartanType

def DynkinDiagram(t):
    return CartanType(t).dynkin_diagram()