from __future__ import annotations
from .cartan_type import Standard_Cartan
from sympy.core.backend import Matrix

class TypeG(Standard_Cartan):

    def __new__(cls, n):
        if n != 2:
            raise ValueError('n should be 2')
        return Standard_Cartan.__new__(cls, 'G', 2)

    def dimension(self):
        return 3

    def simple_root(self, i):
        if i == 1:
            return [0, 1, -1]
        else:
            return [1, -2, 1]

    def positive_roots(self):
        roots = {1: [0, 1, -1], 2: [1, -2, 1], 3: [1, -1, 0], 4: [1, 0, 1], 5: [1, 1, -2], 6: [2, -1, -1]}
        return roots

    def roots(self):
        return 12

    def cartan_matrix(self):
        m = Matrix(2, 2, [2, -1, -3, 2])
        return m

    def basis(self):
        return 14

    def dynkin_diagram(self):
        diag = '0≡<≡0\n1   2'
        return diag