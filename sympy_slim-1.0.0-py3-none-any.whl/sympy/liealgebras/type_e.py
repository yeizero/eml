from __future__ import annotations
import itertools
from .cartan_type import Standard_Cartan
from sympy.core.backend import eye, Rational
from sympy.core.singleton import S

class TypeE(Standard_Cartan):

    def __new__(cls, n):
        if n < 6 or n > 8:
            raise ValueError('Invalid value of n')
        return Standard_Cartan.__new__(cls, 'E', n)

    def dimension(self):
        return 8

    def basic_root(self, i, j):
        root = [0] * 8
        root[i] = -1
        root[j] = 1
        return root

    def simple_root(self, i):
        n = self.n
        if i == 1:
            root = [-0.5] * 8
            root[0] = 0.5
            root[7] = 0.5
            return root
        elif i == 2:
            root = [0] * 8
            root[1] = 1
            root[0] = 1
            return root
        else:
            if i in (7, 8) and n == 6:
                raise ValueError('E6 only has six simple roots!')
            if i == 8 and n == 7:
                raise ValueError('E7 only has seven simple roots!')
            return self.basic_root(i - 3, i - 2)

    def positive_roots(self):
        n = self.n
        neghalf = Rational(-1, 2)
        poshalf = S.Half
        if n == 6:
            posroots = {}
            k = 0
            for i in range(n - 1):
                for j in range(i + 1, n - 1):
                    k += 1
                    root = self.basic_root(i, j)
                    posroots[k] = root
                    k += 1
                    root = self.basic_root(i, j)
                    root[i] = 1
                    posroots[k] = root
            root = [poshalf, poshalf, poshalf, poshalf, poshalf, neghalf, neghalf, poshalf]
            for a, b, c, d, e in itertools.product(range(2), range(2), range(2), range(2), range(2)):
                if (a + b + c + d + e) % 2 == 0:
                    k += 1
                    if a == 1:
                        root[0] = neghalf
                    if b == 1:
                        root[1] = neghalf
                    if c == 1:
                        root[2] = neghalf
                    if d == 1:
                        root[3] = neghalf
                    if e == 1:
                        root[4] = neghalf
                    posroots[k] = root[:]
            return posroots
        if n == 7:
            posroots = {}
            k = 0
            for i in range(n - 1):
                for j in range(i + 1, n - 1):
                    k += 1
                    root = self.basic_root(i, j)
                    posroots[k] = root
                    k += 1
                    root = self.basic_root(i, j)
                    root[i] = 1
                    posroots[k] = root
            k += 1
            posroots[k] = [0, 0, 0, 0, 0, 1, 1, 0]
            root = [poshalf, poshalf, poshalf, poshalf, poshalf, neghalf, neghalf, poshalf]
            for a, b, c, d, e, f in itertools.product(range(2), range(2), range(2), range(2), range(2), range(2)):
                if (a + b + c + d + e + f) % 2 == 0:
                    k += 1
                    if a == 1:
                        root[0] = neghalf
                    if b == 1:
                        root[1] = neghalf
                    if c == 1:
                        root[2] = neghalf
                    if d == 1:
                        root[3] = neghalf
                    if e == 1:
                        root[4] = neghalf
                    if f == 1:
                        root[5] = poshalf
                    posroots[k] = root[:]
            return posroots
        if n == 8:
            posroots = {}
            k = 0
            for i in range(n):
                for j in range(i + 1, n):
                    k += 1
                    root = self.basic_root(i, j)
                    posroots[k] = root
                    k += 1
                    root = self.basic_root(i, j)
                    root[i] = 1
                    posroots[k] = root
            root = [poshalf, poshalf, poshalf, poshalf, poshalf, neghalf, neghalf, poshalf]
            for a, b, c, d, e, f, g in itertools.product(range(2), range(2), range(2), range(2), range(2), range(2), range(2)):
                if (a + b + c + d + e + f + g) % 2 == 0:
                    k += 1
                    if a == 1:
                        root[0] = neghalf
                    if b == 1:
                        root[1] = neghalf
                    if c == 1:
                        root[2] = neghalf
                    if d == 1:
                        root[3] = neghalf
                    if e == 1:
                        root[4] = neghalf
                    if f == 1:
                        root[5] = poshalf
                    if g == 1:
                        root[6] = poshalf
                    posroots[k] = root[:]
            return posroots

    def roots(self):
        n = self.n
        if n == 6:
            return 72
        if n == 7:
            return 126
        if n == 8:
            return 240

    def cartan_matrix(self):
        n = self.n
        m = 2 * eye(n)
        for i in range(3, n - 1):
            m[i, i + 1] = -1
            m[i, i - 1] = -1
        m[0, 2] = m[2, 0] = -1
        m[1, 3] = m[3, 1] = -1
        m[2, 3] = -1
        m[n - 1, n - 2] = -1
        return m

    def basis(self):
        n = self.n
        if n == 6:
            return 78
        if n == 7:
            return 133
        if n == 8:
            return 248

    def dynkin_diagram(self):
        n = self.n
        diag = ' ' * 8 + str(2) + '\n'
        diag += ' ' * 8 + '0\n'
        diag += ' ' * 8 + '|\n'
        diag += ' ' * 8 + '|\n'
        diag += '---'.join(('0' for i in range(1, n))) + '\n'
        diag += '1   ' + '   '.join((str(i) for i in range(3, n + 1)))
        return diag