from __future__ import annotations
from .cartan_type import CartanType
from sympy.core.basic import Atom

class RootSystem(Atom):

    def __new__(cls, cartantype):
        obj = Atom.__new__(cls)
        obj.cartan_type = CartanType(cartantype)
        return obj

    def simple_roots(self):
        n = self.cartan_type.rank()
        roots = {i: self.cartan_type.simple_root(i) for i in range(1, n + 1)}
        return roots

    def all_roots(self):
        alpha = self.cartan_type.positive_roots()
        keys = list(alpha.keys())
        k = max(keys)
        for val in keys:
            k += 1
            root = alpha[val]
            newroot = [-x for x in root]
            alpha[k] = newroot
        return alpha

    def root_space(self):
        n = self.cartan_type.rank()
        rs = ' + '.join(('alpha[' + str(i) + ']' for i in range(1, n + 1)))
        return rs

    def add_simple_roots(self, root1, root2):
        alpha = self.simple_roots()
        if root1 > len(alpha) or root2 > len(alpha):
            raise ValueError("You've used a root that doesn't exist!")
        a1 = alpha[root1]
        a2 = alpha[root2]
        newroot = [_a1 + _a2 for _a1, _a2 in zip(a1, a2)]
        return newroot

    def add_as_roots(self, root1, root2):
        alpha = self.all_roots()
        newroot = [r1 + r2 for r1, r2 in zip(root1, root2)]
        if newroot in alpha.values():
            return newroot
        else:
            return 'The sum of these two roots is not a root'

    def cartan_matrix(self):
        return self.cartan_type.cartan_matrix()

    def dynkin_diagram(self):
        return self.cartan_type.dynkin_diagram()