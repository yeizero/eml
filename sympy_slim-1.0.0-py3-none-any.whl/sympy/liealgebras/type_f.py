from __future__ import annotations
from .cartan_type import Standard_Cartan
from sympy.core.backend import Matrix, Rational

class TypeF(Standard_Cartan):

    def __new__(cls, n):
        if n != 4:
            raise ValueError('n should be 4')
        return Standard_Cartan.__new__(cls, 'F', 4)

    def dimension(self):
        return 4

    def basic_root(self, i, j):
        n = self.n
        root = [0] * n
        root[i] = 1
        root[j] = -1
        return root

    def simple_root(self, i):
        if i < 3:
            return self.basic_root(i - 1, i)
        if i == 3:
            root = [0] * 4
            root[3] = 1
            return root
        if i == 4:
            root = [Rational(-1, 2)] * 4
            return root

    def positive_roots(self):
        n = self.n
        posroots = {}
        k = 0
        for i in range(0, n - 1):
            for j in range(i + 1, n):
                k += 1
                posroots[k] = self.basic_root(i, j)
                k += 1
                root = self.basic_root(i, j)
                root[j] = 1
                posroots[k] = root
        for i in range(0, n):
            k += 1
            root = [0] * n
            root[i] = 1
            posroots[k] = root
        k += 1
        root = [Rational(1, 2)] * n
        posroots[k] = root
        for i in range(1, 4):
            k += 1
            root = [Rational(1, 2)] * n
            root[i] = Rational(-1, 2)
            posroots[k] = root
        posroots[k + 1] = [Rational(1, 2), Rational(1, 2), Rational(-1, 2), Rational(-1, 2)]
        posroots[k + 2] = [Rational(1, 2), Rational(-1, 2), Rational(1, 2), Rational(-1, 2)]
        posroots[k + 3] = [Rational(1, 2), Rational(-1, 2), Rational(-1, 2), Rational(1, 2)]
        posroots[k + 4] = [Rational(1, 2), Rational(-1, 2), Rational(-1, 2), Rational(-1, 2)]
        return posroots

    def roots(self):
        return 48

    def cartan_matrix(self):
        m = Matrix(4, 4, [2, -1, 0, 0, -1, 2, -2, 0, 0, -1, 2, -1, 0, 0, -1, 2])
        return m

    def basis(self):
        return 52

    def dynkin_diagram(self):
        diag = '0---0=>=0---0\n'
        diag += '   '.join((str(i) for i in range(1, 5)))
        return diag