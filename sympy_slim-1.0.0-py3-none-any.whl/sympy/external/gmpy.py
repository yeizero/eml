from __future__ import annotations
import os
from ctypes import c_long, sizeof
from functools import reduce
from typing import TYPE_CHECKING
from warnings import warn
from sympy.external import import_module
from .pythonmpq import PythonMPQ
from .ntheory import bit_scan1 as python_bit_scan1, bit_scan0 as python_bit_scan0, remove as python_remove, factorial as python_factorial, sqrt as python_sqrt, sqrtrem as python_sqrtrem, gcd as python_gcd, lcm as python_lcm, gcdext as python_gcdext, is_square as python_is_square, invert as python_invert, fibonacci as python_fibonacci, legendre as python_legendre, jacobi as python_jacobi, kronecker as python_kronecker, iroot as python_iroot, is_fermat_prp as python_is_fermat_prp, is_euler_prp as python_is_euler_prp, is_strong_prp as python_is_strong_prp, is_fibonacci_prp as python_is_fibonacci_prp, is_lucas_prp as python_is_lucas_prp, is_selfridge_prp as python_is_selfridge_prp, is_strong_lucas_prp as python_is_strong_lucas_prp, is_strong_selfridge_prp as python_is_strong_selfridge_prp, is_bpsw_prp as python_is_bpsw_prp, is_strong_bpsw_prp as python_is_strong_bpsw_prp
if TYPE_CHECKING:
    from typing import Generic, Iterator, Protocol, Self, Sequence, TypeVar, overload
    from types import ModuleType
__all__ = ['GROUND_TYPES', 'HAS_GMPY', 'SYMPY_INTS', 'MPQ', 'MPZ', 'bit_scan1', 'bit_scan0', 'remove', 'factorial', 'sqrt', 'is_square', 'sqrtrem', 'gcd', 'lcm', 'gcdext', 'invert', 'fibonacci', 'legendre', 'jacobi', 'kronecker', 'iroot', 'is_fermat_prp', 'is_euler_prp', 'is_strong_prp', 'is_fibonacci_prp', 'is_lucas_prp', 'is_selfridge_prp', 'is_strong_lucas_prp', 'is_strong_selfridge_prp', 'is_bpsw_prp', 'is_strong_bpsw_prp']
_PYTHON_FLINT_VERSION_NEEDED = ['0.6', '0.7', '0.8', '0.9']

def _flint_version_okay(flint_version):
    major, minor = flint_version.split('.')[:2]
    flint_ver = f'{major}.{minor}'
    return flint_ver in _PYTHON_FLINT_VERSION_NEEDED
_GMPY2_MIN_VERSION = '2.0.0'

def _get_flint(sympy_ground_types):
    if sympy_ground_types not in ('auto', 'flint'):
        return None
    try:
        import flint
        from flint import __version__ as _flint_version
    except ImportError:
        if sympy_ground_types == 'flint':
            warn('SYMPY_GROUND_TYPES was set to flint but python-flint is not installed. Falling back to other ground types.')
        return None
    if _flint_version_okay(_flint_version):
        return flint
    elif sympy_ground_types == 'auto':
        return None
    else:
        warn(f'Using python-flint {_flint_version} because SYMPY_GROUND_TYPES is set to flint but this version of SymPy is only tested with python-flint versions {_PYTHON_FLINT_VERSION_NEEDED}.')
        return flint

def _get_gmpy2(sympy_ground_types):
    if sympy_ground_types not in ('auto', 'gmpy', 'gmpy2'):
        return None
    gmpy = import_module('gmpy2', min_module_version=_GMPY2_MIN_VERSION, module_version_attr='version', module_version_attr_call_args=())
    if sympy_ground_types != 'auto' and gmpy is None:
        warn("gmpy2 library is not installed, switching to 'python' ground types")
    return gmpy
_SYMPY_GROUND_TYPES = os.environ.get('SYMPY_GROUND_TYPES', 'auto').lower()
_flint: ModuleType | None = None
_gmpy: ModuleType | None = None
if _SYMPY_GROUND_TYPES in ('auto', 'flint'):
    _flint = _get_flint(_SYMPY_GROUND_TYPES)
    if _flint is not None:
        _SYMPY_GROUND_TYPES = 'flint'
    else:
        _SYMPY_GROUND_TYPES = 'auto'
if _SYMPY_GROUND_TYPES in ('auto', 'gmpy', 'gmpy2'):
    _gmpy = _get_gmpy2(_SYMPY_GROUND_TYPES)
    if _gmpy is not None:
        _SYMPY_GROUND_TYPES = 'gmpy'
    else:
        _SYMPY_GROUND_TYPES = 'python'
if _SYMPY_GROUND_TYPES not in ('flint', 'gmpy', 'python'):
    warn("SYMPY_GROUND_TYPES environment variable unrecognised. Should be 'auto', 'flint', 'gmpy', 'gmpy2' or 'python'.")
    _SYMPY_GROUND_TYPES = 'python'
LONG_MAX = (1 << 8 * sizeof(c_long) - 1) - 1
SYMPY_INTS: tuple[type, ...]
GROUND_TYPES: str
if TYPE_CHECKING:

    class MPZ:

        def __init__(self, arg: int | MPZ | str=0, /) -> None:
            pass

        def __int__(self) -> int:
            pass

        def __index__(self) -> int:
            pass

        def __pos__(self) -> MPZ:
            pass

        def __neg__(self) -> MPZ:
            pass

        def __add__(self, other: MPZ | int, /) -> MPZ:
            pass

        def __radd__(self, other: int, /) -> MPZ:
            pass

        def __sub__(self, other: MPZ | int, /) -> MPZ:
            pass

        def __rsub__(self, other: int, /) -> MPZ:
            pass

        def __mul__(self, other: MPZ | int, /) -> MPZ:
            pass

        def __rmul__(self, other: int, /) -> MPZ:
            pass

        def __pow__(self, other: int, /) -> MPZ:
            pass

        def __rpow__(self, other: int, /) -> MPZ:
            pass

        def __floordiv__(self, other: MPZ | int, /) -> MPZ:
            pass

        def __rfloordiv__(self, other: int, /) -> MPZ:
            pass

        def __mod__(self, other: MPZ | int, /) -> MPZ:
            pass

        def __rmod__(self, other: int, /) -> MPZ:
            pass

        def __divmod__(self, other: MPZ | int, /) -> tuple[MPZ, MPZ]:
            pass

        def __rdivmod__(self, other: int, /) -> tuple[MPZ, MPZ]:
            pass

        def __lshift__(self, other: int, /) -> MPZ:
            pass

        def __rlshift__(self, other: int, /) -> MPZ:
            pass

        def __rshift__(self, other: int, /) -> MPZ:
            pass

        def __rrshift__(self, other: int, /) -> MPZ:
            pass

        def __and__(self, other: MPZ | int, /) -> MPZ:
            pass

        def __rand__(self, other: int, /) -> MPZ:
            pass

        def __or__(self, other: MPZ | int, /) -> MPZ:
            pass

        def __ror__(self, other: int, /) -> MPZ:
            pass

        def __xor__(self, other: MPZ | int, /) -> MPZ:
            pass

        def __rxor__(self, other: int, /) -> MPZ:
            pass

        def __invert__(self) -> MPZ:
            pass

        def __eq__(self, other: object, /) -> bool:
            pass

        def __hash__(self, /) -> int:
            pass

        def __lt__(self, other: MPZ | int, /) -> bool:
            pass

        def __le__(self, other: MPZ | int, /) -> bool:
            pass

        def __gt__(self, other: MPZ | int, /) -> bool:
            pass

        def __ge__(self, other: MPZ | int, /) -> bool:
            pass

        def __bool__(self, /) -> bool:
            pass

    class MPQ:

        def __init__(self, arg1: int | MPZ | MPQ | str=0, arg2: int | MPZ=1, /) -> None:
            pass

        def __int__(self) -> int:
            pass

        @property
        def numerator(self) -> MPZ:
            pass

        @property
        def denominator(self) -> MPZ:
            pass

        def __pos__(self) -> MPQ:
            pass

        def __neg__(self) -> MPQ:
            pass

        def __add__(self, other: MPQ | MPZ | int, /) -> MPQ:
            pass

        def __radd__(self, other: MPZ | int, /) -> MPQ:
            pass

        def __sub__(self, other: MPQ | MPZ | int, /) -> MPQ:
            pass

        def __rsub__(self, other: MPZ | int, /) -> MPQ:
            pass

        def __mul__(self, other: MPQ | MPZ | int, /) -> MPQ:
            pass

        def __rmul__(self, other: MPZ | int, /) -> MPQ:
            pass

        def __pow__(self, other: int, /) -> MPQ:
            pass

        def __truediv__(self, other: MPQ | MPZ | int, /) -> MPQ:
            pass

        def __rtruediv__(self, other: MPZ | int, /) -> MPQ:
            pass

        def __floordiv__(self, other: MPQ | MPZ | int, /) -> MPQ:
            pass

        def __rfloordiv__(self, other: MPZ | int, /) -> MPQ:
            pass

        def __mod__(self, other: MPQ | MPZ | int, /) -> MPQ:
            pass

        def __rmod__(self, other: MPZ | int, /) -> MPQ:
            pass

        def __divmod__(self, other: MPQ | MPZ | int, /) -> tuple[MPQ, MPQ]:
            pass

        def __rdivmod__(self, other: MPZ | int, /) -> tuple[MPQ, MPQ]:
            pass

        def __lt__(self, other: MPQ | MPZ | int, /) -> bool:
            pass

        def __le__(self, other: MPQ | MPZ | int, /) -> bool:
            pass

        def __gt__(self, other: MPQ | MPZ | int, /) -> bool:
            pass

        def __ge__(self, other: MPQ | MPZ | int, /) -> bool:
            pass

    class NMOD:

        def __init__(self, val: NMOD | MPZ | int=0, mod: int=2, /) -> None:
            pass

        def __int__(self) -> int:
            pass

        def __index__(self) -> int:
            pass

        def __pos__(self) -> NMOD:
            pass

        def __neg__(self) -> NMOD:
            pass

        def __add__(self, other: NMOD | MPZ | int, /) -> NMOD:
            pass

        def __radd__(self, other: MPZ | int, /) -> NMOD:
            pass

        def __sub__(self, other: NMOD | MPZ | int, /) -> NMOD:
            pass

        def __rsub__(self, other: MPZ | int, /) -> NMOD:
            pass

        def __mul__(self, other: NMOD | MPZ | int, /) -> NMOD:
            pass

        def __rmul__(self, other: MPZ | int, /) -> NMOD:
            pass

        def __truediv__(self, other: NMOD | MPZ | int, /) -> NMOD:
            pass

        def __rtruediv__(self, other: MPZ | int, /) -> NMOD:
            pass

        def __pow__(self, other: int, /) -> NMOD:
            pass

        def __eq__(self, other: object, /) -> bool:
            pass

        def __hash__(self, /) -> int:
            pass

        def __bool__(self, /) -> bool:
            pass

    class FMPZ_MOD:

        def __init__(self, val: FMPZ_MOD | MPZ | int=0, mod: MPZ | int=2, /) -> None:
            pass

        def __int__(self) -> int:
            pass

        def __index__(self) -> int:
            pass

        def __pos__(self) -> FMPZ_MOD:
            pass

        def __neg__(self) -> FMPZ_MOD:
            pass

        def __add__(self, other: FMPZ_MOD | MPZ | int, /) -> FMPZ_MOD:
            pass

        def __radd__(self, other: MPZ | int, /) -> FMPZ_MOD:
            pass

        def __sub__(self, other: FMPZ_MOD | MPZ | int, /) -> FMPZ_MOD:
            pass

        def __rsub__(self, other: MPZ | int, /) -> FMPZ_MOD:
            pass

        def __mul__(self, other: FMPZ_MOD | MPZ | int, /) -> FMPZ_MOD:
            pass

        def __rmul__(self, other: MPZ | int, /) -> FMPZ_MOD:
            pass

        def __truediv__(self, other: FMPZ_MOD | MPZ | int, /) -> FMPZ_MOD:
            pass

        def __rtruediv__(self, other: MPZ | int, /) -> FMPZ_MOD:
            pass

        def __pow__(self, other: int, /) -> FMPZ_MOD:
            pass

        def __eq__(self, other: object, /) -> bool:
            pass

        def __hash__(self, /) -> int:
            pass

        def __bool__(self, /) -> bool:
            pass

    class FMPZ_MOD_POLY_CTX:

        def __init__(self, mod: MPZ | int, /) -> None:
            pass

        def modulus(self) -> MPZ:
            pass

        def __call__(self, val: FMPZ_MOD_POLY | Sequence[FMPZ_MOD | MPZ | int], /) -> FMPZ_MOD_POLY:
            pass
    _Tground = TypeVar('_Tground')

    class POLY_P(Protocol[_Tground]):

        def str(self, ascending: bool=False, var: str='x') -> str:
            pass

        def __iter__(self) -> Iterator[_Tground]:
            pass

        def __getitem__(self, index: int, /) -> _Tground:
            pass

        def __setitem__(self, index: int, value: _Tground | int, /) -> None:
            pass

        def __len__(self) -> int:
            pass

        def length(self) -> int:
            pass

        def degree(self) -> int:
            pass

        def coeffs(self) -> list[_Tground]:
            pass

        @overload
        def __call__(self, other: _Tground | int, /) -> _Tground:
            pass

        @overload
        def __call__(self, other: Self, /) -> Self:
            pass

        def __pos__(self) -> Self:
            pass

        def __neg__(self) -> Self:
            pass

        def __add__(self, other: _Tground | int | Self, /) -> Self:
            pass

        def __radd__(self, other: _Tground | int, /) -> Self:
            pass

        def __sub__(self, other: _Tground | int | Self, /) -> Self:
            pass

        def __rsub__(self, other: _Tground | int, /) -> Self:
            pass

        def __mul__(self, other: _Tground | int | Self, /) -> Self:
            pass

        def __rmul__(self, other: _Tground | int, /) -> Self:
            pass

        def __truediv__(self, other: _Tground | int | Self, /) -> Self:
            pass

        def __rtruediv__(self, other: _Tground | int, /) -> Self:
            pass

        def __floordiv__(self, other: _Tground | int | Self, /) -> Self:
            pass

        def __rfloordiv__(self, other: _Tground | int, /) -> Self:
            pass

        def __mod__(self, other: _Tground | int | Self, /) -> Self:
            pass

        def __rmod__(self, other: _Tground | int, /) -> Self:
            pass

        def __divmod__(self, other: _Tground | int | Self, /) -> tuple[Self, Self]:
            pass

        def __rdivmod__(self, other: _Tground | int, /) -> tuple[Self, Self]:
            pass

        def __pow__(self, other: int, /) -> Self:
            pass

        def left_shift(self, other: int, /) -> Self:
            pass

        def right_shift(self, other: int, /) -> Self:
            pass

        def truncate(self, n: int, /) -> Self:
            pass

        def derivative(self) -> Self:
            pass

    class FLINT_POLY_P(POLY_P[_Tground], Protocol[_Tground]):

        def deflation(self) -> tuple[Self, int]:
            pass

        def gcd(self, other: Self | _Tground | int, /) -> Self:
            pass

        def xgcd(self, other: Self | _Tground | int, /) -> tuple[Self, Self, Self]:
            pass

        def factor(self) -> tuple[_Tground, list[tuple[Self, int]]]:
            pass

        def integral(self) -> Self:
            pass

        def numer(self) -> Self:
            pass

        def denom(self) -> _Tground:
            pass

        def is_cyclotomic(self) -> bool:
            pass

    class SERIES_P(Protocol[_Tground]):

        def repr(self) -> str:
            pass

        @property
        def prec(self) -> int:
            pass

        def __len__(self) -> int:
            pass

        def __getitem__(self, index: int, /) -> _Tground:
            pass

        def coeffs(self) -> list[_Tground]:
            pass

    class _POLY_DUMMY(Generic[_Tground]):

        def str(self, ascending: bool=False, var: str='x') -> str:
            pass

        def __iter__(self) -> Iterator[_Tground]:
            pass

        def __getitem__(self, index: int, /) -> _Tground:
            pass

        def __setitem__(self, index: int, value: _Tground | int, /) -> None:
            pass

        def __len__(self) -> int:
            pass

        def length(self) -> int:
            pass

        def degree(self) -> int:
            pass

        def coeffs(self) -> list[_Tground]:
            pass

        def __pos__(self) -> Self:
            pass

        def __neg__(self) -> Self:
            pass

        def __add__(self, other: _Tground | int | Self, /) -> Self:
            pass

        def __radd__(self, other: _Tground | int, /) -> Self:
            pass

        def __sub__(self, other: _Tground | int | Self, /) -> Self:
            pass

        def __rsub__(self, other: _Tground | int, /) -> Self:
            pass

        def __mul__(self, other: _Tground | int | Self, /) -> Self:
            pass

        def __rmul__(self, other: _Tground | int, /) -> Self:
            pass

        def __truediv__(self, other: _Tground | int | Self, /) -> Self:
            pass

        def __rtruediv__(self, other: _Tground | int, /) -> Self:
            pass

        def __floordiv__(self, other: _Tground | int | Self, /) -> Self:
            pass

        def __rfloordiv__(self, other: _Tground | int, /) -> Self:
            pass

        def __mod__(self, other: _Tground | int | Self, /) -> Self:
            pass

        def __rmod__(self, other: _Tground | int, /) -> Self:
            pass

        def __divmod__(self, other: _Tground | int | Self, /) -> tuple[Self, Self]:
            pass

        def __rdivmod__(self, other: _Tground | int, /) -> tuple[Self, Self]:
            pass

        def __pow__(self, other: int, /) -> Self:
            pass

        def left_shift(self, other: int, /) -> Self:
            pass

        def right_shift(self, other: int, /) -> Self:
            pass

        def truncate(self, n: int, /) -> Self:
            pass

        def derivative(self) -> Self:
            pass

    class FMPZ_POLY(_POLY_DUMMY[MPZ]):

        def __init__(self, other: FMPZ_POLY | FMPZ_SERIES | Sequence[MPZ | int] | MPZ | int=0, /) -> None:
            pass

        @overload
        def __call__(self, other: MPZ | int, /) -> MPZ:
            pass

        @overload
        def __call__(self, other: FMPZ_POLY, /) -> FMPZ_POLY:
            pass

        def __call__(self, other: MPZ | int | FMPZ_POLY, /) -> MPZ | FMPZ_POLY:
            pass

        def deflation(self) -> tuple[FMPZ_POLY, int]:
            pass

        def gcd(self, other: FMPZ_POLY | MPZ | int, /) -> FMPZ_POLY:
            pass

        def is_cyclotomic(self) -> bool:
            pass

    class FMPQ_POLY(_POLY_DUMMY[MPQ]):

        def __init__(self, other: FMPQ_POLY | FMPQ_SERIES | Sequence[MPQ | MPZ | int] | MPQ | MPZ | int=0, den: MPZ | int=1, /) -> None:
            pass

        @overload
        def __call__(self, other: MPQ | MPZ | int, /) -> MPQ:
            pass

        @overload
        def __call__(self, other: FMPQ_POLY, /) -> FMPQ_POLY:
            pass

        @overload
        def __call__(self, other: FMPZ_POLY, /) -> FMPQ_POLY:
            pass

        def __call__(self, other: MPQ | MPZ | int | FMPQ_POLY | FMPZ_POLY, /) -> MPQ | FMPQ_POLY:
            pass

        def sqrt(self) -> FMPQ_POLY | FMPQ_SERIES:
            pass

        def deflation(self) -> tuple[FMPQ_POLY, int]:
            pass

        def gcd(self, other: FMPQ_POLY | MPQ | MPZ | int, /) -> FMPQ_POLY:
            pass

        def xgcd(self, other: FMPQ_POLY | MPQ | MPZ | int, /) -> tuple[FMPQ_POLY, FMPQ_POLY, FMPQ_POLY]:
            pass

        def factor(self, *, monic: bool=False) -> tuple[MPQ, list[tuple[FMPQ_POLY, int]]]:
            pass

        def factor_squarefree(self) -> tuple[MPQ, list[tuple[FMPQ_POLY, int]]]:
            pass

        def numer(self) -> FMPZ_POLY:
            pass

        def denom(self) -> MPZ:
            pass

        def integral(self) -> FMPQ_POLY:
            pass

    class NMOD_POLY(_POLY_DUMMY[NMOD]):

        def __init__(self, val: NMOD_POLY | Sequence[NMOD | MPZ | int] | FMPZ_POLY | NMOD | MPZ | int=0, mod: int=2, /) -> None:
            pass

        @overload
        def __call__(self, other: NMOD | MPZ | int, /) -> NMOD:
            pass

        @overload
        def __call__(self, other: NMOD_POLY | FMPZ_POLY, /) -> NMOD_POLY:
            pass

        def __call__(self, other: NMOD | MPZ | int | NMOD_POLY | FMPZ_POLY, /) -> NMOD | NMOD_POLY:
            pass

        def modulus(self) -> int:
            pass

        def integral(self) -> NMOD_POLY:
            pass

        def sqrt(self) -> NMOD_POLY:
            pass

        def gcd(self, other: NMOD_POLY | FMPZ_POLY | NMOD | MPZ | int, /) -> NMOD_POLY:
            pass

        def xgcd(self, other: NMOD_POLY | FMPZ_POLY | NMOD | MPZ | int, /) -> tuple[NMOD_POLY, NMOD_POLY, NMOD_POLY]:
            pass

        def factor(self) -> tuple[NMOD, list[tuple[NMOD_POLY, int]]]:
            pass

        def factor_squarefree(self) -> tuple[NMOD, list[tuple[NMOD_POLY, int]]]:
            pass

        def deflation(self) -> tuple[NMOD_POLY, int]:
            pass

    class FMPZ_MOD_POLY(_POLY_DUMMY[FMPZ_MOD]):

        def __init__(self, val: Sequence[FMPZ_MOD | MPZ | int] | FMPZ_MOD_POLY | FMPZ_POLY | FMPZ_MOD | MPZ | int, ctx: FMPZ_MOD_POLY_CTX, /) -> None:
            pass

        @overload
        def __call__(self, other: FMPZ_MOD | MPZ | int, /) -> FMPZ_MOD:
            pass

        @overload
        def __call__(self, other: FMPZ_MOD_POLY | FMPZ_POLY, /) -> FMPZ_MOD_POLY:
            pass

        def __call__(self, other: FMPZ_MOD | MPZ | int | FMPZ_MOD_POLY | FMPZ_POLY, /) -> FMPZ_MOD | FMPZ_MOD_POLY:
            pass

        def context(self) -> FMPZ_MOD_POLY_CTX:
            pass

        def modulus(self) -> MPZ:
            pass

        def integral(self) -> FMPZ_MOD_POLY:
            pass

        def sqrt(self) -> FMPZ_MOD_POLY:
            pass

        def gcd(self, other: FMPZ_MOD_POLY | FMPZ_POLY | FMPZ_MOD | MPZ | int, /) -> FMPZ_MOD_POLY:
            pass

        def xgcd(self, other: FMPZ_MOD_POLY | FMPZ_POLY | FMPZ_MOD | MPZ | int, /) -> tuple[FMPZ_MOD_POLY, FMPZ_MOD_POLY, FMPZ_MOD_POLY]:
            pass

        def factor(self) -> tuple[FMPZ_MOD, list[tuple[FMPZ_MOD_POLY, int]]]:
            pass

        def factor_squarefree(self) -> tuple[FMPZ_MOD, list[tuple[FMPZ_MOD_POLY, int]]]:
            pass

        def deflation(self) -> tuple[FMPZ_MOD_POLY, int]:
            pass

    class FMPZ_SERIES:

        def __init__(self, val: FMPZ_SERIES | FMPZ_POLY | Sequence[MPZ | int] | MPZ | int | None=None, *, prec: int | None=None) -> None:
            pass

        @property
        def prec(self) -> int:
            pass

        def repr(self) -> str:
            pass

        def __len__(self) -> int:
            pass

        def __bool__(self) -> bool:
            pass

        def __getitem__(self, index: int, /) -> MPZ:
            pass

        def coeffs(self) -> list[MPZ]:
            pass

        def _equal_repr(self, other: FMPZ_SERIES, /) -> bool:
            pass

        def __call__(self, other: FMPZ_POLY | FMPZ_SERIES, /) -> FMPZ_SERIES:
            pass

        def __add__(self, other: MPZ | int | FMPZ_POLY | FMPZ_SERIES, /) -> FMPZ_SERIES:
            pass

        def __radd__(self, other: MPZ | int | FMPZ_POLY, /) -> FMPZ_SERIES:
            pass

        def __sub__(self, other: MPZ | int | FMPZ_POLY | FMPZ_SERIES, /) -> FMPZ_SERIES:
            pass

        def __rsub__(self, other: MPZ | int | FMPZ_POLY, /) -> FMPZ_SERIES:
            pass

        def __mul__(self, other: MPZ | int | FMPZ_POLY | FMPZ_SERIES, /) -> FMPZ_SERIES:
            pass

        def __rmul__(self, other: MPZ | int | FMPZ_POLY, /) -> FMPZ_SERIES:
            pass

        def __truediv__(self, other: MPZ | int | FMPZ_POLY | FMPZ_SERIES, /) -> FMPZ_SERIES:
            pass

        def __rtruediv__(self, other: MPZ | int | FMPZ_POLY, /) -> FMPZ_SERIES:
            pass

        def __pow__(self, n: int, /) -> FMPZ_SERIES:
            pass

        def __neg__(self) -> FMPZ_SERIES:
            pass

        def degree(self) -> int:
            pass

        def reversion(self) -> FMPZ_SERIES:
            pass

    class FMPQ_SERIES:

        def __init__(self, val: FMPQ_SERIES | FMPQ_POLY | FMPZ_SERIES | FMPZ_POLY | Sequence[MPQ | MPZ | int] | MPQ | MPZ | int | None=None, *, prec: int | None=None) -> None:
            pass

        @property
        def prec(self) -> int:
            pass

        def repr(self) -> str:
            pass

        def __len__(self) -> int:
            pass

        def __bool__(self) -> bool:
            pass

        def __getitem__(self, index: int, /) -> MPQ:
            pass

        def coeffs(self) -> list[MPQ]:
            pass

        def _equal_repr(self, other: FMPQ_SERIES, /) -> bool:
            pass

        def __call__(self, other: FMPQ_POLY | FMPQ_SERIES, /) -> FMPQ_SERIES:
            pass

        def __add__(self, other: MPQ | MPZ | int | FMPQ_POLY | FMPQ_SERIES, /) -> FMPQ_SERIES:
            pass

        def __radd__(self, other: MPQ | MPZ | int | FMPQ_POLY, /) -> FMPQ_SERIES:
            pass

        def __sub__(self, other: MPQ | MPZ | int | FMPQ_POLY | FMPQ_SERIES, /) -> FMPQ_SERIES:
            pass

        def __rsub__(self, other: MPQ | MPZ | int | FMPQ_POLY, /) -> FMPQ_SERIES:
            pass

        def __mul__(self, other: MPQ | MPZ | int | FMPQ_POLY | FMPQ_SERIES, /) -> FMPQ_SERIES:
            pass

        def __rmul__(self, other: MPQ | MPZ | int | FMPQ_POLY, /) -> FMPQ_SERIES:
            pass

        def __truediv__(self, other: MPQ | MPZ | int | FMPQ_POLY | FMPQ_SERIES, /) -> FMPQ_SERIES:
            pass

        def __rtruediv__(self, other: MPQ | MPZ | int | FMPQ_POLY, /) -> FMPQ_SERIES:
            pass

        def __pow__(self, n: int, /) -> FMPQ_SERIES:
            pass

        def __neg__(self) -> FMPQ_SERIES:
            pass

        def degree(self) -> int:
            pass

        def sqrt(self) -> FMPQ_SERIES:
            pass

        def inv(self) -> FMPQ_SERIES:
            pass

        def integral(self) -> FMPQ_SERIES:
            pass

        def reversion(self) -> FMPQ_SERIES:
            pass

        def log(self) -> FMPQ_SERIES:
            pass

        def exp(self) -> FMPQ_SERIES:
            pass

        def atan(self) -> FMPQ_SERIES:
            pass

        def atanh(self) -> FMPQ_SERIES:
            pass

        def asin(self) -> FMPQ_SERIES:
            pass

        def asinh(self) -> FMPQ_SERIES:
            pass

        def tan(self) -> FMPQ_SERIES:
            pass

        def tanh(self) -> FMPQ_SERIES:
            pass

        def sin(self) -> FMPQ_SERIES:
            pass

        def sinh(self) -> FMPQ_SERIES:
            pass

        def cos(self) -> FMPQ_SERIES:
            pass

        def cosh(self) -> FMPQ_SERIES:
            pass
    gmpy: ModuleType | None
    flint: ModuleType | None
    try:
        import gmpy2 as _gmpy2
        gmpy = _gmpy2
    except ImportError:
        gmpy = None
    try:
        import flint as _flint_mod
        flint = _flint_mod
    except ImportError:
        flint = None
    try:
        from flint import fmpq as _flint_fmpq
        from flint import fmpq_poly as _flint_fmpq_poly
        from flint import fmpq_series as _flint_fmpq_series
        from flint import fmpz as _flint_fmpz
        from flint import fmpz_mod as _flint_fmpz_mod
        from flint import fmpz_mod_poly as _flint_fmpz_mod_poly
        from flint import fmpz_mod_poly_ctx as _flint_fmpz_mod_poly_ctx
        from flint import fmpz_poly as _flint_fmpz_poly
        from flint import fmpz_series as _flint_fmpz_series
        from flint import nmod as _flint_nmod
        from flint import nmod_poly as _flint_nmod_poly
    except ImportError:
        pass
    else:
        _fmpz_poly: POLY_P[_flint_fmpz] = _flint_fmpz_poly([1, 2])
        _fmpq_poly: POLY_P[_flint_fmpq] = _flint_fmpq_poly([1, 2])
        _nmod_poly: POLY_P[_flint_nmod] = _flint_nmod_poly(1, 2)
        _fmpz_mod_poly: POLY_P[_flint_fmpz_mod] = _flint_fmpz_mod_poly(1, _flint_fmpz_mod_poly_ctx(2))
        _fmpz_series: SERIES_P[_flint_fmpz] = _flint_fmpz_series([1, 2], prec=3)
        _fmpq_series: SERIES_P[_flint_fmpq] = _flint_fmpq_series([1, 2], prec=3)
    _sympy_fmpz_poly: POLY_P[MPZ] = FMPZ_POLY([1, 2])
    _sympy_fmpq_poly: POLY_P[MPQ] = FMPQ_POLY([1, 2])
    _sympy_nmod_poly: POLY_P[NMOD] = NMOD_POLY([1, 2], 2)
    _sympy_fmpz_mod_poly: POLY_P[FMPZ_MOD] = FMPZ_MOD_POLY([1, 2], FMPZ_MOD_POLY_CTX(2))
    _sympy_fmpz_series: SERIES_P[MPZ] = FMPZ_SERIES([1, 2], prec=3)
    _sympy_fmpq_series: SERIES_P[MPQ] = FMPQ_SERIES([1, 2], prec=3)

    def bit_scan1(x: MPZ | int) -> int:
        pass

    def bit_scan0(x: MPZ | int) -> int:
        pass

    def factorial(n: MPZ | int) -> MPZ:
        pass

    def sqrt(x: MPZ | int) -> MPZ:
        pass

    def sqrtrem(x: MPZ | int) -> tuple[MPZ, MPZ]:
        pass

    def gcd(*args: MPZ | int) -> MPZ:
        pass

    def lcm(*args: MPZ | int) -> MPZ:
        pass

    def gcdext(x: MPZ | int, y: MPZ | int) -> tuple[MPZ, MPZ, MPZ]:
        pass

    def invert(x: MPZ | int, y: MPZ | int) -> MPZ:
        pass

    def remove(x: MPZ | int, y: MPZ | int) -> tuple[MPZ, MPZ]:
        pass

    def iroot(x: MPZ | int, n: int) -> tuple[MPZ, bool]:
        pass

    def fibonacci(x: MPZ | int) -> MPZ:
        pass

    def jacobi(x: MPZ | int, y: MPZ | int) -> int:
        pass

    def legendre(x: MPZ | int, y: MPZ | int) -> int:
        pass

    def kronecker(x: MPZ | int, y: MPZ | int) -> int:
        pass

    def is_square(x: MPZ | int) -> bool:
        pass

    def is_fermat_prp(n: MPZ | int, a: MPZ | int) -> bool:
        pass

    def is_euler_prp(n: MPZ | int, a: MPZ | int) -> bool:
        pass

    def is_strong_prp(x: MPZ | int) -> bool:
        pass

    def is_fibonacci_prp(x: MPZ | int) -> bool:
        pass

    def is_lucas_prp(x: MPZ | int) -> bool:
        pass

    def is_selfridge_prp(x: MPZ | int) -> bool:
        pass

    def is_strong_lucas_prp(x: MPZ | int) -> bool:
        pass

    def is_strong_selfridge_prp(x: MPZ | int) -> bool:
        pass

    def is_bpsw_prp(x: MPZ | int) -> bool:
        pass

    def is_strong_bpsw_prp(x: MPZ | int) -> bool:
        pass
elif _SYMPY_GROUND_TYPES == 'gmpy':
    assert _gmpy is not None
    flint = None
    gmpy = _gmpy
    HAS_GMPY = 2
    GROUND_TYPES = 'gmpy'
    SYMPY_INTS = (int, type(gmpy.mpz(0)))
    MPZ = gmpy.mpz
    MPQ = gmpy.mpq
    bit_scan1 = gmpy.bit_scan1
    bit_scan0 = gmpy.bit_scan0
    remove = gmpy.remove
    factorial = gmpy.fac
    sqrt = gmpy.isqrt
    is_square = gmpy.is_square
    sqrtrem = gmpy.isqrt_rem
    gcd = gmpy.gcd
    lcm = gmpy.lcm
    gcdext = gmpy.gcdext
    invert = gmpy.invert
    fibonacci = gmpy.fib
    legendre = gmpy.legendre
    jacobi = gmpy.jacobi
    kronecker = gmpy.kronecker

    def iroot(x, n):
        if n <= LONG_MAX:
            return gmpy.iroot(x, n)
        return python_iroot(x, n)
    is_fermat_prp = gmpy.is_fermat_prp
    is_euler_prp = gmpy.is_euler_prp
    is_strong_prp = gmpy.is_strong_prp
    is_fibonacci_prp = gmpy.is_fibonacci_prp
    is_lucas_prp = gmpy.is_lucas_prp
    is_selfridge_prp = gmpy.is_selfridge_prp
    is_strong_lucas_prp = gmpy.is_strong_lucas_prp
    is_strong_selfridge_prp = gmpy.is_strong_selfridge_prp
    is_bpsw_prp = gmpy.is_bpsw_prp
    is_strong_bpsw_prp = gmpy.is_strong_bpsw_prp
elif _SYMPY_GROUND_TYPES == 'flint':
    assert _flint is not None
    flint = _flint
    gmpy = None
    HAS_GMPY = 0
    GROUND_TYPES = 'flint'
    SYMPY_INTS = (int, flint.fmpz)
    MPZ = flint.fmpz
    MPQ = flint.fmpq
    bit_scan1 = python_bit_scan1
    bit_scan0 = python_bit_scan0
    remove = python_remove
    fibonacci = flint.fmpz.fib_ui
    factorial = python_factorial

    def sqrt(x):
        return flint.fmpz(x).isqrt()

    def is_square(x):
        if x < 0:
            return False
        return flint.fmpz(x).sqrtrem()[1] == 0

    def sqrtrem(x):
        return flint.fmpz(x).sqrtrem()

    def gcd(*args):
        return reduce(flint.fmpz.gcd, args, flint.fmpz(0))

    def lcm(*args):
        return reduce(flint.fmpz.lcm, args, flint.fmpz(1))
    gcdext = python_gcdext
    invert = python_invert
    legendre = python_legendre

    def jacobi(x, y):
        if y <= 0 or not y % 2:
            raise ValueError('y should be an odd positive integer')
        return flint.fmpz(x).jacobi(y)
    kronecker = python_kronecker

    def iroot(x, n):
        if n <= LONG_MAX:
            y = flint.fmpz(x).root(n)
            return (y, y ** n == x)
        return python_iroot(x, n)
    is_fermat_prp = python_is_fermat_prp
    is_euler_prp = python_is_euler_prp
    is_strong_prp = python_is_strong_prp
    is_fibonacci_prp = python_is_fibonacci_prp
    is_lucas_prp = python_is_lucas_prp
    is_selfridge_prp = python_is_selfridge_prp
    is_strong_lucas_prp = python_is_strong_lucas_prp
    is_strong_selfridge_prp = python_is_strong_selfridge_prp
    is_bpsw_prp = python_is_bpsw_prp
    is_strong_bpsw_prp = python_is_strong_bpsw_prp
elif _SYMPY_GROUND_TYPES == 'python':
    flint = None
    gmpy = None
    HAS_GMPY = 0
    GROUND_TYPES = 'python'
    SYMPY_INTS = (int,)
    MPZ = int
    MPQ = PythonMPQ
    bit_scan1 = python_bit_scan1
    bit_scan0 = python_bit_scan0
    remove = python_remove
    factorial = python_factorial
    sqrt = python_sqrt
    is_square = python_is_square
    sqrtrem = python_sqrtrem
    gcd = python_gcd
    lcm = python_lcm
    gcdext = python_gcdext
    invert = python_invert
    fibonacci = python_fibonacci
    legendre = python_legendre
    jacobi = python_jacobi
    kronecker = python_kronecker
    iroot = python_iroot
    is_fermat_prp = python_is_fermat_prp
    is_euler_prp = python_is_euler_prp
    is_strong_prp = python_is_strong_prp
    is_fibonacci_prp = python_is_fibonacci_prp
    is_lucas_prp = python_is_lucas_prp
    is_selfridge_prp = python_is_selfridge_prp
    is_strong_lucas_prp = python_is_strong_lucas_prp
    is_strong_selfridge_prp = python_is_strong_selfridge_prp
    is_bpsw_prp = python_is_bpsw_prp
    is_strong_bpsw_prp = python_is_strong_bpsw_prp
else:
    assert False