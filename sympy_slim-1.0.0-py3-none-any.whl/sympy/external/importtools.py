from __future__ import annotations
import sys
import re
WARN_NOT_INSTALLED = None
WARN_OLD_VERSION = None

def __sympy_debug():
    import os
    debug_str = os.getenv('SYMPY_DEBUG', 'False')
    if debug_str in ('True', 'False'):
        return eval(debug_str)
    else:
        raise RuntimeError('unrecognized value for SYMPY_DEBUG: %s' % debug_str)
if __sympy_debug():
    WARN_OLD_VERSION = True
    WARN_NOT_INSTALLED = True
_component_re = re.compile('(\\d+ | [a-z]+ | \\.)', re.VERBOSE)

def version_tuple(vstring):
    components = []
    for x in _component_re.split(vstring):
        if x and x != '.':
            try:
                x = int(x)
            except ValueError:
                pass
            components.append(x)
    return tuple(components)

def import_module(module, min_module_version=None, min_python_version=None, warn_not_installed=None, warn_old_version=None, module_version_attr='__version__', module_version_attr_call_args=None, import_kwargs={}, catch=()):
    warn_old_version = WARN_OLD_VERSION if WARN_OLD_VERSION is not None else warn_old_version or True
    warn_not_installed = WARN_NOT_INSTALLED if WARN_NOT_INSTALLED is not None else warn_not_installed or False
    import warnings
    if min_python_version:
        if sys.version_info < min_python_version:
            if warn_old_version:
                warnings.warn('Python version is too old to use %s (%s or newer required)' % (module, '.'.join(map(str, min_python_version))), UserWarning, stacklevel=2)
            return
    try:
        mod = __import__(module, **import_kwargs)
        from_list = import_kwargs.get('fromlist', ())
        for submod in from_list:
            if submod == 'collections' and mod.__name__ == 'matplotlib':
                __import__(module + '.' + submod)
    except ImportError:
        if warn_not_installed:
            warnings.warn('%s module is not installed' % module, UserWarning, stacklevel=2)
        return
    except catch as e:
        if warn_not_installed:
            warnings.warn('%s module could not be used (%s)' % (module, repr(e)), stacklevel=2)
        return
    if min_module_version:
        modversion = getattr(mod, module_version_attr)
        if module_version_attr_call_args is not None:
            modversion = modversion(*module_version_attr_call_args)
        if version_tuple(modversion) < version_tuple(min_module_version):
            if warn_old_version:
                if isinstance(min_module_version, str):
                    verstr = min_module_version
                elif isinstance(min_module_version, (tuple, list)):
                    verstr = '.'.join(map(str, min_module_version))
                else:
                    verstr = str(min_module_version)
                warnings.warn('%s version is too old to use (%s or newer required)' % (module, verstr), UserWarning, stacklevel=2)
            return
    return mod