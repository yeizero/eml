from __future__ import annotations
from sympy.core import Add, S, Mul, Pow, oo
from sympy.core.containers import Tuple
from sympy.core.expr import AtomicExpr, Expr
from sympy.core.function import Function, Derivative, AppliedUndef, diff, expand, expand_mul, Subs
from sympy.core.numbers import nan, zoo, Number
from sympy.core.relational import Equality, Eq
from sympy.core.sorting import default_sort_key, ordered
from sympy.core.symbol import Symbol, Wild, Dummy, symbols
from sympy.core.sympify import sympify
from sympy.core.traversal import preorder_traversal
from sympy.logic.boolalg import BooleanAtom, BooleanTrue, BooleanFalse
from sympy.functions import exp, log, sqrt
from sympy.functions.combinatorial.factorials import factorial
from sympy.integrals.integrals import Integral
from sympy.polys import Poly, terms_gcd, PolynomialError, lcm
from sympy.polys.polytools import cancel
from sympy.series import Order
from sympy.series.series import series
from sympy.simplify import collect, logcombine, powsimp, separatevars, simplify, cse
from sympy.simplify.radsimp import collect_const
from sympy.solvers import checksol, solve
from sympy.utilities import numbered_symbols
from sympy.utilities.iterables import uniq, sift, iterable
from sympy.solvers.deutils import _preprocess, ode_order, _desolve
allhints = ('factorable', 'nth_algebraic', 'separable', '1st_exact', '1st_linear', 'Bernoulli', '1st_rational_riccati', 'Riccati_special_minus2', '1st_homogeneous_coeff_best', '1st_homogeneous_coeff_subs_indep_div_dep', '1st_homogeneous_coeff_subs_dep_div_indep', 'almost_linear', 'linear_coefficients', 'separable_reduced', '1st_power_series', 'lie_group', 'nth_linear_constant_coeff_homogeneous', 'nth_linear_euler_eq_homogeneous', 'nth_linear_constant_coeff_undetermined_coefficients', 'nth_linear_euler_eq_nonhomogeneous_undetermined_coefficients', 'nth_linear_constant_coeff_variation_of_parameters', 'nth_linear_euler_eq_nonhomogeneous_variation_of_parameters', 'Liouville', '2nd_linear_airy', '2nd_linear_bessel', '2nd_linear_bessel_transform', '2nd_hypergeometric', '2nd_hypergeometric_Integral', 'nth_order_reducible', '2nd_power_series_ordinary', '2nd_power_series_regular', 'nth_algebraic_Integral', 'separable_Integral', '1st_exact_Integral', '1st_linear_Integral', 'Bernoulli_Integral', '1st_homogeneous_coeff_subs_indep_div_dep_Integral', '1st_homogeneous_coeff_subs_dep_div_indep_Integral', 'almost_linear_Integral', 'linear_coefficients_Integral', 'separable_reduced_Integral', 'nth_linear_constant_coeff_variation_of_parameters_Integral', 'nth_linear_euler_eq_nonhomogeneous_variation_of_parameters_Integral', 'Liouville_Integral', '2nd_nonlinear_autonomous_conserved', '2nd_nonlinear_autonomous_conserved_Integral')

def get_numbered_constants(eq, num=1, start=1, prefix='C'):
    ncs = iter_numbered_constants(eq, start, prefix)
    Cs = [next(ncs) for i in range(num)]
    return Cs[0] if num == 1 else tuple(Cs)

def iter_numbered_constants(eq, start=1, prefix='C'):
    if isinstance(eq, (Expr, Eq)):
        eq = [eq]
    elif not iterable(eq):
        raise ValueError('Expected Expr or iterable but got %s' % eq)
    atom_set = set().union(*[i.free_symbols for i in eq])
    func_set = set().union(*[i.atoms(Function) for i in eq])
    if func_set:
        atom_set |= {Symbol(str(f.func)) for f in func_set}
    return numbered_symbols(start=start, prefix=prefix, exclude=atom_set)

def dsolve(eq, func=None, hint='default', simplify=True, ics=None, xi=None, eta=None, x0=0, n=6, **kwargs):
    if iterable(eq):
        from sympy.solvers.ode.systems import dsolve_system
        try:
            sol = dsolve_system(eq, funcs=func, ics=ics, doit=True)
            return sol[0] if len(sol) == 1 else sol
        except NotImplementedError:
            pass
        match = classify_sysode(eq, func)
        eq = match['eq']
        order = match['order']
        func = match['func']
        t = list(list(eq[0].atoms(Derivative))[0].atoms(Symbol))[0]
        for i in range(len(eq)):
            for func_ in func:
                if isinstance(func_, list):
                    pass
                elif eq[i].coeff(diff(func[i], t, ode_order(eq[i], func[i]))).is_negative:
                    eq[i] = -eq[i]
        match['eq'] = eq
        if len(set(order.values())) != 1:
            raise ValueError('It solves only those systems of equations whose orders are equal')
        match['order'] = list(order.values())[0]

        def recur_len(l):
            return sum((recur_len(item) if isinstance(item, list) else 1 for item in l))
        if recur_len(func) != len(eq):
            raise ValueError('dsolve() and classify_sysode() work with number of functions being equal to number of equations')
        if match['type_of_equation'] is None:
            raise NotImplementedError
        else:
            if match['is_linear'] == True:
                solvefunc = globals()['sysode_linear_%(no_of_equation)seq_order%(order)s' % match]
            else:
                solvefunc = globals()['sysode_nonlinear_%(no_of_equation)seq_order%(order)s' % match]
            sols = solvefunc(match)
            if ics:
                constants = Tuple(*sols).free_symbols - Tuple(*eq).free_symbols
                solved_constants = solve_ics(sols, func, constants, ics)
                return [sol.subs(solved_constants) for sol in sols]
            return sols
    else:
        given_hint = hint
        hints = _desolve(eq, func=func, hint=hint, simplify=True, xi=xi, eta=eta, type='ode', ics=ics, x0=x0, n=n, **kwargs)
        eq = hints.pop('eq', eq)
        all_ = hints.pop('all', False)
        if all_:
            retdict = {}
            failed_hints = {}
            gethints = classify_ode(eq, dict=True, hint='all')
            orderedhints = gethints['ordered_hints']
            for hint in hints:
                try:
                    rv = _helper_simplify(eq, hint, hints[hint], simplify)
                except NotImplementedError as detail:
                    failed_hints[hint] = detail
                else:
                    retdict[hint] = rv
            func = hints[hint]['func']
            retdict['best'] = min(list(retdict.values()), key=lambda x: ode_sol_simplicity(x, func, trysolving=not simplify))
            if given_hint == 'best':
                return retdict['best']
            for i in orderedhints:
                if retdict['best'] == retdict.get(i, None):
                    retdict['best_hint'] = i
                    break
            retdict['default'] = gethints['default']
            retdict['order'] = gethints['order']
            retdict.update(failed_hints)
            return retdict
        else:
            hint = hints['hint']
            return _helper_simplify(eq, hint, hints, simplify, ics=ics)

def _helper_simplify(eq, hint, match, simplify=True, ics=None, **kwargs):
    r = match
    func = r['func']
    order = r['order']
    match = r[hint]
    if isinstance(match, SingleODESolver):
        solvefunc = match
    else:
        solvefunc = globals()['ode_' + hint.removesuffix('_Integral')]
    free = eq.free_symbols
    cons = lambda s: s.free_symbols.difference(free)
    if simplify:
        if isinstance(solvefunc, SingleODESolver):
            sols = solvefunc.get_general_solution()
        else:
            sols = solvefunc(eq, func, order, match)
        if iterable(sols):
            rv = []
            for s in sols:
                simp = odesimp(eq, s, func, hint)
                if iterable(simp):
                    rv.extend(simp)
                else:
                    rv.append(simp)
        else:
            rv = odesimp(eq, sols, func, hint)
    else:
        if isinstance(solvefunc, SingleODESolver):
            exprs = solvefunc.get_general_solution(simplify=False)
        else:
            match['simplify'] = False
            exprs = solvefunc(eq, func, order, match)
        if isinstance(exprs, list):
            rv = [_handle_Integral(expr, func, hint) for expr in exprs]
        else:
            rv = _handle_Integral(exprs, func, hint)
    if isinstance(rv, list):
        assert all((isinstance(i, Eq) for i in rv)), rv
        if simplify:
            rv = _remove_redundant_solutions(eq, rv, order, func.args[0])
        if len(rv) == 1:
            rv = rv[0]
    if ics and 'power_series' not in hint:
        if isinstance(rv, (Expr, Eq)):
            solved_constants = solve_ics([rv], [r['func']], cons(rv), ics)
            rv = rv.subs(solved_constants)
        else:
            rv1 = []
            for s in rv:
                try:
                    solved_constants = solve_ics([s], [r['func']], cons(s), ics)
                except ValueError:
                    continue
                rv1.append(s.subs(solved_constants))
            if len(rv1) == 1:
                return rv1[0]
            rv = rv1
    return rv

def solve_ics(sols, funcs, constants, ics):
    x = funcs[0].args[0]
    diff_sols = []
    subs_sols = []
    diff_variables = set()
    for funcarg, value in ics.items():
        if isinstance(funcarg, AppliedUndef):
            x0 = funcarg.args[0]
            matching_func = [f for f in funcs if f.func == funcarg.func][0]
            S = sols
        elif isinstance(funcarg, (Subs, Derivative)):
            if isinstance(funcarg, Subs):
                funcarg = funcarg.doit()
            if isinstance(funcarg, Subs):
                deriv = funcarg.expr
                x0 = funcarg.point[0]
                variables = funcarg.expr.variables
                matching_func = deriv
            elif isinstance(funcarg, Derivative):
                deriv = funcarg
                x0 = funcarg.variables[0]
                variables = (x,) * len(funcarg.variables)
                matching_func = deriv.subs(x0, x)
            for sol in sols:
                if sol.has(deriv.expr.func):
                    diff_sols.append(Eq(sol.lhs.diff(*variables), sol.rhs.diff(*variables)))
            diff_variables.add(variables)
            S = diff_sols
        else:
            raise NotImplementedError('Unrecognized initial condition')
        for sol in S:
            if sol.has(matching_func):
                sol2 = sol
                sol2 = sol2.subs(x, x0)
                sol2 = sol2.subs(funcarg, value)
                if not isinstance(sol2, BooleanAtom) or not subs_sols:
                    subs_sols = [s for s in subs_sols if not isinstance(s, BooleanAtom)]
                    subs_sols.append(sol2)
    try:
        solved_constants = solve(subs_sols, constants, dict=True)
    except NotImplementedError:
        solved_constants = []
    if not solved_constants:
        raise ValueError("Couldn't solve for initial conditions")
    if solved_constants == True:
        raise ValueError('Initial conditions did not produce any solutions for constants. Perhaps they are degenerate.')
    if len(solved_constants) > 1:
        raise NotImplementedError('Initial conditions produced too many solutions for constants')
    return solved_constants[0]

def classify_ode(eq, func=None, dict=False, ics=None, *, prep=True, xi=None, eta=None, n=None, **kwargs):
    ics = sympify(ics)
    if func and len(func.args) != 1:
        raise ValueError('dsolve() and classify_ode() only work with functions of one variable, not %s' % func)
    if isinstance(eq, Equality):
        eq = eq.lhs - eq.rhs
    eq_orig = eq
    if prep or func is None:
        eq, func_ = _preprocess(eq, func)
        if func is None:
            func = func_
    x = func.args[0]
    f = func.func
    y = Dummy('y')
    terms = 5 if n is None else n
    order = ode_order(eq, f(x))
    matching_hints = {'order': order}
    df = f(x).diff(x)
    a = Wild('a', exclude=[f(x)])
    d = Wild('d', exclude=[df, f(x).diff(x, 2)])
    e = Wild('e', exclude=[df])
    n = Wild('n', exclude=[x, f(x), df])
    c1 = Wild('c1', exclude=[x])
    a3 = Wild('a3', exclude=[f(x), df, f(x).diff(x, 2)])
    b3 = Wild('b3', exclude=[f(x), df, f(x).diff(x, 2)])
    c3 = Wild('c3', exclude=[f(x), df, f(x).diff(x, 2)])
    boundary = {}
    C1 = Symbol('C1')
    if ics is not None:
        for funcarg in ics:
            if isinstance(funcarg, (Subs, Derivative)):
                if isinstance(funcarg, Subs):
                    deriv = funcarg.expr
                    old = funcarg.variables[0]
                    new = funcarg.point[0]
                elif isinstance(funcarg, Derivative):
                    deriv = funcarg
                    old = x
                    new = funcarg.variables[0]
                if isinstance(deriv, Derivative) and isinstance(deriv.args[0], AppliedUndef) and (deriv.args[0].func == f) and (len(deriv.args[0].args) == 1) and (old == x) and (not new.has(x)) and all((i == deriv.variables[0] for i in deriv.variables)) and (x not in ics[funcarg].free_symbols):
                    dorder = ode_order(deriv, x)
                    temp = 'f' + str(dorder)
                    boundary.update({temp: new, temp + 'val': ics[funcarg]})
                else:
                    raise ValueError('Invalid boundary conditions for Derivatives')
            elif isinstance(funcarg, AppliedUndef):
                if funcarg.func == f and len(funcarg.args) == 1 and (not funcarg.args[0].has(x)) and (x not in ics[funcarg].free_symbols):
                    boundary.update({'f0': funcarg.args[0], 'f0val': ics[funcarg]})
                else:
                    raise ValueError('Invalid boundary conditions for Function')
            else:
                raise ValueError('Enter boundary conditions of the form ics={f(point): value, f(x).diff(x, order).subs(x, point): value}')
    ode = SingleODEProblem(eq_orig, func, x, prep=prep, xi=xi, eta=eta)
    user_hint = kwargs.get('hint', 'default')
    early_exit = user_hint == 'default'
    user_hint = user_hint.removesuffix('_Integral')
    user_map = solver_map
    if user_hint not in ['default', 'all', 'all_Integral', 'best'] and user_hint in solver_map:
        user_map = {user_hint: solver_map[user_hint]}
    for hint in user_map:
        solver = user_map[hint](ode)
        if solver.matches():
            matching_hints[hint] = solver
            if user_map[hint].has_integral:
                matching_hints[hint + '_Integral'] = solver
            if dict and early_exit:
                matching_hints['default'] = hint
                return matching_hints
    eq = expand(eq)
    reduced_eq = None
    if eq.is_Add:
        deriv_coef = eq.coeff(f(x).diff(x, order))
        if deriv_coef not in (1, 0):
            r = deriv_coef.match(a * f(x) ** c1)
            if r and r[c1]:
                den = f(x) ** r[c1]
                reduced_eq = Add(*[arg / den for arg in eq.args])
    if not reduced_eq:
        reduced_eq = eq
    if order == 1:
        r = collect(eq, df, exact=True).match(d + e * df)
        if r:
            r['d'] = d
            r['e'] = e
            r['y'] = y
            r[d] = r[d].subs(f(x), y)
            r[e] = r[e].subs(f(x), y)
            point = boundary.get('f0', 0)
            value = boundary.get('f0val', C1)
            check = cancel(r[d] / r[e])
            check1 = check.subs({x: point, y: value})
            if not check1.has(oo) and (not check1.has(zoo)) and (not check1.has(nan)) and (not check1.has(-oo)):
                check2 = check1.diff(x).subs({x: point, y: value})
                if not check2.has(oo) and (not check2.has(zoo)) and (not check2.has(nan)) and (not check2.has(-oo)):
                    rseries = r.copy()
                    rseries.update({'terms': terms, 'f0': point, 'f0val': value})
                    matching_hints['1st_power_series'] = rseries
    elif order == 2:
        deq = a3 * f(x).diff(x, 2) + b3 * df + c3 * f(x)
        r = collect(reduced_eq, [f(x).diff(x, 2), f(x).diff(x), f(x)]).match(deq)
        ordinary = False
        if r:
            if not all((r[key].is_polynomial() for key in r)):
                n, d = reduced_eq.as_numer_denom()
                reduced_eq = expand(n)
                r = collect(reduced_eq, [f(x).diff(x, 2), f(x).diff(x), f(x)]).match(deq)
        if r and r[a3] != 0:
            p = cancel(r[b3] / r[a3])
            q = cancel(r[c3] / r[a3])
            point = kwargs.get('x0', 0)
            check = p.subs(x, point)
            if not check.has(oo, nan, zoo, -oo):
                check = q.subs(x, point)
                if not check.has(oo, nan, zoo, -oo):
                    ordinary = True
                    r.update({'a3': a3, 'b3': b3, 'c3': c3, 'x0': point, 'terms': terms})
                    matching_hints['2nd_power_series_ordinary'] = r
            if not ordinary:
                p = cancel((x - point) * p)
                check = p.subs(x, point)
                if not check.has(oo, nan, zoo, -oo):
                    q = cancel((x - point) ** 2 * q)
                    check = q.subs(x, point)
                    if not check.has(oo, nan, zoo, -oo):
                        coeff_dict = {'p': p, 'q': q, 'x0': point, 'terms': terms}
                        matching_hints['2nd_power_series_regular'] = coeff_dict
    retlist = [i for i in allhints if i in matching_hints]
    if dict:
        matching_hints['default'] = retlist[0] if retlist else None
        matching_hints['ordered_hints'] = tuple(retlist)
        return matching_hints
    else:
        return tuple(retlist)

def classify_sysode(eq, funcs=None, **kwargs):

    def _sympify(eq):
        return list(map(sympify, eq if iterable(eq) else [eq]))
    eq, funcs = (_sympify(w) for w in [eq, funcs])
    for i, fi in enumerate(eq):
        if isinstance(fi, Equality):
            eq[i] = fi.lhs - fi.rhs
    t = list(list(eq[0].atoms(Derivative))[0].atoms(Symbol))[0]
    matching_hints = {'no_of_equation': i + 1}
    matching_hints['eq'] = eq
    if i == 0:
        raise ValueError('classify_sysode() works for systems of ODEs. For scalar ODEs, classify_ode should be used')
    order = {}
    if funcs == [None]:
        funcs = _extract_funcs(eq)
    funcs = list(set(funcs))
    if len(funcs) != len(eq):
        raise ValueError('Number of functions given is not equal to the number of equations %s' % funcs)
    func_dict = {}
    for func in funcs:
        if not order.get(func, False):
            max_order = 0
            for i, eqs_ in enumerate(eq):
                order_ = ode_order(eqs_, func)
                if max_order < order_:
                    max_order = order_
                    eq_no = i
            if eq_no in func_dict:
                func_dict[eq_no] = [func_dict[eq_no], func]
            else:
                func_dict[eq_no] = func
            order[func] = max_order
    funcs = [func_dict[i] for i in range(len(func_dict))]
    matching_hints['func'] = funcs
    for func in funcs:
        if isinstance(func, list):
            for func_elem in func:
                if len(func_elem.args) != 1:
                    raise ValueError('dsolve() and classify_sysode() work with functions of one variable only, not %s' % func)
        elif func and len(func.args) != 1:
            raise ValueError('dsolve() and classify_sysode() work with functions of one variable only, not %s' % func)
    matching_hints['order'] = order

    def linearity_check(eqs, j, func, is_linear_):
        for k in range(order[func] + 1):
            func_coef[j, func, k] = collect(eqs.expand(), [diff(func, t, k)]).coeff(diff(func, t, k))
            if is_linear_ == True:
                if func_coef[j, func, k] == 0:
                    if k == 0:
                        coef = eqs.as_independent(func, as_Add=True)[1]
                        for xr in range(1, ode_order(eqs, func) + 1):
                            coef -= eqs.as_independent(diff(func, t, xr), as_Add=True)[1]
                        if coef != 0:
                            is_linear_ = False
                    elif eqs.as_independent(diff(func, t, k), as_Add=True)[1]:
                        is_linear_ = False
                else:
                    for func_ in funcs:
                        if isinstance(func_, list):
                            for elem_func_ in func_:
                                dep = func_coef[j, func, k].as_independent(elem_func_, as_Add=True)[1]
                                if dep != 0:
                                    is_linear_ = False
                        else:
                            dep = func_coef[j, func, k].as_independent(func_, as_Add=True)[1]
                            if dep != 0:
                                is_linear_ = False
        return is_linear_
    func_coef = {}
    is_linear = True
    for j, eqs in enumerate(eq):
        for func in funcs:
            if isinstance(func, list):
                for func_elem in func:
                    is_linear = linearity_check(eqs, j, func_elem, is_linear)
            else:
                is_linear = linearity_check(eqs, j, func, is_linear)
    matching_hints['func_coeff'] = func_coef
    matching_hints['is_linear'] = is_linear
    if len(set(order.values())) == 1:
        order_eq = list(matching_hints['order'].values())[0]
        if matching_hints['is_linear'] == True:
            if matching_hints['no_of_equation'] == 2:
                if order_eq == 1:
                    type_of_equation = check_linear_2eq_order1(eq, funcs, func_coef)
                else:
                    type_of_equation = None
            else:
                type_of_equation = None
        elif matching_hints['no_of_equation'] == 2:
            if order_eq == 1:
                type_of_equation = check_nonlinear_2eq_order1(eq, funcs, func_coef)
            else:
                type_of_equation = None
        elif matching_hints['no_of_equation'] == 3:
            if order_eq == 1:
                type_of_equation = check_nonlinear_3eq_order1(eq, funcs, func_coef)
            else:
                type_of_equation = None
        else:
            type_of_equation = None
    else:
        type_of_equation = None
    matching_hints['type_of_equation'] = type_of_equation
    return matching_hints

def check_linear_2eq_order1(eq, func, func_coef):
    x = func[0].func
    y = func[1].func
    fc = func_coef
    t = list(list(eq[0].atoms(Derivative))[0].atoms(Symbol))[0]
    r = {}
    r['a1'] = fc[0, x(t), 1]
    r['a2'] = fc[1, y(t), 1]
    r['b1'] = -fc[0, x(t), 0] / fc[0, x(t), 1]
    r['b2'] = -fc[1, x(t), 0] / fc[1, y(t), 1]
    r['c1'] = -fc[0, y(t), 0] / fc[0, x(t), 1]
    r['c2'] = -fc[1, y(t), 0] / fc[1, y(t), 1]
    forcing = [S.Zero, S.Zero]
    for i in range(2):
        for j in Add.make_args(eq[i]):
            if not j.has(x(t), y(t)):
                forcing[i] += j
    if not (forcing[0].has(t) or forcing[1].has(t)):
        r['d1'] = forcing[0]
        r['d2'] = forcing[1]
    else:
        return None
    p = 0
    q = 0
    p1 = cancel(r['b2'] / cancel(r['b2'] / r['c2']).as_numer_denom()[0])
    p2 = cancel(r['b1'] / cancel(r['b1'] / r['c1']).as_numer_denom()[0])
    for n, i in enumerate([p1, p2]):
        for j in Mul.make_args(collect_const(i)):
            if not j.has(t):
                q = j
            if q and n == 0:
                if (r['b2'] / j - r['b1']) / (r['c1'] - r['c2'] / j) == j:
                    p = 1
            elif q and n == 1:
                if (r['b1'] / j - r['b2']) / (r['c2'] - r['c1'] / j) == j:
                    p = 2
    if r['d1'] != 0 or r['d2'] != 0:
        return None
    elif not any((r[k].has(t) for k in 'a1 a2 b1 b2 c1 c2'.split())):
        return None
    else:
        r['b1'] = r['b1'] / r['a1']
        r['b2'] = r['b2'] / r['a2']
        r['c1'] = r['c1'] / r['a1']
        r['c2'] = r['c2'] / r['a2']
        if p:
            return 'type6'
        else:
            return 'type7'

def check_nonlinear_2eq_order1(eq, func, func_coef):
    t = list(list(eq[0].atoms(Derivative))[0].atoms(Symbol))[0]
    f = Wild('f')
    g = Wild('g')
    u, v = symbols('u, v', cls=Dummy)

    def check_type(x, y):
        r1 = eq[0].match(t * diff(x(t), t) - x(t) + f)
        r2 = eq[1].match(t * diff(y(t), t) - y(t) + g)
        if not (r1 and r2):
            r1 = eq[0].match(diff(x(t), t) - x(t) / t + f / t)
            r2 = eq[1].match(diff(y(t), t) - y(t) / t + g / t)
        if not (r1 and r2):
            r1 = (-eq[0]).match(t * diff(x(t), t) - x(t) + f)
            r2 = (-eq[1]).match(t * diff(y(t), t) - y(t) + g)
        if not (r1 and r2):
            r1 = (-eq[0]).match(diff(x(t), t) - x(t) / t + f / t)
            r2 = (-eq[1]).match(diff(y(t), t) - y(t) / t + g / t)
        if r1 and r2 and (not (r1[f].subs(diff(x(t), t), u).subs(diff(y(t), t), v).has(t) or r2[g].subs(diff(x(t), t), u).subs(diff(y(t), t), v).has(t))):
            return 'type5'
        else:
            return None
    for func_ in func:
        if isinstance(func_, list):
            x = func[0][0].func
            y = func[0][1].func
            eq_type = check_type(x, y)
            if not eq_type:
                eq_type = check_type(y, x)
            return eq_type
    x = func[0].func
    y = func[1].func
    fc = func_coef
    n = Wild('n', exclude=[x(t), y(t)])
    f1 = Wild('f1', exclude=[v, t])
    f2 = Wild('f2', exclude=[v, t])
    g1 = Wild('g1', exclude=[u, t])
    g2 = Wild('g2', exclude=[u, t])
    for i in range(2):
        eqs = 0
        for terms in Add.make_args(eq[i]):
            eqs += terms / fc[i, func[i], 1]
        eq[i] = eqs
    r = eq[0].match(diff(x(t), t) - x(t) ** n * f)
    if r:
        g = (diff(y(t), t) - eq[1]) / r[f]
    if r and (not (g.has(x(t)) or g.subs(y(t), v).has(t) or r[f].subs(x(t), u).subs(y(t), v).has(t))):
        return 'type1'
    r = eq[0].match(diff(x(t), t) - exp(n * x(t)) * f)
    if r:
        g = (diff(y(t), t) - eq[1]) / r[f]
    if r and (not (g.has(x(t)) or g.subs(y(t), v).has(t) or r[f].subs(x(t), u).subs(y(t), v).has(t))):
        return 'type2'
    g = Wild('g')
    r1 = eq[0].match(diff(x(t), t) - f)
    r2 = eq[1].match(diff(y(t), t) - g)
    if r1 and r2 and (not (r1[f].subs(x(t), u).subs(y(t), v).has(t) or r2[g].subs(x(t), u).subs(y(t), v).has(t))):
        return 'type3'
    r1 = eq[0].match(diff(x(t), t) - f)
    r2 = eq[1].match(diff(y(t), t) - g)
    num, den = (r1[f].subs(x(t), u).subs(y(t), v) / r2[g].subs(x(t), u).subs(y(t), v)).as_numer_denom()
    R1 = num.match(f1 * g1)
    R2 = den.match(f2 * g2)
    if R1 and R2:
        return 'type4'
    return None

def check_nonlinear_2eq_order2(eq, func, func_coef):
    return None

def check_nonlinear_3eq_order1(eq, func, func_coef):
    x = func[0].func
    y = func[1].func
    z = func[2].func
    fc = func_coef
    t = list(list(eq[0].atoms(Derivative))[0].atoms(Symbol))[0]
    u, v, w = symbols('u, v, w', cls=Dummy)
    a = Wild('a', exclude=[x(t), y(t), z(t), t])
    b = Wild('b', exclude=[x(t), y(t), z(t), t])
    c = Wild('c', exclude=[x(t), y(t), z(t), t])
    f = Wild('f')
    F1 = Wild('F1')
    F2 = Wild('F2')
    F3 = Wild('F3')
    for i in range(3):
        eqs = 0
        for terms in Add.make_args(eq[i]):
            eqs += terms / fc[i, func[i], 1]
        eq[i] = eqs
    r1 = eq[0].match(diff(x(t), t) - a * y(t) * z(t))
    r2 = eq[1].match(diff(y(t), t) - b * z(t) * x(t))
    r3 = eq[2].match(diff(z(t), t) - c * x(t) * y(t))
    if r1 and r2 and r3:
        num1, den1 = r1[a].as_numer_denom()
        num2, den2 = r2[b].as_numer_denom()
        num3, den3 = r3[c].as_numer_denom()
        if solve([num1 * u - den1 * (v - w), num2 * v - den2 * (w - u), num3 * w - den3 * (u - v)], [u, v]):
            return 'type1'
    r = eq[0].match(diff(x(t), t) - y(t) * z(t) * f)
    if r:
        r1 = collect_const(r[f]).match(a * f)
        r2 = ((diff(y(t), t) - eq[1]) / r1[f]).match(b * z(t) * x(t))
        r3 = ((diff(z(t), t) - eq[2]) / r1[f]).match(c * x(t) * y(t))
    if r1 and r2 and r3:
        num1, den1 = r1[a].as_numer_denom()
        num2, den2 = r2[b].as_numer_denom()
        num3, den3 = r3[c].as_numer_denom()
        if solve([num1 * u - den1 * (v - w), num2 * v - den2 * (w - u), num3 * w - den3 * (u - v)], [u, v]):
            return 'type2'
    r = eq[0].match(diff(x(t), t) - (F2 - F3))
    if r:
        r1 = collect_const(r[F2]).match(c * F2)
        r1.update(collect_const(r[F3]).match(b * F3))
        if r1:
            if eq[1].has(r1[F2]) and (not eq[1].has(r1[F3])):
                r1[F2], r1[F3] = (r1[F3], r1[F2])
                r1[c], r1[b] = (-r1[b], -r1[c])
            r2 = eq[1].match(diff(y(t), t) - a * r1[F3] + r1[c] * F1)
        if r2:
            r3 = eq[2] == diff(z(t), t) - r1[b] * r2[F1] + r2[a] * r1[F2]
        if r1 and r2 and r3:
            return 'type3'
    r = eq[0].match(diff(x(t), t) - z(t) * F2 + y(t) * F3)
    if r:
        r1 = collect_const(r[F2]).match(c * F2)
        r1.update(collect_const(r[F3]).match(b * F3))
        if r1:
            if eq[1].has(r1[F2]) and (not eq[1].has(r1[F3])):
                r1[F2], r1[F3] = (r1[F3], r1[F2])
                r1[c], r1[b] = (-r1[b], -r1[c])
            r2 = (diff(y(t), t) - eq[1]).match(a * x(t) * r1[F3] - r1[c] * z(t) * F1)
        if r2:
            r3 = diff(z(t), t) - eq[2] == r1[b] * y(t) * r2[F1] - r2[a] * x(t) * r1[F2]
        if r1 and r2 and r3:
            return 'type4'
    r = (diff(x(t), t) - eq[0]).match(x(t) * (F2 - F3))
    if r:
        r1 = collect_const(r[F2]).match(c * F2)
        r1.update(collect_const(r[F3]).match(b * F3))
        if r1:
            if eq[1].has(r1[F2]) and (not eq[1].has(r1[F3])):
                r1[F2], r1[F3] = (r1[F3], r1[F2])
                r1[c], r1[b] = (-r1[b], -r1[c])
            r2 = (diff(y(t), t) - eq[1]).match(y(t) * (a * r1[F3] - r1[c] * F1))
        if r2:
            r3 = diff(z(t), t) - eq[2] == z(t) * (r1[b] * r2[F1] - r2[a] * r1[F2])
        if r1 and r2 and r3:
            return 'type5'
    return None

def check_nonlinear_3eq_order2(eq, func, func_coef):
    return None

def odesimp(ode, eq, func, hint):
    x = func.args[0]
    f = func.func
    C1 = get_numbered_constants(eq, num=1)
    constants = eq.free_symbols - ode.free_symbols
    eq = _handle_Integral(eq, func, hint)
    if hint.startswith('nth_linear_euler_eq_nonhomogeneous'):
        eq = simplify(eq)
    if not isinstance(eq, Equality):
        raise TypeError('eq should be an instance of Equality')
    eq = eq.xreplace((_ := {i: Dummy(nonzero=True) for i in constants})).xreplace({_[i]: i for i in _})
    eq = constantsimp(eq, constants)
    if eq.rhs == func and (not eq.lhs.has(func)):
        eq = [Eq(eq.rhs, eq.lhs)]
    if eq.lhs == func and (not eq.rhs.has(func)):
        eq = [eq]
    else:
        try:
            floats = any((i.is_Float for i in eq.atoms(Number)))
            eqsol = solve(eq, func, force=True, rational=False if floats else None)
            if not eqsol:
                raise NotImplementedError
        except (NotImplementedError, PolynomialError):
            eq = [eq]
        else:

            def _expand(expr):
                numer, denom = expr.as_numer_denom()
                if denom.is_Add:
                    return expr
                else:
                    return powsimp(expr.expand(), combine='exp', deep=True)
            eq = [Eq(f(x), _expand(t)) for t in eqsol]
        if hint.startswith('1st_homogeneous_coeff'):
            for j, eqi in enumerate(eq):
                newi = logcombine(eqi, force=True)
                if isinstance(newi.lhs, log) and newi.rhs == 0:
                    newi = Eq(newi.lhs.args[0] / C1, C1)
                eq[j] = newi
    for i, eqi in enumerate(eq):
        eq[i] = constantsimp(eqi, constants)
        eq[i] = constant_renumber(eq[i], ode.free_symbols)
    if len(eq) == 1:
        eq = eq[0]
    return eq

def ode_sol_simplicity(sol, func, trysolving=True):
    if iterable(sol):
        for i in sol:
            if ode_sol_simplicity(i, func, trysolving=trysolving) == oo:
                return oo
        return len(str(sol))
    if sol.has(Integral):
        return oo
    if sol.lhs == func and (not sol.rhs.has(func)) or (sol.rhs == func and (not sol.lhs.has(func))):
        return -2
    if trysolving:
        try:
            sols = solve(sol, func)
            if not sols:
                raise NotImplementedError
        except NotImplementedError:
            pass
        else:
            return -1
    return len(str(sol))

def _extract_funcs(eqs):
    funcs = []
    for eq in eqs:
        derivs = [node for node in preorder_traversal(eq) if isinstance(node, Derivative)]
        func = []
        for d in derivs:
            func += list(d.atoms(AppliedUndef))
        for func_ in func:
            funcs.append(func_)
    funcs = list(uniq(funcs))
    return funcs

def _get_constant_subexpressions(expr, Cs):
    Cs = set(Cs)
    Ces = []

    def _recursive_walk(expr):
        expr_syms = expr.free_symbols
        if expr_syms and expr_syms.issubset(Cs):
            Ces.append(expr)
        else:
            if expr.func == exp:
                expr = expr.expand(mul=True)
            if expr.func in (Add, Mul):
                d = sift(expr.args, lambda i: i.free_symbols.issubset(Cs))
                if len(d[True]) > 1:
                    x = expr.func(*d[True])
                    if not x.is_number:
                        Ces.append(x)
            elif isinstance(expr, Integral):
                if expr.free_symbols.issubset(Cs) and all((len(x) == 3 for x in expr.limits)):
                    Ces.append(expr)
            for i in expr.args:
                _recursive_walk(i)
        return
    _recursive_walk(expr)
    return Ces

def __remove_linear_redundancies(expr, Cs):
    cnts = {i: expr.count(i) for i in Cs}
    Cs = [i for i in Cs if cnts[i] > 0]

    def _linear(expr):
        if isinstance(expr, Add):
            xs = [i for i in Cs if expr.count(i) == cnts[i] and 0 == expr.diff(i, 2)]
            d = {}
            for x in xs:
                y = expr.diff(x)
                if y not in d:
                    d[y] = []
                d[y].append(x)
            for y in d:
                if len(d[y]) > 1:
                    d[y].sort(key=str)
                    for x in d[y][1:]:
                        expr = expr.subs(x, 0)
        return expr

    def _recursive_walk(expr):
        if len(expr.args) != 0:
            expr = expr.func(*[_recursive_walk(i) for i in expr.args])
        expr = _linear(expr)
        return expr
    if isinstance(expr, Equality):
        lhs, rhs = [_recursive_walk(i) for i in expr.args]
        f = lambda i: isinstance(i, Number) or i in Cs
        if isinstance(lhs, Symbol) and lhs in Cs:
            rhs, lhs = (lhs, rhs)
        if lhs.func in (Add, Symbol) and rhs.func in (Add, Symbol):
            dlhs = sift([lhs] if isinstance(lhs, AtomicExpr) else lhs.args, f)
            drhs = sift([rhs] if isinstance(rhs, AtomicExpr) else rhs.args, f)
            for i in [True, False]:
                for hs in [dlhs, drhs]:
                    if i not in hs:
                        hs[i] = [0]
            lhs = Add(*dlhs[False]) - Add(*drhs[False])
            rhs = Add(*drhs[True]) - Add(*dlhs[True])
        elif lhs.func in (Mul, Symbol) and rhs.func in (Mul, Symbol):
            dlhs = sift([lhs] if isinstance(lhs, AtomicExpr) else lhs.args, f)
            if True in dlhs:
                if False not in dlhs:
                    dlhs[False] = [1]
                lhs = Mul(*dlhs[False])
                rhs = rhs / Mul(*dlhs[True])
        return Eq(lhs, rhs)
    else:
        return _recursive_walk(expr)

def constantsimp(expr, constants):
    Cs = constants
    orig_expr = expr
    constant_subexprs = _get_constant_subexpressions(expr, Cs)
    for xe in constant_subexprs:
        xes = list(xe.free_symbols)
        if not xes:
            continue
        if all((expr.count(c) == xe.count(c) for c in xes)):
            xes.sort(key=str)
            expr = expr.subs(xe, xes[0])
    try:
        commons, rexpr = cse(expr)
        commons.reverse()
        rexpr = rexpr[0]
        for s in commons:
            cs = list(s[1].atoms(Symbol))
            if len(cs) == 1 and cs[0] in Cs and (cs[0] not in rexpr.atoms(Symbol)) and (not any((cs[0] in ex for ex in commons if ex != s))):
                rexpr = rexpr.subs(s[0], cs[0])
            else:
                rexpr = rexpr.subs(*s)
        expr = rexpr
    except IndexError:
        pass
    expr = __remove_linear_redundancies(expr, Cs)

    def _conditional_term_factoring(expr):
        new_expr = terms_gcd(expr, clear=False, deep=True, expand=False)
        if new_expr.is_Mul:
            infac = False
            asfac = False
            for m in new_expr.args:
                if isinstance(m, exp):
                    asfac = True
                elif m.is_Add:
                    infac = any((isinstance(fi, exp) for t in m.args for fi in Mul.make_args(t)))
                if asfac and infac:
                    new_expr = expr
                    break
        return new_expr
    expr = _conditional_term_factoring(expr)
    if orig_expr != expr:
        return constantsimp(expr, Cs)
    return expr

def constant_renumber(expr, variables=None, newconstants=None):
    if isinstance(expr, (set, list, tuple)):
        return type(expr)(constant_renumber(Tuple(*expr), variables=variables, newconstants=newconstants))
    if variables is not None:
        variables = set(variables)
        free_symbols = expr.free_symbols
        constantsymbols = list(free_symbols - variables)
    else:
        variables = set()
        isconstant = lambda s: s.startswith('C') and s[1:].isdigit()
        constantsymbols = [sym for sym in expr.free_symbols if isconstant(sym.name)]
    if newconstants is None:
        iter_constants = numbered_symbols(start=1, prefix='C', exclude=variables)
    else:
        iter_constants = (sym for sym in newconstants if sym not in variables)
    constants_found = []
    C_1 = [(ci, S.One) for ci in constantsymbols]
    sort_key = lambda arg: default_sort_key(arg.subs(C_1))

    def _constant_renumber(expr):
        if isinstance(expr, Tuple):
            renumbered = [_constant_renumber(e) for e in expr]
            return Tuple(*renumbered)
        if isinstance(expr, Equality):
            return Eq(_constant_renumber(expr.lhs), _constant_renumber(expr.rhs))
        if type(expr) not in (Mul, Add, Pow) and (not expr.is_Function) and (not expr.has(*constantsymbols)):
            return expr
        elif expr.is_Piecewise:
            return expr
        elif expr in constantsymbols:
            if expr not in constants_found:
                constants_found.append(expr)
            return expr
        elif expr.is_Function or expr.is_Pow:
            return expr.func(*[_constant_renumber(x) for x in expr.args])
        else:
            sortedargs = list(expr.args)
            sortedargs.sort(key=sort_key)
            return expr.func(*[_constant_renumber(x) for x in sortedargs])
    expr = _constant_renumber(expr)
    constants_found = [c for c in constants_found if c not in variables]
    subs_dict = dict(zip(constants_found, iter_constants))
    expr = expr.subs(subs_dict, simultaneous=True)
    return expr

def _handle_Integral(expr, func, hint):
    if hint == 'nth_linear_constant_coeff_homogeneous':
        sol = expr
    elif not hint.endswith('_Integral'):
        sol = expr.doit()
    else:
        sol = expr
    return sol

def homogeneous_order(eq, *symbols):
    if not symbols:
        raise ValueError('homogeneous_order: no symbols were given.')
    symset = set(symbols)
    eq = sympify(eq)
    if eq.has(Order, Derivative):
        return None
    if eq.is_Number or eq.is_NumberSymbol or eq.is_number:
        return S.Zero
    dum = numbered_symbols(prefix='d', cls=Dummy)
    newsyms = set()
    for i in [j for j in symset if getattr(j, 'is_Function')]:
        iargs = set(i.args)
        if iargs.difference(symset):
            return None
        else:
            dummyvar = next(dum)
            eq = eq.subs(i, dummyvar)
            symset.remove(i)
            newsyms.add(dummyvar)
    symset.update(newsyms)
    if not eq.free_symbols & symset:
        return None
    if isinstance(eq, Function):
        return None if homogeneous_order(eq.args[0], *tuple(symset)) != 0 else S.Zero
    t = Dummy('t', positive=True)
    eqs = separatevars(eq.subs([(i, t * i) for i in symset]), [t], dict=True)[t]
    if eqs is S.One:
        return S.Zero
    i, d = eqs.as_independent(t, as_Add=False)
    b, e = d.as_base_exp()
    if b == t:
        return e

def ode_2nd_power_series_ordinary(eq, func, order, match):
    x = func.args[0]
    f = func.func
    C0, C1 = get_numbered_constants(eq, num=2)
    n = Dummy('n', integer=True)
    s = Wild('s')
    k = Wild('k', exclude=[x])
    x0 = match['x0']
    terms = match['terms']
    p = match[match['a3']]
    q = match[match['b3']]
    r = match[match['c3']]
    seriesdict = {}
    recurr = Function('r')
    coefflist = [(recurr(n), r), (n * recurr(n), q), (n * (n - 1) * recurr(n), p)]
    for index, coeff in enumerate(coefflist):
        if coeff[1]:
            f2 = powsimp(expand((coeff[1] * (x - x0) ** (n - index)).subs(x, x + x0)))
            if f2.is_Add:
                addargs = f2.args
            else:
                addargs = [f2]
            for arg in addargs:
                powm = arg.match(s * x ** k)
                term = coeff[0] * powm[s]
                if not powm[k].is_Symbol:
                    term = term.subs(n, n - powm[k].as_independent(n)[0])
                startind = powm[k].subs(n, index)
                if startind:
                    for i in reversed(range(startind)):
                        if not term.subs(n, i):
                            seriesdict[term] = i
                        else:
                            seriesdict[term] = i + 1
                            break
                else:
                    seriesdict[term] = S.Zero
    teq = S.Zero
    suminit = seriesdict.values()
    rkeys = seriesdict.keys()
    req = Add(*rkeys)
    if any(suminit):
        maxval = max(suminit)
        for term in seriesdict:
            val = seriesdict[term]
            if val != maxval:
                for i in range(val, maxval):
                    teq += term.subs(n, val)
    finaldict = {}
    if teq:
        fargs = teq.atoms(AppliedUndef)
        if len(fargs) == 1:
            finaldict[fargs.pop()] = 0
        else:
            maxf = max(fargs, key=lambda x: x.args[0])
            sol = solve(teq, maxf)
            if isinstance(sol, list):
                sol = sol[0]
            finaldict[maxf] = sol
    fargs = req.atoms(AppliedUndef)
    maxf = max(fargs, key=lambda x: x.args[0])
    minf = min(fargs, key=lambda x: x.args[0])
    if minf.args[0].is_Symbol:
        startiter = 0
    else:
        startiter = -minf.args[0].as_independent(n)[0]
    lhs = maxf
    rhs = solve(req, maxf)
    if isinstance(rhs, list):
        rhs = rhs[0]
    tcounter = len([t for t in finaldict.values() if t])
    for _ in range(tcounter, terms - 3):
        check = rhs.subs(n, startiter)
        nlhs = lhs.subs(n, startiter)
        nrhs = check.subs(finaldict)
        finaldict[nlhs] = nrhs
        startiter += 1
    series = C0 + C1 * (x - x0)
    for term in finaldict:
        if finaldict[term]:
            fact = term.args[0]
            series += finaldict[term].subs([(recurr(0), C0), (recurr(1), C1)]) * (x - x0) ** fact
    series = collect(expand_mul(series), [C0, C1]) + Order(x ** terms)
    return Eq(f(x), series)

def ode_2nd_power_series_regular(eq, func, order, match):
    x = func.args[0]
    f = func.func
    C0, C1 = get_numbered_constants(eq, num=2)
    m = Dummy('m')
    x0 = match['x0']
    terms = match['terms']
    p = match['p']
    q = match['q']
    indicial = []
    for term in [p, q]:
        if not term.has(x):
            indicial.append(term)
        else:
            term = series(term, x=x, n=1, x0=x0)
            if isinstance(term, Order):
                indicial.append(S.Zero)
            else:
                for arg in term.args:
                    if not arg.has(x):
                        indicial.append(arg)
                        break
    p0, q0 = indicial
    sollist = solve(m * (m - 1) + m * p0 + q0, m)
    if sollist and isinstance(sollist, list) and all((sol.is_real for sol in sollist)):
        serdict1 = {}
        serdict2 = {}
        if len(sollist) == 1:
            m1 = m2 = sollist.pop()
            if terms - m1 - 1 <= 0:
                return Eq(f(x), Order(terms))
            serdict1 = _frobenius(terms - m1 - 1, m1, p0, q0, p, q, x0, x, C0)
        else:
            m1 = sollist[0]
            m2 = sollist[1]
            if m1 < m2:
                m1, m2 = (m2, m1)
            serdict1 = _frobenius(terms - m1 - 1, m1, p0, q0, p, q, x0, x, C0)
            if not (m1 - m2).is_integer:
                serdict2 = _frobenius(terms - m2 - 1, m2, p0, q0, p, q, x0, x, C1)
            else:
                serdict2 = _frobenius(terms - m2 - 1, m2, p0, q0, p, q, x0, x, C1, check=m1)
        if serdict1:
            finalseries1 = C0
            for key in serdict1:
                power = int(key.name[1:])
                finalseries1 += serdict1[key] * (x - x0) ** power
            finalseries1 = (x - x0) ** m1 * finalseries1
            finalseries2 = S.Zero
            if serdict2:
                for key in serdict2:
                    power = int(key.name[1:])
                    finalseries2 += serdict2[key] * (x - x0) ** power
                finalseries2 += C1
                finalseries2 = (x - x0) ** m2 * finalseries2
            return Eq(f(x), collect(finalseries1 + finalseries2, [C0, C1]) + Order(x ** terms))

def _frobenius(n, m, p0, q0, p, q, x0, x, c, check=None):
    n = int(n)
    m2 = check
    d = Dummy('d')
    numsyms = numbered_symbols('C', start=0)
    numsyms = [next(numsyms) for i in range(n + 1)]
    serlist = []
    for ser in [p, q]:
        if ser.is_polynomial(x) and Poly(ser, x).degree() <= n:
            if x0:
                ser = ser.subs(x, x + x0)
            dict_ = Poly(ser, x).as_dict()
        else:
            tseries = series(ser, x=x0, n=n + 1)
            dict_ = Poly(list(ordered(tseries.args))[:-1], x).as_dict()
        for i in range(n + 1):
            if (i,) not in dict_:
                dict_[i,] = S.Zero
        serlist.append(dict_)
    pseries = serlist[0]
    qseries = serlist[1]
    indicial = d * (d - 1) + d * p0 + q0
    frobdict = {}
    for i in range(1, n + 1):
        num = c * (m * pseries[i,] + qseries[i,])
        for j in range(1, i):
            sym = Symbol('C' + str(j))
            num += frobdict[sym] * ((m + j) * pseries[i - j,] + qseries[i - j,])
        if m2 is not None and i == m2 - m:
            if num:
                return False
            else:
                frobdict[numsyms[i]] = S.Zero
        else:
            frobdict[numsyms[i]] = -num / indicial.subs(d, m + i)
    return frobdict

def _remove_redundant_solutions(eq, solns, order, var):

    def is_special_case_of(soln1, soln2):
        return _is_special_case_of(soln1, soln2, eq, order, var)
    unique_solns = []
    for soln1 in solns:
        for soln2 in unique_solns.copy():
            if is_special_case_of(soln1, soln2):
                break
            elif is_special_case_of(soln2, soln1):
                unique_solns.remove(soln2)
        else:
            unique_solns.append(soln1)
    return unique_solns

def _is_special_case_of(soln1, soln2, eq, order, var):
    soln1 = soln1.rhs - soln1.lhs
    soln2 = soln2.rhs - soln2.lhs
    if soln1.has(Order) and soln2.has(Order):
        if soln1.getO() == soln2.getO():
            soln1 = soln1.removeO()
            soln2 = soln2.removeO()
        else:
            return False
    elif soln1.has(Order) or soln2.has(Order):
        return False
    constants1 = soln1.free_symbols.difference(eq.free_symbols)
    constants2 = soln2.free_symbols.difference(eq.free_symbols)
    constants1_new = get_numbered_constants(Tuple(soln1, soln2), len(constants1))
    if len(constants1) == 1:
        constants1_new = {constants1_new}
    for c_old, c_new in zip(constants1, constants1_new):
        soln1 = soln1.subs(c_old, c_new)
    lhs = soln1
    rhs = soln2
    eqns = [Eq(lhs, rhs)]
    for n in range(1, order):
        lhs = lhs.diff(var)
        rhs = rhs.diff(var)
        eq = Eq(lhs, rhs)
        eqns.append(eq)
    if any((isinstance(eq, BooleanFalse) for eq in eqns)):
        return False
    eqns = [eq for eq in eqns if not isinstance(eq, BooleanTrue)]
    try:
        constant_solns = solve(eqns, constants2)
    except NotImplementedError:
        return False
    if isinstance(constant_solns, dict):
        constant_solns = [constant_solns]
    for constant_soln in constant_solns:
        for eq in eqns:
            eq = eq.rhs - eq.lhs
            if checksol(eq, constant_soln) is not True:
                return False
    for constant_soln in constant_solns:
        if not any((c.has(var) for c in constant_soln.values())):
            return True
    return False

def ode_1st_power_series(eq, func, order, match):
    x = func.args[0]
    y = match['y']
    f = func.func
    h = -match[match['d']] / match[match['e']]
    point = match['f0']
    value = match['f0val']
    terms = match['terms']
    F = h
    if not h:
        return Eq(f(x), value)
    series = value
    if terms > 1:
        hc = h.subs({x: point, y: value})
        if hc.has(oo) or hc.has(nan) or hc.has(zoo):
            return Eq(f(x), oo)
        elif hc:
            series += hc * (x - point)
    for factcount in range(2, terms):
        Fnew = F.diff(x) + F.diff(y) * h
        Fnewc = Fnew.subs({x: point, y: value})
        if Fnewc.has(oo) or Fnewc.has(nan) or Fnewc.has(-oo) or Fnewc.has(zoo):
            return Eq(f(x), oo)
        series += Fnewc * (x - point) ** factcount / factorial(factcount)
        F = Fnew
    series += Order(x ** terms)
    return Eq(f(x), series)

def checkinfsol(eq, infinitesimals, func=None, order=None):
    if isinstance(eq, Equality):
        eq = eq.lhs - eq.rhs
    if not func:
        eq, func = _preprocess(eq)
    variables = func.args
    if len(variables) != 1:
        raise ValueError("ODE's have only one independent variable")
    else:
        x = variables[0]
        if not order:
            order = ode_order(eq, func)
        if order != 1:
            raise NotImplementedError('Lie groups solver has been implemented only for first order differential equations')
        else:
            df = func.diff(x)
            a = Wild('a', exclude=[df])
            b = Wild('b', exclude=[df])
            match = collect(expand(eq), df).match(a * df + b)
            if match:
                h = -simplify(match[b] / match[a])
            else:
                try:
                    sol = solve(eq, df)
                except NotImplementedError:
                    raise NotImplementedError('Infinitesimals for the first order ODE could not be found')
                else:
                    h = sol[0]
            y = Dummy('y')
            h = h.subs(func, y)
            xi = Function('xi')(x, y)
            eta = Function('eta')(x, y)
            dxi = Function('xi')(x, func)
            deta = Function('eta')(x, func)
            pde = eta.diff(x) + (eta.diff(y) - xi.diff(x)) * h - xi.diff(y) * h ** 2 - xi * h.diff(x) - eta * h.diff(y)
            soltup = []
            for sol in infinitesimals:
                tsol = {xi: S(sol[dxi]).subs(func, y), eta: S(sol[deta]).subs(func, y)}
                sol = simplify(pde.subs(tsol).doit())
                if sol:
                    soltup.append((False, sol.subs(y, func)))
                else:
                    soltup.append((True, 0))
            return soltup

def sysode_linear_2eq_order1(match_):
    x = match_['func'][0].func
    y = match_['func'][1].func
    func = match_['func']
    fc = match_['func_coeff']
    eq = match_['eq']
    r = {}
    t = list(list(eq[0].atoms(Derivative))[0].atoms(Symbol))[0]
    for i in range(2):
        eq[i] = Add(*[terms / fc[i, func[i], 1] for terms in Add.make_args(eq[i])])
    r['a'] = -fc[0, x(t), 0] / fc[0, x(t), 1]
    r['c'] = -fc[1, x(t), 0] / fc[1, y(t), 1]
    r['b'] = -fc[0, y(t), 0] / fc[0, x(t), 1]
    r['d'] = -fc[1, y(t), 0] / fc[1, y(t), 1]
    forcing = [S.Zero, S.Zero]
    for i in range(2):
        for j in Add.make_args(eq[i]):
            if not j.has(x(t), y(t)):
                forcing[i] += j
    if not (forcing[0].has(t) or forcing[1].has(t)):
        r['k1'] = forcing[0]
        r['k2'] = forcing[1]
    else:
        raise NotImplementedError('Only homogeneous problems are supported' + ' (and constant inhomogeneity)')
    if match_['type_of_equation'] == 'type6':
        sol = _linear_2eq_order1_type6(x, y, t, r, eq)
    if match_['type_of_equation'] == 'type7':
        sol = _linear_2eq_order1_type7(x, y, t, r, eq)
    return sol

def _linear_2eq_order1_type6(x, y, t, r, eq):
    C1, C2, C3, C4 = get_numbered_constants(eq, num=4)
    p = 0
    q = 0
    p1 = cancel(r['c'] / cancel(r['c'] / r['d']).as_numer_denom()[0])
    p2 = cancel(r['a'] / cancel(r['a'] / r['b']).as_numer_denom()[0])
    for n, i in enumerate([p1, p2]):
        for j in Mul.make_args(collect_const(i)):
            if not j.has(t):
                q = j
            if q != 0 and n == 0:
                if (r['c'] / j - r['a']) / (r['b'] - r['d'] / j) == j:
                    p = 1
                    s = j
                    break
            if q != 0 and n == 1:
                if (r['a'] / j - r['c']) / (r['d'] - r['b'] / j) == j:
                    p = 2
                    s = j
                    break
    if p == 1:
        equ = diff(x(t), t) - r['a'] * x(t) - r['b'] * (s * x(t) + C1 * exp(-s * Integral(r['b'] - r['d'] / s, t)))
        hint1 = classify_ode(equ)[1]
        sol1 = dsolve(equ, hint=hint1 + '_Integral').rhs
        sol2 = s * sol1 + C1 * exp(-s * Integral(r['b'] - r['d'] / s, t))
    elif p == 2:
        equ = diff(y(t), t) - r['c'] * y(t) - r['d'] * s * y(t) + C1 * exp(-s * Integral(r['d'] - r['b'] / s, t))
        hint1 = classify_ode(equ)[1]
        sol2 = dsolve(equ, hint=hint1 + '_Integral').rhs
        sol1 = s * sol2 + C1 * exp(-s * Integral(r['d'] - r['b'] / s, t))
    return [Eq(x(t), sol1), Eq(y(t), sol2)]

def _linear_2eq_order1_type7(x, y, t, r, eq):
    C1, C2, C3, C4 = get_numbered_constants(eq, num=4)
    e1 = r['a'] * r['b'] * r['c'] - r['b'] ** 2 * r['c'] + r['a'] * diff(r['b'], t) - diff(r['a'], t) * r['b']
    e2 = r['a'] * r['c'] * r['d'] - r['b'] * r['c'] ** 2 + diff(r['c'], t) * r['d'] - r['c'] * diff(r['d'], t)
    m1 = r['a'] * r['b'] + r['b'] * r['d'] + diff(r['b'], t)
    m2 = r['a'] * r['c'] + r['c'] * r['d'] + diff(r['c'], t)
    if e1 == 0:
        sol1 = dsolve(r['b'] * diff(x(t), t, t) - m1 * diff(x(t), t)).rhs
        sol2 = dsolve(diff(y(t), t) - r['c'] * sol1 - r['d'] * y(t)).rhs
    elif e2 == 0:
        sol2 = dsolve(r['c'] * diff(y(t), t, t) - m2 * diff(y(t), t)).rhs
        sol1 = dsolve(diff(x(t), t) - r['a'] * x(t) - r['b'] * sol2).rhs
    elif not (e1 / r['b']).has(t) and (not (m1 / r['b']).has(t)):
        sol1 = dsolve(diff(x(t), t, t) - m1 / r['b'] * diff(x(t), t) - e1 / r['b'] * x(t)).rhs
        sol2 = dsolve(diff(y(t), t) - r['c'] * sol1 - r['d'] * y(t)).rhs
    elif not (e2 / r['c']).has(t) and (not (m2 / r['c']).has(t)):
        sol2 = dsolve(diff(y(t), t, t) - m2 / r['c'] * diff(y(t), t) - e2 / r['c'] * y(t)).rhs
        sol1 = dsolve(diff(x(t), t) - r['a'] * x(t) - r['b'] * sol2).rhs
    else:
        x0 = Function('x0')(t)
        y0 = Function('y0')(t)
        F = exp(Integral(r['a'], t))
        P = exp(Integral(r['d'], t))
        sol1 = C1 * x0 + C2 * x0 * Integral(r['b'] * F * P / x0 ** 2, t)
        sol2 = C1 * y0 + C2 * (F * P / x0 + y0 * Integral(r['b'] * F * P / x0 ** 2, t))
    return [Eq(x(t), sol1), Eq(y(t), sol2)]

def sysode_nonlinear_2eq_order1(match_):
    func = match_['func']
    eq = match_['eq']
    fc = match_['func_coeff']
    t = list(list(eq[0].atoms(Derivative))[0].atoms(Symbol))[0]
    if match_['type_of_equation'] == 'type5':
        sol = _nonlinear_2eq_order1_type5(func, t, eq)
        return sol
    x = func[0].func
    y = func[1].func
    for i in range(2):
        eqs = 0
        for terms in Add.make_args(eq[i]):
            eqs += terms / fc[i, func[i], 1]
        eq[i] = eqs
    if match_['type_of_equation'] == 'type1':
        sol = _nonlinear_2eq_order1_type1(x, y, t, eq)
    elif match_['type_of_equation'] == 'type2':
        sol = _nonlinear_2eq_order1_type2(x, y, t, eq)
    elif match_['type_of_equation'] == 'type3':
        sol = _nonlinear_2eq_order1_type3(x, y, t, eq)
    elif match_['type_of_equation'] == 'type4':
        sol = _nonlinear_2eq_order1_type4(x, y, t, eq)
    return sol

def _nonlinear_2eq_order1_type1(x, y, t, eq):
    C1, C2 = get_numbered_constants(eq, num=2)
    n = Wild('n', exclude=[x(t), y(t)])
    f = Wild('f')
    u, v = symbols('u, v')
    r = eq[0].match(diff(x(t), t) - x(t) ** n * f)
    g = ((diff(y(t), t) - eq[1]) / r[f]).subs(y(t), v)
    F = r[f].subs(x(t), u).subs(y(t), v)
    n = r[n]
    if n != 1:
        phi = (C1 + (1 - n) * Integral(1 / g, v)) ** (1 / (1 - n))
    else:
        phi = C1 * exp(Integral(1 / g, v))
    phi = phi.doit()
    sol2 = solve(Integral(1 / (g * F.subs(u, phi)), v).doit() - t - C2, v)
    sol = []
    for sols in sol2:
        sol.append(Eq(x(t), phi.subs(v, sols)))
        sol.append(Eq(y(t), sols))
    return sol

def _nonlinear_2eq_order1_type2(x, y, t, eq):
    C1, C2 = get_numbered_constants(eq, num=2)
    n = Wild('n', exclude=[x(t), y(t)])
    f = Wild('f')
    u, v = symbols('u, v')
    r = eq[0].match(diff(x(t), t) - exp(n * x(t)) * f)
    g = ((diff(y(t), t) - eq[1]) / r[f]).subs(y(t), v)
    F = r[f].subs(x(t), u).subs(y(t), v)
    n = r[n]
    if n:
        phi = -1 / n * log(C1 - n * Integral(1 / g, v))
    else:
        phi = C1 + Integral(1 / g, v)
    phi = phi.doit()
    sol2 = solve(Integral(1 / (g * F.subs(u, phi)), v).doit() - t - C2, v)
    sol = []
    for sols in sol2:
        sol.append(Eq(x(t), phi.subs(v, sols)))
        sol.append(Eq(y(t), sols))
    return sol

def _nonlinear_2eq_order1_type3(x, y, t, eq):
    C1, C2, C3, C4 = get_numbered_constants(eq, num=4)
    v = Function('v')
    u = Symbol('u')
    f = Wild('f')
    g = Wild('g')
    r1 = eq[0].match(diff(x(t), t) - f)
    r2 = eq[1].match(diff(y(t), t) - g)
    F = r1[f].subs(x(t), u).subs(y(t), v(u))
    G = r2[g].subs(x(t), u).subs(y(t), v(u))
    sol2r = dsolve(Eq(diff(v(u), u), G / F))
    if isinstance(sol2r, Equality):
        sol2r = [sol2r]
    for sol2s in sol2r:
        sol1 = solve(Integral(1 / F.subs(v(u), sol2s.rhs), u).doit() - t - C2, u)
    sol = []
    for sols in sol1:
        sol.append(Eq(x(t), sols))
        sol.append(Eq(y(t), sol2s.rhs.subs(u, sols)))
    return sol

def _nonlinear_2eq_order1_type4(x, y, t, eq):
    C1, C2 = get_numbered_constants(eq, num=2)
    u, v = symbols('u, v')
    U, V = symbols('U, V', cls=Function)
    f = Wild('f')
    g = Wild('g')
    f1 = Wild('f1', exclude=[v, t])
    f2 = Wild('f2', exclude=[v, t])
    g1 = Wild('g1', exclude=[u, t])
    g2 = Wild('g2', exclude=[u, t])
    r1 = eq[0].match(diff(x(t), t) - f)
    r2 = eq[1].match(diff(y(t), t) - g)
    num, den = (r1[f].subs(x(t), u).subs(y(t), v) / r2[g].subs(x(t), u).subs(y(t), v)).as_numer_denom()
    R1 = num.match(f1 * g1)
    R2 = den.match(f2 * g2)
    phi = r1[f].subs(x(t), u).subs(y(t), v) / num
    F1 = R1[f1]
    F2 = R2[f2]
    G1 = R1[g1]
    G2 = R2[g2]
    sol1r = solve(Integral(F2 / F1, u).doit() - Integral(G1 / G2, v).doit() - C1, u)
    sol2r = solve(Integral(F2 / F1, u).doit() - Integral(G1 / G2, v).doit() - C1, v)
    sol = []
    for sols in sol1r:
        sol.append(Eq(y(t), dsolve(diff(V(t), t) - F2.subs(u, sols).subs(v, V(t)) * G2.subs(v, V(t)) * phi.subs(u, sols).subs(v, V(t))).rhs))
    for sols in sol2r:
        sol.append(Eq(x(t), dsolve(diff(U(t), t) - F1.subs(u, U(t)) * G1.subs(v, sols).subs(u, U(t)) * phi.subs(v, sols).subs(u, U(t))).rhs))
    return set(sol)

def _nonlinear_2eq_order1_type5(func, t, eq):
    C1, C2 = get_numbered_constants(eq, num=2)
    f = Wild('f')
    g = Wild('g')

    def check_type(x, y):
        r1 = eq[0].match(t * diff(x(t), t) - x(t) + f)
        r2 = eq[1].match(t * diff(y(t), t) - y(t) + g)
        if not (r1 and r2):
            r1 = eq[0].match(diff(x(t), t) - x(t) / t + f / t)
            r2 = eq[1].match(diff(y(t), t) - y(t) / t + g / t)
        if not (r1 and r2):
            r1 = (-eq[0]).match(t * diff(x(t), t) - x(t) + f)
            r2 = (-eq[1]).match(t * diff(y(t), t) - y(t) + g)
        if not (r1 and r2):
            r1 = (-eq[0]).match(diff(x(t), t) - x(t) / t + f / t)
            r2 = (-eq[1]).match(diff(y(t), t) - y(t) / t + g / t)
        return [r1, r2]
    for func_ in func:
        if isinstance(func_, list):
            x = func[0][0].func
            y = func[0][1].func
            [r1, r2] = check_type(x, y)
            if not (r1 and r2):
                [r1, r2] = check_type(y, x)
                x, y = (y, x)
    x1 = diff(x(t), t)
    y1 = diff(y(t), t)
    return {Eq(x(t), C1 * t + r1[f].subs(x1, C1).subs(y1, C2)), Eq(y(t), C2 * t + r2[g].subs(x1, C1).subs(y1, C2))}

def sysode_nonlinear_3eq_order1(match_):
    x = match_['func'][0].func
    y = match_['func'][1].func
    z = match_['func'][2].func
    eq = match_['eq']
    t = list(list(eq[0].atoms(Derivative))[0].atoms(Symbol))[0]
    if match_['type_of_equation'] == 'type1':
        sol = _nonlinear_3eq_order1_type1(x, y, z, t, eq)
    if match_['type_of_equation'] == 'type2':
        sol = _nonlinear_3eq_order1_type2(x, y, z, t, eq)
    if match_['type_of_equation'] == 'type3':
        sol = _nonlinear_3eq_order1_type3(x, y, z, t, eq)
    if match_['type_of_equation'] == 'type4':
        sol = _nonlinear_3eq_order1_type4(x, y, z, t, eq)
    if match_['type_of_equation'] == 'type5':
        sol = _nonlinear_3eq_order1_type5(x, y, z, t, eq)
    return sol

def _nonlinear_3eq_order1_type1(x, y, z, t, eq):
    C1, C2 = get_numbered_constants(eq, num=2)
    u, v, w = symbols('u, v, w')
    p = Wild('p', exclude=[x(t), y(t), z(t), t])
    q = Wild('q', exclude=[x(t), y(t), z(t), t])
    s = Wild('s', exclude=[x(t), y(t), z(t), t])
    r = (diff(x(t), t) - eq[0]).match(p * y(t) * z(t))
    r.update((diff(y(t), t) - eq[1]).match(q * z(t) * x(t)))
    r.update((diff(z(t), t) - eq[2]).match(s * x(t) * y(t)))
    n1, d1 = r[p].as_numer_denom()
    n2, d2 = r[q].as_numer_denom()
    n3, d3 = r[s].as_numer_denom()
    val = solve([n1 * u - d1 * v + d1 * w, d2 * u + n2 * v - d2 * w, d3 * u - d3 * v - n3 * w], [u, v])
    vals = [val[v], val[u]]
    c = lcm(vals[0].as_numer_denom()[1], vals[1].as_numer_denom()[1])
    b = vals[0].subs(w, c)
    a = vals[1].subs(w, c)
    y_x = sqrt((c * C1 - C2 - a * (c - a) * x(t) ** 2) / (b * (c - b)))
    z_x = sqrt((b * C1 - C2 - a * (b - a) * x(t) ** 2) / (c * (b - c)))
    z_y = sqrt((a * C1 - C2 - b * (a - b) * y(t) ** 2) / (c * (a - c)))
    x_y = sqrt((c * C1 - C2 - b * (c - b) * y(t) ** 2) / (a * (c - a)))
    x_z = sqrt((b * C1 - C2 - c * (b - c) * z(t) ** 2) / (a * (b - a)))
    y_z = sqrt((a * C1 - C2 - c * (a - c) * z(t) ** 2) / (b * (a - b)))
    sol1 = dsolve(a * diff(x(t), t) - (b - c) * y_x * z_x)
    sol2 = dsolve(b * diff(y(t), t) - (c - a) * z_y * x_y)
    sol3 = dsolve(c * diff(z(t), t) - (a - b) * x_z * y_z)
    return [sol1, sol2, sol3]

def _nonlinear_3eq_order1_type2(x, y, z, t, eq):
    C1, C2 = get_numbered_constants(eq, num=2)
    u, v, w = symbols('u, v, w')
    p = Wild('p', exclude=[x(t), y(t), z(t), t])
    q = Wild('q', exclude=[x(t), y(t), z(t), t])
    s = Wild('s', exclude=[x(t), y(t), z(t), t])
    f = Wild('f')
    r1 = (diff(x(t), t) - eq[0]).match(y(t) * z(t) * f)
    r = collect_const(r1[f]).match(p * f)
    r.update(((diff(y(t), t) - eq[1]) / r[f]).match(q * z(t) * x(t)))
    r.update(((diff(z(t), t) - eq[2]) / r[f]).match(s * x(t) * y(t)))
    n1, d1 = r[p].as_numer_denom()
    n2, d2 = r[q].as_numer_denom()
    n3, d3 = r[s].as_numer_denom()
    val = solve([n1 * u - d1 * v + d1 * w, d2 * u + n2 * v - d2 * w, -d3 * u + d3 * v + n3 * w], [u, v])
    vals = [val[v], val[u]]
    c = lcm(vals[0].as_numer_denom()[1], vals[1].as_numer_denom()[1])
    a = vals[0].subs(w, c)
    b = vals[1].subs(w, c)
    y_x = sqrt((c * C1 - C2 - a * (c - a) * x(t) ** 2) / (b * (c - b)))
    z_x = sqrt((b * C1 - C2 - a * (b - a) * x(t) ** 2) / (c * (b - c)))
    z_y = sqrt((a * C1 - C2 - b * (a - b) * y(t) ** 2) / (c * (a - c)))
    x_y = sqrt((c * C1 - C2 - b * (c - b) * y(t) ** 2) / (a * (c - a)))
    x_z = sqrt((b * C1 - C2 - c * (b - c) * z(t) ** 2) / (a * (b - a)))
    y_z = sqrt((a * C1 - C2 - c * (a - c) * z(t) ** 2) / (b * (a - b)))
    sol1 = dsolve(a * diff(x(t), t) - (b - c) * y_x * z_x * r[f])
    sol2 = dsolve(b * diff(y(t), t) - (c - a) * z_y * x_y * r[f])
    sol3 = dsolve(c * diff(z(t), t) - (a - b) * x_z * y_z * r[f])
    return [sol1, sol2, sol3]

def _nonlinear_3eq_order1_type3(x, y, z, t, eq):
    C1 = get_numbered_constants(eq, num=1)
    u, v, w = symbols('u, v, w')
    fu, fv, fw = symbols('u, v, w', cls=Function)
    p = Wild('p', exclude=[x(t), y(t), z(t), t])
    q = Wild('q', exclude=[x(t), y(t), z(t), t])
    s = Wild('s', exclude=[x(t), y(t), z(t), t])
    F1, F2, F3 = symbols('F1, F2, F3', cls=Wild)
    r1 = (diff(x(t), t) - eq[0]).match(F2 - F3)
    r = collect_const(r1[F2]).match(s * F2)
    r.update(collect_const(r1[F3]).match(q * F3))
    if eq[1].has(r[F2]) and (not eq[1].has(r[F3])):
        r[F2], r[F3] = (r[F3], r[F2])
        r[s], r[q] = (-r[q], -r[s])
    r.update((diff(y(t), t) - eq[1]).match(p * r[F3] - r[s] * F1))
    a = r[p]
    b = r[q]
    c = r[s]
    F1 = r[F1].subs(x(t), u).subs(y(t), v).subs(z(t), w)
    F2 = r[F2].subs(x(t), u).subs(y(t), v).subs(z(t), w)
    F3 = r[F3].subs(x(t), u).subs(y(t), v).subs(z(t), w)
    z_xy = (C1 - a * u - b * v) / c
    y_zx = (C1 - a * u - c * w) / b
    x_yz = (C1 - b * v - c * w) / a
    y_x = dsolve(diff(fv(u), u) - ((a * F3 - c * F1) / (c * F2 - b * F3)).subs(w, z_xy).subs(v, fv(u))).rhs
    z_x = dsolve(diff(fw(u), u) - ((b * F1 - a * F2) / (c * F2 - b * F3)).subs(v, y_zx).subs(w, fw(u))).rhs
    z_y = dsolve(diff(fw(v), v) - ((b * F1 - a * F2) / (a * F3 - c * F1)).subs(u, x_yz).subs(w, fw(v))).rhs
    x_y = dsolve(diff(fu(v), v) - ((c * F2 - b * F3) / (a * F3 - c * F1)).subs(w, z_xy).subs(u, fu(v))).rhs
    y_z = dsolve(diff(fv(w), w) - ((a * F3 - c * F1) / (b * F1 - a * F2)).subs(u, x_yz).subs(v, fv(w))).rhs
    x_z = dsolve(diff(fu(w), w) - ((c * F2 - b * F3) / (b * F1 - a * F2)).subs(v, y_zx).subs(u, fu(w))).rhs
    sol1 = dsolve(diff(fu(t), t) - (c * F2 - b * F3).subs(v, y_x).subs(w, z_x).subs(u, fu(t))).rhs
    sol2 = dsolve(diff(fv(t), t) - (a * F3 - c * F1).subs(u, x_y).subs(w, z_y).subs(v, fv(t))).rhs
    sol3 = dsolve(diff(fw(t), t) - (b * F1 - a * F2).subs(u, x_z).subs(v, y_z).subs(w, fw(t))).rhs
    return [sol1, sol2, sol3]

def _nonlinear_3eq_order1_type4(x, y, z, t, eq):
    C1 = get_numbered_constants(eq, num=1)
    u, v, w = symbols('u, v, w')
    p = Wild('p', exclude=[x(t), y(t), z(t), t])
    q = Wild('q', exclude=[x(t), y(t), z(t), t])
    s = Wild('s', exclude=[x(t), y(t), z(t), t])
    F1, F2, F3 = symbols('F1, F2, F3', cls=Wild)
    r1 = eq[0].match(diff(x(t), t) - z(t) * F2 + y(t) * F3)
    r = collect_const(r1[F2]).match(s * F2)
    r.update(collect_const(r1[F3]).match(q * F3))
    if eq[1].has(r[F2]) and (not eq[1].has(r[F3])):
        r[F2], r[F3] = (r[F3], r[F2])
        r[s], r[q] = (-r[q], -r[s])
    r.update((diff(y(t), t) - eq[1]).match(p * x(t) * r[F3] - r[s] * z(t) * F1))
    a = r[p]
    b = r[q]
    c = r[s]
    F1 = r[F1].subs(x(t), u).subs(y(t), v).subs(z(t), w)
    F2 = r[F2].subs(x(t), u).subs(y(t), v).subs(z(t), w)
    F3 = r[F3].subs(x(t), u).subs(y(t), v).subs(z(t), w)
    x_yz = sqrt((C1 - b * v ** 2 - c * w ** 2) / a)
    y_zx = sqrt((C1 - c * w ** 2 - a * u ** 2) / b)
    z_xy = sqrt((C1 - a * u ** 2 - b * v ** 2) / c)
    y_x = dsolve(diff(v(u), u) - ((a * u * F3 - c * w * F1) / (c * w * F2 - b * v * F3)).subs(w, z_xy).subs(v, v(u))).rhs
    z_x = dsolve(diff(w(u), u) - ((b * v * F1 - a * u * F2) / (c * w * F2 - b * v * F3)).subs(v, y_zx).subs(w, w(u))).rhs
    z_y = dsolve(diff(w(v), v) - ((b * v * F1 - a * u * F2) / (a * u * F3 - c * w * F1)).subs(u, x_yz).subs(w, w(v))).rhs
    x_y = dsolve(diff(u(v), v) - ((c * w * F2 - b * v * F3) / (a * u * F3 - c * w * F1)).subs(w, z_xy).subs(u, u(v))).rhs
    y_z = dsolve(diff(v(w), w) - ((a * u * F3 - c * w * F1) / (b * v * F1 - a * u * F2)).subs(u, x_yz).subs(v, v(w))).rhs
    x_z = dsolve(diff(u(w), w) - ((c * w * F2 - b * v * F3) / (b * v * F1 - a * u * F2)).subs(v, y_zx).subs(u, u(w))).rhs
    sol1 = dsolve(diff(u(t), t) - (c * w * F2 - b * v * F3).subs(v, y_x).subs(w, z_x).subs(u, u(t))).rhs
    sol2 = dsolve(diff(v(t), t) - (a * u * F3 - c * w * F1).subs(u, x_y).subs(w, z_y).subs(v, v(t))).rhs
    sol3 = dsolve(diff(w(t), t) - (b * v * F1 - a * u * F2).subs(u, x_z).subs(v, y_z).subs(w, w(t))).rhs
    return [sol1, sol2, sol3]

def _nonlinear_3eq_order1_type5(x, y, z, t, eq):
    C1 = get_numbered_constants(eq, num=1)
    u, v, w = symbols('u, v, w')
    fu, fv, fw = symbols('u, v, w', cls=Function)
    p = Wild('p', exclude=[x(t), y(t), z(t), t])
    q = Wild('q', exclude=[x(t), y(t), z(t), t])
    s = Wild('s', exclude=[x(t), y(t), z(t), t])
    F1, F2, F3 = symbols('F1, F2, F3', cls=Wild)
    r1 = eq[0].match(diff(x(t), t) - x(t) * F2 + x(t) * F3)
    r = collect_const(r1[F2]).match(s * F2)
    r.update(collect_const(r1[F3]).match(q * F3))
    if eq[1].has(r[F2]) and (not eq[1].has(r[F3])):
        r[F2], r[F3] = (r[F3], r[F2])
        r[s], r[q] = (-r[q], -r[s])
    r.update((diff(y(t), t) - eq[1]).match(y(t) * (p * r[F3] - r[s] * F1)))
    a = r[p]
    b = r[q]
    c = r[s]
    F1 = r[F1].subs(x(t), u).subs(y(t), v).subs(z(t), w)
    F2 = r[F2].subs(x(t), u).subs(y(t), v).subs(z(t), w)
    F3 = r[F3].subs(x(t), u).subs(y(t), v).subs(z(t), w)
    x_yz = (C1 * v ** (-b) * w ** (-c)) ** (-a)
    y_zx = (C1 * w ** (-c) * u ** (-a)) ** (-b)
    z_xy = (C1 * u ** (-a) * v ** (-b)) ** (-c)
    y_x = dsolve(diff(fv(u), u) - (v * (a * F3 - c * F1) / (u * (c * F2 - b * F3))).subs(w, z_xy).subs(v, fv(u))).rhs
    z_x = dsolve(diff(fw(u), u) - (w * (b * F1 - a * F2) / (u * (c * F2 - b * F3))).subs(v, y_zx).subs(w, fw(u))).rhs
    z_y = dsolve(diff(fw(v), v) - (w * (b * F1 - a * F2) / (v * (a * F3 - c * F1))).subs(u, x_yz).subs(w, fw(v))).rhs
    x_y = dsolve(diff(fu(v), v) - (u * (c * F2 - b * F3) / (v * (a * F3 - c * F1))).subs(w, z_xy).subs(u, fu(v))).rhs
    y_z = dsolve(diff(fv(w), w) - (v * (a * F3 - c * F1) / (w * (b * F1 - a * F2))).subs(u, x_yz).subs(v, fv(w))).rhs
    x_z = dsolve(diff(fu(w), w) - (u * (c * F2 - b * F3) / (w * (b * F1 - a * F2))).subs(v, y_zx).subs(u, fu(w))).rhs
    sol1 = dsolve(diff(fu(t), t) - (u * (c * F2 - b * F3)).subs(v, y_x).subs(w, z_x).subs(u, fu(t))).rhs
    sol2 = dsolve(diff(fv(t), t) - (v * (a * F3 - c * F1)).subs(u, x_y).subs(w, z_y).subs(v, fv(t))).rhs
    sol3 = dsolve(diff(fw(t), t) - (w * (b * F1 - a * F2)).subs(u, x_z).subs(v, y_z).subs(w, fw(t))).rhs
    return [sol1, sol2, sol3]
from .single import SingleODEProblem, SingleODESolver, solver_map