from __future__ import annotations
from sympy.core import sympify
from sympy.core.exprtools import factor_terms
from sympy.core.relational import Le, Ge, Eq
from sympy.core.singleton import S
from sympy.core.symbol import Dummy
from sympy.core.sorting import ordered
from sympy.functions.elementary.complexes import sign
from sympy.matrices.dense import Matrix, zeros
from sympy.solvers.solveset import linear_eq_to_matrix
from sympy.utilities.iterables import numbered_symbols
from sympy.utilities.misc import filldedent

class UnboundedLPError(Exception):
    pass

class InfeasibleLPError(Exception):
    pass

def _pivot(M, i, j):
    Mi, Mj, Mij = (M[i, :], M[:, j], M[i, j])
    if Mij == 0:
        raise ZeroDivisionError('Tried to pivot about zero-valued entry.')
    A = M - Mj * (Mi / Mij)
    A[i, :] = Mi / Mij
    A[:, j] = -Mj / Mij
    A[i, j] = 1 / Mij
    return A

def _choose_pivot_row(A, B, candidate_rows, pivot_col, Y):
    return min(candidate_rows, key=lambda i: (B[i] / A[i, pivot_col], Y[i]))

def _simplex(A, B, C, D=None, dual=False):
    A, B, C, D = [Matrix(i) for i in (A, B, C, D or [0])]
    if dual:
        _o, d, p = _simplex(-A.T, C.T, B.T, -D)
        return (-_o, d, p)
    if A and B:
        M = Matrix([[A, B], [C, D]])
    else:
        if A or B:
            raise ValueError('must give A and B')
        M = Matrix([[C, D]])
    n = M.cols - 1
    m = M.rows - 1
    if not all((i.is_Float or i.is_Rational for i in M)):
        raise TypeError(filldedent('\n            Only rationals and floats are allowed.\n            '))
    X = [(False, j) for j in range(n)]
    Y = [(True, i) for i in range(m)]
    while True:
        B = M[:-1, -1]
        A = M[:-1, :-1]
        if all((B[i] >= 0 for i in range(B.rows))):
            break
        for k in range(B.rows):
            if B[k] < 0:
                break
        else:
            pass
        piv_cols = [_ for _ in range(A.cols) if A[k, _] < 0]
        if not piv_cols:
            raise InfeasibleLPError(filldedent('\n                The constraint set is empty!'))
        _, c = min(((X[i], i) for i in piv_cols))
        piv_rows = [_ for _ in range(A.rows) if A[_, c] > 0 and B[_] >= 0]
        piv_rows.append(k)
        r = _choose_pivot_row(A, B, piv_rows, c, Y)
        M = _pivot(M, r, c)
        X[c], Y[r] = (Y[r], X[c])
    while True:
        B = M[:-1, -1]
        A = M[:-1, :-1]
        C = M[-1, :-1]
        piv_cols = [_ for _ in range(n) if C[_] < 0]
        if not piv_cols:
            break
        _, c = min(((X[i], i) for i in piv_cols))
        piv_rows = [_ for _ in range(m) if A[_, c] > 0]
        if not piv_rows:
            raise UnboundedLPError(filldedent('\n                Objective function can assume\n                arbitrarily large values!'))
        r = _choose_pivot_row(A, B, piv_rows, c, Y)
        M = _pivot(M, r, c)
        X[c], Y[r] = (Y[r], X[c])
    argmax = [None] * n
    argmin_dual = [None] * m
    for i, (v, n) in enumerate(X):
        if v == False:
            argmax[n] = S.Zero
        else:
            argmin_dual[n] = M[-1, i]
    for i, (v, n) in enumerate(Y):
        if v == True:
            argmin_dual[n] = S.Zero
        else:
            argmax[n] = M[i, -1]
    return (-M[-1, -1], argmax, argmin_dual)

def _abcd(M, list=False):

    def aslist(i):
        l = i.tolist()
        if len(l[0]) == 1:
            return [i[0] for i in l]
        return l
    m = (M[:-1, :-1], M[:-1, -1], M[-1, :-1], M[-1:, -1:])
    if not list:
        return m
    return tuple([aslist(i) for i in m])

def _m(a, b, c, d=None):
    a, b, c, d = [Matrix(i) for i in (a, b, c, d or [0])]
    return Matrix([[a, b], [c, d]])

def _primal_dual(M, factor=True):
    if not M:
        return ((None, []), (None, []))
    if not hasattr(M, 'shape'):
        if len(M) not in (3, 4):
            raise ValueError('expecting Matrix or 3 or 4 lists')
        M = _m(*M)
    m, n = [i - 1 for i in M.shape]
    A, b, c, d = _abcd(M)
    d = d[0]
    _ = lambda x: numbered_symbols(x, start=1)
    x = Matrix([i for i, j in zip(_('x'), range(n))])
    yT = Matrix([i for i, j in zip(_('y'), range(m))]).T

    def ineq(L, r, op):
        rv = []
        for r in (op(i, j) for i, j in zip(L, r)):
            if r == True:
                continue
            elif r == False:
                return [False]
            if factor:
                f = factor_terms(r)
                if f.lhs.is_Mul and f.rhs % f.lhs.args[0] == 0:
                    assert len(f.lhs.args) == 2, f.lhs
                    k = f.lhs.args[0]
                    r = r.func(sign(k) * f.lhs.args[1], f.rhs // abs(k))
            rv.append(r)
        return rv
    eq = lambda x, d: x[0] - d if x else -d
    F = eq(c * x, d)
    f = eq(yT * b, d)
    return ((F, ineq(A * x, b, Ge)), (f, ineq(yT * A, c, Le)))

def _rel_as_nonpos(constr, syms):
    r = {}
    np = []
    aux = []
    ui = numbered_symbols('z', start=1, cls=Dummy)
    univariate = {}
    unbound = []
    syms = set(syms)
    for i in constr:
        if i == True:
            continue
        if i == False:
            return
        if i.has(S.Infinity, S.NegativeInfinity):
            raise ValueError('only finite bounds are permitted')
        if isinstance(i, (Le, Ge)):
            i = i.lts - i.gts
            freei = i.free_symbols
            if freei - syms:
                raise ValueError('unexpected symbol(s) in constraint: %s' % (freei - syms))
            if len(freei) > 1:
                np.append(i)
            elif freei:
                x = freei.pop()
                if x in unbound:
                    continue
                ivl = Le(i, 0, evaluate=False).as_set()
                if x not in univariate:
                    univariate[x] = ivl
                else:
                    univariate[x] &= ivl
            elif i:
                return False
        else:
            raise TypeError(filldedent('\n                only equalities like Eq(x, y) or non-strict\n                inequalities like x >= y are allowed in lp, not %s' % i))
    for x in syms:
        i = univariate.get(x, True)
        if not i:
            return None
        if i == True:
            unbound.append(x)
            continue
        a, b = (i.inf, i.sup)
        if a.is_infinite:
            u = next(ui)
            r[x] = b - u
            aux.append(u)
        elif b.is_infinite:
            if a:
                u = next(ui)
                r[x] = a + u
                aux.append(u)
            else:
                pass
        else:
            u = next(ui)
            aux.append(u)
            r[x] = u + a
            np.append(u - (b - a))
    for x in unbound:
        u = next(ui)
        r[x] = u - x
        aux.append(u)
    return (np, r, aux)

def _lp_matrices(objective, constraints):
    F = sympify(objective)
    np = [sympify(i) for i in constraints]
    syms = set.union(*[i.free_symbols for i in [F] + np], set())
    for i in range(len(np)):
        if isinstance(np[i], Eq):
            np[i] = np[i].lhs - np[i].rhs <= 0
            np.append(-np[i].lhs <= 0)
    _ = _rel_as_nonpos(np, syms)
    if _ is None:
        raise InfeasibleLPError(filldedent('\n            Inconsistent/False constraint'))
    np, r, aux = _
    F = F.xreplace(r)
    np = [i.xreplace(r) for i in np]
    xx = list(ordered(syms)) + aux
    A, B = linear_eq_to_matrix(np, xx)
    C, D = linear_eq_to_matrix([F], xx)
    return (A, B, C, D, r, xx, aux)

def _lp(min_max, f, constr):
    A, B, C, D, r, xx, aux = _lp_matrices(f, constr)
    how = str(min_max).lower()
    if 'max' in how:
        _o, p, d = _simplex(A, B, -C, -D)
        o = -_o
    elif 'min' in how:
        o, p, d = _simplex(A, B, C, D)
    else:
        raise ValueError('expecting min or max')
    p = dict(zip(xx, p))
    if r:
        r = {k: v.xreplace(p) for k, v in r.items()}
        p.update(r)
        p = {k: p[k] for k in ordered(p) if k not in aux}
    return (o, p)

def lpmin(f, constr):
    return _lp(min, f, constr)

def lpmax(f, constr):
    return _lp(max, f, constr)

def _handle_bounds(bounds):

    def _make_list(length: int, index_value_pairs):
        li = [0] * length
        for idx, val in index_value_pairs:
            li[idx] = val
        return li
    unbound = []
    row = []
    row2 = []
    b_len = len(bounds)
    for x, (a, b) in enumerate(bounds):
        if a is None and b is None:
            unbound.append(x)
        elif a is None:
            b_len += 1
            row.append(_make_list(b_len, [(x, 1), (-1, 1)]))
            row.append(_make_list(b_len, [(x, -1), (-1, -1)]))
            row2.extend([[b], [-b]])
        elif b is None:
            if a:
                b_len += 1
                row.append(_make_list(b_len, [(x, 1), (-1, -1)]))
                row.append(_make_list(b_len, [(x, -1), (-1, 1)]))
                row2.extend([[a], [-a]])
            else:
                pass
        else:
            b_len += 1
            row.append(_make_list(b_len, [(x, 1), (-1, -1)]))
            row.append(_make_list(b_len, [(x, -1), (-1, 1)]))
            row.append(_make_list(b_len, [(-1, 1)]))
            row2.extend([[a], [-a], [b - a]])
    for x in unbound:
        b_len += 2
        row.append(_make_list(b_len, [(x, 1), (-1, 1), (-2, -1)]))
        row.append(_make_list(b_len, [(x, -1), (-1, -1), (-2, 1)]))
        row2.extend([[0], [0]])
    return (Matrix([r + [0] * (b_len - len(r)) for r in row]), Matrix(row2))

def linprog(c, A=None, b=None, A_eq=None, b_eq=None, bounds=None):
    C = Matrix(c)
    if C.rows != 1 and C.cols == 1:
        C = C.T
    if C.rows != 1:
        raise ValueError('C must be a single row.')
    if not A:
        if b:
            raise ValueError('A and b must both be given')
        A, b = (zeros(0, C.cols), zeros(0, 1))
    else:
        A, b = [Matrix(i) for i in (A, b)]
    if A.cols != C.cols:
        raise ValueError('number of columns in A and C must match')
    if A_eq is None:
        if b_eq is not None:
            raise ValueError('A_eq and b_eq must both be given')
            A_eq = zeros(0, C.cols)
            b_eq = zeros(0, 1)
    else:
        A_eq = Matrix(A_eq)
        b_eq = Matrix(b_eq)
        A = A.col_join(A_eq)
        A = A.col_join(-A_eq)
        b = b.col_join(b_eq)
        b = b.col_join(-b_eq)
    if not (bounds is None or bounds == {} or bounds == (0, None)):
        if type(bounds) is tuple and len(bounds) == 2:
            bounds = [bounds] * A.cols
        elif len(bounds) == A.cols and all((type(i) is tuple and len(i) == 2 for i in bounds)):
            pass
        elif type(bounds) is dict and all((type(i) is tuple and len(i) == 2 for i in bounds.values())):
            db = bounds
            bounds = [(0, None)] * A.cols
            while db:
                i, j = db.popitem()
                bounds[i] = j
        else:
            raise ValueError('unexpected bounds %s' % bounds)
        A_, b_ = _handle_bounds(bounds)
        aux = A_.cols - A.cols
        if A:
            A = Matrix([[A, zeros(A.rows, aux)], [A_]])
            b = b.col_join(b_)
        else:
            A = A_
            b = b_
        C = C.row_join(zeros(1, aux))
    else:
        aux = -A.cols
    o, p, d = _simplex(A, b, C)
    return (o, p[:-aux])

def show_linprog(c, A=None, b=None, A_eq=None, b_eq=None, bounds=None):
    from sympy import symbols
    C = Matrix(c)
    if C.rows != 1 and C.cols == 1:
        C = C.T
    if C.rows != 1:
        raise ValueError('C must be a single row.')
    if not A:
        if b:
            raise ValueError('A and b must both be given')
        A, b = (zeros(0, C.cols), zeros(0, 1))
    else:
        if not b:
            raise ValueError('A and b must both be given')
        A, b = [Matrix(i) for i in (A, b)]
    if A.cols != C.cols:
        raise ValueError('number of columns in A and C must match')
    if A_eq is None:
        if b_eq is not None:
            raise ValueError('A_eq and b_eq must both be given')
        A_eq = zeros(0, C.cols)
        b_eq = zeros(0, 1)
    else:
        A_eq = Matrix(A_eq)
        b_eq = Matrix(b_eq)
    if bounds is None or bounds == {} or bounds == (0, None):
        bounds = [(0, None)] * C.cols
    elif type(bounds) is tuple and len(bounds) == 2:
        bounds = [bounds] * A.cols
    elif len(bounds) == A.cols and all((type(i) is tuple and len(i) == 2 for i in bounds)):
        pass
    elif type(bounds) is dict and all((type(i) is tuple and len(i) == 2 for i in bounds.values())):
        db = bounds
        bounds = [(0, None)] * A.cols
        while db:
            i, j = db.popitem()
            bounds[i] = j
    else:
        raise ValueError('unexpected bounds %s' % bounds)
    x = Matrix(symbols('x1:%s' % (A.cols + 1)))
    f, c = ((C * x)[0], [i <= j for i, j in zip(A * x, b)] + [Eq(i, j) for i, j in zip(A_eq * x, b_eq)])
    for i, (lo, hi) in enumerate(bounds):
        if lo is not None:
            c.append(x[i] >= lo)
        if hi is not None:
            c.append(x[i] <= hi)
    return (f, c)