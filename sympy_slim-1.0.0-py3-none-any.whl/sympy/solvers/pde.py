from __future__ import annotations
from functools import reduce
from itertools import combinations_with_replacement
from sympy.simplify import simplify
from sympy.core import Add, S
from sympy.core.function import Function, expand, AppliedUndef, Subs
from sympy.core.relational import Equality, Eq
from sympy.core.symbol import Symbol, Wild, symbols
from sympy.functions import exp
from sympy.integrals.integrals import Integral, integrate
from sympy.utilities.iterables import has_dups, is_sequence
from sympy.utilities.misc import filldedent
from sympy.solvers.deutils import _preprocess, ode_order, _desolve
from sympy.solvers.solvers import solve
from sympy.simplify.radsimp import collect
import operator
allhints = ('1st_linear_constant_coeff_homogeneous', '1st_linear_constant_coeff', '1st_linear_constant_coeff_Integral', '1st_linear_variable_coeff')

def pdsolve(eq, func=None, hint='default', dict=False, solvefun=None, **kwargs):
    if not solvefun:
        solvefun = Function('F')
    hints = _desolve(eq, func=func, hint=hint, simplify=True, type='pde', **kwargs)
    eq = hints.pop('eq', False)
    all_ = hints.pop('all', False)
    if all_:
        pdedict = {}
        failed_hints = {}
        gethints = classify_pde(eq, dict=True)
        pdedict.update({'order': gethints['order'], 'default': gethints['default']})
        for hint in hints:
            try:
                rv = _helper_simplify(eq, hint, hints[hint]['func'], hints[hint]['order'], hints[hint][hint], solvefun)
            except NotImplementedError as detail:
                failed_hints[hint] = detail
            else:
                pdedict[hint] = rv
        pdedict.update(failed_hints)
        return pdedict
    else:
        return _helper_simplify(eq, hints['hint'], hints['func'], hints['order'], hints[hints['hint']], solvefun)

def _helper_simplify(eq, hint, func, order, match, solvefun):
    solvefunc = globals()['pde_' + hint.removesuffix('_Integral')]
    return _handle_Integral(solvefunc(eq, func, order, match, solvefun), func, order, hint)

def _handle_Integral(expr, func, order, hint):
    if hint.endswith('_Integral'):
        return expr
    elif hint == '1st_linear_constant_coeff':
        return simplify(expr.doit())
    else:
        return expr

def classify_pde(eq, func=None, dict=False, *, prep=True, **kwargs):
    if func and len(func.args) != 2:
        raise NotImplementedError('Right now only partial differential equations of two variables are supported')
    if prep or func is None:
        prep, func_ = _preprocess(eq, func)
        if func is None:
            func = func_
    if isinstance(eq, Equality):
        if eq.rhs != 0:
            return classify_pde(eq.lhs - eq.rhs, func)
        eq = eq.lhs
    f = func.func
    x = func.args[0]
    y = func.args[1]
    fx = f(x, y).diff(x)
    fy = f(x, y).diff(y)
    order = ode_order(eq, f(x, y))
    matching_hints = {'order': order}
    if not order:
        if dict:
            matching_hints['default'] = None
            return matching_hints
        return ()
    eq = expand(eq)
    a = Wild('a', exclude=[f(x, y)])
    b = Wild('b', exclude=[f(x, y), fx, fy, x, y])
    c = Wild('c', exclude=[f(x, y), fx, fy, x, y])
    d = Wild('d', exclude=[f(x, y), fx, fy, x, y])
    e = Wild('e', exclude=[f(x, y), fx, fy])
    n = Wild('n', exclude=[x, y])
    reduced_eq = eq
    if eq.is_Add:
        power = None
        for i in set(combinations_with_replacement((x, y), order)):
            coeff = eq.coeff(f(x, y).diff(*i))
            if coeff == 1:
                continue
            match = coeff.match(a * f(x, y) ** n)
            if match and match[a]:
                if power is None or match[n] < power:
                    power = match[n]
        if power:
            den = f(x, y) ** power
            reduced_eq = Add(*[arg / den for arg in eq.args])
    if order == 1:
        reduced_eq = collect(reduced_eq, f(x, y))
        r = reduced_eq.match(b * fx + c * fy + d * f(x, y) + e)
        if r:
            if not r[e]:
                r.update({'b': b, 'c': c, 'd': d})
                matching_hints['1st_linear_constant_coeff_homogeneous'] = r
            elif r[b] ** 2 + r[c] ** 2 != 0:
                r.update({'b': b, 'c': c, 'd': d, 'e': e})
                matching_hints['1st_linear_constant_coeff'] = r
                matching_hints['1st_linear_constant_coeff_Integral'] = r
        else:
            b = Wild('b', exclude=[f(x, y), fx, fy])
            c = Wild('c', exclude=[f(x, y), fx, fy])
            d = Wild('d', exclude=[f(x, y), fx, fy])
            r = reduced_eq.match(b * fx + c * fy + d * f(x, y) + e)
            if r:
                r.update({'b': b, 'c': c, 'd': d, 'e': e})
                matching_hints['1st_linear_variable_coeff'] = r
    rettuple = tuple((i for i in allhints if i in matching_hints))
    if dict:
        matching_hints['default'] = None
        matching_hints['ordered_hints'] = rettuple
        for i in allhints:
            if i in matching_hints:
                matching_hints['default'] = i
                break
        return matching_hints
    return rettuple

def checkpdesol(pde, sol, func=None, solve_for_func=True):
    if not isinstance(pde, Equality):
        pde = Eq(pde, 0)
    if func is None:
        try:
            _, func = _preprocess(pde.lhs)
        except ValueError:
            funcs = [s.atoms(AppliedUndef) for s in (sol if is_sequence(sol, set) else [sol])]
            funcs = set().union(funcs)
            if len(funcs) != 1:
                raise ValueError('must pass func arg to checkpdesol for this case.')
            func = funcs.pop()
    if is_sequence(sol, set):
        return type(sol)([checkpdesol(pde, i, func=func, solve_for_func=solve_for_func) for i in sol])
    if not isinstance(sol, Equality):
        sol = Eq(func, sol)
    elif sol.rhs == func:
        sol = sol.reversed
    solved = sol.lhs == func and (not sol.rhs.has(func))
    if solve_for_func and (not solved):
        solved = solve(sol, func)
        if solved:
            if len(solved) == 1:
                return checkpdesol(pde, Eq(func, solved[0]), func=func, solve_for_func=False)
            else:
                return checkpdesol(pde, [Eq(func, t) for t in solved], func=func, solve_for_func=False)
    if sol.lhs == func:
        pde = pde.lhs - pde.rhs
        s = simplify(pde.subs(func, sol.rhs).doit())
        return (s is S.Zero, s)
    raise NotImplementedError(filldedent('\n        Unable to test if %s is a solution to %s.' % (sol, pde)))

def pde_1st_linear_constant_coeff_homogeneous(eq, func, order, match, solvefun):
    f = func.func
    x = func.args[0]
    y = func.args[1]
    b = match[match['b']]
    c = match[match['c']]
    d = match[match['d']]
    return Eq(f(x, y), exp(-S(d) / (b ** 2 + c ** 2) * (b * x + c * y)) * solvefun(c * x - b * y))

def pde_1st_linear_constant_coeff(eq, func, order, match, solvefun):
    xi, eta = symbols('xi eta')
    f = func.func
    x = func.args[0]
    y = func.args[1]
    b = match[match['b']]
    c = match[match['c']]
    d = match[match['d']]
    e = -match[match['e']]
    expterm = exp(-S(d) / (b ** 2 + c ** 2) * xi)
    functerm = solvefun(eta)
    solvedict = solve((b * x + c * y - xi, c * x - b * y - eta), x, y)
    genterm = 1 / S(b ** 2 + c ** 2) * Integral((1 / expterm * e).subs(solvedict), (xi, b * x + c * y))
    return Eq(f(x, y), Subs(expterm * (functerm + genterm), (eta, xi), (c * x - b * y, b * x + c * y)))

def pde_1st_linear_variable_coeff(eq, func, order, match, solvefun):
    from sympy.solvers.ode import dsolve
    eta = symbols('eta')
    f = func.func
    x = func.args[0]
    y = func.args[1]
    b = match[match['b']]
    c = match[match['c']]
    d = match[match['d']]
    e = -match[match['e']]
    if not d:
        if not (b and c):
            if c:
                try:
                    tsol = integrate(e / c, y)
                except NotImplementedError:
                    raise NotImplementedError('Unable to find a solution due to inability of integrate')
                else:
                    return Eq(f(x, y), solvefun(x) + tsol)
            if b:
                try:
                    tsol = integrate(e / b, x)
                except NotImplementedError:
                    raise NotImplementedError('Unable to find a solution due to inability of integrate')
                else:
                    return Eq(f(x, y), solvefun(y) + tsol)
    if not c:
        plode = f(x).diff(x) * b + d * f(x) - e
        sol = dsolve(plode, f(x))
        syms = sol.free_symbols - plode.free_symbols - {x, y}
        rhs = _simplify_variable_coeff(sol.rhs, syms, solvefun, y)
        return Eq(f(x, y), rhs)
    if not b:
        plode = f(y).diff(y) * c + d * f(y) - e
        sol = dsolve(plode, f(y))
        syms = sol.free_symbols - plode.free_symbols - {x, y}
        rhs = _simplify_variable_coeff(sol.rhs, syms, solvefun, x)
        return Eq(f(x, y), rhs)
    dummy = Function('d')
    h = (c / b).subs(y, dummy(x))
    sol = dsolve(dummy(x).diff(x) - h, dummy(x))
    if isinstance(sol, list):
        sol = sol[0]
    solsym = sol.free_symbols - h.free_symbols - {x, y}
    if len(solsym) == 1:
        solsym = solsym.pop()
        etat = solve(sol, solsym)[0].subs(dummy(x), y)
        ysub = solve(eta - etat, y)[0]
        deq = (b * f(x).diff(x) + d * f(x) - e).subs(y, ysub)
        final = dsolve(deq, f(x), hint='1st_linear').rhs
        if isinstance(final, list):
            final = final[0]
        finsyms = final.free_symbols - deq.free_symbols - {x, y}
        rhs = _simplify_variable_coeff(final, finsyms, solvefun, etat)
        return Eq(f(x, y), rhs)
    else:
        raise NotImplementedError('Cannot solve the partial differential equation due to inability of constantsimp')

def _simplify_variable_coeff(sol, syms, func, funcarg):
    eta = Symbol('eta')
    if len(syms) == 1:
        sym = syms.pop()
        final = sol.subs(sym, func(funcarg))
    else:
        for sym in syms:
            final = sol.subs(sym, func(funcarg))
    return simplify(final.subs(eta, funcarg))

def pde_separate(eq, fun, sep, strategy='mul'):
    do_add = False
    if strategy == 'add':
        do_add = True
    elif strategy == 'mul':
        do_add = False
    else:
        raise ValueError('Unknown strategy: %s' % strategy)
    if isinstance(eq, Equality):
        if eq.rhs != 0:
            return pde_separate(Eq(eq.lhs - eq.rhs, 0), fun, sep, strategy)
    else:
        return pde_separate(Eq(eq, 0), fun, sep, strategy)
    if eq.rhs != 0:
        raise ValueError('Value should be 0')
    orig_args = list(fun.args)
    subs_args = [arg for s in sep for arg in s.args]
    if do_add:
        functions = reduce(operator.add, sep)
    else:
        functions = reduce(operator.mul, sep)
    if len(subs_args) != len(orig_args):
        raise ValueError('Variable counts do not match')
    if has_dups(subs_args):
        raise ValueError('Duplicate substitution arguments detected')
    if set(orig_args) != set(subs_args):
        raise ValueError('Arguments do not match')
    result = eq.lhs.subs(fun, functions).doit()
    if not do_add:
        eq = 0
        for i in result.args:
            eq += i / functions
        result = eq
    svar = subs_args[0]
    dvar = subs_args[1:]
    return _separate(result, svar, dvar)

def pde_separate_add(eq, fun, sep):
    return pde_separate(eq, fun, sep, strategy='add')

def pde_separate_mul(eq, fun, sep):
    return pde_separate(eq, fun, sep, strategy='mul')

def _separate(eq, dep, others):
    terms = set()
    for term in eq.args:
        if term.is_Mul:
            for i in term.args:
                if i.is_Derivative and (not i.has(*others)):
                    terms.add(term)
                    continue
        elif term.is_Derivative and (not term.has(*others)):
            terms.add(term)
    div = set()
    for term in terms:
        ext, sep = term.expand().as_independent(dep)
        if sep.has(*others):
            return None
        div.add(ext)
    if len(div) > 0:
        eq = Add(*[simplify(Add(*[term / i for i in div])) for term in eq.args])
    div = set()
    lhs = rhs = 0
    for term in eq.args:
        if not term.has(*others):
            lhs += term
            continue
        temp, sep = term.expand().as_independent(dep)
        if sep.has(*others):
            return None
        div.add(sep)
        rhs -= term.expand()
    fulldiv = reduce(operator.add, div)
    lhs = simplify(lhs / fulldiv).expand()
    rhs = simplify(rhs / fulldiv).expand()
    if lhs.has(*others) or rhs.has(dep):
        return None
    return [lhs, rhs]