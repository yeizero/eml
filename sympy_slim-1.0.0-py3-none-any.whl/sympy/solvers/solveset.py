from __future__ import annotations
from sympy.core.sympify import sympify
from sympy.core import S, Pow, Dummy, pi, Expr, Wild, Mul, Add, Basic
from sympy.core.containers import Tuple
from sympy.core.function import Lambda, expand_complex, AppliedUndef, expand_log, _mexpand, expand_trig, nfloat
from sympy.core.mod import Mod
from sympy.core.numbers import I, Number, Rational, oo
from sympy.core.intfunc import integer_log
from sympy.core.relational import Eq, Ne, Relational
from sympy.core.sorting import default_sort_key, ordered
from sympy.core.symbol import Symbol, _uniquely_named_symbol
from sympy.core.sympify import _sympify
from sympy.core.traversal import preorder_traversal
from sympy.external.gmpy import gcd as number_gcd, lcm as number_lcm
from sympy.polys.matrices.linsolve import _linear_eq_to_dict
from sympy.polys.polyroots import UnsolvableFactorError
from sympy.simplify.simplify import simplify, fraction, trigsimp, nsimplify
from sympy.simplify import powdenest, logcombine
from sympy.functions import log, tan, cot, sin, cos, sec, csc, exp, acos, asin, atan, acot, acsc, asec, piecewise_fold, Piecewise
from sympy.functions.combinatorial.numbers import totient
from sympy.functions.elementary.complexes import Abs, arg, re, im
from sympy.functions.elementary.hyperbolic import HyperbolicFunction, sinh, cosh, tanh, coth, sech, csch, asinh, acosh, atanh, acoth, asech, acsch
from sympy.functions.elementary.miscellaneous import real_root
from sympy.functions.elementary.trigonometric import TrigonometricFunction
from sympy.logic.boolalg import And, BooleanTrue
from sympy.sets import FiniteSet, imageset, Interval, Intersection, Union, ConditionSet, ImageSet, Complement, Contains
from sympy.sets.sets import Set, ProductSet
from sympy.matrices import zeros, Matrix, MatrixBase
from sympy.ntheory.factor_ import divisors
from sympy.ntheory.residue_ntheory import discrete_log, nthroot_mod
from sympy.polys import roots, Poly, degree, together, PolynomialError, RootOf, factor, lcm, gcd
from sympy.polys.polyerrors import CoercionFailed
from sympy.polys.polytools import invert, groebner, poly
from sympy.polys.solvers import sympy_eqs_to_ring, solve_lin_sys, PolyNonlinearError
from sympy.polys.matrices.linsolve import _linsolve
from sympy.solvers.solvers import checksol, denoms, unrad, _simple_dens, recast_to_symbols
from sympy.solvers.polysys import solve_poly_system
from sympy.utilities import filldedent
from sympy.utilities.iterables import numbered_symbols, has_dups, is_sequence, iterable
from sympy.calculus.util import periodicity, continuous_domain, function_range
from types import GeneratorType

class NonlinearError(ValueError):
    pass

def _masked(f, *atoms):
    sym = numbered_symbols('a', cls=Dummy, real=True)
    mask = []
    for a in ordered(f.atoms(*atoms)):
        for i in mask:
            a = a.replace(*i)
        mask.append((a, next(sym)))
    for i, (o, n) in enumerate(mask):
        f = f.replace(o, n)
        mask[i] = (n, o)
    mask = list(reversed(mask))
    return (f, mask)

def _invert(f_x, y, x, domain=S.Complexes):
    x = sympify(x)
    if not x.is_Symbol:
        raise ValueError('x must be a symbol')
    f_x = sympify(f_x)
    if x not in f_x.free_symbols:
        raise ValueError("Inverse of constant function doesn't exist")
    y = sympify(y)
    if x in y.free_symbols:
        raise ValueError('y should be independent of x ')
    if domain.is_subset(S.Reals):
        x1, s = _invert_real(f_x, FiniteSet(y), x)
    else:
        x1, s = _invert_complex(f_x, FiniteSet(y), x)
    if x1 != x:
        return (x1, s)
    if domain is S.Complexes:
        return (x1, s)
    if isinstance(s, FiniteSet):
        return (x1, s.intersect(domain))
    if domain is S.Reals:
        return (x1, s)
    else:
        return (x1, s.intersect(domain))
invert_complex = _invert

def invert_real(f_x, y, x):
    return _invert(f_x, y, x, S.Reals)

def _invert_real(f, g_ys, symbol):
    if f == symbol or g_ys is S.EmptySet:
        return (symbol, g_ys)
    n = Dummy('n', real=True)
    if isinstance(f, exp) or (f.is_Pow and f.base == S.Exp1):
        return _invert_real(f.exp, imageset(Lambda(n, log(n)), g_ys), symbol)
    if hasattr(f, 'inverse') and f.inverse() is not None and (not isinstance(f, (TrigonometricFunction, HyperbolicFunction))):
        if len(f.args) > 1:
            raise ValueError('Only functions with one argument are supported.')
        return _invert_real(f.args[0], imageset(Lambda(n, f.inverse()(n)), g_ys), symbol)
    if isinstance(f, Abs):
        return _invert_abs(f.args[0], g_ys, symbol)
    if f.is_Add:
        g, h = f.as_independent(symbol)
        if g is not S.Zero:
            return _invert_real(h, imageset(Lambda(n, n - g), g_ys), symbol)
    if f.is_Mul:
        g, h = f.as_independent(symbol)
        if g is not S.One:
            return _invert_real(h, imageset(Lambda(n, n / g), g_ys), symbol)
    if f.is_Pow:
        base, expo = f.args
        base_has_sym = base.has(symbol)
        expo_has_sym = expo.has(symbol)
        if not expo_has_sym:
            if expo.is_rational:
                num, den = expo.as_numer_denom()
                if den % 2 == 0 and num % 2 == 1 and (den.is_zero is False):
                    root = Lambda(n, real_root(n, expo))
                    g_ys_pos = g_ys & Interval(0, oo)
                    res = imageset(root, g_ys_pos)
                    _inv, _set = _invert_real(base, res, symbol)
                    return (_inv, _set)
                if den % 2 == 1:
                    root = Lambda(n, real_root(n, expo))
                    res = imageset(root, g_ys)
                    if num % 2 == 0:
                        neg_res = imageset(Lambda(n, -n), res)
                        return _invert_real(base, res + neg_res, symbol)
                    if num % 2 == 1:
                        return _invert_real(base, res, symbol)
            elif expo.is_irrational:
                root = Lambda(n, real_root(n, expo))
                g_ys_pos = g_ys & Interval(0, oo)
                res = imageset(root, g_ys_pos)
                return _invert_real(base, res, symbol)
            else:
                pass
        if not base_has_sym:
            rhs = g_ys.args[0]
            if base.is_positive:
                return _invert_real(expo, imageset(Lambda(n, log(n, base, evaluate=False)), g_ys), symbol)
            elif base.is_negative:
                s, b = integer_log(rhs, base)
                if b:
                    return _invert_real(expo, FiniteSet(s), symbol)
                else:
                    return (expo, S.EmptySet)
            elif base.is_zero:
                one = Eq(rhs, 1)
                if one == S.true:
                    return _invert_real(expo, FiniteSet(0), symbol)
                elif one == S.false:
                    return (expo, S.EmptySet)
    if isinstance(f, (TrigonometricFunction, HyperbolicFunction)):
        return _invert_trig_hyp_real(f, g_ys, symbol)
    return (f, g_ys)
_trig_inverses = None
_hyp_inverses = None

def _invert_trig_hyp_real(f, g_ys, symbol):
    if isinstance(f, HyperbolicFunction):
        n = Dummy('n', real=True)
        if isinstance(f, sinh):
            return _invert_real(f.args[0], imageset(n, asinh(n), g_ys), symbol)
        if isinstance(f, cosh):
            g_ys_dom = g_ys.intersect(Interval(1, oo))
            if isinstance(g_ys_dom, Intersection):
                if isinstance(g_ys, FiniteSet):
                    g_ys_dom = g_ys
                else:
                    return (f, g_ys)
            return _invert_real(f.args[0], Union(imageset(n, acosh(n), g_ys_dom), imageset(n, -acosh(n), g_ys_dom)), symbol)
        if isinstance(f, sech):
            g_ys_dom = g_ys.intersect(Interval.Lopen(0, 1))
            if isinstance(g_ys_dom, Intersection):
                if isinstance(g_ys, FiniteSet):
                    g_ys_dom = g_ys
                else:
                    return (f, g_ys)
            return _invert_real(f.args[0], Union(imageset(n, asech(n), g_ys_dom), imageset(n, -asech(n), g_ys_dom)), symbol)
        if isinstance(f, tanh):
            g_ys_dom = g_ys.intersect(Interval.open(-1, 1))
            if isinstance(g_ys_dom, Intersection):
                if isinstance(g_ys, FiniteSet):
                    g_ys_dom = g_ys
                else:
                    return (f, g_ys)
            return _invert_real(f.args[0], imageset(n, atanh(n), g_ys_dom), symbol)
        if isinstance(f, coth):
            g_ys_dom = g_ys - Interval(-1, 1)
            if isinstance(g_ys_dom, Complement):
                if isinstance(g_ys, FiniteSet):
                    g_ys_dom = g_ys
                else:
                    return (f, g_ys)
            return _invert_real(f.args[0], imageset(n, acoth(n), g_ys_dom), symbol)
        if isinstance(f, csch):
            g_ys_dom = g_ys - FiniteSet(0)
            if isinstance(g_ys_dom, Complement):
                if isinstance(g_ys, FiniteSet):
                    g_ys_dom = g_ys
                else:
                    return (f, g_ys)
            return _invert_real(f.args[0], imageset(n, acsch(n), g_ys_dom), symbol)
    elif isinstance(f, TrigonometricFunction) and isinstance(g_ys, FiniteSet):

        def _get_trig_inverses(func):
            global _trig_inverses
            if _trig_inverses is None:
                _trig_inverses = {sin: ((asin, lambda y: pi - asin(y)), 2 * pi, Interval(-1, 1)), cos: ((acos, lambda y: -acos(y)), 2 * pi, Interval(-1, 1)), tan: ((atan,), pi, S.Reals), cot: ((acot,), pi, S.Reals), sec: ((asec, lambda y: -asec(y)), 2 * pi, Union(Interval(-oo, -1), Interval(1, oo))), csc: ((acsc, lambda y: pi - acsc(y)), 2 * pi, Union(Interval(-oo, -1), Interval(1, oo)))}
            return _trig_inverses[func]
        invs, period, rng = _get_trig_inverses(f.func)
        n = Dummy('n', integer=True)

        def create_return_set(g):
            invsimg = Union(*[imageset(n, period * n + inv(g), S.Integers) for inv in invs])
            inv_f, inv_g_ys = _invert_real(f.args[0], invsimg, symbol)
            if inv_f == symbol:
                conds = rng.contains(g)
                return ConditionSet(symbol, conds, inv_g_ys)
            else:
                return ConditionSet(symbol, Eq(f, g), S.Reals)
        retset = Union(*[create_return_set(g) for g in g_ys])
        return (symbol, retset)
    else:
        return (f, g_ys)

def _invert_trig_hyp_complex(f, g_ys, symbol):
    if isinstance(f, TrigonometricFunction) and isinstance(g_ys, FiniteSet):

        def inv(trig):
            if isinstance(trig, (sin, csc)):
                F = asin if isinstance(trig, sin) else acsc
                return (lambda a: 2 * n * pi + F(a), lambda a: 2 * n * pi + pi - F(a))
            if isinstance(trig, (cos, sec)):
                F = acos if isinstance(trig, cos) else asec
                return (lambda a: 2 * n * pi + F(a), lambda a: 2 * n * pi - F(a))
            if isinstance(trig, (tan, cot)):
                return (lambda a: n * pi + trig.inverse()(a),)
        n = Dummy('n', integer=True)
        invs = S.EmptySet
        for L in inv(f):
            invs += Union(*[imageset(Lambda(n, L(g)), S.Integers) for g in g_ys])
        return _invert_complex(f.args[0], invs, symbol)
    elif isinstance(f, HyperbolicFunction) and isinstance(g_ys, FiniteSet):

        def _get_hyp_inverses(func):
            global _hyp_inverses
            if _hyp_inverses is None:
                _hyp_inverses = {sinh: ((asinh, lambda y: I * pi - asinh(y)), 2 * I * pi, ()), cosh: ((acosh, lambda y: -acosh(y)), 2 * I * pi, ()), tanh: ((atanh,), I * pi, (-1, 1)), coth: ((acoth,), I * pi, (-1, 1)), sech: ((asech, lambda y: -asech(y)), 2 * I * pi, (0,)), csch: ((acsch, lambda y: I * pi - acsch(y)), 2 * I * pi, (0,))}
            return _hyp_inverses[func]
        invs, period, excl = _get_hyp_inverses(f.func)
        n = Dummy('n', integer=True)

        def create_return_set(g):
            invsimg = Union(*[imageset(n, period * n + inv(g), S.Integers) for inv in invs])
            inv_f, inv_g_ys = _invert_complex(f.args[0], invsimg, symbol)
            if inv_f == symbol:
                conds = And(*[Ne(g, e) for e in excl])
                return ConditionSet(symbol, conds, inv_g_ys)
            else:
                return ConditionSet(symbol, Eq(f, g), S.Complexes)
        retset = Union(*[create_return_set(g) for g in g_ys])
        return (symbol, retset)
    else:
        return (f, g_ys)

def _invert_complex(f, g_ys, symbol):
    if f == symbol or g_ys is S.EmptySet:
        return (symbol, g_ys)
    n = Dummy('n')
    if f.is_Add:
        g, h = f.as_independent(symbol)
        if g is not S.Zero:
            return _invert_complex(h, imageset(Lambda(n, n - g), g_ys), symbol)
    if f.is_Mul:
        g, h = f.as_independent(symbol)
        if g is not S.One:
            if g in {S.NegativeInfinity, S.ComplexInfinity, S.Infinity}:
                return (h, S.EmptySet)
            return _invert_complex(h, imageset(Lambda(n, n / g), g_ys), symbol)
    if f.is_Pow:
        base, expo = f.args
        if expo.is_Rational and g_ys == FiniteSet(0):
            if expo.is_positive:
                return _invert_complex(base, g_ys, symbol)
    if hasattr(f, 'inverse') and f.inverse() is not None and (not isinstance(f, TrigonometricFunction)) and (not isinstance(f, HyperbolicFunction)) and (not isinstance(f, exp)):
        if len(f.args) > 1:
            raise ValueError('Only functions with one argument are supported.')
        return _invert_complex(f.args[0], imageset(Lambda(n, f.inverse()(n)), g_ys), symbol)
    if isinstance(f, exp) or (f.is_Pow and f.base == S.Exp1):
        if isinstance(g_ys, ImageSet):
            g_ys_expr = g_ys.lamda.expr
            g_ys_vars = g_ys.lamda.variables
            k = Dummy('k{}'.format(len(g_ys_vars)))
            g_ys_vars_1 = (k,) + g_ys_vars
            exp_invs = Union(*[imageset(Lambda((g_ys_vars_1,), I * (2 * k * pi + arg(g_ys_expr)) + log(Abs(g_ys_expr))), S.Integers ** len(g_ys_vars_1))])
            return _invert_complex(f.exp, exp_invs, symbol)
        elif isinstance(g_ys, FiniteSet):
            exp_invs = Union(*[imageset(Lambda(n, I * (2 * n * pi + arg(g_y)) + log(Abs(g_y))), S.Integers) for g_y in g_ys if g_y != 0])
            return _invert_complex(f.exp, exp_invs, symbol)
    if isinstance(f, (TrigonometricFunction, HyperbolicFunction)):
        return _invert_trig_hyp_complex(f, g_ys, symbol)
    return (f, g_ys)

def _invert_abs(f, g_ys, symbol):
    if not g_ys.is_FiniteSet:
        pos = Intersection(g_ys, Interval(0, S.Infinity))
        parg = _invert_real(f, pos, symbol)
        narg = _invert_real(-f, pos, symbol)
        if parg[0] != narg[0]:
            raise NotImplementedError
        return (parg[0], Union(narg[1], parg[1]))
    unknown = []
    for a in g_ys.args:
        ok = a.is_nonnegative if a.is_Number else a.is_positive
        if ok is None:
            unknown.append(a)
        elif not ok:
            return (symbol, S.EmptySet)
    if unknown:
        conditions = And(*[Contains(i, Interval(0, oo)) for i in unknown])
    else:
        conditions = True
    n = Dummy('n', real=True)
    g_x, values = _invert_real(f, Union(imageset(Lambda(n, n), g_ys), imageset(Lambda(n, -n), g_ys)), symbol)
    return (g_x, ConditionSet(g_x, conditions, values))

def domain_check(f, symbol, p):
    f, p = (sympify(f), sympify(p))
    if p.is_infinite:
        return False
    return _domain_check(f, symbol, p)

def _domain_check(f, symbol, p):
    if f.is_Atom and f.is_finite:
        return True
    elif f.subs(symbol, p).is_infinite:
        return False
    elif isinstance(f, Piecewise):
        for expr, cond in f.args:
            condsubs = cond.subs(symbol, p)
            if condsubs is S.false:
                continue
            elif condsubs is S.true:
                return _domain_check(expr, symbol, p)
            else:
                return True
    else:
        return all((_domain_check(g, symbol, p) for g in f.args))

def _is_finite_with_finite_vars(f, domain=S.Complexes):

    def assumptions(s):
        A = s.assumptions0
        A.setdefault('finite', A.get('finite', True))
        if domain.is_subset(S.Reals):
            A.setdefault('real', True)
        else:
            A.setdefault('complex', True)
        return A
    reps = {s: Dummy(**assumptions(s)) for s in f.free_symbols}
    return f.xreplace(reps).is_finite

def _is_function_class_equation(func_class, f, symbol):
    if f.is_Mul or f.is_Add:
        return all((_is_function_class_equation(func_class, arg, symbol) for arg in f.args))
    if f.is_Pow:
        if not f.exp.has(symbol):
            return _is_function_class_equation(func_class, f.base, symbol)
        else:
            return False
    if not f.has(symbol):
        return True
    if isinstance(f, func_class):
        try:
            g = Poly(f.args[0], symbol)
            return g.degree() <= 1
        except PolynomialError:
            return False
    else:
        return False

def _solve_as_rational(f, symbol, domain):
    f = together(_mexpand(f, recursive=True), deep=True)
    g, h = fraction(f)
    if not h.has(symbol):
        try:
            return _solve_as_poly(g, symbol, domain)
        except NotImplementedError:
            return ConditionSet(symbol, Eq(f, 0), domain)
        except CoercionFailed:
            return S.EmptySet
    else:
        valid_solns = _solveset(g, symbol, domain)
        invalid_solns = _solveset(h, symbol, domain)
        return valid_solns - invalid_solns

class _SolveTrig1Error(Exception):
    pass

def _solve_trig(f, symbol, domain):
    trig_expr, count = (None, 0)
    for expr in preorder_traversal(f):
        if isinstance(expr, (TrigonometricFunction, HyperbolicFunction)) and expr.has(symbol):
            if not trig_expr:
                trig_expr, count = (expr, 1)
            elif expr == trig_expr:
                count += 1
            else:
                trig_expr, count = (False, 0)
                break
    if count == 1:
        x, sol = _invert(f, 0, symbol, domain)
        if x == symbol:
            cond = True
            if trig_expr.free_symbols - {symbol}:
                a, h = trig_expr.args[0].as_independent(symbol, as_Add=True)
                m, h = h.as_independent(symbol, as_Add=False)
                num, den = m.as_numer_denom()
                cond = Ne(num, 0) & Ne(den, 0)
            return ConditionSet(symbol, cond, sol)
        else:
            return ConditionSet(symbol, Eq(f, 0), domain)
    elif count:
        y = Dummy('y')
        f_cov = f.subs(trig_expr, y)
        sol_cov = solveset(f_cov, y, domain)
        if isinstance(sol_cov, FiniteSet):
            return Union(*[_solve_trig(trig_expr - s, symbol, domain) for s in sol_cov])
    sol = None
    try:
        sol = _solve_trig1(f, symbol, domain)
    except _SolveTrig1Error:
        try:
            sol = _solve_trig2(f, symbol, domain)
        except ValueError:
            raise NotImplementedError(filldedent('\n                Solution to this kind of trigonometric equations\n                is yet to be implemented'))
    return sol

def _solve_trig1(f, symbol, domain):
    x = Dummy('x')
    if _is_function_class_equation(HyperbolicFunction, f, symbol):
        cov = exp(x)
        inverter = invert_real if domain.is_subset(S.Reals) else invert_complex
    else:
        cov = exp(I * x)
        inverter = invert_complex
    f = trigsimp(f)
    f_original = f
    trig_functions = f.atoms(TrigonometricFunction, HyperbolicFunction)
    trig_arguments = [e.args[0] for e in trig_functions]
    if not any((a.has(symbol) for a in trig_arguments)):
        return solveset(f_original, symbol, domain)
    denominators = []
    numerators = []
    for ar in trig_arguments:
        try:
            poly_ar = Poly(ar, symbol)
        except PolynomialError:
            raise _SolveTrig1Error('trig argument is not a polynomial')
        if poly_ar.degree() > 1:
            raise _SolveTrig1Error('degree of variable must not exceed one')
        if poly_ar.degree() == 0:
            continue
        c = poly_ar.all_coeffs()[0]
        numerators.append(fraction(c)[0])
        denominators.append(fraction(c)[1])
    mu = lcm(denominators) / gcd(numerators)
    f = f.subs(symbol, mu * x)
    f = f.rewrite(exp)
    f = together(f)
    g, h = fraction(f)
    y = Dummy('y')
    g, h = (g.expand(), h.expand())
    g, h = (g.subs(cov, y), h.subs(cov, y))
    if g.has(x) or h.has(x):
        raise _SolveTrig1Error('change of variable not possible')
    solns = solveset_complex(g, y) - solveset_complex(h, y)
    if isinstance(solns, ConditionSet):
        raise _SolveTrig1Error('polynomial has ConditionSet solution')
    if isinstance(solns, FiniteSet):
        if any((isinstance(s, RootOf) for s in solns)):
            raise _SolveTrig1Error('polynomial results in RootOf object')
        cov = cov.subs(x, symbol / mu)
        result = Union(*[inverter(cov, s, symbol)[1] for s in solns])
        if mu.has(Symbol):
            syms = mu.atoms(Symbol)
            munum, muden = fraction(mu)
            condnum = munum.as_independent(*syms, as_Add=False)[1]
            condden = muden.as_independent(*syms, as_Add=False)[1]
            cond = And(Ne(condnum, 0), Ne(condden, 0))
        else:
            cond = True
        if domain is S.Complexes:
            return ConditionSet(symbol, cond, result)
        else:
            return ConditionSet(symbol, cond, Intersection(result, domain))
    elif solns is S.EmptySet:
        return S.EmptySet
    else:
        raise _SolveTrig1Error('polynomial solutions must form FiniteSet')

def _solve_trig2(f, symbol, domain):
    f = trigsimp(f)
    f_original = f
    trig_functions = f.atoms(sin, cos, tan, sec, cot, csc)
    trig_arguments = [e.args[0] for e in trig_functions]
    denominators = []
    numerators = []
    if not trig_functions:
        return ConditionSet(symbol, Eq(f_original, 0), domain)
    for ar in trig_arguments:
        try:
            poly_ar = Poly(ar, symbol)
        except PolynomialError:
            raise ValueError('give up, we cannot solve if this is not a polynomial in x')
        if poly_ar.degree() > 1:
            raise ValueError('degree of variable inside polynomial should not exceed one')
        if poly_ar.degree() == 0:
            continue
        c = poly_ar.all_coeffs()[0]
        try:
            numerators.append(Rational(c).p)
            denominators.append(Rational(c).q)
        except TypeError:
            return ConditionSet(symbol, Eq(f_original, 0), domain)
    x = Dummy('x')
    mu = Rational(2) * number_lcm(*denominators) / number_gcd(*numerators)
    f = f.subs(symbol, mu * x)
    f = f.rewrite(tan)
    f = expand_trig(f)
    f = together(f)
    g, h = fraction(f)
    y = Dummy('y')
    g, h = (g.expand(), h.expand())
    g, h = (g.subs(tan(x), y), h.subs(tan(x), y))
    if g.has(x) or h.has(x):
        return ConditionSet(symbol, Eq(f_original, 0), domain)
    solns = solveset(g, y, S.Reals) - solveset(h, y, S.Reals)
    if isinstance(solns, FiniteSet):
        result = Union(*[invert_real(tan(symbol / mu), s, symbol)[1] for s in solns])
        dsol = invert_real(tan(symbol / mu), oo, symbol)[1]
        if degree(h) > degree(g):
            result = Union(result, dsol)
        return Intersection(result, domain)
    elif solns is S.EmptySet:
        return S.EmptySet
    else:
        return ConditionSet(symbol, Eq(f_original, 0), S.Reals)

def _solve_as_poly(f, symbol, domain=S.Complexes):
    result = None
    if f.is_polynomial(symbol):
        solns = roots(f, symbol, cubics=True, quartics=True, quintics=True, domain='EX')
        num_roots = sum(solns.values())
        if degree(f, symbol) <= num_roots:
            result = FiniteSet(*solns.keys())
        else:
            poly = Poly(f, symbol)
            solns = poly.all_roots()
            if poly.degree() <= len(solns):
                result = FiniteSet(*solns)
            else:
                result = ConditionSet(symbol, Eq(f, 0), domain)
    else:
        poly = Poly(f)
        if poly is None:
            result = ConditionSet(symbol, Eq(f, 0), domain)
        gens = [g for g in poly.gens if g.has(symbol)]
        if len(gens) == 1:
            poly = Poly(poly, gens[0])
            gen = poly.gen
            deg = poly.degree()
            poly = Poly(poly.as_expr(), poly.gen, composite=True)
            poly_solns = FiniteSet(*roots(poly, cubics=True, quartics=True, quintics=True).keys())
            if len(poly_solns) < deg:
                result = ConditionSet(symbol, Eq(f, 0), domain)
            if gen != symbol:
                y = Dummy('y')
                inverter = invert_real if domain.is_subset(S.Reals) else invert_complex
                lhs, rhs_s = inverter(gen, y, symbol)
                if lhs == symbol:
                    result = Union(*[rhs_s.subs(y, s) for s in poly_solns])
                    if isinstance(result, FiniteSet) and isinstance(gen, Pow) and gen.base.is_Rational:
                        result = FiniteSet(*[expand_log(i) for i in result])
                else:
                    result = ConditionSet(symbol, Eq(f, 0), domain)
        else:
            result = ConditionSet(symbol, Eq(f, 0), domain)
    if result is not None:
        if isinstance(result, FiniteSet):
            if all((s.atoms(Symbol, AppliedUndef) == set() and (not isinstance(s, RootOf)) for s in result)):
                s = Dummy('s')
                result = imageset(Lambda(s, expand_complex(s)), result)
        if isinstance(result, FiniteSet) and domain != S.Complexes:
            result = result.intersection(domain)
        return result
    else:
        return ConditionSet(symbol, Eq(f, 0), domain)

def _solve_radical(f, unradf, symbol, solveset_solver):
    res = unradf
    eq, cov = res if res else (f, [])
    if not cov:
        result = solveset_solver(eq, symbol) - Union(*[solveset_solver(g, symbol) for g in denoms(f, symbol)])
    else:
        y, yeq = cov
        if not solveset_solver(y - I, y):
            yreal = Dummy('yreal', real=True)
            yeq = yeq.xreplace({y: yreal})
            eq = eq.xreplace({y: yreal})
            y = yreal
        g_y_s = solveset_solver(yeq, symbol)
        f_y_sols = solveset_solver(eq, y)
        result = Union(*[imageset(Lambda(y, g_y), f_y_sols) for g_y in g_y_s])

    def check_finiteset(solutions):
        f_set = []
        c_set = []
        for s in solutions:
            if checksol(f, symbol, s):
                f_set.append(s)
            else:
                c_set.append(s)
        return FiniteSet(*f_set) + ConditionSet(symbol, Eq(f, 0), FiniteSet(*c_set))

    def check_set(solutions):
        if solutions is S.EmptySet:
            return solutions
        elif isinstance(solutions, ConditionSet):
            return solutions
        elif isinstance(solutions, FiniteSet):
            return check_finiteset(solutions)
        elif isinstance(solutions, Complement):
            A, B = solutions.args
            return Complement(check_set(A), B)
        elif isinstance(solutions, Union):
            return Union(*[check_set(s) for s in solutions.args])
        else:
            return solutions
    solution_set = check_set(result)
    return solution_set

def _solve_abs(f, symbol, domain):
    if not domain.is_subset(S.Reals):
        raise ValueError(filldedent('\n            Absolute values cannot be inverted in the\n            complex domain.'))
    p, q, r = (Wild('p'), Wild('q'), Wild('r'))
    pattern_match = f.match(p * Abs(q) + r) or {}
    f_p, f_q, f_r = [pattern_match.get(i, S.Zero) for i in (p, q, r)]
    if not (f_p.is_zero or f_q.is_zero):
        domain = continuous_domain(f_q, symbol, domain)
        from .inequalities import solve_univariate_inequality
        q_pos_cond = solve_univariate_inequality(f_q >= 0, symbol, relational=False, domain=domain, continuous=True)
        q_neg_cond = q_pos_cond.complement(domain)
        sols_q_pos = solveset_real(f_p * f_q + f_r, symbol).intersect(q_pos_cond)
        sols_q_neg = solveset_real(f_p * -f_q + f_r, symbol).intersect(q_neg_cond)
        return Union(sols_q_pos, sols_q_neg)
    else:
        return ConditionSet(symbol, Eq(f, 0), domain)

def solve_decomposition(f, symbol, domain):
    from sympy.solvers.decompogen import decompogen
    g_s = decompogen(f, symbol)
    y_s = FiniteSet(0)
    for g in g_s:
        frange = function_range(g, symbol, domain)
        y_s = Intersection(frange, y_s)
        result = S.EmptySet
        if isinstance(y_s, FiniteSet):
            for y in y_s:
                solutions = solveset(Eq(g, y), symbol, domain)
                if not isinstance(solutions, ConditionSet):
                    result += solutions
        else:
            if isinstance(y_s, ImageSet):
                iter_iset = (y_s,)
            elif isinstance(y_s, Union):
                iter_iset = y_s.args
            elif y_s is S.EmptySet:
                return S.EmptySet
            for iset in iter_iset:
                new_solutions = solveset(Eq(iset.lamda.expr, g), symbol, domain)
                dummy_var = tuple(iset.lamda.expr.free_symbols)[0]
                base_set, = iset.base_sets
                if isinstance(new_solutions, FiniteSet):
                    new_exprs = new_solutions
                elif isinstance(new_solutions, Intersection):
                    if isinstance(new_solutions.args[1], FiniteSet):
                        new_exprs = new_solutions.args[1]
                for new_expr in new_exprs:
                    result += ImageSet(Lambda(dummy_var, new_expr), base_set)
        if result is S.EmptySet:
            return ConditionSet(symbol, Eq(f, 0), domain)
        y_s = result
    return y_s

def _solveset(f, symbol, domain, _check=False):
    from sympy.simplify.simplify import signsimp
    if isinstance(f, BooleanTrue):
        return domain
    orig_f = f
    if f.is_Mul:
        coeff, f = f.as_independent(symbol, as_Add=False)
        if coeff in {S.ComplexInfinity, S.NegativeInfinity, S.Infinity}:
            f = together(orig_f)
    elif f.is_Add:
        a, h = f.as_independent(symbol)
        m, h = h.as_independent(symbol, as_Add=False)
        if m not in {S.ComplexInfinity, S.Zero, S.Infinity, S.NegativeInfinity}:
            f = a / m + h
    solver = lambda f, x, domain=domain: _solveset(f, x, domain)
    inverter = lambda f, rhs, symbol: _invert(f, rhs, symbol, domain)
    result = S.EmptySet
    if f.expand().is_zero:
        return domain
    elif not f.has(symbol):
        return S.EmptySet
    elif f.is_Mul and all((_is_finite_with_finite_vars(m, domain) for m in f.args)):
        result = Union(*[solver(m, symbol) for m in f.args])
    elif _is_function_class_equation(TrigonometricFunction, f, symbol) or _is_function_class_equation(HyperbolicFunction, f, symbol):
        result = _solve_trig(f, symbol, domain)
    elif isinstance(f, arg):
        a = f.args[0]
        result = Intersection(_solveset(re(a) > 0, symbol, domain), _solveset(im(a), symbol, domain))
    elif f.is_Piecewise:
        expr_set_pairs = f.as_expr_set_pairs(domain)
        for expr, in_set in expr_set_pairs:
            if in_set.is_Relational:
                in_set = in_set.as_set()
            solns = solver(expr, symbol, in_set)
            result += solns
    elif isinstance(f, Eq):
        result = solver(Add(f.lhs, -f.rhs, evaluate=False), symbol, domain)
    elif f.is_Relational:
        from .inequalities import solve_univariate_inequality
        try:
            result = solve_univariate_inequality(f, symbol, domain=domain, relational=False)
        except NotImplementedError:
            result = ConditionSet(symbol, f, domain)
        return result
    elif _is_modular(f, symbol):
        result = _solve_modular(f, symbol, domain)
    else:
        lhs, rhs_s = inverter(f, 0, symbol)
        if lhs == symbol:
            if isinstance(rhs_s, FiniteSet):
                rhs_s = FiniteSet(*[Mul(*signsimp(i).as_content_primitive()) for i in rhs_s])
            result = rhs_s
        elif isinstance(rhs_s, FiniteSet):
            for equation in [lhs - rhs for rhs in rhs_s]:
                if equation == f:
                    u = unrad(f, symbol)
                    if u:
                        result += _solve_radical(equation, u, symbol, solver)
                    elif equation.has(Abs):
                        result += _solve_abs(f, symbol, domain)
                    else:
                        result_rational = _solve_as_rational(equation, symbol, domain)
                        if not isinstance(result_rational, ConditionSet):
                            result += result_rational
                        else:
                            t_result = _transolve(equation, symbol, domain)
                            if isinstance(t_result, ConditionSet):
                                factored = equation.factor()
                                if factored.is_Mul and equation != factored:
                                    _, dep = factored.as_independent(symbol)
                                    if not dep.is_Add:
                                        t_results = []
                                        for fac in Mul.make_args(factored):
                                            if fac.has(symbol):
                                                t_results.append(solver(fac, symbol))
                                        t_result = Union(*t_results)
                            result += t_result
                else:
                    result += solver(equation, symbol)
        elif rhs_s is not S.EmptySet:
            result = ConditionSet(symbol, Eq(f, 0), domain)
    if isinstance(result, ConditionSet):
        if isinstance(f, Expr):
            num, den = f.as_numer_denom()
            if den.has(symbol):
                _result = _solveset(num, symbol, domain)
                if not isinstance(_result, ConditionSet):
                    singularities = _solveset(den, symbol, domain)
                    result = _result - singularities
    if _check:
        if isinstance(result, ConditionSet):
            return result
        if isinstance(orig_f, Expr):
            fx = orig_f.as_independent(symbol, as_Add=True)[1]
            fx = fx.as_independent(symbol, as_Add=False)[1]
        else:
            fx = orig_f
        if isinstance(result, FiniteSet):
            result = FiniteSet(*[s for s in result if isinstance(s, RootOf) or domain_check(fx, symbol, s)])
    return result

def _is_modular(f, symbol):
    if not f.has(Mod):
        return False
    modterms = list(f.atoms(Mod))
    return len(modterms) == 1 and modterms[0].args[0].has(symbol) and modterms[0].args[1].is_integer and any((isinstance(term, Mod) for term in list(_term_factors(f))))

def _invert_modular(modterm, rhs, n, symbol):
    a, m = modterm.args
    if rhs.is_integer is False:
        return (symbol, S.EmptySet)
    if rhs.is_real is False or any((term.is_real is False for term in list(_term_factors(a)))):
        return (modterm, rhs)
    if abs(rhs) >= abs(m):
        return (symbol, S.EmptySet)
    if a == symbol:
        return (symbol, ImageSet(Lambda(n, m * n + rhs), S.Integers))
    if a.is_Add:
        g, h = a.as_independent(symbol)
        if g is not S.Zero:
            x_indep_term = rhs - Mod(g, m)
            return _invert_modular(Mod(h, m), Mod(x_indep_term, m), n, symbol)
    if a.is_Mul:
        g, h = a.as_independent(symbol)
        if g is not S.One:
            x_indep_term = rhs * invert(g, m)
            return _invert_modular(Mod(h, m), Mod(x_indep_term, m), n, symbol)
    if a.is_Pow:
        base, expo = a.args
        if expo.has(symbol) and (not base.has(symbol)):
            if not m.is_Integer and rhs.is_Integer and a.base.is_Integer:
                return (modterm, rhs)
            mdiv = m.p // number_gcd(m.p, rhs.p)
            try:
                remainder = discrete_log(mdiv, rhs.p, a.base.p)
            except ValueError:
                return (modterm, rhs)
            period = totient(m)
            for p in divisors(period):
                if pow(a.base, p, m / number_gcd(m.p, a.base.p)) == 1:
                    period = p
                    break
            return (expo, ImageSet(Lambda(n, period * n + remainder), S.Naturals0))
        elif base.has(symbol) and (not expo.has(symbol)):
            try:
                remainder_list = nthroot_mod(rhs, expo, m, all_roots=True)
                if remainder_list == []:
                    return (symbol, S.EmptySet)
            except (ValueError, NotImplementedError):
                return (modterm, rhs)
            g_n = S.EmptySet
            for rem in remainder_list:
                g_n += ImageSet(Lambda(n, m * n + rem), S.Integers)
            return (base, g_n)
    return (modterm, rhs)

def _solve_modular(f, symbol, domain):
    unsolved_result = ConditionSet(symbol, Eq(f, 0), domain)
    modterm = list(f.atoms(Mod))[0]
    rhs = -S.One * f.subs(modterm, S.Zero)
    if f.as_coefficients_dict()[modterm].is_negative:
        rhs *= -S.One
    if not domain.is_subset(S.Integers):
        return unsolved_result
    if rhs.has(symbol):
        return unsolved_result
    n = Dummy('n', integer=True)
    f_x, g_n = _invert_modular(modterm, rhs, n, symbol)
    if f_x == modterm and g_n == rhs:
        return unsolved_result
    if f_x == symbol:
        if domain is not S.Integers:
            return domain.intersect(g_n)
        return g_n
    if isinstance(g_n, ImageSet):
        lamda_expr = g_n.lamda.expr
        lamda_vars = g_n.lamda.variables
        base_sets = g_n.base_sets
        sol_set = _solveset(f_x - lamda_expr, symbol, S.Integers)
        if isinstance(sol_set, FiniteSet):
            tmp_sol = S.EmptySet
            for sol in sol_set:
                tmp_sol += ImageSet(Lambda(lamda_vars, sol), *base_sets)
            sol_set = tmp_sol
        else:
            sol_set = ImageSet(Lambda(lamda_vars, sol_set), *base_sets)
        return domain.intersect(sol_set)
    return unsolved_result

def _term_factors(f):
    for add_arg in Add.make_args(f):
        yield from Mul.make_args(add_arg)

def _solve_exponential(lhs, rhs, symbol, domain):
    unsolved_result = ConditionSet(symbol, Eq(lhs - rhs, 0), domain)
    newlhs = powdenest(lhs)
    if lhs != newlhs:
        neweq = factor(newlhs - rhs)
        if neweq != lhs - rhs:
            return _solveset(neweq, symbol, domain)
    if not (isinstance(lhs, Add) and len(lhs.args) == 2):
        return unsolved_result
    if rhs != 0:
        return unsolved_result
    a, b = list(ordered(lhs.args))
    a_term = a.as_independent(symbol)[1]
    b_term = b.as_independent(symbol)[1]
    a_base, a_exp = a_term.as_base_exp()
    b_base, b_exp = b_term.as_base_exp()
    if domain.is_subset(S.Reals):
        conditions = And(a_base > 0, b_base > 0, Eq(im(a_exp), 0), Eq(im(b_exp), 0))
    else:
        conditions = And(Ne(a_base, 0), Ne(b_base, 0))
    L, R = (expand_log(log(i), force=True) for i in (a, -b))
    solutions = _solveset(L - R, symbol, domain)
    return ConditionSet(symbol, conditions, solutions)

def _is_exponential(f, symbol):
    rv = False
    for expr_arg in _term_factors(f):
        if symbol not in expr_arg.free_symbols:
            continue
        if isinstance(expr_arg, Pow) and symbol not in expr_arg.base.free_symbols or isinstance(expr_arg, exp):
            rv = True
        else:
            return False
    return rv

def _solve_logarithm(lhs, rhs, symbol, domain):
    new_lhs = logcombine(lhs, force=True)
    new_f = new_lhs - rhs
    return _solveset(new_f, symbol, domain)

def _is_logarithmic(f, symbol):
    rv = False
    for term in Add.make_args(f):
        saw_log = False
        for term_arg in Mul.make_args(term):
            if symbol not in term_arg.free_symbols:
                continue
            if isinstance(term_arg, log):
                if saw_log:
                    return False
                saw_log = True
            else:
                return False
        if saw_log:
            rv = True
    return rv

def _is_lambert(f, symbol):
    term_factors = list(_term_factors(f.expand()))
    no_of_symbols = len([arg for arg in term_factors if arg.has(symbol)])
    no_of_trig = len([arg for arg in term_factors if arg.has(HyperbolicFunction, TrigonometricFunction)])
    if f.is_Add and no_of_symbols >= 2:
        lambert_funcs = (log, HyperbolicFunction, TrigonometricFunction)
        if any((isinstance(arg, lambert_funcs) for arg in term_factors if arg.has(symbol))):
            if no_of_trig < no_of_symbols:
                return True
        elif any((isinstance(arg, (Pow, exp)) for arg in term_factors if arg.as_base_exp()[1].has(symbol))):
            return True
    return False

def _transolve(f, symbol, domain):

    def add_type(lhs, rhs, symbol, domain):
        result = ConditionSet(symbol, Eq(lhs - rhs, 0), domain)
        if _is_exponential(lhs, symbol):
            result = _solve_exponential(lhs, rhs, symbol, domain)
        elif _is_logarithmic(lhs, symbol):
            result = _solve_logarithm(lhs, rhs, symbol, domain)
        return result
    result = ConditionSet(symbol, Eq(f, 0), domain)
    lhs, rhs_s = invert_complex(f, 0, symbol, domain)
    if isinstance(rhs_s, FiniteSet):
        assert len(rhs_s.args) == 1
        rhs = rhs_s.args[0]
        if lhs.is_Add:
            result = add_type(lhs, rhs, symbol, domain)
    else:
        result = rhs_s
    return result

def solveset(f, symbol=None, domain=S.Complexes):
    f = sympify(f)
    symbol = sympify(symbol)
    if f is S.true:
        return domain
    if f is S.false:
        return S.EmptySet
    if not isinstance(f, (Expr, Relational, Number)):
        raise ValueError('%s is not a valid SymPy expression' % f)
    if not isinstance(symbol, (Expr, Relational)) and symbol is not None:
        raise ValueError('%s is not a valid SymPy symbol' % (symbol,))
    if not isinstance(domain, Set):
        raise ValueError('%s is not a valid domain' % domain)
    free_symbols = f.free_symbols
    if f.has(Piecewise):
        f = piecewise_fold(f)
    if symbol is None and (not free_symbols):
        b = Eq(f, 0)
        if b is S.true:
            return domain
        elif b is S.false:
            return S.EmptySet
        else:
            raise NotImplementedError(filldedent('\n                relationship between value and 0 is unknown: %s' % b))
    if symbol is None:
        if len(free_symbols) == 1:
            symbol = free_symbols.pop()
        elif free_symbols:
            raise ValueError(filldedent('\n                The independent variable must be specified for a\n                multivariate equation.'))
    elif not isinstance(symbol, Symbol):
        f, s, swap = recast_to_symbols([f], [symbol])
        return solveset(f[0], s[0], domain).xreplace(swap)
    newsym = None
    if domain.is_subset(S.Reals):
        if symbol._assumptions_orig != {'real': True}:
            newsym = Dummy('R', real=True)
    elif domain.is_subset(S.Complexes):
        if symbol._assumptions_orig != {'complex': True}:
            newsym = Dummy('C', complex=True)
    if newsym is not None:
        rv = solveset(f.xreplace({symbol: newsym}), newsym, domain)
        try:
            _rv = rv.xreplace({newsym: symbol})
        except TypeError:
            _rv = rv
        if rv.dummy_eq(_rv):
            rv = _rv
        return rv
    f, mask = _masked(f, Abs)
    f = f.rewrite(Piecewise)
    for d, e in mask:
        e = e.func(e.args[0].rewrite(Piecewise))
        f = f.xreplace({d: e})
    f = piecewise_fold(f)
    return _solveset(f, symbol, domain, _check=True)

def solveset_real(f, symbol):
    return solveset(f, symbol, S.Reals)

def solveset_complex(f, symbol):
    return solveset(f, symbol, S.Complexes)

def _solveset_multi(eqs, syms, domains):
    rep = {}
    for sym, dom in zip(syms, domains):
        if dom is S.Reals:
            rep[sym] = Symbol(sym.name, real=True)
    eqs = [eq.subs(rep) for eq in eqs]
    syms = [sym.subs(rep) for sym in syms]
    syms = tuple(syms)
    if len(eqs) == 0:
        return ProductSet(*domains)
    if len(syms) == 1:
        sym = syms[0]
        domain = domains[0]
        solsets = [solveset(eq, sym, domain) for eq in eqs]
        solset = Intersection(*solsets)
        return ImageSet(Lambda((sym,), (sym,)), solset).doit()
    eqs = sorted(eqs, key=lambda eq: len(eq.free_symbols & set(syms)))
    for n, eq in enumerate(eqs):
        sols = []
        all_handled = True
        for sym in syms:
            if sym not in eq.free_symbols:
                continue
            sol = solveset(eq, sym, domains[syms.index(sym)])
            if isinstance(sol, FiniteSet):
                i = syms.index(sym)
                symsp = syms[:i] + syms[i + 1:]
                domainsp = domains[:i] + domains[i + 1:]
                eqsp = eqs[:n] + eqs[n + 1:]
                for s in sol:
                    eqsp_sub = [eq.subs(sym, s) for eq in eqsp]
                    sol_others = _solveset_multi(eqsp_sub, symsp, domainsp)
                    fun = Lambda((symsp,), symsp[:i] + (s,) + symsp[i:])
                    sols.append(ImageSet(fun, sol_others).doit())
            else:
                all_handled = False
        if all_handled:
            return Union(*sols)

def solvify(f, symbol, domain):
    solution_set = solveset(f, symbol, domain)
    result = None
    if solution_set is S.EmptySet:
        result = []
    elif isinstance(solution_set, ConditionSet):
        raise NotImplementedError('solveset is unable to solve this equation.')
    elif isinstance(solution_set, FiniteSet):
        result = list(solution_set)
    else:
        period = periodicity(f, symbol)
        if period is not None:
            solutions = S.EmptySet
            iter_solutions = ()
            if isinstance(solution_set, ImageSet):
                iter_solutions = (solution_set,)
            elif isinstance(solution_set, Union):
                if all((isinstance(i, ImageSet) for i in solution_set.args)):
                    iter_solutions = solution_set.args
            for solution in iter_solutions:
                solutions += solution.intersect(Interval(0, period, False, True))
            if isinstance(solutions, FiniteSet):
                result = list(solutions)
        else:
            solution = solution_set.intersect(domain)
            if isinstance(solution, Union):
                if any((isinstance(i, FiniteSet) for i in solution.args)):
                    result = [sol for soln in solution.args for sol in soln.args if isinstance(soln, FiniteSet)]
                else:
                    return None
            elif isinstance(solution, FiniteSet):
                result += solution
    return result

def linear_coeffs(eq, *syms, dict=False):
    eq = _sympify(eq)
    if len(syms) == 1 and iterable(syms[0]) and (not isinstance(syms[0], Basic)):
        raise ValueError('expecting unpacked symbols, *syms')
    symset = set(syms)
    if len(symset) != len(syms):
        raise ValueError('duplicate symbols given')
    try:
        d, c = _linear_eq_to_dict([eq], symset)
        d = d[0]
        c = c[0]
    except PolyNonlinearError as err:
        raise NonlinearError(str(err))
    if dict:
        if c:
            d[S.One] = c
        return d
    rv = [S.Zero] * (len(syms) + 1)
    rv[-1] = c
    for i, k in enumerate(syms):
        if k not in d:
            continue
        rv[i] = d[k]
    return rv

def linear_eq_to_matrix(equations, *symbols):
    if not symbols:
        raise ValueError(filldedent('\n            Symbols must be given, for which coefficients\n            are to be found.\n            '))
    if isinstance(symbols[0], set):
        raise TypeError("Unordered 'set' type is not supported as input for symbols.")
    if hasattr(symbols[0], '__iter__'):
        symbols = symbols[0]
    if has_dups(symbols):
        raise ValueError('Symbols must be unique')
    equations = sympify(equations)
    if isinstance(equations, MatrixBase):
        equations = list(equations)
    elif isinstance(equations, (Expr, Eq)):
        equations = [equations]
    elif not is_sequence(equations):
        raise ValueError(filldedent('\n            Equation(s) must be given as a sequence, Expr,\n            Eq or Matrix.\n            '))
    try:
        eq, c = _linear_eq_to_dict(equations, symbols)
    except PolyNonlinearError as err:
        raise NonlinearError(str(err))
    n, m = shape = (len(eq), len(symbols))
    ix = dict(zip(symbols, range(m)))
    A = zeros(*shape)
    for row, d in enumerate(eq):
        for k in d:
            col = ix[k]
            A[row, col] = d[k]
    b = Matrix(n, 1, [-i for i in c])
    return (A, b)

def linsolve(system, *symbols):
    if not system:
        return S.EmptySet
    if symbols and hasattr(symbols[0], '__iter__'):
        symbols = symbols[0]
    sym_gen = isinstance(symbols, GeneratorType)
    dup_msg = 'duplicate symbols given'
    b = None
    if hasattr(system, '__iter__'):
        if len(system) == 2 and isinstance(system[0], MatrixBase):
            A, b = system
        if not isinstance(system[0], MatrixBase):
            if sym_gen or not symbols:
                raise ValueError(filldedent('\n                    When passing a system of equations, the explicit\n                    symbols for which a solution is being sought must\n                    be given as a sequence, too.\n                '))
            if len(set(symbols)) != len(symbols):
                raise ValueError(dup_msg)
            eqs = system
            eqs = [sympify(eq) for eq in eqs]
            try:
                sol = _linsolve(eqs, symbols)
            except PolyNonlinearError as exc:
                raise NonlinearError(str(exc))
            if sol is None:
                return S.EmptySet
            sol = FiniteSet(Tuple(*(sol.get(sym, sym) for sym in symbols)))
            return sol
    elif isinstance(system, MatrixBase) and (not (symbols and (not isinstance(symbols, GeneratorType)) and isinstance(symbols[0], MatrixBase))):
        A, b = (system[:, :-1], system[:, -1:])
    if b is None:
        raise ValueError('Invalid arguments')
    if sym_gen:
        symbols = [next(symbols) for i in range(A.cols)]
        symset = set(symbols)
        if any(symset & (A.free_symbols | b.free_symbols)):
            raise ValueError(filldedent("\n                At least one of the symbols provided\n                already appears in the system to be solved.\n                One way to avoid this is to use Dummy symbols in\n                the generator, e.g. numbered_symbols('%s', cls=Dummy)\n            " % symbols[0].name.rstrip('1234567890')))
        elif len(symset) != len(symbols):
            raise ValueError(dup_msg)
    if not symbols:
        symbols = [Dummy() for _ in range(A.cols)]
        name = _uniquely_named_symbol('tau', (A, b), compare=lambda i: str(i).rstrip('1234567890')).name
        gen = numbered_symbols(name)
    else:
        gen = None
    eqs = []
    rows = A.tolist()
    for rowi, bi in zip(rows, b):
        terms = [elem * sym for elem, sym in zip(rowi, symbols) if elem]
        terms.append(-bi)
        eqs.append(Add(*terms))
    eqs, ring = sympy_eqs_to_ring(eqs, symbols)
    sol = solve_lin_sys(eqs, ring, _raw=False)
    if sol is None:
        return S.EmptySet
    sol = FiniteSet(Tuple(*(sol.get(sym, sym) for sym in symbols)))
    if gen is not None:
        solsym = sol.free_symbols
        rep = {sym: next(gen) for sym in symbols if sym in solsym}
        sol = sol.subs(rep)
    return sol

def _return_conditionset(eqs, symbols):
    eqs = (Eq(lhs, 0) for lhs in eqs)
    condition_set = ConditionSet(Tuple(*symbols), And(*eqs), S.Complexes ** len(symbols))
    return condition_set

def substitution(system, symbols, result=[{}], known_symbols=[], exclude=[], all_symbols=None):
    if not system:
        return S.EmptySet
    for i, e in enumerate(system):
        if isinstance(e, Eq):
            system[i] = e.lhs - e.rhs
    if not symbols:
        msg = 'Symbols must be given, for which solution of the system is to be found.'
        raise ValueError(filldedent(msg))
    if not is_sequence(symbols):
        msg = 'symbols should be given as a sequence, e.g. a list.Not type %s: %s'
        raise TypeError(filldedent(msg % (type(symbols), symbols)))
    if not getattr(symbols[0], 'is_Symbol', False):
        msg = 'Iterable of symbols must be given as second argument, not type %s: %s'
        raise ValueError(filldedent(msg % (type(symbols[0]), symbols[0])))
    if all_symbols is None:
        all_symbols = symbols
    old_result = result
    complements = {}
    intersections = {}
    total_conditionset = -1
    total_solveset_call = -1

    def _unsolved_syms(eq, sort=False):
        free = eq.free_symbols
        unsolved = free - set(known_symbols) & set(all_symbols)
        if sort:
            unsolved = list(unsolved)
            unsolved.sort(key=default_sort_key)
        return unsolved
    eqs_in_better_order = list(ordered(system, lambda _: len(_unsolved_syms(_))))

    def add_intersection_complement(result, intersection_dict, complement_dict):
        final_result = []
        for res in result:
            res_copy = res
            for key_res, value_res in res.items():
                intersect_set, complement_set = (None, None)
                for key_sym, value_sym in intersection_dict.items():
                    if key_sym == key_res:
                        intersect_set = value_sym
                for key_sym, value_sym in complement_dict.items():
                    if key_sym == key_res:
                        complement_set = value_sym
                if intersect_set or complement_set:
                    new_value = FiniteSet(value_res)
                    if intersect_set and intersect_set != S.Complexes:
                        new_value = Intersection(new_value, intersect_set)
                    if complement_set:
                        new_value = Complement(new_value, complement_set)
                    if new_value is S.EmptySet:
                        res_copy = None
                        break
                    elif new_value.is_FiniteSet and len(new_value) == 1:
                        res_copy[key_res] = set(new_value).pop()
                    else:
                        res_copy[key_res] = new_value
            if res_copy is not None:
                final_result.append(res_copy)
        return final_result

    def _extract_main_soln(sym, sol, soln_imageset):
        if isinstance(sol, ConditionSet):
            sol = sol.base_set
        if isinstance(sol, Complement):
            complements[sym] = sol.args[1]
            sol = sol.args[0]
        if isinstance(sol, Union):
            sol_args = sol.args
            sol = S.EmptySet
            for sol_arg2 in sol_args:
                if isinstance(sol_arg2, FiniteSet):
                    sol += sol_arg2
                else:
                    sol += FiniteSet(sol_arg2)
        if isinstance(sol, Intersection):
            if sol.args[0] not in (S.Reals, S.Complexes):
                intersections[sym] = sol.args[0]
            sol = sol.args[1]
        if isinstance(sol, ImageSet):
            soln_imagest = sol
            expr2 = sol.lamda.expr
            sol = FiniteSet(expr2)
            soln_imageset[expr2] = soln_imagest
        if not isinstance(sol, FiniteSet):
            sol = FiniteSet(sol)
        return (sol, soln_imageset)

    def _check_exclude(rnew, imgset_yes):
        rnew_ = rnew
        if imgset_yes:
            rnew_copy = rnew.copy()
            dummy_n = imgset_yes[0]
            for key_res, value_res in rnew_copy.items():
                rnew_copy[key_res] = value_res.subs(dummy_n, 0)
            rnew_ = rnew_copy
        try:
            satisfy_exclude = any((checksol(d, rnew_) for d in exclude))
        except TypeError:
            satisfy_exclude = None
        return satisfy_exclude

    def _restore_imgset(rnew, original_imageset, newresult):
        restore_sym = set(rnew.keys()) & set(original_imageset.keys())
        for key_sym in restore_sym:
            img = original_imageset[key_sym]
            rnew[key_sym] = img
        if rnew not in newresult:
            newresult.append(rnew)

    def _append_eq(eq, result, res, delete_soln, n=None):
        u = Dummy('u')
        if n:
            eq = eq.subs(n, 0)
        satisfy = eq if eq in (True, False) else checksol(u, u, eq, minimal=True)
        if satisfy is False:
            delete_soln = True
            res = {}
        else:
            result.append(res)
        return (result, res, delete_soln)

    def _append_new_soln(rnew, sym, sol, imgset_yes, soln_imageset, original_imageset, newresult, eq=None):
        satisfy_exclude = _check_exclude(rnew, imgset_yes)
        delete_soln = False
        if not satisfy_exclude:
            local_n = None
            if imgset_yes:
                local_n = imgset_yes[0]
                base = imgset_yes[1]
                if sym and sol:
                    dummy_list = list(sol.atoms(Dummy))
                    local_n_list = [local_n for i in range(0, len(dummy_list))]
                    dummy_zip = zip(dummy_list, local_n_list)
                    lam = Lambda(local_n, sol.subs(dummy_zip))
                    rnew[sym] = ImageSet(lam, base)
                if eq is not None:
                    newresult, rnew, delete_soln = _append_eq(eq, newresult, rnew, delete_soln, local_n)
            elif eq is not None:
                newresult, rnew, delete_soln = _append_eq(eq, newresult, rnew, delete_soln)
            elif sol in soln_imageset.keys():
                rnew[sym] = soln_imageset[sol]
                _restore_imgset(rnew, original_imageset, newresult)
            else:
                newresult.append(rnew)
        elif satisfy_exclude:
            delete_soln = True
            rnew = {}
        _restore_imgset(rnew, original_imageset, newresult)
        return (newresult, delete_soln)

    def _new_order_result(result, eq):
        first_priority = []
        second_priority = []
        for res in result:
            if not any((isinstance(val, ImageSet) for val in res.values())):
                if eq.subs(res) == 0:
                    first_priority.append(res)
                else:
                    second_priority.append(res)
        if first_priority or second_priority:
            return first_priority + second_priority
        return result

    def _solve_using_known_values(result, solver):
        soln_imageset = {}
        total_solvest_call = 0
        total_conditionst = 0
        for index, eq in enumerate(eqs_in_better_order):
            newresult = []
            imgset_yes = False
            for res in result:
                original_imageset = {}
                got_symbol = set()
                for k, v in res.items():
                    if isinstance(v, ImageSet):
                        res[k] = v.lamda.expr
                        original_imageset[k] = v
                        dummy_n = v.lamda.expr.atoms(Dummy).pop()
                        base, = v.base_sets
                        imgset_yes = (dummy_n, base)
                    assert not isinstance(v, FiniteSet)
                eq2 = eq.subs(res).expand()
                if imgset_yes and (not eq2.has(imgset_yes[0])):
                    imgset_yes = False
                unsolved_syms = _unsolved_syms(eq2, sort=True)
                if not unsolved_syms:
                    if res:
                        newresult, delete_res = _append_new_soln(res, None, None, imgset_yes, soln_imageset, original_imageset, newresult, eq2)
                        if delete_res:
                            result.remove(res)
                    continue
                depen1, depen2 = eq2.as_independent(*unsolved_syms)
                if (depen1.has(Abs) or depen2.has(Abs)) and solver == solveset_complex:
                    raise NotImplementedError('nonlinsolve cannot solve equations with Abs in the complex domain')
                soln_imageset = {}
                for sym in unsolved_syms:
                    not_solvable = False
                    try:
                        soln = solver(eq2, sym)
                        total_solvest_call += 1
                        soln_new = S.EmptySet
                        if isinstance(soln, Complement):
                            complements[sym] = soln.args[1]
                            soln = soln.args[0]
                        if isinstance(soln, Intersection):
                            if soln.args[0] != Interval(-oo, oo):
                                intersections[sym] = soln.args[0]
                            soln_new += soln.args[1]
                        soln = soln_new if soln_new else soln
                        if index > 0 and solver == solveset_real:
                            if not isinstance(soln, (ImageSet, ConditionSet)):
                                soln += solveset_complex(eq2, sym)
                        if not isinstance(soln, (FiniteSet, ImageSet, ConditionSet, Union)) and soln is not S.EmptySet:
                            raise NotImplementedError(f'nonlinsolve cannot handle solution of type {type(soln).__name__} for symbol {sym}. Got {soln} from equation {eq2}.')
                    except ValueError:
                        continue
                    if isinstance(soln, ConditionSet):
                        if soln.base_set in (S.Reals, S.Complexes):
                            soln = S.EmptySet
                            not_solvable = True
                            total_conditionst += 1
                        else:
                            soln = soln.base_set
                    if soln is not S.EmptySet:
                        soln, soln_imageset = _extract_main_soln(sym, soln, soln_imageset)
                    for sol in soln:
                        sol, soln_imageset = _extract_main_soln(sym, sol, soln_imageset)
                        sol = set(sol).pop()
                        free = sol.free_symbols
                        if got_symbol and any((ss in free for ss in got_symbol)):
                            continue
                        rnew = res.copy()
                        for k, v in res.items():
                            if isinstance(v, Expr) and isinstance(sol, Expr):
                                rnew[k] = v.subs(sym, sol)
                        if sol in soln_imageset.keys():
                            imgst = soln_imageset[sol]
                            rnew[sym] = imgst.lamda(*[0 for i in range(0, len(imgst.lamda.variables))])
                        else:
                            rnew[sym] = sol
                        newresult, delete_res = _append_new_soln(rnew, sym, sol, imgset_yes, soln_imageset, original_imageset, newresult)
                        if delete_res:
                            result.remove(res)
                    if not not_solvable:
                        got_symbol.add(sym)
            if newresult:
                result = newresult
        return (result, total_solvest_call, total_conditionst)
    new_result_real, solve_call1, cnd_call1 = _solve_using_known_values(old_result, solveset_real)
    new_result_complex, solve_call2, cnd_call2 = _solve_using_known_values(old_result, solveset_complex)
    total_conditionset += cnd_call1 + cnd_call2
    total_solveset_call += solve_call1 + solve_call2
    if total_conditionset == total_solveset_call and total_solveset_call != -1:
        return _return_conditionset(eqs_in_better_order, all_symbols)
    filtered_complex = []
    for i in list(new_result_complex):
        for j in list(new_result_real):
            if i.keys() != j.keys():
                continue
            if all((a.dummy_eq(b) for a, b in zip(i.values(), j.values()) if not (isinstance(a, int) and isinstance(b, int)))):
                break
        else:
            filtered_complex.append(i)
    result = new_result_real + filtered_complex
    result_all_variables = []
    result_infinite = []
    for res in result:
        if not res:
            continue
        if len(res) < len(all_symbols):
            solved_symbols = res.keys()
            unsolved = list(filter(lambda x: x not in solved_symbols, all_symbols))
            for unsolved_sym in unsolved:
                res[unsolved_sym] = unsolved_sym
            result_infinite.append(res)
        if res not in result_all_variables:
            result_all_variables.append(res)
    if result_infinite:
        result_all_variables = result_infinite
    if intersections or complements:
        result_all_variables = add_intersection_complement(result_all_variables, intersections, complements)
    result = S.EmptySet
    for r in result_all_variables:
        temp = [r[symb] for symb in all_symbols]
        result += FiniteSet(tuple(temp))
    return result

def _solveset_work(system, symbols):
    soln = solveset(system[0], symbols[0])
    if soln == S.EmptySet:
        return S.EmptySet
    if isinstance(soln, FiniteSet):
        _soln = FiniteSet(*[(s,) for s in soln])
        return _soln
    else:
        return FiniteSet(tuple(FiniteSet(soln)))

def _handle_positive_dimensional(polys, symbols, denominators):
    from sympy.polys.polytools import groebner
    _symbols = list(symbols)
    _symbols.sort(key=default_sort_key)
    basis = groebner(polys, _symbols, polys=True)
    new_system = []
    for poly_eq in basis:
        new_system.append(poly_eq.as_expr())
    result = [{}]
    result = substitution(new_system, symbols, result, [], denominators)
    return result

def _handle_zero_dimensional(polys, symbols, system):
    result = solve_poly_system(polys, *symbols)
    result_update = S.EmptySet
    for res in result:
        dict_sym_value = dict(list(zip(symbols, res)))
        if all((checksol(eq, dict_sym_value) for eq in system)):
            result_update += FiniteSet(res)
    return result_update

def _separate_poly_nonpoly(system, symbols):
    polys = []
    polys_expr = []
    nonpolys = []
    unrad_changed = []
    denominators = set()
    poly = None
    for eq in system:
        denominators.update(_simple_dens(eq, symbols))
        if isinstance(eq, Eq):
            eq = eq.lhs - eq.rhs
        without_radicals = unrad(simplify(eq), *symbols)
        if without_radicals:
            unrad_changed.append(eq)
            eq_unrad, cov = without_radicals
            if not cov:
                eq = eq_unrad
        if isinstance(eq, Expr):
            eq = eq.as_numer_denom()[0]
            poly = eq.as_poly(*symbols, extension=True)
        elif eq == 0:
            continue
        if poly is not None:
            polys.append(poly)
            polys_expr.append(poly.as_expr())
        else:
            nonpolys.append(eq)
    return (polys, polys_expr, nonpolys, denominators, unrad_changed)

def _handle_poly(polys, symbols):
    no_information = [{}]
    no_solutions = []
    no_equations = []
    inexact = any((not p.domain.is_Exact for p in polys))
    if inexact:
        polys = [poly(nsimplify(p.as_expr().evalf(), rational=True)) for p in polys]
    basis = groebner(polys, symbols, order='grevlex', polys=False)
    if 1 in basis:
        poly_sol = no_solutions
        poly_eqs = no_equations
    elif basis.is_zero_dimensional:
        basis = basis.fglm('lex')
        if inexact:
            basis = [nfloat(p) for p in basis]
        try:
            result = solve_poly_system(basis, *symbols, strict=True)
        except UnsolvableFactorError:
            poly_sol = no_information
            poly_eqs = list(basis)
        else:
            poly_sol = [dict(zip(symbols, res)) for res in result]
            poly_eqs = no_equations
    else:
        poly_sol = no_information
        poly_eqs = list(groebner(polys, symbols, order='lex', polys=False))
        if inexact:
            poly_eqs = [nfloat(p) for p in poly_eqs]
    return (poly_sol, poly_eqs)

def nonlinsolve(system, *symbols):
    if not system:
        return S.EmptySet
    if not symbols:
        msg = 'Symbols must be given, for which solution of the system is to be found.'
        raise ValueError(filldedent(msg))
    if hasattr(symbols[0], '__iter__'):
        symbols = symbols[0]
    if not is_sequence(symbols) or not symbols:
        msg = 'Symbols must be given, for which solution of the system is to be found.'
        raise IndexError(filldedent(msg))
    symbols = list(map(_sympify, symbols))
    system = [_sympify(eq) for eq in system]
    system, symbols, swap = recast_to_symbols(system, symbols)
    if swap:
        soln = nonlinsolve(system, symbols)
        return FiniteSet(*[tuple((i.xreplace(swap) for i in s)) for s in soln])
    if len(system) == 1 and len(symbols) == 1:
        return _solveset_work(system, symbols)
    polys, polys_expr, nonpolys, denominators, unrad_changed = _separate_poly_nonpoly(system, symbols)
    poly_eqs = []
    poly_sol = [{}]
    if polys:
        poly_sol, poly_eqs = _handle_poly(polys, symbols)
        if poly_sol and poly_sol[0]:
            poly_syms = set().union(*(eq.free_symbols for eq in polys))
            unrad_syms = set().union(*(eq.free_symbols for eq in unrad_changed))
            if unrad_syms == poly_syms and unrad_changed:
                poly_sol = [sol for sol in poly_sol if checksol(unrad_changed, sol)]
    remaining = poly_eqs + nonpolys
    to_tuple = lambda sol: tuple((sol.get(s, s) for s in symbols))
    if not remaining:
        return FiniteSet(*map(to_tuple, poly_sol))
    else:
        subs_res = substitution(remaining, symbols, result=poly_sol, exclude=denominators)
        if not isinstance(subs_res, FiniteSet):
            return subs_res
        if unrad_changed:
            result = [dict(zip(symbols, sol)) for sol in subs_res.args]
            correct_sols = [sol for sol in result if any((isinstance(v, Set) for v in sol)) or checksol(unrad_changed, sol) != False]
            return FiniteSet(*map(to_tuple, correct_sols))
        else:
            return subs_res