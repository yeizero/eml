from __future__ import annotations
from sympy.core import Pow
from sympy.core.function import Derivative, AppliedUndef
from sympy.core.relational import Equality
from sympy.core.symbol import Wild

def _preprocess(expr, func=None, hint='_Integral'):
    if isinstance(expr, Pow):
        if expr.exp.is_positive:
            expr = expr.base
    derivs = expr.atoms(Derivative)
    if not func:
        funcs = set().union(*[d.atoms(AppliedUndef) for d in derivs])
        if len(funcs) != 1:
            raise ValueError('The function cannot be automatically detected for %s.' % expr)
        func = funcs.pop()
    fvars = set(func.args)
    if hint is None:
        return (expr, func)
    reps = [(d, d.doit()) for d in derivs if not hint.endswith('_Integral') or d.has(func) or set(d.variables) & fvars]
    eq = expr.subs(reps)
    return (eq, func)

def ode_order(expr, func):
    a = Wild('a', exclude=[func])
    if expr.match(a):
        return 0
    if isinstance(expr, Derivative):
        if expr.args[0] == func:
            return len(expr.variables)
        else:
            args = expr.args[0].args
            rv = len(expr.variables)
            if args:
                rv += max((ode_order(_, func) for _ in args))
            return rv
    else:
        return max((ode_order(_, func) for _ in expr.args)) if expr.args else 0

def _desolve(eq, func=None, hint='default', ics=None, simplify=True, *, prep=True, **kwargs):
    if isinstance(eq, Equality):
        eq = eq.lhs - eq.rhs
    if prep or func is None:
        eq, func = _preprocess(eq, func)
        prep = False
    type = kwargs.get('type', None)
    xi = kwargs.get('xi')
    eta = kwargs.get('eta')
    x0 = kwargs.get('x0', 0)
    terms = kwargs.get('n')
    if type == 'ode':
        from sympy.solvers.ode import classify_ode, allhints
        classifier = classify_ode
        string = 'ODE '
        dummy = ''
    elif type == 'pde':
        from sympy.solvers.pde import classify_pde, allhints
        classifier = classify_pde
        string = 'PDE '
        dummy = 'p'
    if kwargs.get('classify', True):
        hints = classifier(eq, func, dict=True, ics=ics, xi=xi, eta=eta, n=terms, x0=x0, hint=hint, prep=prep)
    else:
        hints = kwargs.get('hint', {'default': hint, hint: kwargs['match'], 'order': kwargs['order']})
    if not hints['default']:
        if hint not in allhints and hint != 'default':
            raise ValueError('Hint not recognized: ' + hint)
        elif hint not in hints['ordered_hints'] and hint != 'default':
            raise ValueError(string + str(eq) + ' does not match hint ' + hint)
        elif hints['order'] == 0:
            raise ValueError(str(eq) + ' is not a solvable differential equation in ' + str(func))
        else:
            raise NotImplementedError(dummy + 'solve' + ': Cannot solve ' + str(eq))
    if hint == 'default':
        return _desolve(eq, func, ics=ics, hint=hints['default'], simplify=simplify, prep=prep, x0=x0, classify=False, order=hints['order'], match=hints[hints['default']], xi=xi, eta=eta, n=terms, type=type)
    elif hint in ('all', 'all_Integral', 'best'):
        retdict = {}
        gethints = set(hints) - {'order', 'default', 'ordered_hints'}
        if hint == 'all_Integral':
            for i in hints:
                if i.endswith('_Integral'):
                    gethints.remove(i.removesuffix('_Integral'))
            for k in ['1st_homogeneous_coeff_best', '1st_power_series', 'lie_group', '2nd_power_series_ordinary', '2nd_power_series_regular']:
                if k in gethints:
                    gethints.remove(k)
        for i in gethints:
            sol = _desolve(eq, func, ics=ics, hint=i, x0=x0, simplify=simplify, prep=prep, classify=False, n=terms, order=hints['order'], match=hints[i], type=type)
            retdict[i] = sol
        retdict['all'] = True
        retdict['eq'] = eq
        return retdict
    elif hint not in allhints:
        raise ValueError('Hint not recognized: ' + hint)
    elif hint not in hints:
        raise ValueError(string + str(eq) + ' does not match hint ' + hint)
    else:
        hints['hint'] = hint
    hints.update({'func': func, 'eq': eq})
    return hints