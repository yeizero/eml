from __future__ import annotations
from typing import Any, TYPE_CHECKING
import itertools
from sympy import Dummy
from sympy.core import S
from sympy.core.exprtools import factor_terms
from sympy.core.sorting import default_sort_key
from sympy.logic.boolalg import Boolean
from sympy.polys import Poly, groebner, roots
from sympy.polys.domains import ZZ
from sympy.polys.polyoptions import build_options
from sympy.polys.polytools import parallel_poly_from_expr, sqf_part
from sympy.polys.polyerrors import ComputationFailed, PolificationFailed, CoercionFailed, GeneratorsNeeded, DomainError
from sympy.simplify import rcollect
from sympy.utilities import postfixes
from sympy.utilities.iterables import cartes
from sympy.utilities.misc import filldedent
from sympy.logic.boolalg import Or, And
from sympy.core.relational import Eq
if TYPE_CHECKING:
    from collections.abc import Sequence, Iterable
    from sympy.core.expr import Expr

class SolveFailed(Exception):
    pass

def solve_poly_system(seq, *gens, strict=False, **args):
    try:
        polys, opt = parallel_poly_from_expr(seq, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('solve_poly_system', len(seq), exc)
    if len(polys) == len(opt.gens) == 2:
        f, g = polys
        if all((i <= 2 for i in f.degree_list() + g.degree_list())):
            try:
                return solve_biquadratic(f, g, opt)
            except SolveFailed:
                pass
    return solve_generic(polys, opt, strict=strict)

def solve_biquadratic(f, g, opt):
    G = groebner([f, g])
    if len(G) == 1 and G[0].is_ground:
        return None
    if len(G) != 2:
        raise SolveFailed
    x, y = opt.gens
    p, q = G
    if not p.gcd(q).is_ground:
        raise SolveFailed
    p = Poly(p, x, expand=False)
    p_roots = [rcollect(expr, y) for expr in roots(p).keys()]
    q = q.ltrim(-1)
    q_roots = list(roots(q).keys())
    solutions = [(p_root.subs(y, q_root), q_root) for q_root, p_root in itertools.product(q_roots, p_roots)]
    return sorted(solutions, key=default_sort_key)

def solve_generic(polys, opt, strict=False):

    def _is_univariate(f):
        for monom in f.monoms():
            if any(monom[:-1]):
                return False
        return True

    def _subs_root(f, gen, zero):
        p = f.as_expr({gen: zero})
        if f.degree(gen) >= 2:
            p = p.expand(deep=False)
        return p

    def _solve_reduced_system(system, gens, entry=False):
        if len(system) == len(gens) == 1:
            zeros = list(roots(system[0], gens[-1], strict=strict).keys())
            return [(zero,) for zero in zeros]
        basis = groebner(system, gens, polys=True)
        if len(basis) == 1 and basis[0].is_ground:
            if not entry:
                return []
            else:
                return None
        univariate = list(filter(_is_univariate, basis))
        if len(basis) < len(gens):
            raise NotImplementedError(filldedent('\n                only zero-dimensional systems supported\n                (finite number of solutions)\n                '))
        if len(univariate) == 1:
            f = univariate.pop()
        else:
            raise NotImplementedError(filldedent('\n                only zero-dimensional systems supported\n                (finite number of solutions)\n                '))
        gens = f.gens
        gen = gens[-1]
        zeros = list(roots(f.ltrim(gen), strict=strict).keys())
        if not zeros:
            return []
        if len(basis) == 1:
            return [(zero,) for zero in zeros]
        solutions = []
        for zero in zeros:
            new_system = []
            new_gens = gens[:-1]
            for b in basis[:-1]:
                eq = _subs_root(b, gen, zero)
                if eq is not S.Zero:
                    new_system.append(eq)
            for solution in _solve_reduced_system(new_system, new_gens):
                solutions.append(solution + (zero,))
        if solutions and len(solutions[0]) != len(gens):
            raise NotImplementedError(filldedent('\n                only zero-dimensional systems supported\n                (finite number of solutions)\n                '))
        return solutions
    try:
        result = _solve_reduced_system(polys, opt.gens, entry=True)
    except CoercionFailed:
        raise NotImplementedError
    if result is not None:
        return sorted(result, key=default_sort_key)

def solve_triangulated(polys, *gens, **args):
    opt = build_options(gens, args)
    G = groebner(polys, gens, polys=True)
    G = list(reversed(G))
    extension = opt.get('extension', False)
    if extension:

        def _solve_univariate(f):
            return [r for r, _ in f.all_roots(multiple=False, radicals=False)]
    else:
        domain = opt.get('domain')
        if domain is not None:
            for i, g in enumerate(G):
                G[i] = g.set_domain(domain)

        def _solve_univariate(f):
            return list(f.ground_roots().keys())
    f, G = (G[0].ltrim(-1), G[1:])
    dom = f.get_domain()
    zeros = _solve_univariate(f)
    if extension:
        solutions = {((zero,), dom.algebraic_field(zero)) for zero in zeros}
    else:
        solutions = {((zero,), dom) for zero in zeros}
    var_seq = reversed(gens[:-1])
    vars_seq = postfixes(gens[1:])
    for var, vars in zip(var_seq, vars_seq):
        _solutions = set()
        for values, dom in solutions:
            H, mapping = ([], list(zip(vars, values)))
            for g in G:
                _vars = (var,) + vars
                if g.has_only_gens(*_vars) and g.degree(var) != 0:
                    if extension:
                        g = g.set_domain(g.domain.unify(dom))
                    h = g.ltrim(var).eval(dict(mapping))
                    if g.degree(var) == h.degree():
                        H.append(h)
            p = min(H, key=lambda h: h.degree())
            zeros = _solve_univariate(p)
            for zero in zeros:
                if not zero in dom:
                    dom_zero = dom.algebraic_field(zero)
                else:
                    dom_zero = dom
                _solutions.add(((zero,) + values, dom_zero))
        solutions = _solutions
    return sorted((s for s, _ in solutions), key=default_sort_key)

def factor_system(eqs: Sequence[Expr | complex], gens: Sequence[Expr]=(), **kwargs: Any) -> list[list[Expr]]:
    systems = _factor_system_poly_from_expr(eqs, gens, **kwargs)
    systems_generic = [sys for sys in systems if not _is_degenerate(sys)]
    systems_expr = [[p.as_expr() for p in system] for system in systems_generic]
    return systems_expr

def _is_degenerate(system: list[Poly]) -> bool:
    return any((p.is_ground for p in system))

def factor_system_bool(eqs: Sequence[Expr | complex], gens: Sequence[Expr]=(), **kwargs: Any) -> Boolean:
    systems = factor_system_cond(eqs, gens, **kwargs)
    return Or(*[And(*[Eq(eq, 0) for eq in sys]) for sys in systems])

def factor_system_cond(eqs: Sequence[Expr | complex], gens: Sequence[Expr]=(), **kwargs: Any) -> list[list[Expr]]:
    systems_poly = _factor_system_poly_from_expr(eqs, gens, **kwargs)
    systems = [[p.as_expr() for p in system] for system in systems_poly]
    return systems

def _factor_system_poly_from_expr(eqs: Sequence[Expr | complex], gens: Sequence[Expr], **kwargs: Any) -> list[list[Poly]]:
    try:
        polys, opts = parallel_poly_from_expr(eqs, *gens, **kwargs)
        only_numbers = False
    except (GeneratorsNeeded, PolificationFailed):
        _u = Dummy('u')
        polys, opts = parallel_poly_from_expr(eqs, [_u], **kwargs)
        assert opts['domain'].is_Numerical
        only_numbers = True
    if only_numbers:
        return [[]] if all((p == 0 for p in polys)) else []
    return factor_system_poly(polys)

def factor_system_poly(polys: list[Poly]) -> list[list[Poly]]:
    if not all((isinstance(poly, Poly) for poly in polys)):
        raise TypeError('polys should be a list of Poly instances')
    if not polys:
        return [[]]
    base_domain = polys[0].domain
    base_gens = polys[0].gens
    if not all((poly.domain == base_domain and poly.gens == base_gens for poly in polys[1:])):
        raise DomainError('All polynomials must have the same domain and generators')
    factor_sets = []
    for poly in polys:
        constant, factors_mult = poly.factor_list()
        if constant.is_zero is True:
            continue
        elif constant.is_zero is False:
            if not factors_mult:
                return []
            factor_sets.append([f for f, _ in factors_mult])
        else:
            constant = sqf_part(factor_terms(constant).as_coeff_Mul()[1])
            constp = Poly(constant, base_gens, domain=base_domain)
            factors = [f for f, _ in factors_mult]
            factors.append(constp)
            factor_sets.append(factors)
    if not factor_sets:
        return [[]]
    result = _factor_sets(factor_sets)
    return _sort_systems(result)

def _factor_sets_slow(eqs: list[list]) -> set[frozenset]:
    if not eqs:
        return {frozenset()}
    systems_set = {frozenset(sys) for sys in cartes(*eqs)}
    return {s1 for s1 in systems_set if not any((s1 > s2 for s2 in systems_set))}

def _factor_sets(eqs: list[list]) -> set[frozenset]:
    if not eqs:
        return {frozenset()}
    current_set = min(eqs, key=len)
    other_sets = [s for s in eqs if s is not current_set]
    stack = [(factor, [s for s in other_sets if factor not in s], {factor}) for factor in current_set]
    result = set()
    while stack:
        factor, remaining_sets, current_solution = stack.pop()
        if not remaining_sets:
            result.add(frozenset(current_solution))
            continue
        next_set = min(remaining_sets, key=len)
        next_remaining = [s for s in remaining_sets if s is not next_set]
        for next_factor in next_set:
            valid_remaining = [s for s in next_remaining if next_factor not in s]
            new_solution = current_solution | {next_factor}
            stack.append((next_factor, valid_remaining, new_solution))
    return {s1 for s1 in result if not any((s1 > s2 for s2 in result))}

def _sort_systems(systems: Iterable[Iterable[Poly]]) -> list[list[Poly]]:
    systems_list = [sorted(s, key=_poly_sort_key, reverse=True) for s in systems]
    return sorted(systems_list, key=_sys_sort_key, reverse=True)

def _poly_sort_key(poly):
    if poly.domain.is_FF:
        poly = poly.set_domain(ZZ)
    return (poly.degree_list(), poly.rep.to_list())

def _sys_sort_key(sys):
    return list(zip(*map(_poly_sort_key, sys)))