from __future__ import annotations
from .accumulationbounds import AccumBounds, AccumulationBounds
from .singularities import singularities
from sympy.core import Pow, S
from sympy.core.function import diff, expand_mul, Function
from sympy.core.kind import NumberKind
from sympy.core.mod import Mod
from sympy.core.numbers import equal_valued
from sympy.core.relational import Relational
from sympy.core.symbol import Symbol, Dummy
from sympy.core.sympify import _sympify
from sympy.functions.elementary.complexes import Abs, im, re
from sympy.functions.elementary.exponential import exp, log
from sympy.functions.elementary.integers import frac
from sympy.functions.elementary.piecewise import Piecewise
from sympy.functions.elementary.trigonometric import TrigonometricFunction, sin, cos, tan, cot, csc, sec, asin, acos, acot, atan, asec, acsc
from sympy.functions.elementary.hyperbolic import sinh, cosh, tanh, coth, sech, csch, asinh, acosh, atanh, acoth, asech, acsch
from sympy.polys.polytools import degree, lcm_list
from sympy.sets.sets import Interval, Intersection, FiniteSet, Union, Complement
from sympy.sets.fancysets import ImageSet
from sympy.sets.conditionset import ConditionSet
from sympy.utilities import filldedent
from sympy.utilities.iterables import iterable
from sympy.matrices.dense import hessian

def continuous_domain(f, symbol, domain):
    from sympy.solvers.inequalities import solve_univariate_inequality
    if not domain.is_subset(S.Reals):
        raise NotImplementedError(filldedent('\n            Domain must be a subset of S.Reals.\n            '))
    implemented = [Pow, exp, log, Abs, frac, sin, cos, tan, cot, sec, csc, asin, acos, atan, acot, asec, acsc, sinh, cosh, tanh, coth, sech, csch, asinh, acosh, atanh, acoth, asech, acsch]
    used = [fct.func for fct in f.atoms(Function) if fct.has(symbol)]
    if any((func not in implemented for func in used)):
        raise NotImplementedError(filldedent('\n            Unable to determine the domain of the given function.\n            '))
    x = Symbol('x')
    constraints = {log: (x > 0,), asin: (x >= -1, x <= 1), acos: (x >= -1, x <= 1), acosh: (x >= 1,), atanh: (x > -1, x < 1), asech: (x > 0, x <= 1)}
    constraints_union = {asec: (x <= -1, x >= 1), acsc: (x <= -1, x >= 1), acoth: (x < -1, x > 1)}
    cont_domain = domain
    for atom in f.atoms(Pow):
        den = atom.exp.as_numer_denom()[1]
        if atom.exp.is_rational and den.is_odd:
            pass
        else:
            constraint = solve_univariate_inequality(atom.base >= 0, symbol).as_set()
            cont_domain = Intersection(constraint, cont_domain)
    for atom in f.atoms(Function):
        if atom.func in constraints:
            for c in constraints[atom.func]:
                constraint_relational = c.subs(x, atom.args[0])
                constraint_set = solve_univariate_inequality(constraint_relational, symbol).as_set()
                cont_domain = Intersection(constraint_set, cont_domain)
        elif atom.func in constraints_union:
            constraint_set = S.EmptySet
            for c in constraints_union[atom.func]:
                constraint_relational = c.subs(x, atom.args[0])
                constraint_set += solve_univariate_inequality(constraint_relational, symbol).as_set()
            cont_domain = Intersection(constraint_set, cont_domain)
        elif atom.func == acot:
            from sympy.solvers.solveset import solveset_real
            cont_domain -= solveset_real(atom.args[0], symbol)
        elif atom.func == frac:
            from sympy.solvers.solveset import solveset_real
            r = function_range(atom.args[0], symbol, domain)
            r = Intersection(r, S.Integers)
            if r.is_finite_set:
                discont = S.EmptySet
                for n in r:
                    discont += solveset_real(atom.args[0] - n, symbol)
            else:
                discont = ConditionSet(symbol, S.Integers.contains(atom.args[0]), cont_domain)
            cont_domain -= discont
    return cont_domain - singularities(f, symbol, domain)

def function_range(f, symbol, domain):
    if domain is S.EmptySet:
        return S.EmptySet
    period = periodicity(f, symbol)
    if period == S.Zero:
        return FiniteSet(f.expand())
    from sympy.series.limits import limit
    from sympy.solvers.solveset import solveset
    if period is not None:
        if isinstance(domain, Interval):
            if (domain.inf - domain.sup).is_infinite:
                domain = Interval(0, period)
        elif isinstance(domain, Union):
            for sub_dom in domain.args:
                if isinstance(sub_dom, Interval) and (sub_dom.inf - sub_dom.sup).is_infinite:
                    domain = Interval(0, period)
    intervals = continuous_domain(f, symbol, domain)
    range_int = S.EmptySet
    if isinstance(intervals, (Interval, FiniteSet)):
        interval_iter = (intervals,)
    elif isinstance(intervals, Union):
        interval_iter = intervals.args
    else:
        raise NotImplementedError('Unable to find range for the given domain.')
    for interval in interval_iter:
        if isinstance(interval, FiniteSet):
            for singleton in interval:
                if singleton in domain:
                    range_int += FiniteSet(f.subs(symbol, singleton))
        elif isinstance(interval, Interval):
            vals = S.EmptySet
            critical_values = S.EmptySet
            bounds = ((interval.left_open, interval.inf, '+'), (interval.right_open, interval.sup, '-'))
            for is_open, limit_point, direction in bounds:
                if is_open:
                    critical_values += FiniteSet(limit(f, symbol, limit_point, direction))
                    vals += critical_values
                else:
                    vals += FiniteSet(f.subs(symbol, limit_point))
            critical_points = solveset(f.diff(symbol), symbol, interval)
            if not iterable(critical_points):
                raise NotImplementedError('Unable to find critical points for {}'.format(f))
            if isinstance(critical_points, ImageSet):
                raise NotImplementedError('Infinite number of critical points for {}'.format(f))
            for critical_point in critical_points:
                vals += FiniteSet(f.subs(symbol, critical_point))
            left_open, right_open = (False, False)
            if critical_values is not S.EmptySet:
                if critical_values.inf == vals.inf:
                    left_open = True
                if critical_values.sup == vals.sup:
                    right_open = True
            range_int += Interval(vals.inf, vals.sup, left_open, right_open)
        else:
            raise NotImplementedError('Unable to find range for the given domain.')
    return range_int

def not_empty_in(finset_intersection, *syms):
    if len(syms) == 0:
        raise ValueError('One or more symbols must be given in syms.')
    if finset_intersection is S.EmptySet:
        return S.EmptySet
    if isinstance(finset_intersection, Union):
        elm_in_sets = finset_intersection.args[0]
        return Union(not_empty_in(finset_intersection.args[1], *syms), elm_in_sets)
    if isinstance(finset_intersection, FiniteSet):
        finite_set = finset_intersection
        _sets = S.Reals
    else:
        finite_set = finset_intersection.args[1]
        _sets = finset_intersection.args[0]
    if not isinstance(finite_set, FiniteSet):
        raise ValueError('A FiniteSet must be given, not %s: %s' % (type(finite_set), finite_set))
    if len(syms) == 1:
        symb = syms[0]
    else:
        raise NotImplementedError('more than one variables %s not handled' % (syms,))

    def elm_domain(expr, intrvl):
        from sympy.solvers.solveset import solveset
        _start = intrvl.start
        _end = intrvl.end
        _singularities = solveset(expr.as_numer_denom()[1], symb, domain=S.Reals)
        if intrvl.right_open:
            if _end is S.Infinity:
                _domain1 = S.Reals
            else:
                _domain1 = solveset(expr < _end, symb, domain=S.Reals)
        else:
            _domain1 = solveset(expr <= _end, symb, domain=S.Reals)
        if intrvl.left_open:
            if _start is S.NegativeInfinity:
                _domain2 = S.Reals
            else:
                _domain2 = solveset(expr > _start, symb, domain=S.Reals)
        else:
            _domain2 = solveset(expr >= _start, symb, domain=S.Reals)
        expr_with_sing = Intersection(_domain1, _domain2)
        expr_domain = Complement(expr_with_sing, _singularities)
        return expr_domain
    if isinstance(_sets, Interval):
        return Union(*[elm_domain(element, _sets) for element in finite_set])
    if isinstance(_sets, Union):
        _domain = S.EmptySet
        for intrvl in _sets.args:
            _domain_element = Union(*[elm_domain(element, intrvl) for element in finite_set])
            _domain = Union(_domain, _domain_element)
        return _domain

def periodicity(f, symbol, check=False):
    if symbol.kind is not NumberKind:
        raise NotImplementedError('Cannot use symbol of kind %s' % symbol.kind)
    temp = Dummy('x', real=True)
    f = f.subs(symbol, temp)
    symbol = temp

    def _check(orig_f, period):
        new_f = orig_f.subs(symbol, symbol + period)
        if new_f.equals(orig_f):
            return period
        else:
            raise NotImplementedError(filldedent('\n                The period of the given function cannot be verified.\n                When `%s` was replaced with `%s + %s` in `%s`, the result\n                was `%s` which was not recognized as being the same as\n                the original function.\n                So either the period was wrong or the two forms were\n                not recognized as being equal.\n                Set check=False to obtain the value.' % (symbol, symbol, period, orig_f, new_f)))
    orig_f = f
    period = None
    if isinstance(f, Relational):
        f = f.lhs - f.rhs
    f = f.simplify()
    if symbol not in f.free_symbols:
        return S.Zero
    if isinstance(f, TrigonometricFunction):
        try:
            period = f.period(symbol)
        except NotImplementedError:
            pass
    if isinstance(f, Abs):
        arg = f.args[0]
        if isinstance(arg, (sec, csc, cos)):
            arg = sin(arg.args[0])
        period = periodicity(arg, symbol)
        if period is not None and isinstance(arg, sin):
            orig_f = Abs(arg)
            try:
                return _check(orig_f, period / 2)
            except NotImplementedError as err:
                if check:
                    raise NotImplementedError(err)
    if isinstance(f, exp) or (f.is_Pow and f.base == S.Exp1):
        f = Pow(S.Exp1, expand_mul(f.exp))
        if im(f) != 0:
            period_real = periodicity(re(f), symbol)
            period_imag = periodicity(im(f), symbol)
            if period_real is not None and period_imag is not None:
                period = lcim([period_real, period_imag])
    if f.is_Pow and f.base != S.Exp1:
        base, expo = f.args
        base_has_sym = base.has(symbol)
        expo_has_sym = expo.has(symbol)
        if base_has_sym and (not expo_has_sym):
            period = periodicity(base, symbol)
        elif expo_has_sym and (not base_has_sym):
            period = periodicity(expo, symbol)
        else:
            period = _periodicity(f.args, symbol)
    elif f.is_Mul:
        coeff, g = f.as_independent(symbol, as_Add=False)
        if isinstance(g, TrigonometricFunction) or not equal_valued(coeff, 1):
            period = periodicity(g, symbol)
        else:
            period = _periodicity(g.args, symbol)
    elif f.is_Add:
        k, g = f.as_independent(symbol)
        if k is not S.Zero:
            return periodicity(g, symbol)
        period = _periodicity(g.args, symbol)
    elif isinstance(f, Mod):
        a, n = f.args
        if a == symbol:
            period = n
        elif isinstance(a, TrigonometricFunction):
            period = periodicity(a, symbol)
        elif a.is_polynomial(symbol) and degree(a, symbol) == 1 and (symbol not in n.free_symbols):
            period = Abs(n / a.diff(symbol))
    elif isinstance(f, Piecewise):
        pass
    elif period is None:
        from sympy.solvers.decompogen import compogen, decompogen
        g_s = decompogen(f, symbol)
        num_of_gs = len(g_s)
        if num_of_gs > 1:
            for index, g in enumerate(reversed(g_s)):
                start_index = num_of_gs - 1 - index
                g = compogen(g_s[start_index:], symbol)
                if g not in (orig_f, f):
                    period = periodicity(g, symbol)
                    if period is not None:
                        break
    if period is not None:
        if check:
            return _check(orig_f, period)
        return period
    return None

def _periodicity(args, symbol):
    periods = []
    for f in args:
        period = periodicity(f, symbol)
        if period is None:
            return None
        if period is not S.Zero:
            periods.append(period)
    if len(periods) > 1:
        return lcim(periods)
    if periods:
        return periods[0]

def lcim(numbers):
    result = None
    if all((num.is_irrational for num in numbers)):
        factorized_nums = [num.factor() for num in numbers]
        factors_num = [num.as_coeff_Mul() for num in factorized_nums]
        term = factors_num[0][1]
        if all((factor == term for coeff, factor in factors_num)):
            common_term = term
            coeffs = [coeff for coeff, factor in factors_num]
            result = lcm_list(coeffs) * common_term
    elif all((num.is_rational for num in numbers)):
        result = lcm_list(numbers)
    else:
        pass
    return result

def is_convex(f, *syms, domain=S.Reals):
    if len(syms) > 1:
        return hessian(f, syms).is_positive_semidefinite
    from sympy.solvers.inequalities import solve_univariate_inequality
    f = _sympify(f)
    var = syms[0]
    if any((s in domain for s in singularities(f, var))):
        return False
    condition = f.diff(var, 2) < 0
    if solve_univariate_inequality(condition, var, False, domain):
        return False
    return True

def stationary_points(f, symbol, domain=S.Reals):
    from sympy.solvers.solveset import solveset
    if domain is S.EmptySet:
        return S.EmptySet
    domain = continuous_domain(f, symbol, domain)
    set = solveset(diff(f, symbol), symbol, domain)
    return set

def maximum(f, symbol, domain=S.Reals):
    if isinstance(symbol, Symbol):
        if domain is S.EmptySet:
            raise ValueError('Maximum value not defined for empty domain.')
        return function_range(f, symbol, domain).sup
    else:
        raise ValueError('%s is not a valid symbol.' % symbol)

def minimum(f, symbol, domain=S.Reals):
    if isinstance(symbol, Symbol):
        if domain is S.EmptySet:
            raise ValueError('Minimum value not defined for empty domain.')
        return function_range(f, symbol, domain).inf
    else:
        raise ValueError('%s is not a valid symbol.' % symbol)