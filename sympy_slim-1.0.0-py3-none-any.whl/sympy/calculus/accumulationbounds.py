from __future__ import annotations
from sympy.core import Add, Mul, Pow, S
from sympy.core.basic import Basic
from sympy.core.expr import Expr
from sympy.core.numbers import _sympifyit, oo, zoo
from sympy.core.relational import is_le, is_lt, is_ge, is_gt
from sympy.core.sympify import _sympify
from sympy.functions.elementary.miscellaneous import Min, Max
from sympy.logic.boolalg import And
from sympy.multipledispatch import dispatch
from sympy.series.order import Order
from sympy.sets.sets import FiniteSet

class AccumulationBounds(Expr):
    is_extended_real = True
    is_number = False

    def __new__(cls, min, max) -> Expr:
        min = _sympify(min)
        max = _sympify(max)
        if not min.is_extended_real or not max.is_extended_real:
            raise ValueError('Only real AccumulationBounds are supported')
        if max == min:
            return max
        if max.is_number and min.is_number:
            bad = max.is_comparable and min.is_comparable and (max < min)
        else:
            bad = (max - min).is_extended_negative
        if bad:
            raise ValueError('Lower limit should be smaller than upper limit')
        return Basic.__new__(cls, min, max)
    _op_priority = 11.0

    def _eval_is_real(self):
        if self.min.is_real and self.max.is_real:
            return True

    @property
    def min(self):
        return self.args[0]

    @property
    def max(self):
        return self.args[1]

    @property
    def delta(self):
        return self.max - self.min

    @property
    def mid(self):
        return (self.min + self.max) / 2

    @_sympifyit('other', NotImplemented)
    def _eval_power(self, other):
        return self.__pow__(other)

    @_sympifyit('other', NotImplemented)
    def __add__(self, other):
        if isinstance(other, Expr):
            if isinstance(other, AccumBounds):
                return AccumBounds(Add(self.min, other.min), Add(self.max, other.max))
            if other is S.Infinity and self.min is S.NegativeInfinity or (other is S.NegativeInfinity and self.max is S.Infinity):
                return AccumBounds(-oo, oo)
            elif other.is_extended_real:
                if self.min is S.NegativeInfinity and self.max is S.Infinity:
                    return AccumBounds(-oo, oo)
                elif self.min is S.NegativeInfinity:
                    return AccumBounds(-oo, self.max + other)
                elif self.max is S.Infinity:
                    return AccumBounds(self.min + other, oo)
                else:
                    return AccumBounds(Add(self.min, other), Add(self.max, other))
            return Add(self, other, evaluate=False)
        return NotImplemented
    __radd__ = __add__

    def __neg__(self):
        return AccumBounds(-self.max, -self.min)

    @_sympifyit('other', NotImplemented)
    def __sub__(self, other):
        if isinstance(other, Expr):
            if isinstance(other, AccumBounds):
                return AccumBounds(Add(self.min, -other.max), Add(self.max, -other.min))
            if other is S.NegativeInfinity and self.min is S.NegativeInfinity or (other is S.Infinity and self.max is S.Infinity):
                return AccumBounds(-oo, oo)
            elif other.is_extended_real:
                if self.min is S.NegativeInfinity and self.max is S.Infinity:
                    return AccumBounds(-oo, oo)
                elif self.min is S.NegativeInfinity:
                    return AccumBounds(-oo, self.max - other)
                elif self.max is S.Infinity:
                    return AccumBounds(self.min - other, oo)
                else:
                    return AccumBounds(Add(self.min, -other), Add(self.max, -other))
            return Add(self, -other, evaluate=False)
        return NotImplemented

    @_sympifyit('other', NotImplemented)
    def __rsub__(self, other):
        return self.__neg__() + other

    @_sympifyit('other', NotImplemented)
    def __mul__(self, other):
        if self.args == (-oo, oo):
            return self
        if isinstance(other, Expr):
            if isinstance(other, AccumBounds):
                if other.args == (-oo, oo):
                    return other
                v = set()
                for a in self.args:
                    vi = other * a
                    v.update(vi.args or (vi,))
                return AccumBounds(Min(*v), Max(*v))
            if other is S.Infinity:
                if self.min.is_zero:
                    return AccumBounds(0, oo)
                if self.max.is_zero:
                    return AccumBounds(-oo, 0)
            if other is S.NegativeInfinity:
                if self.min.is_zero:
                    return AccumBounds(-oo, 0)
                if self.max.is_zero:
                    return AccumBounds(0, oo)
            if other.is_extended_real:
                if other.is_zero:
                    if self.max is S.Infinity:
                        return AccumBounds(0, oo)
                    if self.min is S.NegativeInfinity:
                        return AccumBounds(-oo, 0)
                    return S.Zero
                if other.is_extended_positive:
                    return AccumBounds(Mul(self.min, other), Mul(self.max, other))
                elif other.is_extended_negative:
                    return AccumBounds(Mul(self.max, other), Mul(self.min, other))
            if isinstance(other, Order):
                return other
            return Mul(self, other, evaluate=False)
        return NotImplemented
    __rmul__ = __mul__

    @_sympifyit('other', NotImplemented)
    def __truediv__(self, other):
        if isinstance(other, Expr):
            if isinstance(other, AccumBounds):
                if other.min.is_positive or other.max.is_negative:
                    return self * AccumBounds(1 / other.max, 1 / other.min)
                if self.min.is_extended_nonpositive and self.max.is_extended_nonnegative and other.min.is_extended_nonpositive and other.max.is_extended_nonnegative:
                    if self.min.is_zero and other.min.is_zero:
                        return AccumBounds(0, oo)
                    if self.max.is_zero and other.min.is_zero:
                        return AccumBounds(-oo, 0)
                    return AccumBounds(-oo, oo)
                if self.max.is_extended_negative:
                    if other.min.is_extended_negative:
                        if other.max.is_zero:
                            return AccumBounds(self.max / other.min, oo)
                        if other.max.is_extended_positive:
                            return AccumBounds(-oo, oo)
                    if other.min.is_zero and other.max.is_extended_positive:
                        return AccumBounds(-oo, self.max / other.max)
                if self.min.is_extended_positive:
                    if other.min.is_extended_negative:
                        if other.max.is_zero:
                            return AccumBounds(-oo, self.min / other.min)
                        if other.max.is_extended_positive:
                            return AccumBounds(-oo, oo)
                    if other.min.is_zero and other.max.is_extended_positive:
                        return AccumBounds(self.min / other.max, oo)
            elif other.is_extended_real:
                if other in (S.Infinity, S.NegativeInfinity):
                    if self == AccumBounds(-oo, oo):
                        return AccumBounds(-oo, oo)
                    if self.max is S.Infinity:
                        return AccumBounds(Min(0, other), Max(0, other))
                    if self.min is S.NegativeInfinity:
                        return AccumBounds(Min(0, -other), Max(0, -other))
                if other.is_extended_positive:
                    return AccumBounds(self.min / other, self.max / other)
                elif other.is_extended_negative:
                    return AccumBounds(self.max / other, self.min / other)
            if 1 / other is S.ComplexInfinity:
                return Mul(self, 1 / other, evaluate=False)
            else:
                return Mul(self, 1 / other)
        return NotImplemented

    @_sympifyit('other', NotImplemented)
    def __rtruediv__(self, other):
        if isinstance(other, Expr):
            if other.is_extended_real:
                if other.is_zero:
                    return S.Zero
                if self.min.is_extended_nonpositive and self.max.is_extended_nonnegative:
                    if self.min.is_zero:
                        if other.is_extended_positive:
                            return AccumBounds(Mul(other, 1 / self.max), oo)
                        if other.is_extended_negative:
                            return AccumBounds(-oo, Mul(other, 1 / self.max))
                    if self.max.is_zero:
                        if other.is_extended_positive:
                            return AccumBounds(-oo, Mul(other, 1 / self.min))
                        if other.is_extended_negative:
                            return AccumBounds(Mul(other, 1 / self.min), oo)
                    return AccumBounds(-oo, oo)
                else:
                    return AccumBounds(Min(other / self.min, other / self.max), Max(other / self.min, other / self.max))
            return Mul(other, 1 / self, evaluate=False)
        else:
            return NotImplemented

    @_sympifyit('other', NotImplemented)
    def __pow__(self, other):
        if isinstance(other, Expr):
            if other is S.Infinity:
                if self.min.is_extended_nonnegative:
                    if self.max < 1:
                        return S.Zero
                    if self.min > 1:
                        return S.Infinity
                    return AccumBounds(0, oo)
                elif self.max.is_extended_negative:
                    if self.min > -1:
                        return S.Zero
                    if self.max < -1:
                        return zoo
                    return S.NaN
                else:
                    if self.min > -1:
                        if self.max < 1:
                            return S.Zero
                        return AccumBounds(0, oo)
                    return AccumBounds(-oo, oo)
            if other is S.NegativeInfinity:
                return (1 / self) ** oo
            if (self.max - self.min).is_nonnegative:
                if self.min.is_nonnegative:
                    if other.is_nonnegative:
                        return self.func(self.min ** other, self.max ** other)
            if other.is_zero:
                return S.One
            if other.is_Integer or other.is_integer:
                if self.min.is_extended_positive:
                    return AccumBounds(Min(self.min ** other, self.max ** other), Max(self.min ** other, self.max ** other))
                elif self.max.is_extended_negative:
                    return AccumBounds(Min(self.max ** other, self.min ** other), Max(self.max ** other, self.min ** other))
                if other % 2 == 0:
                    if other.is_extended_negative:
                        if self.min.is_zero:
                            return AccumBounds(self.max ** other, oo)
                        if self.max.is_zero:
                            return AccumBounds(self.min ** other, oo)
                        return (1 / self) ** (-other)
                    return AccumBounds(S.Zero, Max(self.min ** other, self.max ** other))
                elif other % 2 == 1:
                    if other.is_extended_negative:
                        if self.min.is_zero:
                            return AccumBounds(self.max ** other, oo)
                        if self.max.is_zero:
                            return AccumBounds(-oo, self.min ** other)
                        return (1 / self) ** (-other)
                    return AccumBounds(self.min ** other, self.max ** other)
            if (other.is_number or other.is_rational) and (self.min.is_extended_nonnegative or (other.is_extended_nonnegative and self.min.is_extended_nonnegative)):
                num, den = other.as_numer_denom()
                if num is S.One:
                    return AccumBounds(*[i ** (1 / den) for i in self.args])
                elif den is not S.One:
                    return (self ** num) ** (1 / den)
            if isinstance(other, AccumBounds):
                if self.min.is_extended_positive or (self.min.is_extended_nonnegative and other.min.is_extended_nonnegative):
                    p = [self ** i for i in other.args]
                    if not any((i.is_Pow for i in p)):
                        a = [j for i in p for j in i.args or (i,)]
                        try:
                            return self.func(min(a), max(a))
                        except TypeError:
                            pass
            return Pow(self, other, evaluate=False)
        return NotImplemented

    @_sympifyit('other', NotImplemented)
    def __rpow__(self, other):
        if other.is_real and other.is_extended_nonnegative and (self.max - self.min).is_extended_positive:
            if other is S.One:
                return S.One
            if other.is_extended_positive:
                a, b = [other ** i for i in self.args]
                if min(a, b) != a:
                    a, b = (b, a)
                return self.func(a, b)
            if other.is_zero:
                if self.min.is_zero:
                    return self.func(0, 1)
                if self.min.is_extended_positive:
                    return S.Zero
        return Pow(other, self, evaluate=False)

    def __abs__(self):
        if self.max.is_extended_negative:
            return self.__neg__()
        elif self.min.is_extended_negative:
            return AccumBounds(S.Zero, Max(abs(self.min), self.max))
        else:
            return self

    def __contains__(self, other):
        other = _sympify(other)
        if other in (S.Infinity, S.NegativeInfinity):
            if self.min is S.NegativeInfinity or self.max is S.Infinity:
                return True
            return False
        rv = And(self.min <= other, self.max >= other)
        if rv not in (True, False):
            raise TypeError('input failed to evaluate')
        return rv

    def intersection(self, other):
        if not isinstance(other, (AccumBounds, FiniteSet)):
            raise TypeError('Input must be AccumulationBounds or FiniteSet object')
        if isinstance(other, FiniteSet):
            fin_set = S.EmptySet
            for i in other:
                if i in self:
                    fin_set = fin_set + FiniteSet(i)
            return fin_set
        if self.max < other.min or self.min > other.max:
            return S.EmptySet
        if self.min <= other.min:
            if self.max <= other.max:
                return AccumBounds(other.min, self.max)
            if self.max > other.max:
                return other
        if other.min <= self.min:
            if other.max <= self.max:
                return AccumBounds(self.min, other.max)
            if other.max > self.max:
                return self

    def union(self, other):
        if not isinstance(other, AccumBounds):
            raise TypeError('Input must be AccumulationBounds object')
        return AccumBounds(Min(self.min, other.min), Max(self.max, other.max))

@dispatch(AccumulationBounds, AccumulationBounds)
def _eval_is_le(lhs, rhs):
    if is_le(lhs.max, rhs.min):
        return True
    if is_gt(lhs.min, rhs.max):
        return False

@dispatch(AccumulationBounds, Basic)
def _eval_is_le(lhs, rhs):
    if not rhs.is_extended_real:
        raise TypeError('Invalid comparison of %s %s' % (type(rhs), rhs))
    elif rhs.is_comparable:
        if is_le(lhs.max, rhs):
            return True
        if is_gt(lhs.min, rhs):
            return False

@dispatch(AccumulationBounds, AccumulationBounds)
def _eval_is_ge(lhs, rhs):
    if is_ge(lhs.min, rhs.max):
        return True
    if is_lt(lhs.max, rhs.min):
        return False

@dispatch(AccumulationBounds, Expr)
def _eval_is_ge(lhs, rhs):
    if not rhs.is_extended_real:
        raise TypeError('Invalid comparison of %s %s' % (type(rhs), rhs))
    elif rhs.is_comparable:
        if is_ge(lhs.min, rhs):
            return True
        if is_lt(lhs.max, rhs):
            return False

@dispatch(Expr, AccumulationBounds)
def _eval_is_ge(lhs, rhs):
    if not lhs.is_extended_real:
        raise TypeError('Invalid comparison of %s %s' % (type(lhs), lhs))
    elif lhs.is_comparable:
        if is_le(rhs.max, lhs):
            return True
        if is_gt(rhs.min, lhs):
            return False

@dispatch(AccumulationBounds, AccumulationBounds)
def _eval_is_ge(lhs, rhs):
    if is_ge(lhs.min, rhs.max):
        return True
    if is_lt(lhs.max, rhs.min):
        return False
AccumBounds = AccumulationBounds