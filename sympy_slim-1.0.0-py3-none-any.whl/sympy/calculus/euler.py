from __future__ import annotations
from itertools import combinations_with_replacement
from sympy.core.function import Derivative, Function, diff
from sympy.core.relational import Eq
from sympy.core.singleton import S
from sympy.core.symbol import Symbol
from sympy.core.sympify import sympify
from sympy.utilities.iterables import iterable

def euler_equations(L, funcs=(), vars=()):
    funcs = tuple(funcs) if iterable(funcs) else (funcs,)
    if not funcs:
        funcs = tuple(L.atoms(Function))
    else:
        for f in funcs:
            if not isinstance(f, Function):
                raise TypeError('Function expected, got: %s' % f)
    vars = tuple(vars) if iterable(vars) else (vars,)
    if not vars:
        vars = funcs[0].args
    else:
        vars = tuple((sympify(var) for var in vars))
    if not all((isinstance(v, Symbol) for v in vars)):
        raise TypeError('Variables are not symbols, got %s' % vars)
    for f in funcs:
        if not vars == f.args:
            raise ValueError('Variables %s do not match args: %s' % (vars, f))
    order = max([len(d.variables) for d in L.atoms(Derivative) if d.expr in funcs] + [0])
    eqns = []
    for f in funcs:
        eq = diff(L, f)
        for i in range(1, order + 1):
            for p in combinations_with_replacement(vars, i):
                eq = eq + S.NegativeOne ** i * diff(L, diff(f, *p), *p)
        new_eq = Eq(eq, 0)
        if isinstance(new_eq, Eq):
            eqns.append(new_eq)
    return eqns