from __future__ import annotations
from sympy.core.function import Derivative
from sympy.core.singleton import S
from sympy.core.function import Subs
from sympy.core.traversal import preorder_traversal
from sympy.utilities.exceptions import sympy_deprecation_warning
from sympy.utilities.iterables import iterable

def finite_diff_weights(order, x_list, x0=S.One):
    order = S(order)
    if not order.is_number:
        raise ValueError('Cannot handle symbolic order.')
    if order < 0:
        raise ValueError('Negative derivative order illegal.')
    if int(order) != order:
        raise ValueError('Non-integer order illegal')
    M = order
    N = len(x_list) - 1
    delta = [[[0 for nu in range(N + 1)] for n in range(N + 1)] for m in range(M + 1)]
    delta[0][0][0] = S.One
    c1 = S.One
    for n in range(1, N + 1):
        c2 = S.One
        for nu in range(n):
            c3 = x_list[n] - x_list[nu]
            c2 = c2 * c3
            if n <= M:
                delta[n][n - 1][nu] = 0
            for m in range(min(n, M) + 1):
                delta[m][n][nu] = (x_list[n] - x0) * delta[m][n - 1][nu] - m * delta[m - 1][n - 1][nu]
                delta[m][n][nu] /= c3
        for m in range(min(n, M) + 1):
            delta[m][n][n] = c1 / c2 * (m * delta[m - 1][n - 1][n - 1] - (x_list[n - 1] - x0) * delta[m][n - 1][n - 1])
        c1 = c2
    return delta

def apply_finite_diff(order, x_list, y_list, x0=S.Zero):
    N = len(x_list) - 1
    if len(x_list) != len(y_list):
        raise ValueError('x_list and y_list not equal in length.')
    delta = finite_diff_weights(order, x_list, x0)
    derivative = 0
    for nu in range(len(x_list)):
        derivative += delta[order][N][nu] * y_list[nu]
    return derivative

def _as_finite_diff(derivative, points=1, x0=None, wrt=None):
    if derivative.is_Derivative:
        pass
    elif derivative.is_Atom:
        return derivative
    else:
        return derivative.fromiter([_as_finite_diff(ar, points, x0, wrt) for ar in derivative.args], **derivative.assumptions0)
    if wrt is None:
        old = None
        for v in derivative.variables:
            if old is v:
                continue
            derivative = _as_finite_diff(derivative, points, x0, v)
            old = v
        return derivative
    order = derivative.variables.count(wrt)
    if x0 is None:
        x0 = wrt
    if not iterable(points):
        if getattr(points, 'is_Function', False) and wrt in points.args:
            points = points.subs(wrt, x0)
        if order % 2 == 0:
            points = [x0 + points * i for i in range(-order // 2, order // 2 + 1)]
        else:
            points = [x0 + points * S(i) / 2 for i in range(-order, order + 1, 2)]
    others = [wrt, 0]
    for v in set(derivative.variables):
        if v == wrt:
            continue
        others += [v, derivative.variables.count(v)]
    if len(points) < order + 1:
        raise ValueError('Too few points for order %d' % order)
    return apply_finite_diff(order, points, [Derivative(derivative.expr.subs({wrt: x}), *others) for x in points], x0)

def differentiate_finite(expr, *symbols, points=1, x0=None, wrt=None, evaluate=False):
    if any((term.is_Derivative for term in list(preorder_traversal(expr)))):
        evaluate = False
    Dexpr = expr.diff(*symbols, evaluate=evaluate)
    if evaluate:
        sympy_deprecation_warning('\n        The evaluate flag to differentiate_finite() is deprecated.\n\n        evaluate=True expands the intermediate derivatives before computing\n        differences, but this usually not what you want, as it does not\n        satisfy the product rule.\n        ', deprecated_since_version='1.5', active_deprecations_target='deprecated-differentiate_finite-evaluate')
        return Dexpr.replace(lambda arg: arg.is_Derivative, lambda arg: arg.as_finite_difference(points=points, x0=x0, wrt=wrt))
    else:
        DFexpr = Dexpr.as_finite_difference(points=points, x0=x0, wrt=wrt)
        return DFexpr.replace(lambda arg: isinstance(arg, Subs), lambda arg: arg.expr.as_finite_difference(points=points, x0=arg.point[0], wrt=arg.variables[0]))