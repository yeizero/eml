from __future__ import annotations

def pprint_nodes(subtrees):

    def indent(s, type=1):
        x = s.split('\n')
        r = '+-%s\n' % x[0]
        for a in x[1:]:
            if a == '':
                continue
            if type == 1:
                r += '| %s\n' % a
            else:
                r += '  %s\n' % a
        return r
    if not subtrees:
        return ''
    f = ''
    for a in subtrees[:-1]:
        f += indent(a)
    f += indent(subtrees[-1], 2)
    return f

def print_node(node, assumptions=True):
    s = '%s: %s\n' % (node.__class__.__name__, str(node))
    if assumptions:
        d = node._assumptions
    else:
        d = None
    if d:
        for a in sorted(d):
            v = d[a]
            if v is None:
                continue
            s += '%s: %s\n' % (a, v)
    return s

def tree(node, assumptions=True):
    subtrees = []
    for arg in node.args:
        subtrees.append(tree(arg, assumptions=assumptions))
    s = print_node(node, assumptions=assumptions) + pprint_nodes(subtrees)
    return s