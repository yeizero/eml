from __future__ import annotations
from sympy.core.basic import Basic
from sympy.core.expr import Expr
from sympy.core.symbol import Symbol
from sympy.core.numbers import Integer, Rational, Float
from sympy.printing.repr import srepr
__all__ = ['dotprint']
default_styles = ((Basic, {'color': 'blue', 'shape': 'ellipse'}), (Expr, {'color': 'black'}))
slotClasses = (Symbol, Integer, Rational, Float)

def purestr(x, with_args=False):
    sargs = ()
    if not isinstance(x, Basic):
        rv = str(x)
    elif not x.args:
        rv = srepr(x)
    else:
        args = x.args
        sargs = tuple(map(purestr, args))
        rv = '%s(%s)' % (type(x).__name__, ', '.join(sargs))
    if with_args:
        rv = (rv, sargs)
    return rv

def styleof(expr, styles=default_styles):
    style = {}
    for typ, sty in styles:
        if isinstance(expr, typ):
            style.update(sty)
    return style

def attrprint(d, delimiter=', '):
    return delimiter.join(('"%s"="%s"' % item for item in sorted(d.items())))

def dotnode(expr, styles=default_styles, labelfunc=str, pos=(), repeat=True):
    style = styleof(expr, styles)
    if isinstance(expr, Basic) and (not expr.is_Atom):
        label = str(expr.__class__.__name__)
    else:
        label = labelfunc(expr)
    style['label'] = label
    expr_str = purestr(expr)
    if repeat:
        expr_str += '_%s' % str(pos)
    return '"%s" [%s];' % (expr_str, attrprint(style))

def dotedges(expr, atom=lambda x: not isinstance(x, Basic), pos=(), repeat=True):
    if atom(expr):
        return []
    else:
        expr_str, arg_strs = purestr(expr, with_args=True)
        if repeat:
            expr_str += '_%s' % str(pos)
            arg_strs = ['%s_%s' % (a, str(pos + (i,))) for i, a in enumerate(arg_strs)]
        return ['"%s" -> "%s";' % (expr_str, a) for a in arg_strs]
template = 'digraph{\n\n# Graph style\n%(graphstyle)s\n\n#########\n# Nodes #\n#########\n\n%(nodes)s\n\n#########\n# Edges #\n#########\n\n%(edges)s\n}'
_graphstyle = {'rankdir': 'TD', 'ordering': 'out'}

def dotprint(expr, styles=None, atom=lambda x: not isinstance(x, Basic), maxdepth=None, repeat=True, labelfunc=str, **kwargs):
    if styles is None:
        styles = default_styles
    graphstyle = _graphstyle.copy()
    graphstyle.update(kwargs)
    nodes = []
    edges = []

    def traverse(e, depth, pos=()):
        nodes.append(dotnode(e, styles, labelfunc=labelfunc, pos=pos, repeat=repeat))
        if maxdepth and depth >= maxdepth:
            return
        edges.extend(dotedges(e, atom=atom, pos=pos, repeat=repeat))
        [traverse(arg, depth + 1, pos + (i,)) for i, arg in enumerate(e.args) if not atom(arg)]
    traverse(expr, 0)
    return template % {'graphstyle': attrprint(graphstyle, delimiter='\n'), 'nodes': '\n'.join(nodes), 'edges': '\n'.join(edges)}