from __future__ import annotations
import re
from collections.abc import Iterable
from sympy.core.function import Derivative
_name_with_digits_p = re.compile('^([^\\W\\d_]+)(\\d+)$', re.UNICODE)

def split_super_sub(text):
    if not text:
        return (text, [], [])
    pos = 0
    name = None
    supers = []
    subs = []
    while pos < len(text):
        start = pos + 1
        if text[pos:pos + 2] == '__':
            start += 1
        pos_hat = text.find('^', start)
        if pos_hat < 0:
            pos_hat = len(text)
        pos_usc = text.find('_', start)
        if pos_usc < 0:
            pos_usc = len(text)
        pos_next = min(pos_hat, pos_usc)
        part = text[pos:pos_next]
        pos = pos_next
        if name is None:
            name = part
        elif part.startswith('^'):
            supers.append(part[1:])
        elif part.startswith('__'):
            supers.append(part[2:])
        elif part.startswith('_'):
            subs.append(part[1:])
        else:
            raise RuntimeError('This should never happen.')
    m = _name_with_digits_p.match(name)
    if m:
        name, sub = m.groups()
        subs.insert(0, sub)
    return (name, supers, subs)

def requires_partial(expr):
    if isinstance(expr, Derivative):
        return requires_partial(expr.expr)
    if not isinstance(expr.free_symbols, Iterable):
        return len(set(expr.variables)) > 1
    return sum((not s.is_integer for s in expr.free_symbols)) > 1