from __future__ import annotations
from sympy.core._print_helpers import Printable
Printable.__module__ = __name__
DefaultPrinting = Printable