from __future__ import annotations
from typing import TYPE_CHECKING, overload
from sympy.core.numbers import Rational
from sympy.core.singleton import S
from sympy.core.relational import is_eq
from sympy.external.mpmath import prec_to_dps
from sympy.functions.elementary.complexes import conjugate, im, re, sign
from sympy.functions.elementary.exponential import exp, log as ln
from sympy.functions.elementary.miscellaneous import sqrt
from sympy.functions.elementary.trigonometric import acos, asin, atan2
from sympy.functions.elementary.trigonometric import cos, sin
from sympy.simplify.trigsimp import trigsimp
from sympy.integrals.integrals import integrate
from sympy.matrices.dense import MutableDenseMatrix as Matrix
from sympy.core.expr import Expr
from sympy.core.sympify import sympify, _sympify
from sympy.core.logic import fuzzy_not, fuzzy_or
from sympy.utilities.misc import as_int

def _check_norm(elements: Iterable[Expr], norm: Expr | None) -> None:
    if norm is not None and norm.is_number:
        if norm.is_positive is False:
            raise ValueError('Input norm must be positive.')
        numerical = all((i.is_number and i.is_real is True for i in elements))
        if numerical and is_eq(norm ** 2, sum((i ** 2 for i in elements), S.Zero)) is False:
            raise ValueError('Incompatible value for norm.')

def _is_extrinsic(seq: str) -> bool:
    if type(seq) != str:
        raise ValueError('Expected seq to be a string.')
    if len(seq) != 3:
        raise ValueError('Expected 3 axes, got `{}`.'.format(seq))
    intrinsic = seq.isupper()
    extrinsic = seq.islower()
    if not (intrinsic or extrinsic):
        raise ValueError('seq must either be fully uppercase (for extrinsic rotations), or fully lowercase, for intrinsic rotations).')
    i, j, k = list(seq.lower())
    if i == j or j == k:
        raise ValueError('Consecutive axes must be different')
    bad = set(seq) - set('xyzXYZ')
    if bad:
        raise ValueError("Expected axes from `seq` to be from ['x', 'y', 'z'] or ['X', 'Y', 'Z'], got {}".format(''.join(bad)))
    return extrinsic

class Quaternion(Expr):
    _op_priority = 11.0
    is_commutative = False

    def __new__(cls, a: SExpr=0, b: SExpr=0, c: SExpr=0, d: SExpr=0, real_field: bool=True, norm: SExpr | None=None) -> Quaternion:
        a, b, c, d = map(sympify, (a, b, c, d))
        if any((i.is_commutative is False for i in [a, b, c, d])):
            raise ValueError('arguments have to be commutative')
        obj = super().__new__(cls, a, b, c, d)
        obj._real_field = real_field
        obj.set_norm(norm)
        return obj

    def set_norm(self, norm: SExpr | None) -> None:
        if norm is not None:
            norm = sympify(norm)
        _check_norm(self.args, norm)
        self._norm = norm

    @property
    def a(self) -> Expr:
        return self.args[0]

    @property
    def b(self) -> Expr:
        return self.args[1]

    @property
    def c(self) -> Expr:
        return self.args[2]

    @property
    def d(self) -> Expr:
        return self.args[3]

    @property
    def real_field(self) -> bool:
        return self._real_field

    @property
    def product_matrix_left(self) -> Matrix:
        return Matrix([[self.a, -self.b, -self.c, -self.d], [self.b, self.a, -self.d, self.c], [self.c, self.d, self.a, -self.b], [self.d, -self.c, self.b, self.a]])

    @property
    def product_matrix_right(self) -> Matrix:
        return Matrix([[self.a, -self.b, -self.c, -self.d], [self.b, self.a, self.d, -self.c], [self.c, -self.d, self.a, self.b], [self.d, self.c, -self.b, self.a]])

    def to_Matrix(self, vector_only: bool=False) -> Matrix:
        if vector_only:
            return Matrix(self.args[1:])
        else:
            return Matrix(self.args)

    @classmethod
    def from_Matrix(cls, elements: Matrix | Sequence[SExpr]) -> Quaternion:
        if isinstance(elements, Matrix):
            elements_list = elements.flat()
        else:
            elements_list = elements
        length = len(elements_list)
        if length == 3:
            e1, e2, e3 = elements_list
            return Quaternion(0, e1, e2, e3)
        elif length == 4:
            e1, e2, e3, e4 = elements_list
            return Quaternion(e1, e2, e3, e4)
        else:
            raise ValueError('Input elements must have length 3 or 4, got {} elements'.format(length))

    @classmethod
    def from_euler(cls, angles: Sequence[SExpr], seq: str) -> Quaternion:
        if len(angles) != 3:
            raise ValueError('3 angles must be given.')
        extrinsic = _is_extrinsic(seq)
        i, j, k = list(seq.lower())
        e = {'x': (1, 0, 0), 'y': (0, 1, 0), 'z': (0, 0, 1)}
        qi = cls.from_axis_angle(e[i], angles[0])
        qj = cls.from_axis_angle(e[j], angles[1])
        qk = cls.from_axis_angle(e[k], angles[2])
        if extrinsic:
            return trigsimp(qk * qj * qi)
        else:
            return trigsimp(qi * qj * qk)

    def to_euler(self, seq: str, angle_addition: bool=True, avoid_square_root: bool=False) -> tuple[Expr, Expr, Expr]:
        if self.is_zero_quaternion():
            raise ValueError('Cannot convert a quaternion with norm 0.')
        extrinsic = _is_extrinsic(seq)
        i1, j1, k1 = list(seq.lower())
        i = 'xyz'.index(i1) + 1
        j = 'xyz'.index(j1) + 1
        k = 'xyz'.index(k1) + 1
        if not extrinsic:
            i, k = (k, i)
        symmetric = i == k
        if symmetric:
            k = 6 - i - j
        sign = (i - j) * (j - k) * (k - i) // 2
        elements = [self.a, self.b, self.c, self.d]
        a = elements[0]
        b = elements[i]
        c = elements[j]
        d = elements[k] * sign
        if not symmetric:
            a, b, c, d = (a - c, b + d, c + a, d - b)
        if avoid_square_root:
            if symmetric:
                n2 = self.norm() ** 2
                angles1 = acos((a * a + b * b - c * c - d * d) / n2)
            else:
                n2 = 2 * self.norm() ** 2
                angles1 = asin((c * c + d * d - a * a - b * b) / n2)
        else:
            angles1 = 2 * atan2(sqrt(c * c + d * d), sqrt(a * a + b * b))
            if not symmetric:
                angles1 -= S.Pi / 2
        case = 0
        if is_eq(c, S.Zero) and is_eq(d, S.Zero):
            case = 1
        if is_eq(a, S.Zero) and is_eq(b, S.Zero):
            case = 2
        if case == 0:
            if angle_addition:
                angles0 = atan2(b, a) + atan2(d, c)
                angles2 = atan2(b, a) - atan2(d, c)
            else:
                angles0 = atan2(b * c + a * d, a * c - b * d)
                angles2 = atan2(b * c - a * d, a * c + b * d)
        elif case == 1:
            if extrinsic:
                angles0 = S.Zero
                angles2 = 2 * atan2(b, a)
            else:
                angles0 = 2 * atan2(b, a)
                angles2 = S.Zero
        elif extrinsic:
            angles0 = S.Zero
            angles2 = -2 * atan2(d, c)
        else:
            angles0 = 2 * atan2(d, c)
            angles2 = S.Zero
        if not symmetric:
            angles0 *= sign
        if extrinsic:
            return (angles2, angles1, angles0)
        else:
            return (angles0, angles1, angles2)

    @classmethod
    def from_axis_angle(cls, vector: tuple[SExpr, SExpr, SExpr], angle: SExpr) -> Quaternion:
        x, y, z = vector
        norm = sqrt(x ** 2 + y ** 2 + z ** 2)
        x, y, z = (x / norm, y / norm, z / norm)
        s = sin(angle * S.Half)
        a = cos(angle * S.Half)
        b = x * s
        c = y * s
        d = z * s
        return cls(a, b, c, d)

    @classmethod
    def from_rotation_matrix(cls, M):
        absQ = M.det() ** Rational(1, 3)
        a = sqrt(absQ + M[0, 0] + M[1, 1] + M[2, 2]) / 2
        b = sqrt(absQ + M[0, 0] - M[1, 1] - M[2, 2]) / 2
        c = sqrt(absQ - M[0, 0] + M[1, 1] - M[2, 2]) / 2
        d = sqrt(absQ - M[0, 0] - M[1, 1] + M[2, 2]) / 2
        b = b * sign(M[2, 1] - M[1, 2])
        c = c * sign(M[0, 2] - M[2, 0])
        d = d * sign(M[1, 0] - M[0, 1])
        return Quaternion(a, b, c, d)

    def __add__(self, other: SExpr | Quaternion) -> Quaternion:
        return self.add(other)

    def __radd__(self, other: SExpr) -> Quaternion:
        return self.add(other)

    def __sub__(self, other: SExpr | Quaternion) -> Quaternion:
        return self.add(other * -1)

    def __mul__(self, other: SExpr | Quaternion) -> Quaternion:
        return self._generic_mul(self, _sympify(other))

    def __rmul__(self, other: SExpr) -> Quaternion:
        return self._generic_mul(_sympify(other), self)

    def __pow__(self, p: int, mod: None=None) -> Quaternion:
        return self.pow(p)

    def __neg__(self) -> Quaternion:
        return Quaternion(-self.a, -self.b, -self.c, -self.d)

    def __truediv__(self, other: SExpr | Quaternion) -> Quaternion:
        return self * sympify(other) ** (-1)

    def __rtruediv__(self, other: SExpr) -> Quaternion:
        return sympify(other) * self ** (-1)

    def _eval_Integral(self, *args) -> Quaternion:
        return self.integrate(*args)

    def diff(self, *symbols, **kwargs):
        kwargs.setdefault('evaluate', True)
        a, b, c, d = [arg.diff(*symbols, **kwargs) for arg in self.args]
        return self.func(a, b, c, d)

    def add(self, other: SExpr | Quaternion) -> Quaternion:
        q1 = self
        q2 = sympify(other)
        if not isinstance(q2, Quaternion):
            if q1.real_field and q2.is_complex:
                return Quaternion(re(q2) + q1.a, im(q2) + q1.b, q1.c, q1.d)
            elif q2.is_commutative:
                return Quaternion(q1.a + q2, q1.b, q1.c, q1.d)
            else:
                raise ValueError('Only commutative expressions can be added with a Quaternion.')
        return Quaternion(q1.a + q2.a, q1.b + q2.b, q1.c + q2.c, q1.d + q2.d)

    def mul(self, other: SExpr | Quaternion) -> Quaternion:
        return self._generic_mul(self, _sympify(other))

    @overload
    @staticmethod
    def _generic_mul(q1: Quaternion, q2: Expr) -> Quaternion:
        pass

    @overload
    @staticmethod
    def _generic_mul(q1: Expr, q2: Quaternion) -> Quaternion:
        pass

    @overload
    @staticmethod
    def _generic_mul(q1: Expr, q2: Expr) -> Expr:
        pass

    @staticmethod
    def _generic_mul(q1: Quaternion | Expr, q2: Quaternion | Expr) -> Quaternion | Expr:
        if isinstance(q1, Quaternion) and isinstance(q2, Quaternion):
            if q1._norm is None and q2._norm is None:
                norm = None
            else:
                norm = q1.norm() * q2.norm()
            return Quaternion(-q1.b * q2.b - q1.c * q2.c - q1.d * q2.d + q1.a * q2.a, q1.b * q2.a + q1.c * q2.d - q1.d * q2.c + q1.a * q2.b, -q1.b * q2.d + q1.c * q2.a + q1.d * q2.b + q1.a * q2.c, q1.b * q2.c - q1.c * q2.b + q1.d * q2.a + q1.a * q2.d, norm=norm)
        elif isinstance(q2, Quaternion):
            if q2.real_field and q1.is_complex:
                return Quaternion(re(q1), im(q1), 0, 0) * q2
            elif q1.is_commutative:
                return Quaternion(q1 * q2.a, q1 * q2.b, q1 * q2.c, q1 * q2.d)
            else:
                raise ValueError('Only commutative expressions can be multiplied with a Quaternion.')
        elif isinstance(q1, Quaternion):
            if q1.real_field and q2.is_complex:
                return q1 * Quaternion(re(q2), im(q2), 0, 0)
            elif q2.is_commutative:
                return Quaternion(q2 * q1.a, q2 * q1.b, q2 * q1.c, q2 * q1.d)
            else:
                raise ValueError('Only commutative expressions can be multiplied with a Quaternion.')
        else:
            return q1 * q2

    def _eval_conjugate(self) -> Quaternion:
        q = self
        return Quaternion(q.a, -q.b, -q.c, -q.d, norm=q._norm)

    def norm(self) -> Expr:
        if self._norm is None:
            q = self
            return sqrt(trigsimp(q.a ** 2 + q.b ** 2 + q.c ** 2 + q.d ** 2))
        return self._norm

    def normalize(self) -> Quaternion:
        q = self
        return q * (1 / q.norm())

    def inverse(self) -> Quaternion:
        q = self
        if not q.norm():
            raise ValueError('Cannot compute inverse for a quaternion with zero norm')
        return conjugate(q) * (1 / q.norm() ** 2)

    def pow(self, p: int) -> Quaternion:
        try:
            q, p = (self, as_int(p))
        except ValueError:
            return NotImplemented
        if p < 0:
            q, p = (q.inverse(), -p)
        if p == 1:
            return q
        res = Quaternion(1, 0, 0, 0)
        while p > 0:
            if p & 1:
                res *= q
            q *= q
            p >>= 1
        return res

    def exp(self) -> Quaternion:
        q = self
        vector_norm = sqrt(q.b ** 2 + q.c ** 2 + q.d ** 2)
        a = exp(q.a) * cos(vector_norm)
        b = exp(q.a) * sin(vector_norm) * q.b / vector_norm
        c = exp(q.a) * sin(vector_norm) * q.c / vector_norm
        d = exp(q.a) * sin(vector_norm) * q.d / vector_norm
        return Quaternion(a, b, c, d)

    def log(self):
        q = self
        vector_norm = sqrt(q.b ** 2 + q.c ** 2 + q.d ** 2)
        q_norm = q.norm()
        if q_norm.is_zero:
            raise ValueError('Cannot compute logarithm for a zero quaternion')
        a = ln(q_norm)
        if vector_norm.is_zero:
            return Quaternion(a, 0, 0, 0)
        angle_over_norm = acos(q.a / q_norm) / vector_norm
        b = q.b * angle_over_norm
        c = q.c * angle_over_norm
        d = q.d * angle_over_norm
        return Quaternion(a, b, c, d)

    def _eval_subs(self, old: Expr, new: Expr) -> Quaternion:
        e1, e2, e3, e4 = [i.subs(old, new) for i in self.args]
        norm = self._norm
        if norm is not None:
            norm = norm.subs(old, new)
        elements = (e1, e2, e3, e4)
        _check_norm(elements, norm)
        return Quaternion(*elements, norm=norm)

    def _eval_evalf(self, prec: int) -> Quaternion:
        nprec = prec_to_dps(prec)
        a, b, c, d = [arg.evalf(n=nprec) for arg in self.args]
        return Quaternion(a, b, c, d)

    def pow_cos_sin(self, p: int) -> Quaternion:
        q = self
        v, angle = q.to_axis_angle()
        q2 = Quaternion.from_axis_angle(v, p * angle)
        return q2 * q.norm() ** p

    def integrate(self, *symbols: SymbolLimits) -> Quaternion:
        return Quaternion(integrate(self.a, *symbols), integrate(self.b, *symbols), integrate(self.c, *symbols), integrate(self.d, *symbols))

    @staticmethod
    def rotate_point(pin: tuple[SExpr, SExpr, SExpr], r: Quaternion | tuple[tuple[SExpr, SExpr, SExpr], SExpr]) -> tuple[Expr, Expr, Expr]:
        if isinstance(r, tuple):
            q = Quaternion.from_axis_angle(r[0], r[1])
        else:
            q = r.normalize()
        pout = q * Quaternion(0, pin[0], pin[1], pin[2]) * conjugate(q)
        return (pout.b, pout.c, pout.d)

    def to_axis_angle(self) -> tuple[tuple[Expr, Expr, Expr], Expr]:
        q = self
        if q.a.is_negative:
            q = q * -1
        q = q.normalize()
        angle = trigsimp(2 * acos(q.a))
        s = sqrt(1 - q.a * q.a)
        x = trigsimp(q.b / s)
        y = trigsimp(q.c / s)
        z = trigsimp(q.d / s)
        v = (x, y, z)
        t = (v, angle)
        return t

    def to_rotation_matrix(self, v: tuple[SExpr, SExpr, SExpr] | None=None, homogeneous: bool=True) -> Matrix:
        q = self
        s = q.norm() ** (-2)
        if homogeneous:
            m00 = s * (q.a ** 2 + q.b ** 2 - q.c ** 2 - q.d ** 2)
            m11 = s * (q.a ** 2 - q.b ** 2 + q.c ** 2 - q.d ** 2)
            m22 = s * (q.a ** 2 - q.b ** 2 - q.c ** 2 + q.d ** 2)
        else:
            m00 = 1 - 2 * s * (q.c ** 2 + q.d ** 2)
            m11 = 1 - 2 * s * (q.b ** 2 + q.d ** 2)
            m22 = 1 - 2 * s * (q.b ** 2 + q.c ** 2)
        m01 = 2 * s * (q.b * q.c - q.d * q.a)
        m02 = 2 * s * (q.b * q.d + q.c * q.a)
        m10 = 2 * s * (q.b * q.c + q.d * q.a)
        m12 = 2 * s * (q.c * q.d - q.b * q.a)
        m20 = 2 * s * (q.b * q.d - q.c * q.a)
        m21 = 2 * s * (q.c * q.d + q.b * q.a)
        if not v:
            return Matrix([[m00, m01, m02], [m10, m11, m12], [m20, m21, m22]])
        else:
            x, y, z = v
            m03 = x - x * m00 - y * m01 - z * m02
            m13 = y - x * m10 - y * m11 - z * m12
            m23 = z - x * m20 - y * m21 - z * m22
            m30 = m31 = m32 = 0
            m33 = 1
            return Matrix([[m00, m01, m02, m03], [m10, m11, m12, m13], [m20, m21, m22, m23], [m30, m31, m32, m33]])

    def scalar_part(self) -> Expr:
        return self.a

    def vector_part(self) -> Quaternion:
        return Quaternion(0, self.b, self.c, self.d)

    def axis(self) -> Quaternion:
        axis = self.vector_part().normalize()
        return Quaternion(0, axis.b, axis.c, axis.d)

    def is_pure(self) -> bool | None:
        return self.a.is_zero

    def is_zero_quaternion(self) -> bool | None:
        return self.norm().is_zero

    def angle(self) -> Expr:
        return 2 * atan2(self.vector_part().norm(), self.scalar_part())

    def arc_coplanar(self, other: Quaternion) -> bool | None:
        if self.is_zero_quaternion() or other.is_zero_quaternion():
            raise ValueError('Neither of the given quaternions can be 0')
        return fuzzy_or([(self.axis() - other.axis()).is_zero_quaternion(), (self.axis() + other.axis()).is_zero_quaternion()])

    @classmethod
    def vector_coplanar(cls, q1: Quaternion, q2: Quaternion, q3: Quaternion) -> bool | None:
        if fuzzy_not(q1.is_pure()) or fuzzy_not(q2.is_pure()) or fuzzy_not(q3.is_pure()):
            raise ValueError('The given quaternions must be pure')
        M = Matrix([[q1.b, q1.c, q1.d], [q2.b, q2.c, q2.d], [q3.b, q3.c, q3.d]]).det()
        return M.is_zero

    def parallel(self, other) -> bool | None:
        if fuzzy_not(self.is_pure()) or fuzzy_not(other.is_pure()):
            raise ValueError('The provided quaternions must be pure')
        return (self * other - other * self).is_zero_quaternion()

    def orthogonal(self, other: Quaternion) -> bool | None:
        if fuzzy_not(self.is_pure()) or fuzzy_not(other.is_pure()):
            raise ValueError('The given quaternions must be pure')
        return (self * other + other * self).is_zero_quaternion()

    def index_vector(self) -> Quaternion:
        return self.norm() * self.axis()

    def mensor(self) -> Expr:
        return ln(self.norm())