from __future__ import annotations
from sympy.core import Symbol
from sympy.logic.boolalg import And, Or
import re
from pathlib import Path

def load(s):
    clauses = []
    lines = s.split('\n')
    pComment = re.compile('c.*')
    pStats = re.compile('p\\s*cnf\\s*(\\d*)\\s*(\\d*)')
    while len(lines) > 0:
        line = lines.pop(0)
        if not pComment.match(line):
            m = pStats.match(line)
            if not m:
                nums = line.rstrip('\n').split(' ')
                list = []
                for lit in nums:
                    if lit != '':
                        if int(lit) == 0:
                            continue
                        num = abs(int(lit))
                        sign = True
                        if int(lit) < 0:
                            sign = False
                        if sign:
                            list.append(Symbol('cnf_%s' % num))
                        else:
                            list.append(~Symbol('cnf_%s' % num))
                if len(list) > 0:
                    clauses.append(Or(*list))
    return And(*clauses)

def load_file(location):
    s = Path(location).read_text()
    return load(s)