from __future__ import annotations
from sympy.logic.boolalg import And, Not, conjuncts, to_cnf, BooleanFunction
from sympy.core.sorting import ordered
from sympy.core.sympify import sympify
from sympy.external.importtools import import_module

def literal_symbol(literal):
    if literal is True or literal is False or literal.is_Symbol:
        return literal
    elif literal.is_Not:
        return literal_symbol(literal.args[0])
    else:
        raise ValueError('Argument must be a boolean literal.')

def satisfiable(expr, algorithm=None, all_models=False, minimal=False, use_lra_theory=False):
    if use_lra_theory:
        if algorithm is not None and algorithm != 'dpll2':
            raise ValueError(f'Currently only dpll2 can handle using lra theory. {algorithm} is not handled.')
        algorithm = 'dpll2'
    if algorithm is None or algorithm == 'pycosat':
        pycosat = import_module('pycosat')
        if pycosat is not None:
            algorithm = 'pycosat'
        else:
            if algorithm == 'pycosat':
                raise ImportError('pycosat module is not present')
            algorithm = 'dpll2'
    if algorithm == 'minisat22':
        pysat = import_module('pysat')
        if pysat is None:
            algorithm = 'dpll2'
    if algorithm == 'z3':
        z3 = import_module('z3')
        if z3 is None:
            algorithm = 'dpll2'
    if algorithm == 'dpll':
        from sympy.logic.algorithms.dpll import dpll_satisfiable
        return dpll_satisfiable(expr)
    elif algorithm == 'dpll2':
        from sympy.logic.algorithms.dpll2 import dpll_satisfiable
        return dpll_satisfiable(expr, all_models, use_lra_theory=use_lra_theory)
    elif algorithm == 'pycosat':
        from sympy.logic.algorithms.pycosat_wrapper import pycosat_satisfiable
        return pycosat_satisfiable(expr, all_models)
    elif algorithm == 'minisat22':
        from sympy.logic.algorithms.minisat22_wrapper import minisat22_satisfiable
        return minisat22_satisfiable(expr, all_models, minimal)
    elif algorithm == 'z3':
        from sympy.logic.algorithms.z3_wrapper import z3_satisfiable
        return z3_satisfiable(expr, all_models)
    raise NotImplementedError

def valid(expr):
    return not satisfiable(Not(expr))

def pl_true(expr, model=None, deep=False):
    from sympy.core.symbol import Symbol
    boolean = (True, False)

    def _validate(expr):
        if isinstance(expr, Symbol) or expr in boolean:
            return True
        if not isinstance(expr, BooleanFunction):
            return False
        return all((_validate(arg) for arg in expr.args))
    if expr in boolean:
        return expr
    expr = sympify(expr)
    if not _validate(expr):
        raise ValueError('%s is not a valid boolean expression' % expr)
    if not model:
        model = {}
    model = {k: v for k, v in model.items() if v in boolean}
    result = expr.subs(model)
    if result in boolean:
        return bool(result)
    if deep:
        model = dict.fromkeys(result.atoms(), True)
        if pl_true(result, model):
            if valid(result):
                return True
        elif not satisfiable(result):
            return False
    return None

def entails(expr, formula_set=None):
    if formula_set:
        formula_set = list(formula_set)
    else:
        formula_set = []
    formula_set.append(Not(expr))
    return not satisfiable(And(*formula_set))

class KB:

    def __init__(self, sentence=None):
        self.clauses_ = set()
        if sentence:
            self.tell(sentence)

    def tell(self, sentence):
        raise NotImplementedError

    def ask(self, query):
        raise NotImplementedError

    def retract(self, sentence):
        raise NotImplementedError

    @property
    def clauses(self):
        return list(ordered(self.clauses_))

class PropKB(KB):

    def tell(self, sentence):
        for c in conjuncts(to_cnf(sentence)):
            self.clauses_.add(c)

    def ask(self, query):
        return entails(query, self.clauses_)

    def retract(self, sentence):
        for c in conjuncts(to_cnf(sentence)):
            self.clauses_.discard(c)