from __future__ import annotations
from typing import TYPE_CHECKING, overload, Any
from collections import defaultdict
from itertools import chain, combinations, product, permutations
from sympy.core.add import Add
from sympy.core.basic import Basic
from sympy.core.cache import cacheit
from sympy.core.containers import Tuple
from sympy.core.decorators import sympify_method_args, sympify_return
from sympy.core.function import Application, Derivative
from sympy.core.kind import BooleanKind, NumberKind
from sympy.core.numbers import Number
from sympy.core.operations import AssocOp, LatticeOp
from sympy.core.parameters import global_parameters
from sympy.core.singleton import Singleton, S
from sympy.core.sorting import ordered
from sympy.core.sympify import _sympy_converter, _sympify, sympify
from sympy.utilities.iterables import sift, ibin
from sympy.utilities.misc import filldedent
if TYPE_CHECKING:
    from collections.abc import Iterable
    from sympy.core.basic import _SupportsItems

def as_Boolean(e):
    from sympy.core.symbol import Symbol
    if e == True:
        return true
    if e == False:
        return false
    if isinstance(e, Symbol):
        z = e.is_zero
        if z is None:
            return e
        return false if z else true
    if isinstance(e, Boolean):
        return e
    raise TypeError('expecting bool or Boolean, not `%s`.' % e)

@sympify_method_args
class Boolean(Basic):
    __slots__ = ()
    kind = BooleanKind
    if TYPE_CHECKING:
        from sympy.sets.sets import Set

        def __new__(cls, *args: Basic | complex) -> Boolean:
            pass

        @overload
        def subs(self, arg1: _SupportsItems[Basic | complex, Boolean | complex] | Iterable[tuple[Basic | complex, Boolean | complex]], arg2: None=None, **kwargs: Any) -> Boolean:
            pass

        @overload
        def subs(self, arg1: Boolean | complex, arg2: Boolean | complex) -> Boolean:
            pass

        @overload
        def subs(self, arg1: _SupportsItems[Basic | complex, Basic | complex] | Iterable[tuple[Basic | complex, Basic | complex]], arg2: None=None, **kwargs: Any) -> Basic:
            pass

        @overload
        def subs(self, arg1: Basic | complex, arg2: Basic | complex, **kwargs: Any) -> Basic:
            pass

        def subs(self, arg1: _SupportsItems[Basic | complex, Basic | complex] | Basic | complex, arg2: Basic | complex | None=None, **kwargs: Any) -> Basic:
            pass

        def simplify(self, **kwargs) -> Boolean:
            pass

    @sympify_return([('other', 'Boolean')], NotImplemented)
    def __and__(self, other: Boolean | bool) -> Boolean:
        return And(self, other)
    __rand__ = __and__

    @sympify_return([('other', 'Boolean')], NotImplemented)
    def __or__(self, other: Boolean | bool) -> Boolean:
        return Or(self, other)
    __ror__ = __or__

    def __invert__(self) -> Boolean:
        return Not(self)

    @sympify_return([('other', 'Boolean')], NotImplemented)
    def __rshift__(self, other: Boolean | bool) -> Boolean:
        return Implies(self, other)

    @sympify_return([('other', 'Boolean')], NotImplemented)
    def __lshift__(self, other: Boolean | bool) -> Boolean:
        return Implies(other, self)
    __rrshift__ = __lshift__
    __rlshift__ = __rshift__

    @sympify_return([('other', 'Boolean')], NotImplemented)
    def __xor__(self, other: Boolean | bool) -> Boolean:
        return Xor(self, other)
    __rxor__ = __xor__

    def equals(self, other):
        from sympy.logic.inference import satisfiable
        from sympy.core.relational import Relational
        if self.has(Relational) or other.has(Relational):
            raise NotImplementedError('handling of relationals')
        return self.atoms() == other.atoms() and (not satisfiable(Not(Equivalent(self, other))))

    def to_nnf(self, simplify=True, form=None):
        return self

    def as_set(self) -> Set:
        from sympy.calculus.util import periodicity
        from sympy.core.relational import Relational
        free = self.free_symbols
        if len(free) == 1:
            x = free.pop()
            if x.kind is NumberKind:
                reps = {}
                for r in self.atoms(Relational):
                    if periodicity(r, x) not in (0, None):
                        s = r._eval_as_set()
                        if s in (S.EmptySet, S.UniversalSet, S.Reals):
                            reps[r] = s.as_relational(x)
                            continue
                        raise NotImplementedError(filldedent('\n                            as_set is not implemented for relationals\n                            with periodic solutions\n                            '))
                new = self.subs(reps)
                if new.func != self.func:
                    return new.as_set()
                else:
                    return new._eval_as_set()
            return self._eval_as_set()
        else:
            raise NotImplementedError('Sorry, as_set has not yet been implemented for multivariate expressions')

    @property
    def binary_symbols(self) -> set[Basic]:
        from sympy.core.symbol import Symbol
        return set().union(*[i.binary_symbols for i in self.args if isinstance(i, (Boolean, Symbol))])

    def _eval_refine(self, assumptions) -> Boolean | None:
        from sympy.assumptions import ask
        ret = ask(self, assumptions)
        if ret is True:
            return true
        elif ret is False:
            return false
        return None

    def _eval_as_set(self) -> Set:
        raise NotImplementedError('Subclasses of Boolean should implement this')

class BooleanAtom(Boolean):
    is_Boolean = True
    is_Atom = True
    _op_priority = 11

    def simplify(self, *a, **kw):
        return self

    def expand(self, *a, **kw):
        return self

    @property
    def canonical(self):
        return self

    def _noop(self, other=None):
        raise TypeError('BooleanAtom not allowed in this context.')
    __add__ = _noop
    __radd__ = _noop
    __sub__ = _noop
    __rsub__ = _noop
    __mul__ = _noop
    __rmul__ = _noop
    __pow__ = _noop
    __rpow__ = _noop
    __truediv__ = _noop
    __rtruediv__ = _noop
    __mod__ = _noop
    __rmod__ = _noop
    _eval_power = _noop

    def __lt__(self, other):
        raise TypeError(filldedent('\n            A Boolean argument can only be used in\n            Eq and Ne; all other relationals expect\n            real expressions.\n        '))
    __le__ = __lt__
    __gt__ = __lt__
    __ge__ = __lt__

    def _eval_simplify(self, **kwargs):
        return self

class BooleanTrue(BooleanAtom, metaclass=Singleton):

    def __bool__(self):
        return True

    def __hash__(self):
        return hash(True)

    def __eq__(self, other):
        if other is True:
            return True
        if other is False:
            return False
        return super().__eq__(other)

    @property
    def negated(self):
        return false

    def as_set(self):
        return S.UniversalSet

class BooleanFalse(BooleanAtom, metaclass=Singleton):

    def __bool__(self):
        return False

    def __hash__(self):
        return hash(False)

    def __eq__(self, other):
        if other is True:
            return False
        if other is False:
            return True
        return super().__eq__(other)

    @property
    def negated(self):
        return true

    def as_set(self):
        return S.EmptySet
true = BooleanTrue()
false = BooleanFalse()
S.true = true
S.false = false
_sympy_converter[bool] = lambda x: true if x else false

class BooleanFunction(Application, Boolean):
    is_Boolean = True

    def _eval_simplify(self, **kwargs):
        rv = simplify_univariate(self)
        if not isinstance(rv, BooleanFunction):
            return rv.simplify(**kwargs)
        rv = rv.func(*[a.simplify(**kwargs) for a in rv.args])
        return simplify_logic(rv)

    def simplify(self, **kwargs):
        from sympy.simplify.simplify import simplify
        return simplify(self, **kwargs)

    def __lt__(self, other):
        raise TypeError(filldedent('\n            A Boolean argument can only be used in\n            Eq and Ne; all other relationals expect\n            real expressions.\n        '))
    __le__ = __lt__
    __ge__ = __lt__
    __gt__ = __lt__

    @classmethod
    def binary_check_and_simplify(self, *args):
        return [as_Boolean(i) for i in args]

    def to_nnf(self, simplify=True, form=None):
        return self._to_nnf(*self.args, simplify=simplify, form=form)

    def to_anf(self, deep=True):
        return self._to_anf(*self.args, deep=deep)

    @classmethod
    def _to_nnf(cls, *args, **kwargs):
        simplify = kwargs.get('simplify', True)
        form = kwargs.get('form', None)
        argset = set()
        for arg in args:
            if not is_literal(arg):
                arg = arg.to_nnf(simplify, form=form)
            if simplify:
                if isinstance(arg, cls):
                    arg = arg.args
                else:
                    arg = (arg,)
                for a in arg:
                    if Not(a) in argset:
                        return cls.zero
                    argset.add(a)
            else:
                argset.add(arg)
        return cls(*argset)

    @classmethod
    def _to_anf(cls, *args, **kwargs):
        deep = kwargs.get('deep', True)
        new_args = []
        for arg in args:
            if deep:
                if not is_literal(arg) or isinstance(arg, Not):
                    arg = arg.to_anf(deep=deep)
            new_args.append(arg)
        return cls(*new_args, remove_true=False)

    def diff(self, *symbols, **assumptions):
        assumptions.setdefault('evaluate', True)
        return Derivative(self, *symbols, **assumptions)

    def _eval_derivative(self, x):
        if x in self.binary_symbols:
            from sympy.core.relational import Eq
            from sympy.functions.elementary.piecewise import Piecewise
            return Piecewise((0, Eq(self.subs(x, 0), self.subs(x, 1))), (1, True))
        elif x in self.free_symbols:
            pass
        else:
            return S.Zero

class And(LatticeOp, BooleanFunction):
    zero = false
    identity = true
    nargs = None
    if TYPE_CHECKING:

        def __new__(cls, *args: Boolean | bool, evaluate: bool | None=None) -> Boolean:
            pass

        @property
        def args(self) -> tuple[Boolean, ...]:
            pass

    @classmethod
    def _from_args(cls, args, is_commutative=None):
        return super(AssocOp, cls).__new__(cls, *args)

    @classmethod
    def _new_args_filter(cls, args):
        args = BooleanFunction.binary_check_and_simplify(*args)
        args = LatticeOp._new_args_filter(args, And)
        newargs = []
        rel = set()
        for x in ordered(args):
            if x.is_Relational:
                c = x.canonical
                if c in rel:
                    continue
                elif c.negated.canonical in rel:
                    return [false]
                else:
                    rel.add(c)
            newargs.append(x)
        return newargs

    def _eval_subs(self, old, new):
        args = []
        bad = None
        for i in self.args:
            try:
                i = i.subs(old, new)
            except TypeError:
                if bad is None:
                    bad = i
                continue
            if i == False:
                return false
            elif i != True:
                args.append(i)
        if bad is not None:
            bad.subs(old, new)
        if isinstance(old, And):
            old_set = set(old.args)
            if old_set.issubset(args):
                args = set(args) - old_set
                args.add(new)
        return self.func(*args)

    def _eval_simplify(self, **kwargs):
        from sympy.core.relational import Equality, Relational
        from sympy.solvers.solveset import linear_coeffs
        rv = super()._eval_simplify(**kwargs)
        if not isinstance(rv, And):
            return rv
        Rel, nonRel = sift(rv.args, lambda i: isinstance(i, Relational), binary=True)
        if not Rel:
            return rv
        eqs, other = sift(Rel, lambda i: isinstance(i, Equality), binary=True)
        measure = kwargs['measure']
        if eqs:
            ratio = kwargs['ratio']
            reps = {}
            sifted = {}
            sifted = sift(ordered([(i.free_symbols, i) for i in eqs]), lambda x: len(x[0]))
            eqs = []
            nonlineqs = []
            while 1 in sifted:
                for free, e in sifted.pop(1):
                    x = free.pop()
                    if (e.lhs != x or x in e.rhs.free_symbols) and x not in reps:
                        try:
                            m, b = linear_coeffs(Add(e.lhs, -e.rhs, evaluate=False), x)
                            enew = e.func(x, -b / m)
                            if measure(enew) <= ratio * measure(e):
                                e = enew
                            else:
                                eqs.append(e)
                                continue
                        except ValueError:
                            pass
                    if x in reps:
                        eqs.append(e.subs(x, reps[x]))
                    elif e.lhs == x and x not in e.rhs.free_symbols:
                        reps[x] = e.rhs
                        eqs.append(e)
                    else:
                        nonlineqs.append(e)
                resifted = defaultdict(list)
                for k in sifted:
                    for f, e in sifted[k]:
                        e = e.xreplace(reps)
                        f = e.free_symbols
                        resifted[len(f)].append((f, e))
                sifted = resifted
            for k in sifted:
                eqs.extend([e for f, e in sifted[k]])
            nonlineqs = [ei.subs(reps) for ei in nonlineqs]
            other = [ei.subs(reps) for ei in other]
            rv = rv.func(*[i.canonical for i in eqs + nonlineqs + other] + nonRel)
        patterns = _simplify_patterns_and()
        threeterm_patterns = _simplify_patterns_and3()
        return _apply_patternbased_simplification(rv, patterns, measure, false, threeterm_patterns=threeterm_patterns)

    def _eval_as_set(self):
        from sympy.sets.sets import Intersection
        return Intersection(*[arg.as_set() for arg in self.args])

    def _eval_rewrite_as_Nor(self, *args, **kwargs):
        return Nor(*[Not(arg) for arg in self.args])

    def to_anf(self, deep=True):
        if deep:
            result = And._to_anf(*self.args, deep=deep)
            return distribute_xor_over_and(result)
        return self

class Or(LatticeOp, BooleanFunction):
    zero = true
    identity = false
    if TYPE_CHECKING:

        def __new__(cls, *args: Boolean | bool, evaluate: bool | None=None) -> Boolean:
            pass

        @property
        def args(self) -> tuple[Boolean, ...]:
            pass

    @classmethod
    def _from_args(cls, args, is_commutative=None):
        return super(AssocOp, cls).__new__(cls, *args)

    @classmethod
    def _new_args_filter(cls, args):
        newargs = []
        rel = []
        args = BooleanFunction.binary_check_and_simplify(*args)
        for x in args:
            if x.is_Relational:
                c = x.canonical
                if c in rel:
                    continue
                nc = c.negated.canonical
                if any((r == nc for r in rel)):
                    return [true]
                rel.append(c)
            newargs.append(x)
        return LatticeOp._new_args_filter(newargs, Or)

    def _eval_subs(self, old, new):
        args = []
        bad = None
        for i in self.args:
            try:
                i = i.subs(old, new)
            except TypeError:
                if bad is None:
                    bad = i
                continue
            if i == True:
                return true
            elif i != False:
                args.append(i)
        if bad is not None:
            bad.subs(old, new)
        if isinstance(old, Or):
            old_set = set(old.args)
            if old_set.issubset(args):
                args = set(args) - old_set
                args.add(new)
        return self.func(*args)

    def _eval_as_set(self):
        from sympy.sets.sets import Union
        return Union(*[arg.as_set() for arg in self.args])

    def _eval_rewrite_as_Nand(self, *args, **kwargs):
        return Nand(*[Not(arg) for arg in self.args])

    def _eval_simplify(self, **kwargs):
        from sympy.core.relational import Le, Ge, Eq
        lege = self.atoms(Le, Ge)
        if lege:
            reps = {i: self.func(Eq(i.lhs, i.rhs), i.strict) for i in lege}
            return self.xreplace(reps)._eval_simplify(**kwargs)
        rv = super()._eval_simplify(**kwargs)
        if not isinstance(rv, Or):
            return rv
        patterns = _simplify_patterns_or()
        return _apply_patternbased_simplification(rv, patterns, kwargs['measure'], true)

    def to_anf(self, deep=True):
        args = range(1, len(self.args) + 1)
        args = (combinations(self.args, j) for j in args)
        args = chain.from_iterable(args)
        args = (And(*arg) for arg in args)
        args = (to_anf(x, deep=deep) if deep else x for x in args)
        return Xor(*list(args), remove_true=False)

class Not(BooleanFunction):
    is_Not = True

    @classmethod
    def eval(cls, arg):
        if isinstance(arg, Number) or arg in (True, False):
            return false if arg else true
        if arg.is_Not:
            return arg.args[0]
        if arg.is_Relational:
            return arg.negated

    def _eval_as_set(self):
        return self.args[0].as_set().complement(S.Reals)

    def to_nnf(self, simplify=True, form=None):
        if is_literal(self):
            return self
        expr = self.args[0]
        func, args = (expr.func, expr.args)
        if func == And:
            return Or._to_nnf(*[Not(arg) for arg in args], simplify=simplify, form=form)
        if func == Or:
            return And._to_nnf(*[Not(arg) for arg in args], simplify=simplify, form=form)
        if func == Implies:
            a, b = args
            return And._to_nnf(a, Not(b), simplify=simplify, form=form)
        if func == Equivalent:
            return And._to_nnf(Or(*args), Or(*[Not(arg) for arg in args]), simplify=simplify, form=form)
        if func == Xor:
            result = []
            for i in range(1, len(args) + 1, 2):
                for neg in combinations(args, i):
                    clause = [Not(s) if s in neg else s for s in args]
                    result.append(Or(*clause))
            return And._to_nnf(*result, simplify=simplify, form=form)
        if func == ITE:
            a, b, c = args
            return And._to_nnf(Or(a, Not(c)), Or(Not(a), Not(b)), simplify=simplify, form=form)
        raise ValueError('Illegal operator %s in expression' % func)

    def to_anf(self, deep=True):
        return Xor._to_anf(true, self.args[0], deep=deep)

class Xor(BooleanFunction):

    def __new__(cls, *args, remove_true=True, evaluate=None, **kwargs):
        if evaluate is None:
            evaluate = global_parameters.evaluate
        if not evaluate:
            return super().__new__(cls, *args, evaluate=evaluate, **kwargs)
        argset = set()
        for arg in map(_sympify, args):
            if isinstance(arg, Number) or arg in (True, False):
                if arg:
                    arg = true
                else:
                    continue
            if isinstance(arg, Xor):
                for a in arg.args:
                    argset.remove(a) if a in argset else argset.add(a)
            elif arg in argset:
                argset.remove(arg)
            else:
                argset.add(arg)
        rel = [(r, r.canonical, r.negated.canonical) for r in argset if r.is_Relational]
        odd = False
        remove = []
        for i, (r, c, nc) in enumerate(rel):
            for j in range(i + 1, len(rel)):
                rj, cj = rel[j][:2]
                if cj == nc:
                    odd = not odd
                    break
                elif cj == c:
                    break
            else:
                continue
            remove.append((r, rj))
        if odd:
            argset.remove(true) if true in argset else argset.add(true)
        for a, b in remove:
            argset.remove(a)
            argset.remove(b)
        if len(argset) == 0:
            return false
        elif len(argset) == 1:
            return argset.pop()
        elif True in argset and remove_true:
            argset.remove(True)
            return Not(Xor(*argset))
        return super().__new__(cls, *ordered(argset))

    def to_nnf(self, simplify=True, form=None):
        if form == 'dnf':
            terms = []
            for mask in _get_odd_parity_terms(len(self.args)):
                conj = [self.args[i] if mask[i] == 1 else Not(self.args[i]) for i in range(len(self.args))]
                terms.append(And(*conj, evaluate=False))
            return Or._to_nnf(*terms, simplify=simplify)
        else:
            args = []
            for i in range(0, len(self.args) + 1, 2):
                for neg in combinations(self.args, i):
                    clause = [Not(s) if s in neg else s for s in self.args]
                    args.append(Or(*clause, evaluate=False))
            return And._to_nnf(*args, simplify=simplify)

    def _eval_rewrite_as_Or(self, *args, **kwargs):
        a = self.args
        return Or(*[_convert_to_varsSOP(x, self.args) for x in _get_odd_parity_terms(len(a))])

    def _eval_rewrite_as_And(self, *args, **kwargs):
        a = self.args
        return And(*[_convert_to_varsPOS(x, self.args) for x in _get_even_parity_terms(len(a))])

    def _eval_simplify(self, **kwargs):
        rv = self.func(*[a.simplify(**kwargs) for a in self.args])
        rv = rv.to_anf()
        if not isinstance(rv, Xor):
            return rv
        patterns = _simplify_patterns_xor()
        return _apply_patternbased_simplification(rv, patterns, kwargs['measure'], None)

    def _eval_subs(self, old, new):
        if isinstance(old, Xor):
            old_set = set(old.args)
            if old_set.issubset(self.args):
                args = set(self.args) - old_set
                args.add(new)
                return self.func(*args)

class Nand(BooleanFunction):

    @classmethod
    def eval(cls, *args):
        return Not(And(*args))

class Nor(BooleanFunction):

    @classmethod
    def eval(cls, *args):
        return Not(Or(*args))

class Xnor(BooleanFunction):

    @classmethod
    def eval(cls, *args):
        return Not(Xor(*args))

class Implies(BooleanFunction):

    @classmethod
    def eval(cls, *args):
        try:
            newargs = []
            for x in args:
                if isinstance(x, Number) or x in (0, 1):
                    newargs.append(bool(x))
                else:
                    newargs.append(x)
            A, B = newargs
        except ValueError:
            raise ValueError('%d operand(s) used for an Implies (pairs are required): %s' % (len(args), str(args)))
        if A in (True, False) or B in (True, False):
            return Or(Not(A), B)
        elif A == B:
            return true
        elif A.is_Relational and B.is_Relational:
            if A.canonical == B.canonical:
                return true
            if A.negated.canonical == B.canonical:
                return B
        else:
            return Basic.__new__(cls, *args)

    def to_nnf(self, simplify=True, form=None):
        a, b = self.args
        return Or._to_nnf(Not(a), b, simplify=simplify, form=form)

    def to_anf(self, deep=True):
        a, b = self.args
        return Xor._to_anf(true, a, And(a, b), deep=deep)

class Equivalent(BooleanFunction):

    def __new__(cls, *args, evaluate=None, **kwargs):
        if evaluate is None:
            evaluate = global_parameters.evaluate
        if not evaluate:
            return super().__new__(cls, *args, evaluate=evaluate, **kwargs)
        from sympy.core.relational import Relational
        args = [_sympify(arg) for arg in args]
        argset = set(args)
        for x in args:
            if isinstance(x, Number) or x in [True, False]:
                argset.discard(x)
                argset.add(bool(x))
        rel = []
        for r in argset:
            if isinstance(r, Relational):
                rel.append((r, r.canonical, r.negated.canonical))
        remove = []
        for i, (r, c, nc) in enumerate(rel):
            for j in range(i + 1, len(rel)):
                rj, cj = rel[j][:2]
                if cj == nc:
                    return false
                elif cj == c:
                    remove.append((r, rj))
                    break
        for a, b in remove:
            argset.remove(a)
            argset.remove(b)
            argset.add(True)
        if len(argset) <= 1:
            return true
        if True in argset:
            argset.discard(True)
            return And(*argset)
        if False in argset:
            argset.discard(False)
            return And(*[Not(arg) for arg in argset])
        return super().__new__(cls, *ordered(argset))

    def to_nnf(self, simplify=True, form=None):
        args = []
        for a, b in zip(self.args, self.args[1:]):
            args.append(Or(Not(a), b))
        args.append(Or(Not(self.args[-1]), self.args[0]))
        return And._to_nnf(*args, simplify=simplify, form=form)

    def to_anf(self, deep=True):
        a = And(*self.args)
        b = And(*[to_anf(Not(arg), deep=False) for arg in self.args])
        b = distribute_xor_over_and(b)
        return Xor._to_anf(a, b, deep=deep)

class ITE(BooleanFunction):

    def __new__(cls, *args, **kwargs):
        from sympy.core.relational import Eq, Ne
        if len(args) != 3:
            raise ValueError('expecting exactly 3 args')
        a, b, c = args
        if isinstance(a, (Eq, Ne)):
            b, c = map(as_Boolean, (b, c))
            bin_syms = set().union(*[i.binary_symbols for i in (b, c)])
            if len(set(a.args) - bin_syms) == 1:
                _a = a
                if a.lhs is true:
                    a = a.rhs
                elif a.rhs is true:
                    a = a.lhs
                elif a.lhs is false:
                    a = Not(a.rhs)
                elif a.rhs is false:
                    a = Not(a.lhs)
                else:
                    a = false
                if isinstance(_a, Ne):
                    a = Not(a)
        else:
            a, b, c = BooleanFunction.binary_check_and_simplify(a, b, c)
        rv = None
        if kwargs.get('evaluate', True):
            rv = cls.eval(a, b, c)
        if rv is None:
            rv = BooleanFunction.__new__(cls, a, b, c, evaluate=False)
        return rv

    @classmethod
    def eval(cls, *args):
        from sympy.core.relational import Eq, Ne
        a, b, c = args
        if isinstance(a, (Ne, Eq)):
            _a = a
            if true in a.args:
                a = a.lhs if a.rhs is true else a.rhs
            elif false in a.args:
                a = Not(a.lhs) if a.rhs is false else Not(a.rhs)
            else:
                _a = None
            if _a is not None and isinstance(_a, Ne):
                a = Not(a)
        if a is true:
            return b
        if a is false:
            return c
        if b == c:
            return b
        else:
            if b is true and c is false:
                return a
            if b is false and c is true:
                return Not(a)
        if [a, b, c] != args:
            return cls(a, b, c, evaluate=False)

    def to_nnf(self, simplify=True, form=None):
        a, b, c = self.args
        return And._to_nnf(Or(Not(a), b), Or(a, c), simplify=simplify, form=form)

    def _eval_as_set(self):
        return self.to_nnf().as_set()

    def _eval_rewrite_as_Piecewise(self, *args, **kwargs):
        from sympy.functions.elementary.piecewise import Piecewise
        return Piecewise((args[1], args[0]), (args[2], True))

class Exclusive(BooleanFunction):

    @classmethod
    def eval(cls, *args):
        and_args = []
        for a, b in combinations(args, 2):
            and_args.append(Not(And(a, b)))
        return And(*and_args)

def conjuncts(expr):
    return And.make_args(expr)

def disjuncts(expr):
    return Or.make_args(expr)

def distribute_and_over_or(expr):
    return _distribute((expr, And, Or))

def distribute_or_over_and(expr):
    return _distribute((expr, Or, And))

def distribute_xor_over_and(expr):
    return _distribute((expr, Xor, And))

def _distribute(info):
    if isinstance(info[0], info[2]):
        for arg in info[0].args:
            if isinstance(arg, info[1]):
                conj = arg
                break
        else:
            return info[0]
        rest = info[2](*[a for a in info[0].args if a is not conj])
        return info[1](*list(map(_distribute, [(info[2](c, rest), info[1], info[2]) for c in conj.args])), remove_true=False)
    elif isinstance(info[0], info[1]):
        return info[1](*list(map(_distribute, [(x, info[1], info[2]) for x in info[0].args])), remove_true=False)
    else:
        return info[0]

def to_anf(expr, deep=True):
    expr = sympify(expr)
    if is_anf(expr):
        return expr
    return expr.to_anf(deep=deep)

def to_nnf(expr, simplify=True, form=None):
    if is_nnf(expr, simplify):
        return expr
    return expr.to_nnf(simplify, form=form)

def to_cnf(expr, simplify=False, force=False):
    expr = sympify(expr)
    if not isinstance(expr, BooleanFunction):
        return expr
    if simplify:
        if not force and len(_find_predicates(expr)) > 8:
            raise ValueError(filldedent('\n            To simplify a logical expression with more\n            than 8 variables may take a long time and requires\n            the use of `force=True`.'))
        return simplify_logic(expr, 'cnf', True, force=force)
    if is_cnf(expr):
        return expr
    expr = eliminate_implications(expr, form='cnf')
    res = distribute_and_over_or(expr)
    return res

def to_dnf(expr, simplify=False, force=False):
    expr = sympify(expr)
    if not isinstance(expr, BooleanFunction):
        return expr
    if simplify:
        if not force and len(_find_predicates(expr)) > 8:
            raise ValueError(filldedent('\n            To simplify a logical expression with more\n            than 8 variables may take a long time and requires\n            the use of `force=True`.'))
        return simplify_logic(expr, 'dnf', True, force=force)
    if is_dnf(expr):
        return expr
    expr = eliminate_implications(expr, form='dnf')
    return distribute_or_over_and(expr)

def is_anf(expr):
    expr = sympify(expr)
    if is_literal(expr) and (not isinstance(expr, Not)):
        return True
    if isinstance(expr, And):
        for arg in expr.args:
            if not arg.is_Symbol:
                return False
        return True
    elif isinstance(expr, Xor):
        for arg in expr.args:
            if isinstance(arg, And):
                for a in arg.args:
                    if not a.is_Symbol:
                        return False
            elif is_literal(arg):
                if isinstance(arg, Not):
                    return False
            else:
                return False
        return True
    else:
        return False

def is_nnf(expr, simplified=True):
    expr = sympify(expr)
    if is_literal(expr):
        return True
    stack = [expr]
    while stack:
        expr = stack.pop()
        if expr.func in (And, Or):
            if simplified:
                args = expr.args
                for arg in args:
                    if Not(arg) in args:
                        return False
            stack.extend(expr.args)
        elif not is_literal(expr):
            return False
    return True

def is_cnf(expr):
    return _is_form(expr, And, Or)

def is_dnf(expr):
    return _is_form(expr, Or, And)

def _is_form(expr, function1, function2):
    expr = sympify(expr)
    vals = function1.make_args(expr) if isinstance(expr, function1) else [expr]
    for lit in vals:
        if isinstance(lit, function2):
            vals2 = function2.make_args(lit) if isinstance(lit, function2) else [lit]
            for l in vals2:
                if is_literal(l) is False:
                    return False
        elif is_literal(lit) is False:
            return False
    return True

def eliminate_implications(expr, form=None):
    return to_nnf(expr, simplify=False, form=form)

def is_literal(expr):
    from sympy.assumptions import AppliedPredicate
    if isinstance(expr, Not):
        return is_literal(expr.args[0])
    elif expr in (True, False) or isinstance(expr, AppliedPredicate) or expr.is_Atom:
        return True
    elif not isinstance(expr, BooleanFunction) and all((isinstance(expr, AppliedPredicate) or a.is_Atom for a in expr.args)):
        return True
    return False

def to_int_repr(clauses, symbols):
    symbols = dict(zip(symbols, range(1, len(symbols) + 1)))

    def append_symbol(arg, symbols):
        if isinstance(arg, Not):
            return -symbols[arg.args[0]]
        else:
            return symbols[arg]
    return [{append_symbol(arg, symbols) for arg in Or.make_args(c)} for c in clauses]

def term_to_integer(term):
    return int(''.join(list(map(str, list(term)))), 2)
integer_to_term = ibin

def truth_table(expr, variables, input=True):
    variables = [sympify(v) for v in variables]
    expr = sympify(expr)
    if not isinstance(expr, BooleanFunction) and (not is_literal(expr)):
        return
    table = product((0, 1), repeat=len(variables))
    for term in table:
        value = expr.xreplace(dict(zip(variables, term)))
        if input:
            yield (list(term), value)
        else:
            yield value

def _check_pair(minterm1, minterm2):
    index = -1
    for x, i in enumerate(minterm1):
        if i != minterm2[x]:
            if index == -1:
                index = x
            else:
                return -1
    return index

def _convert_to_varsSOP(minterm, variables):
    temp = [variables[n] if val == 1 else Not(variables[n]) for n, val in enumerate(minterm) if val != 3]
    return And(*temp)

def _convert_to_varsPOS(maxterm, variables):
    temp = [variables[n] if val == 0 else Not(variables[n]) for n, val in enumerate(maxterm) if val != 3]
    return Or(*temp)

def _convert_to_varsANF(term, variables):
    temp = [variables[n] for n, t in enumerate(term) if t == 1]
    if not temp:
        return true
    return And(*temp)

def _get_odd_parity_terms(n):
    return [[1 if mask >> i & 1 else 0 for i in range(n)] for mask in range(1 << n) if mask.bit_count() % 2 == 1]

def _get_even_parity_terms(n):
    return [[1 if mask >> i & 1 else 0 for i in range(n)] for mask in range(1 << n) if mask.bit_count() % 2 == 0]

def _simplified_pairs(terms):
    if not terms:
        return []
    simplified_terms = []
    todo = list(range(len(terms)))
    termdict = defaultdict(list)
    for n, term in enumerate(terms):
        ones = sum((1 for t in term if t == 1))
        termdict[ones].append(n)
    variables = len(terms[0])
    for k in range(variables):
        for i in termdict[k]:
            for j in termdict[k + 1]:
                index = _check_pair(terms[i], terms[j])
                if index != -1:
                    todo[i] = todo[j] = None
                    newterm = terms[i][:]
                    newterm[index] = 3
                    if newterm not in simplified_terms:
                        simplified_terms.append(newterm)
    if simplified_terms:
        simplified_terms = _simplified_pairs(simplified_terms)
    simplified_terms.extend([terms[i] for i in todo if i is not None])
    return simplified_terms

def _rem_redundancy(l1, terms):
    if not terms:
        return []
    nterms = len(terms)
    nl1 = len(l1)
    dommatrix = [[0] * nl1 for n in range(nterms)]
    colcount = [0] * nl1
    rowcount = [0] * nterms
    for primei, prime in enumerate(l1):
        for termi, term in enumerate(terms):
            if all((t == 3 or t == mt for t, mt in zip(prime, term))):
                dommatrix[termi][primei] = 1
                colcount[primei] += 1
                rowcount[termi] += 1
    anythingchanged = True
    while anythingchanged:
        anythingchanged = False
        for rowi in range(nterms):
            if rowcount[rowi]:
                row = dommatrix[rowi]
                for row2i in range(nterms):
                    if rowi != row2i and rowcount[rowi] and (rowcount[rowi] <= rowcount[row2i]):
                        row2 = dommatrix[row2i]
                        if all((row2[n] >= row[n] for n in range(nl1))):
                            rowcount[row2i] = 0
                            anythingchanged = True
                            for primei, prime in enumerate(row2):
                                if prime:
                                    dommatrix[row2i][primei] = 0
                                    colcount[primei] -= 1
        colcache = {}
        for coli in range(nl1):
            if colcount[coli]:
                if coli in colcache:
                    col = colcache[coli]
                else:
                    col = [dommatrix[i][coli] for i in range(nterms)]
                    colcache[coli] = col
                for col2i in range(nl1):
                    if coli != col2i and colcount[col2i] and (colcount[coli] >= colcount[col2i]):
                        if col2i in colcache:
                            col2 = colcache[col2i]
                        else:
                            col2 = [dommatrix[i][col2i] for i in range(nterms)]
                            colcache[col2i] = col2
                        if all((col[n] >= col2[n] for n in range(nterms))):
                            colcount[col2i] = 0
                            anythingchanged = True
                            for termi, term in enumerate(col2):
                                if term and dommatrix[termi][col2i]:
                                    dommatrix[termi][col2i] = 0
                                    rowcount[termi] -= 1
        if not anythingchanged:
            maxterms = 0
            bestcolidx = -1
            for coli in range(nl1):
                s = colcount[coli]
                if s > maxterms:
                    bestcolidx = coli
                    maxterms = s
            if bestcolidx != -1 and maxterms > 1:
                for primei, prime in enumerate(l1):
                    if primei != bestcolidx:
                        for termi, term in enumerate(colcache[bestcolidx]):
                            if term and dommatrix[termi][primei]:
                                dommatrix[termi][primei] = 0
                                anythingchanged = True
                                rowcount[termi] -= 1
                                colcount[primei] -= 1
    return [l1[i] for i in range(nl1) if colcount[i]]

def _input_to_binlist(inputlist, variables):
    binlist = []
    bits = len(variables)
    for val in inputlist:
        if isinstance(val, int):
            binlist.append(ibin(val, bits))
        elif isinstance(val, dict):
            nonspecvars = list(variables)
            for key in val.keys():
                nonspecvars.remove(key)
            for t in product((0, 1), repeat=len(nonspecvars)):
                d = dict(zip(nonspecvars, t))
                d.update(val)
                binlist.append([d[v] for v in variables])
        elif isinstance(val, (list, tuple)):
            if len(val) != bits:
                raise ValueError('Each term must contain {bits} bits as there are\n{bits} variables (or be an integer).'.format(bits=bits))
            binlist.append(list(val))
        else:
            raise TypeError('A term list can only contain lists, ints or dicts.')
    return binlist

def SOPform(variables, minterms, dontcares=None):
    if not minterms:
        return false
    variables = tuple(map(sympify, variables))
    minterms = _input_to_binlist(minterms, variables)
    dontcares = _input_to_binlist(dontcares or [], variables)
    for d in dontcares:
        if d in minterms:
            raise ValueError('%s in minterms is also in dontcares' % d)
    return _sop_form(variables, minterms, dontcares)

def _sop_form(variables, minterms, dontcares):
    new = _simplified_pairs(minterms + dontcares)
    essential = _rem_redundancy(new, minterms)
    return Or(*[_convert_to_varsSOP(x, variables) for x in essential])

def POSform(variables, minterms, dontcares=None):
    if not minterms:
        return false
    variables = tuple(map(sympify, variables))
    minterms = _input_to_binlist(minterms, variables)
    dontcares = _input_to_binlist(dontcares or [], variables)
    for d in dontcares:
        if d in minterms:
            raise ValueError('%s in minterms is also in dontcares' % d)
    maxterms = []
    for t in product((0, 1), repeat=len(variables)):
        t = list(t)
        if t not in minterms and t not in dontcares:
            maxterms.append(t)
    new = _simplified_pairs(maxterms + dontcares)
    essential = _rem_redundancy(new, maxterms)
    return And(*[_convert_to_varsPOS(x, variables) for x in essential])

def ANFform(variables, truthvalues):
    n_vars = len(variables)
    n_values = len(truthvalues)
    if n_values != 2 ** n_vars:
        raise ValueError('The number of truth values must be equal to 2^%d, got %d' % (n_vars, n_values))
    variables = tuple(map(sympify, variables))
    coeffs = anf_coeffs(truthvalues)
    terms = []
    for i, t in enumerate(product((0, 1), repeat=n_vars)):
        if coeffs[i] == 1:
            terms.append(t)
    return Xor(*[_convert_to_varsANF(x, variables) for x in terms], remove_true=False)

def anf_coeffs(truthvalues):
    s = '{:b}'.format(len(truthvalues))
    n = len(s) - 1
    if len(truthvalues) != 2 ** n:
        raise ValueError('The number of truth values must be a power of two, got %d' % len(truthvalues))
    coeffs = [[v] for v in truthvalues]
    for i in range(n):
        tmp = []
        for j in range(2 ** (n - i - 1)):
            tmp.append(coeffs[2 * j] + list(map(lambda x, y: x ^ y, coeffs[2 * j], coeffs[2 * j + 1])))
        coeffs = tmp
    return coeffs[0]

def bool_minterm(k, variables):
    if isinstance(k, int):
        k = ibin(k, len(variables))
    variables = tuple(map(sympify, variables))
    return _convert_to_varsSOP(k, variables)

def bool_maxterm(k, variables):
    if isinstance(k, int):
        k = ibin(k, len(variables))
    variables = tuple(map(sympify, variables))
    return _convert_to_varsPOS(k, variables)

def bool_monomial(k, variables):
    if isinstance(k, int):
        k = ibin(k, len(variables))
    variables = tuple(map(sympify, variables))
    return _convert_to_varsANF(k, variables)

def _find_predicates(expr):
    if not isinstance(expr, BooleanFunction):
        return {expr}
    return set().union(*map(_find_predicates, expr.args))

def simplify_logic(expr, form=None, deep=True, force=False, dontcare=None):
    if form not in (None, 'cnf', 'dnf'):
        raise ValueError('form can be cnf or dnf only')
    expr = sympify(expr)
    if form:
        form_ok = False
        if form == 'cnf':
            form_ok = is_cnf(expr)
        elif form == 'dnf':
            form_ok = is_dnf(expr)
        if form_ok and dontcare is None and all((is_literal(a) for a in expr.args)):
            return expr
    from sympy.core.relational import Relational
    if deep:
        variables = expr.atoms(Relational)
        from sympy.simplify.simplify import simplify
        s = tuple(map(simplify, variables))
        expr = expr.xreplace(dict(zip(variables, s)))
    if not isinstance(expr, BooleanFunction) and dontcare is None:
        return expr
    repl = {}
    undo = {}
    from sympy.core.symbol import Dummy
    variables = expr.atoms(Relational)
    if dontcare is not None:
        dontcare = sympify(dontcare)
        variables.update(dontcare.atoms(Relational))
    while variables:
        var = variables.pop()
        if var.is_Relational:
            d = Dummy()
            undo[d] = var
            repl[var] = d
            nvar = var.negated
            if nvar in variables:
                repl[nvar] = Not(d)
                variables.remove(nvar)
    expr = expr.xreplace(repl)
    if dontcare is not None:
        dontcare = dontcare.xreplace(repl)
    variables = _find_predicates(expr)
    if not force and len(variables) > 8:
        return expr.xreplace(undo)
    if dontcare is not None:
        dcvariables = _find_predicates(dontcare)
        variables.update(dcvariables)
        if not force and len(variables) > 8:
            variables = _find_predicates(expr)
            dontcare = None
    c, v = sift(ordered(variables), lambda x: x in (True, False), binary=True)
    variables = c + v
    c = [1 if i == True else 0 for i in c]
    truthtable = _get_truthtable(v, expr, c)
    if dontcare is not None:
        dctruthtable = _get_truthtable(v, dontcare, c)
        truthtable = [t for t in truthtable if t not in dctruthtable]
    else:
        dctruthtable = []
    big = len(truthtable) >= 2 ** (len(variables) - 1)
    if form == 'dnf' or (form is None and big):
        return _sop_form(variables, truthtable, dctruthtable).xreplace(undo)
    return POSform(variables, truthtable, dctruthtable).xreplace(undo)

def _get_truthtable(variables, expr, const):
    _variables = variables.copy()

    def _get_tt(inputs):
        if _variables:
            v = _variables.pop()
            tab = [[i[0].xreplace({v: false}), [0] + i[1]] for i in inputs if i[0] is not false]
            tab.extend([[i[0].xreplace({v: true}), [1] + i[1]] for i in inputs if i[0] is not false])
            return _get_tt(tab)
        return inputs
    res = [const + k[1] for k in _get_tt([[expr, []]]) if k[0]]
    if res == [[]]:
        return []
    else:
        return res

def _finger(eq):
    f = eq.free_symbols
    d = dict(list(zip(f, [[0] * 4 + [defaultdict(int)] for fi in f])))
    for a in eq.args:
        if a.is_Symbol:
            d[a][0] += 1
        elif a.is_Not:
            d[a.args[0]][1] += 1
        else:
            o = (len(a.args), sum((isinstance(ai, Not) for ai in a.args)))
            for ai in a.args:
                if ai.is_Symbol:
                    d[ai][2] += 1
                    d[ai][-1][o] += 1
                elif ai.is_Not:
                    d[ai.args[0]][3] += 1
                else:
                    raise NotImplementedError('unexpected level of nesting')
    inv = defaultdict(list)
    for k, v in ordered(iter(d.items())):
        v[-1] = tuple(sorted([i + (j,) for i, j in v[-1].items()]))
        inv[tuple(v)].append(k)
    return inv

def bool_map(bool1, bool2):

    def match(function1, function2):
        if function1.__class__ != function2.__class__:
            return None
        if len(function1.args) != len(function2.args):
            return None
        if function1.is_Symbol:
            return {function1: function2}
        f1 = _finger(function1)
        f2 = _finger(function2)
        if len(f1) != len(f2):
            return False
        matchdict = {}
        for k in f1.keys():
            if k not in f2:
                return False
            if len(f1[k]) != len(f2[k]):
                return False
            for i, x in enumerate(f1[k]):
                matchdict[x] = f2[k][i]
        return matchdict
    a = simplify_logic(bool1)
    b = simplify_logic(bool2)
    m = match(a, b)
    if m:
        return (a, m)
    return m

def _apply_patternbased_simplification(rv, patterns, measure, dominatingvalue, replacementvalue=None, threeterm_patterns=None):
    from sympy.core.relational import Relational, _canonical
    if replacementvalue is None and dominatingvalue is not None:
        replacementvalue = dominatingvalue
    Rel, nonRel = sift(rv.args, lambda i: isinstance(i, Relational), binary=True)
    if len(Rel) <= 1:
        return rv
    Rel, nonRealRel = sift(Rel, lambda i: not any((s.is_real is False for s in i.free_symbols)), binary=True)
    Rel = [i.canonical for i in Rel]
    if threeterm_patterns and len(Rel) >= 3:
        Rel = _apply_patternbased_threeterm_simplification(Rel, threeterm_patterns, rv.func, dominatingvalue, replacementvalue, measure)
    Rel = _apply_patternbased_twoterm_simplification(Rel, patterns, rv.func, dominatingvalue, replacementvalue, measure)
    rv = rv.func(*[_canonical(i) for i in ordered(Rel)] + nonRel + nonRealRel)
    return rv

def _apply_patternbased_twoterm_simplification(Rel, patterns, func, dominatingvalue, replacementvalue, measure):
    from sympy.functions.elementary.miscellaneous import Min, Max
    from sympy.core.relational import Ge, Gt, _Inequality
    changed = True
    while changed and len(Rel) >= 2:
        changed = False
        Rel = [r.reversed if isinstance(r, (Ge, Gt)) else r for r in Rel]
        Rel = list(ordered(Rel))
        rtmp = [(r,) if isinstance(r, _Inequality) else (r, r.reversed) for r in Rel]
        results = []
        for (i, pi), (j, pj) in combinations(enumerate(rtmp), 2):
            for pattern, simp in patterns:
                res = []
                for p1, p2 in product(pi, pj):
                    oldexpr = Tuple(p1, p2)
                    tmpres = oldexpr.match(pattern)
                    if tmpres:
                        res.append((tmpres, oldexpr))
                if res:
                    for tmpres, oldexpr in res:
                        np = simp.xreplace(tmpres)
                        if np == dominatingvalue:
                            return [replacementvalue]
                        if not isinstance(np, ITE) and (not np.has(Min, Max)):
                            costsaving = measure(func(*oldexpr.args)) - measure(np)
                            if costsaving > 0:
                                results.append((costsaving, ([i, j], np)))
        if results:
            results = sorted(results, key=lambda pair: pair[0], reverse=True)
            replacement = results[0][1]
            idx, newrel = replacement
            idx.sort()
            for index in reversed(idx):
                del Rel[index]
            if dominatingvalue is None or newrel != Not(dominatingvalue):
                if newrel.func == func:
                    for a in newrel.args:
                        Rel.append(a)
                else:
                    Rel.append(newrel)
            changed = True
    return Rel

def _apply_patternbased_threeterm_simplification(Rel, patterns, func, dominatingvalue, replacementvalue, measure):
    from sympy.functions.elementary.miscellaneous import Min, Max
    from sympy.core.relational import Le, Lt, _Inequality
    changed = True
    while changed and len(Rel) >= 3:
        changed = False
        Rel = [r.reversed if isinstance(r, (Le, Lt)) else r for r in Rel]
        Rel = list(ordered(Rel))
        results = []
        rtmp = [(r,) if isinstance(r, _Inequality) else (r, r.reversed) for r in Rel]
        for (i, pi), (j, pj), (k, pk) in permutations(enumerate(rtmp), 3):
            for pattern, simp in patterns:
                res = []
                for p1, p2, p3 in product(pi, pj, pk):
                    oldexpr = Tuple(p1, p2, p3)
                    tmpres = oldexpr.match(pattern)
                    if tmpres:
                        res.append((tmpres, oldexpr))
                if res:
                    for tmpres, oldexpr in res:
                        np = simp.xreplace(tmpres)
                        if np == dominatingvalue:
                            return [replacementvalue]
                        if not isinstance(np, ITE) and (not np.has(Min, Max)):
                            costsaving = measure(func(*oldexpr.args)) - measure(np)
                            if costsaving > 0:
                                results.append((costsaving, ([i, j, k], np)))
        if results:
            results = sorted(results, key=lambda pair: pair[0], reverse=True)
            replacement = results[0][1]
            idx, newrel = replacement
            idx.sort()
            for index in reversed(idx):
                del Rel[index]
            if dominatingvalue is None or newrel != Not(dominatingvalue):
                if newrel.func == func:
                    for a in newrel.args:
                        Rel.append(a)
                else:
                    Rel.append(newrel)
            changed = True
    return Rel

@cacheit
def _simplify_patterns_and():
    from sympy.core import Wild
    from sympy.core.relational import Eq, Ne, Ge, Gt, Le, Lt
    from sympy.functions.elementary.complexes import Abs
    from sympy.functions.elementary.miscellaneous import Min, Max
    a = Wild('a')
    b = Wild('b')
    c = Wild('c')
    _matchers_and = ((Tuple(Eq(a, b), Lt(a, b)), false), (Tuple(Lt(b, a), Lt(a, b)), false), (Tuple(Eq(a, b), Le(b, a)), Eq(a, b)), (Tuple(Le(b, a), Le(a, b)), Eq(a, b)), (Tuple(Le(a, b), Lt(a, b)), Lt(a, b)), (Tuple(Le(a, b), Ne(a, b)), Lt(a, b)), (Tuple(Lt(a, b), Ne(a, b)), Lt(a, b)), (Tuple(Eq(a, b), Eq(a, -b)), And(Eq(a, S.Zero), Eq(b, S.Zero))), (Tuple(Le(b, a), Le(c, a)), Ge(a, Max(b, c))), (Tuple(Le(b, a), Lt(c, a)), ITE(b > c, Ge(a, b), Gt(a, c))), (Tuple(Lt(b, a), Lt(c, a)), Gt(a, Max(b, c))), (Tuple(Le(a, b), Le(a, c)), Le(a, Min(b, c))), (Tuple(Le(a, b), Lt(a, c)), ITE(b < c, Le(a, b), Lt(a, c))), (Tuple(Lt(a, b), Lt(a, c)), Lt(a, Min(b, c))), (Tuple(Le(a, b), Le(c, a)), ITE(Eq(b, c), Eq(a, b), ITE(b < c, false, And(Le(a, b), Ge(a, c))))), (Tuple(Le(c, a), Le(a, b)), ITE(Eq(b, c), Eq(a, b), ITE(b < c, false, And(Le(a, b), Ge(a, c))))), (Tuple(Lt(a, b), Lt(c, a)), ITE(b < c, false, And(Lt(a, b), Gt(a, c)))), (Tuple(Lt(c, a), Lt(a, b)), ITE(b < c, false, And(Lt(a, b), Gt(a, c)))), (Tuple(Le(a, b), Lt(c, a)), ITE(b <= c, false, And(Le(a, b), Gt(a, c)))), (Tuple(Le(c, a), Lt(a, b)), ITE(b <= c, false, And(Lt(a, b), Ge(a, c)))), (Tuple(Eq(a, b), Eq(a, c)), ITE(Eq(b, c), Eq(a, b), false)), (Tuple(Lt(a, b), Lt(-b, a)), ITE(b > 0, Lt(Abs(a), b), false)), (Tuple(Le(a, b), Le(-b, a)), ITE(b >= 0, Le(Abs(a), b), false)))
    return _matchers_and

@cacheit
def _simplify_patterns_and3():
    from sympy.core import Wild
    from sympy.core.relational import Eq, Ge, Gt
    a = Wild('a')
    b = Wild('b')
    c = Wild('c')
    _matchers_and = ((Tuple(Ge(a, b), Ge(b, c), Gt(c, a)), false), (Tuple(Ge(a, b), Gt(b, c), Gt(c, a)), false), (Tuple(Gt(a, b), Gt(b, c), Gt(c, a)), false), (Tuple(Ge(a, b), Ge(a, c), Ge(b, c)), And(Ge(a, b), Ge(b, c))), (Tuple(Ge(a, b), Ge(a, c), Gt(b, c)), And(Ge(a, b), Gt(b, c))), (Tuple(Ge(a, b), Gt(a, c), Gt(b, c)), And(Ge(a, b), Gt(b, c))), (Tuple(Ge(a, c), Gt(a, b), Gt(b, c)), And(Gt(a, b), Gt(b, c))), (Tuple(Ge(b, c), Gt(a, b), Gt(a, c)), And(Gt(a, b), Ge(b, c))), (Tuple(Gt(a, b), Gt(a, c), Gt(b, c)), And(Gt(a, b), Gt(b, c))), (Tuple(Ge(b, a), Ge(c, a), Ge(b, c)), And(Ge(c, a), Ge(b, c))), (Tuple(Ge(b, a), Ge(c, a), Gt(b, c)), And(Ge(c, a), Gt(b, c))), (Tuple(Ge(b, a), Gt(c, a), Gt(b, c)), And(Gt(c, a), Gt(b, c))), (Tuple(Ge(c, a), Gt(b, a), Gt(b, c)), And(Ge(c, a), Gt(b, c))), (Tuple(Ge(b, c), Gt(b, a), Gt(c, a)), And(Gt(c, a), Ge(b, c))), (Tuple(Gt(b, a), Gt(c, a), Gt(b, c)), And(Gt(c, a), Gt(b, c))), (Tuple(Ge(a, b), Ge(b, c), Ge(c, a)), And(Eq(a, b), Eq(b, c))))
    return _matchers_and

@cacheit
def _simplify_patterns_or():
    from sympy.core import Wild
    from sympy.core.relational import Eq, Ne, Ge, Gt, Le, Lt
    from sympy.functions.elementary.complexes import Abs
    from sympy.functions.elementary.miscellaneous import Min, Max
    a = Wild('a')
    b = Wild('b')
    c = Wild('c')
    _matchers_or = ((Tuple(Le(b, a), Le(a, b)), true), (Tuple(Le(b, a), Ne(a, b)), true), (Tuple(Eq(a, b), Le(a, b)), Le(a, b)), (Tuple(Eq(a, b), Lt(a, b)), Le(a, b)), (Tuple(Lt(b, a), Lt(a, b)), Ne(a, b)), (Tuple(Lt(b, a), Ne(a, b)), Ne(a, b)), (Tuple(Le(a, b), Lt(a, b)), Le(a, b)), (Tuple(Eq(a, b), Ne(a, c)), ITE(Eq(b, c), true, Ne(a, c))), (Tuple(Ne(a, b), Ne(a, c)), ITE(Eq(b, c), Ne(a, b), true)), (Tuple(Le(b, a), Le(c, a)), Ge(a, Min(b, c))), (Tuple(Le(b, a), Lt(c, a)), ITE(b > c, Lt(c, a), Le(b, a))), (Tuple(Lt(b, a), Lt(c, a)), Gt(a, Min(b, c))), (Tuple(Le(a, b), Le(a, c)), Le(a, Max(b, c))), (Tuple(Le(a, b), Lt(a, c)), ITE(b >= c, Le(a, b), Lt(a, c))), (Tuple(Lt(a, b), Lt(a, c)), Lt(a, Max(b, c))), (Tuple(Le(a, b), Le(c, a)), ITE(b >= c, true, Or(Le(a, b), Ge(a, c)))), (Tuple(Le(c, a), Le(a, b)), ITE(b >= c, true, Or(Le(a, b), Ge(a, c)))), (Tuple(Lt(a, b), Lt(c, a)), ITE(b > c, true, Or(Lt(a, b), Gt(a, c)))), (Tuple(Lt(c, a), Lt(a, b)), ITE(b > c, true, Or(Lt(a, b), Gt(a, c)))), (Tuple(Le(a, b), Lt(c, a)), ITE(b >= c, true, Or(Le(a, b), Gt(a, c)))), (Tuple(Le(c, a), Lt(a, b)), ITE(b >= c, true, Or(Lt(a, b), Ge(a, c)))), (Tuple(Lt(b, a), Lt(a, -b)), ITE(b >= 0, Gt(Abs(a), b), true)), (Tuple(Le(b, a), Le(a, -b)), ITE(b > 0, Ge(Abs(a), b), true)))
    return _matchers_or

@cacheit
def _simplify_patterns_xor():
    from sympy.functions.elementary.miscellaneous import Min, Max
    from sympy.core import Wild
    from sympy.core.relational import Eq, Ne, Ge, Gt, Le, Lt
    a = Wild('a')
    b = Wild('b')
    c = Wild('c')
    _matchers_xor = ((Tuple(Eq(a, b), Le(a, b)), Lt(a, b)), (Tuple(Eq(a, b), Lt(a, b)), Le(a, b)), (Tuple(Le(a, b), Lt(a, b)), Eq(a, b)), (Tuple(Le(a, b), Le(b, a)), Ne(a, b)), (Tuple(Le(b, a), Ne(a, b)), Le(a, b)), (Tuple(Lt(b, a), Ne(a, b)), Lt(a, b)), (Tuple(Le(b, a), Le(c, a)), And(Ge(a, Min(b, c)), Lt(a, Max(b, c)))), (Tuple(Le(b, a), Lt(c, a)), ITE(b > c, And(Gt(a, c), Lt(a, b)), And(Ge(a, b), Le(a, c)))), (Tuple(Lt(b, a), Lt(c, a)), And(Gt(a, Min(b, c)), Le(a, Max(b, c)))), (Tuple(Le(a, b), Le(a, c)), And(Le(a, Max(b, c)), Gt(a, Min(b, c)))), (Tuple(Le(a, b), Lt(a, c)), ITE(b < c, And(Lt(a, c), Gt(a, b)), And(Le(a, b), Ge(a, c)))), (Tuple(Lt(a, b), Lt(a, c)), And(Lt(a, Max(b, c)), Ge(a, Min(b, c)))))
    return _matchers_xor

def simplify_univariate(expr):
    from sympy.functions.elementary.piecewise import Piecewise
    from sympy.core.relational import Eq, Ne
    if not isinstance(expr, BooleanFunction):
        return expr
    if expr.atoms(Eq, Ne):
        return expr
    c = expr
    free = c.free_symbols
    if len(free) != 1:
        return c
    x = free.pop()
    ok, i = Piecewise((0, c), evaluate=False)._intervals(x, err_on_Eq=True)
    if not ok:
        return c
    if not i:
        return false
    args = []
    for a, b, _, _ in i:
        if a is S.NegativeInfinity:
            if b is S.Infinity:
                c = true
            elif c.subs(x, b) == True:
                c = x <= b
            else:
                c = x < b
        else:
            incl_a = c.subs(x, a) == True
            incl_b = c.subs(x, b) == True
            if incl_a and incl_b:
                if b.is_infinite:
                    c = x >= a
                else:
                    c = And(a <= x, x <= b)
            elif incl_a:
                c = And(a <= x, x < b)
            elif incl_b:
                if b.is_infinite:
                    c = x > a
                else:
                    c = And(a < x, x <= b)
            else:
                c = And(a < x, x < b)
        args.append(c)
    return Or(*args)
BooleanGates = (And, Or, Xor, Nand, Nor, Not, Xnor, ITE)

def gateinputcount(expr):
    if not isinstance(expr, Boolean):
        raise TypeError('Expression must be Boolean')
    if isinstance(expr, BooleanGates):
        return len(expr.args) + sum((gateinputcount(x) for x in expr.args))
    return 0