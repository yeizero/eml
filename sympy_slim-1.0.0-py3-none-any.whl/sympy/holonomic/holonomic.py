from __future__ import annotations
from sympy.core import Add, Mul, Pow
from sympy.core.numbers import NaN, Infinity, NegativeInfinity, Float, I, pi, equal_valued, int_valued
from sympy.core.singleton import S
from sympy.core.sorting import ordered
from sympy.core.symbol import Dummy, Symbol
from sympy.core.sympify import sympify
from sympy.external.mpmath import mp
from sympy.functions.combinatorial.factorials import binomial, factorial, rf
from sympy.functions.elementary.exponential import exp_polar, exp, log
from sympy.functions.elementary.hyperbolic import cosh, sinh
from sympy.functions.elementary.miscellaneous import sqrt
from sympy.functions.elementary.trigonometric import cos, sin, sinc
from sympy.functions.special.error_functions import Ci, Shi, Si, erf, erfc, erfi
from sympy.functions.special.gamma_functions import gamma
from sympy.functions.special.hyper import hyper, meijerg
from sympy.integrals import meijerint
from sympy.matrices import Matrix
from sympy.polys.rings import PolyElement
from sympy.polys.fields import FracElement
from sympy.polys.domains import QQ, RR
from sympy.polys.polyclasses import DMF
from sympy.polys.polyroots import roots
from sympy.polys.polytools import Poly
from sympy.polys.matrices import DomainMatrix
from sympy.printing import sstr
from sympy.series.limits import limit
from sympy.series.order import Order
from sympy.simplify.hyperexpand import hyperexpand
from sympy.simplify.simplify import nsimplify
from sympy.solvers.solvers import solve
from .recurrence import HolonomicSequence, RecurrenceOperator, RecurrenceOperators
from .holonomicerrors import NotPowerSeriesError, NotHyperSeriesError, SingularityError, NotHolonomicError

def _find_nonzero_solution(r, homosys):
    ones = lambda shape: DomainMatrix.ones(shape, r.domain)
    particular, nullspace = r._solve(homosys)
    nullity = nullspace.shape[0]
    nullpart = ones((1, nullity)) * nullspace
    sol = (particular + nullpart).transpose()
    return sol

def DifferentialOperators(base, generator):
    ring = DifferentialOperatorAlgebra(base, generator)
    return (ring, ring.derivative_operator)

class DifferentialOperatorAlgebra:

    def __init__(self, base, generator):
        self.base = base
        self.derivative_operator = DifferentialOperator([base.zero, base.one], self)
        if generator is None:
            self.gen_symbol = Symbol('Dx', commutative=False)
        elif isinstance(generator, str):
            self.gen_symbol = Symbol(generator, commutative=False)
        elif isinstance(generator, Symbol):
            self.gen_symbol = generator

    def __str__(self):
        string = 'Univariate Differential Operator Algebra in intermediate ' + sstr(self.gen_symbol) + ' over the base ring ' + self.base.__str__()
        return string
    __repr__ = __str__

    def __eq__(self, other):
        return self.base == other.base and self.gen_symbol == other.gen_symbol

class DifferentialOperator:
    _op_priority = 20

    def __init__(self, list_of_poly, parent):
        self.parent = parent
        base = self.parent.base
        self.x = base.gens[0] if isinstance(base.gens[0], Symbol) else base.gens[0][0]
        for i, j in enumerate(list_of_poly):
            if not isinstance(j, base.dtype):
                list_of_poly[i] = base.from_sympy(sympify(j))
            else:
                list_of_poly[i] = base.from_sympy(base.to_sympy(j))
        self.listofpoly = list_of_poly
        self.order = len(self.listofpoly) - 1

    def __mul__(self, other):
        listofself = self.listofpoly
        if isinstance(other, DifferentialOperator):
            listofother = other.listofpoly
        elif isinstance(other, self.parent.base.dtype):
            listofother = [other]
        else:
            listofother = [self.parent.base.from_sympy(sympify(other))]

        def _mul_dmp_diffop(b, listofother):
            if isinstance(listofother, list):
                return [i * b for i in listofother]
            return [b * listofother]
        sol = _mul_dmp_diffop(listofself[0], listofother)

        def _mul_Dxi_b(b):
            sol1 = [self.parent.base.zero]
            sol2 = []
            if isinstance(b, list):
                for i in b:
                    sol1.append(i)
                    sol2.append(i.diff())
            else:
                sol1.append(self.parent.base.from_sympy(b))
                sol2.append(self.parent.base.from_sympy(b).diff())
            return _add_lists(sol1, sol2)
        for i in range(1, len(listofself)):
            listofother = _mul_Dxi_b(listofother)
            sol = _add_lists(sol, _mul_dmp_diffop(listofself[i], listofother))
        return DifferentialOperator(sol, self.parent)

    def __rmul__(self, other):
        if not isinstance(other, DifferentialOperator):
            if not isinstance(other, self.parent.base.dtype):
                other = self.parent.base.from_sympy(sympify(other))
            sol = [other * j for j in self.listofpoly]
            return DifferentialOperator(sol, self.parent)

    def __add__(self, other):
        if isinstance(other, DifferentialOperator):
            sol = _add_lists(self.listofpoly, other.listofpoly)
            return DifferentialOperator(sol, self.parent)
        list_self = self.listofpoly
        if not isinstance(other, self.parent.base.dtype):
            list_other = [self.parent.base.from_sympy(sympify(other))]
        else:
            list_other = [other]
        sol = [list_self[0] + list_other[0]] + list_self[1:]
        return DifferentialOperator(sol, self.parent)
    __radd__ = __add__

    def __sub__(self, other):
        return self + -1 * other

    def __rsub__(self, other):
        return -1 * self + other

    def __neg__(self):
        return -1 * self

    def __truediv__(self, other):
        return self * (S.One / other)

    def __pow__(self, n):
        if n == 1:
            return self
        result = DifferentialOperator([self.parent.base.one], self.parent)
        if n == 0:
            return result
        if self.listofpoly == self.parent.derivative_operator.listofpoly:
            sol = [self.parent.base.zero] * n + [self.parent.base.one]
            return DifferentialOperator(sol, self.parent)
        x = self
        while True:
            if n % 2:
                result *= x
            n >>= 1
            if not n:
                break
            x *= x
        return result

    def __str__(self):
        listofpoly = self.listofpoly
        print_str = ''
        for i, j in enumerate(listofpoly):
            if j == self.parent.base.zero:
                continue
            j = self.parent.base.to_sympy(j)
            if i == 0:
                print_str += '(' + sstr(j) + ')'
                continue
            if print_str:
                print_str += ' + '
            if i == 1:
                print_str += '(' + sstr(j) + ')*%s' % self.parent.gen_symbol
                continue
            print_str += '(' + sstr(j) + ')' + '*%s**' % self.parent.gen_symbol + sstr(i)
        return print_str
    __repr__ = __str__

    def __eq__(self, other):
        if isinstance(other, DifferentialOperator):
            return self.listofpoly == other.listofpoly and self.parent == other.parent
        return self.listofpoly[0] == other and all((i is self.parent.base.zero for i in self.listofpoly[1:]))

    def is_singular(self, x0):
        base = self.parent.base
        return x0 in roots(base.to_sympy(self.listofpoly[-1]), self.x)

class HolonomicFunction:
    _op_priority = 20

    def __init__(self, annihilator, x, x0=0, y0=None):
        self.y0 = y0
        self.x0 = x0
        self.annihilator = annihilator
        self.x = x

    def __str__(self):
        if self._have_init_cond():
            str_sol = 'HolonomicFunction(%s, %s, %s, %s)' % (str(self.annihilator), sstr(self.x), sstr(self.x0), sstr(self.y0))
        else:
            str_sol = 'HolonomicFunction(%s, %s)' % (str(self.annihilator), sstr(self.x))
        return str_sol
    __repr__ = __str__

    def unify(self, other):
        R1 = self.annihilator.parent.base
        R2 = other.annihilator.parent.base
        dom1 = R1.dom
        dom2 = R2.dom
        if R1 == R2:
            return (self, other)
        R = dom1.unify(dom2).old_poly_ring(self.x)
        newparent, _ = DifferentialOperators(R, str(self.annihilator.parent.gen_symbol))
        sol1 = [R1.to_sympy(i) for i in self.annihilator.listofpoly]
        sol2 = [R2.to_sympy(i) for i in other.annihilator.listofpoly]
        sol1 = DifferentialOperator(sol1, newparent)
        sol2 = DifferentialOperator(sol2, newparent)
        sol1 = HolonomicFunction(sol1, self.x, self.x0, self.y0)
        sol2 = HolonomicFunction(sol2, other.x, other.x0, other.y0)
        return (sol1, sol2)

    def is_singularics(self):
        if isinstance(self.y0, dict):
            return True
        elif isinstance(self.y0, list):
            return False

    def _have_init_cond(self):
        return bool(self.y0)

    def _singularics_to_ord(self):
        a = list(self.y0)[0]
        b = self.y0[a]
        if len(self.y0) == 1 and a == int(a) and (a > 0):
            a = int(a)
            y0 = [S.Zero] * a
            y0 += [j * factorial(a + i) for i, j in enumerate(b)]
            return HolonomicFunction(self.annihilator, self.x, self.x0, y0)

    def __add__(self, other):
        if self.annihilator.parent.base != other.annihilator.parent.base:
            a, b = self.unify(other)
            return a + b
        deg1 = self.annihilator.order
        deg2 = other.annihilator.order
        dim = max(deg1, deg2)
        R = self.annihilator.parent.base
        K = R.get_field()
        rowsself = [self.annihilator]
        rowsother = [other.annihilator]
        gen = self.annihilator.parent.derivative_operator
        for i in range(dim - deg1):
            diff1 = gen * rowsself[-1]
            rowsself.append(diff1)
        for i in range(dim - deg2):
            diff2 = gen * rowsother[-1]
            rowsother.append(diff2)
        row = rowsself + rowsother
        r = []
        for expr in row:
            p = []
            for i in range(dim + 1):
                if i >= len(expr.listofpoly):
                    p.append(K.zero)
                else:
                    p.append(K.new(expr.listofpoly[i].to_list()))
            r.append(p)
        r = DomainMatrix(r, (len(row), dim + 1), K).transpose()
        homosys = DomainMatrix.zeros((dim + 1, 1), K)
        sol = _find_nonzero_solution(r, homosys)
        while sol.is_zero_matrix:
            dim += 1
            diff1 = gen * rowsself[-1]
            rowsself.append(diff1)
            diff2 = gen * rowsother[-1]
            rowsother.append(diff2)
            row = rowsself + rowsother
            r = []
            for expr in row:
                p = []
                for i in range(dim + 1):
                    if i >= len(expr.listofpoly):
                        p.append(K.zero)
                    else:
                        p.append(K.new(expr.listofpoly[i].to_list()))
                r.append(p)
            r = DomainMatrix(r, (len(row), dim + 1), K).transpose()
            homosys = DomainMatrix.zeros((dim + 1, 1), K)
            sol = _find_nonzero_solution(r, homosys)
        sol = sol.flat()[:dim + 1 - deg1]
        sol1 = _normalize(sol, self.annihilator.parent)
        sol = sol1 * self.annihilator
        sol = _normalize(sol.listofpoly, self.annihilator.parent, negative=False)
        if not (self._have_init_cond() and other._have_init_cond()):
            return HolonomicFunction(sol, self.x)
        if self.is_singularics() == False and other.is_singularics() == False:
            if self.x0 == other.x0:
                y1 = _extend_y0(self, sol.order)
                y2 = _extend_y0(other, sol.order)
                y0 = [a + b for a, b in zip(y1, y2)]
                return HolonomicFunction(sol, self.x, self.x0, y0)
            selfat0 = self.annihilator.is_singular(0)
            otherat0 = other.annihilator.is_singular(0)
            if self.x0 == 0 and (not selfat0) and (not otherat0):
                return self + other.change_ics(0)
            if other.x0 == 0 and (not selfat0) and (not otherat0):
                return self.change_ics(0) + other
            selfatx0 = self.annihilator.is_singular(self.x0)
            otheratx0 = other.annihilator.is_singular(self.x0)
            if not selfatx0 and (not otheratx0):
                return self + other.change_ics(self.x0)
            return self.change_ics(other.x0) + other
        if self.x0 != other.x0:
            return HolonomicFunction(sol, self.x)
        y1 = None
        y2 = None
        if self.is_singularics() == False and other.is_singularics() == True:
            _y0 = [j / factorial(i) for i, j in enumerate(self.y0)]
            y1 = {S.Zero: _y0}
            y2 = other.y0
        elif self.is_singularics() == True and other.is_singularics() == False:
            _y0 = [j / factorial(i) for i, j in enumerate(other.y0)]
            y1 = self.y0
            y2 = {S.Zero: _y0}
        elif self.is_singularics() == True and other.is_singularics() == True:
            y1 = self.y0
            y2 = other.y0
        y0 = {}
        for i in y1:
            if i in y2:
                y0[i] = [a + b for a, b in zip(y1[i], y2[i])]
            else:
                y0[i] = y1[i]
        for i in y2:
            if i not in y1:
                y0[i] = y2[i]
        return HolonomicFunction(sol, self.x, self.x0, y0)

    def integrate(self, limits, initcond=False):
        D = self.annihilator.parent.derivative_operator
        if self.is_singularics() == True:
            r = self._singularics_to_ord()
            if r:
                return r.integrate(limits, initcond=initcond)
            y0 = {}
            for i in self.y0:
                c = self.y0[i]
                c2 = []
                for j, cj in enumerate(c):
                    if cj == 0:
                        c2.append(S.Zero)
                    elif i + j + 1 == 0:
                        raise NotImplementedError('logarithmic terms in the series are not supported')
                    else:
                        c2.append(cj / S(i + j + 1))
                y0[i + 1] = c2
            if hasattr(limits, '__iter__'):
                raise NotImplementedError('Definite integration for singular initial conditions')
            return HolonomicFunction(self.annihilator * D, self.x, self.x0, y0)
        if not self._have_init_cond():
            if initcond:
                return HolonomicFunction(self.annihilator * D, self.x, self.x0, [S.Zero])
            return HolonomicFunction(self.annihilator * D, self.x)
        if hasattr(limits, '__iter__'):
            if len(limits) == 3 and limits[0] == self.x:
                x0 = self.x0
                a = limits[1]
                b = limits[2]
                definite = True
        else:
            definite = False
        y0 = [S.Zero]
        y0 += self.y0
        indefinite_integral = HolonomicFunction(self.annihilator * D, self.x, self.x0, y0)
        if not definite:
            return indefinite_integral
        if x0 != a:
            try:
                indefinite_expr = indefinite_integral.to_expr()
            except (NotHyperSeriesError, NotPowerSeriesError):
                indefinite_expr = None
            if indefinite_expr:
                lower = indefinite_expr.subs(self.x, a)
                if isinstance(lower, NaN):
                    lower = indefinite_expr.limit(self.x, a)
            else:
                lower = indefinite_integral.evalf(a)
            if b == self.x:
                y0[0] = y0[0] - lower
                return HolonomicFunction(self.annihilator * D, self.x, x0, y0)
            elif S(b).is_Number:
                if indefinite_expr:
                    upper = indefinite_expr.subs(self.x, b)
                    if isinstance(upper, NaN):
                        upper = indefinite_expr.limit(self.x, b)
                else:
                    upper = indefinite_integral.evalf(b)
                return upper - lower
        if b == self.x:
            return HolonomicFunction(self.annihilator * D, self.x, a, y0)
        elif S(b).is_Number:
            try:
                s = HolonomicFunction(self.annihilator * D, self.x, a, y0).to_expr()
                indefinite = s.subs(self.x, b)
                if not isinstance(indefinite, NaN):
                    return indefinite
                else:
                    return s.limit(self.x, b)
            except (NotHyperSeriesError, NotPowerSeriesError):
                return HolonomicFunction(self.annihilator * D, self.x, a, y0).evalf(b)
        return HolonomicFunction(self.annihilator * D, self.x)

    def diff(self, *args, **kwargs):
        kwargs.setdefault('evaluate', True)
        if args:
            if args[0] != self.x:
                return S.Zero
            elif len(args) == 2:
                sol = self
                for i in range(args[1]):
                    sol = sol.diff(args[0])
                return sol
        ann = self.annihilator
        if ann.listofpoly[0] == ann.parent.base.zero and ann.order == 1:
            return S.Zero
        elif ann.listofpoly[0] == ann.parent.base.zero:
            sol = DifferentialOperator(ann.listofpoly[1:], ann.parent)
            if self._have_init_cond():
                if self.is_singularics() == False:
                    return HolonomicFunction(sol, self.x, self.x0, self.y0[1:])
                return HolonomicFunction(sol, self.x)
            else:
                return HolonomicFunction(sol, self.x)
        R = ann.parent.base
        K = R.get_field()
        seq_dmf = [K.new(i.to_list()) for i in ann.listofpoly]
        rhs = [i / seq_dmf[0] for i in seq_dmf[1:]]
        rhs.insert(0, K.zero)
        sol = _derivate_diff_eq(rhs, K)
        sol = _add_lists(sol, [K.zero, K.one])
        sol = _normalize(sol[1:], self.annihilator.parent, negative=False)
        if not self._have_init_cond() or self.is_singularics() == True:
            return HolonomicFunction(sol, self.x)
        y0 = _extend_y0(self, sol.order + 1)[1:]
        return HolonomicFunction(sol, self.x, self.x0, y0)

    def __eq__(self, other):
        if self.annihilator != other.annihilator or self.x != other.x:
            return False
        if self._have_init_cond() and other._have_init_cond():
            return self.x0 == other.x0 and self.y0 == other.y0
        return True

    def __mul__(self, other):
        ann_self = self.annihilator
        if not isinstance(other, HolonomicFunction):
            other = sympify(other)
            if other.has(self.x):
                raise NotImplementedError(" Can't multiply a HolonomicFunction and expressions/functions.")
            if not self._have_init_cond():
                return self
            y0 = _extend_y0(self, ann_self.order)
            y1 = [(Poly.new(j, self.x) * other).rep for j in y0]
            return HolonomicFunction(ann_self, self.x, self.x0, y1)
        if self.annihilator.parent.base != other.annihilator.parent.base:
            a, b = self.unify(other)
            return a * b
        ann_other = other.annihilator
        a = ann_self.order
        b = ann_other.order
        R = ann_self.parent.base
        K = R.get_field()
        list_self = [K.new(j.to_list()) for j in ann_self.listofpoly]
        list_other = [K.new(j.to_list()) for j in ann_other.listofpoly]
        self_red = [-list_self[i] / list_self[a] for i in range(a)]
        other_red = [-list_other[i] / list_other[b] for i in range(b)]
        coeff_mul = [[K.zero for i in range(b + 1)] for j in range(a + 1)]
        coeff_mul[0][0] = K.one
        lin_sys_elements = [[coeff_mul[i][j] for i in range(a) for j in range(b)]]
        lin_sys = DomainMatrix(lin_sys_elements, (1, a * b), K).transpose()
        homo_sys = DomainMatrix.zeros((a * b, 1), K)
        sol = _find_nonzero_solution(lin_sys, homo_sys)
        while sol.is_zero_matrix:
            for i in range(a - 1, -1, -1):
                for j in range(b - 1, -1, -1):
                    coeff_mul[i][j + 1] += coeff_mul[i][j]
                    coeff_mul[i + 1][j] += coeff_mul[i][j]
                    if isinstance(coeff_mul[i][j], K.dtype):
                        coeff_mul[i][j] = DMFdiff(coeff_mul[i][j], K)
                    else:
                        coeff_mul[i][j] = coeff_mul[i][j].diff(self.x)
            for i in range(a + 1):
                if coeff_mul[i][b].is_zero:
                    continue
                for j in range(b):
                    coeff_mul[i][j] += other_red[j] * coeff_mul[i][b]
                coeff_mul[i][b] = K.zero
            for j in range(b):
                if coeff_mul[a][j] == 0:
                    continue
                for i in range(a):
                    coeff_mul[i][j] += self_red[i] * coeff_mul[a][j]
                coeff_mul[a][j] = K.zero
            lin_sys_elements.append([coeff_mul[i][j] for i in range(a) for j in range(b)])
            lin_sys = DomainMatrix(lin_sys_elements, (len(lin_sys_elements), a * b), K).transpose()
            sol = _find_nonzero_solution(lin_sys, homo_sys)
        sol_ann = _normalize(sol.flat(), self.annihilator.parent, negative=False)
        if not (self._have_init_cond() and other._have_init_cond()):
            return HolonomicFunction(sol_ann, self.x)
        if self.is_singularics() == False and other.is_singularics() == False:
            if self.x0 == other.x0:
                y0_self = _extend_y0(self, sol_ann.order)
                y0_other = _extend_y0(other, sol_ann.order)
                y0 = [y0_self[0] * y0_other[0]]
                for i in range(1, min(len(y0_self), len(y0_other))):
                    coeff = [[0 for i in range(i + 1)] for j in range(i + 1)]
                    for j in range(i + 1):
                        for k in range(i + 1):
                            if j + k == i:
                                coeff[j][k] = binomial(i, j)
                    sol = 0
                    for j in range(i + 1):
                        for k in range(i + 1):
                            sol += coeff[j][k] * y0_self[j] * y0_other[k]
                    y0.append(sol)
                return HolonomicFunction(sol_ann, self.x, self.x0, y0)
            selfat0 = self.annihilator.is_singular(0)
            otherat0 = other.annihilator.is_singular(0)
            if self.x0 == 0 and (not selfat0) and (not otherat0):
                return self * other.change_ics(0)
            if other.x0 == 0 and (not selfat0) and (not otherat0):
                return self.change_ics(0) * other
            selfatx0 = self.annihilator.is_singular(self.x0)
            otheratx0 = other.annihilator.is_singular(self.x0)
            if not selfatx0 and (not otheratx0):
                return self * other.change_ics(self.x0)
            return self.change_ics(other.x0) * other
        if self.x0 != other.x0:
            return HolonomicFunction(sol_ann, self.x)
        y1 = None
        y2 = None
        if self.is_singularics() == False and other.is_singularics() == True:
            _y0 = [j / factorial(i) for i, j in enumerate(self.y0)]
            y1 = {S.Zero: _y0}
            y2 = other.y0
        elif self.is_singularics() == True and other.is_singularics() == False:
            _y0 = [j / factorial(i) for i, j in enumerate(other.y0)]
            y1 = self.y0
            y2 = {S.Zero: _y0}
        elif self.is_singularics() == True and other.is_singularics() == True:
            y1 = self.y0
            y2 = other.y0
        y0 = {}
        for i in y1:
            for j in y2:
                k = min(len(y1[i]), len(y2[j]))
                c = [sum((y1[i][b] * y2[j][a - b] for b in range(a + 1)), start=S.Zero) for a in range(k)]
                if not i + j in y0:
                    y0[i + j] = c
                else:
                    y0[i + j] = [a + b for a, b in zip(c, y0[i + j])]
        return HolonomicFunction(sol_ann, self.x, self.x0, y0)
    __rmul__ = __mul__

    def __sub__(self, other):
        return self + other * -1

    def __rsub__(self, other):
        return self * -1 + other

    def __neg__(self):
        return -1 * self

    def __truediv__(self, other):
        return self * (S.One / other)

    def __pow__(self, n):
        if self.annihilator.order <= 1:
            ann = self.annihilator
            parent = ann.parent
            if self.y0 is None:
                y0 = None
            else:
                y0 = [list(self.y0)[0] ** n]
            p0 = ann.listofpoly[0]
            p1 = ann.listofpoly[1]
            p0 = (Poly.new(p0, self.x) * n).rep
            sol = [parent.base.to_sympy(i) for i in [p0, p1]]
            dd = DifferentialOperator(sol, parent)
            return HolonomicFunction(dd, self.x, self.x0, y0)
        if n < 0:
            raise NotHolonomicError('Negative Power on a Holonomic Function')
        Dx = self.annihilator.parent.derivative_operator
        result = HolonomicFunction(Dx, self.x, S.Zero, [S.One])
        if n == 0:
            return result
        x = self
        while True:
            if n % 2:
                result *= x
            n >>= 1
            if not n:
                break
            x *= x
        return result

    def degree(self):
        return max((i.degree() for i in self.annihilator.listofpoly))

    def composition(self, expr, *args, **kwargs):
        R = self.annihilator.parent
        a = self.annihilator.order
        diff = expr.diff(self.x)
        listofpoly = self.annihilator.listofpoly
        for i, j in enumerate(listofpoly):
            if isinstance(j, self.annihilator.parent.base.dtype):
                listofpoly[i] = self.annihilator.parent.base.to_sympy(j)
        r = listofpoly[a].subs({self.x: expr})
        subs = [-listofpoly[i].subs({self.x: expr}) / r for i in range(a)]
        coeffs = [S.Zero for i in range(a)]
        coeffs[0] = S.One
        system = [coeffs]
        homogeneous = Matrix([[S.Zero for i in range(a)]]).transpose()
        while True:
            coeffs_next = [p.diff(self.x) for p in coeffs]
            for i in range(a - 1):
                coeffs_next[i + 1] += coeffs[i] * diff
            for i in range(a):
                coeffs_next[i] += coeffs[-1] * subs[i] * diff
            coeffs = coeffs_next
            system.append(coeffs)
            sol, taus = Matrix(system).transpose().gauss_jordan_solve(homogeneous)
            if sol.is_zero_matrix is not True:
                break
        tau = list(taus)[0]
        sol = sol.subs(tau, 1)
        sol = _normalize(sol[0:], R, negative=False)
        if args:
            return HolonomicFunction(sol, self.x, args[0], args[1])
        return HolonomicFunction(sol, self.x)

    def to_sequence(self, lb=True):
        if self.x0 != 0:
            return self.shift_x(self.x0).to_sequence()
        if self.annihilator.is_singular(self.x0):
            return self._frobenius(lb=lb)
        dict1 = {}
        n = Symbol('n', integer=True)
        dom = self.annihilator.parent.base.dom
        R, _ = RecurrenceOperators(dom.old_poly_ring(n), 'Sn')
        for i, j in enumerate(self.annihilator.listofpoly):
            listofdmp = j.all_coeffs()
            degree = len(listofdmp) - 1
            for k in range(degree + 1):
                coeff = listofdmp[degree - k]
                if coeff == 0:
                    continue
                if (i - k, k) in dict1:
                    dict1[i - k, k] += dom.to_sympy(coeff) * rf(n - k + 1, i)
                else:
                    dict1[i - k, k] = dom.to_sympy(coeff) * rf(n - k + 1, i)
        sol = []
        keylist = [i[0] for i in dict1]
        lower = min(keylist)
        upper = max(keylist)
        degree = self.degree()
        smallest_n = lower + degree
        dummys = {}
        eqs = []
        unknowns = []
        for j in range(lower, upper + 1):
            if j in keylist:
                temp = sum((v.subs(n, n - lower) for k, v in dict1.items() if k[0] == j), start=S.Zero)
                sol.append(temp)
            else:
                sol.append(S.Zero)
        sol = RecurrenceOperator(sol, R)
        order = sol.order
        all_roots = roots(R.base.to_sympy(sol.listofpoly[-1]), n, filter='Z')
        all_roots = all_roots.keys()
        if all_roots:
            max_root = max(all_roots) + 1
            smallest_n = max(max_root, smallest_n)
        order += smallest_n
        y0 = _extend_y0(self, order)
        u0 = [j / factorial(i) for i, j in enumerate(y0)]
        if len(u0) < order:
            for i in range(degree):
                eq = S.Zero
                for j in dict1:
                    if i + j[0] < 0:
                        dummys[i + j[0]] = S.Zero
                    elif i + j[0] < len(u0):
                        dummys[i + j[0]] = u0[i + j[0]]
                    elif not i + j[0] in dummys:
                        dummys[i + j[0]] = Symbol('C_%s' % (i + j[0]))
                        unknowns.append(dummys[i + j[0]])
                    if j[1] <= i:
                        eq += dict1[j].subs(n, i) * dummys[i + j[0]]
                eqs.append(eq)
            soleqs = solve(eqs, *unknowns)
            if isinstance(soleqs, dict):
                for i in range(len(u0), order):
                    if i not in dummys:
                        dummys[i] = Symbol('C_%s' % i)
                    if dummys[i] in soleqs:
                        u0.append(soleqs[dummys[i]])
                    else:
                        u0.append(dummys[i])
                if lb:
                    return [(HolonomicSequence(sol, u0), smallest_n)]
                return [HolonomicSequence(sol, u0)]
            for i in range(len(u0), order):
                if i not in dummys:
                    dummys[i] = Symbol('C_%s' % i)
                s = False
                for j in soleqs:
                    if dummys[i] in j:
                        u0.append(j[dummys[i]])
                        s = True
                if not s:
                    u0.append(dummys[i])
        if lb:
            return [(HolonomicSequence(sol, u0), smallest_n)]
        return [HolonomicSequence(sol, u0)]

    def _frobenius(self, lb=True):
        indicialroots = self._indicial()
        reals = []
        compl = []
        for i in ordered(indicialroots.keys()):
            if i.is_real:
                reals.extend([i] * indicialroots[i])
            else:
                a, b = i.as_real_imag()
                compl.extend([(i, a, b)] * indicialroots[i])
        compl.sort(key=lambda x: x[1])
        compl.sort(key=lambda x: x[2])
        reals.sort()
        grp = []
        for i in reals:
            if len(grp) == 0:
                grp.append([i])
                continue
            for j in grp:
                if int_valued(j[0] - i):
                    j.append(i)
                    break
            else:
                grp.append([i])
        independent = all((len(i) == 1 for i in grp))
        allpos = all((i >= 0 for i in reals))
        allint = all((int_valued(i) for i in reals))
        if self.is_singularics() == True:
            rootstoconsider = []
            for i in ordered(self.y0.keys()):
                for j in ordered(indicialroots.keys()):
                    if equal_valued(j, i):
                        rootstoconsider.append(i)
        elif allpos and allint:
            rootstoconsider = [min(reals)]
        elif independent:
            rootstoconsider = [i[0] for i in grp] + [j[0] for j in compl]
        elif not allint:
            rootstoconsider = [i for i in reals if not int(i) == i]
        elif not allpos:
            if not self._have_init_cond() or S(self.y0[0]).is_finite == False:
                rootstoconsider = [min(reals)]
            else:
                posroots = [i for i in reals if i >= 0]
                rootstoconsider = [min(posroots)]
        n = Symbol('n', integer=True)
        dom = self.annihilator.parent.base.dom
        R, _ = RecurrenceOperators(dom.old_poly_ring(n), 'Sn')
        finalsol = []
        char = ord('C')
        for p in rootstoconsider:
            dict1 = {}
            for i, j in enumerate(self.annihilator.listofpoly):
                listofdmp = j.all_coeffs()
                degree = len(listofdmp) - 1
                for k in range(degree + 1):
                    coeff = listofdmp[degree - k]
                    if coeff == 0:
                        continue
                    if (i - k, k - i) in dict1:
                        dict1[i - k, k - i] += dom.to_sympy(coeff) * rf(n - k + 1 + p, i)
                    else:
                        dict1[i - k, k - i] = dom.to_sympy(coeff) * rf(n - k + 1 + p, i)
            sol = []
            keylist = [i[0] for i in dict1]
            lower = min(keylist)
            upper = max(keylist)
            degree = max((i[1] for i in dict1))
            degree2 = min((i[1] for i in dict1))
            smallest_n = lower + degree
            dummys = {}
            eqs = []
            unknowns = []
            for j in range(lower, upper + 1):
                if j in keylist:
                    temp = sum((v.subs(n, n - lower) for k, v in dict1.items() if k[0] == j), start=S.Zero)
                    sol.append(temp)
                else:
                    sol.append(S.Zero)
            sol = RecurrenceOperator(sol, R)
            order = sol.order
            all_roots = roots(R.base.to_sympy(sol.listofpoly[-1]), n, filter='Z')
            all_roots = all_roots.keys()
            if all_roots:
                max_root = max(all_roots) + 1
                smallest_n = max(max_root, smallest_n)
            order += smallest_n
            u0 = []
            if self.is_singularics() == True:
                u0 = self.y0[p]
            elif self.is_singularics() == False and p >= 0 and (int(p) == p) and (len(rootstoconsider) == 1):
                y0 = _extend_y0(self, order + int(p))
                if len(y0) > int(p):
                    u0 = [y0[i] / factorial(i) for i in range(int(p), len(y0))]
            if len(u0) < order:
                for i in range(degree2, degree):
                    eq = S.Zero
                    for j in dict1:
                        if i + j[0] < 0:
                            dummys[i + j[0]] = S.Zero
                        elif i + j[0] < len(u0):
                            dummys[i + j[0]] = u0[i + j[0]]
                        elif not i + j[0] in dummys:
                            letter = chr(char) + '_%s' % (i + j[0])
                            dummys[i + j[0]] = Symbol(letter)
                            unknowns.append(dummys[i + j[0]])
                        if j[1] <= i:
                            eq += dict1[j].subs(n, i) * dummys[i + j[0]]
                    eqs.append(eq)
                soleqs = solve(eqs, *unknowns)
                if isinstance(soleqs, dict):
                    for i in range(len(u0), order):
                        if i not in dummys:
                            letter = chr(char) + '_%s' % i
                            dummys[i] = Symbol(letter)
                        if dummys[i] in soleqs:
                            u0.append(soleqs[dummys[i]])
                        else:
                            u0.append(dummys[i])
                    if lb:
                        finalsol.append((HolonomicSequence(sol, u0), p, smallest_n))
                        continue
                    else:
                        finalsol.append((HolonomicSequence(sol, u0), p))
                        continue
                for i in range(len(u0), order):
                    if i not in dummys:
                        letter = chr(char) + '_%s' % i
                        dummys[i] = Symbol(letter)
                    s = False
                    for j in soleqs:
                        if dummys[i] in j:
                            u0.append(j[dummys[i]])
                            s = True
                    if not s:
                        u0.append(dummys[i])
            if lb:
                finalsol.append((HolonomicSequence(sol, u0), p, smallest_n))
            else:
                finalsol.append((HolonomicSequence(sol, u0), p))
            char += 1
        return finalsol

    def series(self, n=6, coefficient=False, order=True, _recur=None):
        if _recur is None:
            recurrence = self.to_sequence()
        else:
            recurrence = _recur
        if isinstance(recurrence, tuple) and len(recurrence) == 2:
            recurrence = recurrence[0]
            constantpower = 0
        elif isinstance(recurrence, tuple) and len(recurrence) == 3:
            constantpower = recurrence[1]
            recurrence = recurrence[0]
        elif len(recurrence) == 1 and len(recurrence[0]) == 2:
            recurrence = recurrence[0][0]
            constantpower = 0
        elif len(recurrence) == 1 and len(recurrence[0]) == 3:
            constantpower = recurrence[0][1]
            recurrence = recurrence[0][0]
        else:
            return [self.series(_recur=i) for i in recurrence]
        n = n - int(constantpower)
        l = len(recurrence.u0) - 1
        k = recurrence.recurrence.order
        x = self.x
        x0 = self.x0
        seq_dmp = recurrence.recurrence.listofpoly
        R = recurrence.recurrence.parent.base
        K = R.get_field()
        seq = [K.new(j.to_list()) for j in seq_dmp]
        sub = [-seq[i] / seq[k] for i in range(k)]
        sol = list(recurrence.u0)
        if l + 1 < n:
            for i in range(l + 1 - k, n - k):
                coeff = sum((DMFsubs(sub[j], i) * sol[i + j] for j in range(k) if i + j >= 0), start=S.Zero)
                sol.append(coeff)
        if coefficient:
            return sol
        ser = sum((x ** (i + constantpower) * j for i, j in enumerate(sol)), start=S.Zero)
        if order:
            ser += Order(x ** (n + int(constantpower)), x)
        if x0 != 0:
            return ser.subs(x, x - x0)
        return ser

    def _indicial(self):
        if self.x0 != 0:
            return self.shift_x(self.x0)._indicial()
        list_coeff = self.annihilator.listofpoly
        R = self.annihilator.parent.base
        x = self.x
        s = R.zero
        y = R.one

        def _pole_degree(poly):
            root_all = roots(R.to_sympy(poly), x, filter='Z')
            if 0 in root_all.keys():
                return root_all[0]
            else:
                return 0
        degree = max((j.degree() for j in list_coeff))
        inf = 10 * (max(1, degree) + max(1, self.annihilator.order))
        deg = lambda q: inf if q.is_zero else _pole_degree(q)
        b = min((deg(q) - j for j, q in enumerate(list_coeff)))
        for i, j in enumerate(list_coeff):
            listofdmp = j.all_coeffs()
            degree = len(listofdmp) - 1
            if 0 <= i + b <= degree:
                s = s + listofdmp[degree - i - b] * y
            y *= R.from_sympy(x - i)
        return roots(R.to_sympy(s), x)

    def evalf(self, points, method='RK4', h=0.05, derivatives=False):
        from sympy.holonomic.numerical import _evalf
        lp = False
        if not hasattr(points, '__iter__'):
            lp = True
            b = S(points)
            if self.x0 == b:
                return _evalf(self, [b], method=method, derivatives=derivatives)[-1]
            if not b.is_Number:
                raise NotImplementedError
            a = self.x0
            if a > b:
                h = -h
            n = int((b - a) / h)
            points = [a + h]
            for i in range(n - 1):
                points.append(points[-1] + h)
        for i in roots(self.annihilator.parent.base.to_sympy(self.annihilator.listofpoly[-1]), self.x):
            if i == self.x0 or i in points:
                raise SingularityError(self, i)
        if lp:
            return _evalf(self, points, method=method, derivatives=derivatives)[-1]
        return _evalf(self, points, method=method, derivatives=derivatives)

    def change_x(self, z):
        dom = self.annihilator.parent.base.dom
        R = dom.old_poly_ring(z)
        parent, _ = DifferentialOperators(R, 'Dx')
        sol = [R(j.to_list()) for j in self.annihilator.listofpoly]
        sol = DifferentialOperator(sol, parent)
        return HolonomicFunction(sol, z, self.x0, self.y0)

    def shift_x(self, a):
        x = self.x
        listaftershift = self.annihilator.listofpoly
        base = self.annihilator.parent.base
        sol = [base.from_sympy(base.to_sympy(i).subs(x, x + a)) for i in listaftershift]
        sol = DifferentialOperator(sol, self.annihilator.parent)
        x0 = self.x0 - a
        if not self._have_init_cond():
            return HolonomicFunction(sol, x)
        return HolonomicFunction(sol, x, x0, self.y0)

    def to_hyper(self, as_list=False, _recur=None):
        if _recur is None:
            recurrence = self.to_sequence()
        else:
            recurrence = _recur
        if isinstance(recurrence, tuple) and len(recurrence) == 2:
            smallest_n = recurrence[1]
            recurrence = recurrence[0]
            constantpower = 0
        elif isinstance(recurrence, tuple) and len(recurrence) == 3:
            smallest_n = recurrence[2]
            constantpower = recurrence[1]
            recurrence = recurrence[0]
        elif len(recurrence) == 1 and len(recurrence[0]) == 2:
            smallest_n = recurrence[0][1]
            recurrence = recurrence[0][0]
            constantpower = 0
        elif len(recurrence) == 1 and len(recurrence[0]) == 3:
            smallest_n = recurrence[0][2]
            constantpower = recurrence[0][1]
            recurrence = recurrence[0][0]
        else:
            sol = self.to_hyper(as_list=as_list, _recur=recurrence[0])
            for i in recurrence[1:]:
                sol += self.to_hyper(as_list=as_list, _recur=i)
            return sol
        u0 = recurrence.u0
        r = recurrence.recurrence
        x = self.x
        x0 = self.x0
        m = r.order
        if m == 0:
            nonzeroterms = roots(r.parent.base.to_sympy(r.listofpoly[0]), recurrence.n, filter='R')
            sol = S.Zero
            for j, i in enumerate(nonzeroterms):
                if i < 0 or not int_valued(i):
                    continue
                i = int(i)
                if i < len(u0):
                    if isinstance(u0[i], (PolyElement, FracElement)):
                        u0[i] = u0[i].as_expr()
                    sol += u0[i] * x ** i
                else:
                    sol += Symbol('C_%s' % j) * x ** i
            if isinstance(sol, (PolyElement, FracElement)):
                sol = sol.as_expr() * x ** constantpower
            else:
                sol = sol * x ** constantpower
            if as_list:
                if x0 != 0:
                    return [(sol.subs(x, x - x0),)]
                return [(sol,)]
            if x0 != 0:
                return sol.subs(x, x - x0)
            return sol
        if smallest_n + m > len(u0):
            raise NotImplementedError("Can't compute sufficient Initial Conditions")
        if any((i != r.parent.base.zero for i in r.listofpoly[1:-1])):
            raise NotHyperSeriesError(self, self.x0)
        a = r.listofpoly[0]
        b = r.listofpoly[-1]
        if isinstance(a.LC(), (PolyElement, FracElement)):
            c = -(S(a.LC().as_expr()) * m ** a.degree()) / (S(b.LC().as_expr()) * m ** b.degree())
        else:
            c = -(S(a.LC()) * m ** a.degree()) / (S(b.LC()) * m ** b.degree())
        sol = 0
        arg1 = roots(r.parent.base.to_sympy(a), recurrence.n)
        arg2 = roots(r.parent.base.to_sympy(b), recurrence.n)
        if as_list:
            listofsol = []
        for i in range(smallest_n + m):
            if i < smallest_n:
                if as_list:
                    listofsol.append(((S(u0[i]) * x ** (i + constantpower)).subs(x, x - x0),))
                else:
                    sol += S(u0[i]) * x ** i
                continue
            if S(u0[i]) == 0:
                continue
            ap = []
            bq = []
            for k in ordered(arg1.keys()):
                ap.extend([nsimplify((i - k) / m)] * arg1[k])
            for k in ordered(arg2.keys()):
                bq.extend([nsimplify((i - k) / m)] * arg2[k])
            if 1 in bq:
                bq.remove(1)
            else:
                ap.append(1)
            if as_list:
                listofsol.append(((S(u0[i]) * x ** (i + constantpower)).subs(x, x - x0), hyper(ap, bq, c * x ** m).subs(x, x - x0)))
            else:
                sol += S(u0[i]) * hyper(ap, bq, c * x ** m) * x ** i
        if as_list:
            return listofsol
        sol = sol * x ** constantpower
        if x0 != 0:
            return sol.subs(x, x - x0)
        return sol

    def to_expr(self):
        return hyperexpand(self.to_hyper()).simplify()

    def change_ics(self, b, lenics=None):
        symbolic = True
        if lenics is None and len(self.y0) > self.annihilator.order:
            lenics = len(self.y0)
        dom = self.annihilator.parent.base.domain
        try:
            sol = expr_to_holonomic(self.to_expr(), x=self.x, x0=b, lenics=lenics, domain=dom)
        except (NotPowerSeriesError, NotHyperSeriesError):
            symbolic = False
        if symbolic and sol.x0 == b:
            return sol
        y0 = self.evalf(b, derivatives=True)
        return HolonomicFunction(self.annihilator, self.x, b, y0)

    def to_meijerg(self):
        rep = self.to_hyper(as_list=True)
        sol = S.Zero
        for i in rep:
            if len(i) == 1:
                sol += i[0]
            elif len(i) == 2:
                sol += i[0] * _hyper_to_meijerg(i[1])
        return sol

def from_hyper(func, x0=0, evalf=False):
    a = func.ap
    b = func.bq
    z = func.args[2]
    x = z.atoms(Symbol).pop()
    R, Dx = DifferentialOperators(QQ.old_poly_ring(x), 'Dx')
    xDx = x * Dx
    r1 = 1
    for ai in a:
        r1 *= xDx + ai
    xDx_1 = xDx - 1
    r2 = Dx
    for bi in b:
        r2 *= xDx_1 + bi
    sol = r1 - r2
    simp = hyperexpand(func)
    if simp in (Infinity, NegativeInfinity):
        return HolonomicFunction(sol, x).composition(z)
    if not isinstance(simp, hyper):
        y0 = _find_conditions(simp, x, x0, sol.order, use_limit=False)
        while not y0:
            x0 += 1
            y0 = _find_conditions(simp, x, x0, sol.order, use_limit=False)
        return HolonomicFunction(sol, x).composition(z, x0, y0)
    if isinstance(simp, hyper):
        x0 = 1
        y0 = _find_conditions(simp, x, x0, sol.order, evalf, use_limit=False)
        while not y0:
            x0 += 1
            y0 = _find_conditions(simp, x, x0, sol.order, evalf, use_limit=False)
        return HolonomicFunction(sol, x).composition(z, x0, y0)
    return HolonomicFunction(sol, x).composition(z)

def from_meijerg(func, x0=0, evalf=False, initcond=True, domain=QQ):
    a = func.ap
    b = func.bq
    n = len(func.an)
    m = len(func.bm)
    p = len(a)
    z = func.args[2]
    x = z.atoms(Symbol).pop()
    R, Dx = DifferentialOperators(domain.old_poly_ring(x), 'Dx')
    xDx = x * Dx
    xDx1 = xDx + 1
    r1 = x * (-1) ** (m + n - p)
    for ai in a:
        r1 *= xDx1 - ai
    r2 = 1
    for bi in b:
        r2 *= xDx - bi
    sol = r1 - r2
    if not initcond:
        return HolonomicFunction(sol, x).composition(z)
    simp = hyperexpand(func)
    if simp in (Infinity, NegativeInfinity):
        return HolonomicFunction(sol, x).composition(z)
    if not isinstance(simp, meijerg):
        y0 = _find_conditions(simp, x, x0, sol.order, use_limit=False)
        while not y0:
            x0 += 1
            y0 = _find_conditions(simp, x, x0, sol.order, use_limit=False)
        return HolonomicFunction(sol, x).composition(z, x0, y0)
    if isinstance(simp, meijerg):
        x0 = 1
        y0 = _find_conditions(simp, x, x0, sol.order, evalf, use_limit=False)
        while not y0:
            x0 += 1
            y0 = _find_conditions(simp, x, x0, sol.order, evalf, use_limit=False)
        return HolonomicFunction(sol, x).composition(z, x0, y0)
    return HolonomicFunction(sol, x).composition(z)
x_1 = Dummy('x_1')
_lookup_table = None
domain_for_table = None
from sympy.integrals.meijerint import _mytype

def expr_to_holonomic(func, x=None, x0=0, y0=None, lenics=None, domain=None, initcond=True):
    func = sympify(func)
    syms = func.free_symbols
    if not x:
        if len(syms) == 1:
            x = syms.pop()
        else:
            raise ValueError('Specify the variable for the function')
    elif x in syms:
        syms.remove(x)
    extra_syms = list(syms)
    if domain is None:
        if func.has(Float):
            domain = RR
        else:
            domain = QQ
        if len(extra_syms) != 0:
            domain = domain[extra_syms].get_field()
    solpoly = _convert_poly_rat_alg(func, x, x0=x0, y0=y0, lenics=lenics, domain=domain, initcond=initcond)
    if solpoly:
        return solpoly
    global _lookup_table, domain_for_table
    if not _lookup_table or domain != domain_for_table:
        domain_for_table = domain
        _lookup_table = {}
        _create_table(_lookup_table, domain=domain)
    if func.is_Function:
        f = func.subs(x, x_1)
        t = _mytype(f, x_1)
        if t in _lookup_table:
            l = _lookup_table[t]
            sol = l[0][1].change_x(x)
        else:
            sol = _convert_meijerint(func, x, initcond=False, domain=domain)
            if not sol:
                raise NotImplementedError
            if y0:
                sol.y0 = y0
            if y0 or not initcond:
                sol.x0 = x0
                return sol
            if not lenics:
                lenics = sol.annihilator.order
            _y0 = _find_conditions(func, x, x0, lenics)
            while not _y0:
                x0 += 1
                _y0 = _find_conditions(func, x, x0, lenics)
            return HolonomicFunction(sol.annihilator, x, x0, _y0)
        if y0 or not initcond:
            sol = sol.composition(func.args[0])
            if y0:
                sol.y0 = y0
            sol.x0 = x0
            return sol
        if not lenics:
            lenics = sol.annihilator.order
        _y0 = _find_conditions(func, x, x0, lenics)
        while not _y0:
            x0 += 1
            _y0 = _find_conditions(func, x, x0, lenics)
        return sol.composition(func.args[0], x0, _y0)
    args = func.args
    f = func.func
    sol = expr_to_holonomic(args[0], x=x, initcond=False, domain=domain)
    if f is Add:
        for i in range(1, len(args)):
            sol += expr_to_holonomic(args[i], x=x, initcond=False, domain=domain)
    elif f is Mul:
        for i in range(1, len(args)):
            sol *= expr_to_holonomic(args[i], x=x, initcond=False, domain=domain)
    elif f is Pow:
        sol = sol ** args[1]
    sol.x0 = x0
    if not sol:
        raise NotImplementedError
    if y0:
        sol.y0 = y0
    if y0 or not initcond:
        return sol
    if sol.y0:
        return sol
    if not lenics:
        lenics = sol.annihilator.order
    if sol.annihilator.is_singular(x0):
        r = sol._indicial()
        l = list(r)
        if len(r) == 1 and r[l[0]] == S.One:
            r = l[0]
            g = func / (x - x0) ** r
            singular_ics = _find_conditions(g, x, x0, lenics)
            singular_ics = [j / factorial(i) for i, j in enumerate(singular_ics)]
            y0 = {r: singular_ics}
            return HolonomicFunction(sol.annihilator, x, x0, y0)
    _y0 = _find_conditions(func, x, x0, lenics)
    while not _y0:
        x0 += 1
        _y0 = _find_conditions(func, x, x0, lenics)
    return HolonomicFunction(sol.annihilator, x, x0, _y0)

def _normalize(list_of, parent, negative=True):
    num = []
    denom = []
    base = parent.base
    K = base.get_field()
    lcm_denom = base.from_sympy(S.One)
    list_of_coeff = []
    for i, j in enumerate(list_of):
        if isinstance(j, base.dtype):
            list_of_coeff.append(K.new(j.to_list()))
        elif not isinstance(j, K.dtype):
            list_of_coeff.append(K.from_sympy(sympify(j)))
        else:
            list_of_coeff.append(j)
        num.append(list_of_coeff[i].numer())
        denom.append(list_of_coeff[i].denom())
    for i in denom:
        lcm_denom = i.lcm(lcm_denom)
    if negative:
        lcm_denom = -lcm_denom
    lcm_denom = K.new(lcm_denom.to_list())
    for i, j in enumerate(list_of_coeff):
        list_of_coeff[i] = j * lcm_denom
    gcd_numer = base((list_of_coeff[-1].numer() / list_of_coeff[-1].denom()).to_list())
    for i in num:
        gcd_numer = i.gcd(gcd_numer)
    gcd_numer = K.new(gcd_numer.to_list())
    for i, j in enumerate(list_of_coeff):
        frac_ans = j / gcd_numer
        list_of_coeff[i] = base((frac_ans.numer() / frac_ans.denom()).to_list())
    return DifferentialOperator(list_of_coeff, parent)

def _derivate_diff_eq(listofpoly, K):
    sol = []
    a = len(listofpoly) - 1
    sol.append(DMFdiff(listofpoly[0], K))
    for i, j in enumerate(listofpoly[1:]):
        sol.append(DMFdiff(j, K) + listofpoly[i])
    sol.append(listofpoly[a])
    return sol

def _hyper_to_meijerg(func):
    ap = func.ap
    bq = func.bq
    if any((i <= 0 and int(i) == i for i in ap)):
        return hyperexpand(func)
    z = func.args[2]
    an = (1 - i for i in ap)
    anp = ()
    bm = (S.Zero,)
    bmq = (1 - i for i in bq)
    k = S.One
    for i in bq:
        k = k * gamma(i)
    for i in ap:
        k = k / gamma(i)
    return k * meijerg(an, anp, bm, bmq, -z)

def _add_lists(list1, list2):
    if len(list1) <= len(list2):
        sol = [a + b for a, b in zip(list1, list2)] + list2[len(list1):]
    else:
        sol = [a + b for a, b in zip(list1, list2)] + list1[len(list2):]
    return sol

def _extend_y0(Holonomic, n):
    if Holonomic.annihilator.is_singular(Holonomic.x0) or Holonomic.is_singularics() == True:
        return Holonomic.y0
    annihilator = Holonomic.annihilator
    a = annihilator.order
    listofpoly = []
    y0 = Holonomic.y0
    R = annihilator.parent.base
    K = R.get_field()
    for j in annihilator.listofpoly:
        if isinstance(j, annihilator.parent.base.dtype):
            listofpoly.append(K.new(j.to_list()))
    if len(y0) < a or n <= len(y0):
        return y0
    list_red = [-listofpoly[i] / listofpoly[a] for i in range(a)]
    y1 = y0[:min(len(y0), a)]
    for _ in range(n - a):
        sol = 0
        for a, b in zip(y1, list_red):
            r = DMFsubs(b, Holonomic.x0)
            if not getattr(r, 'is_finite', True):
                return y0
            if isinstance(r, (PolyElement, FracElement)):
                r = r.as_expr()
            sol += a * r
        y1.append(sol)
        list_red = _derivate_diff_eq(list_red, K)
    return y0 + y1[len(y0):]

def DMFdiff(frac, K):
    if not isinstance(frac, DMF):
        return frac.diff()
    p = K.numer(frac)
    q = K.denom(frac)
    sol_num = -p * q.diff() + q * p.diff()
    sol_denom = q ** 2
    return K((sol_num.to_list(), sol_denom.to_list()))

def DMFsubs(frac, x0, mpm=False):
    if not isinstance(frac, DMF):
        return frac
    p = frac.num
    q = frac.den
    sol_p = S.Zero
    sol_q = S.Zero
    for i, j in enumerate(reversed(p)):
        if mpm:
            j = sympify(j)._to_mpmath(mp.prec)
        sol_p += j * x0 ** i
    for i, j in enumerate(reversed(q)):
        if mpm:
            j = sympify(j)._to_mpmath(mp.prec)
        sol_q += j * x0 ** i
    if isinstance(sol_p, (PolyElement, FracElement)):
        sol_p = sol_p.as_expr()
    if isinstance(sol_q, (PolyElement, FracElement)):
        sol_q = sol_q.as_expr()
    return sol_p / sol_q

def _convert_poly_rat_alg(func, x, x0=0, y0=None, lenics=None, domain=QQ, initcond=True):
    ispoly = func.is_polynomial()
    if not ispoly:
        israt = func.is_rational_function()
    else:
        israt = True
    if not (ispoly or israt):
        basepoly, ratexp = func.as_base_exp()
        if basepoly.is_polynomial() and ratexp.is_Number:
            if isinstance(ratexp, Float):
                ratexp = nsimplify(ratexp)
            m, n = (ratexp.p, ratexp.q)
            is_alg = True
        else:
            is_alg = False
    else:
        is_alg = True
    if not (ispoly or israt or is_alg):
        return None
    R = domain.old_poly_ring(x)
    _, Dx = DifferentialOperators(R, 'Dx')
    if not func.has(x):
        return HolonomicFunction(Dx, x, 0, [func])
    if ispoly:
        sol = func * Dx - func.diff(x)
        sol = _normalize(sol.listofpoly, sol.parent, negative=False)
        is_singular = sol.is_singular(x0)
        if y0 is None and x0 == 0 and is_singular:
            rep = R.from_sympy(func).to_list()
            for i, j in enumerate(reversed(rep)):
                if j == 0:
                    continue
                coeff = list(reversed(rep))[i:]
                indicial = i
                break
            for i, j in enumerate(coeff):
                if isinstance(j, (PolyElement, FracElement)):
                    coeff[i] = j.as_expr()
            y0 = {indicial: S(coeff)}
    elif israt:
        p, q = func.as_numer_denom()
        sol = p * q * Dx + p * q.diff(x) - q * p.diff(x)
        sol = _normalize(sol.listofpoly, sol.parent, negative=False)
    elif is_alg:
        sol = n * (x / m) * Dx - 1
        sol = HolonomicFunction(sol, x).composition(basepoly).annihilator
        is_singular = sol.is_singular(x0)
        if y0 is None and x0 == 0 and is_singular and (lenics is None or lenics <= 1):
            rep = R.from_sympy(basepoly).to_list()
            for i, j in enumerate(reversed(rep)):
                if j == 0:
                    continue
                if isinstance(j, (PolyElement, FracElement)):
                    j = j.as_expr()
                coeff = S(j) ** ratexp
                indicial = S(i) * ratexp
                break
            if isinstance(coeff, (PolyElement, FracElement)):
                coeff = coeff.as_expr()
            y0 = {indicial: S([coeff])}
    if y0 or not initcond:
        return HolonomicFunction(sol, x, x0, y0)
    if not lenics:
        lenics = sol.order
    if sol.is_singular(x0):
        r = HolonomicFunction(sol, x, x0)._indicial()
        l = list(r)
        if len(r) == 1 and r[l[0]] == S.One:
            r = l[0]
            g = func / (x - x0) ** r
            singular_ics = _find_conditions(g, x, x0, lenics)
            singular_ics = [j / factorial(i) for i, j in enumerate(singular_ics)]
            y0 = {r: singular_ics}
            return HolonomicFunction(sol, x, x0, y0)
    y0 = _find_conditions(func, x, x0, lenics)
    while not y0:
        x0 += 1
        y0 = _find_conditions(func, x, x0, lenics)
    return HolonomicFunction(sol, x, x0, y0)

def _convert_meijerint(func, x, initcond=True, domain=QQ):
    args = meijerint._rewrite1(func, x)
    if args:
        fac, po, g, _ = args
    else:
        return None
    fac_list = [fac * i[0] for i in g]
    t = po.as_base_exp()
    s = t[1] if t[0] == x else S.Zero
    po_list = [s + i[1] for i in g]
    G_list = [i[2] for i in g]

    def _shift(func, s):
        z = func.args[-1]
        if z.has(I):
            z = z.subs(exp_polar, exp)
        d = z.collect(x, evaluate=False)
        b = list(d)[0]
        a = d[b]
        t = b.as_base_exp()
        b = t[1] if t[0] == x else S.Zero
        r = s / b
        an = (i + r for i in func.args[0][0])
        ap = (i + r for i in func.args[0][1])
        bm = (i + r for i in func.args[1][0])
        bq = (i + r for i in func.args[1][1])
        return (a ** (-r), meijerg((an, ap), (bm, bq), z))
    coeff, m = _shift(G_list[0], po_list[0])
    sol = fac_list[0] * coeff * from_meijerg(m, initcond=initcond, domain=domain)
    for i in range(1, len(G_list)):
        coeff, m = _shift(G_list[i], po_list[i])
        sol += fac_list[i] * coeff * from_meijerg(m, initcond=initcond, domain=domain)
    return sol

def _create_table(table, domain=QQ):

    def add(formula, annihilator, arg, x0=0, y0=()):
        table.setdefault(_mytype(formula, x_1), []).append((formula, HolonomicFunction(annihilator, arg, x0, y0)))
    R = domain.old_poly_ring(x_1)
    _, Dx = DifferentialOperators(R, 'Dx')
    add(sin(x_1), Dx ** 2 + 1, x_1, 0, [0, 1])
    add(cos(x_1), Dx ** 2 + 1, x_1, 0, [1, 0])
    add(exp(x_1), Dx - 1, x_1, 0, 1)
    add(log(x_1), Dx + x_1 * Dx ** 2, x_1, 1, [0, 1])
    add(erf(x_1), 2 * x_1 * Dx + Dx ** 2, x_1, 0, [0, 2 / sqrt(pi)])
    add(erfc(x_1), 2 * x_1 * Dx + Dx ** 2, x_1, 0, [1, -2 / sqrt(pi)])
    add(erfi(x_1), -2 * x_1 * Dx + Dx ** 2, x_1, 0, [0, 2 / sqrt(pi)])
    add(sinh(x_1), Dx ** 2 - 1, x_1, 0, [0, 1])
    add(cosh(x_1), Dx ** 2 - 1, x_1, 0, [1, 0])
    add(sinc(x_1), x_1 + 2 * Dx + x_1 * Dx ** 2, x_1)
    add(Si(x_1), x_1 * Dx + 2 * Dx ** 2 + x_1 * Dx ** 3, x_1)
    add(Ci(x_1), x_1 * Dx + 2 * Dx ** 2 + x_1 * Dx ** 3, x_1)
    add(Shi(x_1), -x_1 * Dx + 2 * Dx ** 2 + x_1 * Dx ** 3, x_1)

def _find_conditions(func, x, x0, order, evalf=False, use_limit=True):
    y0 = []
    for _ in range(order):
        val = func.subs(x, x0)
        if evalf:
            val = val.evalf()
        if use_limit and isinstance(val, NaN):
            val = limit(func, x, x0)
        if val.is_finite is False or isinstance(val, NaN):
            return None
        y0.append(val)
        func = func.diff(x)
    return y0