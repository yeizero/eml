from __future__ import annotations
from typing import TYPE_CHECKING
from sympy.core import S
from sympy.core.sympify import sympify
from sympy.core.parameters import global_parameters
from sympy.logic.boolalg import Boolean
from sympy.utilities.misc import func_name
from sympy.sets.sets import Set
if TYPE_CHECKING:
    from sympy.core.basic import Basic

class Contains(Boolean):
    if TYPE_CHECKING:

        @property
        def args(self) -> tuple[Basic, Set]:
            pass

    def __new__(cls, x: Basic, s: Set, evaluate: bool | None=None) -> Boolean:
        x = sympify(x)
        s = sympify(s)
        if evaluate is None:
            evaluate = global_parameters.evaluate
        if not isinstance(s, Set):
            raise TypeError('expecting Set, not %s' % func_name(s))
        if evaluate:
            result = s._contains(x)
            if isinstance(result, Boolean):
                if result in (S.true, S.false):
                    return result
            elif result is not None:
                raise TypeError('_contains() should return Boolean or None')
        return super().__new__(cls, x, s)

    @property
    def binary_symbols(self) -> set[Basic]:
        bool_args = [a for a in self.args[1].args if isinstance(a, Boolean)]
        return set().union(*[i.binary_symbols for i in bool_args])

    def as_set(self) -> Set:
        return self.args[1]