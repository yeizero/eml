from __future__ import annotations
from typing import Any, TYPE_CHECKING, overload
from functools import reduce
from collections import defaultdict
import inspect
from sympy.core.kind import Kind, UndefinedKind, NumberKind
from sympy.core.basic import Basic
from sympy.core.containers import Tuple, TupleKind
from sympy.core.decorators import sympify_method_args, sympify_return
from sympy.core.evalf import EvalfMixin
from sympy.core.expr import Expr
from sympy.core.function import Lambda
from sympy.core.logic import FuzzyBool, fuzzy_bool, fuzzy_or, fuzzy_and, fuzzy_not
from sympy.core.numbers import Float, Integer
from sympy.core.operations import LatticeOp
from sympy.core.parameters import global_parameters
from sympy.core.relational import Eq, Ne, is_lt
from sympy.core.singleton import Singleton, S
from sympy.core.sorting import ordered
from sympy.core.symbol import symbols, Symbol, Dummy, uniquely_named_symbol
from sympy.core.sympify import _sympify, sympify, _sympy_converter
from sympy.external.mpmath import prec_to_dps, mpf, mpi
from sympy.functions.elementary.exponential import exp, log
from sympy.functions.elementary.miscellaneous import Max, Min
from sympy.logic.boolalg import And, Or, Not, Xor, true, false, Boolean
from sympy.utilities.decorator import deprecated
from sympy.utilities.exceptions import sympy_deprecation_warning
from sympy.utilities.iterables import iproduct, sift, roundrobin, iterable, subsets
from sympy.utilities.misc import func_name, filldedent
if TYPE_CHECKING:
    from collections.abc import Mapping, Iterable
tfn: dict[bool | Boolean | None, Boolean | None] = defaultdict(lambda: None, {True: S.true, S.true: S.true, False: S.false, S.false: S.false})

@sympify_method_args
class Set(Basic, EvalfMixin):
    __slots__: tuple[()] = ()
    is_number = False
    is_iterable = False
    is_interval = False
    is_FiniteSet = False
    is_Interval = False
    is_ProductSet = False
    is_Union = False
    is_Intersection: FuzzyBool = None
    is_UniversalSet: FuzzyBool = None
    is_Complement: FuzzyBool = None
    is_ComplexRegion = False
    is_empty: FuzzyBool = None
    is_finite_set: FuzzyBool = None

    @property
    @deprecated('\n        The is_EmptySet attribute of Set objects is deprecated.\n        Use \'s is S.EmptySet" or \'s.is_empty\' instead.\n        ', deprecated_since_version='1.5', active_deprecations_target='deprecated-is-emptyset')
    def is_EmptySet(self):
        return None
    if TYPE_CHECKING:

        def __new__(cls, *args: Basic | complex) -> Set:
            pass

        @overload
        def subs(self, arg1: Mapping[Basic | complex, Set | complex], arg2: None=None) -> Set:
            pass

        @overload
        def subs(self, arg1: Iterable[tuple[Basic | complex, Set | complex]], arg2: None=None, **kwargs: Any) -> Set:
            pass

        @overload
        def subs(self, arg1: Set | complex, arg2: Set | complex) -> Set:
            pass

        @overload
        def subs(self, arg1: Mapping[Basic | complex, Basic | complex], arg2: None=None, **kwargs: Any) -> Basic:
            pass

        @overload
        def subs(self, arg1: Iterable[tuple[Basic | complex, Basic | complex]], arg2: None=None, **kwargs: Any) -> Basic:
            pass

        @overload
        def subs(self, arg1: Basic | complex, arg2: Basic | complex, **kwargs: Any) -> Basic:
            pass

        def subs(self, arg1: Mapping[Basic | complex, Basic | complex] | Basic | complex, arg2: Basic | complex | None=None, **kwargs: Any) -> Basic:
            pass

        def simplify(self, **kwargs) -> Set:
            assert False

        def evalf(self, n: int=15, subs: dict[Basic, Basic | float] | None=None, maxn: int=100, chop: bool=False, strict: bool=False, quad: str | None=None, verbose: bool=False) -> Set:
            pass
        n = evalf

    @staticmethod
    def _infimum_key(expr):
        try:
            infimum = expr.inf
            assert infimum.is_comparable
            infimum = infimum.evalf()
        except (NotImplementedError, AttributeError, AssertionError, ValueError):
            infimum = S.Infinity
        return infimum

    def union(self, other):
        return Union(self, other)

    def intersect(self, other):
        return Intersection(self, other)

    def intersection(self, other):
        return self.intersect(other)

    def is_disjoint(self, other):
        return self.intersect(other) == S.EmptySet

    def isdisjoint(self, other):
        return self.is_disjoint(other)

    def complement(self, universe):
        return Complement(universe, self)

    def _complement(self, other):
        if isinstance(self, ProductSet) and isinstance(other, ProductSet):
            if len(self.sets) != len(other.sets):
                return other
            overlaps = []
            pairs = list(zip(self.sets, other.sets))
            for n in range(len(pairs)):
                sets = (o if i != n else o - s for i, (s, o) in enumerate(pairs))
                overlaps.append(ProductSet(*sets))
            return Union(*overlaps)
        elif isinstance(other, Interval):
            if isinstance(self, (Interval, FiniteSet)):
                return Intersection(other, self.complement(S.Reals))
        elif isinstance(other, Union):
            return Union(*(o - self for o in other.args))
        elif isinstance(other, Complement):
            return Complement(other.args[0], Union(other.args[1], self), evaluate=False)
        elif other is S.EmptySet:
            return S.EmptySet
        elif isinstance(other, FiniteSet):
            sifted = sift(other, lambda x: fuzzy_bool(self.contains(x)))
            return Union(FiniteSet(*sifted[False]), Complement(FiniteSet(*sifted[None]), self, evaluate=False) if sifted[None] else S.EmptySet)

    def symmetric_difference(self, other):
        return SymmetricDifference(self, other)

    def _symmetric_difference(self, other):
        return Union(Complement(self, other), Complement(other, self))

    @property
    def inf(self):
        return self._inf

    @property
    def _inf(self):
        raise NotImplementedError('(%s)._inf' % self)

    @property
    def sup(self):
        return self._sup

    @property
    def _sup(self):
        raise NotImplementedError('(%s)._sup' % self)

    def contains(self, other):
        from .contains import Contains
        other = sympify(other, strict=True)
        c = self._contains(other)
        if isinstance(c, Contains):
            return c
        if c is None:
            return Contains(other, self, evaluate=False)
        b = tfn[c]
        if b is None:
            return c
        return b

    def _contains(self, other):
        raise NotImplementedError(f'{type(self).__name__}._contains')

    def is_subset(self, other):
        if not isinstance(other, Set):
            raise ValueError("Unknown argument '%s'" % other)
        if self == other:
            return True
        is_empty = self.is_empty
        if is_empty is True:
            return True
        elif fuzzy_not(is_empty) and other.is_empty:
            return False
        if self.is_finite_set is False and other.is_finite_set:
            return False
        ret = self._eval_is_subset(other)
        if ret is not None:
            return ret
        ret = other._eval_is_superset(self)
        if ret is not None:
            return ret
        from sympy.sets.handlers.issubset import is_subset_sets
        ret = is_subset_sets(self, other)
        if ret is not None:
            return ret

    def _eval_is_subset(self, other):
        return None

    def _eval_is_superset(self, other):
        return None

    def issubset(self, other):
        return self.is_subset(other)

    def is_proper_subset(self, other):
        if isinstance(other, Set):
            return fuzzy_and([self.is_subset(other), fuzzy_not(other.is_subset(self))])
        else:
            raise ValueError("Unknown argument '%s'" % other)

    def is_superset(self, other):
        if isinstance(other, Set):
            return other.is_subset(self)
        else:
            raise ValueError("Unknown argument '%s'" % other)

    def issuperset(self, other):
        return self.is_superset(other)

    def is_proper_superset(self, other):
        if isinstance(other, Set):
            return other.is_proper_subset(self)
        else:
            raise ValueError("Unknown argument '%s'" % other)

    def _eval_powerset(self):
        from .powerset import PowerSet
        return PowerSet(self)

    def powerset(self):
        return self._eval_powerset()

    @property
    def measure(self):
        return self._measure

    @property
    def kind(self):
        return self._kind()

    @property
    def boundary(self):
        return self._boundary

    @property
    def is_open(self):
        return Intersection(self, self.boundary).is_empty

    @property
    def is_closed(self):
        return self.boundary.is_subset(self)

    @property
    def closure(self):
        return self + self.boundary

    @property
    def interior(self):
        return self - self.boundary

    @property
    def _boundary(self):
        raise NotImplementedError()

    @property
    def _measure(self):
        raise NotImplementedError('(%s)._measure' % self)

    def _kind(self):
        return SetKind(UndefinedKind)

    def _eval_evalf(self, prec):
        dps = prec_to_dps(prec)
        return self.func(*[arg.evalf(n=dps) for arg in self.args])

    @sympify_return([('other', 'Set')], NotImplemented)
    def __add__(self, other):
        return self.union(other)

    @sympify_return([('other', 'Set')], NotImplemented)
    def __or__(self, other):
        return self.union(other)

    @sympify_return([('other', 'Set')], NotImplemented)
    def __and__(self, other):
        return self.intersect(other)

    @sympify_return([('other', 'Set')], NotImplemented)
    def __mul__(self, other):
        return ProductSet(self, other)

    @sympify_return([('other', 'Set')], NotImplemented)
    def __xor__(self, other):
        return SymmetricDifference(self, other)

    @sympify_return([('exp', Expr)], NotImplemented)
    def __pow__(self, exp):
        if not (exp.is_Integer and exp >= 0):
            raise ValueError('%s: Exponent must be a positive Integer' % exp)
        return ProductSet(*[self] * exp)

    @sympify_return([('other', 'Set')], NotImplemented)
    def __sub__(self, other):
        return Complement(self, other)

    def __contains__(self, other):
        other = _sympify(other)
        c = self._contains(other)
        b = tfn[c]
        if b is None:
            raise TypeError('did not evaluate to a bool: %r' % c)
        return b

    def as_relational(self, symbol):
        raise NotImplementedError('as_relational is not implemented for this set type.')

class ProductSet(Set):
    is_ProductSet = True

    def __new__(cls, *sets, **assumptions):
        if len(sets) == 1 and iterable(sets[0]) and (not isinstance(sets[0], (Set, set))):
            sympy_deprecation_warning('\nProductSet(iterable) is deprecated. Use ProductSet(*iterable) instead.\n                ', deprecated_since_version='1.5', active_deprecations_target='deprecated-productset-iterable')
            sets = tuple(sets[0])
        sets = [sympify(s) for s in sets]
        if not all((isinstance(s, Set) for s in sets)):
            raise TypeError('Arguments to ProductSet should be of type Set')
        if len(sets) == 0:
            return FiniteSet(())
        if S.EmptySet in sets:
            return S.EmptySet
        return Basic.__new__(cls, *sets, **assumptions)

    @property
    def sets(self):
        return self.args

    def flatten(self):

        def _flatten(sets):
            for s in sets:
                if s.is_ProductSet:
                    yield from _flatten(s.sets)
                else:
                    yield s
        return ProductSet(*_flatten(self.sets))

    def _contains(self, element):
        if element.is_Symbol:
            return None
        if not isinstance(element, Tuple) or len(element) != len(self.sets):
            return S.false
        return And(*[s.contains(e) for s, e in zip(self.sets, element)])

    def as_relational(self, *symbols):
        symbols = [_sympify(s) for s in symbols]
        if len(symbols) != len(self.sets) or not all((i.is_Symbol for i in symbols)):
            raise ValueError('number of symbols must match the number of sets')
        return And(*[s.as_relational(i) for s, i in zip(self.sets, symbols)])

    @property
    def _boundary(self):
        return Union(*(ProductSet(*(b + b.boundary if i != j else b.boundary for j, b in enumerate(self.sets))) for i, a in enumerate(self.sets)))

    @property
    def is_iterable(self):
        return all((set.is_iterable for set in self.sets))

    def __iter__(self):
        return iproduct(*self.sets)

    @property
    def is_empty(self):
        return fuzzy_or((s.is_empty for s in self.sets))

    @property
    def is_finite_set(self):
        all_finite = fuzzy_and((s.is_finite_set for s in self.sets))
        return fuzzy_or([self.is_empty, all_finite])

    @property
    def _measure(self):
        measure = 1
        for s in self.sets:
            measure *= s.measure
        return measure

    def _kind(self):
        return SetKind(TupleKind(*(i.kind.element_kind for i in self.args)))

    def __len__(self):
        return reduce(lambda a, b: a * b, (len(s) for s in self.args))

    def __bool__(self):
        return all(self.sets)

class Interval(Set):
    is_Interval = True

    def __new__(cls, start, end, left_open=False, right_open=False):
        start = _sympify(start)
        end = _sympify(end)
        left_open = _sympify(left_open)
        right_open = _sympify(right_open)
        if not all((isinstance(a, (type(true), type(false))) for a in [left_open, right_open])):
            raise NotImplementedError('left_open and right_open can have only true/false values, got %s and %s' % (left_open, right_open))
        if fuzzy_not(fuzzy_and((i.is_extended_real for i in (start, end, end - start)))):
            raise ValueError('Non-real intervals are not supported')
        if is_lt(end, start):
            return S.EmptySet
        elif (end - start).is_negative:
            return S.EmptySet
        if end == start and (left_open or right_open):
            return S.EmptySet
        if end == start and (not (left_open or right_open)):
            if start is S.Infinity or start is S.NegativeInfinity:
                return S.EmptySet
            return FiniteSet(end)
        if start is S.NegativeInfinity:
            left_open = true
        if end is S.Infinity:
            right_open = true
        if start == S.Infinity or end == S.NegativeInfinity:
            return S.EmptySet
        return Basic.__new__(cls, start, end, left_open, right_open)

    @property
    def start(self):
        return self._args[0]

    @property
    def end(self):
        return self._args[1]

    @property
    def left_open(self):
        return self._args[2]

    @property
    def right_open(self):
        return self._args[3]

    @classmethod
    def open(cls, a, b):
        return cls(a, b, True, True)

    @classmethod
    def Lopen(cls, a, b):
        return cls(a, b, True, False)

    @classmethod
    def Ropen(cls, a, b):
        return cls(a, b, False, True)

    @property
    def _inf(self):
        return self.start

    @property
    def _sup(self):
        return self.end

    @property
    def left(self):
        return self.start

    @property
    def right(self):
        return self.end

    @property
    def is_empty(self):
        if self.left_open or self.right_open:
            cond = self.start >= self.end
        else:
            cond = self.start > self.end
        return fuzzy_bool(cond)

    @property
    def is_finite_set(self):
        return self.measure.is_zero

    def _complement(self, other):
        if other == S.Reals:
            a = Interval(S.NegativeInfinity, self.start, True, not self.left_open)
            b = Interval(self.end, S.Infinity, not self.right_open, True)
            return Union(a, b)
        if isinstance(other, FiniteSet):
            nums = [m for m in other.args if m.is_number]
            if nums == []:
                return None
        return Set._complement(self, other)

    @property
    def _boundary(self):
        finite_points = [p for p in (self.start, self.end) if abs(p) != S.Infinity]
        return FiniteSet(*finite_points)

    def _contains(self, other):
        if not isinstance(other, Expr) or other is S.NaN or other.is_real is False or other.has(S.ComplexInfinity):
            return false
        if self.start is S.NegativeInfinity and self.end is S.Infinity:
            if other.is_real is not None:
                return tfn[other.is_real]
        d = Dummy()
        return self.as_relational(d).subs(d, other)

    def as_relational(self, x):
        x = sympify(x)
        if self.right_open:
            right = x < self.end
        else:
            right = x <= self.end
        if self.left_open:
            left = self.start < x
        else:
            left = self.start <= x
        return And(left, right)

    @property
    def _measure(self):
        return self.end - self.start

    def _kind(self):
        return SetKind(NumberKind)

    def to_mpi(self, prec=53):
        return mpi(mpf(self.start._eval_evalf(prec)), mpf(self.end._eval_evalf(prec)))

    def _eval_evalf(self, prec):
        return Interval(self.left._evalf(prec), self.right._evalf(prec), left_open=self.left_open, right_open=self.right_open)

    def _is_comparable(self, other):
        is_comparable = self.start.is_comparable
        is_comparable &= self.end.is_comparable
        is_comparable &= other.start.is_comparable
        is_comparable &= other.end.is_comparable
        return is_comparable

    @property
    def is_left_unbounded(self):
        return self.left is S.NegativeInfinity or self.left == Float('-inf')

    @property
    def is_right_unbounded(self):
        return self.right is S.Infinity or self.right == Float('+inf')

    def _eval_Eq(self, other):
        if not isinstance(other, Interval):
            if isinstance(other, FiniteSet):
                return false
            elif isinstance(other, Set):
                return None
            return false

class Union(Set, LatticeOp):
    is_Union = True

    @property
    def identity(self):
        return S.EmptySet

    @property
    def zero(self):
        return S.UniversalSet

    def __new__(cls, *args, **kwargs):
        evaluate = kwargs.get('evaluate', global_parameters.evaluate)
        args = _sympify(args)
        if evaluate:
            args = list(cls._new_args_filter(args))
            return simplify_union(args)
        args = list(ordered(args, Set._infimum_key))
        obj = Basic.__new__(cls, *args)
        obj._argset = frozenset(args)
        return obj

    @property
    def args(self):
        return self._args

    def _complement(self, universe):
        return Intersection((s.complement(universe) for s in self.args))

    @property
    def _inf(self):
        return Min(*[set.inf for set in self.args])

    @property
    def _sup(self):
        return Max(*[set.sup for set in self.args])

    @property
    def is_empty(self):
        return fuzzy_and((set.is_empty for set in self.args))

    @property
    def is_finite_set(self):
        return fuzzy_and((set.is_finite_set for set in self.args))

    @property
    def _measure(self):
        sets = [(FiniteSet(s), s) for s in self.args]
        measure = 0
        parity = 1
        while sets:
            measure += parity * sum((inter.measure for sos, inter in sets))
            sets = ((sos + FiniteSet(newset), newset.intersect(intersection)) for sos, intersection in sets for newset in self.args if newset not in sos)
            sets = [(sos, inter) for sos, inter in sets if inter.measure != 0]
            sos_list = []
            sets_list = []
            for _set in sets:
                if _set[0] in sos_list:
                    continue
                else:
                    sos_list.append(_set[0])
                    sets_list.append(_set)
            sets = sets_list
            parity *= -1
        return measure

    def _kind(self):
        kinds = tuple((arg.kind for arg in self.args if arg is not S.EmptySet))
        if not kinds:
            return SetKind()
        elif all((i == kinds[0] for i in kinds)):
            return kinds[0]
        else:
            return SetKind(UndefinedKind)

    @property
    def _boundary(self):

        def boundary_of_set(i):
            b = self.args[i].boundary
            for j, a in enumerate(self.args):
                if j != i:
                    b = b - a.interior
            return b
        return Union(*map(boundary_of_set, range(len(self.args))))

    def _contains(self, other):
        return Or(*[s.contains(other) for s in self.args])

    def _eval_is_subset(self, other):
        return fuzzy_and((arg.is_subset(other) for arg in self.args))

    def _eval_is_superset(self, other):
        if fuzzy_or((arg.is_superset(other) for arg in self.args)):
            return True

    def as_relational(self, symbol):
        if len(self.args) == 2 and all((isinstance(i, Interval) for i in self.args)):
            a, b = self.args
            if a.sup == b.inf and a.right_open and b.left_open:
                mincond = symbol > a.inf if a.left_open else symbol >= a.inf
                maxcond = symbol < b.sup if b.right_open else symbol <= b.sup
                necond = Ne(symbol, a.sup)
                return And(necond, mincond, maxcond)
        return Or(*[i.as_relational(symbol) for i in self.args])

    @property
    def is_iterable(self):
        return all((arg.is_iterable for arg in self.args))

    def __iter__(self):
        return roundrobin(*(iter(arg) for arg in self.args))

class Intersection(Set, LatticeOp):
    is_Intersection = True

    @property
    def identity(self):
        return S.UniversalSet

    @property
    def zero(self):
        return S.EmptySet

    def __new__(cls, *args, evaluate=None):
        if evaluate is None:
            evaluate = global_parameters.evaluate
        args = list(ordered(set(_sympify(args))))
        if evaluate:
            args = list(cls._new_args_filter(args))
            return simplify_intersection(args)
        args = list(ordered(args, Set._infimum_key))
        obj = Basic.__new__(cls, *args)
        obj._argset = frozenset(args)
        return obj

    @property
    def args(self):
        return self._args

    @property
    def is_iterable(self):
        return any((arg.is_iterable for arg in self.args))

    @property
    def is_finite_set(self):
        if fuzzy_or((arg.is_finite_set for arg in self.args)):
            return True

    def _kind(self):
        kinds = tuple((arg.kind for arg in self.args if arg is not S.UniversalSet))
        if not kinds:
            return SetKind(UndefinedKind)
        elif all((i == kinds[0] for i in kinds)):
            return kinds[0]
        else:
            return SetKind()

    @property
    def _inf(self):
        raise NotImplementedError()

    @property
    def _sup(self):
        raise NotImplementedError()

    def _contains(self, other):
        return And(*[set.contains(other) for set in self.args])

    def __iter__(self):
        sets_sift = sift(self.args, lambda x: x.is_iterable)
        completed = False
        candidates = sets_sift[True] + sets_sift[None]
        finite_candidates, others = ([], [])
        for candidate in candidates:
            length = None
            try:
                length = len(candidate)
            except TypeError:
                others.append(candidate)
            if length is not None:
                finite_candidates.append(candidate)
        finite_candidates.sort(key=len)
        for s in finite_candidates + others:
            other_sets = set(self.args) - {s}
            other = Intersection(*other_sets, evaluate=False)
            completed = True
            for x in s:
                try:
                    if x in other:
                        yield x
                except TypeError:
                    completed = False
            if completed:
                return
        if not completed:
            if not candidates:
                raise TypeError('None of the constituent sets are iterable')
            raise TypeError('The computation had not completed because of the undecidable set membership is found in every candidates.')

    @staticmethod
    def _handle_finite_sets(args):
        fs_args, others = sift(args, lambda x: x.is_FiniteSet, binary=True)
        if not fs_args:
            return
        fs_sets = [set(fs) for fs in fs_args]
        all_elements = reduce(lambda a, b: a | b, fs_sets, set())
        definite = set()
        for e in all_elements:
            inall = fuzzy_and((s.contains(e) for s in args))
            if inall is True:
                definite.add(e)
            if inall is not None:
                for s in fs_sets:
                    s.discard(e)
        fs_elements = reduce(lambda a, b: a | b, fs_sets, set())
        fs_symsets = [FiniteSet(*s) for s in fs_sets]
        while fs_elements:
            for e in fs_elements:
                infs = fuzzy_and((s.contains(e) for s in fs_symsets))
                if infs is True:
                    definite.add(e)
                if infs is not None:
                    for n, s in enumerate(fs_sets):
                        if e in s:
                            s.remove(e)
                            fs_symsets[n] = FiniteSet(*s)
                    fs_elements.remove(e)
                    break
            else:
                break
        if not all(fs_sets):
            fs_sets = [set()]
        if definite:
            fs_sets = [fs | definite for fs in fs_sets]
        if fs_sets == [set()]:
            return S.EmptySet
        sets = [FiniteSet(*s) for s in fs_sets]
        all_elements = reduce(lambda a, b: a | b, fs_sets, set())
        is_redundant = lambda o: all((fuzzy_bool(o.contains(e)) for e in all_elements))
        others = [o for o in others if not is_redundant(o)]
        if others:
            rest = Intersection(*others)
            if rest is S.EmptySet:
                return S.EmptySet
            if rest.is_Intersection:
                sets.extend(rest.args)
            else:
                sets.append(rest)
        if len(sets) == 1:
            return sets[0]
        else:
            return Intersection(*sets, evaluate=False)

    def as_relational(self, symbol):
        return And(*[set.as_relational(symbol) for set in self.args])

class Complement(Set):
    is_Complement = True

    def __new__(cls, a, b, evaluate=True):
        a, b = map(_sympify, (a, b))
        if evaluate:
            return Complement.reduce(a, b)
        return Basic.__new__(cls, a, b)

    @staticmethod
    def reduce(A, B):
        if B == S.UniversalSet or A.is_subset(B):
            return S.EmptySet
        if isinstance(B, Union):
            return Intersection(*(s.complement(A) for s in B.args))
        result = B._complement(A)
        if result is not None:
            return result
        else:
            return Complement(A, B, evaluate=False)

    def _contains(self, other):
        A = self.args[0]
        B = self.args[1]
        return And(A.contains(other), Not(B.contains(other)))

    def _eval_is_subset(self, other):
        A, B = self.args
        if A.is_subset(other):
            return True

    def as_relational(self, symbol):
        A, B = self.args
        A_rel = A.as_relational(symbol)
        B_rel = Not(B.as_relational(symbol))
        return And(A_rel, B_rel)

    def _kind(self):
        return self.args[0].kind

    @property
    def is_iterable(self):
        if self.args[0].is_iterable:
            return True

    @property
    def is_finite_set(self):
        A, B = self.args
        a_finite = A.is_finite_set
        if a_finite is True:
            return True
        elif a_finite is False and B.is_finite_set:
            return False

    def __iter__(self):
        A, B = self.args
        for a in A:
            if a not in B:
                yield a
            else:
                continue

class EmptySet(Set, metaclass=Singleton):
    is_empty = True
    is_finite_set = True
    is_FiniteSet = True

    @property
    @deprecated('\n        The is_EmptySet attribute of Set objects is deprecated.\n        Use \'s is S.EmptySet" or \'s.is_empty\' instead.\n        ', deprecated_since_version='1.5', active_deprecations_target='deprecated-is-emptyset')
    def is_EmptySet(self):
        return True

    @property
    def _measure(self):
        return 0

    def _contains(self, other):
        return false

    def as_relational(self, symbol):
        return false

    def __len__(self):
        return 0

    def __iter__(self):
        return iter([])

    def _eval_powerset(self):
        return FiniteSet(self)

    @property
    def _boundary(self):
        return self

    def _complement(self, other):
        return other

    def _kind(self):
        return SetKind()

    def _symmetric_difference(self, other):
        return other

class UniversalSet(Set, metaclass=Singleton):
    is_UniversalSet = True
    is_empty = False
    is_finite_set = False

    def _complement(self, other):
        return S.EmptySet

    def _symmetric_difference(self, other):
        return other

    @property
    def _measure(self):
        return S.Infinity

    def _kind(self):
        return SetKind(UndefinedKind)

    def _contains(self, other):
        return true

    def as_relational(self, symbol):
        return true

    @property
    def _boundary(self):
        return S.EmptySet

class FiniteSet(Set):
    is_FiniteSet = True
    is_iterable = True
    is_empty = False
    is_finite_set = True

    def __new__(cls, *args, **kwargs):
        evaluate = kwargs.get('evaluate', global_parameters.evaluate)
        if evaluate:
            args = list(map(sympify, args))
            if len(args) == 0:
                return S.EmptySet
        else:
            args = list(map(sympify, args))
        dargs = {}
        for i in reversed(list(ordered(args))):
            if i.is_Symbol:
                dargs[i] = i
            else:
                try:
                    dargs[i.as_dummy()] = i
                except TypeError:
                    dargs[i] = i
        _args_set = set(dargs.values())
        args = list(ordered(_args_set, Set._infimum_key))
        obj = Basic.__new__(cls, *args)
        obj._args_set = _args_set
        return obj

    def __iter__(self):
        return iter(self.args)

    def _complement(self, other):
        if isinstance(other, Interval):
            nums, syms = ([], [])
            for m in self.args:
                if m.is_number and m.is_real:
                    nums.append(m)
                elif m.is_real == False:
                    pass
                else:
                    syms.append(m)
            if other == S.Reals and nums != []:
                nums.sort()
                intervals = []
                intervals += [Interval(S.NegativeInfinity, nums[0], True, True)]
                for a, b in zip(nums[:-1], nums[1:]):
                    intervals.append(Interval(a, b, True, True))
                intervals.append(Interval(nums[-1], S.Infinity, True, True))
                if syms != []:
                    return Complement(Union(*intervals, evaluate=False), FiniteSet(*syms), evaluate=False)
                else:
                    return Union(*intervals, evaluate=False)
            elif nums == []:
                if syms:
                    return Complement(other, FiniteSet(*syms), evaluate=False)
                else:
                    return other
        elif isinstance(other, FiniteSet):
            unk = []
            for i in self:
                c = sympify(other.contains(i))
                if c is not S.true and c is not S.false:
                    unk.append(i)
            unk = FiniteSet(*unk)
            if unk == self:
                return
            not_true = []
            for i in other:
                c = sympify(self.contains(i))
                if c is not S.true:
                    not_true.append(i)
            return Complement(FiniteSet(*not_true), unk)
        return Set._complement(self, other)

    def _contains(self, other):
        if other in self._args_set:
            return S.true
        else:
            return Or(*[Eq(e, other, evaluate=True) for e in self.args])

    def _eval_is_subset(self, other):
        return fuzzy_and((other._contains(e) for e in self.args))

    @property
    def _boundary(self):
        return self

    @property
    def _inf(self):
        return Min(*self)

    @property
    def _sup(self):
        return Max(*self)

    @property
    def measure(self):
        return 0

    def _kind(self):
        if not self.args:
            return SetKind()
        elif all((i.kind == self.args[0].kind for i in self.args)):
            return SetKind(self.args[0].kind)
        else:
            return SetKind(UndefinedKind)

    def __len__(self):
        return len(self.args)

    def as_relational(self, symbol):
        return Or(*[Eq(symbol, elem) for elem in self])

    def _eval_evalf(self, prec):
        dps = prec_to_dps(prec)
        return FiniteSet(*[elem.evalf(n=dps) for elem in self])

    def _eval_simplify(self, **kwargs):
        from sympy.simplify import simplify
        return FiniteSet(*[simplify(elem, **kwargs) for elem in self])

    @property
    def _sorted_args(self):
        return self.args

    def _eval_powerset(self):
        return self.func(*[self.func(*s) for s in subsets(self.args)])

    def _eval_rewrite_as_PowerSet(self, *args, **kwargs):
        from .powerset import PowerSet
        is2pow = lambda n: bool(n and (not n & n - 1))
        if not is2pow(len(self)):
            return None
        fs_test = lambda arg: isinstance(arg, Set) and arg.is_FiniteSet
        if not all((fs_test(arg) for arg in args)):
            return None
        biggest = max(args, key=len)
        for arg in subsets(biggest.args):
            arg_set = FiniteSet(*arg)
            if arg_set not in args:
                return None
        return PowerSet(biggest)

    def __ge__(self, other):
        if not isinstance(other, Set):
            raise TypeError('Invalid comparison of set with %s' % func_name(other))
        return other.is_subset(self)

    def __gt__(self, other):
        if not isinstance(other, Set):
            raise TypeError('Invalid comparison of set with %s' % func_name(other))
        return self.is_proper_superset(other)

    def __le__(self, other):
        if not isinstance(other, Set):
            raise TypeError('Invalid comparison of set with %s' % func_name(other))
        return self.is_subset(other)

    def __lt__(self, other):
        if not isinstance(other, Set):
            raise TypeError('Invalid comparison of set with %s' % func_name(other))
        return self.is_proper_subset(other)

    def __eq__(self, other):
        if isinstance(other, (set, frozenset)):
            return self._args_set == other
        return super().__eq__(other)

    def __hash__(self):
        return Basic.__hash__(self)
_sympy_converter[set] = lambda x: FiniteSet(*x)
_sympy_converter[frozenset] = lambda x: FiniteSet(*x)

class SymmetricDifference(Set):
    is_SymmetricDifference = True

    def __new__(cls, a, b, evaluate=True):
        if evaluate:
            return SymmetricDifference.reduce(a, b)
        return Basic.__new__(cls, a, b)

    @staticmethod
    def reduce(A, B):
        result = B._symmetric_difference(A)
        if result is not None:
            return result
        else:
            return SymmetricDifference(A, B, evaluate=False)

    def as_relational(self, symbol):
        A, B = self.args
        A_rel = A.as_relational(symbol)
        B_rel = B.as_relational(symbol)
        return Xor(A_rel, B_rel)

    @property
    def is_iterable(self):
        if all((arg.is_iterable for arg in self.args)):
            return True

    def __iter__(self):
        args = self.args
        union = roundrobin(*(iter(arg) for arg in args))
        for item in union:
            count = 0
            for s in args:
                if item in s:
                    count += 1
            if count % 2 == 1:
                yield item

class DisjointUnion(Set):

    def __new__(cls, *sets):
        dj_collection = []
        for set_i in sets:
            if isinstance(set_i, Set):
                dj_collection.append(set_i)
            else:
                raise TypeError("Invalid input: '%s', input args                     to DisjointUnion must be Sets" % set_i)
        obj = Basic.__new__(cls, *dj_collection)
        return obj

    @property
    def sets(self):
        return self.args

    @property
    def is_empty(self):
        return fuzzy_and((s.is_empty for s in self.sets))

    @property
    def is_finite_set(self):
        all_finite = fuzzy_and((s.is_finite_set for s in self.sets))
        return fuzzy_or([self.is_empty, all_finite])

    @property
    def is_iterable(self):
        if self.is_empty:
            return False
        iter_flag = True
        for set_i in self.sets:
            if not set_i.is_empty:
                iter_flag = iter_flag and set_i.is_iterable
        return iter_flag

    def _eval_rewrite_as_Union(self, *sets, **kwargs):
        dj_union = S.EmptySet
        index = 0
        for set_i in sets:
            if isinstance(set_i, Set):
                cross = ProductSet(set_i, FiniteSet(index))
                dj_union = Union(dj_union, cross)
                index = index + 1
        return dj_union

    def _contains(self, element):
        if not isinstance(element, Tuple) or len(element) != 2:
            return S.false
        if not element[1].is_Integer:
            return S.false
        if element[1] >= len(self.sets) or element[1] < 0:
            return S.false
        return self.sets[element[1]]._contains(element[0])

    def _kind(self):
        if not self.args:
            return SetKind()
        elif all((i.kind == self.args[0].kind for i in self.args)):
            return self.args[0].kind
        else:
            return SetKind(UndefinedKind)

    def __iter__(self):
        if self.is_iterable:
            iters = []
            for i, s in enumerate(self.sets):
                iters.append(iproduct(s, {Integer(i)}))
            return iter(roundrobin(*iters))
        else:
            raise ValueError("'%s' is not iterable." % self)

    def __len__(self):
        if self.is_finite_set:
            size = 0
            for set in self.sets:
                size += len(set)
            return size
        else:
            raise ValueError("'%s' is not a finite set." % self)

def imageset(*args):
    from .fancysets import ImageSet
    from .setexpr import set_function
    if len(args) < 2:
        raise ValueError('imageset expects at least 2 args, got: %s' % len(args))
    if isinstance(args[0], (Symbol, tuple)) and len(args) > 2:
        f = Lambda(args[0], args[1])
        set_list = args[2:]
    else:
        f = args[0]
        set_list = args[1:]
    if isinstance(f, Lambda):
        pass
    elif callable(f):
        nargs = getattr(f, 'nargs', {})
        if nargs:
            if len(nargs) != 1:
                raise NotImplementedError(filldedent('\n                    This function can take more than 1 arg\n                    but the potentially complicated set input\n                    has not been analyzed at this point to\n                    know its dimensions. TODO\n                    '))
            N = nargs.args[0]
            if N == 1:
                s = 'x'
            else:
                s = [Symbol('x%i' % i) for i in range(1, N + 1)]
        else:
            s = inspect.signature(f).parameters
        dexpr = _sympify(f(*[Dummy() for i in s]))
        var = tuple((uniquely_named_symbol(Symbol(i), dexpr) for i in s))
        f = Lambda(var, f(*var))
    else:
        raise TypeError(filldedent("\n            expecting lambda, Lambda, or FunctionClass,\n            not '%s'." % func_name(f)))
    if any((not isinstance(s, Set) for s in set_list)):
        name = [func_name(s) for s in set_list]
        raise ValueError('arguments after mapping should be sets, not %s' % name)
    if len(set_list) == 1:
        set = set_list[0]
        try:
            r = set_function(f, set)
            if r is None:
                raise TypeError
            if not r:
                return r
        except TypeError:
            r = ImageSet(f, set)
        if isinstance(r, ImageSet):
            f, set = r.args
        if f.variables[0] == f.expr:
            return set
        if isinstance(set, ImageSet):
            if len(set.lamda.variables) == 1 and len(f.variables) == 1:
                x = set.lamda.variables[0]
                y = f.variables[0]
                return imageset(Lambda(x, f.expr.subs(y, set.lamda.expr)), *set.base_sets)
        if r is not None:
            return r
    return ImageSet(f, *set_list)

def is_function_invertible_in_set(func, setv):
    if func in (exp, log):
        return True
    u = Dummy('u')
    fdiff = func(u).diff(u)
    if (fdiff > 0) == True or (fdiff < 0) == True:
        return True
    return None

def simplify_union(args):
    from sympy.sets.handlers.union import union_sets
    if not args:
        return S.EmptySet
    for arg in args:
        if not isinstance(arg, Set):
            raise TypeError('Input args to Union must be Sets')
    finite_sets = [x for x in args if x.is_FiniteSet]
    if len(finite_sets) > 1:
        a = (x for set in finite_sets for x in set)
        finite_set = FiniteSet(*a)
        args = [finite_set] + [x for x in args if not x.is_FiniteSet]
    args = set(args)
    new_args = True
    while new_args:
        for s in args:
            new_args = False
            for t in args - {s}:
                new_set = union_sets(s, t)
                if new_set is not None:
                    if not isinstance(new_set, set):
                        new_set = {new_set}
                    new_args = (args - {s, t}).union(new_set)
                    break
            if new_args:
                args = new_args
                break
    if len(args) == 1:
        return args.pop()
    else:
        return Union(*args, evaluate=False)

def simplify_intersection(args):
    if not args:
        return S.UniversalSet
    for arg in args:
        if not isinstance(arg, Set):
            raise TypeError('Input args to Union must be Sets')
    if S.EmptySet in args:
        return S.EmptySet
    rv = Intersection._handle_finite_sets(args)
    if rv is not None:
        return rv
    for s in args:
        if s.is_Union:
            other_sets = set(args) - {s}
            if len(other_sets) > 0:
                other = Intersection(*other_sets)
                return Union(*(Intersection(arg, other) for arg in s.args))
            else:
                return Union(*s.args)
    for s in args:
        if s.is_Complement:
            args.remove(s)
            other_sets = args + [s.args[0]]
            return Complement(Intersection(*other_sets), s.args[1])
    from sympy.sets.handlers.intersection import intersection_sets
    args = set(args)
    new_args = True
    while new_args:
        for s in args:
            new_args = False
            for t in args - {s}:
                new_set = intersection_sets(s, t)
                if new_set is not None:
                    new_args = (args - {s, t}).union({new_set})
                    break
            if new_args:
                args = new_args
                break
    if len(args) == 1:
        return args.pop()
    else:
        return Intersection(*args, evaluate=False)

def _handle_finite_sets(op, x, y, commutative):
    fs_args, other = sift([x, y], lambda x: isinstance(x, FiniteSet), binary=True)
    if len(fs_args) == 2:
        return FiniteSet(*[op(i, j) for i in fs_args[0] for j in fs_args[1]])
    elif len(fs_args) == 1:
        sets = [_apply_operation(op, other[0], i, commutative) for i in fs_args[0]]
        return Union(*sets)
    else:
        return None

def _apply_operation(op, x, y, commutative):
    from .fancysets import ImageSet
    d = Dummy('d')
    out = _handle_finite_sets(op, x, y, commutative)
    if out is None:
        out = op(x, y)
    if out is None and commutative:
        out = op(y, x)
    if out is None:
        _x, _y = symbols('x y')
        if isinstance(x, Set) and (not isinstance(y, Set)):
            out = ImageSet(Lambda(d, op(d, y)), x).doit()
        elif not isinstance(x, Set) and isinstance(y, Set):
            out = ImageSet(Lambda(d, op(x, d)), y).doit()
        else:
            out = ImageSet(Lambda((_x, _y), op(_x, _y)), x, y)
    return out

def set_add(x, y):
    from sympy.sets.handlers.add import _set_add
    return _apply_operation(_set_add, x, y, commutative=True)

def set_sub(x, y):
    from sympy.sets.handlers.add import _set_sub
    return _apply_operation(_set_sub, x, y, commutative=False)

def set_mul(x, y):
    from sympy.sets.handlers.mul import _set_mul
    return _apply_operation(_set_mul, x, y, commutative=True)

def set_div(x, y):
    from sympy.sets.handlers.mul import _set_div
    return _apply_operation(_set_div, x, y, commutative=False)

def set_pow(x, y):
    from sympy.sets.handlers.power import _set_pow
    return _apply_operation(_set_pow, x, y, commutative=False)

def set_function(f, x):
    from sympy.sets.handlers.functions import _set_function
    return _set_function(f, x)

class SetKind(Kind):

    def __new__(cls, element_kind=None):
        obj = super().__new__(cls, element_kind)
        obj.element_kind = element_kind
        return obj

    def __repr__(self):
        if not self.element_kind:
            return 'SetKind()'
        else:
            return 'SetKind(%s)' % self.element_kind