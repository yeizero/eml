from __future__ import annotations
from functools import reduce
from itertools import product
from sympy.core.basic import Basic
from sympy.core.containers import Tuple
from sympy.core.expr import Expr
from sympy.core.function import Lambda
from sympy.core.logic import fuzzy_not, fuzzy_or, fuzzy_and
from sympy.core.mod import Mod
from sympy.core.intfunc import igcd
from sympy.core.numbers import oo, Rational, Integer
from sympy.core.relational import Eq, is_eq
from sympy.core.kind import NumberKind
from sympy.core.singleton import Singleton, S
from sympy.core.symbol import Dummy, symbols, Symbol
from sympy.core.sympify import _sympify, sympify, _sympy_converter
from sympy.functions.elementary.integers import ceiling, floor
from sympy.functions.elementary.trigonometric import sin, cos
from sympy.logic.boolalg import And, Or
from .sets import tfn, Set, Interval, Union, FiniteSet, ProductSet, SetKind
from sympy.utilities.misc import filldedent

class Rationals(Set, metaclass=Singleton):
    is_iterable = True
    _inf = S.NegativeInfinity
    _sup = S.Infinity
    is_empty = False
    is_finite_set = False

    def _contains(self, other):
        if not isinstance(other, Expr):
            return S.false
        return tfn[other.is_rational]

    def __iter__(self):
        yield S.Zero
        yield S.One
        yield S.NegativeOne
        d = 2
        while True:
            for n in range(d):
                if igcd(n, d) == 1:
                    yield Rational(n, d)
                    yield Rational(d, n)
                    yield Rational(-n, d)
                    yield Rational(-d, n)
            d += 1

    @property
    def _boundary(self):
        return S.Reals

    def _kind(self):
        return SetKind(NumberKind)

class Naturals(Set, metaclass=Singleton):
    is_iterable = True
    _inf: Integer = S.One
    _sup = S.Infinity
    is_empty = False
    is_finite_set = False

    def _contains(self, other):
        if not isinstance(other, Expr):
            return S.false
        elif other.is_positive and other.is_integer:
            return S.true
        elif other.is_integer is False or other.is_positive is False:
            return S.false

    def _eval_is_subset(self, other):
        return Range(1, oo).is_subset(other)

    def _eval_is_superset(self, other):
        return Range(1, oo).is_superset(other)

    def __iter__(self):
        i = self._inf
        while True:
            yield i
            i = i + 1

    @property
    def _boundary(self):
        return self

    def as_relational(self, x):
        return And(Eq(floor(x), x), x >= self.inf, x < oo)

    def _kind(self):
        return SetKind(NumberKind)

class Naturals0(Naturals):
    _inf = S.Zero

    def _contains(self, other):
        if not isinstance(other, Expr):
            return S.false
        elif other.is_integer and other.is_nonnegative:
            return S.true
        elif other.is_integer is False or other.is_nonnegative is False:
            return S.false

    def _eval_is_subset(self, other):
        return Range(oo).is_subset(other)

    def _eval_is_superset(self, other):
        return Range(oo).is_superset(other)

class Integers(Set, metaclass=Singleton):
    is_iterable = True
    is_empty = False
    is_finite_set = False

    def _contains(self, other):
        if not isinstance(other, Expr):
            return S.false
        return tfn[other.is_integer]

    def __iter__(self):
        yield S.Zero
        i = S.One
        while True:
            yield i
            yield (-i)
            i = i + 1

    @property
    def _inf(self):
        return S.NegativeInfinity

    @property
    def _sup(self):
        return S.Infinity

    @property
    def _boundary(self):
        return self

    def _kind(self):
        return SetKind(NumberKind)

    def as_relational(self, x):
        return And(Eq(floor(x), x), -oo < x, x < oo)

    def _eval_is_subset(self, other):
        return Range(-oo, oo).is_subset(other)

    def _eval_is_superset(self, other):
        return Range(-oo, oo).is_superset(other)

class Reals(Interval, metaclass=Singleton):

    @property
    def start(self):
        return S.NegativeInfinity

    @property
    def end(self):
        return S.Infinity

    @property
    def left_open(self):
        return True

    @property
    def right_open(self):
        return True

    def __eq__(self, other):
        return other == Interval(S.NegativeInfinity, S.Infinity)

    def __hash__(self):
        return hash(Interval(S.NegativeInfinity, S.Infinity))

class ImageSet(Set):

    def __new__(cls, flambda, *sets):
        if not isinstance(flambda, Lambda):
            raise ValueError('First argument must be a Lambda')
        signature = flambda.signature
        if len(signature) != len(sets):
            raise ValueError('Incompatible signature')
        sets = [_sympify(s) for s in sets]
        if not all((isinstance(s, Set) for s in sets)):
            raise TypeError('Set arguments to ImageSet should of type Set')
        if not all((cls._check_sig(sg, st) for sg, st in zip(signature, sets))):
            raise ValueError('Signature %s does not match sets %s' % (signature, sets))
        if flambda is S.IdentityFunction and len(sets) == 1:
            return sets[0]
        if not set(flambda.variables) & flambda.expr.free_symbols:
            is_empty = fuzzy_or((s.is_empty for s in sets))
            if is_empty == True:
                return S.EmptySet
            elif is_empty == False:
                return FiniteSet(flambda.expr)
        return Basic.__new__(cls, flambda, *sets)
    lamda = property(lambda self: self.args[0])
    base_sets = property(lambda self: self.args[1:])

    @property
    def base_set(self):
        sets = self.base_sets
        if len(sets) == 1:
            return sets[0]
        else:
            return ProductSet(*sets).flatten()

    @property
    def base_pset(self):
        return ProductSet(*self.base_sets)

    @classmethod
    def _check_sig(cls, sig_i, set_i):
        if sig_i.is_symbol:
            return True
        elif isinstance(set_i, ProductSet):
            sets = set_i.sets
            if len(sig_i) != len(sets):
                return False
            return all((cls._check_sig(ts, ps) for ts, ps in zip(sig_i, sets)))
        else:
            return True

    def __iter__(self):
        already_seen = set()
        for i in self.base_pset:
            val = self.lamda(*i)
            if val in already_seen:
                continue
            else:
                already_seen.add(val)
                yield val

    def _is_multivariate(self):
        return len(self.lamda.variables) > 1

    def _contains(self, other):
        from sympy.solvers.solveset import _solveset_multi

        def get_symsetmap(signature, base_sets):
            queue = list(zip(signature, base_sets))
            symsetmap = {}
            for sig, base_set in queue:
                if sig.is_symbol:
                    symsetmap[sig] = base_set
                elif base_set.is_ProductSet:
                    sets = base_set.sets
                    if len(sig) != len(sets):
                        raise ValueError('Incompatible signature')
                    queue.extend(zip(sig, sets))
                else:
                    return None
            return symsetmap

        def get_equations(expr, candidate):
            queue = [(expr, candidate)]
            for e, c in queue:
                if not isinstance(e, Tuple):
                    yield Eq(e, c)
                elif not isinstance(c, Tuple) or len(e) != len(c):
                    yield False
                    return
                else:
                    queue.extend(zip(e, c))
        other = _sympify(other)
        expr = self.lamda.expr
        sig = self.lamda.signature
        variables = self.lamda.variables
        base_sets = self.base_sets
        rep = {v: Dummy(v.name) for v in variables}
        variables = [v.subs(rep) for v in variables]
        sig = sig.subs(rep)
        expr = expr.subs(rep)
        equations = []
        for eq in get_equations(expr, other):
            if eq is False:
                return S.false
            equations.append(eq)
        symsetmap = get_symsetmap(sig, base_sets)
        if symsetmap is None:
            return None
        symss = (eq.free_symbols for eq in equations)
        variables = set(variables) & reduce(set.union, symss, set())
        variables = tuple(variables)
        base_sets = [symsetmap[v] for v in variables]
        solnset = _solveset_multi(equations, variables, base_sets)
        if solnset is None:
            return None
        return tfn[fuzzy_not(solnset.is_empty)]

    @property
    def is_iterable(self):
        return all((s.is_iterable for s in self.base_sets))

    def doit(self, **hints):
        from sympy.sets.setexpr import SetExpr
        f = self.lamda
        sig = f.signature
        if len(sig) == 1 and sig[0].is_symbol and isinstance(f.expr, Expr):
            base_set = self.base_sets[0]
            return SetExpr(base_set)._eval_func(f).set
        if all((s.is_FiniteSet for s in self.base_sets)):
            return FiniteSet(*(f(*a) for a in product(*self.base_sets)))
        return self

    def _kind(self):
        return SetKind(self.lamda.expr.kind)

class Range(Set):

    def __new__(cls, *args):
        if len(args) == 1:
            if isinstance(args[0], range):
                raise TypeError('use sympify(%s) to convert range to Range' % args[0])
        slc = slice(*args)
        if slc.step == 0:
            raise ValueError('step cannot be 0')
        start, stop, step = (slc.start or 0, slc.stop, slc.step or 1)
        try:
            ok = []
            for w in (start, stop, step):
                w = sympify(w)
                if w in [S.NegativeInfinity, S.Infinity] or (w.has(Symbol) and w.is_integer != False):
                    ok.append(w)
                elif not w.is_Integer:
                    if w.is_infinite:
                        raise ValueError('infinite symbols not allowed')
                    raise ValueError
                else:
                    ok.append(w)
        except ValueError:
            raise ValueError(filldedent('\n    Finite arguments to Range must be integers; `imageset` can define\n    other cases, e.g. use `imageset(i, i/10, Range(3))` to give\n    [0, 1/10, 1/5].'))
        start, stop, step = ok
        null = False
        if any((i.has(Symbol) for i in (start, stop, step))):
            dif = stop - start
            n = dif / step
            if n.is_Rational:
                if dif == 0:
                    null = True
                else:
                    n = floor(n)
                    end = start + n * step
                    if dif.is_Rational:
                        if (end - stop).is_negative:
                            end += step
                    elif (end / stop - 1).is_negative:
                        end += step
            elif n.is_extended_negative:
                null = True
            else:
                end = stop
        elif start.is_infinite:
            span = step * (stop - start)
            if span is S.NaN or span <= 0:
                null = True
            elif step.is_Integer and stop.is_infinite and (abs(step) != 1):
                raise ValueError(filldedent('\n                    Step size must be %s in this case.' % (1 if step > 0 else -1)))
            else:
                end = stop
        else:
            oostep = step.is_infinite
            if oostep:
                step = S.One if step > 0 else S.NegativeOne
            n = ceiling((stop - start) / step)
            if n <= 0:
                null = True
            elif oostep:
                step = S.One
                end = start + step
            else:
                end = start + n * step
        if null:
            start = end = S.Zero
            step = S.One
        return Basic.__new__(cls, start, end, step)
    start = property(lambda self: self.args[0])
    stop = property(lambda self: self.args[1])
    step = property(lambda self: self.args[2])

    @property
    def reversed(self):
        if self.has(Symbol):
            n = (self.stop - self.start) / self.step
            if not n.is_extended_positive or not all((i.is_integer or i.is_infinite for i in self.args)):
                raise ValueError('invalid method for symbolic range')
        if self.start == self.stop:
            return self
        return self.func(self.stop - self.step, self.start - self.step, -self.step)

    def _kind(self):
        return SetKind(NumberKind)

    def _contains(self, other):
        if self.start == self.stop:
            return S.false
        if other.is_infinite:
            return S.false
        if not other.is_integer:
            return tfn[other.is_integer]
        if self.has(Symbol):
            n = (self.stop - self.start) / self.step
            if not n.is_extended_positive or not all((i.is_integer or i.is_infinite for i in self.args)):
                return
        else:
            n = self.size
        if self.start.is_finite:
            ref = self.start
        elif self.stop.is_finite:
            ref = self.stop
        else:
            return S.true
        if n == 1:
            return Eq(other, self[0])
        res = (ref - other) % self.step
        if res == S.Zero:
            if self.has(Symbol):
                d = Dummy('i')
                return self.as_relational(d).subs(d, other)
            return And(other >= self.inf, other <= self.sup)
        elif res.is_Integer:
            return S.false
        else:
            return None

    def __iter__(self):
        n = self.size
        if not (n.has(S.Infinity) or n.has(S.NegativeInfinity) or n.is_Integer):
            raise TypeError('Cannot iterate over symbolic Range')
        if self.start in [S.NegativeInfinity, S.Infinity]:
            raise TypeError('Cannot iterate over Range with infinite start')
        elif self.start != self.stop:
            i = self.start
            if n.is_infinite:
                while True:
                    yield i
                    i += self.step
            else:
                for _ in range(n):
                    yield i
                    i += self.step

    @property
    def is_iterable(self):
        dif = self.stop - self.start
        n = dif / self.step
        if not (n.has(S.Infinity) or n.has(S.NegativeInfinity) or n.is_Integer):
            return False
        if self.start in [S.NegativeInfinity, S.Infinity]:
            return False
        if not (n.is_extended_nonnegative and all((i.is_integer for i in self.args))):
            return False
        return True

    def __len__(self):
        rv = self.size
        if rv is S.Infinity:
            raise ValueError('Use .size to get the length of an infinite Range')
        return int(rv)

    @property
    def size(self):
        if self.start == self.stop:
            return S.Zero
        dif = self.stop - self.start
        n = dif / self.step
        if n.is_infinite:
            return S.Infinity
        if n.is_extended_nonnegative and all((i.is_integer for i in self.args)):
            return abs(floor(n))
        raise ValueError('Invalid method for symbolic Range')

    @property
    def is_finite_set(self):
        if self.start.is_integer and self.stop.is_integer:
            return True
        return self.size.is_finite

    @property
    def is_empty(self):
        try:
            return self.size.is_zero
        except ValueError:
            return None

    def __bool__(self):
        b = is_eq(self.start, self.stop)
        if b is None:
            raise ValueError('cannot tell if Range is null or not')
        return not bool(b)

    def __getitem__(self, i):
        ooslice = 'cannot slice from the end with an infinite value'
        zerostep = 'slice step cannot be zero'
        infinite = 'slicing not possible on range with infinite start'
        ambiguous = 'cannot unambiguously re-stride from the end ' + 'with an infinite value'
        if isinstance(i, slice):
            if self.size.is_finite:
                if self.start == self.stop:
                    return Range(0)
                start, stop, step = i.indices(self.size)
                n = ceiling((stop - start) / step)
                if n <= 0:
                    return Range(0)
                canonical_stop = start + n * step
                end = canonical_stop - step
                ss = step * self.step
                return Range(self[start], self[end] + ss, ss)
            else:
                start = i.start
                stop = i.stop
                if i.step == 0:
                    raise ValueError(zerostep)
                step = i.step or 1
                ss = step * self.step
                if self.start.is_infinite and self.stop.is_infinite:
                    raise ValueError(infinite)
                if self.stop.is_infinite:
                    return self.reversed[stop if stop is None else -stop + 1:start if start is None else -start:step].reversed
                if start is None:
                    if stop is None:
                        if step < 0:
                            return Range(self[-1], self.start, ss)
                        elif step > 1:
                            raise ValueError(ambiguous)
                        else:
                            return self
                    elif stop < 0:
                        if step < 0:
                            return Range(self[-1], self[stop], ss)
                        else:
                            return Range(self.start, self[stop], ss)
                    elif stop == 0:
                        if step > 0:
                            return Range(0)
                        else:
                            raise ValueError(ooslice)
                    elif stop == 1:
                        if step > 0:
                            raise ValueError(ooslice)
                        else:
                            raise ValueError(ooslice)
                    else:
                        raise ValueError(ooslice)
                elif start < 0:
                    if stop is None:
                        if step < 0:
                            return Range(self[start], self.start, ss)
                        else:
                            return Range(self[start], self.stop, ss)
                    elif stop < 0:
                        return Range(self[start], self[stop], ss)
                    elif stop == 0:
                        if step < 0:
                            raise ValueError(ooslice)
                        else:
                            return Range(0)
                    elif stop > 0:
                        raise ValueError(ooslice)
                elif start == 0:
                    if stop is None:
                        if step < 0:
                            raise ValueError(ooslice)
                        elif step > 1:
                            raise ValueError(ambiguous)
                        else:
                            return self
                    elif stop < 0:
                        if step > 1:
                            raise ValueError(ambiguous)
                        elif step == 1:
                            return Range(self.start, self[stop], ss)
                        else:
                            return Range(0)
                    else:
                        raise ValueError(ooslice)
                elif start > 0:
                    raise ValueError(ooslice)
        else:
            if self.start == self.stop:
                raise IndexError('Range index out of range')
            if not (all((i.is_integer or i.is_infinite for i in self.args)) and ((self.stop - self.start) / self.step).is_extended_positive):
                raise ValueError('Invalid method for symbolic Range')
            if i == 0:
                if self.start.is_infinite:
                    raise ValueError(ooslice)
                return self.start
            if i == -1:
                if self.stop.is_infinite:
                    raise ValueError(ooslice)
                return self.stop - self.step
            n = self.size
            rv = (self.stop if i < 0 else self.start) + i * self.step
            if rv.is_infinite:
                raise ValueError(ooslice)
            val = (rv - self.start) / self.step
            rel = fuzzy_or([val.is_infinite, fuzzy_and([val.is_nonnegative, (n - val).is_nonnegative])])
            if rel:
                return rv
            if rel is None:
                raise ValueError('Invalid method for symbolic Range')
            raise IndexError('Range index out of range')

    @property
    def _inf(self):
        if not self:
            return S.EmptySet.inf
        if self.has(Symbol):
            if all((i.is_integer or i.is_infinite for i in self.args)):
                dif = self.stop - self.start
                if self.step.is_positive and dif.is_positive:
                    return self.start
                elif self.step.is_negative and dif.is_negative:
                    return self.stop - self.step
            raise ValueError('invalid method for symbolic range')
        if self.step > 0:
            return self.start
        else:
            return self.stop - self.step

    @property
    def _sup(self):
        if not self:
            return S.EmptySet.sup
        if self.has(Symbol):
            if all((i.is_integer or i.is_infinite for i in self.args)):
                dif = self.stop - self.start
                if self.step.is_positive and dif.is_positive:
                    return self.stop - self.step
                elif self.step.is_negative and dif.is_negative:
                    return self.start
            raise ValueError('invalid method for symbolic range')
        if self.step > 0:
            return self.stop - self.step
        else:
            return self.start

    @property
    def _boundary(self):
        return self

    def as_relational(self, x):
        if self.start.is_infinite:
            assert not self.stop.is_infinite
            a = self.reversed.start
        else:
            a = self.start
        step = self.step
        in_seq = Eq(Mod(x - a, step), 0)
        ints = And(Eq(Mod(a, 1), 0), Eq(Mod(step, 1), 0))
        n = (self.stop - self.start) / self.step
        if n == 0:
            return S.EmptySet.as_relational(x)
        if n == 1:
            return And(Eq(x, a), ints)
        try:
            a, b = (self.inf, self.sup)
        except ValueError:
            a = None
        if a is not None:
            range_cond = And(x > a if a.is_infinite else x >= a, x < b if b.is_infinite else x <= b)
        else:
            a, b = (self.start, self.stop - self.step)
            range_cond = Or(And(self.step >= 1, x > a if a.is_infinite else x >= a, x < b if b.is_infinite else x <= b), And(self.step <= -1, x < a if a.is_infinite else x <= a, x > b if b.is_infinite else x >= b))
        return And(in_seq, ints, range_cond)
_sympy_converter[range] = lambda r: Range(r.start, r.stop, r.step)

def normalize_theta_set(theta):
    from sympy.functions.elementary.trigonometric import _pi_coeff
    if theta.is_Interval:
        interval_len = theta.measure
        if interval_len >= 2 * S.Pi:
            if interval_len == 2 * S.Pi and theta.left_open and theta.right_open:
                k = _pi_coeff(theta.start)
                return Union(Interval(0, k * S.Pi, False, True), Interval(k * S.Pi, 2 * S.Pi, True, True))
            return Interval(0, 2 * S.Pi, False, True)
        k_start, k_end = (_pi_coeff(theta.start), _pi_coeff(theta.end))
        if k_start is None or k_end is None:
            raise NotImplementedError('Normalizing theta without pi as coefficient is not yet implemented')
        new_start = k_start * S.Pi
        new_end = k_end * S.Pi
        if new_start > new_end:
            return Union(Interval(S.Zero, new_end, False, theta.right_open), Interval(new_start, 2 * S.Pi, theta.left_open, True))
        else:
            return Interval(new_start, new_end, theta.left_open, theta.right_open)
    elif theta.is_FiniteSet:
        new_theta = []
        for element in theta:
            k = _pi_coeff(element)
            if k is None:
                raise NotImplementedError('Normalizing theta without pi as coefficient, is not Implemented.')
            else:
                new_theta.append(k * S.Pi)
        return FiniteSet(*new_theta)
    elif theta.is_Union:
        return Union(*[normalize_theta_set(interval) for interval in theta.args])
    elif theta.is_subset(S.Reals):
        raise NotImplementedError('Normalizing theta when, it is of type %s is not implemented' % type(theta))
    else:
        raise ValueError(' %s is not a real set' % theta)

class ComplexRegion(Set):
    is_ComplexRegion = True

    def __new__(cls, sets, polar=False):
        if polar is False:
            return CartesianComplexRegion(sets)
        elif polar is True:
            return PolarComplexRegion(sets)
        else:
            raise ValueError('polar should be either True or False')

    @property
    def sets(self):
        return self.args[0]

    @property
    def psets(self):
        if self.sets.is_ProductSet:
            psets = ()
            psets = psets + (self.sets,)
        else:
            psets = self.sets.args
        return psets

    @property
    def a_interval(self):
        a_interval = []
        for element in self.psets:
            a_interval.append(element.args[0])
        a_interval = Union(*a_interval)
        return a_interval

    @property
    def b_interval(self):
        b_interval = []
        for element in self.psets:
            b_interval.append(element.args[1])
        b_interval = Union(*b_interval)
        return b_interval

    @property
    def _measure(self):
        return self.sets._measure

    def _kind(self):
        return self.args[0].kind

    @classmethod
    def from_real(cls, sets):
        if not sets.is_subset(S.Reals):
            raise ValueError('sets must be a subset of the real line')
        return CartesianComplexRegion(sets * FiniteSet(0))

    def _contains(self, other):
        from sympy.functions import arg, Abs
        isTuple = isinstance(other, Tuple)
        if isTuple and len(other) != 2:
            raise ValueError('expecting Tuple of length 2')
        if not isinstance(other, (Expr, Tuple)):
            return S.false
        if not self.polar:
            re, im = other if isTuple else other.as_real_imag()
            return tfn[fuzzy_or((fuzzy_and([pset.args[0]._contains(re), pset.args[1]._contains(im)]) for pset in self.psets))]
        elif self.polar:
            if other.is_zero:
                return tfn[fuzzy_or((pset.args[0]._contains(S.Zero) for pset in self.psets))]
            if isTuple:
                r, theta = other
            else:
                r, theta = (Abs(other), arg(other))
            if theta.is_real and theta.is_number:
                theta %= 2 * S.Pi
                return tfn[fuzzy_or((fuzzy_and([pset.args[0]._contains(r), pset.args[1]._contains(theta)]) for pset in self.psets))]

class CartesianComplexRegion(ComplexRegion):
    polar = False
    variables = symbols('x, y', cls=Dummy)

    def __new__(cls, sets):
        if sets == S.Reals * S.Reals:
            return S.Complexes
        if all((_a.is_FiniteSet for _a in sets.args)) and len(sets.args) == 2:
            complex_num = []
            for x in sets.args[0]:
                for y in sets.args[1]:
                    complex_num.append(x + S.ImaginaryUnit * y)
            return FiniteSet(*complex_num)
        else:
            return Set.__new__(cls, sets)

    @property
    def expr(self):
        x, y = self.variables
        return x + S.ImaginaryUnit * y

class PolarComplexRegion(ComplexRegion):
    polar = True
    variables = symbols('r, theta', cls=Dummy)

    def __new__(cls, sets):
        new_sets = []
        if not sets.is_ProductSet:
            for k in sets.args:
                new_sets.append(k)
        else:
            new_sets.append(sets)
        for k, v in enumerate(new_sets):
            new_sets[k] = ProductSet(v.args[0], normalize_theta_set(v.args[1]))
        sets = Union(*new_sets)
        return Set.__new__(cls, sets)

    @property
    def expr(self):
        r, theta = self.variables
        return r * (cos(theta) + S.ImaginaryUnit * sin(theta))

class Complexes(CartesianComplexRegion, metaclass=Singleton):
    is_empty = False
    is_finite_set = False

    @property
    def sets(self):
        return ProductSet(S.Reals, S.Reals)

    def __new__(cls):
        return Set.__new__(cls)