from __future__ import annotations
from typing import TYPE_CHECKING, Iterator
from sympy.core.decorators import _sympifyit
from sympy.core.parameters import global_parameters
from sympy.core.logic import fuzzy_bool
from sympy.core.singleton import S
from sympy.core.sympify import _sympify
from .sets import Set, FiniteSet, SetKind

class PowerSet(Set):
    if TYPE_CHECKING:

        @property
        def args(self) -> tuple[Set]:
            pass

    def __new__(cls, arg, evaluate=None):
        if evaluate is None:
            evaluate = global_parameters.evaluate
        arg = _sympify(arg)
        if not isinstance(arg, Set):
            raise ValueError('{} must be a set.'.format(arg))
        return super().__new__(cls, arg)

    @property
    def arg(self):
        return self.args[0]

    def _eval_rewrite_as_FiniteSet(self, *args, **kwargs):
        arg = self.arg
        if arg.is_FiniteSet:
            return arg.powerset()
        return None

    @_sympifyit('other', NotImplemented)
    def _contains(self, other):
        if not isinstance(other, Set):
            return None
        return fuzzy_bool(self.arg.is_superset(other))

    def _eval_is_subset(self, other):
        if isinstance(other, PowerSet):
            return self.arg.is_subset(other.arg)
        return None

    def __len__(self) -> int:
        return 2 ** len(self.arg)

    def __iter__(self) -> Iterator[Set]:
        found = [S.EmptySet]
        yield S.EmptySet
        for x in self.arg:
            temp = []
            x = FiniteSet(x)
            for y in found:
                new = x + y
                yield new
                temp.append(new)
            found.extend(temp)

    @property
    def kind(self):
        return SetKind(self.arg.kind)