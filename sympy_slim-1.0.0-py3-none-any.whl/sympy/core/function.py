from __future__ import annotations
from typing import Any
from collections.abc import Iterable
import copyreg
from .add import Add
from .basic import Basic, _atomic
from .cache import cacheit
from .containers import Tuple, Dict
from .decorators import _sympifyit
from .evalf import pure_complex
from .expr import Expr, AtomicExpr
from .logic import fuzzy_and, fuzzy_or, fuzzy_not, FuzzyBool
from .mul import Mul
from .numbers import Rational, Float, Integer
from .operations import LatticeOp
from .parameters import global_parameters
from .rules import Transform
from .singleton import S
from .sympify import sympify, _sympify
from .sorting import default_sort_key, ordered
from sympy.utilities.exceptions import sympy_deprecation_warning, SymPyDeprecationWarning, ignore_warnings
from sympy.utilities.iterables import has_dups, sift, iterable, is_sequence, uniq, topological_sort
from sympy.utilities.lambdify import MPMATH_TRANSLATIONS
from sympy.utilities.misc import as_int, filldedent, func_name
import mpmath
from sympy.external.mpmath import prec_to_dps, mpf, mpc, mp, workprec, diff as mpmath_diff
import inspect
from collections import Counter

def _coeff_isneg(a):
    if a.is_MatMul:
        a = a.args[0]
    if a.is_Mul:
        a = a.args[0]
    return a.is_Number and a.is_extended_negative

class PoleError(Exception):
    pass

class ArgumentIndexError(ValueError):

    def __str__(self):
        return 'Invalid operation with argument number %s for Function %s' % (self.args[1], self.args[0])

class BadSignatureError(TypeError):
    pass

class BadArgumentsError(TypeError):
    pass

def arity(cls):
    eval_ = getattr(cls, 'eval', cls)
    parameters = inspect.signature(eval_).parameters.items()
    if [p for _, p in parameters if p.kind == p.VAR_POSITIONAL]:
        return
    p_or_k = [p for _, p in parameters if p.kind == p.POSITIONAL_OR_KEYWORD]
    no, yes = map(len, sift(p_or_k, lambda p: p.default == p.empty, binary=True))
    return no if not yes else tuple(range(no, no + yes + 1))

class FunctionClass(type):
    _new = type.__new__

    def __init__(cls, *args, **kwargs):
        nargs = kwargs.pop('nargs', cls.__dict__.get('nargs', arity(cls)))
        if nargs is None and 'nargs' not in cls.__dict__:
            for supcls in cls.__mro__:
                if hasattr(supcls, '_nargs'):
                    nargs = supcls._nargs
                    break
                else:
                    continue
        if is_sequence(nargs):
            if not nargs:
                raise ValueError(filldedent('\n                    Incorrectly specified nargs as %s:\n                    if there are no arguments, it should be\n                    `nargs = 0`;\n                    if there are any number of arguments,\n                    it should be\n                    `nargs = None`' % str(nargs)))
            nargs = tuple(ordered(set(nargs)))
        elif nargs is not None:
            nargs = (as_int(nargs),)
        cls._nargs = nargs
        if len(args) == 3:
            namespace = args[2]
            if 'eval' in namespace and (not isinstance(namespace['eval'], classmethod)):
                raise TypeError('eval on Function subclasses should be a class method (defined with @classmethod)')

    @property
    def __signature__(self):
        try:
            from inspect import signature
        except ImportError:
            return None
        return signature(self.eval)

    @property
    def free_symbols(self):
        return set()

    @property
    def xreplace(self):
        return lambda rule, **_: rule.get(self, self)

    @property
    def nargs(self):
        from sympy.sets.sets import FiniteSet
        return FiniteSet(*self._nargs) if self._nargs else S.Naturals0

    def _valid_nargs(self, n: int) -> bool:
        if self._nargs:
            return n in self._nargs
        nargs = self.nargs
        return nargs is S.Naturals0 or n in nargs

    def __repr__(cls):
        return cls.__name__

class Application(Basic, metaclass=FunctionClass):
    is_Function = True

    @cacheit
    def __new__(cls, *args, **options):
        from sympy.sets.fancysets import Naturals0
        from sympy.sets.sets import FiniteSet
        args = list(map(sympify, args))
        evaluate = options.pop('evaluate', global_parameters.evaluate)
        options.pop('nargs', None)
        if options:
            raise ValueError('Unknown options: %s' % options)
        if evaluate:
            evaluated = cls.eval(*args)
            if evaluated is not None:
                return evaluated
        obj = super().__new__(cls, *args, **options)
        sentinel = object()
        objnargs = getattr(obj, 'nargs', sentinel)
        if objnargs is not sentinel:
            if is_sequence(objnargs):
                nargs = tuple(ordered(set(objnargs)))
            elif objnargs is not None:
                nargs = (as_int(objnargs),)
            else:
                nargs = None
        else:
            nargs = obj._nargs
        obj.nargs = FiniteSet(*nargs) if nargs else Naturals0()
        return obj

    @classmethod
    def eval(cls, *args):
        return

    @property
    def func(self):
        return self.__class__

    def _eval_subs(self, old, new):
        if old.is_Function and new.is_Function and callable(old) and callable(new) and (old == self.func) and (len(self.args) in new.nargs):
            return new(*[i._subs(old, new) for i in self.args])

class Function(Application, Expr):

    @property
    def _diff_wrt(self):
        return False

    @cacheit
    def __new__(cls, *args, **options) -> type[AppliedUndef]:
        if cls is Function:
            return UndefinedFunction(*args, **options)
        else:
            return cls._new_(*args, **options)

    @classmethod
    def _new_(cls, *args, **options) -> Expr:
        n = len(args)
        if not cls._valid_nargs(n):
            temp = '%(name)s takes %(qual)s %(args)s argument%(plural)s (%(given)s given)'
            raise TypeError(temp % {'name': cls, 'qual': 'exactly' if len(cls.nargs) == 1 else 'at least', 'args': min(cls.nargs), 'plural': 's' * (min(cls.nargs) != 1), 'given': n})
        evaluate = options.get('evaluate', global_parameters.evaluate)
        result = super().__new__(cls, *args, **options)
        if evaluate and isinstance(result, cls) and result.args:
            _should_evalf = [cls._should_evalf(a) for a in result.args]
            pr2 = min(_should_evalf)
            if pr2 > 0:
                pr = max(_should_evalf)
                result = result.evalf(prec_to_dps(pr))
        return _sympify(result)

    @classmethod
    def _should_evalf(cls, arg):
        if arg.is_Float:
            return arg._prec
        if not arg.is_Add:
            return -1
        m = pure_complex(arg)
        if m is None:
            return -1
        return max(m[0]._prec, m[1]._prec)

    @classmethod
    def class_key(cls):
        from sympy.sets.fancysets import Naturals0
        funcs = {'exp': 10, 'log': 11, 'sin': 20, 'cos': 21, 'tan': 22, 'cot': 23, 'sinh': 30, 'cosh': 31, 'tanh': 32, 'coth': 33, 'conjugate': 40, 're': 41, 'im': 42, 'arg': 43}
        name = cls.__name__
        try:
            i = funcs[name]
        except KeyError:
            i = 0 if isinstance(cls.nargs, Naturals0) else 10000
        return (4, i, name)

    def _eval_evalf(self, prec):

        def _get_mpmath_func(fname):
            if isinstance(self, AppliedUndef):
                return None
            if not hasattr(mpmath, fname):
                fname = MPMATH_TRANSLATIONS.get(fname, None)
                if fname is None:
                    return None
            return getattr(mpmath, fname)
        _eval_mpmath = getattr(self, '_eval_mpmath', None)
        if _eval_mpmath is None:
            func = _get_mpmath_func(self.func.__name__)
            args = self.args
        else:
            func, args = _eval_mpmath()
        if func is None:
            imp = getattr(self, '_imp_', None)
            if imp is None:
                return None
            try:
                return Float(imp(*[i.evalf(prec) for i in self.args]), prec)
            except (TypeError, ValueError):
                return None
        try:
            args = [arg._to_mpmath(prec + 5) for arg in args]

            def bad(m):
                if isinstance(m, mpf):
                    m = m._mpf_
                    return m[1] != 1 and m[-1] == 1
                elif isinstance(m, mpc):
                    m, n = m._mpc_
                    return m[1] != 1 and m[-1] == 1 and (n[1] != 1) and (n[-1] == 1)
                else:
                    return False
            if any((bad(a) for a in args)):
                raise ValueError
        except ValueError:
            return
        with workprec(prec):
            v = func(*args)
        return Expr._from_mpmath(v, prec)

    def _eval_derivative(self, s):
        i = 0
        l = []
        for a in self.args:
            i += 1
            da = a.diff(s)
            if da.is_zero:
                continue
            try:
                df = self.fdiff(i)
            except ArgumentIndexError:
                df = Function.fdiff(self, i)
            l.append(df * da)
        return Add(*l)

    def _eval_is_commutative(self):
        return fuzzy_and((a.is_commutative for a in self.args))

    def _eval_is_meromorphic(self, x, a):
        if not self.args:
            return True
        if any((arg.has(x) for arg in self.args[1:])):
            return False
        arg = self.args[0]
        if not arg._eval_is_meromorphic(x, a):
            return None
        return fuzzy_not(type(self).is_singular(arg.subs(x, a)))
    _singularities: FuzzyBool | tuple[Expr, ...] = None

    @classmethod
    def is_singular(cls, a):
        ss = cls._singularities
        if ss in (True, None, False):
            return ss
        return fuzzy_or((a.is_infinite if s is S.ComplexInfinity else (a - s).is_zero for s in ss))

    def _eval_aseries(self, n, args0, x, logx):
        raise PoleError(filldedent('\n            Asymptotic expansion of %s around %s is\n            not implemented.' % (type(self), args0)))

    def _eval_nseries(self, x, n, logx, cdir=0):
        from .symbol import uniquely_named_symbol
        from sympy.series.order import Order
        from sympy.sets.sets import FiniteSet
        args = self.args
        args0 = [t.limit(x, 0) for t in args]
        if any((t.is_finite is False for t in args0)):
            from .numbers import oo, zoo, nan
            a = [t.as_leading_term(x, logx=logx) for t in args]
            a0 = [t.limit(x, 0) for t in a]
            if any((t.has(oo, -oo, zoo, nan) for t in a0)):
                return self._eval_aseries(n, args0, x, logx)
            a = [t._eval_nseries(x, n, logx) for t in args]
            z = [r - r0 for r, r0 in zip(a, a0)]
            p = [Dummy() for _ in z]
            q = []
            v = None
            for ai, zi, pi in zip(a0, z, p):
                if zi.has(x):
                    if v is not None:
                        raise NotImplementedError
                    q.append(ai + pi)
                    v = pi
                else:
                    q.append(ai)
            e1 = self.func(*q)
            if v is None:
                return e1
            s = e1._eval_nseries(v, n, logx)
            o = s.getO()
            s = s.removeO()
            s = s.subs(v, zi).expand() + Order(o.expr.subs(v, zi), x)
            return s
        if self.func.nargs is S.Naturals0 or (self.func.nargs == FiniteSet(1) and args0[0]) or any((c > 1 for c in self.func.nargs)):
            e = self
            e1 = e.expand()
            if e == e1:
                if len(e.args) == 1:
                    e = e.func(e.args[0].cancel())
                term = e.subs(x, S.Zero)
                if term.is_finite is False or term is S.NaN:
                    raise PoleError('Cannot expand %s around 0' % self)
                series = term
                fact = S.One
                _x = uniquely_named_symbol('xi', self)
                e = e.subs(x, _x)
                for i in range(1, n):
                    fact *= Rational(i)
                    e = e.diff(_x)
                    subs = e.subs(_x, S.Zero)
                    if subs is S.NaN:
                        subs = e.limit(_x, S.Zero)
                    if subs.is_finite is False:
                        raise PoleError('Cannot expand %s around 0' % self)
                    term = subs * x ** i / fact
                    term = term.expand()
                    series += term
                return series + Order(x ** n, x)
            return e1.nseries(x, n=n, logx=logx)
        arg = self.args[0]
        l = []
        g = None
        nterms = n + 2
        cf = Order(arg.as_leading_term(x), x).getn()
        if cf != 0:
            nterms = (n / cf).ceiling()
        for i in range(nterms):
            g = self.taylor_term(i, arg, g)
            g = g.nseries(x, n=n, logx=logx)
            l.append(g)
        return Add(*l) + Order(x ** n, x)

    def fdiff(self, argindex=1):
        if not 1 <= argindex <= len(self.args):
            raise ArgumentIndexError(self, argindex)
        ix = argindex - 1
        A = self.args[ix]
        if A._diff_wrt:
            if len(self.args) == 1 or not A.is_Symbol:
                return _derivative_dispatch(self, A)
            for i, v in enumerate(self.args):
                if i != ix and A in v.free_symbols:
                    break
            else:
                return _derivative_dispatch(self, A)
        D = Dummy('xi_%i' % argindex, dummy_index=hash(A))
        args = self.args[:ix] + (D,) + self.args[ix + 1:]
        return Subs(Derivative(self.func(*args), D), D, A)

    def _eval_as_leading_term(self, x, logx, cdir):
        from sympy.series.order import Order
        args = [a.as_leading_term(x, logx=logx) for a in self.args]
        o = Order(1, x)
        if any((x in a.free_symbols and o.contains(a) for a in args)):
            raise NotImplementedError('%s has no _eval_as_leading_term routine' % self.func)
        else:
            return self

class DefinedFunction(Function):

    @cacheit
    def __new__(cls, *args, **options) -> Expr:
        return cls._new_(*args, **options)

class AppliedUndef(Function):
    is_number = False
    name: str

    def __new__(cls, *args, **options) -> Expr:
        args = tuple(map(sympify, args))
        u = [a.name for a in args if isinstance(a, UndefinedFunction)]
        if u:
            raise TypeError('Invalid argument: expecting an expression, not UndefinedFunction%s: %s' % ('s' * (len(u) > 1), ', '.join(u)))
        obj: Expr = super().__new__(cls, *args, **options)
        return obj

    def _eval_as_leading_term(self, x, logx, cdir):
        return self

    @property
    def _diff_wrt(self):
        return True

class UndefSageHelper:

    def __get__(self, ins, typ):
        import sage.all as sage
        if ins is None:
            return lambda: sage.function(typ.__name__)
        else:
            args = [arg._sage_() for arg in ins.args]
            return lambda: sage.function(ins.__class__.__name__)(*args)
_undef_sage_helper = UndefSageHelper()

class UndefinedFunction(FunctionClass):
    name: str
    _sage_: UndefSageHelper

    def __new__(mcl, name, bases=(AppliedUndef,), __dict__=None, **kwargs) -> type[AppliedUndef]:
        from .symbol import _filter_assumptions
        assumptions, kwargs = _filter_assumptions(kwargs)
        if isinstance(name, Symbol):
            assumptions = name._merge(assumptions)
            name = name.name
        elif not isinstance(name, str):
            raise TypeError('expecting string or Symbol for name')
        else:
            commutative = assumptions.get('commutative', None)
            assumptions = Symbol(name, **assumptions).assumptions0
            if commutative is None:
                assumptions.pop('commutative')
        __dict__ = __dict__ or {}
        __dict__.update({'is_%s' % k: v for k, v in assumptions.items()})
        __dict__.update(kwargs)
        kwargs.update(assumptions)
        __dict__.update({'_kwargs': kwargs})
        __dict__['__module__'] = None
        obj = super().__new__(mcl, name, bases, __dict__)
        obj.name = name
        obj._sage_ = _undef_sage_helper
        return obj

    def __instancecheck__(cls, instance):
        return cls in type(instance).__mro__
    _kwargs: dict[str, bool | None] = {}

    def __hash__(self):
        return hash((self.class_key(), frozenset(self._kwargs.items())))

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.class_key() == other.class_key() and (self._kwargs == other._kwargs)

    def __ne__(self, other):
        return not self == other

    @property
    def _diff_wrt(self):
        return False

def _reduce_undef(f):
    return (_rebuild_undef, (f.name, f._kwargs))

def _rebuild_undef(name, kwargs):
    return Function(name, **kwargs)
copyreg.pickle(UndefinedFunction, _reduce_undef)

class WildFunction(Function, AtomicExpr):
    include: set[Any] = set()

    def __init__(cls, name, **assumptions):
        from sympy.sets.sets import Set, FiniteSet
        cls.name = name
        nargs = assumptions.pop('nargs', S.Naturals0)
        if not isinstance(nargs, Set):
            if is_sequence(nargs):
                nargs = tuple(ordered(set(nargs)))
            elif nargs is not None:
                nargs = (as_int(nargs),)
            nargs = FiniteSet(*nargs)
        cls.nargs = nargs

    def matches(self, expr, repl_dict=None, old=False):
        if not isinstance(expr, (AppliedUndef, Function)):
            return None
        if len(expr.args) not in self.nargs:
            return None
        if repl_dict is None:
            repl_dict = {}
        else:
            repl_dict = repl_dict.copy()
        repl_dict[self] = expr
        return repl_dict

class Derivative(Expr):
    is_Derivative = True

    @property
    def _diff_wrt(self):
        return self.expr._diff_wrt and isinstance(self.doit(), Derivative)

    def __new__(cls, expr, *variables, **kwargs):
        expr = sympify(expr)
        if not isinstance(expr, Basic):
            raise TypeError(f'Cannot represent derivative of {type(expr)}')
        symbols_or_none = getattr(expr, 'free_symbols', None)
        has_symbol_set = isinstance(symbols_or_none, set)
        if not has_symbol_set:
            raise ValueError(filldedent('\n                Since there are no variables in the expression %s,\n                it cannot be differentiated.' % expr))
        if not variables:
            variables = expr.free_symbols
            if len(variables) != 1:
                if expr.is_number:
                    return S.Zero
                if len(variables) == 0:
                    raise ValueError(filldedent('\n                        Since there are no variables in the expression,\n                        the variable(s) of differentiation must be supplied\n                        to differentiate %s' % expr))
                else:
                    raise ValueError(filldedent('\n                        Since there is more than one variable in the\n                        expression, the variable(s) of differentiation\n                        must be supplied to differentiate %s' % expr))
        variable_count = []
        array_likes = (tuple, list, Tuple)
        from sympy.tensor.array import Array, NDimArray
        for i, v in enumerate(variables):
            if isinstance(v, UndefinedFunction):
                raise TypeError('cannot differentiate wrt UndefinedFunction: %s' % v)
            if isinstance(v, array_likes):
                if len(v) == 0:
                    continue
                if isinstance(v[0], array_likes):
                    if len(v) == 1:
                        v = Array(v[0])
                        count = 1
                    else:
                        v, count = v
                        v = Array(v)
                else:
                    v, count = v
                if count == 0:
                    continue
                variable_count.append(Tuple(v, count))
                continue
            v = sympify(v)
            if isinstance(v, Integer):
                if i == 0:
                    raise ValueError('First variable cannot be a number: %i' % v)
                count = v
                prev, prevcount = variable_count[-1]
                if prevcount != 1:
                    raise TypeError('tuple {} followed by number {}'.format((prev, prevcount), v))
                if count == 0:
                    variable_count.pop()
                else:
                    variable_count[-1] = Tuple(prev, count)
            else:
                count = 1
                variable_count.append(Tuple(v, count))
        merged = []
        for t in variable_count:
            v, c = t
            if c.is_negative:
                raise ValueError('order of differentiation must be nonnegative')
            if merged and merged[-1][0] == v:
                c += merged[-1][1]
                if not c:
                    merged.pop()
                else:
                    merged[-1] = Tuple(v, c)
            else:
                merged.append(t)
        variable_count = merged
        for v, c in variable_count:
            if not v._diff_wrt:
                __ = ''
                raise ValueError(filldedent("\n                    Can't calculate derivative wrt %s.%s" % (v, __)))
        if len(variable_count) == 0:
            return expr
        evaluate = kwargs.get('evaluate', False)
        if evaluate:
            if isinstance(expr, Derivative):
                expr = expr.canonical
            variable_count = [(v.canonical if isinstance(v, Derivative) else v, c) for v, c in variable_count]
            zero = False
            free = expr.free_symbols
            from sympy.matrices.expressions.matexpr import MatrixExpr, MatrixElement
            for v, c in variable_count:
                vfree = v.free_symbols
                if c.is_positive and vfree:
                    if isinstance(v, AppliedUndef):
                        D = Dummy()
                        if not expr.xreplace({v: D}).has(D):
                            zero = True
                            break
                    elif isinstance(v, MatrixExpr):
                        zero = False
                        break
                    elif isinstance(v, MatrixElement):
                        zero = False
                        break
                    elif isinstance(v, Symbol) and v not in free:
                        zero = True
                        break
                    elif not free & vfree:
                        zero = True
                        break
            if zero:
                return cls._get_zero_with_shape_like(expr)
            variable_count = cls._sort_variable_count(variable_count)
        if isinstance(expr, Derivative):
            variable_count = list(expr.variable_count) + variable_count
            expr = expr.expr
            return _derivative_dispatch(expr, *variable_count, **kwargs)
        if not evaluate or not hasattr(expr, '_eval_derivative'):
            if evaluate and variable_count == [(expr, 1)] and expr.is_scalar:
                return S.One
            return Expr.__new__(cls, expr, *variable_count)
        nderivs = 0
        unhandled = []
        from sympy.matrices.matrixbase import MatrixBase
        for i, (v, count) in enumerate(variable_count):
            old_expr = expr
            old_v = None
            is_symbol = v.is_symbol or isinstance(v, (Iterable, Tuple, MatrixBase, NDimArray))
            if not is_symbol:
                old_v = v
                v = Dummy('xi')
                expr = expr.xreplace({old_v: v})
                clashing = not isinstance(old_v, (Derivative, AppliedUndef))
                if v not in expr.free_symbols and (not clashing):
                    return expr.diff(v)
                if not old_v.is_scalar and (not hasattr(old_v, '_eval_derivative')):
                    expr *= old_v.diff(old_v)
            obj = cls._dispatch_eval_derivative_n_times(expr, v, count)
            if obj is not None and obj.is_zero:
                return obj
            nderivs += count
            if old_v is not None:
                if obj is not None:
                    obj = obj.subs(v, old_v)
                expr = old_expr
            if obj is None:
                unhandled = variable_count[i:]
                break
            expr = obj
        expr = expr.replace(lambda x: isinstance(x, Derivative), lambda x: x.canonical)
        if unhandled:
            if isinstance(expr, Derivative):
                unhandled = list(expr.variable_count) + unhandled
                expr = expr.expr
            expr = Expr.__new__(cls, expr, *unhandled)
        if (nderivs > 1) == True and kwargs.get('simplify', True):
            from .exprtools import factor_terms
            from sympy.simplify.simplify import signsimp
            expr = factor_terms(signsimp(expr))
        return expr

    @property
    def canonical(cls):
        return cls.func(cls.expr, *Derivative._sort_variable_count(cls.variable_count))

    @classmethod
    def _sort_variable_count(cls, vc):
        if not vc:
            return []
        vc = list(vc)
        if len(vc) == 1:
            return [Tuple(*vc[0])]
        V = list(range(len(vc)))
        E = []
        v = lambda i: vc[i][0]
        D = Dummy()

        def _block(d, v, wrt=False):
            if d == v:
                return wrt
            if d.is_Symbol:
                return False
            if isinstance(d, Derivative):
                if any((_block(k, v, wrt=True) for k in d._wrt_variables)):
                    return True
                return False
            if not wrt and isinstance(d, AppliedUndef):
                return False
            if v.is_Symbol:
                return v in d.free_symbols
            if isinstance(v, AppliedUndef):
                return _block(d.xreplace({v: D}), D)
            return d.free_symbols & v.free_symbols
        for i in range(len(vc)):
            for j in range(i):
                if _block(v(j), v(i)):
                    E.append((j, i))
        O = dict(zip(ordered(uniq([i for i, c in vc])), range(len(vc))))
        ix = topological_sort((V, E), key=lambda i: O[v(i)])
        merged = []
        for v, c in [vc[i] for i in ix]:
            if merged and merged[-1][0] == v:
                merged[-1][1] += c
            else:
                merged.append([v, c])
        return [Tuple(*i) for i in merged]

    def _eval_is_commutative(self):
        return self.expr.is_commutative

    def _eval_derivative(self, v):
        if v not in self._wrt_variables:
            dedv = self.expr.diff(v)
            if isinstance(dedv, Derivative):
                return dedv.func(dedv.expr, *self.variable_count + dedv.variable_count)
            return self.func(dedv, *self.variables, evaluate=True)
        variable_count = list(self.variable_count)
        variable_count.append((v, 1))
        return self.func(self.expr, *variable_count, evaluate=False)

    def doit(self, **hints):
        expr = self.expr
        if hints.get('deep', True):
            expr = expr.doit(**hints)
        hints['evaluate'] = True
        rv = self.func(expr, *self.variable_count, **hints)
        if rv != self and rv.has(Derivative):
            rv = rv.doit(**hints)
        return rv

    @_sympifyit('z0', NotImplementedError)
    def doit_numerically(self, z0):
        if len(self.free_symbols) != 1 or len(self.variables) != 1:
            raise NotImplementedError('partials and higher order derivatives')
        z = list(self.free_symbols)[0]

        def eval(x):
            f0 = self.expr.subs(z, Expr._from_mpmath(x, prec=mp.prec))
            f0 = f0.evalf(prec_to_dps(mp.prec))
            return f0._to_mpmath(mp.prec)
        fp = mpmath_diff(eval, z0._to_mpmath(mp.prec))
        return Expr._from_mpmath(fp, mp.prec)

    @property
    def expr(self):
        return self._args[0]

    @property
    def _wrt_variables(self):
        return [i[0] for i in self.variable_count]

    @property
    def variables(self):
        rv = []
        for v, count in self.variable_count:
            if not count.is_Integer:
                raise TypeError(filldedent('\n                Cannot give expansion for symbolic count. If you just\n                want a list of all variables of differentiation, use\n                _wrt_variables.'))
            rv.extend([v] * count)
        return tuple(rv)

    @property
    def variable_count(self):
        return self._args[1:]

    @property
    def derivative_count(self):
        return sum([count for _, count in self.variable_count], 0)

    @property
    def free_symbols(self):
        ret = self.expr.free_symbols
        for _, count in self.variable_count:
            ret.update(count.free_symbols)
        return ret

    @property
    def kind(self):
        return self.args[0].kind

    def _eval_subs(self, old, new):
        if old in self._wrt_variables:
            expr = self.func(self.expr, *[(v, c.subs(old, new)) for v, c in self.variable_count])
            if expr != self:
                return expr._eval_subs(old, new)
            if not getattr(new, '_diff_wrt', False):
                if isinstance(old, Symbol):
                    return Subs(self, old, new)
                else:
                    xi = Dummy('xi')
                    return Subs(self.xreplace({old: xi}), xi, new)
        if old.is_Derivative and old.expr == self.expr:
            if self.canonical == old.canonical:
                return new

            def _subset(a, b):
                return all(((a[i] <= b[i]) == True for i in a))
            old_vars = Counter(dict(reversed(old.variable_count)))
            self_vars = Counter(dict(reversed(self.variable_count)))
            if _subset(old_vars, self_vars):
                return _derivative_dispatch(new, *(self_vars - old_vars).items()).canonical
        args = list(self.args)
        newargs = [x._subs(old, new) for x in args]
        if args[0] == old:
            return _derivative_dispatch(*newargs)
        if newargs[0] != args[0]:
            syms = {vi: Dummy() for vi in self._wrt_variables if not vi.is_Symbol}
            wrt = {syms.get(vi, vi) for vi in self._wrt_variables}
            forbidden = args[0].xreplace(syms).free_symbols & wrt
            nfree = new.xreplace(syms).free_symbols
            ofree = old.xreplace(syms).free_symbols
            if nfree - ofree & forbidden:
                return Subs(self, old, new)
        viter = ((i, j) for (i, _), (j, _) in zip(newargs[1:], args[1:]))
        if any((i != j for i, j in viter)):
            for a in _atomic(self.expr, recursive=True):
                for i in range(1, len(newargs)):
                    vi, _ = newargs[i]
                    if a == vi and vi != args[i][0]:
                        return Subs(self, old, new)
            vc = newargs[1:]
            oldv = self._wrt_variables
            newe = self.expr
            subs = []
            for i, (vi, ci) in enumerate(vc):
                if not vi._diff_wrt:
                    xi = Dummy('xi_%i' % i)
                    newe = newe.xreplace({oldv[i]: xi})
                    vc[i] = (xi, ci)
                    subs.append((xi, vi))
            if subs:
                newe = newe._subs(old, new)
                return Subs(Derivative(newe, *vc), *zip(*subs))
        return _derivative_dispatch(*newargs)

    def _eval_lseries(self, x, logx, cdir=0):
        dx = self.variables
        for term in self.expr.lseries(x, logx=logx, cdir=cdir):
            yield self.func(term, *dx)

    def _eval_nseries(self, x, n, logx, cdir=0):
        arg = self.expr.nseries(x, n=n, logx=logx)
        o = arg.getO()
        dx = self.variables
        rv = [self.func(a, *dx) for a in Add.make_args(arg.removeO())]
        if o:
            rv.append(o / x)
        return Add(*rv)

    def _eval_as_leading_term(self, x, logx, cdir):
        series_gen = self.expr.lseries(x)
        d = S.Zero
        for leading_term in series_gen:
            d = diff(leading_term, *self.variables)
            if d != 0:
                break
        return d

    def as_finite_difference(self, points=1, x0=None, wrt=None):
        from sympy.calculus.finite_diff import _as_finite_diff
        return _as_finite_diff(self, points, x0, wrt)

    @classmethod
    def _get_zero_with_shape_like(cls, expr):
        return S.Zero

    @classmethod
    def _dispatch_eval_derivative_n_times(cls, expr, v, count):
        return expr._eval_derivative_n_times(v, count)

def _derivative_dispatch(expr, *variables, **kwargs):
    from sympy.matrices.matrixbase import MatrixBase
    from sympy.matrices.expressions.matexpr import MatrixExpr
    from sympy.tensor.array import NDimArray
    array_types = (MatrixBase, MatrixExpr, NDimArray, list, tuple, Tuple)
    if isinstance(expr, array_types) or any((isinstance(i[0], array_types) if isinstance(i, (tuple, list, Tuple)) else isinstance(i, array_types) for i in variables)):
        from sympy.tensor.array.array_derivatives import ArrayDerivative
        return ArrayDerivative(expr, *variables, **kwargs)
    return Derivative(expr, *variables, **kwargs)

class Lambda(Expr):
    is_Function = True

    def __new__(cls, signature, expr) -> Lambda:
        if iterable(signature) and (not isinstance(signature, (tuple, Tuple))):
            sympy_deprecation_warning('\n                Using a non-tuple iterable as the first argument to Lambda\n                is deprecated. Use Lambda(tuple(args), expr) instead.\n                ', deprecated_since_version='1.5', active_deprecations_target='deprecated-non-tuple-lambda')
            signature = tuple(signature)
        _sig = signature if iterable(signature) else (signature,)
        sig: Tuple = sympify(_sig)
        cls._check_signature(sig)
        if len(sig) == 1 and sig[0] == expr:
            return S.IdentityFunction
        return Expr.__new__(cls, sig, sympify(expr))

    @classmethod
    def _check_signature(cls, sig):
        syms = set()

        def rcheck(args):
            for a in args:
                if a.is_symbol:
                    if a in syms:
                        raise BadSignatureError('Duplicate symbol %s' % a)
                    syms.add(a)
                elif isinstance(a, Tuple):
                    rcheck(a)
                else:
                    raise BadSignatureError('Lambda signature should be only tuples and symbols, not %s' % a)
        if not isinstance(sig, Tuple):
            raise BadSignatureError('Lambda signature should be a tuple not %s' % sig)
        rcheck(sig)

    @property
    def signature(self):
        return self._args[0]

    @property
    def expr(self):
        return self._args[1]

    @property
    def variables(self):

        def _variables(args):
            if isinstance(args, Tuple):
                for arg in args:
                    yield from _variables(arg)
            else:
                yield args
        return tuple(_variables(self.signature))

    @property
    def nargs(self):
        from sympy.sets.sets import FiniteSet
        return FiniteSet(len(self.signature))
    bound_symbols = variables

    @property
    def free_symbols(self):
        return self.expr.free_symbols - set(self.variables)

    def __call__(self, *args):
        n = len(args)
        if n not in self.nargs:
            temp = '%(name)s takes exactly %(args)s argument%(plural)s (%(given)s given)'
            raise BadArgumentsError(temp % {'name': self, 'args': list(self.nargs)[0], 'plural': 's' * (list(self.nargs)[0] != 1), 'given': n})
        d = self._match_signature(self.signature, args)
        return self.expr.xreplace(d)

    def _match_signature(self, sig, args):
        symargmap = {}

        def rmatch(pars, args):
            for par, arg in zip(pars, args):
                if par.is_symbol:
                    symargmap[par] = arg
                elif isinstance(par, Tuple):
                    if not isinstance(arg, (tuple, Tuple)) or len(args) != len(pars):
                        raise BadArgumentsError("Can't match %s and %s" % (args, pars))
                    rmatch(par, arg)
        rmatch(sig, args)
        return symargmap

    @property
    def is_identity(self):
        return self.signature == self.expr

    def _eval_evalf(self, prec):
        return self.func(self.args[0], self.args[1].evalf(n=prec_to_dps(prec)))

class Subs(Expr):

    def __new__(cls, expr, variables, point, **assumptions):
        if not is_sequence(variables, Tuple):
            variables = [variables]
        variables = Tuple(*variables)
        if has_dups(variables):
            repeated = [str(v) for v, i in Counter(variables).items() if i > 1]
            __ = ', '.join(repeated)
            raise ValueError(filldedent('\n                The following expressions appear more than once: %s\n                ' % __))
        point = Tuple(*(point if is_sequence(point, Tuple) else [point]))
        if len(point) != len(variables):
            raise ValueError('Number of point values must be the same as the number of variables.')
        if not point:
            return sympify(expr)
        if isinstance(expr, Subs):
            variables = expr.variables + variables
            point = expr.point + point
            expr = expr.expr
        else:
            expr = sympify(expr)
        pre = '_'
        pts = sorted(set(point), key=default_sort_key)
        from sympy.printing.str import StrPrinter

        class CustomStrPrinter(StrPrinter):

            def _print_Dummy(self, expr):
                return str(expr) + str(expr.dummy_index)

        def mystr(expr, **settings):
            p = CustomStrPrinter(settings)
            return p.doprint(expr)
        while 1:
            s_pts = {p: Symbol(pre + mystr(p)) for p in pts}
            reps = [(v, s_pts[p]) for v, p in zip(variables, point)]
            if any((r in expr.free_symbols and r in variables and (Symbol(pre + mystr(point[variables.index(r)])) != r) for _, r in reps)):
                pre += '_'
                continue
            break
        obj = Expr.__new__(cls, expr, Tuple(*variables), point)
        obj._expr = expr.xreplace(dict(reps))
        return obj

    def _eval_is_commutative(self):
        return self.expr.is_commutative

    def doit(self, **hints):
        e, v, p = self.args
        for i, (vi, pi) in enumerate(zip(v, p)):
            if vi == pi:
                v = v[:i] + v[i + 1:]
                p = p[:i] + p[i + 1:]
        if not v:
            return self.expr
        if isinstance(e, Derivative):
            undone = []
            for i, vi in enumerate(v):
                if isinstance(vi, FunctionClass):
                    e = e.subs(vi, p[i])
                else:
                    undone.append((vi, p[i]))
            if not isinstance(e, Derivative):
                e = e.doit()
            if isinstance(e, Derivative):
                undone2 = []
                D = Dummy()
                arg = e.args[0]
                for vi, pi in undone:
                    if D not in e.xreplace({vi: D}).free_symbols:
                        if arg.has(vi):
                            e = e.subs(vi, pi)
                    else:
                        undone2.append((vi, pi))
                undone = undone2
                wrt = []
                D = Dummy()
                expr = e.expr
                free = expr.free_symbols
                for vi, ci in e.variable_count:
                    if isinstance(vi, Symbol) and vi in free:
                        expr = expr.diff((vi, ci))
                    elif D in expr.subs(vi, D).free_symbols:
                        expr = expr.diff((vi, ci))
                    else:
                        wrt.append((vi, ci))
                rv = expr.subs(undone)
                for vc in wrt:
                    rv = rv.diff(vc)
            else:
                rv = e.subs(undone)
        else:
            rv = e.doit(**hints).subs(list(zip(v, p)))
        if hints.get('deep', True) and rv != self:
            rv = rv.doit(**hints)
        return rv

    def evalf(self, prec=None, **options):
        return self.doit().evalf(prec, **options)
    n = evalf

    @property
    def variables(self):
        return self._args[1]
    bound_symbols = variables

    @property
    def expr(self):
        return self._args[0]

    @property
    def point(self):
        return self._args[2]

    @property
    def free_symbols(self):
        return self.expr.free_symbols - set(self.variables) | set(self.point.free_symbols)

    @property
    def expr_free_symbols(self):
        sympy_deprecation_warning('\n        The expr_free_symbols property is deprecated. Use free_symbols to get\n        the free symbols of an expression.\n        ', deprecated_since_version='1.9', active_deprecations_target='deprecated-expr-free-symbols')
        with ignore_warnings(SymPyDeprecationWarning):
            return self.expr.expr_free_symbols - set(self.variables) | set(self.point.expr_free_symbols)

    def __eq__(self, other):
        if not isinstance(other, Subs):
            return False
        return self._hashable_content() == other._hashable_content()

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return super().__hash__()

    def _hashable_content(self):
        return (self._expr.xreplace(self.canonical_variables),) + tuple(ordered([(v, p) for v, p in zip(self.variables, self.point) if not self.expr.has(v)]))

    def _eval_subs(self, old, new):
        pt = list(self.point)
        if old in self.variables:
            if _atomic(new) == {new} and (not any((i.has(new) for i in self.args))):
                return self.xreplace({old: new})
            i = self.variables.index(old)
            for j in range(i, len(self.variables)):
                pt[j] = pt[j]._subs(old, new)
            return self.func(self.expr, self.variables, pt)
        v = [i._subs(old, new) for i in self.variables]
        if v != list(self.variables):
            return self.func(self.expr, self.variables + (old,), pt + [new])
        expr = self.expr._subs(old, new)
        pt = [i._subs(old, new) for i in self.point]
        return self.func(expr, v, pt)

    def _eval_derivative(self, s):
        f = self.expr
        vp = V, P = (self.variables, self.point)
        val = Add.fromiter((p.diff(s) * Subs(f.diff(v), *vp).doit() for v, p in zip(V, P)))
        efree = f.free_symbols
        compound = {i for i in efree if len(i.free_symbols) > 1}
        dums = {Dummy() for i in compound}
        masked = f.xreplace(dict(zip(compound, dums)))
        ifree = masked.free_symbols - dums
        free = ifree | compound
        free -= set(V)
        free |= {i for j in free & compound for i in j.free_symbols}
        if free & s.free_symbols:
            val += Subs(f.diff(s), self.variables, self.point).doit()
        return val

    def _eval_nseries(self, x, n, logx, cdir=0):
        if x in self.point:
            apos = self.point.index(x)
            other = self.variables[apos]
        else:
            other = x
        arg = self.expr.nseries(other, n=n, logx=logx)
        o = arg.getO()
        terms = Add.make_args(arg.removeO())
        rv = Add(*[self.func(a, *self.args[1:]) for a in terms])
        if o:
            rv += o.subs(other, x)
        return rv

    def _eval_as_leading_term(self, x, logx, cdir):
        if x in self.point:
            ipos = self.point.index(x)
            xvar = self.variables[ipos]
            return self.expr.as_leading_term(xvar)
        if x in self.variables:
            return self
        return self.expr.as_leading_term(x)

def diff(f, *symbols, **kwargs):
    if hasattr(f, 'diff'):
        return f.diff(*symbols, **kwargs)
    kwargs.setdefault('evaluate', True)
    return _derivative_dispatch(f, *symbols, **kwargs)

def expand(e, deep=True, modulus=None, power_base=True, power_exp=True, mul=True, log=True, multinomial=True, basic=True, **hints):
    hints['power_base'] = power_base
    hints['power_exp'] = power_exp
    hints['mul'] = mul
    hints['log'] = log
    hints['multinomial'] = multinomial
    hints['basic'] = basic
    return sympify(e).expand(deep=deep, modulus=modulus, **hints)

def _mexpand(expr, recursive=False):
    if expr is None:
        return
    was = None
    while was != expr:
        was, expr = (expr, expand_mul(expand_multinomial(expr)))
        if not recursive:
            break
    return expr

def expand_mul(expr, deep=True):
    return sympify(expr).expand(deep=deep, mul=True, power_exp=False, power_base=False, basic=False, multinomial=False, log=False)

def expand_multinomial(expr, deep=True):
    return sympify(expr).expand(deep=deep, mul=False, power_exp=False, power_base=False, basic=False, multinomial=True, log=False)

def expand_log(expr, deep=True, force=False, factor=False):
    from sympy.functions.elementary.exponential import log
    from sympy.simplify.radsimp import fraction
    if factor is False:

        def _handleMul(x):
            n, d = fraction(x)
            n = [i for i in n.atoms(log) if i.args[0].is_Integer]
            d = [i for i in d.atoms(log) if i.args[0].is_Integer]
            if len(n) == 1 and len(d) == 1:
                n = n[0]
                d = d[0]
                from sympy import multiplicity
                m = multiplicity(d.args[0], n.args[0])
                if m:
                    r = m + log(n.args[0] // d.args[0] ** m) / d
                    x = x.subs(n, d * r)
            x1 = expand_mul(expand_log(x, deep=deep, force=force, factor=True))
            if x1.count(log) <= x.count(log):
                return x1
            return x
        expr = expr.replace(lambda x: x.is_Mul and all((any((isinstance(i, log) and i.args[0].is_Rational for i in Mul.make_args(j))) for j in x.as_numer_denom())), _handleMul)
    return sympify(expr).expand(deep=deep, log=True, mul=False, power_exp=False, power_base=False, multinomial=False, basic=False, force=force, factor=factor)

def expand_func(expr, deep=True):
    return sympify(expr).expand(deep=deep, func=True, basic=False, log=False, mul=False, power_exp=False, power_base=False, multinomial=False)

def expand_trig(expr, deep=True):
    return sympify(expr).expand(deep=deep, trig=True, basic=False, log=False, mul=False, power_exp=False, power_base=False, multinomial=False)

def expand_complex(expr, deep=True):
    return sympify(expr).expand(deep=deep, complex=True, basic=False, log=False, mul=False, power_exp=False, power_base=False, multinomial=False)

def expand_power_base(expr, deep=True, force=False):
    return sympify(expr).expand(deep=deep, log=False, mul=False, power_exp=False, power_base=True, multinomial=False, basic=False, force=force)

def expand_power_exp(expr, deep=True):
    return sympify(expr).expand(deep=deep, complex=False, basic=False, log=False, mul=False, power_exp=True, power_base=False, multinomial=False)

def count_ops(expr, visual=False):
    from .relational import Relational
    from sympy.concrete.summations import Sum
    from sympy.integrals.integrals import Integral
    from sympy.logic.boolalg import BooleanFunction
    from sympy.simplify.radsimp import fraction
    expr = sympify(expr)
    if isinstance(expr, Expr) and (not expr.is_Relational):
        ops = []
        args = [expr]
        NEG = Symbol('NEG')
        DIV = Symbol('DIV')
        SUB = Symbol('SUB')
        ADD = Symbol('ADD')
        EXP = Symbol('EXP')
        while args:
            a = args.pop()
            if a.is_Rational:
                if a is not S.One:
                    if a.p < 0:
                        ops.append(NEG)
                    if a.q != 1:
                        ops.append(DIV)
                    continue
            elif a.is_Mul or a.is_MatMul:
                if _coeff_isneg(a):
                    ops.append(NEG)
                    if a.args[0] is S.NegativeOne:
                        a = a.as_two_terms()[1]
                    else:
                        a = -a
                n, d = fraction(a)
                if n.is_Integer:
                    ops.append(DIV)
                    if n < 0:
                        ops.append(NEG)
                    args.append(d)
                    continue
                elif d is not S.One:
                    if not d.is_Integer:
                        args.append(d)
                    ops.append(DIV)
                    args.append(n)
                    continue
            elif a.is_Add or a.is_MatAdd:
                aargs = list(a.args)
                negs = 0
                for i, ai in enumerate(aargs):
                    if _coeff_isneg(ai):
                        negs += 1
                        args.append(-ai)
                        if i > 0:
                            ops.append(SUB)
                    else:
                        args.append(ai)
                        if i > 0:
                            ops.append(ADD)
                if negs == len(aargs):
                    ops.append(NEG)
                elif _coeff_isneg(aargs[0]):
                    ops.append(SUB - ADD)
                continue
            if a.is_Pow and a.exp is S.NegativeOne:
                ops.append(DIV)
                args.append(a.base)
                continue
            if a == S.Exp1:
                ops.append(EXP)
                continue
            if a.is_Pow and a.base == S.Exp1:
                ops.append(EXP)
                args.append(a.exp)
                continue
            if a.is_Mul or isinstance(a, LatticeOp):
                o = Symbol(a.func.__name__.upper())
                ops.append(o * (len(a.args) - 1))
            elif a.args and (a.is_Pow or a.is_Function or isinstance(a, (Derivative, Integral, Sum))):
                if isinstance(a.func, UndefinedFunction):
                    o = Symbol('FUNC_' + a.func.__name__.upper())
                else:
                    o = Symbol(a.func.__name__.upper())
                ops.append(o)
            if not a.is_Symbol:
                args.extend(a.args)
    elif isinstance(expr, Dict):
        ops = [count_ops(k, visual=visual) + count_ops(v, visual=visual) for k, v in expr.items()]
    elif iterable(expr):
        ops = [count_ops(i, visual=visual) for i in expr]
    elif isinstance(expr, (Relational, BooleanFunction)):
        ops = []
        for arg in expr.args:
            ops.append(count_ops(arg, visual=True))
        o = Symbol(func_name(expr, short=True).upper())
        ops.append(o)
    elif not isinstance(expr, Basic):
        ops = []
    elif not isinstance(expr, Basic):
        raise TypeError('Invalid type of expr')
    else:
        ops = []
        args = [expr]
        while args:
            a = args.pop()
            if a.args:
                o = Symbol(type(a).__name__.upper())
                if a.is_Boolean:
                    ops.append(o * (len(a.args) - 1))
                else:
                    ops.append(o)
                args.extend(a.args)
    if not ops:
        if visual:
            return S.Zero
        return 0
    ops = Add(*ops)
    if visual:
        return ops
    if ops.is_Number:
        return int(ops)
    return sum((int((a.args or [1])[0]) for a in Add.make_args(ops)))

def nfloat(expr, n=15, exponent=False, dkeys=False):
    from sympy.matrices.matrixbase import MatrixBase
    kw = {'n': n, 'exponent': exponent, 'dkeys': dkeys}
    if isinstance(expr, MatrixBase):
        return expr.applyfunc(lambda e: nfloat(e, **kw))
    if iterable(expr, exclude=str):
        if isinstance(expr, (dict, Dict)):
            if dkeys:
                args = [tuple((nfloat(i, **kw) for i in a)) for a in expr.items()]
            else:
                args = [(k, nfloat(v, **kw)) for k, v in expr.items()]
            if isinstance(expr, dict):
                return type(expr)(args)
            else:
                return expr.func(*args)
        elif isinstance(expr, Basic):
            return expr.func(*[nfloat(a, **kw) for a in expr.args])
        return type(expr)([nfloat(a, **kw) for a in expr])
    rv = sympify(expr)
    if rv.is_Number:
        return Float(rv, n)
    elif rv.is_number:
        rv = rv.n(n)
        if rv.is_Number:
            rv = Float(rv.n(n), n)
        else:
            pass
        return rv
    elif rv.is_Atom:
        return rv
    elif rv.is_Relational:
        args_nfloat = (nfloat(arg, **kw) for arg in rv.args)
        return rv.func(*args_nfloat)
    from sympy.polys.rootoftools import RootOf
    rv = rv.xreplace({ro: ro.n(n) for ro in rv.atoms(RootOf)})
    from .power import Pow
    if not exponent:
        reps = [(p, Pow(p.base, Dummy())) for p in rv.atoms(Pow)]
        rv = rv.xreplace(dict(reps))
    rv = rv.n(n)
    if not exponent:
        rv = rv.xreplace({d.exp: p.exp for p, d in reps})
    else:
        rv = rv.xreplace(Transform(lambda x: Pow(x.base, Float(x.exp, n)), lambda x: x.is_Pow and x.exp.is_Integer))
    return rv.xreplace(Transform(lambda x: x.func(*nfloat(x.args, n, exponent)), lambda x: isinstance(x, Function) and (not isinstance(x, AppliedUndef))))
from .symbol import Dummy, Symbol