from __future__ import annotations
from typing import TYPE_CHECKING
from .basic import Atom, Basic
from .coreerrors import LazyExceptionMessage
from .sorting import ordered
from .evalf import EvalfMixin
from .function import AppliedUndef
from .numbers import int_valued
from .singleton import S
from .sympify import _sympify, SympifyError
from .parameters import global_parameters
from .logic import fuzzy_bool, fuzzy_xor, fuzzy_and, fuzzy_not
from sympy.logic.boolalg import Boolean, BooleanAtom
from sympy.utilities.iterables import sift
from sympy.utilities.misc import filldedent
from sympy.utilities.exceptions import sympy_deprecation_warning
if TYPE_CHECKING:
    from typing import ClassVar
    from typing_extensions import Self
    from sympy.logic.boolalg import BooleanTrue, BooleanFalse
    from sympy.sets.sets import Set
__all__ = ('Rel', 'Eq', 'Ne', 'Lt', 'Le', 'Gt', 'Ge', 'Relational', 'Equality', 'Unequality', 'StrictLessThan', 'LessThan', 'StrictGreaterThan', 'GreaterThan')
from .expr import Expr
from sympy.multipledispatch import dispatch
from .containers import Tuple
from .symbol import Symbol

def _nontrivBool(side):
    return isinstance(side, Boolean) and (not isinstance(side, Atom))

def _canonical(cond):
    reps = {r: r.canonical for r in cond.atoms(Relational)}
    return cond.xreplace(reps)

def _canonical_coeff(rel):
    rel = rel.canonical
    if not rel.is_Relational or rel.rhs.is_Boolean:
        return rel
    if not isinstance(rel.lhs, Expr):
        return rel.reversed
    b, l = rel.lhs.as_coeff_Add(rational=True)
    m, lhs = l.as_coeff_Mul(rational=True)
    rhs = (rel.rhs - b) / m
    if m < 0:
        return rel.reversed.func(lhs, rhs)
    return rel.func(lhs, rhs)

class Relational(Boolean, EvalfMixin):
    __slots__ = ()
    ValidRelationOperator: dict[str | None, type[Relational]] = {}
    rel_op: ClassVar[str]
    is_Relational = True

    def __new__(cls, lhs, rhs, rop=None, **assumptions) -> Self:
        if cls is not Relational:
            return Basic.__new__(cls, lhs, rhs, **assumptions)
        cls = cls.ValidRelationOperator.get(rop, None)
        if cls is None:
            raise ValueError('Invalid relational operator symbol: %r' % rop)
        if not issubclass(cls, (Eq, Ne)):
            if any(map(_nontrivBool, (lhs, rhs))):
                raise TypeError(filldedent('\n                    A Boolean argument can only be used in\n                    Eq and Ne; all other relationals expect\n                    real expressions.\n                '))
        return cls(lhs, rhs, **assumptions)

    @property
    def lhs(self) -> Basic:
        return self._args[0]

    @property
    def rhs(self) -> Basic:
        return self._args[1]

    @property
    def reversed(self):
        ops = {Eq: Eq, Gt: Lt, Ge: Le, Lt: Gt, Le: Ge, Ne: Ne}
        a, b = self.args
        return Relational.__new__(ops.get(self.func, self.func), b, a)

    @property
    def reversedsign(self):
        a, b = self.args
        if not (isinstance(a, BooleanAtom) or isinstance(b, BooleanAtom)):
            ops = {Eq: Eq, Gt: Lt, Ge: Le, Lt: Gt, Le: Ge, Ne: Ne}
            return Relational.__new__(ops.get(self.func, self.func), -a, -b)
        else:
            return self

    @property
    def negated(self):
        ops = {Eq: Ne, Ge: Lt, Gt: Le, Le: Gt, Lt: Ge, Ne: Eq}
        return Relational.__new__(ops.get(self.func), *self.args)

    @property
    def weak(self):
        return self

    @property
    def strict(self):
        return self

    def _eval_evalf(self, prec):
        return self.func(*[s._evalf(prec) for s in self.args])

    @property
    def canonical(self):
        args = tuple([i.canonical if isinstance(i, Relational) else i for i in self.args])
        if args != self.args:
            r = self.func(*args)
            if not isinstance(r, Relational):
                return r
        else:
            r = self
        if r.rhs.is_number:
            if r.rhs.is_Number and r.lhs.is_Number and (r.lhs > r.rhs):
                r = r.reversed
        elif r.lhs.is_number or tuple(ordered(args)) != args:
            r = r.reversed
        LHS_CEMS = getattr(r.lhs, 'could_extract_minus_sign', None)
        RHS_CEMS = getattr(r.rhs, 'could_extract_minus_sign', None)
        if isinstance(r.lhs, BooleanAtom) or isinstance(r.rhs, BooleanAtom):
            return r
        if LHS_CEMS and LHS_CEMS():
            return r.reversedsign
        elif not r.rhs.is_number and RHS_CEMS and RHS_CEMS():
            expr1, _ = ordered([r.lhs, -r.rhs])
            if expr1 != r.lhs:
                return r.reversed.reversedsign
        return r

    def equals(self, other, failing_expression=False):
        if isinstance(other, Relational):
            if other in (self, self.reversed):
                return True
            a, b = (self, other)
            if a.func in (Eq, Ne) or b.func in (Eq, Ne):
                if a.func != b.func:
                    return False
                left, right = [i.equals(j, failing_expression=failing_expression) for i, j in zip(a.args, b.args)]
                if left is True:
                    return right
                if right is True:
                    return left
                lr, rl = [i.equals(j, failing_expression=failing_expression) for i, j in zip(a.args, b.reversed.args)]
                if lr is True:
                    return rl
                if rl is True:
                    return lr
                e = (left, right, lr, rl)
                if all((i is False for i in e)):
                    return False
                for i in e:
                    if i not in (True, False):
                        return i
            else:
                if b.func != a.func:
                    b = b.reversed
                if a.func != b.func:
                    return False
                left = a.lhs.equals(b.lhs, failing_expression=failing_expression)
                if left is False:
                    return False
                right = a.rhs.equals(b.rhs, failing_expression=failing_expression)
                if right is False:
                    return False
                if left is True:
                    return right
                return left

    def _eval_simplify(self, **kwargs):
        from .add import Add
        from .expr import Expr
        r = self
        r = r.func(*[i.simplify(**kwargs) for i in r.args])
        if r.is_Relational:
            if not isinstance(r.lhs, Expr) or not isinstance(r.rhs, Expr):
                return r
            dif = r.lhs - r.rhs
            v = None
            if dif.is_comparable:
                v = dif.n(2)
                if any((i._prec == 1 for i in v.as_real_imag())):
                    rv, iv = [i.n(2) for i in dif.as_real_imag()]
                    v = rv + S.ImaginaryUnit * iv
            elif dif.equals(0):
                v = S.Zero
            if v is not None:
                r = r.func._eval_relation(v, S.Zero)
            r = r.canonical
            free = list(filter(lambda x: x.is_real is not False, r.free_symbols))
            if len(free) == 1:
                try:
                    from sympy.solvers.solveset import linear_coeffs
                    x = free.pop()
                    dif = r.lhs - r.rhs
                    m, b = linear_coeffs(dif, x)
                    if m.is_zero is False:
                        if m.is_negative:
                            r = r.func(-b / m, x)
                        else:
                            r = r.func(x, -b / m)
                    else:
                        r = r.func(b, S.Zero)
                except ValueError:
                    from sympy.polys.polyerrors import PolynomialError
                    from sympy.polys.polytools import gcd, Poly, poly
                    try:
                        p = poly(dif, x)
                        c = p.all_coeffs()
                        constant = c[-1]
                        c[-1] = 0
                        scale = gcd(c)
                        c = [ctmp / scale for ctmp in c]
                        r = r.func(Poly.from_list(c, x).as_expr(), -constant / scale)
                    except PolynomialError:
                        pass
            elif len(free) >= 2:
                try:
                    from sympy.solvers.solveset import linear_coeffs
                    from sympy.polys.polytools import gcd
                    free = list(ordered(free))
                    dif = r.lhs - r.rhs
                    m = linear_coeffs(dif, *free)
                    constant = m[-1]
                    del m[-1]
                    scale = gcd(m)
                    m = [mtmp / scale for mtmp in m]
                    nzm = list(filter(lambda f: f[0] != 0, list(zip(m, free))))
                    if scale.is_zero is False:
                        if constant != 0:
                            newexpr = Add(*[i * j for i, j in nzm])
                            r = r.func(newexpr, -constant / scale)
                        else:
                            lhsterm = nzm[0][0] * nzm[0][1]
                            del nzm[0]
                            newexpr = Add(*[i * j for i, j in nzm])
                            r = r.func(lhsterm, -newexpr)
                    else:
                        r = r.func(constant, S.Zero)
                except ValueError:
                    pass
        r = r.canonical
        measure = kwargs['measure']
        if measure(r) < kwargs['ratio'] * measure(self):
            return r
        else:
            return self

    def _eval_trigsimp(self, **opts):
        from sympy.simplify.trigsimp import trigsimp
        return self.func(trigsimp(self.lhs, **opts), trigsimp(self.rhs, **opts))

    def expand(self, **kwargs):
        args = (arg.expand(**kwargs) for arg in self.args)
        return self.func(*args)

    def __bool__(self) -> bool:
        raise TypeError(LazyExceptionMessage(lambda: f'cannot determine truth value of Relational: {self}'))

    def _eval_as_set(self) -> Set:
        from sympy.solvers.inequalities import solve_univariate_inequality
        from sympy.sets.conditionset import ConditionSet
        syms = self.free_symbols
        assert len(syms) == 1
        x = syms.pop()
        try:
            xset = solve_univariate_inequality(self, x, relational=False)
        except NotImplementedError:
            xset = ConditionSet(x, self, S.Reals)
        return xset

    @property
    def binary_symbols(self):
        return set()
Rel = Relational

class Equality(Relational):
    rel_op = '=='
    __slots__ = ()
    is_Equality = True

    def __new__(cls, lhs, rhs, **options) -> Equality | BooleanFalse | BooleanTrue:
        evaluate = options.pop('evaluate', global_parameters.evaluate)
        lhs = _sympify(lhs)
        rhs = _sympify(rhs)
        if evaluate:
            val = is_eq(lhs, rhs)
            if val is None:
                return cls(lhs, rhs, evaluate=False)
            else:
                return _sympify(val)
        return Relational.__new__(cls, lhs, rhs)

    @classmethod
    def _eval_relation(cls, lhs, rhs):
        return _sympify(lhs == rhs)

    def _eval_rewrite_as_Add(self, L, R, evaluate=True, **kwargs):
        sympy_deprecation_warning('\n        Eq.rewrite(Add) is deprecated.\n\n        For ``eq = Eq(a, b)`` use ``eq.lhs - eq.rhs`` to obtain\n        ``a - b``.\n        ', deprecated_since_version='1.13', active_deprecations_target='eq-rewrite-Add', stacklevel=5)
        from .add import _unevaluated_Add, Add
        if L == 0:
            return R
        if R == 0:
            return L
        if evaluate:
            return L - R
        args = Add.make_args(L) + Add.make_args(-R)
        if evaluate is None:
            return _unevaluated_Add(*args)
        return Add._from_args(args)

    @property
    def binary_symbols(self):
        if S.true in self.args or S.false in self.args:
            if self.lhs.is_Symbol:
                return {self.lhs}
            elif self.rhs.is_Symbol:
                return {self.rhs}
        return set()

    def _eval_simplify(self, **kwargs):
        e = super()._eval_simplify(**kwargs)
        if not isinstance(e, Equality):
            return e
        from .expr import Expr
        if not isinstance(e.lhs, Expr) or not isinstance(e.rhs, Expr):
            return e
        free = self.free_symbols
        if len(free) == 1:
            try:
                from .add import Add
                from sympy.solvers.solveset import linear_coeffs
                x = free.pop()
                m, b = linear_coeffs(Add(e.lhs, -e.rhs, evaluate=False), x)
                if m.is_zero is False:
                    enew = e.func(x, -b / m)
                else:
                    enew = e.func(m * x, -b)
                measure = kwargs['measure']
                if measure(enew) <= kwargs['ratio'] * measure(e):
                    e = enew
            except ValueError:
                pass
        return e.canonical

    def integrate(self, *args, **kwargs):
        from sympy.integrals.integrals import integrate
        return integrate(self, *args, **kwargs)

    def as_poly(self, *gens, **kwargs):
        return (self.lhs - self.rhs).as_poly(*gens, **kwargs)
Eq = Equality

class Unequality(Relational):
    rel_op = '!='
    __slots__ = ()

    def __new__(cls, lhs, rhs, **options) -> Unequality | BooleanFalse | BooleanTrue:
        lhs = _sympify(lhs)
        rhs = _sympify(rhs)
        evaluate = options.pop('evaluate', global_parameters.evaluate)
        if evaluate:
            val = is_neq(lhs, rhs)
            if val is None:
                return cls(lhs, rhs, evaluate=False)
            else:
                return _sympify(val)
        return Relational.__new__(cls, lhs, rhs, **options)

    @classmethod
    def _eval_relation(cls, lhs, rhs):
        return _sympify(lhs != rhs)

    @property
    def binary_symbols(self):
        if S.true in self.args or S.false in self.args:
            if self.lhs.is_Symbol:
                return {self.lhs}
            elif self.rhs.is_Symbol:
                return {self.rhs}
        return set()

    def _eval_simplify(self, **kwargs):
        eq = Equality(*self.args)._eval_simplify(**kwargs)
        if isinstance(eq, Equality):
            return self.func(*eq.args)
        return eq.negated
Ne = Unequality

class _Inequality(Relational):
    __slots__ = ()
    if TYPE_CHECKING:

        @property
        def args(self) -> tuple[Expr, Expr]:
            pass

        @property
        def lhs(self) -> Expr:
            pass

        @property
        def rhs(self) -> Expr:
            pass

    def __new__(cls, lhs: Expr | complex, rhs: Expr | complex, **options) -> Self | BooleanTrue | BooleanFalse:
        try:
            lhs_e = _sympify(lhs)
            rhs_e = _sympify(rhs)
        except SympifyError:
            return NotImplemented
        evaluate = options.pop('evaluate', global_parameters.evaluate)
        if evaluate:
            for me in (lhs_e, rhs_e):
                if me.is_extended_real is False:
                    raise TypeError('Invalid comparison of non-real %s' % me)
                if me is S.NaN:
                    raise TypeError('Invalid NaN comparison')
            return cls._eval_relation(lhs_e, rhs_e, **options)
        return Relational.__new__(cls, lhs_e, rhs_e, **options)

    @classmethod
    def _eval_relation(cls, lhs, rhs, **options):
        val = cls._eval_fuzzy_relation(lhs, rhs)
        if val is None:
            return cls(lhs, rhs, evaluate=False)
        else:
            return _sympify(val)

class _Greater(_Inequality):
    __slots__ = ()

    @property
    def gts(self):
        return self._args[0]

    @property
    def lts(self):
        return self._args[1]

class _Less(_Inequality):
    __slots__ = ()

    @property
    def gts(self):
        return self._args[1]

    @property
    def lts(self):
        return self._args[0]

class GreaterThan(_Greater):
    __slots__ = ()
    rel_op = '>='

    @classmethod
    def _eval_fuzzy_relation(cls, lhs, rhs):
        return is_ge(lhs, rhs)

    @property
    def strict(self):
        return Gt(*self.args)
Ge = GreaterThan

class LessThan(_Less):
    __doc__ = GreaterThan.__doc__
    __slots__ = ()
    rel_op = '<='

    @classmethod
    def _eval_fuzzy_relation(cls, lhs, rhs):
        return is_le(lhs, rhs)

    @property
    def strict(self):
        return Lt(*self.args)
Le = LessThan

class StrictGreaterThan(_Greater):
    __doc__ = GreaterThan.__doc__
    __slots__ = ()
    rel_op = '>'

    @classmethod
    def _eval_fuzzy_relation(cls, lhs, rhs):
        return is_gt(lhs, rhs)

    @property
    def weak(self):
        return Ge(*self.args)
Gt = StrictGreaterThan

class StrictLessThan(_Less):
    __doc__ = GreaterThan.__doc__
    __slots__ = ()
    rel_op = '<'

    @classmethod
    def _eval_fuzzy_relation(cls, lhs, rhs):
        return is_lt(lhs, rhs)

    @property
    def weak(self):
        return Le(*self.args)
Lt = StrictLessThan
Relational.ValidRelationOperator = {None: Equality, '==': Equality, 'eq': Equality, '!=': Unequality, '<>': Unequality, 'ne': Unequality, '>=': GreaterThan, 'ge': GreaterThan, '<=': LessThan, 'le': LessThan, '>': StrictGreaterThan, 'gt': StrictGreaterThan, '<': StrictLessThan, 'lt': StrictLessThan}

def _n2(a, b):
    if a.is_comparable and b.is_comparable:
        dif = (a - b).evalf(2)
        if dif.is_comparable:
            return dif

@dispatch(Expr, Expr)
def _eval_is_ge(lhs, rhs):
    return None

@dispatch(Basic, Basic)
def _eval_is_eq(lhs, rhs):
    return None

@dispatch(Tuple, Expr)
def _eval_is_eq(lhs, rhs):
    return False

@dispatch(Tuple, AppliedUndef)
def _eval_is_eq(lhs, rhs):
    return None

@dispatch(Tuple, Symbol)
def _eval_is_eq(lhs, rhs):
    return None

@dispatch(Tuple, Tuple)
def _eval_is_eq(lhs, rhs):
    if len(lhs) != len(rhs):
        return False
    return fuzzy_and((fuzzy_bool(is_eq(s, o)) for s, o in zip(lhs, rhs)))

def is_lt(lhs, rhs, assumptions=None):
    return fuzzy_not(is_ge(lhs, rhs, assumptions))

def is_gt(lhs, rhs, assumptions=None):
    return fuzzy_not(is_le(lhs, rhs, assumptions))

def is_le(lhs, rhs, assumptions=None):
    return is_ge(rhs, lhs, assumptions)

def is_ge(lhs, rhs, assumptions=None):
    from sympy.assumptions.wrapper import AssumptionsWrapper, is_extended_nonnegative
    if not (isinstance(lhs, Expr) and isinstance(rhs, Expr)):
        raise TypeError('Can only compare inequalities with Expr')
    retval = _eval_is_ge(lhs, rhs)
    if retval is not None:
        return retval
    else:
        n2 = _n2(lhs, rhs)
        if n2 is not None:
            if n2 in (S.Infinity, S.NegativeInfinity):
                n2 = float(n2)
            return n2 >= 0
        _lhs = AssumptionsWrapper(lhs, assumptions)
        _rhs = AssumptionsWrapper(rhs, assumptions)
        if _lhs.is_extended_real and _rhs.is_extended_real:
            if _lhs.is_infinite and _lhs.is_extended_positive or (_rhs.is_infinite and _rhs.is_extended_negative):
                return True
            diff = lhs - rhs
            if diff is not S.NaN:
                rv = is_extended_nonnegative(diff, assumptions)
                if rv is not None:
                    return rv

def is_neq(lhs, rhs, assumptions=None):
    return fuzzy_not(is_eq(lhs, rhs, assumptions))

def is_eq(lhs: Basic, rhs: Basic, assumptions=None) -> bool | None:
    for side1, side2 in ((lhs, rhs), (rhs, lhs)):
        eval_func = getattr(side1, '_eval_Eq', None)
        if eval_func is not None:
            retval = eval_func(side2)
            if retval is not None:
                return retval
    retval = _eval_is_eq(lhs, rhs)
    if retval is not None:
        return retval
    if dispatch(type(lhs), type(rhs)) != dispatch(type(rhs), type(lhs)):
        retval = _eval_is_eq(rhs, lhs)
        if retval is not None:
            return retval
    if lhs == rhs:
        return True
    elif all((isinstance(i, BooleanAtom) for i in (rhs, lhs))):
        return False
    elif not (lhs.is_Symbol or rhs.is_Symbol) and isinstance(lhs, Boolean) != isinstance(rhs, Boolean):
        return False
    from sympy.assumptions.wrapper import AssumptionsWrapper, is_infinite, is_extended_real
    from .add import Add
    _lhs = AssumptionsWrapper(lhs, assumptions)
    _rhs = AssumptionsWrapper(rhs, assumptions)
    if _lhs.is_infinite or _rhs.is_infinite:
        if fuzzy_xor([_lhs.is_infinite, _rhs.is_infinite]):
            return False
        if fuzzy_xor([_lhs.is_extended_real, _rhs.is_extended_real]):
            return False
        if fuzzy_and([_lhs.is_extended_real, _rhs.is_extended_real]):
            return fuzzy_xor([_lhs.is_extended_positive, fuzzy_not(_rhs.is_extended_positive)])
        I = S.ImaginaryUnit

        def split_real_imag(expr):
            real_imag = lambda t: 'real' if is_extended_real(t, assumptions) else 'imag' if is_extended_real(I * t, assumptions) else None
            return sift(Add.make_args(expr), real_imag)
        lhs_ri = split_real_imag(lhs)
        if not lhs_ri[None]:
            rhs_ri = split_real_imag(rhs)
            if not rhs_ri[None]:
                eq_real = is_eq(Add(*lhs_ri['real']), Add(*rhs_ri['real']), assumptions)
                eq_imag = is_eq(I * Add(*lhs_ri['imag']), I * Add(*rhs_ri['imag']), assumptions)
                return fuzzy_and(map(fuzzy_bool, [eq_real, eq_imag]))
        from sympy.functions.elementary.complexes import arg
        arglhs = arg(lhs)
        argrhs = arg(rhs)
        if not (arglhs == S.NaN and argrhs == S.NaN):
            return fuzzy_bool(is_eq(arglhs, argrhs, assumptions))
    if isinstance(lhs, Expr) and isinstance(rhs, Expr):
        dif = lhs - rhs
        _dif = AssumptionsWrapper(dif, assumptions)
        z = _dif.is_zero
        if z is not None:
            if z is False and _dif.is_commutative:
                return False
            if z:
                return True
        c, t = dif.as_coeff_Add()
        if c.is_Float:
            if int_valued(c):
                if t.is_integer is False:
                    return False
            elif t.is_rational is False:
                return False
        n2 = _n2(lhs, rhs)
        if n2 is not None:
            return _sympify(n2 == 0)
        n, d = dif.as_numer_denom()
        rv = None
        _n = AssumptionsWrapper(n, assumptions)
        _d = AssumptionsWrapper(d, assumptions)
        if _n.is_zero:
            rv = _d.is_nonzero
        elif _n.is_finite:
            if _d.is_infinite:
                rv = True
            elif _n.is_zero is False:
                rv = _d.is_infinite
                if rv is None:
                    from sympy.simplify.simplify import clear_coefficients
                    l, r = clear_coefficients(d, S.Infinity)
                    lhs2 = lhs.subs(l, r)
                    rhs2 = rhs.subs(l, r)
                    if lhs2 != lhs or rhs2 != rhs:
                        rv = fuzzy_bool(is_eq(lhs2, rhs2, assumptions))
                        if rv is True:
                            rv = None
        elif any((is_infinite(a, assumptions) for a in Add.make_args(n))):
            rv = False
        if rv is not None:
            return rv
    return None