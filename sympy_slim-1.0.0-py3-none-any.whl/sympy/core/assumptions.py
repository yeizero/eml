from __future__ import annotations
from sympy.utilities.exceptions import sympy_deprecation_warning
from .facts import FactRules, FactKB
from .sympify import sympify
from sympy.core.random import _assumptions_shuffle as shuffle
from sympy.core.assumptions_generated import generated_assumptions as _assumptions

def _load_pre_generated_assumption_rules() -> FactRules:
    _assume_rules = FactRules._from_python(_assumptions)
    return _assume_rules

def _generate_assumption_rules():
    _assume_rules = FactRules(['integer        ->  rational', 'rational       ->  real', 'rational       ->  algebraic', 'algebraic      ->  complex', 'transcendental ==  complex & !algebraic', 'imaginary      ->  complex', 'extended_real  ->  commutative', 'complex        ->  commutative', 'complex        ->  finite', 'odd            ==  integer & !even', 'even           ==  integer & !odd', 'real           ->  complex', 'extended_real  ->  real | infinite', 'real           ==  extended_real & finite', 'extended_real        ==  extended_negative | zero | extended_positive', 'extended_negative    ==  extended_nonpositive & extended_nonzero', 'extended_positive    ==  extended_nonnegative & extended_nonzero', 'extended_nonpositive ==  extended_real & !extended_positive', 'extended_nonnegative ==  extended_real & !extended_negative', 'real           ==  negative | zero | positive', 'negative       ==  nonpositive & nonzero', 'positive       ==  nonnegative & nonzero', 'nonpositive    ==  real & !positive', 'nonnegative    ==  real & !negative', 'positive       ==  extended_positive & finite', 'negative       ==  extended_negative & finite', 'nonpositive    ==  extended_nonpositive & finite', 'nonnegative    ==  extended_nonnegative & finite', 'nonzero        ==  extended_nonzero & finite', 'zero           ->  even & finite', 'zero           ==  extended_nonnegative & extended_nonpositive', 'zero           ==  nonnegative & nonpositive', 'nonzero        ->  real', 'prime          ->  integer & positive', 'composite      ->  integer & positive & !prime', '!composite     ->  !positive | !even | prime', 'irrational     ==  real & !rational', 'imaginary      ->  !extended_real', 'infinite       ==  !finite', 'noninteger     ==  extended_real & !integer', 'extended_nonzero == extended_real & !zero'])
    return _assume_rules
_assume_rules = _load_pre_generated_assumption_rules()
_assume_defined = _assume_rules.defined_facts.copy()
_assume_defined.add('polar')
_assume_defined = frozenset(_assume_defined)
all_assumptions = _assume_defined

def assumptions(expr, _check=None):
    n = sympify(expr)
    if n.is_Symbol:
        rv = n.assumptions0
        if _check is not None:
            rv = {k: rv[k] for k in set(rv) & set(_check)}
        return rv
    rv = {}
    for k in _assume_defined if _check is None else _check:
        v = getattr(n, 'is_{}'.format(k))
        if v is not None:
            rv[k] = v
    return rv

def common_assumptions(exprs, check=None):
    check = _assume_defined if check is None else set(check)
    if not check or not exprs:
        return {}
    assume = [assumptions(i, _check=check) for i in sympify(exprs)]
    for i, e in enumerate(assume):
        assume[i] = {k: e[k] for k in set(e) & check}
    common = set.intersection(*[set(i) for i in assume])
    a = assume[0]
    return {k: a[k] for k in common if all((a[k] == b[k] for b in assume))}

def failing_assumptions(expr, **assumptions):
    expr = sympify(expr)
    failed = {}
    for k in assumptions:
        test = getattr(expr, 'is_%s' % k, None)
        if test is not assumptions[k]:
            failed[k] = test
    return failed

def check_assumptions(expr, against=None, **assume):
    expr = sympify(expr)
    if against is not None:
        if assume:
            raise ValueError('Expecting `against` or `assume`, not both.')
        assume = assumptions(against)
    known = True
    for k, v in assume.items():
        if v is None:
            continue
        e = getattr(expr, 'is_' + k, None)
        if e is None:
            known = None
        elif v != e:
            return False
    return known

class StdFactKB(FactKB):

    def __init__(self, facts=None):
        super().__init__(_assume_rules)
        if not facts:
            self._generator = {}
        elif not isinstance(facts, FactKB):
            self._generator = facts.copy()
        else:
            self._generator = facts.generator
        if facts:
            self.deduce_all_facts(facts)

    def copy(self):
        return self.__class__(self)

    @property
    def generator(self):
        return self._generator.copy()

def as_property(fact):
    return 'is_%s' % fact

def make_property(fact):

    def getit(self):
        try:
            return self._assumptions[fact]
        except KeyError:
            if self._assumptions is self.default_assumptions:
                self._assumptions = self.default_assumptions.copy()
            return _ask(fact, self)
    getit.func_name = as_property(fact)
    return property(getit)

def _ask(fact, obj):
    assumptions = obj._assumptions
    handler_map = obj._prop_handler
    facts_to_check = [fact]
    facts_queued = {fact}
    for fact_i in facts_to_check:
        if fact_i in assumptions:
            continue
        fact_i_value = None
        handler_i = handler_map.get(fact_i)
        if handler_i is not None:
            fact_i_value = handler_i(obj)
        if fact_i_value is not None:
            assumptions.deduce_all_facts(((fact_i, fact_i_value),))
        fact_value = assumptions.get(fact)
        if fact_value is not None:
            return fact_value
        new_facts_to_check = list(_assume_rules.prereq[fact_i] - facts_queued)
        shuffle(new_facts_to_check)
        facts_to_check.extend(new_facts_to_check)
        facts_queued.update(new_facts_to_check)
    if fact in assumptions:
        return assumptions[fact]
    assumptions._tell(fact, None)
    return None

def _prepare_class_assumptions(cls):
    local_defs = {}
    for k in _assume_defined:
        attrname = as_property(k)
        v = cls.__dict__.get(attrname, '')
        if isinstance(v, (bool, int, type(None))):
            if v is not None:
                v = bool(v)
            local_defs[k] = v
    defs = {}
    for base in reversed(cls.__bases__):
        assumptions = getattr(base, '_explicit_class_assumptions', None)
        if assumptions is not None:
            defs.update(assumptions)
    defs.update(local_defs)
    cls._explicit_class_assumptions = defs
    cls.default_assumptions = StdFactKB(defs)
    cls._prop_handler = {}
    for k in _assume_defined:
        eval_is_meth = getattr(cls, '_eval_is_%s' % k, None)
        if eval_is_meth is not None:
            cls._prop_handler[k] = eval_is_meth
    for k, v in cls.default_assumptions.items():
        setattr(cls, as_property(k), v)
    derived_from_bases = set()
    for base in cls.__bases__:
        default_assumptions = getattr(base, 'default_assumptions', None)
        if default_assumptions is not None:
            derived_from_bases.update(default_assumptions)
    for fact in derived_from_bases - set(cls.default_assumptions):
        pname = as_property(fact)
        if pname not in cls.__dict__:
            setattr(cls, pname, make_property(fact))
    for fact in _assume_defined:
        pname = as_property(fact)
        if not hasattr(cls, pname):
            setattr(cls, pname, make_property(fact))

class ManagedProperties(type):

    def __init__(cls, *args, **kwargs):
        msg = 'The ManagedProperties metaclass. Basic does not use metaclasses any more'
        sympy_deprecation_warning(msg, deprecated_since_version='1.12', active_deprecations_target='managedproperties')
        _prepare_class_assumptions(cls)