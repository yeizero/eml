from __future__ import annotations

class Printable:
    __slots__ = ()

    def __str__(self):
        from sympy.printing.str import sstr
        return sstr(self, order=None)
    __repr__ = __str__

    def _repr_disabled(self):
        return None
    _repr_png_ = _repr_disabled
    _repr_svg_ = _repr_disabled

    def _repr_latex_(self):
        from sympy.printing.latex import latex
        s = latex(self, mode='plain')
        return '$\\displaystyle %s$' % s