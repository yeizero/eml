from __future__ import annotations
from collections import Counter
from collections.abc import Mapping, Iterable
from itertools import zip_longest
from functools import cmp_to_key
from typing import TYPE_CHECKING, overload
from .assumptions import _prepare_class_assumptions
from .cache import cacheit
from .sympify import _sympify, sympify, SympifyError, _external_converter
from .sorting import ordered
from .kind import Kind, UndefinedKind
from ._print_helpers import Printable
from sympy.utilities.decorator import deprecated
from sympy.utilities.exceptions import sympy_deprecation_warning
from sympy.utilities.iterables import iterable, numbered_symbols
from sympy.utilities.misc import filldedent, func_name
if TYPE_CHECKING:
    from typing import ClassVar, Any, Hashable, TypeVar, Protocol
    from typing_extensions import Self
    from .assumptions import StdFactKB
    from .symbol import Symbol
    Tbasic = TypeVar('Tbasic', bound='Basic')
    _K_co = TypeVar('_K_co', covariant=True)
    _V_co = TypeVar('_V_co', covariant=True)

    class _SupportsItems(Protocol[_K_co, _V_co]):

        def items(self) -> Iterable[tuple[_K_co, _V_co]]:
            pass

def as_Basic(expr):
    try:
        return _sympify(expr)
    except SympifyError:
        raise TypeError('Argument must be a Basic object, not `%s`' % func_name(expr))
ordering_of_classes = ['Zero', 'One', 'Half', 'Infinity', 'NaN', 'NegativeOne', 'NegativeInfinity', 'Integer', 'Rational', 'Float', 'Exp1', 'Pi', 'ImaginaryUnit', 'Symbol', 'Wild', 'Pow', 'Mul', 'Add', 'Derivative', 'Integral', 'Abs', 'Sign', 'Sqrt', 'Floor', 'Ceiling', 'Re', 'Im', 'Arg', 'Conjugate', 'Exp', 'Log', 'Sin', 'Cos', 'Tan', 'Cot', 'ASin', 'ACos', 'ATan', 'ACot', 'Sinh', 'Cosh', 'Tanh', 'Coth', 'ASinh', 'ACosh', 'ATanh', 'ACoth', 'RisingFactorial', 'FallingFactorial', 'factorial', 'binomial', 'Gamma', 'LowerGamma', 'UpperGamma', 'PolyGamma', 'Erf', 'Chebyshev', 'Chebyshev2', 'Function', 'WildFunction', 'Lambda', 'Order', 'Equality', 'Unequality', 'StrictGreaterThan', 'StrictLessThan', 'GreaterThan', 'LessThan']

def _cmp_name(x: type, y: type) -> int:
    n1 = x.__name__
    n2 = y.__name__
    if n1 == n2:
        return 0
    if not issubclass(y, Basic):
        return -1
    UNKNOWN = len(ordering_of_classes) + 1
    try:
        i1 = ordering_of_classes.index(n1)
    except ValueError:
        i1 = UNKNOWN
    try:
        i2 = ordering_of_classes.index(n2)
    except ValueError:
        i2 = UNKNOWN
    if i1 == UNKNOWN and i2 == UNKNOWN:
        return (n1 > n2) - (n1 < n2)
    return (i1 > i2) - (i1 < i2)

@cacheit
def _get_postprocessors(clsname, arg_type):
    postprocessors = set()
    mappings = _get_postprocessors_for_type(arg_type)
    for mapping in mappings:
        f = mapping.get(clsname, None)
        if f is not None:
            postprocessors.update(f)
    return postprocessors

@cacheit
def _get_postprocessors_for_type(arg_type):
    return tuple((Basic._constructor_postprocessor_mapping[cls] for cls in arg_type.mro() if cls in Basic._constructor_postprocessor_mapping))

class Basic(Printable):
    __slots__ = ('_mhash', '_args', '_assumptions')
    _args: tuple[Basic, ...]
    _mhash: int | None

    @property
    def __sympy__(self):
        return True

    def __init_subclass__(cls):
        super().__init_subclass__()
        _prepare_class_assumptions(cls)
    is_number = False
    is_Atom = False
    is_Symbol = False
    is_symbol = False
    is_Indexed = False
    is_Dummy = False
    is_Wild = False
    is_Function = False
    is_Add = False
    is_Mul = False
    is_Pow = False
    is_Number = False
    is_Float = False
    is_Rational = False
    is_Integer = False
    is_NumberSymbol = False
    is_Order = False
    is_Derivative = False
    is_Piecewise = False
    is_Poly = False
    is_AlgebraicNumber = False
    is_Relational = False
    is_Equality = False
    is_Boolean = False
    is_Not = False
    is_Matrix = False
    is_Vector = False
    is_Point = False
    is_MatAdd = False
    is_MatMul = False
    default_assumptions: ClassVar[StdFactKB]
    is_composite: bool | None
    is_noninteger: bool | None
    is_extended_positive: bool | None
    is_negative: bool | None
    is_complex: bool | None
    is_extended_nonpositive: bool | None
    is_integer: bool | None
    is_positive: bool | None
    is_rational: bool | None
    is_extended_nonnegative: bool | None
    is_infinite: bool | None
    is_extended_negative: bool | None
    is_extended_real: bool | None
    is_finite: bool | None
    is_polar: bool | None
    is_imaginary: bool | None
    is_transcendental: bool | None
    is_extended_nonzero: bool | None
    is_nonzero: bool | None
    is_odd: bool | None
    is_algebraic: bool | None
    is_prime: bool | None
    is_commutative: bool | None
    is_nonnegative: bool | None
    is_nonpositive: bool | None
    is_irrational: bool | None
    is_real: bool | None
    is_zero: bool | None
    is_even: bool | None
    kind: Kind = UndefinedKind

    def __new__(cls, *args):
        obj = object.__new__(cls)
        obj._assumptions = cls.default_assumptions
        obj._mhash = None
        obj._args = args
        return obj

    def copy(self):
        return self.func(*self.args)

    def __getnewargs__(self) -> tuple[Basic, ...] | tuple[Hashable, ...]:
        return self.args

    def __getstate__(self):
        return None

    def __setstate__(self, state):
        for name, value in state.items():
            setattr(self, name, value)

    def __reduce_ex__(self, protocol):
        if protocol < 2:
            msg = 'Only pickle protocol 2 or higher is supported by SymPy'
            raise NotImplementedError(msg)
        return super().__reduce_ex__(protocol)

    def __hash__(self) -> int:
        h = self._mhash
        if h is None:
            h = hash((type(self).__name__,) + self._hashable_content())
            self._mhash = h
        return h

    def _hashable_content(self) -> tuple[Hashable, ...]:
        return self._args

    @property
    def assumptions0(self):
        return {}

    def compare(self, other):
        if self is other:
            return 0
        n1 = self.__class__
        n2 = other.__class__
        c = _cmp_name(n1, n2)
        if c:
            return c
        st = self._hashable_content()
        ot = other._hashable_content()
        len_st = len(st)
        len_ot = len(ot)
        c = (len_st > len_ot) - (len_st < len_ot)
        if c:
            return c
        for l, r in zip(st, ot):
            if isinstance(l, Basic):
                c = l.compare(r)
            elif isinstance(l, frozenset):
                l = Basic(*l) if isinstance(l, frozenset) else l
                r = Basic(*r) if isinstance(r, frozenset) else r
                c = l.compare(r)
            else:
                c = (l > r) - (l < r)
            if c:
                return c
        return 0

    @classmethod
    def fromiter(cls, args, **assumptions):
        return cls(*tuple(args), **assumptions)

    @classmethod
    def class_key(cls) -> tuple[int, int, str]:
        return (5, 0, cls.__name__)

    @cacheit
    def sort_key(self, order=None):

        def inner_key(arg):
            if isinstance(arg, Basic):
                return arg.sort_key(order)
            else:
                return arg
        args = self._sorted_args
        args = (len(args), tuple([inner_key(arg) for arg in args]))
        return (self.class_key(), args, S.One.sort_key(), S.One)

    def _do_eq_sympify(self, other):
        for superclass in type(other).__mro__:
            conv = _external_converter.get(superclass)
            if conv is not None:
                return self == conv(other)
        if hasattr(other, '_sympy_'):
            return self == other._sympy_()
        return NotImplemented

    def __eq__(self, other):
        if self is other:
            return True
        if not isinstance(other, Basic):
            return self._do_eq_sympify(other)
        if not (self.is_Number and other.is_Number) and type(self) != type(other):
            return False
        a, b = (self._hashable_content(), other._hashable_content())
        if a != b:
            return False
        for a, b in zip(a, b):
            if not isinstance(a, Basic):
                continue
            if a.is_Number and type(a) != type(b):
                return False
        return True

    def __ne__(self, other):
        return not self == other

    def dummy_eq(self, other, symbol=None):
        s = self.as_dummy()
        o = _sympify(other)
        o = o.as_dummy()
        dummy_symbols = [i for i in s.free_symbols if i.is_Dummy]
        if len(dummy_symbols) == 1:
            dummy = dummy_symbols.pop()
        else:
            return s == o
        if symbol is None:
            symbols = o.free_symbols
            if len(symbols) == 1:
                symbol = symbols.pop()
            else:
                return s == o
        tmp = dummy.__class__()
        return s.xreplace({dummy: tmp}) == o.xreplace({symbol: tmp})

    @overload
    def atoms(self) -> set[Basic]:
        pass

    @overload
    def atoms(self, *types: Tbasic | type[Tbasic]) -> set[Tbasic]:
        pass

    def atoms(self, *types: Tbasic | type[Tbasic]) -> set[Basic] | set[Tbasic]:
        nodes = _preorder_traversal(self)
        if types:
            types2 = tuple([t if isinstance(t, type) else type(t) for t in types])
            return {node for node in nodes if isinstance(node, types2)}
        else:
            return {node for node in nodes if not node.args}

    @property
    def free_symbols(self) -> set[Basic]:
        empty: set[Basic] = set()
        return empty.union(*(a.free_symbols for a in self.args))

    @property
    def expr_free_symbols(self):
        sympy_deprecation_warning('\n        The expr_free_symbols property is deprecated. Use free_symbols to get\n        the free symbols of an expression.\n        ', deprecated_since_version='1.9', active_deprecations_target='deprecated-expr-free-symbols')
        return set()

    def as_dummy(self) -> 'Self':
        from .symbol import Dummy, Symbol

        def can(x):
            free = x.free_symbols
            bound = set(x.bound_symbols)
            d = {i: Dummy() for i in bound & free}
            x = x.subs(d)
            x = x.xreplace(x.canonical_variables)
            return x.xreplace({v: k for k, v in d.items()})
        if not self.has(Symbol):
            return self
        return self.replace(lambda x: hasattr(x, 'bound_symbols'), can, simultaneous=False)

    @property
    def canonical_variables(self) -> dict[Basic, Symbol]:
        bound: list[Basic] | None = getattr(self, 'bound_symbols', None)
        if bound is None:
            return {}
        dums = numbered_symbols('_')
        reps = {}
        names = {i.name for i in self.free_symbols - set(bound)}
        for b in bound:
            d = next(dums)
            if b.is_Symbol:
                while d.name in names:
                    d = next(dums)
            reps[b] = d
        return reps

    def rcall(self, *args):
        if callable(self):
            return self(*args)
        elif self.args:
            newargs = [sub.rcall(*args) for sub in self.args]
            return self.func(*newargs)
        else:
            return self

    def is_hypergeometric(self, k):
        from sympy.simplify.simplify import hypersimp
        from sympy.functions.elementary.piecewise import Piecewise
        if self.has(Piecewise):
            return None
        return hypersimp(self, k) is not None

    @property
    def is_comparable(self):
        return self._eval_is_comparable()

    def _eval_is_comparable(self) -> bool:
        return False

    @property
    def func(self):
        return self.__class__

    @property
    def args(self) -> tuple[Basic, ...]:
        return self._args

    @property
    def _sorted_args(self):
        return self.args

    def as_content_primitive(self, radical=False, clear=True):
        return (S.One, self)

    @overload
    def subs(self, arg1: _SupportsItems[Basic | complex, Basic | complex] | Iterable[tuple[Basic | complex, Basic | complex]], arg2: None=None, **kwargs: Any) -> Basic:
        pass

    @overload
    def subs(self, arg1: Basic | complex, arg2: Basic | complex, **kwargs: Any) -> Basic:
        pass

    def subs(self, arg1: _SupportsItems[Basic | complex, Basic | complex] | Iterable[tuple[Basic | complex, Basic | complex]] | Basic | complex, arg2: Basic | complex | None=None, **kwargs: Any) -> Basic:
        from .containers import Dict
        from .symbol import Dummy, Symbol
        from .numbers import _illegal
        items: Iterable[tuple[Basic | complex, Basic | complex]]
        unordered = False
        if arg2 is None:
            if isinstance(arg1, set):
                items = arg1
                unordered = True
            elif isinstance(arg1, (Dict, Mapping)):
                unordered = True
                items = arg1.items()
            elif not iterable(arg1):
                raise ValueError(filldedent('\n                   When a single argument is passed to subs\n                   it should be a dictionary of old: new pairs or an iterable\n                   of (old, new) tuples.'))
            else:
                items = arg1
        else:
            items = [(arg1, arg2)]

        def sympify_old(old) -> Basic:
            if isinstance(old, str):
                return Symbol(old)
            elif isinstance(old, type):
                return sympify(old, strict=False)
            else:
                return sympify(old, strict=True)

        def sympify_new(new) -> Basic:
            if isinstance(new, (str, type)):
                return sympify(new, strict=False)
            else:
                return sympify(new, strict=True)
        sequence = [(sympify_old(s1), sympify_new(s2)) for s1, s2 in items]
        sequence = [(s1, s2) for s1, s2 in sequence if not _aresame(s1, s2)]
        simultaneous = kwargs.pop('simultaneous', False)
        if unordered:
            from .sorting import _nodes, default_sort_key
            sequence_dict = dict(sequence)
            k = list(ordered(sequence_dict, default=False, keys=(lambda x: -_nodes(x), default_sort_key)))
            sequence = [(k, sequence_dict[k]) for k in k]
            if not simultaneous:
                redo = [i for i, seq in enumerate(sequence) if seq[1] in _illegal]
                for i in reversed(redo):
                    sequence.insert(0, sequence.pop(i))
        if simultaneous:
            reps = {}
            rv = self
            kwargs['hack2'] = True
            m = Dummy('subs_m')
            for old, new in sequence:
                com = new.is_commutative
                if com is None:
                    com = True
                d = Dummy('subs_d', commutative=com)
                rv = rv._subs(old, d * m, **kwargs)
                if not isinstance(rv, Basic):
                    break
                reps[d] = new
            reps[m] = S.One
            return rv.xreplace(reps)
        else:
            rv = self
            for old, new in sequence:
                rv = rv._subs(old, new, **kwargs)
                if not isinstance(rv, Basic):
                    break
            return rv

    @cacheit
    def _subs(self, old, new, **hints):

        def fallback(self, old, new):
            hit = False
            args = list(self.args)
            for i, arg in enumerate(args):
                if not hasattr(arg, '_eval_subs'):
                    continue
                arg = arg._subs(old, new, **hints)
                if not _aresame(arg, args[i]):
                    hit = True
                    args[i] = arg
            if hit:
                rv = self.func(*args)
                hack2 = hints.get('hack2', False)
                if hack2 and self.is_Mul and (not rv.is_Mul):
                    coeff = S.One
                    nonnumber = []
                    for i in args:
                        if i.is_Number:
                            coeff *= i
                        else:
                            nonnumber.append(i)
                    nonnumber = self.func(*nonnumber)
                    if coeff is S.One:
                        return nonnumber
                    else:
                        return self.func(coeff, nonnumber, evaluate=False)
                return rv
            return self
        if _aresame(self, old):
            return new
        rv = self._eval_subs(old, new)
        if rv is None:
            rv = fallback(self, old, new)
        return rv

    def _eval_subs(self, old: Basic, new: Basic) -> Basic | None:
        return None

    def xreplace(self, rule):
        value, _ = self._xreplace(rule)
        return value

    def _xreplace(self, rule):
        if self in rule:
            return (rule[self], True)
        elif rule:
            args = []
            changed = False
            for a in self.args:
                _xreplace = getattr(a, '_xreplace', None)
                if _xreplace is not None:
                    a_xr = _xreplace(rule)
                    args.append(a_xr[0])
                    changed |= a_xr[1]
                else:
                    args.append(a)
            args = tuple(args)
            if changed:
                return (self.func(*args), True)
        return (self, False)

    @cacheit
    def has(self, *patterns):
        return self._has(iterargs, *patterns)

    def has_xfree(self, s: set[Basic]):
        if type(s) is not set:
            raise TypeError('expecting set argument')
        return any((a in s for a in iterfreeargs(self)))

    @cacheit
    def has_free(self, *patterns):
        if not patterns:
            return False
        p0 = patterns[0]
        if len(patterns) == 1 and iterable(p0) and (not isinstance(p0, Basic)):
            raise TypeError(filldedent("\n                Expecting 1 or more Basic args, not a single\n                non-Basic iterable. Don't forget to unpack\n                iterables: `eq.has_free(*patterns)`"))
        s = set(patterns)
        rv = self.has_xfree(s)
        if rv:
            return rv
        return self._has(iterfreeargs, *patterns)

    def _has(self, iterargs, *patterns):
        type_set = set()
        p_set = set()
        for p in patterns:
            if isinstance(p, type) and issubclass(p, Basic):
                type_set.add(p)
                continue
            if not isinstance(p, Basic):
                try:
                    p = _sympify(p)
                except SympifyError:
                    continue
            p_set.add(p)
        types = tuple(type_set)
        for i in iterargs(self):
            if i in p_set:
                return True
            if isinstance(i, types):
                return True
        for i in p_set - type_set:
            if not hasattr(i, '_has_matcher'):
                continue
            match = i._has_matcher()
            if any((match(arg) for arg in iterargs(self))):
                return True
        return False

    def replace(self, query, value, map=False, simultaneous=True, exact=None) -> Basic:
        try:
            query = _sympify(query)
        except SympifyError:
            pass
        try:
            value = _sympify(value)
        except SympifyError:
            pass
        if isinstance(query, type):
            _query = lambda expr: isinstance(expr, query)
            if isinstance(value, type) or callable(value):
                _value = lambda expr, result: value(*expr.args)
            else:
                raise TypeError('given a type, replace() expects another type or a callable')
        elif isinstance(query, Basic):
            _query = lambda expr: expr.match(query)
            if exact is None:
                from .symbol import Wild
                exact = len(query.atoms(Wild)) > 1
            if isinstance(value, Basic):
                if exact:
                    _value = lambda expr, result: value.subs(result) if all(result.values()) else expr
                else:
                    _value = lambda expr, result: value.subs(result)
            elif callable(value):
                if exact:
                    _value = lambda expr, result: value(**{str(k)[:-1]: v for k, v in result.items()}) if all((val for val in result.values())) else expr
                else:
                    _value = lambda expr, result: value(**{str(k)[:-1]: v for k, v in result.items()})
            else:
                raise TypeError('given an expression, replace() expects another expression or a callable')
        elif callable(query):
            _query = query
            if callable(value):
                _value = lambda expr, result: value(expr)
            else:
                raise TypeError('given a callable, replace() expects another callable')
        else:
            raise TypeError('first argument to replace() must be a type, an expression or a callable')

        def walk(rv, F):
            args = getattr(rv, 'args', None)
            if args is not None:
                if args:
                    newargs = tuple([walk(a, F) for a in args])
                    if args != newargs:
                        rv = rv.func(*newargs)
                        if simultaneous:
                            for i, e in enumerate(args):
                                if rv == e and e != newargs[i]:
                                    return rv
                rv = F(rv)
            return rv
        mapping = {}

        def rec_replace(expr):
            result = _query(expr)
            if result or result == {}:
                v = _value(expr, result)
                if v is not None and v != expr:
                    if map:
                        mapping[expr] = v
                    expr = v
            return expr
        rv = walk(self, rec_replace)
        return (rv, mapping) if map else rv

    def find(self, query, group=False):
        query = _make_find_query(query)
        results = list(filter(query, _preorder_traversal(self)))
        if not group:
            return set(results)
        return dict(Counter(results))

    def count(self, query):
        query = _make_find_query(query)
        return sum((bool(query(sub)) for sub in _preorder_traversal(self)))

    def matches(self, expr, repl_dict=None, old=False):
        expr = sympify(expr)
        if not isinstance(expr, self.__class__):
            return None
        if repl_dict is None:
            repl_dict = {}
        else:
            repl_dict = repl_dict.copy()
        if self == expr:
            return repl_dict
        if len(self.args) != len(expr.args):
            return None
        d = repl_dict
        for arg, other_arg in zip(self.args, expr.args):
            if arg == other_arg:
                continue
            if arg.is_Relational:
                try:
                    d = arg.xreplace(d).matches(other_arg, d, old=old)
                except TypeError:
                    d = None
            else:
                d = arg.xreplace(d).matches(other_arg, d, old=old)
            if d is None:
                return None
        return d

    def match(self, pattern, old=False):
        pattern = sympify(pattern)
        return pattern.matches(self, old=old)

    def count_ops(self, visual=False):
        from .function import count_ops
        return count_ops(self, visual)

    def doit(self, **hints):
        if hints.get('deep', True):
            terms = [term.doit(**hints) if isinstance(term, Basic) else term for term in self.args]
            return self.func(*terms)
        else:
            return self

    def simplify(self, **kwargs) -> Basic:
        from sympy.simplify.simplify import simplify
        return simplify(self, **kwargs)

    def refine(self, assumption=True):
        from sympy.assumptions.refine import refine
        return refine(self, assumption)

    def _eval_derivative_n_times(self, s, n):
        from .numbers import Integer
        if isinstance(n, (int, Integer)):
            obj = self
            for i in range(n):
                prev = obj
                obj = obj._eval_derivative(s)
                if obj is None:
                    return None
                elif obj == prev:
                    break
            return obj
        else:
            return None

    def rewrite(self, *args, deep=True, **hints):
        if not args:
            return self
        hints.update(deep=deep)
        pattern = args[:-1]
        rule = args[-1]
        if rule is abs:
            from sympy.functions.elementary.complexes import Abs
            rule = Abs
        if isinstance(rule, str):
            method = '_eval_rewrite_as_%s' % rule
        elif hasattr(rule, '__name__'):
            clsname = rule.__name__
            method = '_eval_rewrite_as_%s' % clsname
        else:
            clsname = rule.__class__.__name__
            method = '_eval_rewrite_as_%s' % clsname
        if pattern:
            if iterable(pattern[0]):
                pattern = pattern[0]
            pattern = tuple((p for p in pattern if self.has(p)))
            if not pattern:
                return self
        return self._rewrite(pattern, rule, method, **hints)

    def _rewrite(self, pattern, rule, method, **hints):
        deep = hints.pop('deep', True)
        if deep:
            args = [a._rewrite(pattern, rule, method, **hints) for a in self.args]
        else:
            args = self.args
        if not pattern or any((isinstance(self, p) for p in pattern)):
            meth = getattr(self, method, None)
            if meth is not None:
                rewritten = meth(*args, **hints)
            else:
                rewritten = self._eval_rewrite(rule, args, **hints)
            if rewritten is not None:
                return rewritten
        if not args:
            return self
        return self.func(*args)

    def _eval_rewrite(self, rule, args, **hints):
        return None
    _constructor_postprocessor_mapping = {}

    @classmethod
    def _exec_constructor_postprocessors(cls, obj):
        clsname = obj.__class__.__name__
        postprocessors = {f for i in obj.args for f in _get_postprocessors(clsname, type(i))}
        for f in postprocessors:
            obj = f(obj)
        return obj

    def _sage_(self):
        old_method = self._sage_
        from sage.interfaces.sympy import sympy_init
        sympy_init()
        if old_method == self._sage_:
            raise NotImplementedError('conversion to SageMath is not implemented')
        else:
            return self._sage_()

    def could_extract_minus_sign(self) -> bool:
        return False

    def is_same(a, b, approx=None):
        from .numbers import Number
        from .traversal import postorder_traversal as pot
        for t in zip_longest(pot(a), pot(b)):
            if None in t:
                return False
            a, b = t
            if isinstance(a, Number):
                if not isinstance(b, Number):
                    return False
                if approx:
                    return approx(a, b)
            if not (a == b and a.__class__ == b.__class__):
                return False
        return True
_aresame = Basic.is_same
_args_sortkey = cmp_to_key(Basic.compare)
_prepare_class_assumptions(Basic)

class Atom(Basic):
    is_Atom = True
    __slots__ = ()

    def matches(self, expr, repl_dict=None, old=False):
        if self == expr:
            if repl_dict is None:
                return {}
            return repl_dict.copy()

    def xreplace(self, rule, hack2=False):
        return rule.get(self, self)

    def doit(self, **hints):
        return self

    @classmethod
    def class_key(cls):
        return (2, 0, cls.__name__)

    @cacheit
    def sort_key(self, order=None):
        return (self.class_key(), (1, (str(self),)), S.One.sort_key(), S.One)

    def _eval_simplify(self, **kwargs):
        return self

    @property
    def _sorted_args(self):
        raise AttributeError('Atoms have no args. It might be necessary to make a check for Atoms in the calling code.')

def _atomic(e, recursive=False):
    pot = _preorder_traversal(e)
    seen = set()
    if isinstance(e, Basic):
        free = getattr(e, 'free_symbols', None)
        if free is None:
            return {e}
    else:
        return set()
    from .symbol import Symbol
    from .function import Derivative, Function
    atoms = set()
    for p in pot:
        if p in seen:
            pot.skip()
            continue
        seen.add(p)
        if isinstance(p, Symbol) and p in free:
            atoms.add(p)
        elif isinstance(p, (Derivative, Function)):
            if not recursive:
                pot.skip()
            atoms.add(p)
    return atoms

def _make_find_query(query):
    try:
        query = _sympify(query)
    except SympifyError:
        pass
    if isinstance(query, type):
        return lambda expr: isinstance(expr, query)
    elif isinstance(query, Basic):
        return lambda expr: expr.match(query) is not None
    return query
from .singleton import S
from .traversal import preorder_traversal as _preorder_traversal, iterargs, iterfreeargs
preorder_traversal = deprecated('\n    Using preorder_traversal from the sympy.core.basic submodule is\n    deprecated.\n\n    Instead, use preorder_traversal from the top-level sympy namespace, like\n\n        sympy.preorder_traversal\n    ', deprecated_since_version='1.10', active_deprecations_target='deprecated-traversal-functions-moved')(_preorder_traversal)