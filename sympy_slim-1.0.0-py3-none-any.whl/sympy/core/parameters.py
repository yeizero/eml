from __future__ import annotations
from .cache import clear_cache
from contextlib import contextmanager
from threading import local

class _global_parameters(local):

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def __setattr__(self, name, value):
        if getattr(self, name) != value:
            clear_cache()
        return super().__setattr__(name, value)
global_parameters = _global_parameters(evaluate=True, distribute=True, exp_is_pow=False)

class evaluate:

    def __init__(self, x):
        self.x = x
        self.old = []

    def __enter__(self):
        self.old.append(global_parameters.evaluate)
        global_parameters.evaluate = self.x

    def __exit__(self, exc_type, exc_val, exc_tb):
        global_parameters.evaluate = self.old.pop()

@contextmanager
def distribute(x):
    old = global_parameters.distribute
    try:
        global_parameters.distribute = x
        yield
    finally:
        global_parameters.distribute = old

@contextmanager
def _exp_is_pow(x):
    old = global_parameters.exp_is_pow
    clear_cache()
    try:
        global_parameters.exp_is_pow = x
        yield
    finally:
        clear_cache()
        global_parameters.exp_is_pow = old