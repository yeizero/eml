from __future__ import annotations
from typing import Callable
from sympy.utilities.iterables import is_sequence
from sympy.utilities.misc import as_int
import random as _random
rng = _random.Random()
choice = rng.choice
random = rng.random
randint = rng.randint
randrange = rng.randrange
sample = rng.sample
shuffle = rng.shuffle
uniform = rng.uniform
_assumptions_rng = _random.Random()
_assumptions_shuffle = _assumptions_rng.shuffle

def seed(a=None, version=2):
    rng.seed(a=a, version=version)
    _assumptions_rng.seed(a=a, version=version)

def random_complex_number(a=2, b=-1, c=3, d=1, rational=False, tolerance=None):
    from sympy.core.numbers import I
    from sympy.simplify.simplify import nsimplify
    A, B = (uniform(a, c), uniform(b, d))
    if not rational:
        return A + I * B
    return nsimplify(A, rational=True, tolerance=tolerance) + I * nsimplify(B, rational=True, tolerance=tolerance)

def verify_numerically(f, g, z=None, tol=1e-06, a=2, b=-1, c=3, d=1):
    from sympy.core.symbol import Symbol
    from sympy.core.sympify import sympify
    from sympy.core.numbers import comp
    f, g = (sympify(i) for i in (f, g))
    if z is None:
        z = f.free_symbols | g.free_symbols
    elif isinstance(z, Symbol):
        z = [z]
    reps = list(zip(z, [random_complex_number(a, b, c, d) for _ in z]))
    z1 = f.subs(reps).n()
    z2 = g.subs(reps).n()
    return comp(z1, z2, tol)

def test_derivative_numerically(f, z, tol=1e-06, a=2, b=-1, c=3, d=1):
    from sympy.core.numbers import comp
    from sympy.core.function import Derivative
    z0 = random_complex_number(a, b, c, d)
    f1 = f.diff(z).subs(z, z0)
    f2 = Derivative(f, z).doit_numerically(z0)
    return comp(f1.n(), f2.n(), tol)

def _randrange(seed=None):
    if seed is None:
        return randrange
    elif isinstance(seed, int):
        rng.seed(seed)
        return randrange
    elif is_sequence(seed):
        seed = list(seed)
        seed.reverse()

        def give(a, b=None, seq=seed):
            if b is None:
                a, b = (0, a)
            a, b = (as_int(a), as_int(b))
            w = b - a
            if w < 1:
                raise ValueError('_randrange got empty range')
            try:
                x = seq.pop()
            except IndexError:
                raise ValueError('_randrange sequence was too short')
            if a <= x < b:
                return x
            else:
                return give(a, b, seq)
        return give
    else:
        raise ValueError('_randrange got an unexpected seed')

def _randint(seed: int | None | list[int]=None) -> Callable[[int, int], int]:
    if seed is None:
        return randint
    elif isinstance(seed, int):
        rng.seed(seed)
        return randint
    elif is_sequence(seed):
        seed = list(seed)
        seed.reverse()

        def give(a, b, seq=seed):
            a, b = (as_int(a), as_int(b))
            w = b - a
            if w < 0:
                raise ValueError('_randint got empty range')
            try:
                x = seq.pop()
            except IndexError:
                raise ValueError('_randint sequence was too short')
            if a <= x <= b:
                return x
            else:
                return give(a, b, seq)
        return give
    else:
        raise ValueError('_randint got an unexpected seed')