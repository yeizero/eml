from __future__ import annotations
from typing import Iterator
from .basic import Basic
from .sorting import ordered
from .sympify import sympify
from sympy.utilities.iterables import iterable

def iterargs(expr):
    args = [expr]
    for i in args:
        yield i
        args.extend(i.args)

def iterfreeargs(expr, _first=True):
    args = [expr]
    for i in args:
        yield i
        if _first and hasattr(i, 'bound_symbols'):
            void = i.canonical_variables.values()
            for i in iterfreeargs(i.as_dummy(), _first=False):
                if not i.has(*void):
                    yield i
        args.extend(i.args)

class preorder_traversal:

    def __init__(self, node, keys=None):
        self._skip_flag = False
        self._pt = self._preorder_traversal(node, keys)

    def _preorder_traversal(self, node, keys):
        yield node
        if self._skip_flag:
            self._skip_flag = False
            return
        if isinstance(node, Basic):
            if not keys and hasattr(node, '_argset'):
                args = node._argset
            else:
                args = node.args
            if keys:
                if keys != True:
                    args = ordered(args, keys, default=False)
                else:
                    args = ordered(args)
            for arg in args:
                yield from self._preorder_traversal(arg, keys)
        elif iterable(node):
            for item in node:
                yield from self._preorder_traversal(item, keys)

    def skip(self):
        self._skip_flag = True

    def __next__(self):
        return next(self._pt)

    def __iter__(self) -> Iterator[Basic]:
        return self

def use(expr, func, level=0, args=(), kwargs={}):

    def _use(expr, level):
        if not level:
            return func(expr, *args, **kwargs)
        elif expr.is_Atom:
            return expr
        else:
            level -= 1
            _args = [_use(arg, level) for arg in expr.args]
            return expr.__class__(*_args)
    return _use(sympify(expr), level)

def walk(e, *target):
    if isinstance(e, target):
        yield e
        for i in e.args:
            yield from walk(i, *target)

def bottom_up(rv, F, atoms=False, nonbasic=False):
    args = getattr(rv, 'args', None)
    if args is not None:
        if args:
            args = tuple([bottom_up(a, F, atoms, nonbasic) for a in args])
            if args != rv.args:
                rv = rv.func(*args)
            rv = F(rv)
        elif atoms:
            rv = F(rv)
    elif nonbasic:
        try:
            rv = F(rv)
        except TypeError:
            pass
    return rv

def postorder_traversal(node, keys=None):
    if isinstance(node, Basic):
        args = node.args
        if keys:
            if keys != True:
                args = ordered(args, keys, default=False)
            else:
                args = ordered(args)
        for arg in args:
            yield from postorder_traversal(arg, keys)
    elif iterable(node):
        for item in node:
            yield from postorder_traversal(item, keys)
    yield node