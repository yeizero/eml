from __future__ import annotations
from typing import overload, Literal
import numbers
import decimal
import fractions
import math
from .containers import Tuple
from .sympify import SympifyError, _sympy_converter, sympify, _convert_numpy_types, _sympify, _is_numpy_instance
from .singleton import S, Singleton
from .basic import Basic
from .expr import Expr, AtomicExpr
from .evalf import pure_complex
from .cache import cacheit, clear_cache
from .decorators import _sympifyit
from .intfunc import num_digits, igcd, ilcm, mod_inverse, integer_nthroot
from .logic import fuzzy_not
from .kind import NumberKind
from .sorting import ordered
from sympy.external.gmpy import SYMPY_INTS, gmpy, flint
from sympy.multipledispatch import dispatch
from sympy.external.mpmath import mpnumeric, make_mpf as _make_mpf, mpf as _mpf, finf as _mpf_inf, fninf as _mpf_ninf, fnan as _mpf_nan, fzero, normalize as mpf_normalize, prec_to_dps, dps_to_prec, round_nearest as rnd, to_float as _to_float, to_int as _to_int, from_int as _from_int, from_rational as _from_rational, from_float as _from_float, from_str as _from_str, MPZ, mpf_neg as _mpf_neg, mpf_gt as _mpf_gt, mpf_lt as _mpf_lt, mpf_le as _mpf_le, mpf_ge as _mpf_ge, mpf_abs as _mpf_abs, mpf_floor as _mpf_floor, mpf_ceil as _mpf_ceil, mpf_add as _mpf_add, mpf_sub as _mpf_sub, mpf_mul as _mpf_mul, mpf_div as _mpf_div, mpf_mod as _mpf_mod, mpf_pow_int as _mpf_pow_int, mpf_pow, mpf_pi, mpf_e, mpc_pow as _mpc_pow, phi_fixed, from_man_exp as _from_man_exp, catalan_fixed as _catalan_fixed, euler_fixed as _euler_fixed, ComplexResult as _ComplexResult
from sympy.utilities.misc import debug, as_int
from sympy.utilities.exceptions import sympy_deprecation_warning
from .parameters import global_parameters
_LOG2 = math.log(2)

def comp(z1, z2, tol=None):
    if isinstance(z2, str):
        if not pure_complex(z1, or_real=True):
            raise ValueError('when z2 is a str z1 must be a Number')
        return str(z1) == z2
    if not z1:
        z1, z2 = (z2, z1)
    if not z1:
        return True
    if not tol:
        a, b = (z1, z2)
        if tol == '':
            return str(a) == str(b)
        if tol is None:
            a, b = (sympify(a), sympify(b))
            if not all((i.is_number for i in (a, b))):
                raise ValueError('expecting 2 numbers')
            fa = a.atoms(Float)
            fb = b.atoms(Float)
            if not fa and (not fb):
                return a == b
            for _ in range(2):
                ca = pure_complex(a, or_real=True)
                if not ca:
                    if fa:
                        a = a.n(prec_to_dps(min((i._prec for i in fa))))
                        ca = pure_complex(a, or_real=True)
                        break
                    else:
                        fa, fb = (fb, fa)
                        a, b = (b, a)
            cb = pure_complex(b)
            if not cb and fb:
                b = b.n(prec_to_dps(min((i._prec for i in fb))))
                cb = pure_complex(b, or_real=True)
            if ca and cb and (ca[1] or cb[1]):
                return all((comp(i, j) for i, j in zip(ca, cb)))
            tol = 10 ** prec_to_dps(min(a._prec, getattr(b, '_prec', a._prec)))
            return int(abs(a - b) * tol) <= 5
    diff = abs(z1 - z2)
    az1 = abs(z1)
    if z2 and az1 > 1:
        return diff / az1 <= tol
    else:
        return diff <= tol

def mpf_norm(mpf, prec):
    sign, man, expt, bc = mpf
    if not man:
        if not bc:
            return fzero
        else:
            return mpf
    rv = mpf_normalize(sign, MPZ(man), expt, bc, prec, rnd)
    return rv
_errdict = {'divide': False}

def seterr(divide=False):
    if _errdict['divide'] != divide:
        clear_cache()
        _errdict['divide'] = divide

def _as_integer_ratio(p):
    neg_pow, man, expt, _ = getattr(p, '_mpf_', _mpf(p)._mpf_)
    p = [1, -1][neg_pow % 2] * man
    if expt < 0:
        q = 2 ** (-expt)
    else:
        q = 1
        p *= 2 ** expt
    return (int(p), int(q))

def _decimal_to_Rational_prec(dec):
    if not dec.is_finite():
        raise TypeError('dec must be finite, got %s.' % dec)
    s, d, e = dec.as_tuple()
    prec = len(d)
    if e >= 0:
        rv = Integer(int(dec))
    else:
        s = (-1) ** s
        d = sum((di * 10 ** i for i, di in enumerate(reversed(d))))
        rv = Rational(s * d, 10 ** (-e))
    return (rv, prec)
_dig = str.maketrans(dict.fromkeys('1234567890'))

def _literal_float(s):
    parts = s.split('e')
    if len(parts) > 2:
        return False
    if len(parts) == 2:
        m, e = parts
        if e.startswith(tuple('+-')):
            e = e[1:]
        if not e:
            return False
    else:
        m, e = (s, '1')
    parts = m.split('.')
    if len(parts) > 2:
        return False
    elif len(parts) == 2:
        i, f = parts
    else:
        i, f = (m, '1')
    if not i and (not f):
        return False
    if i and i[0] in '+-':
        i = i[1:]
    if not i:
        i = '1'
    f = f or '1'
    for n in (i, f, e):
        for g in n.split('_'):
            if not g or g.translate(_dig):
                return False
    return True

class Number(AtomicExpr):
    is_commutative = True
    is_number = True
    is_Number = True
    __slots__ = ()
    _prec = -1
    kind = NumberKind

    def __new__(cls, *obj):
        if len(obj) == 1:
            obj = obj[0]
        if isinstance(obj, Number):
            return obj
        if isinstance(obj, SYMPY_INTS):
            return Integer(obj)
        if isinstance(obj, tuple) and len(obj) == 2:
            return Rational(*obj)
        if isinstance(obj, (float, _mpf, decimal.Decimal)):
            return Float(obj)
        if isinstance(obj, str):
            _obj = obj.lower()
            if _obj == 'nan':
                return S.NaN
            elif _obj == 'inf':
                return S.Infinity
            elif _obj == '+inf':
                return S.Infinity
            elif _obj == '-inf':
                return S.NegativeInfinity
            val = sympify(obj)
            if isinstance(val, Number):
                return val
            else:
                raise ValueError('String "%s" does not denote a Number' % obj)
        msg = 'expected str|int|long|float|Decimal|Number object but got %r'
        raise TypeError(msg % type(obj).__name__)

    def could_extract_minus_sign(self):
        return bool(self.is_extended_negative)

    def invert(self, other, *gens, **args):
        from sympy.polys.polytools import invert
        if getattr(other, 'is_number', True):
            return mod_inverse(self, other)
        return invert(self, other, *gens, **args)

    def __divmod__(self, other):
        from sympy.functions.elementary.complexes import sign
        try:
            other = Number(other)
            if self.is_infinite or S.NaN in (self, other):
                return (S.NaN, S.NaN)
        except TypeError:
            return NotImplemented
        if not other:
            raise ZeroDivisionError('modulo by zero')
        if self.is_Integer and other.is_Integer:
            return Tuple(*divmod(self.p, other.p))
        elif isinstance(other, Float):
            rat = self / Rational(other)
        else:
            rat = self / other
        if other.is_finite:
            w = int(rat) if rat >= 0 else int(rat) - 1
            r = self - other * w
            if r == Float(other):
                w += 1
                r = 0
            if isinstance(self, Float) or isinstance(other, Float):
                r = Float(r)
        else:
            w = 0 if not self or sign(self) == sign(other) else -1
            r = other if w else self
        return Tuple(w, r)

    def __rdivmod__(self, other):
        try:
            other = Number(other)
        except TypeError:
            return NotImplemented
        return divmod(other, self)

    def _as_mpf_val(self, prec):
        raise NotImplementedError('%s needs ._as_mpf_val() method' % self.__class__.__name__)

    def _eval_evalf(self, prec):
        return Float._new(self._as_mpf_val(prec), prec)

    def _as_mpf_op(self, prec):
        prec = max(prec, self._prec)
        return (self._as_mpf_val(prec), prec)

    def __float__(self):
        return _to_float(self._as_mpf_val(53))

    def floor(self):
        raise NotImplementedError('%s needs .floor() method' % self.__class__.__name__)

    def ceiling(self):
        raise NotImplementedError('%s needs .ceiling() method' % self.__class__.__name__)

    def __floor__(self):
        return self.floor()

    def __ceil__(self):
        return self.ceiling()

    def _eval_conjugate(self):
        return self

    def _eval_order(self, *symbols):
        from sympy.series.order import Order
        return Order(S.One, *symbols)

    def _eval_subs(self, old, new):
        if old == -self:
            return -new
        return self

    @classmethod
    def class_key(cls):
        return (1, 0, 'Number')

    @cacheit
    def sort_key(self, order=None):
        return (self.class_key(), (0, ()), (), self)

    def __neg__(self) -> Number:
        raise NotImplementedError

    @overload
    def __add__(self, other: Number | int | float) -> Number:
        pass

    @overload
    def __add__(self, other: Expr) -> Expr:
        pass

    @_sympifyit('other', NotImplemented)
    def __add__(self, other) -> Expr:
        if isinstance(other, Number) and global_parameters.evaluate:
            if other is S.NaN:
                return S.NaN
            elif other is S.Infinity:
                return S.Infinity
            elif other is S.NegativeInfinity:
                return S.NegativeInfinity
        return AtomicExpr.__add__(self, other)

    @_sympifyit('other', NotImplemented)
    def __sub__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            if other is S.NaN:
                return S.NaN
            elif other is S.Infinity:
                return S.NegativeInfinity
            elif other is S.NegativeInfinity:
                return S.Infinity
        return AtomicExpr.__sub__(self, other)

    @_sympifyit('other', NotImplemented)
    def __mul__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            if other is S.NaN:
                return S.NaN
            elif other is S.Infinity:
                if self.is_zero:
                    return S.NaN
                elif self.is_positive:
                    return S.Infinity
                else:
                    return S.NegativeInfinity
            elif other is S.NegativeInfinity:
                if self.is_zero:
                    return S.NaN
                elif self.is_positive:
                    return S.NegativeInfinity
                else:
                    return S.Infinity
        elif isinstance(other, Tuple):
            return NotImplemented
        return AtomicExpr.__mul__(self, other)

    @_sympifyit('other', NotImplemented)
    def __truediv__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            if other is S.NaN:
                return S.NaN
            elif other in (S.Infinity, S.NegativeInfinity):
                return S.Zero
        return AtomicExpr.__truediv__(self, other)

    def __eq__(self, other):
        raise NotImplementedError('%s needs .__eq__() method' % self.__class__.__name__)

    def __ne__(self, other):
        raise NotImplementedError('%s needs .__ne__() method' % self.__class__.__name__)

    def __lt__(self, other):
        try:
            other = _sympify(other)
        except SympifyError:
            raise TypeError('Invalid comparison %s < %s' % (self, other))
        raise NotImplementedError('%s needs .__lt__() method' % self.__class__.__name__)

    def __le__(self, other):
        try:
            other = _sympify(other)
        except SympifyError:
            raise TypeError('Invalid comparison %s <= %s' % (self, other))
        raise NotImplementedError('%s needs .__le__() method' % self.__class__.__name__)

    def __gt__(self, other):
        try:
            other = _sympify(other)
        except SympifyError:
            raise TypeError('Invalid comparison %s > %s' % (self, other))
        return _sympify(other).__lt__(self)

    def __ge__(self, other):
        try:
            other = _sympify(other)
        except SympifyError:
            raise TypeError('Invalid comparison %s >= %s' % (self, other))
        return _sympify(other).__le__(self)

    def __hash__(self):
        return super().__hash__()

    def is_constant(self, *wrt, **flags):
        return True

    def as_coeff_mul(self, *deps, rational=True, **kwargs):
        if self.is_Rational or not rational:
            return (self, ())
        elif self.is_negative:
            return (S.NegativeOne, (-self,))
        return (S.One, (self,))

    def as_coeff_add(self, *deps):
        if self.is_Rational:
            return (self, ())
        return (S.Zero, (self,))

    def as_coeff_Mul(self, rational=False):
        if not rational:
            return (self, S.One)
        return (S.One, self)

    def as_coeff_Add(self, rational=False):
        if not rational:
            return (self, S.Zero)
        return (S.Zero, self)

    def gcd(self, other):
        from sympy.polys.polytools import gcd
        return gcd(self, other)

    def lcm(self, other):
        from sympy.polys.polytools import lcm
        return lcm(self, other)

    def cofactors(self, other):
        from sympy.polys.polytools import cofactors
        return cofactors(self, other)

class Float(Number):
    __slots__ = ('_mpf_', '_prec')
    _mpf_: tuple[int, int, int, int]
    is_rational = None
    is_irrational = None
    is_number = True
    is_real = True
    is_extended_real = True
    is_Float = True
    _remove_non_digits = str.maketrans(dict.fromkeys('-+_.'))

    def __new__(cls, num, dps=None, precision=None):
        if dps is not None and precision is not None:
            raise ValueError('Both decimal and binary precision supplied. Supply only one. ')
        if isinstance(num, str):
            _num = num = num.strip()
            num = num.replace(' ', '_').lower()
            if num.startswith('.') and len(num) > 1:
                num = '0' + num
            elif num.startswith('-.') and len(num) > 2:
                num = '-0.' + num[2:]
            elif num in ('inf', '+inf'):
                return S.Infinity
            elif num == '-inf':
                return S.NegativeInfinity
            elif num == 'nan':
                return S.NaN
            elif not _literal_float(num):
                raise ValueError('string-float not recognized: %s' % _num)
        elif isinstance(num, float) and num == 0:
            num = '0'
        elif isinstance(num, float) and num == float('inf'):
            return S.Infinity
        elif isinstance(num, float) and num == float('-inf'):
            return S.NegativeInfinity
        elif isinstance(num, float) and math.isnan(num):
            return S.NaN
        elif isinstance(num, (SYMPY_INTS, Integer)):
            num = str(num)
        elif num is S.Infinity or num is S.NegativeInfinity or num is S.NaN:
            return num
        elif _is_numpy_instance(num):
            num = _convert_numpy_types(num)
        elif isinstance(num, _mpf):
            if precision is None:
                if dps is None:
                    precision = num.context.prec
            num = num._mpf_
        if dps is None and precision is None:
            dps = 15
            if isinstance(num, Float):
                return num
            if isinstance(num, str):
                try:
                    Num = decimal.Decimal(num)
                except decimal.InvalidOperation:
                    pass
                else:
                    isint = '.' not in num
                    num, dps = _decimal_to_Rational_prec(Num)
                    if num.is_Integer and isint:
                        dps = max(dps, num_digits(num))
                    dps = max(15, dps)
                    precision = dps_to_prec(dps)
        elif precision == '' and dps is None or (precision is None and dps == ''):
            if not isinstance(num, str):
                raise ValueError('The null string can only be used when the number to Float is passed as a string or an integer.')
            try:
                Num = decimal.Decimal(num)
            except decimal.InvalidOperation:
                raise ValueError('string-float not recognized by Decimal: %s' % num)
            else:
                isint = '.' not in num
                num, dps = _decimal_to_Rational_prec(Num)
                if num.is_Integer and isint:
                    dps = max(dps, num_digits(num))
                    precision = dps_to_prec(dps)
        if precision is None or precision == '':
            precision = dps_to_prec(dps)
        precision = int(precision)
        if isinstance(num, float):
            _mpf_ = _from_float(num, precision, rnd)
        elif isinstance(num, str):
            _mpf_ = _from_str(num, precision, rnd)
        elif isinstance(num, decimal.Decimal):
            if num.is_finite():
                _mpf_ = _from_str(str(num), precision, rnd)
            elif num.is_nan():
                return S.NaN
            elif num.is_infinite():
                if num > 0:
                    return S.Infinity
                return S.NegativeInfinity
            else:
                raise ValueError('unexpected decimal value %s' % str(num))
        elif isinstance(num, tuple) and len(num) in (3, 4):
            if isinstance(num[1], str):
                num = list(num)
                num[1] = num[1].removeprefix('0x').removesuffix('L')
                num[1] = MPZ(num[1], 16)
                _mpf_ = tuple(num)
            elif len(num) == 4:
                return Float._new(num, precision)
            else:
                if not all((num[0] in (0, 1), num[1] >= 0, all((type(i) in (int, int) for i in num)))):
                    raise ValueError('malformed mpf: %s' % (num,))
                return Float._new((num[0], num[1], num[2], num[1].bit_length()), precision)
        elif isinstance(num, (Number, NumberSymbol)):
            _mpf_ = num._as_mpf_val(precision)
        else:
            _mpf_ = _mpf(num, prec=precision)._mpf_
        return cls._new(_mpf_, precision, zero=False)

    @classmethod
    def _new(cls, _mpf_, _prec, zero=True):
        if zero and _mpf_ == fzero:
            return S.Zero
        elif _mpf_ == _mpf_nan:
            return S.NaN
        elif _mpf_ == _mpf_inf:
            return S.Infinity
        elif _mpf_ == _mpf_ninf:
            return S.NegativeInfinity
        obj = Expr.__new__(cls)
        obj._mpf_ = mpf_norm(_mpf_, _prec)
        obj._prec = _prec
        return obj

    def __getnewargs_ex__(self):
        sign, man, exp, bc = self._mpf_
        arg = (sign, f'{man:x}', exp, bc)
        kwargs = {'precision': self._prec}
        return ((arg,), kwargs)

    def _hashable_content(self):
        return (self._mpf_, self._prec)

    def floor(self):
        return Integer(int(_to_int(_mpf_floor(self._mpf_, self._prec))))

    def ceiling(self):
        return Integer(int(_to_int(_mpf_ceil(self._mpf_, self._prec))))

    def __floor__(self):
        return self.floor()

    def __ceil__(self):
        return self.ceiling()

    @property
    def num(self):
        return _mpf(self._mpf_)

    def _as_mpf_val(self, prec):
        rv = mpf_norm(self._mpf_, prec)
        if rv != self._mpf_ and self._prec == prec:
            debug(self._mpf_, rv)
        return rv

    def _as_mpf_op(self, prec):
        return (self._mpf_, max(prec, self._prec))

    def _eval_is_finite(self):
        if self._mpf_ in (_mpf_inf, _mpf_ninf):
            return False
        return True

    def _eval_is_infinite(self):
        if self._mpf_ in (_mpf_inf, _mpf_ninf):
            return True
        return False

    def _eval_is_integer(self):
        if self._mpf_ == fzero:
            return True
        if not int_valued(self):
            return False

    def _eval_is_negative(self):
        if self._mpf_ in (_mpf_ninf, _mpf_inf):
            return False
        return self.num < 0

    def _eval_is_positive(self):
        if self._mpf_ in (_mpf_ninf, _mpf_inf):
            return False
        return self.num > 0

    def _eval_is_extended_negative(self):
        if self._mpf_ == _mpf_ninf:
            return True
        if self._mpf_ == _mpf_inf:
            return False
        return self.num < 0

    def _eval_is_extended_positive(self):
        if self._mpf_ == _mpf_inf:
            return True
        if self._mpf_ == _mpf_ninf:
            return False
        return self.num > 0

    def _eval_is_zero(self):
        return self._mpf_ == fzero

    def __bool__(self):
        return self._mpf_ != fzero

    def __neg__(self):
        if not self:
            return self
        return Float._new(_mpf_neg(self._mpf_), self._prec)

    @_sympifyit('other', NotImplemented)
    def __add__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            rhs, prec = other._as_mpf_op(self._prec)
            return Float._new(_mpf_add(self._mpf_, rhs, prec, rnd), prec)
        return Number.__add__(self, other)

    @_sympifyit('other', NotImplemented)
    def __sub__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            rhs, prec = other._as_mpf_op(self._prec)
            return Float._new(_mpf_sub(self._mpf_, rhs, prec, rnd), prec)
        return Number.__sub__(self, other)

    @_sympifyit('other', NotImplemented)
    def __mul__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            rhs, prec = other._as_mpf_op(self._prec)
            return Float._new(_mpf_mul(self._mpf_, rhs, prec, rnd), prec)
        return Number.__mul__(self, other)

    @_sympifyit('other', NotImplemented)
    def __truediv__(self, other):
        if isinstance(other, Number) and other != 0 and global_parameters.evaluate:
            rhs, prec = other._as_mpf_op(self._prec)
            return Float._new(_mpf_div(self._mpf_, rhs, prec, rnd), prec)
        return Number.__truediv__(self, other)

    @_sympifyit('other', NotImplemented)
    def __mod__(self, other):
        if isinstance(other, Rational) and other.q != 1 and global_parameters.evaluate:
            return Float(Rational.__mod__(Rational(self), other), precision=self._prec)
        if isinstance(other, Float) and global_parameters.evaluate:
            r = self / other
            if int_valued(r):
                return Float(0, precision=max(self._prec, other._prec))
        if isinstance(other, Number) and global_parameters.evaluate:
            rhs, prec = other._as_mpf_op(self._prec)
            return Float._new(_mpf_mod(self._mpf_, rhs, prec, rnd), prec)
        return Number.__mod__(self, other)

    @_sympifyit('other', NotImplemented)
    def __rmod__(self, other):
        if isinstance(other, Float) and global_parameters.evaluate:
            return other.__mod__(self)
        if isinstance(other, Number) and global_parameters.evaluate:
            rhs, prec = other._as_mpf_op(self._prec)
            return Float._new(_mpf_mod(rhs, self._mpf_, prec, rnd), prec)
        return Number.__rmod__(self, other)

    def _eval_power(self, expt):
        if equal_valued(self, 0):
            if expt.is_extended_positive:
                return self
            if expt.is_extended_negative:
                return S.ComplexInfinity
        if isinstance(expt, Number):
            if isinstance(expt, Integer):
                prec = self._prec
                return Float._new(_mpf_pow_int(self._mpf_, expt.p, prec, rnd), prec)
            elif isinstance(expt, Rational) and expt.p == 1 and expt.q % 2 and self.is_negative:
                return Pow(S.NegativeOne, expt, evaluate=False) * (-self)._eval_power(expt)
            expt, prec = expt._as_mpf_op(self._prec)
            mpfself = self._mpf_
            try:
                y = mpf_pow(mpfself, expt, prec, rnd)
                return Float._new(y, prec)
            except _ComplexResult:
                re, im = _mpc_pow((mpfself, fzero), (expt, fzero), prec, rnd)
                return Float._new(re, prec) + Float._new(im, prec) * S.ImaginaryUnit

    def __abs__(self):
        return Float._new(_mpf_abs(self._mpf_), self._prec)

    def __int__(self):
        if self._mpf_ == fzero:
            return 0
        return int(_to_int(self._mpf_))

    def __eq__(self, other):
        if isinstance(other, float):
            other = Float(other)
        return Basic.__eq__(self, other)

    def __ne__(self, other):
        eq = self.__eq__(other)
        if eq is NotImplemented:
            return eq
        else:
            return not eq

    def __hash__(self):
        float_val = float(self)
        if not math.isinf(float_val):
            return hash(float_val)
        return Basic.__hash__(self)

    def _Frel(self, other, op):
        try:
            other = _sympify(other)
        except SympifyError:
            return NotImplemented
        if other.is_Rational:
            '\n            >>> f = Float(.1,2)\n            >>> i = 1234567890\n            >>> (f*i)._mpf_\n            (0, 471, 18, 9)\n            >>> mpf_mul(f._mpf_, from_int(i))\n            (0, 505555550955, -12, 39)\n            '
            smpf = _mpf_mul(self._mpf_, _from_int(other.q))
            ompf = _from_int(other.p)
            return _sympify(bool(op(smpf, ompf)))
        elif other.is_Float:
            return _sympify(bool(op(self._mpf_, other._mpf_)))
        elif other.is_comparable and other not in (S.Infinity, S.NegativeInfinity):
            other = other.evalf(prec_to_dps(self._prec))
            if other._prec > 1:
                if other.is_Number:
                    return _sympify(bool(op(self._mpf_, other._as_mpf_val(self._prec))))

    def __gt__(self, other):
        if isinstance(other, NumberSymbol):
            return other.__lt__(self)
        rv = self._Frel(other, _mpf_gt)
        if rv is None:
            return Expr.__gt__(self, other)
        return rv

    def __ge__(self, other):
        if isinstance(other, NumberSymbol):
            return other.__le__(self)
        rv = self._Frel(other, _mpf_ge)
        if rv is None:
            return Expr.__ge__(self, other)
        return rv

    def __lt__(self, other):
        if isinstance(other, NumberSymbol):
            return other.__gt__(self)
        rv = self._Frel(other, _mpf_lt)
        if rv is None:
            return Expr.__lt__(self, other)
        return rv

    def __le__(self, other):
        if isinstance(other, NumberSymbol):
            return other.__ge__(self)
        rv = self._Frel(other, _mpf_le)
        if rv is None:
            return Expr.__le__(self, other)
        return rv

    def epsilon_eq(self, other, epsilon='1e-15'):
        return abs(self - other) < Float(epsilon)

    def __format__(self, format_spec):
        return format(decimal.Decimal(str(self)), format_spec)
_sympy_converter[float] = _sympy_converter[decimal.Decimal] = Float
RealNumber = Float

class Rational(Number):
    is_real = True
    is_integer = False
    is_rational = True
    is_number = True
    __slots__ = ('p', 'q')
    p: int
    q: int
    is_Rational = True

    @cacheit
    def __new__(cls, p, q=None, gcd=None):
        if q is None:
            if isinstance(p, Rational):
                return p
            if isinstance(p, SYMPY_INTS):
                pass
            else:
                if isinstance(p, (float, Float)):
                    return Rational(*_as_integer_ratio(p))
                if not isinstance(p, str):
                    try:
                        p = sympify(p)
                    except (SympifyError, SyntaxError):
                        pass
                else:
                    if p.count('/') > 1:
                        raise TypeError('invalid input: %s' % p)
                    p = p.replace(' ', '')
                    pq = p.rsplit('/', 1)
                    if len(pq) == 2:
                        p, q = pq
                        fp = fractions.Fraction(p)
                        fq = fractions.Fraction(q)
                        p = fp / fq
                    try:
                        p = fractions.Fraction(p)
                    except ValueError:
                        pass
                    else:
                        return cls._new(p.numerator, p.denominator, 1)
                if not isinstance(p, Rational):
                    raise TypeError('invalid input: %s' % p)
            q = 1
        Q = 1
        if not isinstance(p, SYMPY_INTS):
            p = Rational(p)
            Q *= p.q
            p = p.p
        else:
            p = int(p)
        if not isinstance(q, SYMPY_INTS):
            q = Rational(q)
            p *= q.q
            Q *= q.p
        else:
            Q *= int(q)
        q = Q
        if gcd is not None:
            sympy_deprecation_warning('gcd is deprecated in Rational, use nsimplify instead', deprecated_since_version='1.11', active_deprecations_target='deprecated-rational-gcd', stacklevel=4)
            return cls._new(p, q, gcd)
        return cls._new(p, q)

    @classmethod
    def _new(cls, p, q, gcd=None):
        if q == 0:
            if p == 0:
                if _errdict['divide']:
                    raise ValueError('Indeterminate 0/0')
                else:
                    return S.NaN
            return S.ComplexInfinity
        if q < 0:
            q = -q
            p = -p
        if gcd is None:
            gcd = igcd(abs(p), q)
        if gcd > 1:
            p //= gcd
            q //= gcd
        return cls.from_coprime_ints(p, q)

    @classmethod
    def from_coprime_ints(cls, p: int, q: int) -> Rational:
        if q == 1:
            return Integer(p)
        if p == 1 and q == 2:
            return S.Half
        obj = Expr.__new__(cls)
        obj.p = p
        obj.q = q
        return obj

    def limit_denominator(self, max_denominator=1000000):
        f = fractions.Fraction(self.p, self.q)
        return Rational(f.limit_denominator(fractions.Fraction(int(max_denominator))))

    def __getnewargs__(self):
        return (self.p, self.q)

    def _hashable_content(self):
        return (self.p, self.q)

    def _eval_is_positive(self):
        return self.p > 0

    def _eval_is_zero(self):
        return self.p == 0

    def __neg__(self):
        return Rational(-self.p, self.q)

    @_sympifyit('other', NotImplemented)
    def __add__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, Integer):
                return Rational._new(self.p + self.q * other.p, self.q, 1)
            elif isinstance(other, Rational):
                return Rational(self.p * other.q + self.q * other.p, self.q * other.q)
            elif isinstance(other, Float):
                return other + self
            else:
                return Number.__add__(self, other)
        return Number.__add__(self, other)
    __radd__ = __add__

    @_sympifyit('other', NotImplemented)
    def __sub__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, Integer):
                return Rational._new(self.p - self.q * other.p, self.q, 1)
            elif isinstance(other, Rational):
                return Rational(self.p * other.q - self.q * other.p, self.q * other.q)
            elif isinstance(other, Float):
                return -other + self
            else:
                return Number.__sub__(self, other)
        return Number.__sub__(self, other)

    @_sympifyit('other', NotImplemented)
    def __rsub__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, Integer):
                return Rational._new(self.q * other.p - self.p, self.q, 1)
            elif isinstance(other, Rational):
                return Rational(self.q * other.p - self.p * other.q, self.q * other.q)
            elif isinstance(other, Float):
                return -self + other
            else:
                return Number.__rsub__(self, other)
        return Number.__rsub__(self, other)

    @_sympifyit('other', NotImplemented)
    def __mul__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, Integer):
                return Rational._new(self.p * other.p, self.q, igcd(other.p, self.q))
            elif isinstance(other, Rational):
                return Rational._new(self.p * other.p, self.q * other.q, igcd(self.p, other.q) * igcd(self.q, other.p))
            elif isinstance(other, Float):
                return other * self
            else:
                return Number.__mul__(self, other)
        return Number.__mul__(self, other)
    __rmul__ = __mul__

    @_sympifyit('other', NotImplemented)
    def __truediv__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, Integer):
                if self.p and other.p == S.Zero:
                    return S.ComplexInfinity
                else:
                    return Rational._new(self.p, self.q * other.p, igcd(self.p, other.p))
            elif isinstance(other, Rational):
                return Rational._new(self.p * other.q, self.q * other.p, igcd(self.p, other.p) * igcd(self.q, other.q))
            elif isinstance(other, Float):
                return self * (1 / other)
            else:
                return Number.__truediv__(self, other)
        return Number.__truediv__(self, other)

    @_sympifyit('other', NotImplemented)
    def __rtruediv__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, Integer):
                return Rational._new(other.p * self.q, self.p, igcd(self.p, other.p))
            elif isinstance(other, Rational):
                return Rational._new(other.p * self.q, other.q * self.p, igcd(self.p, other.p) * igcd(self.q, other.q))
            elif isinstance(other, Float):
                return other * (1 / self)
            else:
                return Number.__rtruediv__(self, other)
        return Number.__rtruediv__(self, other)

    @_sympifyit('other', NotImplemented)
    def __mod__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, Rational):
                n = self.p * other.q // (other.p * self.q)
                return Rational(self.p * other.q - n * other.p * self.q, self.q * other.q)
            if isinstance(other, Float):
                return Float(self.__mod__(Rational(other)), precision=other._prec)
            return Number.__mod__(self, other)
        return Number.__mod__(self, other)

    @_sympifyit('other', NotImplemented)
    def __rmod__(self, other):
        if isinstance(other, Rational):
            return Rational.__mod__(other, self)
        return Number.__rmod__(self, other)

    def _eval_power(self, expt):
        if isinstance(expt, Number):
            if isinstance(expt, Float):
                return self._eval_evalf(expt._prec) ** expt
            if expt.is_extended_negative:
                ne = -expt
                if ne is S.One:
                    return Rational(self.q, self.p)
                if self.is_negative:
                    return S.NegativeOne ** expt * Rational(self.q, -self.p) ** ne
                else:
                    return Rational(self.q, self.p) ** ne
            if expt is S.Infinity:
                if self.p > self.q:
                    return S.Infinity
                if self.p < -self.q:
                    return S.Infinity + S.Infinity * S.ImaginaryUnit
                return S.Zero
            if isinstance(expt, Integer):
                return Rational._new(self.p ** expt.p, self.q ** expt.p, 1)
            if isinstance(expt, Rational):
                intpart = expt.p // expt.q
                if intpart:
                    intpart += 1
                    remfracpart = intpart * expt.q - expt.p
                    ratfracpart = Rational(remfracpart, expt.q)
                    if self.p != 1:
                        return Integer(self.p) ** expt * Integer(self.q) ** ratfracpart * Rational._new(1, self.q ** intpart, 1)
                    return Integer(self.q) ** ratfracpart * Rational._new(1, self.q ** intpart, 1)
                else:
                    remfracpart = expt.q - expt.p
                    ratfracpart = Rational(remfracpart, expt.q)
                    if self.p != 1:
                        return Integer(self.p) ** expt * Integer(self.q) ** ratfracpart * Rational._new(1, self.q, 1)
                    return Integer(self.q) ** ratfracpart * Rational._new(1, self.q, 1)
        if self.is_extended_negative and expt.is_even:
            return (-self) ** expt
        return

    def _as_mpf_val(self, prec):
        return _from_rational(self.p, self.q, prec, rnd)

    def _mpmath_(self, prec, rnd):
        return _make_mpf(_from_rational(self.p, self.q, prec, rnd))

    def __abs__(self):
        return Rational(abs(self.p), self.q)

    def __int__(self):
        p, q = (self.p, self.q)
        if p < 0:
            return -int(-p // q)
        return int(p // q)

    def floor(self):
        return Integer(self.p // self.q)

    def ceiling(self):
        return -Integer(-self.p // self.q)

    def __floor__(self):
        return self.floor()

    def __ceil__(self):
        return self.ceiling()

    def __eq__(self, other):
        try:
            other = _sympify(other)
        except SympifyError:
            return NotImplemented
        if not isinstance(other, Number):
            return False
        if other.is_NumberSymbol:
            if other.is_irrational:
                return False
            return other.__eq__(self)
        if other.is_Rational:
            return self.p == other.p and self.q == other.q
        return False

    def __ne__(self, other):
        return not self == other

    def _Rrel(self, other, attr):
        try:
            other = _sympify(other)
        except SympifyError:
            return NotImplemented
        if other.is_Number:
            op = None
            s, o = (self, other)
            if other.is_NumberSymbol or other.is_Float:
                op = getattr(o, attr)
            elif other.is_Rational:
                s, o = (Integer(s.p * o.q), Integer(s.q * o.p))
                op = getattr(o, attr)
            if op:
                return op(s)
            if o.is_number and o.is_extended_real:
                return (Integer(s.p), s.q * o)

    def __gt__(self, other):
        rv = self._Rrel(other, '__lt__')
        if rv is None:
            rv = (self, other)
        elif not isinstance(rv, tuple):
            return rv
        return Expr.__gt__(*rv)

    def __ge__(self, other):
        rv = self._Rrel(other, '__le__')
        if rv is None:
            rv = (self, other)
        elif not isinstance(rv, tuple):
            return rv
        return Expr.__ge__(*rv)

    def __lt__(self, other):
        rv = self._Rrel(other, '__gt__')
        if rv is None:
            rv = (self, other)
        elif not isinstance(rv, tuple):
            return rv
        return Expr.__lt__(*rv)

    def __le__(self, other):
        rv = self._Rrel(other, '__ge__')
        if rv is None:
            rv = (self, other)
        elif not isinstance(rv, tuple):
            return rv
        return Expr.__le__(*rv)

    def __hash__(self):
        return super().__hash__()

    def __format__(self, format_spec):
        return format(fractions.Fraction(self.p, self.q), format_spec)

    def factors(self, limit=None, use_trial=True, use_rho=False, use_pm1=False, verbose=False, visual=False):
        from sympy.ntheory.factor_ import factorrat
        return factorrat(self, limit=limit, use_trial=use_trial, use_rho=use_rho, use_pm1=use_pm1, verbose=verbose).copy()

    @property
    def numerator(self):
        return self.p

    @property
    def denominator(self):
        return self.q

    @_sympifyit('other', NotImplemented)
    def gcd(self, other):
        if isinstance(other, Rational):
            if other == S.Zero:
                return other
            return Rational(igcd(self.p, other.p), ilcm(self.q, other.q))
        return Number.gcd(self, other)

    @_sympifyit('other', NotImplemented)
    def lcm(self, other):
        if isinstance(other, Rational):
            return Rational(self.p // igcd(self.p, other.p) * other.p, igcd(self.q, other.q))
        return Number.lcm(self, other)

    def as_numer_denom(self):
        return (Integer(self.p), Integer(self.q))

    def as_content_primitive(self, radical=False, clear=True):
        if self:
            if self.is_positive:
                return (self, S.One)
            return (-self, S.NegativeOne)
        return (S.One, self)

    @overload
    def as_coeff_Mul(self, rational: Literal[True]) -> tuple[Rational, Expr]:
        pass

    @overload
    def as_coeff_Mul(self, rational: bool=False) -> tuple['Number', Expr]:
        pass

    def as_coeff_Mul(self, rational=False):
        return (self, S.One)

    def as_coeff_Add(self, rational=False):
        return (self, S.Zero)

class Integer(Rational):
    q = 1
    is_integer = True
    is_number = True
    is_Integer = True
    __slots__ = ()

    def _as_mpf_val(self, prec):
        return _from_int(self.p, prec, rnd)

    def _mpmath_(self, prec, rnd):
        return _make_mpf(self._as_mpf_val(prec))

    @cacheit
    def __new__(cls, i):
        if isinstance(i, str):
            i = i.replace(' ', '')
        try:
            ival = int(i)
        except TypeError:
            raise TypeError('Argument of Integer should be of numeric type, got %s.' % i)
        if ival == 1:
            return S.One
        if ival == -1:
            return S.NegativeOne
        if ival == 0:
            return S.Zero
        obj = Expr.__new__(cls)
        obj.p = ival
        return obj

    def __getnewargs__(self):
        return (self.p,)

    def __int__(self):
        return self.p

    def floor(self):
        return Integer(self.p)

    def ceiling(self):
        return Integer(self.p)

    def __floor__(self):
        return self.floor()

    def __ceil__(self):
        return self.ceiling()

    def __neg__(self):
        return Integer(-self.p)

    def __abs__(self):
        if self.p >= 0:
            return self
        else:
            return Integer(-self.p)

    def __divmod__(self, other):
        if isinstance(other, Integer) and global_parameters.evaluate:
            return Tuple(*divmod(self.p, other.p))
        else:
            return Number.__divmod__(self, other)

    def __rdivmod__(self, other):
        if isinstance(other, int) and global_parameters.evaluate:
            return Tuple(*divmod(other, self.p))
        else:
            try:
                other = Number(other)
            except TypeError:
                msg = "unsupported operand type(s) for divmod(): '%s' and '%s'"
                oname = type(other).__name__
                sname = type(self).__name__
                raise TypeError(msg % (oname, sname))
            return Number.__divmod__(other, self)

    def __add__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, int):
                return Integer(self.p + other)
            elif isinstance(other, Integer):
                return Integer(self.p + other.p)
            elif isinstance(other, Rational):
                return Rational._new(self.p * other.q + other.p, other.q, 1)
            return Rational.__add__(self, other)
        else:
            return Add(self, other)

    def __radd__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, int):
                return Integer(other + self.p)
            elif isinstance(other, Rational):
                return Rational._new(other.p + self.p * other.q, other.q, 1)
            return Rational.__radd__(self, other)
        return Rational.__radd__(self, other)

    def __sub__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, int):
                return Integer(self.p - other)
            elif isinstance(other, Integer):
                return Integer(self.p - other.p)
            elif isinstance(other, Rational):
                return Rational._new(self.p * other.q - other.p, other.q, 1)
            return Rational.__sub__(self, other)
        return Rational.__sub__(self, other)

    def __rsub__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, int):
                return Integer(other - self.p)
            elif isinstance(other, Rational):
                return Rational._new(other.p - self.p * other.q, other.q, 1)
            return Rational.__rsub__(self, other)
        return Rational.__rsub__(self, other)

    def __mul__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, int):
                return Integer(self.p * other)
            elif isinstance(other, Integer):
                return Integer(self.p * other.p)
            elif isinstance(other, Rational):
                return Rational._new(self.p * other.p, other.q, igcd(self.p, other.q))
            return Rational.__mul__(self, other)
        return Rational.__mul__(self, other)

    def __rmul__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, int):
                return Integer(other * self.p)
            elif isinstance(other, Rational):
                return Rational._new(other.p * self.p, other.q, igcd(self.p, other.q))
            return Rational.__rmul__(self, other)
        return Rational.__rmul__(self, other)

    def __mod__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, int):
                return Integer(self.p % other)
            elif isinstance(other, Integer):
                return Integer(self.p % other.p)
            return Rational.__mod__(self, other)
        return Rational.__mod__(self, other)

    def __rmod__(self, other):
        if global_parameters.evaluate:
            if isinstance(other, int):
                return Integer(other % self.p)
            elif isinstance(other, Integer):
                return Integer(other.p % self.p)
            return Rational.__rmod__(self, other)
        return Rational.__rmod__(self, other)

    def __pow__(self, other, mod=None):
        if mod is not None:
            try:
                other_int = as_int(other)
                mod_int = as_int(mod)
            except ValueError:
                pass
            else:
                return Integer(pow(self.p, other_int, mod_int))
        return super().__pow__(other, mod)

    def __eq__(self, other):
        if isinstance(other, int):
            return self.p == other
        elif isinstance(other, Integer):
            return self.p == other.p
        return Rational.__eq__(self, other)

    def __ne__(self, other):
        return not self == other

    def __gt__(self, other):
        try:
            other = _sympify(other)
        except SympifyError:
            return NotImplemented
        if other.is_Integer:
            return _sympify(self.p > other.p)
        return Rational.__gt__(self, other)

    def __lt__(self, other):
        try:
            other = _sympify(other)
        except SympifyError:
            return NotImplemented
        if other.is_Integer:
            return _sympify(self.p < other.p)
        return Rational.__lt__(self, other)

    def __ge__(self, other):
        try:
            other = _sympify(other)
        except SympifyError:
            return NotImplemented
        if other.is_Integer:
            return _sympify(self.p >= other.p)
        return Rational.__ge__(self, other)

    def __le__(self, other):
        try:
            other = _sympify(other)
        except SympifyError:
            return NotImplemented
        if other.is_Integer:
            return _sympify(self.p <= other.p)
        return Rational.__le__(self, other)

    def __hash__(self):
        return hash(self.p)

    def __index__(self):
        return self.p

    def _eval_is_odd(self):
        return bool(self.p % 2)

    def _eval_power(self, expt):
        from sympy.ntheory.factor_ import perfect_power
        if expt is S.Infinity:
            if self.p > S.One:
                return S.Infinity
            return S.Infinity + S.ImaginaryUnit * S.Infinity
        if expt is S.NegativeInfinity:
            return Rational._new(1, self, 1) ** S.Infinity
        if not isinstance(expt, Number):
            if self.is_negative and expt.is_even:
                return (-self) ** expt
        if isinstance(expt, Float):
            return super()._eval_power(expt)
        if not isinstance(expt, Rational):
            return
        if expt is S.Half and self.is_negative:
            return S.ImaginaryUnit * Pow(-self, expt)
        if expt.is_negative:
            ne = -expt
            if self.is_negative:
                return S.NegativeOne ** expt * Rational._new(1, -self.p, 1) ** ne
            else:
                return Rational._new(1, self.p, 1) ** ne
        x, xexact = integer_nthroot(abs(self.p), expt.q)
        if xexact:
            result = Integer(x ** abs(expt.p))
            if self.is_negative:
                result *= S.NegativeOne ** expt
            return result
        b_pos = int(abs(self.p))
        p = perfect_power(b_pos)
        if p is not False:
            dict = {p[0]: p[1]}
        else:
            dict = Integer(b_pos).factors(limit=2 ** 15)
        out_int = 1
        out_rad = 1
        sqr_int = 1
        sqr_gcd = 0
        sqr_dict = {}
        for prime, exponent in dict.items():
            exponent *= expt.p
            div_e, div_m = divmod(exponent, expt.q)
            if div_e > 0:
                out_int *= prime ** div_e
            if div_m > 0:
                g = igcd(div_m, expt.q)
                if g != 1:
                    out_rad *= Pow(prime, Rational._new(div_m // g, expt.q // g, 1))
                else:
                    sqr_dict[prime] = div_m
        for p, ex in sqr_dict.items():
            if sqr_gcd == 0:
                sqr_gcd = ex
            else:
                sqr_gcd = igcd(sqr_gcd, ex)
                if sqr_gcd == 1:
                    break
        for k, v in sqr_dict.items():
            sqr_int *= k ** (v // sqr_gcd)
        if sqr_int == b_pos and out_int == 1 and (out_rad == 1):
            result = None
        else:
            result = out_int * out_rad * Pow(sqr_int, Rational(sqr_gcd, expt.q))
            if self.is_negative:
                result *= Pow(S.NegativeOne, expt)
        return result

    def _eval_is_prime(self):
        from sympy.ntheory.primetest import isprime
        return isprime(self)

    def _eval_is_composite(self):
        if self > 1:
            return fuzzy_not(self.is_prime)
        else:
            return False

    def as_numer_denom(self):
        return (self, S.One)

    @_sympifyit('other', NotImplemented)
    def __floordiv__(self, other):
        if not isinstance(other, Expr):
            return NotImplemented
        if isinstance(other, Integer):
            return Integer(self.p // other)
        return divmod(self, other)[0]

    def __rfloordiv__(self, other):
        return Integer(Integer(other).p // self.p)

    def __lshift__(self, other):
        if isinstance(other, (int, Integer, numbers.Integral)):
            return Integer(self.p << int(other))
        else:
            return NotImplemented

    def __rlshift__(self, other):
        if isinstance(other, (int, numbers.Integral)):
            return Integer(int(other) << self.p)
        else:
            return NotImplemented

    def __rshift__(self, other):
        if isinstance(other, (int, Integer, numbers.Integral)):
            return Integer(self.p >> int(other))
        else:
            return NotImplemented

    def __rrshift__(self, other):
        if isinstance(other, (int, numbers.Integral)):
            return Integer(int(other) >> self.p)
        else:
            return NotImplemented

    def __and__(self, other):
        if isinstance(other, (int, Integer, numbers.Integral)):
            return Integer(self.p & int(other))
        else:
            return NotImplemented

    def __rand__(self, other):
        if isinstance(other, (int, numbers.Integral)):
            return Integer(int(other) & self.p)
        else:
            return NotImplemented

    def __xor__(self, other):
        if isinstance(other, (int, Integer, numbers.Integral)):
            return Integer(self.p ^ int(other))
        else:
            return NotImplemented

    def __rxor__(self, other):
        if isinstance(other, (int, numbers.Integral)):
            return Integer(int(other) ^ self.p)
        else:
            return NotImplemented

    def __or__(self, other):
        if isinstance(other, (int, Integer, numbers.Integral)):
            return Integer(self.p | int(other))
        else:
            return NotImplemented

    def __ror__(self, other):
        if isinstance(other, (int, numbers.Integral)):
            return Integer(int(other) | self.p)
        else:
            return NotImplemented

    def __invert__(self):
        return Integer(~self.p)
_sympy_converter[int] = Integer

class AlgebraicNumber(Expr):
    __slots__ = ('rep', 'root', 'alias', 'minpoly', '_own_minpoly')
    is_AlgebraicNumber = True
    is_algebraic = True
    is_number = True
    kind = NumberKind
    free_symbols: set[Basic] = set()

    def __new__(cls, expr, coeffs=None, alias=None, **args):
        from sympy.polys.polyclasses import ANP, DMP
        from sympy.polys.numberfields import minimal_polynomial
        expr = sympify(expr)
        rep0 = None
        alias0 = None
        if isinstance(expr, (tuple, Tuple)):
            minpoly, root = expr
            if not minpoly.is_Poly:
                from sympy.polys.polytools import Poly
                minpoly = Poly(minpoly)
        elif expr.is_AlgebraicNumber:
            minpoly, root, rep0, alias0 = (expr.minpoly, expr.root, expr.rep, expr.alias)
        else:
            minpoly, root = (minimal_polynomial(expr, args.get('gen'), polys=True), expr)
        dom = minpoly.get_domain()
        if coeffs is not None:
            if not isinstance(coeffs, ANP):
                rep = DMP.from_sympy_list(sympify(coeffs), 0, dom)
                scoeffs = Tuple(*coeffs)
            else:
                rep = DMP.from_list(coeffs.to_list(), 0, dom)
                scoeffs = Tuple(*coeffs.to_list())
        else:
            rep = DMP.from_list([1, 0], 0, dom)
            scoeffs = Tuple(1, 0)
        if rep0 is not None:
            from sympy.polys.densetools import dup_compose
            c = dup_compose(rep.to_list(), rep0.to_list(), dom)
            rep = DMP.from_list(c, 0, dom)
            scoeffs = Tuple(*c)
        if rep.degree() >= minpoly.degree():
            rep = rep.rem(minpoly.rep)
        sargs = (root, scoeffs)
        alias = alias or alias0
        if alias is not None:
            from .symbol import Symbol
            if not isinstance(alias, Symbol):
                alias = Symbol(alias)
            sargs = sargs + (alias,)
        obj = Expr.__new__(cls, *sargs)
        obj.rep = rep
        obj.root = root
        obj.alias = alias
        obj.minpoly = minpoly
        obj._own_minpoly = None
        return obj

    def __hash__(self):
        return super().__hash__()

    def _eval_evalf(self, prec):
        return self.as_expr()._evalf(prec)

    @property
    def is_aliased(self):
        return self.alias is not None

    def as_poly(self, x=None):
        from sympy.polys.polytools import Poly, PurePoly
        if x is not None:
            return Poly.new(self.rep, x)
        elif self.alias is not None:
            return Poly.new(self.rep, self.alias)
        else:
            from .symbol import Dummy
            return PurePoly.new(self.rep, Dummy('x'))

    def as_expr(self, x=None):
        return self.as_poly(x or self.root).as_expr().expand()

    def coeffs(self):
        return [self.rep.dom.to_sympy(c) for c in self.rep.all_coeffs()]

    def native_coeffs(self):
        return self.rep.all_coeffs()

    def to_algebraic_integer(self):
        from sympy.polys.polytools import Poly
        f = self.minpoly
        if f.LC() == 1:
            return self
        coeff = f.LC() ** (f.degree() - 1)
        poly = f.compose(Poly(f.gen / f.LC()))
        minpoly = poly * coeff
        root = f.LC() * self.root
        return AlgebraicNumber((minpoly, root), self.coeffs())

    def _eval_simplify(self, **kwargs):
        from sympy.polys.rootoftools import CRootOf
        from sympy.polys import minpoly
        measure, ratio = (kwargs['measure'], kwargs['ratio'])
        for r in [r for r in self.minpoly.all_roots() if r.func != CRootOf]:
            if minpoly(self.root - r).is_Symbol:
                if measure(r) < ratio * measure(self.root):
                    return AlgebraicNumber(r)
        return self

    def field_element(self, coeffs):
        return AlgebraicNumber((self.minpoly, self.root), coeffs=coeffs, alias=self.alias)

    @property
    def is_primitive_element(self):
        c = self.coeffs()
        return c == [1, 0] or c == [self.root]

    def primitive_element(self):
        if self.is_primitive_element:
            return self
        return self.field_element([1, 0])

    def to_primitive_element(self, radicals=True):
        if self.is_primitive_element:
            return self
        m = self.minpoly_of_element()
        r = self.to_root(radicals=radicals)
        return AlgebraicNumber((m, r))

    def minpoly_of_element(self):
        if self._own_minpoly is None:
            if self.is_primitive_element:
                self._own_minpoly = self.minpoly
            else:
                from sympy.polys.numberfields.minpoly import minpoly
                theta = self.primitive_element()
                self._own_minpoly = minpoly(self.as_expr(theta), polys=True)
        return self._own_minpoly

    def to_root(self, radicals=True, minpoly=None):
        if self.is_primitive_element and (not isinstance(self.root, AlgebraicNumber)):
            return self.root
        m = minpoly or self.minpoly_of_element()
        roots = m.all_roots(radicals=radicals)
        if len(roots) == 1:
            return roots[0]
        ex = self.as_expr()
        for b in roots:
            if m.same_root(b, ex):
                return b

class RationalConstant(Rational):
    __slots__ = ()

    def __new__(cls):
        return AtomicExpr.__new__(cls)

class IntegerConstant(Integer):
    __slots__ = ()

    def __new__(cls):
        return AtomicExpr.__new__(cls)

class Zero(IntegerConstant, metaclass=Singleton):
    p = 0
    q = 1
    is_positive = False
    is_negative = False
    is_zero = True
    is_number = True
    is_comparable = True
    __slots__ = ()

    def __getnewargs__(self):
        return ()

    @staticmethod
    def __abs__():
        return S.Zero

    @staticmethod
    def __neg__():
        return S.Zero

    def _eval_power(self, expt):
        if expt.is_extended_positive:
            return self
        if expt.is_extended_negative:
            return S.ComplexInfinity
        if expt.is_extended_real is False:
            return S.NaN
        if expt.is_zero:
            return S.One
        coeff, terms = expt.as_coeff_Mul()
        if coeff.is_negative:
            return S.ComplexInfinity ** terms
        if coeff is not S.One:
            return self ** terms

    def _eval_order(self, *symbols):
        return self

    def __bool__(self):
        return False

class One(IntegerConstant, metaclass=Singleton):
    is_number = True
    is_positive = True
    p = 1
    q = 1
    __slots__ = ()

    def __getnewargs__(self):
        return ()

    @staticmethod
    def __abs__():
        return S.One

    @staticmethod
    def __neg__():
        return S.NegativeOne

    def _eval_power(self, expt):
        return self

    def _eval_order(self, *symbols):
        return

    @staticmethod
    def factors(limit=None, use_trial=True, use_rho=False, use_pm1=False, verbose=False, visual=False):
        if visual:
            return S.One
        else:
            return {}

class NegativeOne(IntegerConstant, metaclass=Singleton):
    is_number = True
    p = -1
    q = 1
    __slots__ = ()

    def __getnewargs__(self):
        return ()

    @staticmethod
    def __abs__():
        return S.One

    @staticmethod
    def __neg__():
        return S.One

    def _eval_power(self, expt):
        if expt.is_odd:
            return S.NegativeOne
        if expt.is_even:
            return S.One
        if isinstance(expt, Number):
            if isinstance(expt, Float):
                return Float(-1.0) ** expt
            if expt is S.NaN:
                return S.NaN
            if expt in (S.Infinity, S.NegativeInfinity):
                return S.NaN
            if expt is S.Half:
                return S.ImaginaryUnit
            if isinstance(expt, Rational):
                if expt.q == 2:
                    return S.ImaginaryUnit ** Integer(expt.p)
                i, r = divmod(expt.p, expt.q)
                if i:
                    return self ** i * self ** Rational(r, expt.q)
        return

class Half(RationalConstant, metaclass=Singleton):
    is_number = True
    p = 1
    q = 2
    __slots__ = ()

    def __getnewargs__(self):
        return ()

    @staticmethod
    def __abs__():
        return S.Half

class Infinity(Number, metaclass=Singleton):
    is_commutative = True
    is_number = True
    is_complex = False
    is_extended_real = True
    is_infinite = True
    is_comparable = True
    is_extended_positive = True
    is_prime = False
    __slots__ = ()

    def __new__(cls):
        return AtomicExpr.__new__(cls)

    def _latex(self, printer):
        return '\\infty'

    def _eval_subs(self, old, new):
        if self == old:
            return new

    def _eval_evalf(self, prec=None):
        return Float('inf')

    def evalf(self, prec=None, **options):
        return self._eval_evalf(prec)

    @_sympifyit('other', NotImplemented)
    def __add__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            if other in (S.NegativeInfinity, S.NaN):
                return S.NaN
            return self
        return Number.__add__(self, other)
    __radd__ = __add__

    @_sympifyit('other', NotImplemented)
    def __sub__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            if other in (S.Infinity, S.NaN):
                return S.NaN
            return self
        return Number.__sub__(self, other)

    @_sympifyit('other', NotImplemented)
    def __rsub__(self, other):
        return (-self).__add__(other)

    @_sympifyit('other', NotImplemented)
    def __mul__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            if other.is_zero or other is S.NaN:
                return S.NaN
            if other.is_extended_positive:
                return self
            return S.NegativeInfinity
        return Number.__mul__(self, other)
    __rmul__ = __mul__

    @_sympifyit('other', NotImplemented)
    def __truediv__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            if other is S.Infinity or other is S.NegativeInfinity or other is S.NaN:
                return S.NaN
            if other.is_extended_nonnegative:
                return self
            return S.NegativeInfinity
        return Number.__truediv__(self, other)

    def __abs__(self):
        return S.Infinity

    def __neg__(self):
        return S.NegativeInfinity

    def _eval_power(self, expt):
        if expt.is_extended_positive:
            return S.Infinity
        if expt.is_extended_negative:
            return S.Zero
        if expt is S.NaN:
            return S.NaN
        if expt is S.ComplexInfinity:
            return S.NaN
        if expt.is_extended_real is False and expt.is_number:
            from sympy.functions.elementary.complexes import re
            expt_real = re(expt)
            if expt_real.is_positive:
                return S.ComplexInfinity
            if expt_real.is_negative:
                return S.Zero
            if expt_real.is_zero:
                return S.NaN
            return self ** expt.evalf()

    def _as_mpf_val(self, prec):
        return _mpf_inf

    def __hash__(self):
        return super().__hash__()

    def __eq__(self, other):
        return other is S.Infinity or other == float('inf')

    def __ne__(self, other):
        return other is not S.Infinity and other != float('inf')
    __gt__ = Expr.__gt__
    __ge__ = Expr.__ge__
    __lt__ = Expr.__lt__
    __le__ = Expr.__le__

    @_sympifyit('other', NotImplemented)
    def __mod__(self, other):
        if not isinstance(other, Expr):
            return NotImplemented
        return S.NaN
    __rmod__ = __mod__

    def floor(self):
        return self

    def ceiling(self):
        return self
oo = S.Infinity

class NegativeInfinity(Number, metaclass=Singleton):
    is_extended_real = True
    is_complex = False
    is_commutative = True
    is_infinite = True
    is_comparable = True
    is_extended_negative = True
    is_number = True
    is_prime = False
    __slots__ = ()

    def __new__(cls):
        return AtomicExpr.__new__(cls)

    def _latex(self, printer):
        return '-\\infty'

    def _eval_subs(self, old, new):
        if self == old:
            return new

    def _eval_evalf(self, prec=None):
        return Float('-inf')

    def evalf(self, prec=None, **options):
        return self._eval_evalf(prec)

    @_sympifyit('other', NotImplemented)
    def __add__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            if other in (S.Infinity, S.NaN):
                return S.NaN
            return self
        return Number.__add__(self, other)
    __radd__ = __add__

    @_sympifyit('other', NotImplemented)
    def __sub__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            if other in (S.NegativeInfinity, S.NaN):
                return S.NaN
            return self
        return Number.__sub__(self, other)

    @_sympifyit('other', NotImplemented)
    def __rsub__(self, other):
        return (-self).__add__(other)

    @_sympifyit('other', NotImplemented)
    def __mul__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            if other.is_zero or other is S.NaN:
                return S.NaN
            if other.is_extended_positive:
                return self
            return S.Infinity
        return Number.__mul__(self, other)
    __rmul__ = __mul__

    @_sympifyit('other', NotImplemented)
    def __truediv__(self, other):
        if isinstance(other, Number) and global_parameters.evaluate:
            if other is S.Infinity or other is S.NegativeInfinity or other is S.NaN:
                return S.NaN
            if other.is_extended_nonnegative:
                return self
            return S.Infinity
        return Number.__truediv__(self, other)

    def __abs__(self):
        return S.Infinity

    def __neg__(self):
        return S.Infinity

    def _eval_power(self, expt):
        if expt.is_number:
            if expt is S.NaN or expt is S.Infinity or expt is S.NegativeInfinity:
                return S.NaN
            if isinstance(expt, Integer) and expt.is_extended_positive:
                if expt.is_odd:
                    return S.NegativeInfinity
                else:
                    return S.Infinity
            inf_part = S.Infinity ** expt
            s_part = S.NegativeOne ** expt
            if inf_part == 0 and s_part.is_finite:
                return inf_part
            if inf_part is S.ComplexInfinity and s_part.is_finite and (not s_part.is_zero):
                return S.ComplexInfinity
            return s_part * inf_part

    def _as_mpf_val(self, prec):
        return _mpf_ninf

    def __hash__(self):
        return super().__hash__()

    def __eq__(self, other):
        return other is S.NegativeInfinity or other == float('-inf')

    def __ne__(self, other):
        return other is not S.NegativeInfinity and other != float('-inf')
    __gt__ = Expr.__gt__
    __ge__ = Expr.__ge__
    __lt__ = Expr.__lt__
    __le__ = Expr.__le__

    @_sympifyit('other', NotImplemented)
    def __mod__(self, other):
        if not isinstance(other, Expr):
            return NotImplemented
        return S.NaN
    __rmod__ = __mod__

    def floor(self):
        return self

    def ceiling(self):
        return self

    def as_powers_dict(self):
        return {S.NegativeOne: 1, S.Infinity: 1}

class NaN(Number, metaclass=Singleton):
    is_commutative = True
    is_extended_real = None
    is_real = None
    is_rational = None
    is_algebraic = None
    is_transcendental = None
    is_integer = None
    is_comparable = False
    is_finite = None
    is_zero = None
    is_prime = None
    is_positive = None
    is_negative = None
    is_number = True
    __slots__ = ()

    def __new__(cls):
        return AtomicExpr.__new__(cls)

    def _latex(self, printer):
        return '\\text{NaN}'

    def __neg__(self):
        return self

    @_sympifyit('other', NotImplemented)
    def __add__(self, other):
        return self

    @_sympifyit('other', NotImplemented)
    def __sub__(self, other):
        return self

    @_sympifyit('other', NotImplemented)
    def __mul__(self, other):
        return self

    @_sympifyit('other', NotImplemented)
    def __truediv__(self, other):
        return self

    def floor(self):
        return self

    def ceiling(self):
        return self

    def _as_mpf_val(self, prec):
        return _mpf_nan

    def __hash__(self):
        return super().__hash__()

    def __eq__(self, other):
        return other is S.NaN

    def __ne__(self, other):
        return other is not S.NaN
    __gt__ = Expr.__gt__
    __ge__ = Expr.__ge__
    __lt__ = Expr.__lt__
    __le__ = Expr.__le__
nan = S.NaN

@dispatch(NaN, Expr)
def _eval_is_eq(a, b):
    return False

class ComplexInfinity(AtomicExpr, metaclass=Singleton):
    is_commutative = True
    is_infinite = True
    is_number = True
    is_prime = False
    is_complex = False
    is_extended_real = False
    kind = NumberKind
    __slots__ = ()

    def __new__(cls):
        return AtomicExpr.__new__(cls)

    def _latex(self, printer):
        return '\\tilde{\\infty}'

    @staticmethod
    def __abs__():
        return S.Infinity

    def floor(self):
        return self

    def ceiling(self):
        return self

    @staticmethod
    def __neg__():
        return S.ComplexInfinity

    def _eval_power(self, expt):
        if expt is S.ComplexInfinity:
            return S.NaN
        if isinstance(expt, Number):
            if expt.is_zero:
                return S.NaN
            elif expt.is_positive:
                return S.ComplexInfinity
            else:
                return S.Zero
zoo = S.ComplexInfinity

class NumberSymbol(AtomicExpr):
    is_commutative = True
    is_finite = True
    is_number = True
    __slots__ = ()
    is_NumberSymbol = True
    kind = NumberKind

    def __new__(cls):
        return AtomicExpr.__new__(cls)

    def approximation(self, number_cls):
        pass

    def _eval_evalf(self, prec):
        return Float._new(self._as_mpf_val(prec), prec)

    def __eq__(self, other):
        try:
            other = _sympify(other)
        except SympifyError:
            return NotImplemented
        if self is other:
            return True
        if other.is_Number and self.is_irrational:
            return False
        return False

    def __ne__(self, other):
        return not self == other

    def __le__(self, other):
        if self is other:
            return S.true
        return Expr.__le__(self, other)

    def __ge__(self, other):
        if self is other:
            return S.true
        return Expr.__ge__(self, other)

    def __int__(self):
        raise NotImplementedError

    def __hash__(self):
        return super().__hash__()

class Exp1(NumberSymbol, metaclass=Singleton):
    is_real = True
    is_positive = True
    is_negative = False
    is_irrational = True
    is_number = True
    is_algebraic = False
    is_transcendental = True
    __slots__ = ()

    def _latex(self, printer):
        return 'e'

    @staticmethod
    def __abs__():
        return S.Exp1

    def __int__(self):
        return 2

    def _as_mpf_val(self, prec):
        return mpf_e(prec)

    def approximation_interval(self, number_cls):
        if issubclass(number_cls, Integer):
            return (Integer(2), Integer(3))
        elif issubclass(number_cls, Rational):
            pass

    def _eval_power(self, expt):
        if global_parameters.exp_is_pow:
            return self._eval_power_exp_is_pow(expt)
        else:
            from sympy.functions.elementary.exponential import exp
            return exp(expt)

    def _eval_power_exp_is_pow(self, arg):
        if arg.is_Number:
            if arg is oo:
                return oo
            elif arg == -oo:
                return S.Zero
        from sympy.functions.elementary.exponential import log
        if isinstance(arg, log):
            return arg.args[0]
        elif not arg.is_Add:
            Ioo = I * oo
            if arg in [Ioo, -Ioo]:
                return nan
            coeff = arg.coeff(pi * I)
            if coeff:
                if (2 * coeff).is_integer:
                    if coeff.is_even:
                        return S.One
                    elif coeff.is_odd:
                        return S.NegativeOne
                    elif (coeff + S.Half).is_even:
                        return -I
                    elif (coeff + S.Half).is_odd:
                        return I
                elif coeff.is_Rational:
                    ncoeff = coeff % 2
                    if ncoeff > 1:
                        ncoeff -= 2
                    if ncoeff != coeff:
                        return S.Exp1 ** (ncoeff * S.Pi * S.ImaginaryUnit)
            coeff, terms = arg.as_coeff_Mul()
            if coeff in (oo, -oo):
                return
            coeffs, log_term = ([coeff], None)
            for term in Mul.make_args(terms):
                if isinstance(term, log):
                    if log_term is None:
                        log_term = term.args[0]
                    else:
                        return
                elif term.is_comparable:
                    coeffs.append(term)
                else:
                    return
            return log_term ** Mul(*coeffs) if log_term else None
        elif arg.is_Add:
            out = []
            add = []
            argchanged = False
            for a in arg.args:
                if a is S.One:
                    add.append(a)
                    continue
                newa = self ** a
                if isinstance(newa, Pow) and newa.base is self:
                    if newa.exp != a:
                        add.append(newa.exp)
                        argchanged = True
                    else:
                        add.append(a)
                else:
                    out.append(newa)
            if out or argchanged:
                return Mul(*out) * Pow(self, Add(*add), evaluate=False)
        elif arg.is_Matrix:
            return arg.exp()

    def _eval_rewrite_as_sin(self, **kwargs):
        from sympy.functions.elementary.trigonometric import sin
        return sin(I + S.Pi / 2) - I * sin(I)

    def _eval_rewrite_as_cos(self, **kwargs):
        from sympy.functions.elementary.trigonometric import cos
        return cos(I) + I * cos(I + S.Pi / 2)
E = S.Exp1

class Pi(NumberSymbol, metaclass=Singleton):
    is_real = True
    is_positive = True
    is_negative = False
    is_irrational = True
    is_number = True
    is_algebraic = False
    is_transcendental = True
    __slots__ = ()

    def _latex(self, printer):
        return '\\pi'

    @staticmethod
    def __abs__():
        return S.Pi

    def __int__(self):
        return 3

    def _as_mpf_val(self, prec):
        return mpf_pi(prec)

    def approximation_interval(self, number_cls):
        if issubclass(number_cls, Integer):
            return (Integer(3), Integer(4))
        elif issubclass(number_cls, Rational):
            return (Rational(223, 71, 1), Rational(22, 7, 1))
pi = S.Pi

class GoldenRatio(NumberSymbol, metaclass=Singleton):
    is_real = True
    is_positive = True
    is_negative = False
    is_irrational = True
    is_number = True
    is_algebraic = True
    is_transcendental = False
    __slots__ = ()

    def _latex(self, printer):
        return '\\phi'

    def __int__(self):
        return 1

    def _as_mpf_val(self, prec):
        rv = _from_man_exp(phi_fixed(prec + 10), -prec - 10)
        return mpf_norm(rv, prec)

    def _eval_expand_func(self, **hints):
        from sympy.functions.elementary.miscellaneous import sqrt
        return S.Half + S.Half * sqrt(5)

    def approximation_interval(self, number_cls):
        if issubclass(number_cls, Integer):
            return (S.One, Rational(2))
        elif issubclass(number_cls, Rational):
            pass
    _eval_rewrite_as_sqrt = _eval_expand_func

class TribonacciConstant(NumberSymbol, metaclass=Singleton):
    is_real = True
    is_positive = True
    is_negative = False
    is_irrational = True
    is_number = True
    is_algebraic = True
    is_transcendental = False
    __slots__ = ()

    def _latex(self, printer):
        return '\\text{TribonacciConstant}'

    def __int__(self):
        return 1

    def _as_mpf_val(self, prec):
        return self._eval_evalf(prec)._mpf_

    def _eval_evalf(self, prec):
        rv = self._eval_expand_func(function=True)._eval_evalf(prec + 4)
        return Float(rv, precision=prec)

    def _eval_expand_func(self, **hints):
        from sympy.functions.elementary.miscellaneous import cbrt, sqrt
        return (1 + cbrt(19 - 3 * sqrt(33)) + cbrt(19 + 3 * sqrt(33))) / 3

    def approximation_interval(self, number_cls):
        if issubclass(number_cls, Integer):
            return (S.One, Rational(2))
        elif issubclass(number_cls, Rational):
            pass
    _eval_rewrite_as_sqrt = _eval_expand_func

class EulerGamma(NumberSymbol, metaclass=Singleton):
    is_real = True
    is_positive = True
    is_negative = False
    is_irrational = None
    is_number = True
    __slots__ = ()

    def _latex(self, printer):
        return '\\gamma'

    def __int__(self):
        return 0

    def _as_mpf_val(self, prec):
        v = _euler_fixed(prec + 10)
        rv = _from_man_exp(v, -prec - 10)
        return mpf_norm(rv, prec)

    def approximation_interval(self, number_cls):
        if issubclass(number_cls, Integer):
            return (S.Zero, S.One)
        elif issubclass(number_cls, Rational):
            return (S.Half, Rational(3, 5, 1))

class Catalan(NumberSymbol, metaclass=Singleton):
    is_real = True
    is_positive = True
    is_negative = False
    is_irrational = None
    is_number = True
    __slots__ = ()

    def __int__(self):
        return 0

    def _as_mpf_val(self, prec):
        v = _catalan_fixed(prec + 10)
        rv = _from_man_exp(v, -prec - 10)
        return mpf_norm(rv, prec)

    def approximation_interval(self, number_cls):
        if issubclass(number_cls, Integer):
            return (S.Zero, S.One)
        elif issubclass(number_cls, Rational):
            return (Rational(9, 10, 1), S.One)

    def _eval_rewrite_as_Sum(self, k_sym=None, symbols=None, **hints):
        if k_sym is not None or symbols is not None:
            return self
        from .symbol import Dummy
        from sympy.concrete.summations import Sum
        k = Dummy('k', integer=True, nonnegative=True)
        return Sum(S.NegativeOne ** k / (2 * k + 1) ** 2, (k, 0, S.Infinity))

    def _latex(self, printer):
        return 'G'

class ImaginaryUnit(AtomicExpr, metaclass=Singleton):
    is_commutative = True
    is_imaginary = True
    is_finite = True
    is_number = True
    is_algebraic = True
    is_transcendental = False
    kind = NumberKind
    __slots__ = ()

    def _latex(self, printer):
        return printer._settings['imaginary_unit_latex']

    @staticmethod
    def __abs__():
        return S.One

    def _eval_evalf(self, prec):
        return self

    def _eval_conjugate(self):
        return -S.ImaginaryUnit

    def _eval_power(self, expt):
        if isinstance(expt, Integer):
            expt = expt % 4
            if expt == 0:
                return S.One
            elif expt == 1:
                return S.ImaginaryUnit
            elif expt == 2:
                return S.NegativeOne
            elif expt == 3:
                return -S.ImaginaryUnit
        if isinstance(expt, Rational):
            i, r = divmod(expt, 2)
            rv = Pow(S.ImaginaryUnit, r, evaluate=False)
            if i % 2:
                return Mul(S.NegativeOne, rv, evaluate=False)
            return rv

    def as_base_exp(self):
        return (S.NegativeOne, S.Half)

    @property
    def _mpc_(self):
        return (Float(0)._mpf_, Float(1)._mpf_)
I = S.ImaginaryUnit

def int_valued(x):
    if isinstance(x, (SYMPY_INTS, int)):
        return True
    if type(x) is float:
        return x.is_integer()
    if isinstance(x, Integer):
        return True
    if isinstance(x, Float):
        return x._mpf_[2] >= 0
    return False

def equal_valued(x, y):
    x = _sympify(x)
    y = _sympify(y)
    if not x.is_Float and (not y.is_Float):
        return x == y
    elif x.is_Float and y.is_Float:
        return x._mpf_ == y._mpf_
    elif x.is_Float:
        x, y = (y, x)
    if not x.is_Rational:
        return False
    sign, man, exp, _ = y._mpf_
    p, q = (x.p, x.q)
    if sign:
        man = -man
    if exp == 0:
        return q == 1 and man == p
    elif exp > 0:
        if q != 1:
            return False
        if p.bit_length() != man.bit_length() + exp:
            return False
        return man << exp == p
    else:
        if p != man:
            return False
        neg_exp = -exp
        if q.bit_length() - 1 != neg_exp:
            return False
        return 1 << neg_exp == q

def all_close(expr1, expr2, rtol=1e-05, atol=1e-08):
    NUM_TYPES = (Rational, Float)

    def _all_close(obj1, obj2):
        if type(obj1) == type(obj2) and isinstance(obj1, (list, tuple)):
            if len(obj1) != len(obj2):
                return False
            return all((_all_close(e1, e2) for e1, e2 in zip(obj1, obj2)))
        else:
            return _all_close_expr(_sympify(obj1), _sympify(obj2))

    def _all_close_expr(expr1, expr2):
        num1 = isinstance(expr1, NUM_TYPES)
        num2 = isinstance(expr2, NUM_TYPES)
        if num1 != num2:
            return False
        elif num1:
            return _close_num(expr1, expr2)
        if expr1.is_Add or expr1.is_Mul or expr2.is_Add or expr2.is_Mul:
            return _all_close_ac(expr1, expr2)
        if expr1.func != expr2.func or len(expr1.args) != len(expr2.args):
            return False
        args = zip(expr1.args, expr2.args)
        return all((_all_close_expr(a1, a2) for a1, a2 in args))

    def _close_num(num1, num2):
        return bool(abs(num1 - num2) <= atol + rtol * abs(num2))

    def _all_close_ac(expr1, expr2):
        if expr1.is_Mul or expr2.is_Mul:
            c1, e1 = expr1.as_coeff_mul(rational=False)
            c2, e2 = expr2.as_coeff_mul(rational=False)
            if not _close_num(c1, c2):
                return False
            s1 = set(e1)
            s2 = set(e2)
            common = s1 & s2
            s1 -= common
            s2 -= common
            if not s1:
                return True
            if not any((i.has(Float) for j in (s1, s2) for i in j)):
                return False
            s1 = [i.as_base_exp() for i in ordered(s1)]
            s2 = [i.as_base_exp() for i in ordered(s2)]
            unmatched = list(range(len(s1)))
            for be1 in s1:
                for i in unmatched:
                    be2 = s2[i]
                    if _all_close(be1, be2):
                        unmatched.remove(i)
                        break
                else:
                    return False
            return not unmatched
        assert expr1.is_Add or expr2.is_Add
        cd1 = expr1.as_coefficients_dict()
        cd2 = expr2.as_coefficients_dict()
        if not _close_num(cd1[1], cd2[1]):
            return False
        if len(cd1) != len(cd2):
            return False
        for k in list(cd1):
            if k in cd2:
                if not _close_num(cd1.pop(k), cd2.pop(k)):
                    return False
        else:
            if not cd1:
                return True
        for k1 in cd1:
            for k2 in cd2:
                if _all_close_expr(k1, k2):
                    if not _close_num(cd1[k1], cd2[k2]):
                        return False
                    break
            else:
                return False
        return True
    return _all_close(expr1, expr2)

@dispatch(Tuple, Number)
def _eval_is_eq(self, other):
    return False

def sympify_fractions(f):
    return Rational._new(f.numerator, f.denominator, 1)
_sympy_converter[fractions.Fraction] = sympify_fractions
if gmpy is not None:

    def sympify_mpz(x):
        return Integer(int(x))

    def sympify_mpq(x):
        return Rational(int(x.numerator), int(x.denominator))
    _sympy_converter[type(gmpy.mpz(1))] = sympify_mpz
    _sympy_converter[type(gmpy.mpq(1, 2))] = sympify_mpq
if flint is not None:

    def sympify_fmpz(x):
        return Integer(int(x))

    def sympify_fmpq(x):
        return Rational(int(x.numerator), int(x.denominator))
    _sympy_converter[type(flint.fmpz(1))] = sympify_fmpz
    _sympy_converter[type(flint.fmpq(1, 2))] = sympify_fmpq

def sympify_mpmath(x):
    return Expr._from_mpmath(x, x.context.prec)
_sympy_converter[mpnumeric] = sympify_mpmath

def sympify_complex(a):
    real, imag = list(map(sympify, (a.real, a.imag)))
    return real + S.ImaginaryUnit * imag
_sympy_converter[complex] = sympify_complex
from .power import Pow
from .mul import Mul
Mul.identity = One()
from .add import Add
Add.identity = Zero()

def _register_classes():
    numbers.Number.register(Number)
    numbers.Real.register(Float)
    numbers.Rational.register(Rational)
    numbers.Integral.register(Integer)
_register_classes()
_illegal = (S.NaN, S.Infinity, S.NegativeInfinity, S.ComplexInfinity)