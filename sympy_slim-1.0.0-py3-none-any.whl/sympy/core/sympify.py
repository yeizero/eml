from __future__ import annotations
from typing import Any, Callable, overload, TYPE_CHECKING, TypeVar
from sympy.external.mpmath import from_rational
from inspect import getmro
import string
from sympy.core.random import choice
from .parameters import global_parameters
from sympy.utilities.iterables import iterable
if TYPE_CHECKING:
    from sympy.core.basic import Basic
    from sympy.core.expr import Expr
    from sympy.core.numbers import Integer, Float
    Tbasic = TypeVar('Tbasic', bound=Basic)

class SympifyError(ValueError):

    def __init__(self, expr, base_exc=None):
        self.expr = expr
        self.base_exc = base_exc

    def __str__(self):
        if self.base_exc is None:
            return 'SympifyError: %r' % (self.expr,)
        return "Sympify of expression '%s' failed, because of exception being raised:\n%s: %s" % (self.expr, self.base_exc.__class__.__name__, str(self.base_exc))
converter: dict[type[Any], Callable[[Any], Basic]] = {}
_sympy_converter: dict[type[Any], Callable[[Any], Basic]] = {}
_external_converter = converter

class CantSympify:
    __slots__ = ()

def _is_numpy_instance(a):
    return any((type_.__module__ == 'numpy' for type_ in type(a).__mro__))

def _convert_numpy_types(a, **sympify_args):
    import numpy as np
    if not isinstance(a, np.floating):
        if np.iscomplex(a):
            return _sympy_converter[complex](a.item())
        else:
            return sympify(a.item(), **sympify_args)
    else:
        from .numbers import Float
        prec = np.finfo(a).nmant + 1
        if np.isposinf(a):
            return Float('inf')
        elif np.isneginf(a):
            return Float('-inf')
        else:
            p, q = a.as_integer_ratio()
            a = from_rational(p, q, prec)
            return Float(a, precision=prec)

@overload
def sympify(a: int, *, strict: bool=False) -> Integer:
    pass

@overload
def sympify(a: float, *, strict: bool=False) -> Float:
    pass

@overload
def sympify(a: Expr | complex, *, strict: bool=False) -> Expr:
    pass

@overload
def sympify(a: Tbasic, *, strict: bool=False) -> Tbasic:
    pass

@overload
def sympify(a: Any, *, strict: bool=False) -> Basic:
    pass

def sympify(a, locals=None, convert_xor=True, strict=False, rational=False, evaluate=None):
    is_sympy = getattr(a, '__sympy__', None)
    if is_sympy is True:
        return a
    elif is_sympy is not None:
        if not strict:
            return a
        else:
            raise SympifyError(a)
    if isinstance(a, CantSympify):
        raise SympifyError(a)
    cls = getattr(a, '__class__', None)
    for superclass in getmro(cls):
        conv = _external_converter.get(superclass)
        if conv is None:
            conv = _sympy_converter.get(superclass)
        if conv is not None:
            return conv(a)
    if cls is type(None):
        if strict:
            raise SympifyError(a)
        else:
            return a
    if evaluate is None:
        evaluate = global_parameters.evaluate
    if _is_numpy_instance(a):
        import numpy as np
        if np.isscalar(a):
            return _convert_numpy_types(a, locals=locals, convert_xor=convert_xor, strict=strict, rational=rational, evaluate=evaluate)
    _sympy_ = getattr(a, '_sympy_', None)
    if _sympy_ is not None:
        return a._sympy_()
    if not strict:
        flat = getattr(a, 'flat', None)
        if flat is not None:
            shape = getattr(a, 'shape', None)
            if shape is not None:
                from sympy.tensor.array import Array
                return Array(a.flat, a.shape)
    if not isinstance(a, str):
        if _is_numpy_instance(a):
            import numpy as np
            assert not isinstance(a, np.number)
            if isinstance(a, np.ndarray):
                if a.ndim == 0:
                    try:
                        return sympify(a.item(), locals=locals, convert_xor=convert_xor, strict=strict, rational=rational, evaluate=evaluate)
                    except SympifyError:
                        pass
        elif hasattr(a, '__float__'):
            return sympify(float(a))
        elif hasattr(a, '__int__'):
            return sympify(int(a))
    if strict:
        raise SympifyError(a)
    if iterable(a):
        try:
            return type(a)([sympify(x, locals=locals, convert_xor=convert_xor, rational=rational, evaluate=evaluate) for x in a])
        except TypeError:
            pass
    if not isinstance(a, str):
        raise SympifyError('cannot sympify object of type %r' % type(a))
    from sympy.parsing.sympy_parser import parse_expr, TokenError, standard_transformations
    from sympy.parsing.sympy_parser import convert_xor as t_convert_xor
    from sympy.parsing.sympy_parser import rationalize as t_rationalize
    transformations = standard_transformations
    if rational:
        transformations += (t_rationalize,)
    if convert_xor:
        transformations += (t_convert_xor,)
    try:
        a = a.replace('\n', '')
        expr = parse_expr(a, local_dict=locals, transformations=transformations, evaluate=evaluate)
    except (TokenError, SyntaxError) as exc:
        raise SympifyError('could not parse %r' % a, exc)
    return expr

def _sympify(a):
    return sympify(a, strict=True)

def kernS(s):
    hit = False
    quoted = '"' in s or "'" in s
    if '(' in s and (not quoted):
        if s.count('(') != s.count(')'):
            raise SympifyError('unmatched left parenthesis')
        s = ''.join(s.split())
        olds = s
        s = s.replace('*(', '* *(')
        s = s.replace('** *', '**')
        target = '-( *('
        s = s.replace('-(', target)
        i = nest = 0
        assert target.endswith('(')
        while True:
            j = s.find(target, i)
            if j == -1:
                break
            j += len(target) - 1
            for j in range(j, len(s)):
                if s[j] == '(':
                    nest += 1
                elif s[j] == ')':
                    nest -= 1
                if nest == 0:
                    break
            s = s[:j] + ')' + s[j:]
            i = j + 2
        if ' ' in s:
            kern = '_'
            while kern in s:
                kern += choice(string.ascii_letters + string.digits)
            s = s.replace(' ', kern)
            hit = kern in s
        else:
            hit = False
    for i in range(2):
        try:
            expr = sympify(s)
            break
        except TypeError:
            if hit:
                s = olds
                hit = False
                continue
            expr = sympify(s)
    if not hit:
        return expr
    from .symbol import Symbol
    rep = {Symbol(kern): 1}

    def _clear(expr):
        if isinstance(expr, (list, tuple, set)):
            return type(expr)([_clear(e) for e in expr])
        if hasattr(expr, 'subs'):
            return expr.subs(rep, hack2=True)
        return expr
    expr = _clear(expr)
    return expr
from .basic import Basic