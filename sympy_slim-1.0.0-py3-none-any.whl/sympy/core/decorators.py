from __future__ import annotations
from typing import TYPE_CHECKING
from functools import wraps
from .sympify import SympifyError, sympify
if TYPE_CHECKING:
    from typing import Callable, TypeVar
    T1 = TypeVar('T1')
    T2 = TypeVar('T2')
    T3 = TypeVar('T3')

def _sympifyit(arg, retval=None) -> Callable[[Callable[[T1, T2], T3]], Callable[[T1, T2], T3]]:

    def deco(func):
        return __sympifyit(func, arg, retval)
    return deco

def __sympifyit(func, arg, retval=None):
    if not func.__code__.co_argcount:
        raise LookupError('func not found')
    assert func.__code__.co_varnames[1] == arg
    if retval is None:

        @wraps(func)
        def __sympifyit_wrapper(a, b):
            return func(a, sympify(b, strict=True))
    else:

        @wraps(func)
        def __sympifyit_wrapper(a, b):
            try:
                if not hasattr(b, '_op_priority'):
                    b = sympify(b, strict=True)
                return func(a, b)
            except SympifyError:
                return retval
    return __sympifyit_wrapper

def call_highest_priority(method_name: str) -> Callable[[Callable[[T1, T2], T3]], Callable[[T1, T2], T3]]:

    def priority_decorator(func: Callable[[T1, T2], T3]) -> Callable[[T1, T2], T3]:

        @wraps(func)
        def binary_op_wrapper(self: T1, other: T2) -> T3:
            if hasattr(other, '_op_priority'):
                if other._op_priority > self._op_priority:
                    f: Callable[[T1], T3] | None = getattr(other, method_name, None)
                    if f is not None:
                        return f(self)
            return func(self, other)
        return binary_op_wrapper
    return priority_decorator

def sympify_method_args(cls: type[T1]) -> type[T1]:
    for attrname, obj in cls.__dict__.items():
        if isinstance(obj, _SympifyWrapper):
            setattr(cls, attrname, obj.make_wrapped(cls))
    return cls

def sympify_return(*args):

    def wrapper(func: Callable[[T1, T2], T3]) -> Callable[[T1, T2], T3]:
        return _SympifyWrapper(func, args)
    return wrapper

class _SympifyWrapper:

    def __init__(self, func, args):
        self.func = func
        self.args = args

    def make_wrapped(self, cls):
        func = self.func
        parameters, retval = self.args
        [(parameter, expectedcls)] = parameters
        if expectedcls == cls.__name__:
            expectedcls = cls
        nargs = func.__code__.co_argcount
        if nargs != 2:
            raise RuntimeError('sympify_return can only be used with 2 argument functions')
        if func.__code__.co_varnames[1] != parameter:
            raise RuntimeError('parameter name mismatch "%s" in %s' % (parameter, func.__name__))

        @wraps(func)
        def _func(self, other):
            if not hasattr(other, '_op_priority'):
                try:
                    other = sympify(other, strict=True)
                except SympifyError:
                    return retval
            if not isinstance(other, expectedcls):
                return retval
            return func(self, other)
        return _func