from __future__ import annotations
from typing import overload, TYPE_CHECKING
from operator import attrgetter
from collections import defaultdict
from sympy.utilities.exceptions import sympy_deprecation_warning
from .sympify import _sympify as _sympify_, sympify
from .basic import Basic
from .cache import cacheit
from .sorting import ordered
from .logic import fuzzy_and
from .parameters import global_parameters
from sympy.utilities.iterables import sift
from sympy.multipledispatch.dispatcher import Dispatcher, ambiguity_register_error_ignore_dup, str_signature, RaiseNotImplementedError
if TYPE_CHECKING:
    from sympy.core.expr import Expr
    from sympy.core.add import Add
    from sympy.core.mul import Mul
    from sympy.logic.boolalg import Boolean, And, Or

class AssocOp(Basic):
    __slots__: tuple[str, ...] = ('is_commutative',)
    _args_type: type[Basic] | None = None

    @cacheit
    def __new__(cls, *args, evaluate=None, _sympify=True):
        if _sympify:
            args = list(map(_sympify_, args))
        typ = cls._args_type
        if typ is not None:
            from .relational import Relational
            if any((isinstance(arg, Relational) for arg in args)):
                raise TypeError('Relational cannot be used in %s' % cls.__name__)
            for arg in args:
                if not isinstance(arg, typ):
                    sympy_deprecation_warning(f'\n\nUsing non-Expr arguments in {cls.__name__} is deprecated (in this case, one of\nthe arguments has type {type(arg).__name__!r}).\n\nIf you really did intend to use a multiplication or addition operation with\nthis object, use the * or + operator instead.\n\n                        ', deprecated_since_version='1.7', active_deprecations_target='non-expr-args-deprecated', stacklevel=4)
        if evaluate is None:
            evaluate = global_parameters.evaluate
        if not evaluate:
            obj = cls._from_args(args)
            obj = cls._exec_constructor_postprocessors(obj)
            return obj
        args = [a for a in args if a is not cls.identity]
        if len(args) == 0:
            return cls.identity
        if len(args) == 1:
            return args[0]
        c_part, nc_part, order_symbols = cls.flatten(args)
        is_commutative = not nc_part
        obj = cls._from_args(c_part + nc_part, is_commutative)
        obj = cls._exec_constructor_postprocessors(obj)
        if order_symbols is not None:
            from sympy.series.order import Order
            return Order(obj, *order_symbols)
        return obj

    @classmethod
    def _from_args(cls, args, is_commutative=None):
        if len(args) == 0:
            return cls.identity
        elif len(args) == 1:
            return args[0]
        obj = super().__new__(cls, *args)
        if is_commutative is None:
            is_commutative = fuzzy_and((a.is_commutative for a in args))
        obj.is_commutative = is_commutative
        return obj

    def _new_rawargs(self, *args, reeval=True, **kwargs):
        if reeval and self.is_commutative is False:
            is_commutative = None
        else:
            is_commutative = self.is_commutative
        return self._from_args(args, is_commutative)

    @classmethod
    def flatten(cls, seq):
        new_seq = []
        while seq:
            o = seq.pop()
            if o.__class__ is cls:
                seq.extend(o.args)
            else:
                new_seq.append(o)
        new_seq.reverse()
        return ([], new_seq, None)

    def _matches_commutative(self, expr, repl_dict=None, old=False):
        from .function import _coeff_isneg
        from .expr import Expr
        if isinstance(self, Expr) and (not isinstance(expr, Expr)):
            return None
        if repl_dict is None:
            repl_dict = {}
        if self == expr:
            return repl_dict
        d = self._matches_simple(expr, repl_dict)
        if d is not None:
            return d
        from .function import WildFunction
        from .symbol import Wild
        wild_part, exact_part = sift(self.args, lambda p: p.has(Wild, WildFunction) and (not expr.has(p)), binary=True)
        if not exact_part:
            wild_part = list(ordered(wild_part))
            if self.is_Add:
                wild_part = sorted(wild_part, key=lambda x: x.args[0] if x.is_Mul and x.args[0].is_Number else 0)
        else:
            exact = self._new_rawargs(*exact_part)
            free = expr.free_symbols
            if free and exact.free_symbols - free:
                return None
            newexpr = self._combine_inverse(expr, exact)
            if not old and (expr.is_Add or expr.is_Mul):
                check = newexpr
                if _coeff_isneg(check):
                    check = -check
                if check.count_ops() > expr.count_ops():
                    return None
            newpattern = self._new_rawargs(*wild_part)
            return newpattern.matches(newexpr, repl_dict)
        i = 0
        saw = set()
        while expr not in saw:
            saw.add(expr)
            args = tuple(ordered(self.make_args(expr)))
            if self.is_Add and expr.is_Add:
                args = tuple(sorted(args, key=lambda x: x.args[0] if x.is_Mul and x.args[0].is_Number else 0))
            expr_list = (self.identity,) + args
            for last_op in reversed(expr_list):
                for w in reversed(wild_part):
                    d1 = w.matches(last_op, repl_dict)
                    if d1 is not None:
                        d2 = self.xreplace(d1).matches(expr, d1)
                        if d2 is not None:
                            return d2
            if i == 0:
                if self.is_Mul:
                    if expr.is_Pow and expr.exp.is_Integer:
                        from .mul import Mul
                        if expr.exp > 0:
                            expr = Mul(*[expr.base, expr.base ** (expr.exp - 1)], evaluate=False)
                        else:
                            expr = Mul(*[1 / expr.base, expr.base ** (expr.exp + 1)], evaluate=False)
                        i += 1
                        continue
                elif self.is_Add:
                    c, e = expr.as_coeff_Mul()
                    if abs(c) > 1:
                        from .add import Add
                        if c > 0:
                            expr = Add(*[e, (c - 1) * e], evaluate=False)
                        else:
                            expr = Add(*[-e, (c + 1) * e], evaluate=False)
                        i += 1
                        continue
                    from sympy.simplify.radsimp import collect
                    was = expr
                    did = set()
                    for w in reversed(wild_part):
                        c, w = w.as_coeff_mul(Wild)
                        free = c.free_symbols - did
                        if free:
                            did.update(free)
                            expr = collect(expr, free)
                    if expr != was:
                        i += 0
                        continue
                break
        return

    def _has_matcher(self):

        def _ncsplit(expr):
            cpart, ncpart = sift(expr.args, lambda arg: arg.is_commutative is True, binary=True)
            return (set(cpart), ncpart)
        c, nc = _ncsplit(self)
        cls = self.__class__

        def is_in(expr):
            if isinstance(expr, cls):
                if expr == self:
                    return True
                _c, _nc = _ncsplit(expr)
                if c & _c == c:
                    if not nc:
                        return True
                    elif len(nc) <= len(_nc):
                        for i in range(len(_nc) - len(nc) + 1):
                            if _nc[i:i + len(nc)] == nc:
                                return True
            return False
        return is_in

    def _eval_evalf(self, prec):
        from .add import Add
        from .mul import Mul
        from .symbol import Symbol
        from .function import AppliedUndef
        if isinstance(self, (Mul, Add)):
            x, tail = self.as_independent(Symbol, AppliedUndef)
            if not (tail is self.identity or (isinstance(x, AssocOp) and x.is_Function) or (x is self.identity and isinstance(tail, AssocOp))):
                x = x._evalf(prec) if x is not self.identity else self.identity
                args = []
                tail_args = tuple(self.func.make_args(tail))
                for a in tail_args:
                    newa = a._eval_evalf(prec)
                    if newa is None:
                        args.append(a)
                    else:
                        args.append(newa)
                return self.func(x, *args)
        args = []
        for a in self.args:
            newa = a._eval_evalf(prec)
            if newa is None:
                args.append(a)
            else:
                args.append(newa)
        return self.func(*args)

    @overload
    @classmethod
    def make_args(cls: type[Add], expr: Expr) -> tuple[Expr, ...]:
        pass

    @overload
    @classmethod
    def make_args(cls: type[Mul], expr: Expr) -> tuple[Expr, ...]:
        pass

    @overload
    @classmethod
    def make_args(cls: type[And], expr: Boolean) -> tuple[Boolean, ...]:
        pass

    @overload
    @classmethod
    def make_args(cls: type[Or], expr: Boolean) -> tuple[Boolean, ...]:
        pass

    @classmethod
    def make_args(cls: type[Basic], expr: Basic) -> tuple[Basic, ...]:
        if isinstance(expr, cls):
            return expr.args
        else:
            return (sympify(expr),)

    def doit(self, **hints):
        if hints.get('deep', True):
            terms = [term.doit(**hints) for term in self.args]
        else:
            terms = self.args
        return self.func(*terms, evaluate=True)

class ShortCircuit(Exception):
    pass

class LatticeOp(AssocOp):
    is_commutative = True

    def __new__(cls, *args, evaluate=None, **options):
        args = (_sympify_(arg) for arg in args)
        if evaluate is None:
            evaluate = global_parameters.evaluate
        if not evaluate:
            obj = super().__new__(cls, *args, evaluate=False, **options)
            obj._argset = frozenset(args)
            return obj
        try:
            _args = frozenset(cls._new_args_filter(args))
        except ShortCircuit:
            return sympify(cls.zero)
        if not _args:
            return sympify(cls.identity)
        elif len(_args) == 1:
            return set(_args).pop()
        else:
            obj = super(AssocOp, cls).__new__(cls, *ordered(_args))
            obj._argset = _args
            return obj

    @classmethod
    def _new_args_filter(cls, arg_sequence, call_cls=None):
        ncls = call_cls or cls
        for arg in arg_sequence:
            if arg == ncls.zero:
                raise ShortCircuit(arg)
            elif arg == ncls.identity:
                continue
            elif arg.func == ncls:
                yield from arg.args
            else:
                yield arg

    @classmethod
    def make_args(cls, expr):
        if isinstance(expr, cls):
            return expr._argset
        else:
            return frozenset([sympify(expr)])

class AssocOpDispatcher:

    def __init__(self, name, doc=None):
        self.name = name
        self.doc = doc
        self.handlerattr = '_%s_handler' % name
        self._handlergetter = attrgetter(self.handlerattr)
        self._dispatcher = Dispatcher(name)

    def __repr__(self):
        return '<dispatched %s>' % self.name

    def register_handlerclass(self, classes, typ, on_ambiguity=ambiguity_register_error_ignore_dup):
        if not len(classes) == 2:
            raise RuntimeError('Only binary dispatch is supported, but got %s types: <%s>.' % (len(classes), str_signature(classes)))
        if len(set(classes)) == 1:
            raise RuntimeError('Duplicate types <%s> cannot be dispatched.' % str_signature(classes))
        self._dispatcher.add(tuple(classes), typ, on_ambiguity=on_ambiguity)
        self._dispatcher.add(tuple(reversed(classes)), typ, on_ambiguity=on_ambiguity)

    @cacheit
    def __call__(self, *args, _sympify=True, **kwargs):
        if _sympify:
            args = tuple(map(_sympify_, args))
        handlers = frozenset(map(self._handlergetter, args))
        return self.dispatch(handlers)(*args, _sympify=False, **kwargs)

    @cacheit
    def dispatch(self, handlers):
        if len(handlers) == 1:
            h, = handlers
            if not isinstance(h, type):
                raise RuntimeError('Handler {!r} is not a type.'.format(h))
            return h
        for i, typ in enumerate(handlers):
            if not isinstance(typ, type):
                raise RuntimeError('Handler {!r} is not a type.'.format(typ))
            if i == 0:
                handler = typ
            else:
                prev_handler = handler
                handler = self._dispatcher.dispatch(prev_handler, typ)
                if not isinstance(handler, type):
                    raise RuntimeError('Dispatcher for {!r} and {!r} must return a type, but got {!r}'.format(prev_handler, typ, handler))
        return handler

    @property
    def __doc__(self):
        docs = ['Multiply dispatched associative operator: %s' % self.name, 'Note that support for this is experimental, see the docs for :class:`AssocOpDispatcher` for details']
        if self.doc:
            docs.append(self.doc)
        s = 'Registered handler classes\n'
        s += '=' * len(s)
        docs.append(s)
        amb_sigs = []
        typ_sigs = defaultdict(list)
        for sigs in self._dispatcher.ordering[::-1]:
            key = self._dispatcher.funcs[sigs]
            typ_sigs[key].append(sigs)
        for typ, sigs in typ_sigs.items():
            sigs_str = ', '.join(('<%s>' % str_signature(sig) for sig in sigs))
            if isinstance(typ, RaiseNotImplementedError):
                amb_sigs.append(sigs_str)
                continue
            s = 'Inputs: %s\n' % sigs_str
            s += '-' * len(s) + '\n'
            s += typ.__name__
            docs.append(s)
        if amb_sigs:
            s = 'Ambiguous handler classes\n'
            s += '=' * len(s)
            docs.append(s)
            s = '\n'.join(amb_sigs)
            docs.append(s)
        return '\n\n'.join(docs)