from __future__ import annotations
from typing import TYPE_CHECKING, overload
from .core import Registry
from .sympify import sympify
if TYPE_CHECKING:
    from typing import Any, TypeVar
    from sympy.core.numbers import Zero as _Zero, One as _One, NegativeOne as _NegativeOne, Half as _Half, ImaginaryUnit as _ImaginaryUnit, Exp1 as _Exp1, Pi as _Pi, GoldenRatio as _GoldenRatio, TribonacciConstant as _TribonacciConstant, EulerGamma as _EulerGamma, Catalan as _Catalan, Infinity as _Infinity, NegativeInfinity as _NegativeInfinity, ComplexInfinity as _ComplexInfinity, NaN as _NaN
    from sympy.logic.boolalg import BooleanTrue as _BooleanTrue, BooleanFalse as _BooleanFalse
    from .basic import Basic
    from .expr import Expr
    from .numbers import Float, Integer
    Tbasic = TypeVar('Tbasic', bound=Basic)

class SingletonRegistry(Registry):
    __slots__ = ()
    Zero: _Zero
    One: _One
    NegativeOne: _NegativeOne
    Half: _Half
    ImaginaryUnit: _ImaginaryUnit
    Exp1: _Exp1
    Pi: _Pi
    GoldenRatio: _GoldenRatio
    TribonacciConstant: _TribonacciConstant
    EulerGamma: _EulerGamma
    Catalan: _Catalan
    Infinity: _Infinity
    NegativeInfinity: _NegativeInfinity
    ComplexInfinity: _ComplexInfinity
    NaN: _NaN
    true: _BooleanTrue
    false: _BooleanFalse

    @overload
    def __call__(self, a: int, *, strict: bool=False) -> Integer:
        pass

    @overload
    def __call__(self, a: float, *, strict: bool=False) -> Float:
        pass

    @overload
    def __call__(self, a: Expr | complex, *, strict: bool=False) -> Expr:
        pass

    @overload
    def __call__(self, a: Tbasic, *, strict: bool=False) -> Tbasic:
        pass

    @overload
    def __call__(self, a: Any, *, strict: bool=False) -> Basic:
        pass

    def __call__(self, a, locals=None, convert_xor=True, strict=False, rational=False, evaluate=None):
        return sympify(a, locals=locals, convert_xor=convert_xor, strict=strict, rational=rational, evaluate=evaluate)

    def __init__(self):
        self._classes_to_install = {}

    def register(self, cls):
        if hasattr(self, cls.__name__):
            delattr(self, cls.__name__)
        self._classes_to_install[cls.__name__] = cls

    def __getattr__(self, name):
        if name not in self._classes_to_install:
            raise AttributeError("Attribute '%s' was not installed on SymPy registry %s" % (name, self))
        class_to_install = self._classes_to_install[name]
        value_to_install = class_to_install()
        self.__setattr__(name, value_to_install)
        del self._classes_to_install[name]
        return value_to_install

    def __repr__(self):
        return 'S'
S = SingletonRegistry()

class Singleton(type):

    def __init__(cls, *args, **kwargs):
        cls._instance = obj = Basic.__new__(cls)
        cls.__new__ = lambda cls: obj
        cls.__getnewargs__ = lambda obj: ()
        cls.__getstate__ = lambda obj: None
        S.register(cls)
from .basic import Basic