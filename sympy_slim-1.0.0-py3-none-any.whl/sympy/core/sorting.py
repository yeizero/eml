from __future__ import annotations
from collections import defaultdict
from .sympify import sympify, SympifyError
from sympy.utilities.iterables import iterable, uniq
__all__ = ['default_sort_key', 'ordered']

def default_sort_key(item, order=None):
    from .basic import Basic
    from .singleton import S
    if isinstance(item, Basic):
        return item.sort_key(order=order)
    if iterable(item, exclude=str):
        if isinstance(item, dict):
            args = item.items()
            unordered = True
        elif isinstance(item, set):
            args = item
            unordered = True
        else:
            args = list(item)
            unordered = False
        args = [default_sort_key(arg, order=order) for arg in args]
        if unordered:
            args = sorted(args)
        cls_index, args = (10, (len(args), tuple(args)))
    else:
        if not isinstance(item, str):
            try:
                item = sympify(item, strict=True)
            except SympifyError:
                pass
            else:
                if isinstance(item, Basic):
                    return default_sort_key(item)
        cls_index, args = (0, (1, (str(item),)))
    return ((cls_index, 0, item.__class__.__name__), args, S.One.sort_key(), S.One)

def _node_count(e):
    if e.is_Float:
        return 0.5
    return 1 + sum(map(_node_count, e.args))

def _nodes(e):
    from .basic import Basic
    from .function import Derivative
    if isinstance(e, Basic):
        if isinstance(e, Derivative):
            return _nodes(e.expr) + sum((i[1] if i[1].is_Number else _nodes(i[1]) for i in e.variable_count))
        return _node_count(e)
    elif iterable(e):
        return 1 + sum((_nodes(ei) for ei in e))
    elif isinstance(e, dict):
        return 1 + sum((_nodes(k) + _nodes(v) for k, v in e.items()))
    else:
        return 1

def ordered(seq, keys=None, default=True, warn=False):
    d = defaultdict(list)
    if keys:
        if isinstance(keys, (list, tuple)):
            keys = list(keys)
            f = keys.pop(0)
        else:
            f = keys
            keys = []
        for a in seq:
            d[f(a)].append(a)
    else:
        if not default:
            raise ValueError('if default=False then keys must be provided')
        d[None].extend(seq)
    for k, value in sorted(d.items()):
        if len(value) > 1:
            if keys:
                value = ordered(value, keys, default, warn)
            elif default:
                value = ordered(value, (_nodes, default_sort_key), default=False, warn=warn)
            elif warn:
                u = list(uniq(value))
                if len(u) > 1:
                    raise ValueError('not enough keys to break ties: %s' % u)
        yield from value