from __future__ import annotations
from typing import Callable

class BaseCoreError(Exception):
    pass

class NonCommutativeExpression(BaseCoreError):
    pass

class LazyExceptionMessage:
    callback: Callable[[], str]

    def __init__(self, callback: Callable[[], str]):
        self.callback = callback

    def __str__(self):
        return self.callback()