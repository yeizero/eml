from __future__ import annotations
from typing import TYPE_CHECKING, overload, Literal
from collections.abc import Iterable, Mapping
from functools import reduce
import re
from .sympify import sympify, _sympify
from .basic import Basic, Atom
from .singleton import S
from .evalf import EvalfMixin, pure_complex, DEFAULT_MAXPREC
from .decorators import call_highest_priority, sympify_method_args, sympify_return
from .cache import cacheit
from .logic import fuzzy_or, fuzzy_not
from .intfunc import mod_inverse
from .sorting import default_sort_key
from .kind import NumberKind
from sympy.utilities.exceptions import sympy_deprecation_warning
from sympy.utilities.misc import as_int, func_name, filldedent
from sympy.utilities.iterables import has_variety, _sift_true_false
from sympy.external.mpmath import prec_to_dps, giant_steps as _giant_steps, mpf_ln
if TYPE_CHECKING:
    from typing import Any, Hashable
    from typing_extensions import Self
    from .numbers import Number
from collections import defaultdict

def _corem(eq, c):
    co = []
    non = []
    for i in Add.make_args(eq):
        ci = i.coeff(c)
        if not ci:
            non.append(i)
        else:
            co.append(ci)
    return (Add(*co), Add(*non))

@sympify_method_args
class Expr(Basic, EvalfMixin):
    __slots__: tuple[str, ...] = ()
    if TYPE_CHECKING:

        def __new__(cls, *args: Basic) -> Self:
            pass

        @overload
        def subs(self, arg1: Mapping[Basic | complex, Expr | complex], arg2: None=None) -> Expr:
            pass

        @overload
        def subs(self, arg1: Iterable[tuple[Basic | complex, Expr | complex]], arg2: None=None, **kwargs: Any) -> Expr:
            pass

        @overload
        def subs(self, arg1: Expr | complex, arg2: Expr | complex) -> Expr:
            pass

        @overload
        def subs(self, arg1: Mapping[Basic | complex, Basic | complex], arg2: None=None, **kwargs: Any) -> Basic:
            pass

        @overload
        def subs(self, arg1: Iterable[tuple[Basic | complex, Basic | complex]], arg2: None=None, **kwargs: Any) -> Basic:
            pass

        @overload
        def subs(self, arg1: Basic | complex, arg2: Basic | complex, **kwargs: Any) -> Basic:
            pass

        def subs(self, arg1: Mapping[Basic | complex, Basic | complex] | Basic | complex, arg2: Basic | complex | None=None, **kwargs: Any) -> Basic:
            pass

        def simplify(self, **kwargs) -> Expr:
            pass

        def evalf(self, n: int | None=15, subs: dict[Basic, Basic | float] | None=None, maxn: int=100, chop: bool | int=False, strict: bool=False, quad: str | None=None, verbose: bool=False) -> Expr:
            pass
        n = evalf
    is_scalar = True

    @property
    def is_hermitian(self):
        if self.is_real:
            return True
        if callable(getattr(self, '_eval_is_hermitian', None)):
            return self._eval_is_hermitian()
        return None

    @property
    def is_antihermitian(self):
        if self.is_imaginary or self.is_zero:
            return True
        if callable(getattr(self, '_eval_is_antihermitian', None)):
            return self._eval_is_antihermitian()
        return None

    @property
    def _diff_wrt(self) -> bool:
        return False

    @cacheit
    def sort_key(self, order=None):
        coeff, expr = self.as_coeff_Mul()
        if expr.is_Pow:
            base, exp = expr.as_base_exp()
            if base is S.Exp1:
                base, exp = (Function('exp')(exp), S.One)
            expr = base
        else:
            exp = S.One
        if expr.is_Dummy:
            args = (expr.sort_key(),)
        elif expr.is_Atom:
            args = (str(expr),)
        else:
            if expr.is_Add:
                args = expr.as_ordered_terms(order=order)
            elif expr.is_Mul:
                args = expr.as_ordered_factors(order=order)
            else:
                args = expr.args
            args = tuple([default_sort_key(arg, order=order) for arg in args])
        args = (len(args), tuple(args))
        exp = exp.sort_key(order=order)
        return (expr.class_key(), args, exp, coeff)

    def _hashable_content(self) -> tuple[Basic, ...] | tuple[Hashable, ...]:
        return self._args
    _op_priority = 10.0

    @property
    def _add_handler(self):
        return Add

    @property
    def _mul_handler(self):
        return Mul

    def __pos__(self) -> Expr:
        return self

    def __neg__(self) -> Expr:
        c = self.is_commutative
        return Mul._from_args((S.NegativeOne, self), c)

    def __abs__(self) -> Expr:
        from sympy.functions.elementary.complexes import Abs
        return Abs(self)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__radd__')
    def __add__(self, other: complex) -> Expr:
        return Add(self, other)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__add__')
    def __radd__(self, other: Expr | complex) -> Expr:
        return Add(other, self)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__rsub__')
    def __sub__(self, other: complex) -> Expr:
        return Add(self, -other)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__sub__')
    def __rsub__(self, other: Expr | complex) -> Expr:
        return Add(other, -self)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__rmul__')
    def __mul__(self, other: complex) -> Expr:
        return Mul(self, other)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__mul__')
    def __rmul__(self, other: Expr | complex) -> Expr:
        return Mul(other, self)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__rpow__')
    def _pow(self, other):
        return Pow(self, other)

    def __pow__(self, other, mod=None) -> Expr:
        power = self._pow(other)
        if mod is None:
            return power
        else:
            try:
                return power % mod
            except TypeError:
                return NotImplemented

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__pow__')
    def __rpow__(self, other) -> Expr:
        return Pow(other, self)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__rtruediv__')
    def __truediv__(self, other) -> Expr:
        denom = Pow(other, S.NegativeOne)
        if self is S.One:
            return denom
        else:
            return Mul(self, denom)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__truediv__')
    def __rtruediv__(self, other) -> Expr:
        denom = Pow(self, S.NegativeOne)
        if other is S.One:
            return denom
        else:
            return Mul(other, denom)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__rmod__')
    def __mod__(self, other) -> Expr:
        return Mod(self, other)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__mod__')
    def __rmod__(self, other) -> Expr:
        return Mod(other, self)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__rfloordiv__')
    def __floordiv__(self, other) -> Expr:
        from sympy.functions.elementary.integers import floor
        return floor(self / other)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__floordiv__')
    def __rfloordiv__(self, other) -> Expr:
        from sympy.functions.elementary.integers import floor
        return floor(other / self)

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__rdivmod__')
    def __divmod__(self, other) -> tuple[Expr, Expr]:
        from sympy.functions.elementary.integers import floor
        return (floor(self / other), Mod(self, other))

    @sympify_return([('other', 'Expr')], NotImplemented)
    @call_highest_priority('__divmod__')
    def __rdivmod__(self, other) -> tuple[Expr, Expr]:
        from sympy.functions.elementary.integers import floor
        return (floor(other / self), Mod(other, self))

    def __int__(self) -> int:
        if not self.is_number:
            raise TypeError('Cannot convert symbols to int')
        if not self.is_comparable:
            raise TypeError('Cannot convert non-comparable expression to int')
        r = self.round(2)
        if not r.is_Number:
            raise TypeError('Cannot convert complex to int')
        if r in (S.NaN, S.Infinity, S.NegativeInfinity):
            raise TypeError('Cannot convert %s to int' % r)
        i = int(r)
        if not i:
            return i
        if int_valued(r):
            r = self.round(15)
            i = int(r)
        if int_valued(r):
            if (self > i) is S.true:
                return i
            if (self < i) is S.true:
                return i - 1
            ok = self.equals(i)
            if ok is None:
                raise TypeError('cannot compute int value accurately')
            if ok:
                return i
            return i - (1 if i > 0 else -1)
        return i

    def __float__(self) -> float:
        result = self.evalf()
        if result.is_Number:
            return float(result)
        if result.is_number and result.as_real_imag()[1]:
            raise TypeError('Cannot convert complex to float')
        raise TypeError('Cannot convert expression to float')

    def __complex__(self) -> complex:
        result = self.evalf()
        re, im = result.as_real_imag()
        return complex(float(re), float(im))

    @sympify_return([('other', 'Expr')], NotImplemented)
    def __ge__(self, other):
        from .relational import GreaterThan
        return GreaterThan(self, other)

    @sympify_return([('other', 'Expr')], NotImplemented)
    def __le__(self, other):
        from .relational import LessThan
        return LessThan(self, other)

    @sympify_return([('other', 'Expr')], NotImplemented)
    def __gt__(self, other):
        from .relational import StrictGreaterThan
        return StrictGreaterThan(self, other)

    @sympify_return([('other', 'Expr')], NotImplemented)
    def __lt__(self, other):
        from .relational import StrictLessThan
        return StrictLessThan(self, other)

    def __trunc__(self):
        if not self.is_number:
            raise TypeError('Cannot truncate symbols and expressions')
        else:
            return Integer(self)

    def __format__(self, format_spec: str):
        if self.is_number:
            mt = re.match('\\+?\\d*\\.(\\d+)f', format_spec)
            if mt:
                prec = int(mt.group(1))
                rounded = self.round(prec)
                if rounded.is_Integer:
                    return format(int(rounded), format_spec)
                if rounded.is_Float:
                    return format(rounded, format_spec)
        return super().__format__(format_spec)

    @staticmethod
    def _from_mpmath(x, prec) -> Expr:
        if hasattr(x, '_mpf_'):
            return Float._new(x._mpf_, prec)
        elif hasattr(x, '_mpc_'):
            re, im = x._mpc_
            re = Float._new(re, prec)
            im = Float._new(im, prec) * S.ImaginaryUnit
            return re + im
        else:
            raise TypeError('expected mpmath number (mpf or mpc)')

    @property
    def is_number(self):
        return all((obj.is_number for obj in self.args))

    def _eval_is_comparable(self):
        is_extended_real = self.is_extended_real
        if is_extended_real is False:
            return False
        if not self.is_number:
            return False
        n, i = self.as_real_imag()
        if not n.is_Number:
            n = n.evalf(2)
            if not n.is_Number:
                return False
        if not i.is_Number:
            i = i.evalf(2)
            if not i.is_Number:
                return False
        if i:
            return False
        else:
            return n._prec != 1

    def _random(self, n=None, re_min=-1, im_min=-1, re_max=1, im_max=1):
        free = self.free_symbols
        prec = 1
        if free:
            from sympy.core.random import random_complex_number
            a, c, b, d = (re_min, re_max, im_min, im_max)
            reps = dict(list(zip(free, [random_complex_number(a, b, c, d, rational=True) for zi in free])))
            try:
                nmag = abs(self.evalf(2, subs=reps))
            except (ValueError, TypeError):
                return None
        else:
            reps = {}
            nmag = abs(self.evalf(2))
        if not hasattr(nmag, '_prec'):
            return None
        if nmag._prec == 1:
            for prec in _giant_steps(2, DEFAULT_MAXPREC):
                nmag = abs(self.evalf(prec, subs=reps))
                if nmag._prec != 1:
                    break
        if nmag._prec != 1:
            if n is None:
                n = max(prec, 15)
            return self.evalf(n, subs=reps)
        return None

    def is_constant(self, *wrt, **flags):
        simplify = flags.get('simplify', True)
        if self.is_number:
            return True
        free = self.free_symbols
        if not free:
            return True
        wrt = set(wrt)
        if wrt and (not wrt & free):
            return True
        wrt = wrt or free
        expr = self
        if simplify:
            expr = expr.simplify()
        if expr.is_zero:
            return True
        wrt_number = {sym for sym in wrt if sym.kind is NumberKind}
        failing_number = None
        if wrt_number == free:
            try:
                a = expr.subs(list(zip(free, [0] * len(free))), simultaneous=True)
                if a is S.NaN:
                    a = expr._random(None, 0, 0, 0, 0)
            except ZeroDivisionError:
                a = None
            if a is not None and a is not S.NaN:
                try:
                    b = expr.subs(list(zip(free, [1] * len(free))), simultaneous=True)
                    if b is S.NaN:
                        b = expr._random(None, 1, 0, 1, 0)
                except ZeroDivisionError:
                    b = None
                if b is not None and b is not S.NaN and (b.equals(a) is False):
                    return False
                b = expr._random(None, -1, 0, 1, 0)
                if b is not None and b is not S.NaN and (b.equals(a) is False):
                    return False
                b = expr._random()
                if b is not None and b is not S.NaN:
                    if b.equals(a) is False:
                        return False
                    failing_number = a if a.is_number else b
        for w in wrt_number:
            deriv = expr.diff(w)
            if simplify:
                deriv = deriv.simplify()
            if deriv != 0:
                if not pure_complex(deriv, or_real=True):
                    if flags.get('failing_number', False):
                        return failing_number
                return False
        from sympy.solvers.solvers import denoms
        return fuzzy_not(fuzzy_or((den.is_zero for den in denoms(self))))

    def equals(self, other, failing_expression=False):
        from sympy.simplify.simplify import nsimplify, simplify
        from sympy.solvers.solvers import solve
        from sympy.polys.polyerrors import NotAlgebraic
        from sympy.polys.numberfields import minimal_polynomial
        other = sympify(other)
        if not isinstance(other, Expr):
            return False
        if self == other:
            return True
        diff = factor_terms(simplify(self - other), radical=True)
        if not diff:
            return True
        if not diff.has(Add, Mod):
            return False
        factors = diff.as_coeff_mul()[1]
        if len(factors) > 1:
            fac_zero = [fac.equals(0) for fac in factors]
            if None not in fac_zero:
                return any(fac_zero)
        constant = diff.is_constant(simplify=False, failing_number=True)
        if constant is False:
            return False
        if not diff.is_number:
            if constant is None:
                return
        if constant is True:
            ndiff = diff._random()
            if ndiff and ndiff.is_comparable:
                return False
        if diff.is_number:
            surds = [s for s in diff.atoms(Pow) if s.args[0].is_Integer]
            surds.sort(key=lambda x: -x.args[0])
            for s in surds:
                try:
                    sol = solve(diff, s, simplify=False)
                    if sol:
                        if s in sol:
                            return True
                        if all((si.is_Integer for si in sol)):
                            return False
                        if all((i.is_algebraic is False for i in sol)):
                            return False
                        if any((si in surds for si in sol)):
                            return False
                        if any((nsimplify(s - si) == 0 and simplify(s - si) == 0 for si in sol)):
                            return True
                        if s.is_real:
                            if any((nsimplify(si, [s]) == s and simplify(si) == s for si in sol)):
                                return True
                except NotImplementedError:
                    pass
            if True:
                try:
                    mp = minimal_polynomial(diff)
                    if mp.is_Symbol:
                        return True
                    return False
                except (NotAlgebraic, NotImplementedError):
                    pass
        if constant not in (True, None) and constant != 0:
            return False
        if failing_expression:
            return diff
        return None

    def _eval_is_extended_positive_negative(self, positive):
        from sympy.polys.numberfields import minimal_polynomial
        from sympy.polys.polyerrors import NotAlgebraic
        if self.is_number:
            try:
                n2 = self._eval_evalf(2)
            except ValueError:
                return None
            if n2 is None:
                return None
            if getattr(n2, '_prec', 1) == 1:
                return None
            if n2 is S.NaN:
                return None
            f = self.evalf(2)
            if f.is_Float:
                match = (f, S.Zero)
            else:
                match = pure_complex(f)
            if match is None:
                return False
            r, i = match
            if not (i.is_Number and r.is_Number):
                return False
            if r._prec != 1 and i._prec != 1:
                return bool(not i and (r > 0 if positive else r < 0))
            elif r._prec == 1 and (not i or i._prec == 1) and self._eval_is_algebraic() and (not self.has(Function)):
                try:
                    if minimal_polynomial(self).is_Symbol:
                        return False
                except (NotAlgebraic, NotImplementedError):
                    pass

    def _eval_is_extended_positive(self):
        return self._eval_is_extended_positive_negative(positive=True)

    def _eval_is_extended_negative(self):
        return self._eval_is_extended_positive_negative(positive=False)

    def _eval_interval(self, x, a, b):
        from sympy.calculus.accumulationbounds import AccumBounds
        from sympy.functions.elementary.exponential import log
        from sympy.series.limits import limit, Limit
        from sympy.sets.sets import Interval
        from sympy.solvers.solveset import solveset
        if a is None and b is None:
            raise ValueError('Both interval ends cannot be None.')

        def _eval_endpoint(left):
            c = a if left else b
            if c is None:
                return S.Zero
            else:
                C = self.subs(x, c)
                if C.has(S.NaN, S.Infinity, S.NegativeInfinity, S.ComplexInfinity, AccumBounds):
                    if (a < b) != False:
                        C = limit(self, x, c, '+' if left else '-')
                    else:
                        C = limit(self, x, c, '-' if left else '+')
                    if isinstance(C, Limit):
                        raise NotImplementedError('Could not compute limit')
            return C
        if a == b:
            return S.Zero
        A = _eval_endpoint(left=True)
        if A is S.NaN:
            return A
        B = _eval_endpoint(left=False)
        if (a and b) is None:
            return B - A
        value = B - A
        if a.is_comparable and b.is_comparable:
            if a < b:
                domain = Interval(a, b)
            else:
                domain = Interval(b, a)
            singularities = solveset(self.cancel().as_numer_denom()[1], x, domain=domain)
            for logterm in self.atoms(log):
                singularities = singularities | solveset(logterm.args[0], x, domain=domain)
            try:
                for s in singularities:
                    if value is S.NaN:
                        break
                    if not s.is_comparable:
                        continue
                    if (a < s) == (s < b) == True:
                        value += -limit(self, x, s, '+') + limit(self, x, s, '-')
                    elif (b < s) == (s < a) == True:
                        value += limit(self, x, s, '+') - limit(self, x, s, '-')
            except TypeError:
                pass
        return value

    def _eval_power(self, expt) -> Expr | None:
        return None

    def _eval_conjugate(self):
        if self.is_extended_real:
            return self
        elif self.is_imaginary:
            return -self

    def conjugate(self):
        from sympy.functions.elementary.complexes import conjugate as c
        return c(self)

    def dir(self, x, cdir):
        if self.is_zero:
            return S.Zero
        from sympy.functions.elementary.exponential import log
        minexp = S.Zero
        arg = self
        while arg:
            minexp += S.One
            arg = arg.diff(x)
            coeff = arg.subs(x, 0)
            if coeff is S.NaN:
                coeff = arg.limit(x, 0)
            if coeff is S.ComplexInfinity:
                try:
                    coeff, _ = arg.leadterm(x)
                    if coeff.has(log(x)):
                        raise ValueError()
                except ValueError:
                    coeff = arg.limit(x, 0)
            if coeff != S.Zero:
                break
        return coeff * cdir ** minexp

    def _eval_transpose(self):
        from sympy.functions.elementary.complexes import conjugate
        if self.is_commutative:
            return self
        elif self.is_hermitian:
            return conjugate(self)
        elif self.is_antihermitian:
            return -conjugate(self)

    def transpose(self):
        from sympy.functions.elementary.complexes import transpose
        return transpose(self)

    def _eval_adjoint(self):
        from sympy.functions.elementary.complexes import conjugate, transpose
        if self.is_hermitian:
            return self
        elif self.is_antihermitian:
            return -self
        obj = self._eval_conjugate()
        if obj is not None:
            return transpose(obj)
        obj = self._eval_transpose()
        if obj is not None:
            return conjugate(obj)

    def adjoint(self):
        from sympy.functions.elementary.complexes import adjoint
        return adjoint(self)

    @classmethod
    def _parse_order(cls, order):
        from sympy.polys.orderings import monomial_key
        startswith = getattr(order, 'startswith', None)
        if startswith is None:
            reverse = False
        else:
            reverse = startswith('rev-')
            if reverse:
                order = order[4:]
        monom_key = monomial_key(order)

        def neg(monom):
            return tuple([neg(m) if isinstance(m, tuple) else -m for m in monom])

        def key(term):
            _, ((re, im), monom, ncpart) = term
            monom = neg(monom_key(monom))
            ncpart = tuple([e.sort_key(order=order) for e in ncpart])
            coeff = ((bool(im), im), (re, im))
            return (monom, ncpart, coeff)
        return (key, reverse)

    def as_ordered_factors(self, order=None):
        return [self]

    def as_poly(self, *gens, **args):
        from sympy.polys.polyerrors import PolynomialError, GeneratorsNeeded, CoercionFailed
        from sympy.polys.polytools import Poly
        try:
            poly = Poly(self, *gens, **args)
            if not poly.is_Poly:
                return None
            else:
                return poly
        except (PolynomialError, GeneratorsNeeded, CoercionFailed):
            return None

    def as_ordered_terms(self, order=None, data: Literal[False]=False) -> list[Expr]:
        from .numbers import Number, NumberSymbol
        if order is None and self.is_Add:
            key = lambda x: not isinstance(x, (Number, NumberSymbol))
            add_args = sorted(Add.make_args(self), key=key)
            if len(add_args) == 2 and isinstance(add_args[0], (Number, NumberSymbol)) and isinstance(add_args[1], Mul):
                mul_args = sorted(Mul.make_args(add_args[1]), key=key)
                if len(mul_args) == 2 and isinstance(mul_args[0], Number) and add_args[0].is_positive and mul_args[0].is_negative:
                    return add_args
        key, reverse = self._parse_order(order)
        terms, gens = self.as_terms()
        if not any((term.is_Order for term, _ in terms)):
            ordered = sorted(terms, key=key, reverse=reverse)
        else:
            _order, _terms = _sift_true_false(terms, lambda x: x[0].is_Order)
            ordered = sorted(_terms, key=key, reverse=True) + sorted(_order, key=key, reverse=True)
        if data:
            return (ordered, gens)
        else:
            return [term for term, _ in ordered]

    def as_terms(self) -> tuple[list[tuple[Expr, Any]], list[Expr]]:
        from .exprtools import decompose_power
        gens_set, terms = (set(), [])
        for term in Add.make_args(self):
            coeff, _term = term.as_coeff_Mul()
            coeff_complex = complex(coeff)
            cpart, ncpart = ({}, [])
            if _term is not S.One:
                for factor in Mul.make_args(_term):
                    if factor.is_number:
                        try:
                            coeff_complex *= complex(factor)
                        except (TypeError, ValueError):
                            pass
                        else:
                            continue
                    if factor.is_commutative:
                        base, exp = decompose_power(factor)
                        cpart[base] = exp
                        gens_set.add(base)
                    else:
                        ncpart.append(factor)
            coeff_tuple = (coeff_complex.real, coeff_complex.imag)
            ncpart_tuple = tuple(ncpart)
            terms.append((term, (coeff_tuple, cpart, ncpart_tuple)))
        gens = sorted(gens_set, key=default_sort_key)
        k, indices = (len(gens), {})
        for i, g in enumerate(gens):
            indices[g] = i
        result = []
        for term, (coeff_tuple, cpart, ncpart_tuple) in terms:
            monom = [0] * k
            for base, exp in cpart.items():
                monom[indices[base]] = exp
            result.append((term, (coeff_tuple, tuple(monom), ncpart_tuple)))
        return (result, gens)

    def removeO(self) -> Expr:
        return self

    def getO(self) -> Expr | None:
        return None

    def getn(self):
        o = self.getO()
        if o is None:
            return None
        elif o.is_Order:
            o = o.expr
            if o is S.One:
                return S.Zero
            if o.is_Symbol:
                return S.One
            if o.is_Pow:
                return o.args[1]
            if o.is_Mul:
                for oi in o.args:
                    if oi.is_Symbol:
                        return S.One
                    if oi.is_Pow:
                        from .symbol import Dummy, Symbol
                        syms = oi.atoms(Symbol)
                        if len(syms) == 1:
                            x = syms.pop()
                            oi = oi.subs(x, Dummy('x', positive=True))
                            if oi.base.is_Symbol and oi.exp.is_Rational:
                                return abs(oi.exp)
        raise NotImplementedError('not sure of order of %s' % o)

    def count_ops(self, visual=False):
        from .function import count_ops
        return count_ops(self, visual)

    def args_cnc(self, cset=False, warn=True, split_1=True):
        args = list(Mul.make_args(self))
        for i, mi in enumerate(args):
            if not mi.is_commutative:
                c = args[:i]
                nc = args[i:]
                break
        else:
            c = args
            nc = []
        if c and split_1 and (c[0].is_Number and c[0].is_extended_negative and (c[0] is not S.NegativeOne)):
            c[:1] = [S.NegativeOne, -c[0]]
        if cset:
            clen = len(c)
            c = set(c)
            if clen and warn and (len(c) != clen):
                raise ValueError('repeated commutative arguments: %s' % [ci for ci in c if list(self.args).count(ci) > 1])
        return [c, nc]

    def coeff(self, x: Expr | complex, n=1, right=False, _first=True):
        xe = sympify(x)
        if not isinstance(xe, Basic):
            return S.Zero
        n = as_int(n)
        if not xe:
            return S.Zero
        if xe == self:
            if n == 1:
                return S.One
            return S.Zero
        co2: list[Expr]
        if xe is S.One:
            co2 = [a for a in Add.make_args(self) if a.as_coeff_Mul()[0] is S.One]
            if not co2:
                return S.Zero
            return Add(*co2)
        if n == 0:
            if xe.is_Add and self.is_Add:
                c = self.coeff(xe, right=right)
                if not c:
                    return S.Zero
                if not right:
                    return self - Add(*[a * xe for a in Add.make_args(c)])
                return self - Add(*[xe * a for a in Add.make_args(c)])
            return self.as_independent(xe, as_Add=True)[0]
        xe = xe ** n

        def incommon(l1, l2):
            if not l1 or not l2:
                return []
            n = min(len(l1), len(l2))
            for i in range(n):
                if l1[i] != l2[i]:
                    return l1[:i]
            return l1[:]

        def find(l, sub, first=True):
            if not sub or not l or len(sub) > len(l):
                return None
            n = len(sub)
            if not first:
                l.reverse()
                sub.reverse()
            for i in range(len(l) - n + 1):
                if all((l[i + j] == sub[j] for j in range(n))):
                    break
            else:
                i = None
            if not first:
                l.reverse()
                sub.reverse()
            if i is not None and (not first):
                i = len(l) - (i + n)
            return i
        co2 = []
        co: list[tuple[set[Expr], list[Expr]]] = []
        args = Add.make_args(self)
        self_c = self.is_commutative
        x_c = xe.is_commutative
        if self_c and (not x_c):
            return S.Zero
        if _first and self.is_Add and (not self_c) and (not x_c):
            xargs = Mul.make_args(xe)
            d = Add(*[i for i in Add.make_args(self.as_independent(xe)[1]) if all((xi in Mul.make_args(i) for xi in xargs))])
            rv = d.coeff(xe, right=right, _first=False)
            if not rv.is_Add or not right:
                return rv
            c_part, nc_part = zip(*[i.args_cnc() for i in rv.args])
            if has_variety(c_part):
                return rv
            return Add(*[Mul._from_args(i) for i in nc_part])
        one_c = self_c or x_c
        xargs, nx = xe.args_cnc(cset=True, warn=bool(not x_c))
        for a in args:
            margs, nc = a.args_cnc(cset=True, warn=bool(not self_c))
            if nc is None:
                nc = []
            if len(xargs) > len(margs):
                continue
            resid = margs.difference(xargs)
            if len(resid) + len(xargs) == len(margs):
                if one_c:
                    co2.append(Mul(*list(resid) + nc))
                else:
                    co.append((resid, nc))
        if one_c:
            if co2 == []:
                return S.Zero
            elif co2:
                return Add(*co2)
        else:
            if not co:
                return S.Zero
            if all((n == co[0][1] for r, n in co)):
                ii = find(co[0][1], nx, right)
                if ii is not None:
                    if not right:
                        return Mul(Add(*[Mul(*r) for r, c in co]), Mul(*co[0][1][:ii]))
                    else:
                        return Mul(*co[0][1][ii + len(nx):])
            beg = reduce(incommon, (n[1] for n in co))
            if beg:
                ii = find(beg, nx, right)
                if ii is not None:
                    if not right:
                        gcdc = co[0][0]
                        for i in range(1, len(co)):
                            gcdc = gcdc.intersection(co[i][0])
                            if not gcdc:
                                break
                        return Mul(*list(gcdc) + beg[:ii])
                    else:
                        m = ii + len(nx)
                        return Add(*[Mul(*list(r) + n[m:]) for r, n in co])
            end = list(reversed(reduce(incommon, (list(reversed(n[1])) for n in co))))
            if end:
                ii = find(end, nx, right)
                if ii is not None:
                    if not right:
                        return Add(*[Mul(*list(r) + n[:-len(end) + ii]) for r, n in co])
                    else:
                        return Mul(*end[ii + len(nx):])
            hit = None
            for i, (r, n) in enumerate(co):
                ii = find(n, nx, right)
                if ii is not None:
                    if not hit:
                        hit = (ii, r, n)
                    else:
                        break
            else:
                if hit:
                    ii, r, n = hit
                    if not right:
                        return Mul(*list(r) + n[:ii])
                    else:
                        return Mul(*n[ii + len(nx):])
            return S.Zero

    def as_expr(self, *gens):
        return self

    def as_coefficient(self, expr: Expr) -> Expr | None:
        r = self.extract_multiplicatively(expr)
        if r and (not r.has(expr)):
            return r
        else:
            return None

    def as_independent(self, *deps: Basic | type[Basic], as_Add: bool | None=None, strict: bool=True) -> tuple[Expr, Expr]:
        from .symbol import Symbol
        from .add import _unevaluated_Add
        from .mul import _unevaluated_Mul
        if self is S.Zero:
            return (self, self)
        if as_Add is None:
            as_Add = self.is_Add
        syms, other = _sift_true_false(deps, lambda d: isinstance(d, Symbol))
        syms_set = set(syms)
        if other:

            def has(e):
                return e.has_xfree(syms_set) or e.has(*other)
        else:

            def has(e):
                return e.has_xfree(syms_set)
        if as_Add:
            if not self.is_Add:
                if has(self):
                    return (S.Zero, self)
                else:
                    return (self, S.Zero)
            depend, indep = _sift_true_false(self.args, has)
            return (self.func(*indep), _unevaluated_Add(*depend))
        else:
            if not self.is_Mul:
                if has(self):
                    return (S.One, self)
                else:
                    return (self, S.One)
            args, nc = self.args_cnc()
            depend, indep = _sift_true_false(args, has)
            for i, n in enumerate(nc):
                if has(n):
                    depend.extend(nc[i:])
                    break
                indep.append(n)
            return (self.func(*indep), _unevaluated_Mul(*depend))

    def as_real_imag(self, deep=True, **hints) -> tuple[Expr, Expr]:
        if hints.get('ignore') == self:
            return None
        else:
            from sympy.functions.elementary.complexes import im, re
            return (re(self), im(self))

    def as_powers_dict(self):
        d = defaultdict(int)
        d.update([self.as_base_exp()])
        return d

    def as_coefficients_dict(self, *syms):
        d = defaultdict(list)
        if not syms:
            for ai in Add.make_args(self):
                c, m = ai.as_coeff_Mul()
                d[m].append(c)
            for k, v in d.items():
                if len(v) == 1:
                    d[k] = v[0]
                else:
                    d[k] = Add(*v)
        else:
            ind, dep = self.as_independent(*syms, as_Add=True)
            for i in Add.make_args(dep):
                if i.is_Mul:
                    c, x = i.as_coeff_mul(*syms)
                    if c is S.One:
                        d[i].append(c)
                    else:
                        d[i._new_rawargs(*x)].append(c)
                elif i:
                    d[i].append(S.One)
            d = {k: Add(*d[k]) for k in d}
            if ind is not S.Zero:
                d.update({S.One: ind})
        di = defaultdict(int)
        di.update(d)
        return di

    def as_base_exp(self) -> tuple[Expr, Expr]:
        return (self, S.One)

    def as_coeff_mul(self, *deps, **kwargs) -> tuple[Expr, tuple[Expr, ...]]:
        if deps:
            if not self.has(*deps):
                return (self, ())
        return (S.One, (self,))

    def as_coeff_add(self, *deps) -> tuple[Expr, tuple[Expr, ...]]:
        if deps:
            if not self.has_free(*deps):
                return (self, ())
        return (S.Zero, (self,))

    def primitive(self) -> tuple[Number, Expr]:
        if not self:
            return (S.One, S.Zero)
        c, r = self.as_coeff_Mul(rational=True)
        if c.is_negative:
            c, r = (-c, -r)
        return (c, r)

    def as_content_primitive(self, radical=False, clear=True):
        return (S.One, self)

    def as_numer_denom(self) -> tuple[Expr, Expr]:
        return (self, S.One)

    def normal(self):
        from .mul import _unevaluated_Mul
        n, d = self.as_numer_denom()
        if d is S.One:
            return n
        if d.is_Number:
            return _unevaluated_Mul(n, 1 / d)
        else:
            return n / d

    def extract_multiplicatively(self, c: Expr | complex) -> Expr | None:
        from sympy.functions.elementary.exponential import exp
        from .add import _unevaluated_Add
        c = sympify(c)
        if self is S.NaN:
            return None
        if c is S.One:
            return self
        elif c == self:
            return S.One
        if c.is_Add:
            cc, pc = c.primitive()
            if cc is not S.One:
                c = Mul(cc, pc, evaluate=False)
        if c.is_Mul:
            a, b = c.as_two_terms()
            x = self.extract_multiplicatively(a)
            if x is not None:
                return x.extract_multiplicatively(b)
            else:
                return x
        quotient = self / c
        if self.is_Number:
            if self is S.Infinity:
                if c.is_positive:
                    return S.Infinity
            elif self is S.NegativeInfinity:
                if c.is_negative:
                    return S.Infinity
                elif c.is_positive:
                    return S.NegativeInfinity
            elif self is S.ComplexInfinity:
                if not c.is_zero:
                    return S.ComplexInfinity
            elif self.is_Integer:
                if not quotient.is_Integer:
                    return None
                elif self.is_positive and quotient.is_negative:
                    return None
                else:
                    return quotient
            elif self.is_Rational:
                if not quotient.is_Rational:
                    return None
                elif self.is_positive and quotient.is_negative:
                    return None
                else:
                    return quotient
            elif self.is_Float:
                if not quotient.is_Float:
                    return None
                elif self.is_positive and quotient.is_negative:
                    return None
                else:
                    return quotient
        elif self.is_NumberSymbol or self.is_Symbol or self is S.ImaginaryUnit:
            if quotient.is_Mul and len(quotient.args) == 2:
                if quotient.args[0].is_Integer and quotient.args[0].is_positive and (quotient.args[1] == self):
                    return quotient
            elif quotient.is_Integer and c.is_Number:
                return quotient
        elif self.is_Add:
            cs, ps = self.primitive()
            if c.is_Number and c is not S.NegativeOne:
                if cs is not S.One:
                    if c.is_negative:
                        xc = cs.extract_multiplicatively(-c)
                        if xc is not None:
                            xc = -xc
                    else:
                        xc = cs.extract_multiplicatively(c)
                    if xc is not None:
                        return xc * ps
                return None
            if c == ps:
                return cs
            newargs = []
            arg: Expr
            for arg in ps.args:
                newarg = arg.extract_multiplicatively(c)
                if newarg is None:
                    return None
                newargs.append(newarg)
            if cs is not S.One:
                args = [cs * t for t in newargs]
                return _unevaluated_Add(*args)
            else:
                return Add._from_args(newargs)
        elif self.is_Mul:
            args: list[Expr] = list(self.args)
            for i, arg in enumerate(args):
                newarg = arg.extract_multiplicatively(c)
                if newarg is not None:
                    args[i] = newarg
                    return Mul(*args)
        elif self.is_Pow or isinstance(self, exp):
            sb, se = self.as_base_exp()
            cb, ce = c.as_base_exp()
            if cb == sb:
                new_exp = se.extract_additively(ce)
                if new_exp is not None:
                    return Pow(sb, new_exp)
            elif c == sb:
                new_exp = se.extract_additively(1)
                if new_exp is not None:
                    return Pow(sb, new_exp)
        return None

    def extract_additively(self, c):
        c = sympify(c)
        if self is S.NaN:
            return None
        if c.is_zero:
            return self
        elif c == self:
            return S.Zero
        elif self == S.Zero:
            return None
        if self.is_Number:
            if not c.is_Number:
                return None
            co = self
            diff = co - c
            if co > 0 and diff >= 0 and (diff < co) or (co < 0 and diff <= 0 and (diff > co)):
                return diff
            return None
        if c.is_Number:
            co, t = self.as_coeff_Add()
            xa = co.extract_additively(c)
            if xa is None:
                return None
            return xa + t
        if c.is_Add and c.args[0].is_Number:
            co = self.coeff(c)
            xa0 = (co.extract_additively(1) or 0) * c
            if xa0:
                diff = self - co * c
                return xa0 + (diff.extract_additively(c) or diff) or None
            h, t = c.as_coeff_Add()
            sh, st = self.as_coeff_Add()
            xa = sh.extract_additively(h)
            if xa is None:
                return None
            xa2 = st.extract_additively(t)
            if xa2 is None:
                return None
            return xa + xa2
        co, diff = _corem(self, c)
        xa0 = (co.extract_additively(1) or 0) * c
        if xa0:
            return xa0 + (diff.extract_additively(c) or diff) or None
        coeffs = []
        for a in Add.make_args(c):
            ac, at = a.as_coeff_Mul()
            co = self.coeff(at)
            if not co:
                return None
            coc, cot = co.as_coeff_Add()
            xa = coc.extract_additively(ac)
            if xa is None:
                return None
            self -= co * at
            coeffs.append((cot + xa) * at)
        coeffs.append(self)
        return Add(*coeffs)

    @property
    def expr_free_symbols(self):
        sympy_deprecation_warning('\n        The expr_free_symbols property is deprecated. Use free_symbols to get\n        the free symbols of an expression.\n        ', deprecated_since_version='1.9', active_deprecations_target='deprecated-expr-free-symbols')
        return {j for i in self.args for j in i.expr_free_symbols}

    def could_extract_minus_sign(self) -> bool:
        return False

    def extract_branch_factor(self, allow_half=False):
        from sympy.functions.elementary.exponential import exp_polar
        from sympy.functions.elementary.integers import ceiling
        n = S.Zero
        res = S.One
        args = Mul.make_args(self)
        exps = []
        for arg in args:
            if isinstance(arg, exp_polar):
                exps += [arg.exp]
            else:
                res *= arg
        piimult = S.Zero
        extras = []
        ipi = S.Pi * S.ImaginaryUnit
        while exps:
            exp = exps.pop()
            if exp.is_Add:
                exps += exp.args
                continue
            if exp.is_Mul:
                coeff = exp.as_coefficient(ipi)
                if coeff is not None:
                    piimult += coeff
                    continue
            extras += [exp]
        if piimult.is_number:
            coeff = piimult
            tail = ()
        else:
            coeff, tail = piimult.as_coeff_add(*piimult.free_symbols)
        branchfact = ceiling(coeff / 2 - S.Half) * 2
        n += branchfact / 2
        c = coeff - branchfact
        if allow_half:
            nc = c.extract_additively(1)
            if nc is not None:
                n += S.Half
                c = nc
        newexp = ipi * Add(*(c,) + tail) + Add(*extras)
        if newexp != 0:
            res *= exp_polar(newexp)
        return (res, n)

    def is_polynomial(self, *syms):
        if syms:
            syms = set(map(sympify, syms))
        else:
            syms = self.free_symbols
            if not syms:
                return True
        return self._eval_is_polynomial(syms)

    def _eval_is_polynomial(self, syms) -> bool | None:
        if self in syms:
            return True
        if not self.has_free(*syms):
            return True
        return None

    def is_rational_function(self, *syms):
        if syms:
            syms = set(map(sympify, syms))
        else:
            syms = self.free_symbols
            if not syms:
                return self not in _illegal
        return self._eval_is_rational_function(syms)

    def _eval_is_rational_function(self, syms) -> bool | None:
        if self in syms:
            return True
        if not self.has_xfree(syms):
            return True
        return None

    def is_meromorphic(self, x, a):
        if not x.is_symbol:
            raise TypeError('{} should be of symbol type'.format(x))
        a = sympify(a)
        return self._eval_is_meromorphic(x, a)

    def _eval_is_meromorphic(self, x, a) -> bool | None:
        if self == x:
            return True
        if not self.has_free(x):
            return True
        return None

    def is_algebraic_expr(self, *syms):
        if syms:
            syms = set(map(sympify, syms))
        else:
            syms = self.free_symbols
            if not syms:
                return True
        return self._eval_is_algebraic_expr(syms)

    def _eval_is_algebraic_expr(self, syms) -> bool | None:
        if self in syms:
            return True
        if not self.has_free(*syms):
            return True
        return None

    def series(self, x=None, x0=0, n=6, dir='+', logx=None, cdir=0):
        if x is None:
            syms = self.free_symbols
            if not syms:
                return self
            elif len(syms) > 1:
                raise ValueError('x must be given for multivariate functions.')
            x = syms.pop()
        from .symbol import Dummy, Symbol
        if isinstance(x, Symbol):
            dep = x in self.free_symbols
        else:
            d = Dummy()
            dep = d in self.xreplace({x: d}).free_symbols
        if not dep:
            if n is None:
                return (s for s in [self])
            else:
                return self
        if len(dir) != 1 or dir not in '+-':
            raise ValueError("Dir must be '+' or '-'")
        if n is not None:
            n = int(n)
            if n < 0:
                raise ValueError('Number of terms should be nonnegative')
        x0 = sympify(x0)
        cdir = sympify(cdir)
        from sympy.functions.elementary.complexes import im, sign
        if not cdir.is_zero:
            if cdir.is_real:
                dir = '+' if cdir.is_positive else '-'
            else:
                dir = '+' if im(cdir).is_positive else '-'
        elif x0 and x0.is_infinite:
            cdir = sign(x0).simplify()
        elif str(dir) == '+':
            cdir = S.One
        elif str(dir) == '-':
            cdir = S.NegativeOne
        elif cdir == S.Zero:
            cdir = S.One
        cdir = cdir / abs(cdir)
        if x0 and x0.is_infinite:
            from .function import PoleError
            try:
                s = self.subs(x, cdir / x).series(x, n=n, dir='+', cdir=1)
                if n is None:
                    return (si.subs(x, cdir / x) for si in s)
                return s.subs(x, cdir / x)
            except PoleError:
                s = self.subs(x, cdir * x).aseries(x, n=n)
                return s.subs(x, cdir * x)
        if x0 or cdir != 1:
            s = self.subs({x: x0 + cdir * x}).series(x, x0=0, n=n, dir='+', logx=logx, cdir=1)
            if n is None:
                return (si.subs({x: x / cdir - x0 / cdir}) for si in s)
            return s.subs({x: x / cdir - x0 / cdir})
        if x.is_positive is x.is_negative is None or x.is_Symbol is not True:
            xpos = Dummy('x', positive=True)
            rv = self.subs(x, xpos).series(xpos, x0, n, dir, logx=logx, cdir=cdir)
            if n is None:
                return (s.subs(xpos, x) for s in rv)
            else:
                return rv.subs(xpos, x)
        from sympy.series.order import Order
        if n is not None:
            s1 = self._eval_nseries(x, n=n, logx=logx, cdir=cdir)
            o = s1.getO() or S.Zero
            if o:
                ngot = o.getn()
                if ngot > n:
                    if n != 0:
                        s1 += o.subs(x, x ** Rational(n, ngot))
                    else:
                        s1 += Order(1, x)
                elif ngot < n:
                    from sympy.functions.elementary.integers import ceiling
                    for more in range(1, 9):
                        s1 = self._eval_nseries(x, n=n + more, logx=logx, cdir=cdir)
                        newn = s1.getn()
                        if newn != ngot:
                            ndo = n + ceiling((n - ngot) * more / (newn - ngot))
                            s1 = self._eval_nseries(x, n=ndo, logx=logx, cdir=cdir)
                            while s1.getn() < n:
                                s1 = self._eval_nseries(x, n=ndo, logx=logx, cdir=cdir)
                                ndo += 1
                            break
                    else:
                        raise ValueError('Could not calculate %s terms for %s' % (str(n), self))
                    s1 += Order(x ** n, x)
                o = s1.getO()
                s1 = s1.removeO()
            elif s1.has(Order):
                return s1
            else:
                o = Order(x ** n, x)
                s1done = s1.doit()
                try:
                    if (s1done + o).removeO() == s1done:
                        o = S.Zero
                except NotImplementedError:
                    return s1
            try:
                from sympy.simplify.radsimp import collect
                return collect(s1, x) + o
            except NotImplementedError:
                return s1 + o
        else:

            def yield_lseries(s):
                for si in s:
                    if not si.is_Add:
                        yield si
                        continue
                    yielded = 0
                    o = Order(si, x) * x
                    ndid = 0
                    ndo = len(si.args)
                    while 1:
                        do = (si - yielded + o).removeO()
                        o *= x
                        if not do or do.is_Order:
                            continue
                        if do.is_Add:
                            ndid += len(do.args)
                        else:
                            ndid += 1
                        yield do
                        if ndid == ndo:
                            break
                        yielded += do
            return yield_lseries(self.removeO()._eval_lseries(x, logx=logx, cdir=cdir))

    def aseries(self, x=None, n=6, bound=0, hir=False):
        from .symbol import Dummy
        if x.is_positive is x.is_negative is None:
            xpos = Dummy('x', positive=True)
            return self.subs(x, xpos).aseries(xpos, n, bound, hir).subs(xpos, x)
        from .function import PoleError
        from sympy.series.gruntz import mrv, rewrite
        try:
            om, exps = mrv(self, x)
        except PoleError:
            return self
        from sympy.functions.elementary.exponential import exp, log
        from sympy.series.order import Order
        if x in om:
            s = self.subs(x, exp(x)).aseries(x, n, bound, hir).subs(x, log(x))
            if s.getO():
                return s + Order(1 / x ** n, (x, S.Infinity))
            return s
        k = Dummy('k', positive=True)
        func, logw = rewrite(exps, om, x, k)
        if self in om:
            if bound <= 0:
                return self
            s = self.exp.aseries(x, n, bound=bound)
            s = s.func(*[t.removeO() for t in s.args])
            try:
                res = exp(s.subs(x, 1 / x).as_leading_term(x).subs(x, 1 / x))
            except PoleError:
                res = self
            func = exp(self.args[0] - res.args[0]) / k
            logw = log(1 / res)
        s = func.series(k, 0, n)
        from sympy.core.function import expand_mul
        s = expand_mul(s)
        if hir:
            return s.subs(k, exp(logw))
        o = s.getO()
        terms = sorted(Add.make_args(s.removeO()), key=lambda i: int(i.as_coeff_exponent(k)[1]))
        s = S.Zero
        has_ord = False
        for t in terms:
            coeff, expo = t.as_coeff_exponent(k)
            if coeff.has(x):
                snew = coeff.aseries(x, n, bound=bound - 1)
                if has_ord and snew.getO():
                    break
                elif snew.getO():
                    has_ord = True
                s += snew * k ** expo
            else:
                s += t
        if not o or has_ord:
            return s.subs(k, exp(logw))
        return (s + o).subs(k, exp(logw))

    def taylor_term(self, n, x, *previous_terms):
        from .symbol import Dummy
        from sympy.functions.combinatorial.factorials import factorial
        x = sympify(x)
        _x = Dummy('x')
        return self.subs(x, _x).diff(_x, n).subs(_x, x).subs(x, 0) * x ** n / factorial(n)

    def lseries(self, x=None, x0=0, dir='+', logx=None, cdir=0):
        return self.series(x, x0, n=None, dir=dir, logx=logx, cdir=cdir)

    def _eval_lseries(self, x, logx=None, cdir=0):
        n = 0
        series = self._eval_nseries(x, n=n, logx=logx, cdir=cdir)
        while series.is_Order:
            n += 1
            series = self._eval_nseries(x, n=n, logx=logx, cdir=cdir)
        e = series.removeO()
        yield e
        if e is S.Zero:
            return
        while 1:
            while 1:
                n += 1
                series = self._eval_nseries(x, n=n, logx=logx, cdir=cdir).removeO()
                if e != series:
                    break
                if (series - self).cancel() is S.Zero:
                    return
            yield (series - e)
            e = series

    def nseries(self, x=None, x0=0, n=6, dir='+', logx=None, cdir=0):
        if x and x not in self.free_symbols:
            return self
        if x is None or x0 or dir != '+':
            return self.series(x, x0, n, dir, cdir=cdir)
        else:
            return self._eval_nseries(x, n=n, logx=logx, cdir=cdir)

    def _eval_nseries(self, x, n, logx, cdir):
        raise NotImplementedError(filldedent('\n                     The _eval_nseries method should be added to\n                     %s to give terms up to O(x**n) at x=0\n                     from the positive direction so it is available when\n                     nseries calls it.' % self.func))

    def limit(self, x, xlim, dir='+'):
        from sympy.series.limits import limit
        return limit(self, x, xlim, dir)

    @cacheit
    def as_leading_term(self, *symbols, logx=None, cdir=0):
        if len(symbols) > 1:
            c = self
            for x in symbols:
                c = c.as_leading_term(x, logx=logx, cdir=cdir)
            return c
        elif not symbols:
            return self
        x = sympify(symbols[0])
        cdir = sympify(cdir)
        if not x.is_symbol:
            raise ValueError('expecting a Symbol but got %s' % x)
        if x not in self.free_symbols:
            return self
        obj = self._eval_as_leading_term(x, logx=logx, cdir=cdir)
        if obj is not None:
            from sympy.simplify.powsimp import powsimp
            return powsimp(obj, deep=True, combine='exp')
        raise NotImplementedError('as_leading_term(%s, %s)' % (self, x))

    def _eval_as_leading_term(self, x, logx, cdir):
        return self

    def as_coeff_exponent(self, x) -> tuple[Expr, Expr]:
        from sympy.simplify.radsimp import collect
        s = collect(self, x)
        c, p = s.as_coeff_mul(x)
        if len(p) == 1:
            b, e = p[0].as_base_exp()
            if b == x:
                return (c, e)
        return (s, S.Zero)

    def leadterm(self, x, logx=None, cdir=0):
        from .symbol import Dummy
        from sympy.functions.elementary.exponential import log
        l = self.as_leading_term(x, logx=logx, cdir=cdir)
        d = Dummy('logx')
        if l.has(log(x)):
            l = l.subs(log(x), d)
        c, e = l.as_coeff_exponent(x)
        if x in c.free_symbols:
            raise ValueError(filldedent('\n                cannot compute leadterm(%s, %s). The coefficient\n                should have been free of %s but got %s' % (self, x, x, c)))
        c = c.subs(d, log(x))
        return (c, e)

    @overload
    def as_coeff_Mul(self, rational: Literal[True]) -> tuple['Rational', Expr]:
        pass

    @overload
    def as_coeff_Mul(self, rational: bool=False) -> tuple['Number', Expr]:
        pass

    def as_coeff_Mul(self, rational: bool=False) -> tuple['Number', Expr]:
        return (S.One, self)

    def as_coeff_Add(self, rational=False) -> tuple['Number', Expr]:
        return (S.Zero, self)

    def fps(self, x=None, x0=0, dir=1, hyper=True, order=4, rational=True, full=False):
        from sympy.series.formal import fps
        return fps(self, x, x0, dir, hyper, order, rational, full)

    def fourier_series(self, limits=None):
        from sympy.series.fourier import fourier_series
        return fourier_series(self, limits)

    def diff(self, *symbols, **assumptions) -> Expr:
        assumptions.setdefault('evaluate', True)
        return _derivative_dispatch(self, *symbols, **assumptions)

    def _eval_expand_complex(self, **hints):
        real, imag = self.as_real_imag(**hints)
        return real + S.ImaginaryUnit * imag

    @staticmethod
    def _expand_hint(expr, hint, deep=True, **hints):
        hit = False
        if deep and getattr(expr, 'args', ()) and (not expr.is_Atom):
            sargs = []
            for arg in expr.args:
                arg, arghit = Expr._expand_hint(arg, hint, **hints)
                hit |= arghit
                sargs.append(arg)
            if hit:
                expr = expr.func(*sargs)
        if hasattr(expr, hint):
            newexpr = getattr(expr, hint)(**hints)
            if newexpr != expr:
                return (newexpr, True)
        return (expr, hit)

    @cacheit
    def expand(self, deep=True, modulus=None, power_base=True, power_exp=True, mul=True, log=True, multinomial=True, basic=True, **hints) -> Expr:
        from sympy.simplify.radsimp import fraction
        hints.update(power_base=power_base, power_exp=power_exp, mul=mul, log=log, multinomial=multinomial, basic=basic)
        expr = self
        _fraction = lambda x: fraction(x, hints.get('exact', False))
        if hints.pop('frac', False):
            n, d = [a.expand(deep=deep, modulus=modulus, **hints) for a in _fraction(self)]
            return n / d
        elif hints.pop('denom', False):
            n, d = _fraction(self)
            return n / d.expand(deep=deep, modulus=modulus, **hints)
        elif hints.pop('numer', False):
            n, d = _fraction(self)
            return n.expand(deep=deep, modulus=modulus, **hints) / d

        def _expand_hint_key(hint):
            if hint == 'mul':
                return 'mulz'
            return hint
        for hint in sorted(hints.keys(), key=_expand_hint_key):
            use_hint = hints[hint]
            if use_hint:
                hint = '_eval_expand_' + hint
                expr, hit = Expr._expand_hint(expr, hint, deep=deep, **hints)
        while True:
            was = expr
            if hints.get('multinomial', False):
                expr, _ = Expr._expand_hint(expr, '_eval_expand_multinomial', deep=deep, **hints)
            if hints.get('mul', False):
                expr, _ = Expr._expand_hint(expr, '_eval_expand_mul', deep=deep, **hints)
            if hints.get('log', False):
                expr, _ = Expr._expand_hint(expr, '_eval_expand_log', deep=deep, **hints)
            if expr == was:
                break
        if modulus is not None:
            modulus = sympify(modulus)
            if not modulus.is_Integer or modulus <= 0:
                raise ValueError('modulus must be a positive integer, got %s' % modulus)
            terms = []
            for term in Add.make_args(expr):
                coeff, tail = term.as_coeff_Mul(rational=True)
                coeff %= modulus
                if coeff:
                    terms.append(coeff * tail)
            expr = Add(*terms)
        return expr

    def integrate(self, *args, **kwargs):
        from sympy.integrals.integrals import integrate
        return integrate(self, *args, **kwargs)

    def nsimplify(self, constants=(), tolerance=None, full=False):
        from sympy.simplify.simplify import nsimplify
        return nsimplify(self, constants, tolerance, full)

    def separate(self, deep=False, force=False):
        from .function import expand_power_base
        return expand_power_base(self, deep=deep, force=force)

    def collect(self, syms, func=None, evaluate=True, exact=False, distribute_order_term=True):
        from sympy.simplify.radsimp import collect
        return collect(self, syms, func, evaluate, exact, distribute_order_term)

    def together(self, *args, **kwargs):
        from sympy.polys.rationaltools import together
        return together(self, *args, **kwargs)

    def apart(self, x=None, **args):
        from sympy.polys.partfrac import apart
        return apart(self, x, **args)

    def ratsimp(self):
        from sympy.simplify.ratsimp import ratsimp
        return ratsimp(self)

    def trigsimp(self, **args):
        from sympy.simplify.trigsimp import trigsimp
        return trigsimp(self, **args)

    def radsimp(self, **kwargs):
        from sympy.simplify.radsimp import radsimp
        return radsimp(self, **kwargs)

    def powsimp(self, *args, **kwargs):
        from sympy.simplify.powsimp import powsimp
        return powsimp(self, *args, **kwargs)

    def combsimp(self):
        from sympy.simplify.combsimp import combsimp
        return combsimp(self)

    def gammasimp(self):
        from sympy.simplify.gammasimp import gammasimp
        return gammasimp(self)

    def factor(self, *gens, **args):
        from sympy.polys.polytools import factor
        return factor(self, *gens, **args)

    def cancel(self, *gens, **args):
        from sympy.polys.polytools import cancel
        return cancel(self, *gens, **args)

    def invert(self, g, *gens, **args):
        if self.is_number and getattr(g, 'is_number', True):
            return mod_inverse(self, g)
        from sympy.polys.polytools import invert
        return invert(self, g, *gens, **args)

    def round(self, n=None):
        x = self
        if not x.is_number:
            raise TypeError('Cannot round symbolic expression')
        if not x.is_Atom:
            if not pure_complex(x.n(2), or_real=True):
                raise TypeError('Expected a number but got %s:' % func_name(x))
        elif x in _illegal:
            return x
        if not (xr := x.is_extended_real):
            r, i = x.as_real_imag()
            if xr is False:
                return r.round(n) + S.ImaginaryUnit * i.round(n)
            if i.equals(0):
                return r.round(n)
        if not x:
            return S.Zero if n is None else x
        p = as_int(n or 0)
        if x.is_Integer:
            return Integer(round(int(x), p))
        digits_to_decimal = _mag(x)
        allow = digits_to_decimal + p
        precs = [f._prec for f in x.atoms(Float)]
        dps = prec_to_dps(max(precs)) if precs else None
        if dps is None:
            dps = max(15, allow)
        else:
            allow = min(allow, dps)
        shift = -digits_to_decimal + dps
        extra = 1
        xf = x.n(dps + extra) * Pow(10, shift)
        if xf.is_Number and xf._prec == 1:
            if x.equals(0):
                return Float(0)
            raise ValueError('not computing with precision')
        xi = Integer(xf)
        sign = 1 if x > 0 else -1
        dif2 = sign * (xf - xi).n(extra)
        if dif2 < 0:
            raise NotImplementedError('not expecting int(x) to round away from 0')
        if dif2 > 0.5:
            xi += sign
        elif dif2 == 0.5:
            xi += sign if xi % 2 else -sign
        ip = p - shift
        xr = round(xi.p, ip)
        rv = Rational(xr, Pow(10, shift))
        if rv.is_Integer:
            if n is None:
                return rv
            return Float(str(rv), dps)
        else:
            if not allow and rv > self:
                allow += 1
            return Float(rv, allow)
    __round__ = round

    def _eval_derivative_matrix_lines(self, x):
        from sympy.matrices.expressions.matexpr import _LeftRightArgs
        return [_LeftRightArgs([S.One, S.One], higher=self._eval_derivative(x))]

class AtomicExpr(Atom, Expr):
    is_number = False
    is_Atom = True
    __slots__ = ()

    def _eval_derivative(self, s):
        if self == s:
            return S.One
        return S.Zero

    def _eval_derivative_n_times(self, s, n):
        from .containers import Tuple
        from sympy.matrices.expressions.matexpr import MatrixExpr
        from sympy.matrices.matrixbase import MatrixBase
        if isinstance(s, (MatrixBase, Tuple, Iterable, MatrixExpr)):
            return super()._eval_derivative_n_times(s, n)
        from .relational import Eq
        from sympy.functions.elementary.piecewise import Piecewise
        if self == s:
            return Piecewise((self, Eq(n, 0)), (1, Eq(n, 1)), (0, True))
        else:
            return Piecewise((self, Eq(n, 0)), (0, True))

    def _eval_is_polynomial(self, syms):
        return True

    def _eval_is_rational_function(self, syms):
        return self not in _illegal

    def _eval_is_meromorphic(self, x, a):
        from sympy.calculus.accumulationbounds import AccumBounds
        return (not self.is_Number or self.is_finite) and (not isinstance(self, AccumBounds))

    def _eval_is_algebraic_expr(self, syms):
        return True

    def _eval_nseries(self, x, n, logx, cdir=0):
        return self

    @property
    def expr_free_symbols(self):
        sympy_deprecation_warning('\n        The expr_free_symbols property is deprecated. Use free_symbols to get\n        the free symbols of an expression.\n        ', deprecated_since_version='1.9', active_deprecations_target='deprecated-expr-free-symbols')
        return {self}

def _mag(x):
    from math import log10, ceil, log
    xpos = abs(x.n())
    if not xpos:
        return S.Zero
    try:
        mag_first_dig = int(ceil(log10(xpos)))
    except (ValueError, OverflowError):
        mag_first_dig = int(ceil(Float(mpf_ln(xpos._mpf_, 53)) / log(10)))
    if xpos / S(10) ** mag_first_dig >= 1:
        assert 1 <= xpos / S(10) ** mag_first_dig < 10
        mag_first_dig += 1
    return mag_first_dig

class UnevaluatedExpr(Expr):

    def __new__(cls, arg, **kwargs):
        arg = _sympify(arg)
        obj = Expr.__new__(cls, arg, **kwargs)
        return obj

    def doit(self, **hints):
        if hints.get('deep', True):
            return self.args[0].doit(**hints)
        else:
            return self.args[0]

def unchanged(func, *args):
    f = func(*args)
    return f.func == func and f.args == args

class ExprBuilder:

    def __init__(self, op, args=None, validator=None, check=True):
        if not hasattr(op, '__call__'):
            raise TypeError('op {} needs to be callable'.format(op))
        self.op = op
        if args is None:
            self.args = []
        else:
            self.args = args
        self.validator = validator
        if validator is not None and check:
            self.validate()

    @staticmethod
    def _build_args(args):
        return [i.build() if isinstance(i, ExprBuilder) else i for i in args]

    def validate(self):
        if self.validator is None:
            return
        args = self._build_args(self.args)
        self.validator(*args)

    def build(self, check=True):
        args = self._build_args(self.args)
        if self.validator and check:
            self.validator(*args)
        return self.op(*args)

    def append_argument(self, arg, check=True):
        self.args.append(arg)
        if self.validator and check:
            self.validate(*self.args)

    def __getitem__(self, item):
        if item == 0:
            return self.op
        else:
            return self.args[item - 1]

    def __repr__(self):
        return str(self.build())

    def search_element(self, elem):
        for i, arg in enumerate(self.args):
            if isinstance(arg, ExprBuilder):
                ret = arg.search_index(elem)
                if ret is not None:
                    return (i,) + ret
            elif id(arg) == id(elem):
                return (i,)
        return None
from .mul import Mul
from .add import Add
from .power import Pow
from .function import Function, _derivative_dispatch
from .mod import Mod
from .exprtools import factor_terms
from .numbers import Float, Integer, Rational, _illegal, int_valued