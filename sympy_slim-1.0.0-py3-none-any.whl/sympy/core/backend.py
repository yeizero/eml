from __future__ import annotations
import os
USE_SYMENGINE = os.getenv('USE_SYMENGINE', '0')
USE_SYMENGINE = USE_SYMENGINE.lower() in ('1', 't', 'true')
if USE_SYMENGINE:
    from symengine import Symbol, Integer, sympify as sympify_symengine, S, SympifyError, exp, log, gamma, sqrt, I, E, pi, Matrix, sin, cos, tan, cot, csc, sec, asin, acos, atan, acot, acsc, asec, sinh, cosh, tanh, coth, asinh, acosh, atanh, acoth, lambdify, symarray, diff, zeros, eye, diag, ones, expand, Function, symbols, var, Add, Mul, Derivative, ImmutableMatrix, MatrixBase, Rational, Basic
    from symengine.lib.symengine_wrapper import gcd as igcd
    from symengine import AppliedUndef

    def sympify(a, *, strict=False):
        if strict and isinstance(a, str):
            raise SympifyError(a)
        return sympify_symengine(a)
    sympify.__doc__ = sympify_symengine.__doc__ + sympify.__doc__.replace('        ', '    ')
else:
    from sympy.core.add import Add
    from sympy.core.basic import Basic
    from sympy.core.function import diff, Function, AppliedUndef, expand, Derivative
    from sympy.core.mul import Mul
    from sympy.core.intfunc import igcd
    from sympy.core.numbers import pi, I, Integer, Rational, E
    from sympy.core.singleton import S
    from sympy.core.symbol import Symbol, var, symbols
    from sympy.core.sympify import SympifyError, sympify
    from sympy.functions.elementary.exponential import log, exp
    from sympy.functions.elementary.hyperbolic import coth, sinh, acosh, acoth, tanh, asinh, atanh, cosh
    from sympy.functions.elementary.miscellaneous import sqrt
    from sympy.functions.elementary.trigonometric import csc, asec, cos, atan, sec, acot, asin, tan, sin, cot, acsc, acos
    from sympy.functions.special.gamma_functions import gamma
    from sympy.matrices.dense import eye, zeros, diag, Matrix, ones, symarray
    from sympy.matrices.immutable import ImmutableMatrix
    from sympy.matrices.matrixbase import MatrixBase
    from sympy.utilities.lambdify import lambdify

def _simplify_matrix(M):
    if not isinstance(M, (Matrix, ImmutableMatrix)):
        raise TypeError('The matrix M must be an instance of Matrix or ImmutableMatrix')
    Mnew = M.as_mutable()
    Mnew.simplify()
    if isinstance(M, ImmutableMatrix):
        Mnew = Mnew.as_immutable()
    return Mnew
__all__ = ['Symbol', 'Integer', 'sympify', 'S', 'SympifyError', 'exp', 'log', 'gamma', 'sqrt', 'I', 'E', 'pi', 'Matrix', 'sin', 'cos', 'tan', 'cot', 'csc', 'sec', 'asin', 'acos', 'atan', 'acot', 'acsc', 'asec', 'sinh', 'cosh', 'tanh', 'coth', 'asinh', 'acosh', 'atanh', 'acoth', 'lambdify', 'symarray', 'diff', 'zeros', 'eye', 'diag', 'ones', 'expand', 'Function', 'symbols', 'var', 'Add', 'Mul', 'Derivative', 'ImmutableMatrix', 'MatrixBase', 'Rational', 'Basic', 'igcd', 'AppliedUndef']