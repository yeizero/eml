from __future__ import annotations
FuzzyBool = bool | None

def _torf(args):
    sawT = sawF = False
    for a in args:
        if a is True:
            if sawF:
                return
            sawT = True
        elif a is False:
            if sawT:
                return
            sawF = True
        else:
            return
    return sawT

def _fuzzy_group(args, quick_exit=False):
    saw_other = False
    for a in args:
        if a is True:
            continue
        if a is None:
            return
        if quick_exit and saw_other:
            return
        saw_other = True
    return not saw_other

def fuzzy_bool(x):
    if x is None:
        return None
    if x in (True, False):
        return bool(x)

def fuzzy_and(args):
    rv = True
    for ai in args:
        ai = fuzzy_bool(ai)
        if ai is False:
            return False
        if rv:
            rv = ai
    return rv

def fuzzy_not(v: bool | None) -> bool | None:
    if v is None:
        return v
    else:
        return not v

def fuzzy_or(args):
    rv = False
    for ai in args:
        ai = fuzzy_bool(ai)
        if ai is True:
            return True
        if rv is False:
            rv = ai
    return rv

def fuzzy_xor(args):
    t = 0
    for a in args:
        ai = fuzzy_bool(a)
        if ai:
            t += 1
        elif ai is None:
            return
    return t % 2 == 1

def fuzzy_nand(args):
    return fuzzy_not(fuzzy_and(args))

class Logic:
    op_2class: dict[str, type[Logic]] = {}

    def __new__(cls, *args):
        obj = object.__new__(cls)
        obj.args = args
        return obj

    def __getnewargs__(self):
        return self.args

    def __hash__(self):
        return hash((type(self).__name__,) + tuple(self.args))

    def __eq__(a, b):
        if not isinstance(b, type(a)):
            return False
        else:
            return a.args == b.args

    def __ne__(a, b):
        if not isinstance(b, type(a)):
            return True
        else:
            return a.args != b.args

    def __str__(self):
        return '%s(%s)' % (self.__class__.__name__, ', '.join((str(a) for a in self.args)))
    __repr__ = __str__

    @staticmethod
    def fromstring(text):
        lexpr = None
        schedop = None
        for term in text.split():
            if term in '&|':
                if schedop is not None:
                    raise ValueError('double op forbidden: "%s %s"' % (term, schedop))
                if lexpr is None:
                    raise ValueError('%s cannot be in the beginning of expression' % term)
                schedop = term
                continue
            if '&' in term or '|' in term:
                raise ValueError('& and | must have space around them')
            if term[0] == '!':
                if len(term) == 1:
                    raise ValueError('do not include space after "!"')
                term = Not(term[1:])
            if schedop:
                lexpr = Logic.op_2class[schedop](lexpr, term)
                schedop = None
                continue
            if lexpr is not None:
                raise ValueError('missing op between "%s" and "%s"' % (lexpr, term))
            lexpr = term
        if schedop is not None:
            raise ValueError('premature end-of-expression in "%s"' % text)
        if lexpr is None:
            raise ValueError('"%s" is empty' % text)
        return lexpr

class AndOr_Base(Logic):

    def __new__(cls, *args):
        bargs = []
        for a in args:
            if a == cls.op_x_notx:
                return a
            elif a == (not cls.op_x_notx):
                continue
            bargs.append(a)
        args = sorted(set(cls.flatten(bargs)), key=hash)
        for a in args:
            if Not(a) in args:
                return cls.op_x_notx
        if len(args) == 1:
            return args.pop()
        elif len(args) == 0:
            return not cls.op_x_notx
        return Logic.__new__(cls, *args)

    @classmethod
    def flatten(cls, args):
        args_queue = list(args)
        res = []
        while True:
            try:
                arg = args_queue.pop(0)
            except IndexError:
                break
            if isinstance(arg, Logic):
                if isinstance(arg, cls):
                    args_queue.extend(arg.args)
                    continue
            res.append(arg)
        args = tuple(res)
        return args

class And(AndOr_Base):
    op_x_notx = False

    def _eval_propagate_not(self):
        return Or(*[Not(a) for a in self.args])

    def expand(self):
        for i, arg in enumerate(self.args):
            if isinstance(arg, Or):
                arest = self.args[:i] + self.args[i + 1:]
                orterms = [And(*arest + (a,)) for a in arg.args]
                for j in range(len(orterms)):
                    if isinstance(orterms[j], Logic):
                        orterms[j] = orterms[j].expand()
                res = Or(*orterms)
                return res
        return self

class Or(AndOr_Base):
    op_x_notx = True

    def _eval_propagate_not(self):
        return And(*[Not(a) for a in self.args])

class Not(Logic):

    def __new__(cls, arg):
        if isinstance(arg, str):
            return Logic.__new__(cls, arg)
        elif isinstance(arg, bool):
            return not arg
        elif isinstance(arg, Not):
            return arg.args[0]
        elif isinstance(arg, Logic):
            arg = arg._eval_propagate_not()
            return arg
        else:
            raise ValueError('Not: unknown argument %r' % (arg,))

    @property
    def arg(self):
        return self.args[0]
Logic.op_2class['&'] = And
Logic.op_2class['|'] = Or
Logic.op_2class['!'] = Not