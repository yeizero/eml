from __future__ import annotations
from typing import TYPE_CHECKING, overload
from .assumptions import StdFactKB, _assume_defined
from .basic import Basic, Atom
from .cache import cacheit
from .containers import Tuple
from .expr import Expr, AtomicExpr
from .function import AppliedUndef, FunctionClass
from .kind import NumberKind, UndefinedKind
from .logic import fuzzy_bool
from .singleton import S
from .sorting import ordered
from .sympify import sympify
from sympy.logic.boolalg import Boolean
from sympy.utilities.iterables import is_sequence, _sift_true_false
from sympy.utilities.misc import filldedent
import string
import re as _re
import random
from itertools import product
if TYPE_CHECKING:
    from typing import Any, Literal, Iterable, Callable
    from typing_extensions import Self

class Str(Atom):
    __slots__ = ('name',)
    name: str

    def __new__(cls, name, **kwargs):
        if not isinstance(name, str):
            raise TypeError('name should be a string, not %s' % repr(type(name)))
        obj = super().__new__(cls, **kwargs)
        obj.name = name
        return obj

    def __getnewargs__(self):
        return (self.name,)

    def _hashable_content(self):
        return (self.name,)

def _filter_assumptions(kwargs: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    true, false = _sift_true_false(kwargs.items(), lambda i: i[0] in _assume_defined)
    assumptions = dict(true)
    nonassumptions = dict(false)
    Symbol._sanitize(assumptions)
    return (assumptions, nonassumptions)

def _symbol(s: str | Symbol, matching_symbol: Symbol | None=None, **assumptions: bool | None) -> Symbol:
    if isinstance(s, str):
        if matching_symbol and matching_symbol.name == s:
            return matching_symbol
        return Symbol(s, **assumptions)
    elif isinstance(s, Symbol):
        return s
    else:
        raise ValueError('symbol must be string for symbol name or Symbol')

def uniquely_named_symbol(xname, exprs=(), compare=str, modify=None, **assumptions) -> Symbol:

    def numbered_string_incr(s, start=0):
        if not s:
            return str(start)
        i = len(s) - 1
        while i != -1:
            if not s[i].isdigit():
                break
            i -= 1
        n = str(int(s[i + 1:] or start - 1) + 1)
        return s[:i + 1] + n
    default = None
    if is_sequence(xname):
        xname, default = xname
    x = compare(xname)
    if not exprs:
        return _symbol(x, default, **assumptions)
    if not is_sequence(exprs):
        exprs = [exprs]
    names = set().union([i.name for e in exprs for i in e.atoms(Symbol)] + [i.func.name for e in exprs for i in e.atoms(AppliedUndef)])
    if modify is None:
        modify = numbered_string_incr
    while any((x == compare(s) for s in names)):
        x = modify(x)
    return _symbol(x, default, **assumptions)
_uniquely_named_symbol = uniquely_named_symbol

class Symbol(AtomicExpr, Boolean):
    is_comparable = False
    __slots__ = ('name', '_assumptions_orig', '_assumptions0')
    name: str
    _assumptions_orig: dict[str, bool | None]
    _assumptions0: tuple[tuple[str, bool | None], ...]
    _assumptions: StdFactKB
    is_Symbol = True
    is_symbol = True

    @property
    def kind(self):
        if self.is_commutative:
            return NumberKind
        return UndefinedKind

    @property
    def _diff_wrt(self) -> bool:
        return True

    @staticmethod
    def _sanitize(assumptions, obj=None):
        is_commutative = fuzzy_bool(assumptions.get('commutative', True))
        if is_commutative is None:
            whose = '%s ' % obj.__name__ if obj else ''
            raise ValueError('%scommutativity must be True or False.' % whose)
        for key in list(assumptions.keys()):
            v = assumptions[key]
            if v is None:
                assumptions.pop(key)
                continue
            assumptions[key] = bool(v)

    def _merge(self, assumptions):
        base = self.assumptions0
        for k in set(assumptions) & set(base):
            if assumptions[k] != base[k]:
                raise ValueError(filldedent('\n                    non-matching assumptions for %s: existing value\n                    is %s and new value is %s' % (k, base[k], assumptions[k])))
        base.update(assumptions)
        return base

    def __new__(cls, name: str, **assumptions: bool | None) -> Self:
        cls._sanitize(assumptions, cls)
        return Symbol.__xnew_cached_(cls, name, **assumptions)

    @staticmethod
    @cacheit
    def _canonical_assumptions(**assumptions):
        assumptions_orig = assumptions.copy()
        assumptions.setdefault('commutative', True)
        assumptions_kb = StdFactKB(assumptions)
        assumptions0 = dict(assumptions_kb)
        return (assumptions_kb, assumptions_orig, assumptions0)

    @staticmethod
    def __xnew__(cls, name, **assumptions):
        if not isinstance(name, str):
            raise TypeError('name should be a string, not %s' % repr(type(name)))
        obj = Expr.__new__(cls)
        obj.name = name
        assumptions_kb, assumptions_orig, assumptions0 = Symbol._canonical_assumptions(**assumptions)
        obj._assumptions = assumptions_kb
        obj._assumptions_orig = assumptions_orig
        obj._assumptions0 = tuple(sorted(assumptions0.items()))
        return obj

    @staticmethod
    @cacheit
    def __xnew_cached_(cls, name, **assumptions):
        return Symbol.__xnew__(cls, name, **assumptions)

    def __getnewargs_ex__(self):
        return ((self.name,), self._assumptions_orig)

    def __setstate__(self, state):
        for name, value in state.items():
            setattr(self, name, value)

    def _hashable_content(self):
        return (self.name,) + self._assumptions0

    def _eval_subs(self, old, new):
        if old.is_Pow:
            from sympy.core.power import Pow
            return Pow(self, S.One, evaluate=False)._eval_subs(old, new)

    def _eval_refine(self, assumptions):
        return self

    @property
    def assumptions0(self):
        return dict(self._assumptions0)

    @cacheit
    def sort_key(self, order=None):
        return (self.class_key(), (1, (self.name,)), S.One.sort_key(), S.One)

    def as_dummy(self):
        return Dummy(self.name) if self.is_commutative is not False else Dummy(self.name, commutative=self.is_commutative)

    def as_real_imag(self, deep=True, **hints) -> tuple[Expr, Expr]:
        if hints.get('ignore') == self:
            return None
        else:
            from sympy.functions.elementary.complexes import im, re
            return (re(self), im(self))

    def is_constant(self, *wrt, **flags):
        if not wrt:
            return False
        return self not in wrt

    @property
    def free_symbols(self) -> set[Basic]:
        return {self}
    binary_symbols = free_symbols

    def as_set(self):
        return S.UniversalSet

class Dummy(Symbol):
    _count = 0
    _prng = random.Random()
    _base_dummy_index = _prng.randint(10 ** 6, 9 * 10 ** 6)
    __slots__ = ('dummy_index',)
    is_Dummy = True

    def __new__(cls, name: str | None=None, dummy_index: int | None=None, **assumptions: bool | None) -> Self:
        if dummy_index is not None:
            assert name is not None, 'If you specify a dummy_index, you must also provide a name'
        if name is None:
            name = 'Dummy_' + str(Dummy._count)
        if dummy_index is None:
            dummy_index = Dummy._base_dummy_index + Dummy._count
            Dummy._count += 1
        cls._sanitize(assumptions, cls)
        obj = Symbol.__xnew__(cls, name, **assumptions)
        obj.dummy_index = dummy_index
        return obj

    def __getnewargs_ex__(self):
        return ((self.name, self.dummy_index), self._assumptions_orig)

    @cacheit
    def sort_key(self, order=None):
        return (self.class_key(), (2, (self.name, self.dummy_index)), S.One.sort_key(), S.One)

    def _hashable_content(self):
        return Symbol._hashable_content(self) + (self.dummy_index,)

class Wild(Symbol):
    is_Wild = True
    __slots__ = ('exclude', 'properties')

    def __new__(cls, name: str, exclude: Iterable[Expr | complex]=(), properties: Iterable[Callable[[Expr], bool | None]]=(), **assumptions: bool | None) -> Self:
        exclude = tuple([sympify(x) for x in exclude])
        properties = tuple(properties)
        cls._sanitize(assumptions, cls)
        return Wild.__xnew__(cls, name, exclude, properties, **assumptions)

    def __getnewargs__(self):
        return (self.name, self.exclude, self.properties)

    @staticmethod
    @cacheit
    def __xnew__(cls, name, exclude, properties, **assumptions):
        obj = Symbol.__xnew__(cls, name, **assumptions)
        obj.exclude = exclude
        obj.properties = properties
        return obj

    def _hashable_content(self):
        return super()._hashable_content() + (self.exclude, self.properties)

    def matches(self, expr, repl_dict=None, old=False):
        if any((expr.has(x) for x in self.exclude)):
            return None
        if not all((f(expr) for f in self.properties)):
            return None
        if repl_dict is None:
            repl_dict = {}
        else:
            repl_dict = repl_dict.copy()
        repl_dict[self] = expr
        return repl_dict
_range = _re.compile('([0-9]*:[0-9]+|[a-zA-Z]?:[a-zA-Z])')

@overload
def symbols(names: str, *, cls: type[Symbol]=Symbol, seq: Literal[True], **kwargs: bool | int) -> tuple[Symbol, ...]:
    pass

@overload
def symbols(names: str, *, cls: Any=Symbol, seq: Literal[True], **kwargs: bool | int) -> tuple[Any, ...]:
    pass

@overload
def symbols(names: str, *, cls: Any=Symbol, seq: Literal[False]=False, **kwargs: bool | int) -> Any:
    pass

def symbols(names, *, cls: Any=Symbol, **args) -> Any:
    result = []
    if isinstance(names, str):
        marker = 0
        splitters = ('\\,', '\\:', '\\ ')
        literals: list[tuple[str, str]] = []
        for splitter in splitters:
            if splitter in names:
                while chr(marker) in names:
                    marker += 1
                lit_char = chr(marker)
                marker += 1
                names = names.replace(splitter, lit_char)
                literals.append((lit_char, splitter[1:]))

        def literal(s):
            if literals:
                for c, l in literals:
                    s = s.replace(c, l)
            return s
        names = names.strip()
        as_seq = names.endswith(',')
        if as_seq:
            names = names[:-1].rstrip()
        if not names:
            raise ValueError('no symbols given')
        names = [n.strip() for n in names.split(',')]
        if not all((n for n in names)):
            raise ValueError('missing symbol between commas')
        for i in range(len(names) - 1, -1, -1):
            names[i:i + 1] = names[i].split()
        seq = args.pop('seq', as_seq)
        for name in names:
            if not name:
                raise ValueError('missing symbol')
            if ':' not in name:
                symbol = cls(literal(name), **args)
                result.append(symbol)
                continue
            split: list[str] = _range.split(name)
            split_list: list[list[str]] = []
            for i in range(len(split) - 1):
                if i and ':' in split[i] and (split[i] != ':') and split[i - 1].endswith('(') and split[i + 1].startswith(')'):
                    split[i - 1] = split[i - 1][:-1]
                    split[i + 1] = split[i + 1][1:]
            for s in split:
                if ':' in s:
                    if s.endswith(':'):
                        raise ValueError('missing end range')
                    a, b = s.split(':')
                    if b[-1] in string.digits:
                        a_i = 0 if not a else int(a)
                        b_i = int(b)
                        split_list.append([str(c) for c in range(a_i, b_i)])
                    else:
                        a = a or 'a'
                        split_list.append([string.ascii_letters[c] for c in range(string.ascii_letters.index(a), string.ascii_letters.index(b) + 1)])
                    if not split_list[-1]:
                        break
                else:
                    split_list.append([s])
            else:
                seq = True
                if len(split_list) == 1:
                    names = split_list[0]
                else:
                    names = [''.join(s) for s in product(*split_list)]
                if literals:
                    result.extend([cls(literal(s), **args) for s in names])
                else:
                    result.extend([cls(s, **args) for s in names])
        if not seq and len(result) <= 1:
            if not result:
                return ()
            return result[0]
        return tuple(result)
    else:
        for name in names:
            result.append(symbols(name, cls=cls, **args))
        return type(names)(result)

def var(names, **args):

    def traverse(symbols, frame):
        for symbol in symbols:
            if isinstance(symbol, Basic):
                frame.f_globals[symbol.name] = symbol
            elif isinstance(symbol, FunctionClass):
                frame.f_globals[symbol.__name__] = symbol
            else:
                traverse(symbol, frame)
    from inspect import currentframe
    frame = currentframe().f_back
    try:
        syms = symbols(names, **args)
        if syms is not None:
            if isinstance(syms, Basic):
                frame.f_globals[syms.name] = syms
            elif isinstance(syms, FunctionClass):
                frame.f_globals[syms.__name__] = syms
            else:
                traverse(syms, frame)
    finally:
        del frame
    return syms

def disambiguate(*iter):
    new_iter = Tuple(*iter)
    key = lambda x: tuple(sorted(x.assumptions0.items()))
    syms = ordered(new_iter.free_symbols, keys=key)
    mapping = {}
    for s in syms:
        mapping.setdefault(str(s).lstrip('_'), []).append(s)
    reps = {}
    for k in mapping:
        mapk0 = Symbol('%s' % k, **mapping[k][0].assumptions0)
        if mapping[k][0] != mapk0:
            reps[mapping[k][0]] = mapk0
        skip = 0
        for i in range(1, len(mapping[k])):
            while True:
                name = '%s_%i' % (k, i + skip)
                if name not in mapping:
                    break
                skip += 1
            ki = mapping[k][i]
            reps[ki] = Symbol(name, **ki.assumptions0)
    return new_iter.xreplace(reps)