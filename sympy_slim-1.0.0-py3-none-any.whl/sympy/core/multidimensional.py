from __future__ import annotations
from functools import wraps

def apply_on_element(f, args, kwargs, n):
    if isinstance(n, int):
        structure = args[n]
        is_arg = True
    elif isinstance(n, str):
        structure = kwargs[n]
        is_arg = False

    def f_reduced(x):
        if hasattr(x, '__iter__'):
            return list(map(f_reduced, x))
        else:
            if is_arg:
                args[n] = x
            else:
                kwargs[n] = x
            return f(*args, **kwargs)
    return list(map(f_reduced, structure))

def iter_copy(structure):
    return [iter_copy(i) if hasattr(i, '__iter__') else i for i in structure]

def structure_copy(structure):
    if hasattr(structure, 'copy'):
        return structure.copy()
    return iter_copy(structure)

class vectorize:

    def __init__(self, *mdargs):
        for a in mdargs:
            if not isinstance(a, (int, str)):
                raise TypeError('a is of invalid type')
        self.mdargs = mdargs

    def __call__(self, f):

        @wraps(f)
        def wrapper(*args, **kwargs):
            if self.mdargs:
                mdargs = self.mdargs
            else:
                mdargs = range(len(args)) + kwargs.keys()
            arglength = len(args)
            for n in mdargs:
                if isinstance(n, int):
                    if n >= arglength:
                        continue
                    entry = args[n]
                    is_arg = True
                elif isinstance(n, str):
                    try:
                        entry = kwargs[n]
                    except KeyError:
                        continue
                    is_arg = False
                if hasattr(entry, '__iter__'):
                    if is_arg:
                        args = list(args)
                        args[n] = structure_copy(entry)
                    else:
                        kwargs[n] = structure_copy(entry)
                    result = apply_on_element(wrapper, args, kwargs, n)
                    return result
            return f(*args, **kwargs)
        return wrapper