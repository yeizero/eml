from __future__ import annotations
from sympy.utilities.exceptions import sympy_deprecation_warning
sympy_deprecation_warning('\nThe sympy.core.compatibility submodule is deprecated.\n\nThis module was only ever intended for internal use. Some of the functions\nthat were in this module are available from the top-level SymPy namespace,\ni.e.,\n\n    from sympy import ordered, default_sort_key\n\nThe remaining were only intended for internal SymPy use and should not be used\nby user code.\n', deprecated_since_version='1.10', active_deprecations_target='deprecated-sympy-core-compatibility')
from .sorting import ordered, _nodes, default_sort_key
from sympy.utilities.misc import as_int as _as_int
from sympy.utilities.iterables import iterable, is_sequence, NotIterable