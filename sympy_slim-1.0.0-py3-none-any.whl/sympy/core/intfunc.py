from __future__ import annotations
import math
import sys
from functools import lru_cache
from .sympify import sympify
from .singleton import S
from sympy.external.gmpy import gcd as number_gcd, lcm as number_lcm, sqrt, iroot, bit_scan1, gcdext
from sympy.utilities.misc import as_int, filldedent

def num_digits(n, base=10):
    if base < 0:
        raise ValueError('base must be int greater than 1')
    if not n:
        return 1
    e, t = integer_log(abs(n), base)
    return 1 + e

def integer_log(n, b):
    n = as_int(n)
    b = as_int(b)
    if b < 0:
        e, t = integer_log(abs(n), -b)
        t = t and e % 2 == (n < 0)
        return (e, t)
    if b <= 1:
        raise ValueError('base must be 2 or more')
    if n < 0:
        if b != 2:
            return (0, False)
        e, t = integer_log(-n, b)
        return (e, False)
    if n == 0:
        raise ValueError('n cannot be 0')
    if n < b:
        return (0, n == 1)
    if b == 2:
        e = n.bit_length() - 1
        return (e, trailing(n) == e)
    t = trailing(b)
    if 2 ** t == b:
        e = int(n.bit_length() - 1) // t
        n_ = 1 << t * e
        return (e, n_ == n)
    d = math.floor(math.log10(n) / math.log10(b))
    n_ = b ** d
    while n_ <= n:
        d += 1
        n_ *= b
    return (d - (n_ > n), n_ == n or n_ // b == n)

def trailing(n):
    if not n:
        return 0
    return bit_scan1(int(n))

@lru_cache(1024)
def igcd(*args):
    if len(args) < 2:
        raise TypeError('igcd() takes at least 2 arguments (%s given)' % len(args))
    return int(number_gcd(*map(as_int, args)))
igcd2 = math.gcd

def igcd_lehmer(a, b):
    a, b = (abs(as_int(a)), abs(as_int(b)))
    if a < b:
        a, b = (b, a)
    nbits = 2 * sys.int_info.bits_per_digit
    while a.bit_length() > nbits and b != 0:
        n = a.bit_length() - nbits
        x, y = (int(a >> n), int(b >> n))
        A, B, C, D = (1, 0, 0, 1)
        while True:
            if y + C <= 0:
                break
            q = (x + A) // (y + C)
            x_qy, B_qD = (x - q * y, B - q * D)
            if x_qy + B_qD < 0:
                break
            x, y = (y, x_qy)
            A, B, C, D = (C, D, A - q * C, B_qD)
            if y + D <= 0:
                break
            q = (x + B) // (y + D)
            x_qy, A_qC = (x - q * y, A - q * C)
            if x_qy + A_qC < 0:
                break
            x, y = (y, x_qy)
            A, B, C, D = (C, D, A_qC, B - q * D)
        if B == 0:
            a, b = (b, a % b)
            continue
        a, b = (A * a + B * b, C * a + D * b)
    while b:
        a, b = (b, a % b)
    return a

def ilcm(*args):
    if len(args) < 2:
        raise TypeError('ilcm() takes at least 2 arguments (%s given)' % len(args))
    return int(number_lcm(*map(as_int, args)))

def igcdex(a, b):
    g, x, y = gcdext(int(a), int(b))
    return (x, y, g)

def mod_inverse(a, m):
    c = None
    try:
        a, m = (as_int(a), as_int(m))
        if m != 1 and m != -1:
            x, _, g = igcdex(a, m)
            if g == 1:
                c = x % m
    except ValueError:
        a, m = (sympify(a), sympify(m))
        if not (a.is_number and m.is_number):
            raise TypeError(filldedent('\n                Expected numbers for arguments; symbolic `mod_inverse`\n                is not implemented\n                but symbolic expressions can be handled with the\n                similar function,\n                sympy.polys.polytools.invert'))
        big = m > 1
        if big not in (S.true, S.false):
            raise ValueError('m > 1 did not evaluate; try to simplify %s' % m)
        elif big:
            c = 1 / a
    if c is None:
        raise ValueError('inverse of %s (mod %s) does not exist' % (a, m))
    return c

def isqrt(n):
    if n < 0:
        raise ValueError('n must be nonnegative')
    return int(sqrt(int(n)))

def integer_nthroot(y, n):
    x, b = iroot(as_int(y), as_int(n))
    return (int(x), b)