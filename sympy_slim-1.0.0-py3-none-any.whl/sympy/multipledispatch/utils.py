from __future__ import annotations
from collections import OrderedDict

def expand_tuples(L):
    if not L:
        return [()]
    elif not isinstance(L[0], tuple):
        rest = expand_tuples(L[1:])
        return [(L[0],) + t for t in rest]
    else:
        rest = expand_tuples(L[1:])
        return [(item,) + t for t in rest for item in L[0]]

def _toposort(edges):
    incoming_edges = reverse_dict(edges)
    incoming_edges = {k: set(val) for k, val in incoming_edges.items()}
    S = OrderedDict.fromkeys((v for v in edges if v not in incoming_edges))
    L = []
    while S:
        n, _ = S.popitem()
        L.append(n)
        for m in edges.get(n, ()):
            assert n in incoming_edges[m]
            incoming_edges[m].remove(n)
            if not incoming_edges[m]:
                S[m] = None
    if any((incoming_edges.get(v, None) for v in edges)):
        raise ValueError('Input has cycles')
    return L

def reverse_dict(d):
    result = {}
    for key in d:
        for val in d[key]:
            result[val] = result.get(val, ()) + (key,)
    return result

def groupby(func, seq):
    d = {}
    for item in seq:
        key = func(item)
        if key not in d:
            d[key] = []
        d[key].append(item)
    return d