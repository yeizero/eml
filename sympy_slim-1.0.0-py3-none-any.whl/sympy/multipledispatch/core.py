from __future__ import annotations
from typing import Any
import inspect
from .dispatcher import Dispatcher, MethodDispatcher, ambiguity_warn
global_namespace: dict[str, Any] = {}

def dispatch(*types, namespace=global_namespace, on_ambiguity=ambiguity_warn):
    types = tuple(types)

    def _(func):
        name = func.__name__
        if ismethod(func):
            dispatcher = inspect.currentframe().f_back.f_locals.get(name, MethodDispatcher(name))
        else:
            if name not in namespace:
                namespace[name] = Dispatcher(name)
            dispatcher = namespace[name]
        dispatcher.add(types, func, on_ambiguity=on_ambiguity)
        return dispatcher
    return _

def ismethod(func):
    signature = inspect.signature(func)
    return signature.parameters.get('self', None) is not None