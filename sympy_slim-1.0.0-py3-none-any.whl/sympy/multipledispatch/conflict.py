from __future__ import annotations
from .utils import _toposort, groupby

class AmbiguityWarning(Warning):
    pass

def supercedes(a, b):
    return len(a) == len(b) and all(map(issubclass, a, b))

def consistent(a, b):
    return len(a) == len(b) and all((issubclass(aa, bb) or issubclass(bb, aa) for aa, bb in zip(a, b)))

def ambiguous(a, b):
    return consistent(a, b) and (not (supercedes(a, b) or supercedes(b, a)))

def ambiguities(signatures):
    signatures = list(map(tuple, signatures))
    return {(a, b) for a in signatures for b in signatures if hash(a) < hash(b) and ambiguous(a, b) and (not any((supercedes(c, a) and supercedes(c, b) for c in signatures)))}

def super_signature(signatures):
    n = len(signatures[0])
    assert all((len(s) == n for s in signatures))
    return [max([type.mro(sig[i]) for sig in signatures], key=len)[0] for i in range(n)]

def edge(a, b, tie_breaker=hash):
    if supercedes(a, b):
        if supercedes(b, a):
            return tie_breaker(a) > tie_breaker(b)
        else:
            return True
    return False

def ordering(signatures):
    signatures = list(map(tuple, signatures))
    edges = [(a, b) for a in signatures for b in signatures if edge(a, b)]
    edges = groupby(lambda x: x[0], edges)
    for s in signatures:
        if s not in edges:
            edges[s] = []
    edges = {k: [b for a, b in v] for k, v in edges.items()}
    return _toposort(edges)