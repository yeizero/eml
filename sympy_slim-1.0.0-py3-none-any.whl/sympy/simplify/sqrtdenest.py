from __future__ import annotations
from sympy.core import Add, Expr, Mul, S, sympify
from sympy.core.function import _mexpand, count_ops, expand_mul
from sympy.core.sorting import default_sort_key
from sympy.core.symbol import Dummy
from sympy.functions import root, sign, sqrt
from sympy.polys import Poly, PolynomialError

def is_sqrt(expr):
    return expr.is_Pow and expr.exp.is_Rational and (abs(expr.exp) is S.Half)

def sqrt_depth(p) -> int:
    if p is S.ImaginaryUnit:
        return 1
    if p.is_Atom:
        return 0
    if p.is_Add or p.is_Mul:
        return max((sqrt_depth(x) for x in p.args))
    if is_sqrt(p):
        return sqrt_depth(p.base) + 1
    return 0

def is_algebraic(p):
    if p.is_Rational:
        return True
    elif p.is_Atom:
        return False
    elif is_sqrt(p) or (p.is_Pow and p.exp.is_Integer):
        return is_algebraic(p.base)
    elif p.is_Add or p.is_Mul:
        return all((is_algebraic(x) for x in p.args))
    else:
        return False

def _subsets(n):
    if n == 1:
        a = [[1]]
    elif n == 2:
        a = [[1, 0], [0, 1], [1, 1]]
    elif n == 3:
        a = [[1, 0, 0], [0, 1, 0], [1, 1, 0], [0, 0, 1], [1, 0, 1], [0, 1, 1], [1, 1, 1]]
    else:
        b = _subsets(n - 1)
        a0 = [x + [0] for x in b]
        a1 = [x + [1] for x in b]
        a = a0 + [[0] * (n - 1) + [1]] + a1
    return a

def sqrtdenest(expr, max_iter=3):
    expr = expand_mul(expr)
    for i in range(max_iter):
        z = _sqrtdenest0(expr)
        if expr == z:
            return expr
        expr = z
    return expr

def _sqrt_match(p):
    from sympy.simplify.radsimp import split_surds
    p = _mexpand(p)
    if p.is_Number:
        res = (p, S.Zero, S.Zero)
    elif p.is_Add:
        pargs = sorted(p.args, key=default_sort_key)
        sqargs = [x ** 2 for x in pargs]
        if all((sq.is_Rational and sq.is_positive for sq in sqargs)):
            r, b, a = split_surds(p)
            res = (a, b, r)
            return list(res)
        v = [(sqrt_depth(x), x, i) for i, x in enumerate(pargs)]
        nmax = max(v, key=default_sort_key)
        if nmax[0] == 0:
            res = []
        else:
            depth, _, i = nmax
            r = pargs.pop(i)
            v.pop(i)
            b = S.One
            if r.is_Mul:
                bv = []
                rv = []
                for x in r.args:
                    if sqrt_depth(x) < depth:
                        bv.append(x)
                    else:
                        rv.append(x)
                b = Mul._from_args(bv)
                r = Mul._from_args(rv)
            a1 = []
            b1 = [b]
            for x in v:
                if x[0] < depth:
                    a1.append(x[1])
                else:
                    x1 = x[1]
                    if x1 == r:
                        b1.append(1)
                    elif x1.is_Mul:
                        x1args = list(x1.args)
                        if r in x1args:
                            x1args.remove(r)
                            b1.append(Mul(*x1args))
                        else:
                            a1.append(x[1])
                    else:
                        a1.append(x[1])
            a = Add(*a1)
            b = Add(*b1)
            res = (a, b, r ** 2)
    else:
        b, r = p.as_coeff_Mul()
        if is_sqrt(r):
            res = (S.Zero, b, r ** 2)
        else:
            res = []
    return list(res)

class SqrtdenestStopIteration(StopIteration):
    pass

def _sqrtdenest0(expr):
    if is_sqrt(expr):
        n, d = expr.as_numer_denom()
        if d is S.One:
            if n.base.is_Add:
                args = sorted(n.base.args, key=default_sort_key)
                if len(args) > 2 and all(((x ** 2).is_Integer for x in args)):
                    try:
                        return _sqrtdenest_rec(n)
                    except SqrtdenestStopIteration:
                        pass
                expr = sqrt(_mexpand(Add(*[_sqrtdenest0(x) for x in args])))
            return _sqrtdenest1(expr)
        else:
            n, d = [_sqrtdenest0(i) for i in (n, d)]
            return n / d
    if isinstance(expr, Add):
        cs = []
        args = []
        for arg in expr.args:
            c, a = arg.as_coeff_Mul()
            cs.append(c)
            args.append(a)
        if all((c.is_Rational for c in cs)) and all((is_sqrt(arg) for arg in args)):
            return _sqrt_ratcomb(cs, args)
    if isinstance(expr, Expr):
        args = expr.args
        if args:
            return expr.func(*[_sqrtdenest0(a) for a in args])
    return expr

def _sqrtdenest_rec(expr):
    from sympy.simplify.radsimp import radsimp, rad_rationalize, split_surds
    if not expr.is_Pow:
        return sqrtdenest(expr)
    if expr.base < 0:
        return sqrt(-1) * _sqrtdenest_rec(sqrt(-expr.base))
    g, a, b = split_surds(expr.base)
    a = a * sqrt(g)
    if a < b:
        a, b = (b, a)
    c2 = _mexpand(a ** 2 - b ** 2)
    if len(c2.args) > 2:
        g, a1, b1 = split_surds(c2)
        a1 = a1 * sqrt(g)
        if a1 < b1:
            a1, b1 = (b1, a1)
        c2_1 = _mexpand(a1 ** 2 - b1 ** 2)
        c_1 = _sqrtdenest_rec(sqrt(c2_1))
        d_1 = _sqrtdenest_rec(sqrt(a1 + c_1))
        num, den = rad_rationalize(b1, d_1)
        c = _mexpand(d_1 / sqrt(2) + num / (den * sqrt(2)))
    else:
        c = _sqrtdenest1(sqrt(c2))
    if sqrt_depth(c) > 1:
        raise SqrtdenestStopIteration
    ac = a + c
    if len(ac.args) >= len(expr.args):
        if count_ops(ac) >= count_ops(expr.base):
            raise SqrtdenestStopIteration
    d = sqrtdenest(sqrt(ac))
    if sqrt_depth(d) > 1:
        raise SqrtdenestStopIteration
    num, den = rad_rationalize(b, d)
    r = d / sqrt(2) + num / (den * sqrt(2))
    r = radsimp(r)
    return _mexpand(r)

def _sqrtdenest1(expr, denester=True):
    from sympy.simplify.simplify import radsimp
    if not is_sqrt(expr):
        return expr
    a = expr.base
    if a.is_Atom:
        return expr
    val = _sqrt_match(a)
    if not val:
        return expr
    a, b, r = val
    d2 = _mexpand(a ** 2 - b ** 2 * r)
    if d2.is_Rational:
        if d2.is_positive:
            z = _sqrt_numeric_denest(a, b, r, d2)
            if z is not None:
                return z
        else:
            dr2 = _mexpand(-d2 * r)
            dr = sqrt(dr2)
            if dr.is_Rational:
                z = _sqrt_numeric_denest(_mexpand(b * r), a, r, dr2)
                if z is not None:
                    return z / root(r, 4)
    else:
        z = _sqrt_symbolic_denest(a, b, r)
        if z is not None:
            return z
    if not denester or not is_algebraic(expr):
        return expr
    res = sqrt_biquadratic_denest(expr, a, b, r, d2)
    if res:
        return res
    av0 = [a, b, r, d2]
    z = _denester([radsimp(expr ** 2)], av0, 0, sqrt_depth(expr))[0]
    if av0[1] is None:
        return expr
    if z is not None:
        if sqrt_depth(z) == sqrt_depth(expr) and count_ops(z) > count_ops(expr):
            return expr
        return z
    return expr

def _sqrt_symbolic_denest(a, b, r):
    a, b, r = map(sympify, (a, b, r))
    rval = _sqrt_match(r)
    if not rval:
        return None
    ra, rb, rr = rval
    if rb:
        y = Dummy('y', positive=True)
        try:
            newa = Poly(a.subs(sqrt(rr), (y ** 2 - ra) / rb), y)
        except PolynomialError:
            return None
        if newa.degree() == 2:
            ca, cb, cc = newa.all_coeffs()
            cb += b
            if _mexpand(cb ** 2 - 4 * ca * cc).equals(0):
                z = sqrt(ca * (sqrt(r) + cb / (2 * ca)) ** 2)
                if z.is_number:
                    z = _mexpand(Mul._from_args(z.as_content_primitive()))
                return z

def _sqrt_numeric_denest(a, b, r, d2):
    d = sqrt(d2)
    s = a + d
    if sqrt_depth(s) < sqrt_depth(r) + 1 or (s ** 2).is_Rational:
        s1, s2 = (sign(s), sign(b))
        if s1 == s2 == -1:
            s1 = s2 = 1
        res = (s1 * sqrt(a + d) + s2 * sqrt(a - d)) * sqrt(2) / 2
        return res.expand()

def sqrt_biquadratic_denest(expr, a, b, r, d2):
    from sympy.simplify.radsimp import radsimp, rad_rationalize
    if r <= 0 or d2 < 0 or (not b) or (sqrt_depth(expr.base) < 2):
        return None
    for x in (a, b, r):
        for y in x.args:
            y2 = y ** 2
            if not y2.is_Integer or not y2.is_positive:
                return None
    sqd = _mexpand(sqrtdenest(sqrt(radsimp(d2))))
    if sqrt_depth(sqd) > 1:
        return None
    x1, x2 = [a / 2 + sqd / 2, a / 2 - sqd / 2]
    for x in (x1, x2):
        A = sqrtdenest(sqrt(x))
        if sqrt_depth(A) > 1:
            continue
        Bn, Bd = rad_rationalize(b, _mexpand(2 * A))
        B = Bn / Bd
        z = A + B * sqrt(r)
        if z < 0:
            z = -z
        return _mexpand(z)
    return None

def _denester(nested, av0, h, max_depth_level):
    from sympy.simplify.simplify import radsimp
    if h > max_depth_level:
        return (None, None)
    if av0[1] is None:
        return (None, None)
    if av0[0] is None and all((n.is_Number for n in nested)):
        for f in _subsets(len(nested)):
            p = _mexpand(Mul(*[nested[i] for i in range(len(f)) if f[i]]))
            if f.count(1) > 1 and f[-1]:
                p = -p
            sqp = sqrt(p)
            if sqp.is_Rational:
                return (sqp, f)
        return (sqrt(nested[-1]), [0] * len(nested))
    else:
        R = None
        if av0[0] is not None:
            values = [av0[:2]]
            R = av0[2]
            nested2 = [av0[3], R]
            av0[0] = None
        else:
            values = list(filter(None, [_sqrt_match(expr) for expr in nested]))
            for v in values:
                if v[2]:
                    if R is not None:
                        if R != v[2]:
                            av0[1] = None
                            return (None, None)
                    else:
                        R = v[2]
            if R is None:
                return (sqrt(nested[-1]), [0] * len(nested))
            nested2 = [_mexpand(v[0] ** 2) - _mexpand(R * v[1] ** 2) for v in values] + [R]
        d, f = _denester(nested2, av0, h + 1, max_depth_level)
        if not f:
            return (None, None)
        if not any((f[i] for i in range(len(nested)))):
            v = values[-1]
            return (sqrt(v[0] + _mexpand(v[1] * d)), f)
        else:
            p = Mul(*[nested[i] for i in range(len(nested)) if f[i]])
            v = _sqrt_match(p)
            if 1 in f and f.index(1) < len(nested) - 1 and f[len(nested) - 1]:
                v[0] = -v[0]
                v[1] = -v[1]
            if not f[len(nested)]:
                vad = _mexpand(v[0] + d)
                if vad <= 0:
                    return (sqrt(nested[-1]), [0] * len(nested))
                if not (sqrt_depth(vad) <= sqrt_depth(R) + 1 or (vad ** 2).is_Number):
                    av0[1] = None
                    return (None, None)
                sqvad = _sqrtdenest1(sqrt(vad), denester=False)
                if not sqrt_depth(sqvad) <= sqrt_depth(R) + 1:
                    av0[1] = None
                    return (None, None)
                sqvad1 = radsimp(1 / sqvad)
                res = _mexpand(sqvad / sqrt(2) + v[1] * sqrt(R) * sqvad1 / sqrt(2))
                return (res, f)
            else:
                s2 = _mexpand(v[1] * R) + d
                if s2 <= 0:
                    return (sqrt(nested[-1]), [0] * len(nested))
                FR, s = (root(_mexpand(R), 4), sqrt(s2))
                return (_mexpand(s / (sqrt(2) * FR) + v[0] * FR / (sqrt(2) * s)), f)

def _sqrt_ratcomb(cs, args):
    from sympy.simplify.radsimp import radsimp

    def find(a):
        n = len(a)
        for i in range(n - 1):
            for j in range(i + 1, n):
                s1 = a[i].base
                s2 = a[j].base
                p = _mexpand(s1 * s2)
                s = sqrtdenest(sqrt(p))
                if s != sqrt(p):
                    return (s, i, j)
    indices = find(args)
    if indices is None:
        return Add(*[c * arg for c, arg in zip(cs, args)])
    s, i1, i2 = indices
    c2 = cs.pop(i2)
    args.pop(i2)
    a1 = args[i1]
    cs[i1] += radsimp(c2 * s / a1.base)
    return _sqrt_ratcomb(cs, args)