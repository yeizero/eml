from __future__ import annotations
from typing import overload, TYPE_CHECKING
from collections import defaultdict
from sympy.concrete.products import Product
from sympy.concrete.summations import Sum
from sympy.core import Basic, S, Add, Mul, Pow, Symbol, sympify, expand_func, Function, Dummy, Expr, factor_terms, expand_power_exp, Eq
from sympy.core.exprtools import factor_nc
from sympy.core.parameters import global_parameters
from sympy.core.function import expand_log, count_ops, _mexpand, nfloat, expand_mul, expand
from sympy.core.numbers import Float, I, Integer, pi, Rational, equal_valued
from sympy.core.relational import Relational
from sympy.core.rules import Transform
from sympy.core.sorting import ordered
from sympy.core.sympify import _sympify
from sympy.core.traversal import bottom_up as _bottom_up, walk as _walk
from sympy.functions import gamma, exp, sqrt, log, exp_polar, re
from sympy.functions.combinatorial.factorials import CombinatorialFunction
from sympy.functions.elementary.complexes import unpolarify, Abs, sign
from sympy.functions.elementary.exponential import ExpBase
from sympy.functions.elementary.hyperbolic import HyperbolicFunction
from sympy.functions.elementary.integers import ceiling
from sympy.functions.elementary.piecewise import Piecewise, piecewise_fold, piecewise_simplify
from sympy.functions.elementary.trigonometric import TrigonometricFunction
from sympy.functions.special.bessel import BesselBase, besselj, besseli, besselk, bessely, jn
from sympy.functions.special.tensor_functions import KroneckerDelta
from sympy.integrals.integrals import Integral
from sympy.matrices.expressions import MatrixExpr, MatAdd, MatMul, MatPow, MatrixSymbol
from sympy.polys import together, cancel, factor
from sympy.polys.numberfields.minpoly import _is_sum_surds, _minimal_polynomial_sq
from sympy.simplify.combsimp import combsimp
from sympy.simplify.cse_opts import sub_pre, sub_post
from sympy.simplify.hyperexpand import hyperexpand
from sympy.simplify.powsimp import powsimp
from sympy.simplify.radsimp import radsimp, fraction, collect_abs
from sympy.simplify.sqrtdenest import sqrtdenest
from sympy.simplify.trigsimp import trigsimp, exptrigsimp
from sympy.utilities.decorator import deprecated
from sympy.utilities.iterables import has_variety, sift, subsets, iterable
from sympy.external.mpmath import prec_to_dps, local_workprec, inf as _mpmath_inf, ninf as _mpmath_ninf

def separatevars(expr, symbols=[], dict=False, force=False):
    expr = sympify(expr)
    if dict:
        return _separatevars_dict(_separatevars(expr, force), symbols)
    else:
        return _separatevars(expr, force)

def _separatevars(expr, force):
    if isinstance(expr, Abs):
        arg = expr.args[0]
        if arg.is_Mul and (not arg.is_number):
            s = separatevars(arg, dict=True, force=force)
            if s is not None:
                return Mul(*map(expr.func, s.values()))
            else:
                return expr
    if len(expr.free_symbols) < 2:
        return expr
    if expr.is_Mul:
        args = list(expr.args)
        changed = False
        for i, a in enumerate(args):
            args[i] = separatevars(a, force)
            changed = changed or args[i] != a
        if changed:
            expr = expr.func(*args)
        return expr
    if expr.is_Pow and expr.base != S.Exp1:
        expr = Pow(separatevars(expr.base, force=force), expr.exp)
    expr = expr.expand(mul=False, multinomial=False, force=force)
    _expr, reps = posify(expr) if force else (expr, {})
    expr = factor(_expr).subs(reps)
    if not expr.is_Add:
        return expr
    args = list(expr.args)
    commonc = args[0].args_cnc(cset=True, warn=False)[0]
    for i in args[1:]:
        commonc &= i.args_cnc(cset=True, warn=False)[0]
    commonc = Mul(*commonc)
    commonc = commonc.as_coeff_Mul()[1]
    commonc_set = commonc.args_cnc(cset=True, warn=False)[0]
    for i, a in enumerate(args):
        c, nc = a.args_cnc(cset=True, warn=False)
        c = c - commonc_set
        args[i] = Mul(*c) * Mul(*nc)
    nonsepar = Add(*args)
    if len(nonsepar.free_symbols) > 1:
        _expr = nonsepar
        _expr, reps = posify(_expr) if force else (_expr, {})
        _expr = factor(_expr).subs(reps)
        if not _expr.is_Add:
            nonsepar = _expr
    return commonc * nonsepar

def _separatevars_dict(expr, symbols):
    if symbols:
        if not all((t.is_Atom for t in symbols)):
            raise ValueError('symbols must be Atoms.')
        symbols = list(symbols)
    elif symbols is None:
        return {'coeff': expr}
    else:
        symbols = list(expr.free_symbols)
        if not symbols:
            return None
    ret = {i: [] for i in symbols + ['coeff']}
    for i in Mul.make_args(expr):
        expsym = i.free_symbols
        intersection = set(symbols).intersection(expsym)
        if len(intersection) > 1:
            return None
        if len(intersection) == 0:
            ret['coeff'].append(i)
        else:
            ret[intersection.pop()].append(i)
    for k, v in ret.items():
        ret[k] = Mul(*v)
    return ret

def posify(eq):
    eq = sympify(eq)
    if not isinstance(eq, Basic) and iterable(eq):
        f = type(eq)
        eq = list(eq)
        syms = set()
        for e in eq:
            syms = syms.union(e.atoms(Symbol))
        reps = {}
        for s in syms:
            reps.update({v: k for k, v in posify(s)[1].items()})
        for i, e in enumerate(eq):
            eq[i] = e.subs(reps)
        return (f(eq), {r: s for s, r in reps.items()})
    reps = {s: Dummy(s.name, positive=True, **s.assumptions0) for s in eq.free_symbols if s.is_positive is None}
    eq = eq.subs(reps)
    return (eq, {r: s for s, r in reps.items()})

def hypersimp(f, k):
    f = sympify(f)
    g = f.subs(k, k + 1) / f
    g = g.rewrite(gamma)
    if g.has(Piecewise):
        g = piecewise_fold(g)
        g = g.args[-1][0]
    g = expand_func(g)
    g = powsimp(g, deep=True, combine='exp')
    if g.is_rational_function(k):
        return simplify(g, ratio=S.Infinity)
    else:
        return None

def hypersimilar(f, g, k):
    f, g = list(map(sympify, (f, g)))
    h = (f / g).rewrite(gamma)
    h = h.expand(func=True, basic=False)
    return h.is_rational_function(k)

def signsimp(expr, evaluate=None):
    if evaluate is None:
        evaluate = global_parameters.evaluate
    expr = sympify(expr)
    if not isinstance(expr, (Expr, Relational)) or expr.is_Atom:
        return expr
    e = expr.replace(lambda x: x.is_Mul and --x != x, lambda x: --x)
    e = sub_post(sub_pre(e))
    if not isinstance(e, (Expr, Relational)) or e.is_Atom:
        return e
    if e.is_Add:
        rv = e.func(*[signsimp(a) for a in e.args])
        if not evaluate and isinstance(rv, Add) and rv.could_extract_minus_sign():
            return Mul(S.NegativeOne, -rv, evaluate=False)
        return rv
    if evaluate:
        e = e.replace(lambda x: x.is_Mul and --x != x, lambda x: --x)
    return e

@overload
def simplify(expr: Expr, **kwargs) -> Expr:
    pass

@overload
def simplify(expr: Boolean, **kwargs) -> Boolean:
    pass

@overload
def simplify(expr: Set, **kwargs) -> Set:
    pass

@overload
def simplify(expr: Basic, **kwargs) -> Basic:
    pass

def simplify(expr, ratio=1.7, measure=count_ops, rational=False, inverse=False, doit=True, **kwargs):

    def shorter(*choices):
        if not has_variety(choices):
            return choices[0]
        return min(choices, key=measure)

    def done(e):
        rv = e.doit() if doit else e
        return shorter(rv, collect_abs(rv))
    expr = sympify(expr, rational=rational)
    kwargs = {'ratio': kwargs.get('ratio', ratio), 'measure': kwargs.get('measure', measure), 'rational': kwargs.get('rational', rational), 'inverse': kwargs.get('inverse', inverse), 'doit': kwargs.get('doit', doit)}
    if isinstance(expr, Expr) and expr.is_zero:
        return S.Zero if not expr.is_Number else expr
    _eval_simplify = getattr(expr, '_eval_simplify', None)
    if _eval_simplify is not None:
        return _eval_simplify(**kwargs)
    original_expr = expr = collect_abs(signsimp(expr))
    if not isinstance(expr, Basic) or not expr.args:
        return expr
    if inverse and expr.has(Function):
        expr = inversecombine(expr)
        if not expr.args:
            return expr
    handled = (Add, Mul, Pow, ExpBase)
    expr = expr.replace(lambda x: isinstance(x, Expr) and x.args and (not isinstance(x, handled)), lambda x: x.func(*[simplify(i, **kwargs) for i in x.args]), simultaneous=False)
    if not isinstance(expr, handled):
        return done(expr)
    if not expr.is_commutative:
        expr = nc_simplify(expr)
    floats = False
    if rational is not False and expr.has(Float):
        floats = True
        expr = nsimplify(expr, rational=True)
    expr = _bottom_up(expr, lambda w: getattr(w, 'normal', lambda: w)())
    expr = Mul(*powsimp(expr).as_content_primitive())
    _e = cancel(expr)
    expr1 = shorter(_e, _mexpand(_e).cancel())
    expr2 = shorter(together(expr, deep=True), together(expr1, deep=True))
    if ratio is S.Infinity:
        expr = expr2
    else:
        expr = shorter(expr2, expr1, expr)
    if not isinstance(expr, Basic):
        return expr
    expr = factor_terms(expr, sign=False)
    if expr.has(sign):
        expr = expr.rewrite(Abs)
    if expr.has(Piecewise):
        expr = piecewise_fold(expr)
        expr = done(expr)
        if expr.has(Piecewise):
            expr = piecewise_fold(expr)
            if expr.has(KroneckerDelta):
                expr = kroneckersimp(expr)
            if expr.has(Piecewise):
                expr = piecewise_simplify(expr, deep=True, doit=False)
                if expr.has(Piecewise):
                    expr = shorter(expr, factor_terms(expr))
                    return expr
    expr = hyperexpand(expr)
    if expr.has(KroneckerDelta):
        expr = kroneckersimp(expr)
    if expr.has(BesselBase):
        expr = besselsimp(expr)
    if expr.has(TrigonometricFunction, HyperbolicFunction):
        expr = trigsimp(expr, deep=True)
    if expr.has(log):
        expr = shorter(expand_log(expr, deep=True), logcombine(expr))
    if expr.has(CombinatorialFunction, gamma):
        expr = combsimp(expr)
    if expr.has(Sum):
        expr = sum_simplify(expr, **kwargs)
    if expr.has(Integral):
        expr = expr.xreplace({i: factor_terms(i) for i in expr.atoms(Integral)})
    if expr.has(Product):
        expr = product_simplify(expr, **kwargs)
    short = shorter(powsimp(expr, combine='exp', deep=True), powsimp(expr), expr)
    short = shorter(short, cancel(short))
    short = shorter(short, factor_terms(short), expand_power_exp(expand_mul(short)))
    if short.has(TrigonometricFunction, HyperbolicFunction, ExpBase, exp):
        short = exptrigsimp(short)
    hollow_mul = Transform(lambda x: Mul(*x.args), lambda x: x.is_Mul and len(x.args) == 2 and x.args[0].is_Number and x.args[1].is_Add and x.is_commutative)
    expr = short.xreplace(hollow_mul)
    numer, denom = expr.as_numer_denom()
    if denom.is_Add:
        n, d = fraction(radsimp(1 / denom, symbolic=False, max_terms=1))
        if n is not S.One:
            expr = (numer * n).expand() / d
    if expr.could_extract_minus_sign():
        n, d = fraction(expr)
        if d != 0:
            expr = signsimp(-n / -d)
    if measure(expr) > ratio * measure(original_expr):
        expr = original_expr
    if floats and rational is None:
        expr = nfloat(expr, exponent=False)
    return done(expr)

def sum_simplify(s, **kwargs):
    if not isinstance(s, Add):
        s = s.xreplace({a: sum_simplify(a, **kwargs) for a in s.atoms(Add) if a.has(Sum)})
    s = expand(s)
    if not isinstance(s, Add):
        return s
    terms = s.args
    s_t = []
    o_t = []
    for term in terms:
        sum_terms, other = sift(Mul.make_args(term), lambda i: isinstance(i, Sum), binary=True)
        if not sum_terms:
            o_t.append(term)
            continue
        other = [Mul(*other)]
        s_t.append(Mul(*other + [s._eval_simplify(**kwargs) for s in sum_terms]))
    result = Add(sum_combine(s_t), *o_t)
    return result

def sum_combine(s_t):
    used = [False] * len(s_t)
    for method in range(2):
        for i, s_term1 in enumerate(s_t):
            if not used[i]:
                for j, s_term2 in enumerate(s_t):
                    if not used[j] and i != j:
                        temp = sum_add(s_term1, s_term2, method)
                        if isinstance(temp, (Sum, Mul)):
                            s_t[i] = temp
                            s_term1 = s_t[i]
                            used[j] = True
    result = S.Zero
    for i, s_term in enumerate(s_t):
        if not used[i]:
            result = Add(result, s_term)
    return result

def factor_sum(self, limits=None, radical=False, clear=False, fraction=False, sign=True):
    kwargs = {'radical': radical, 'clear': clear, 'fraction': fraction, 'sign': sign}
    expr = Sum(self, *limits) if limits else self
    return factor_terms(expr, **kwargs)

def sum_add(self, other, method=0):

    def __refactor(val):
        args = Mul.make_args(val)
        sumv = next((x for x in args if isinstance(x, Sum)))
        constant = Mul(*[x for x in args if x != sumv])
        return Sum(constant * sumv.function, *sumv.limits)
    if isinstance(self, Mul):
        rself = __refactor(self)
    else:
        rself = self
    if isinstance(other, Mul):
        rother = __refactor(other)
    else:
        rother = other
    if type(rself) is type(rother):
        if method == 0:
            if rself.limits == rother.limits:
                return factor_sum(Sum(rself.function + rother.function, *rself.limits))
        elif method == 1:
            if simplify(rself.function - rother.function) == 0:
                if len(rself.limits) == len(rother.limits) == 1:
                    i = rself.limits[0][0]
                    x1 = rself.limits[0][1]
                    y1 = rself.limits[0][2]
                    j = rother.limits[0][0]
                    x2 = rother.limits[0][1]
                    y2 = rother.limits[0][2]
                    if i == j:
                        if x2 == y1 + 1:
                            return factor_sum(Sum(rself.function, (i, x1, y2)))
                        elif x1 == y2 + 1:
                            return factor_sum(Sum(rself.function, (i, x2, y1)))
    return Add(self, other)

def product_simplify(s, **kwargs):
    terms = Mul.make_args(s)
    p_t = []
    o_t = []
    deep = kwargs.get('deep', True)
    for term in terms:
        if isinstance(term, Product):
            if deep:
                p_t.append(Product(term.function.simplify(**kwargs), *term.limits))
            else:
                p_t.append(term)
        else:
            o_t.append(term)
    used = [False] * len(p_t)
    for method in range(2):
        for i, p_term1 in enumerate(p_t):
            if not used[i]:
                for j, p_term2 in enumerate(p_t):
                    if not used[j] and i != j:
                        tmp_prod = product_mul(p_term1, p_term2, method)
                        if isinstance(tmp_prod, Product):
                            p_t[i] = tmp_prod
                            used[j] = True
    result = Mul(*o_t)
    for i, p_term in enumerate(p_t):
        if not used[i]:
            result = Mul(result, p_term)
    return result

def product_mul(self, other, method=0):
    if type(self) is type(other):
        if method == 0:
            if self.limits == other.limits:
                return Product(self.function * other.function, *self.limits)
        elif method == 1:
            if simplify(self.function - other.function) == 0:
                if len(self.limits) == len(other.limits) == 1:
                    i = self.limits[0][0]
                    x1 = self.limits[0][1]
                    y1 = self.limits[0][2]
                    j = other.limits[0][0]
                    x2 = other.limits[0][1]
                    y2 = other.limits[0][2]
                    if i == j:
                        if x2 == y1 + 1:
                            return Product(self.function, (i, x1, y2))
                        elif x1 == y2 + 1:
                            return Product(self.function, (i, x2, y1))
    return Mul(self, other)

def _nthroot_solve(p, n, prec):
    from sympy.solvers import solve
    while n % 2 == 0:
        p = sqrtdenest(sqrt(p))
        n = n // 2
    if n == 1:
        return p
    pn = p ** Rational(1, n)
    x = Symbol('x')
    f = _minimal_polynomial_sq(p, n, x)
    if f is None:
        return None
    sols = solve(f, x)
    for sol in sols:
        if abs(sol - pn).n() < 1.0 / 10 ** prec:
            sol = sqrtdenest(sol)
            if _mexpand(sol ** n) == p:
                return sol

def logcombine(expr, force=False):

    def f(rv):
        if not (rv.is_Add or rv.is_Mul):
            return rv

        def gooda(a):
            return a is not S.NegativeOne and (a.is_extended_real or (force and a.is_extended_real is not False))

        def goodlog(l):
            a = l.args[0]
            return a.is_positive or (force and a.is_nonpositive is not False)
        other = []
        logs = []
        log1 = defaultdict(list)
        for a in Add.make_args(rv):
            if isinstance(a, log) and goodlog(a):
                log1[()].append(([], a))
            elif not a.is_Mul:
                other.append(a)
            else:
                ot = []
                co = []
                lo = []
                for ai in a.args:
                    if ai.is_Rational and ai < 0:
                        ot.append(S.NegativeOne)
                        co.append(-ai)
                    elif isinstance(ai, log) and goodlog(ai):
                        lo.append(ai)
                    elif gooda(ai):
                        co.append(ai)
                    else:
                        ot.append(ai)
                if len(lo) > 1:
                    logs.append((ot, co, lo))
                elif lo:
                    log1[tuple(ot)].append((co, lo[0]))
                else:
                    other.append(a)
        if len(other) == 1 and isinstance(other[0], log):
            log1[()].append(([], other.pop()))
        if not logs and all((len(log1[k]) == 1 and log1[k][0] == [] for k in log1)):
            return rv
        for o, e, l in logs:
            l = list(ordered(l))
            e = log(l.pop(0).args[0] ** Mul(*e))
            while l:
                li = l.pop(0)
                e = log(li.args[0] ** e)
            c, l = (Mul(*o), e)
            if isinstance(l, log):
                log1[c,].append(([], l))
            else:
                other.append(c * l)
        for k in list(log1.keys()):
            log1[Mul(*k)] = log(logcombine(Mul(*[l.args[0] ** Mul(*c) for c, l in log1.pop(k)]), force=force), evaluate=False)
        for k in ordered(list(log1.keys())):
            if k not in log1:
                continue
            if -k in log1:
                num, den = (k, -k)
                if num.count_ops() > den.count_ops():
                    num, den = (den, num)
                other.append(num * log(log1.pop(num).args[0] / log1.pop(den).args[0], evaluate=False))
            else:
                other.append(k * log1.pop(k))
        return Add(*other)
    return _bottom_up(expr, f)

def inversecombine(expr):

    def f(rv):
        if isinstance(rv, log):
            if isinstance(rv.args[0], exp) or (rv.args[0].is_Pow and rv.args[0].base == S.Exp1):
                rv = rv.args[0].exp
        elif rv.is_Function and hasattr(rv, 'inverse'):
            if len(rv.args) == 1 and len(rv.args[0].args) == 1 and isinstance(rv.args[0], rv.inverse(argindex=1)):
                rv = rv.args[0].args[0]
        if rv.is_Pow and rv.base == S.Exp1:
            if isinstance(rv.exp, log):
                rv = rv.exp.args[0]
        return rv
    return _bottom_up(expr, f)

def kroneckersimp(expr):

    def args_cancel(args1, args2):
        for i1 in range(2):
            for i2 in range(2):
                a1 = args1[i1]
                a2 = args2[i2]
                a3 = args1[(i1 + 1) % 2]
                a4 = args2[(i2 + 1) % 2]
                if Eq(a1, a2) is S.true and Eq(a3, a4) is S.false:
                    return True
        return False

    def cancel_kronecker_mul(m):
        args = m.args
        deltas = [a for a in args if isinstance(a, KroneckerDelta)]
        for delta1, delta2 in subsets(deltas, 2):
            args1 = delta1.args
            args2 = delta2.args
            if args_cancel(args1, args2):
                return S.Zero * m
        return m
    if not expr.has(KroneckerDelta):
        return expr
    if expr.has(Piecewise):
        expr = expr.rewrite(KroneckerDelta)
    newexpr = expr
    expr = None
    while newexpr != expr:
        expr = newexpr
        newexpr = expr.replace(lambda e: isinstance(e, Mul), cancel_kronecker_mul)
    return expr

def besselsimp(expr):

    def replacer(fro, to, factors):
        factors = set(factors)

        def repl(nu, z):
            if factors.intersection(Mul.make_args(z)):
                return to(nu, z)
            return fro(nu, z)
        return repl

    def torewrite(fro, to):

        def tofunc(nu, z):
            return fro(nu, z).rewrite(to)
        return tofunc

    def tominus(fro):

        def tofunc(nu, z):
            return exp(I * pi * nu) * fro(nu, exp_polar(-I * pi) * z)
        return tofunc
    orig_expr = expr
    ifactors = [I, exp_polar(I * pi / 2), exp_polar(-I * pi / 2)]
    expr = expr.replace(besselj, replacer(besselj, torewrite(besselj, besseli), ifactors))
    expr = expr.replace(besseli, replacer(besseli, torewrite(besseli, besselj), ifactors))
    minusfactors = [-1, exp_polar(I * pi)]
    expr = expr.replace(besselj, replacer(besselj, tominus(besselj), minusfactors))
    expr = expr.replace(besseli, replacer(besseli, tominus(besseli), minusfactors))
    z0 = Dummy('z')

    def expander(fro):

        def repl(nu, z):
            if nu % 1 == S.Half:
                return simplify(trigsimp(unpolarify(fro(nu, z0).rewrite(besselj).rewrite(jn).expand(func=True)).subs(z0, z)))
            elif nu.is_Integer and nu > 1:
                return fro(nu, z).expand(func=True)
            return fro(nu, z)
        return repl
    expr = expr.replace(besselj, expander(besselj))
    expr = expr.replace(bessely, expander(bessely))
    expr = expr.replace(besseli, expander(besseli))
    expr = expr.replace(besselk, expander(besselk))

    def _bessel_simp_recursion(expr):

        def _use_recursion(bessel, expr):
            while True:
                bessels = expr.find(lambda x: isinstance(x, bessel))
                try:
                    for ba in sorted(bessels, key=lambda x: re(x.args[0])):
                        a, x = ba.args
                        bap1 = bessel(a + 1, x)
                        bap2 = bessel(a + 2, x)
                        if expr.has(bap1) and expr.has(bap2):
                            expr = expr.subs(ba, 2 * (a + 1) / x * bap1 - bap2)
                            break
                    else:
                        return expr
                except (ValueError, TypeError):
                    return expr
        if expr.has(besselj):
            expr = _use_recursion(besselj, expr)
        if expr.has(bessely):
            expr = _use_recursion(bessely, expr)
        return expr
    expr = _bessel_simp_recursion(expr)
    if expr != orig_expr:
        expr = expr.factor()
    return expr

def nthroot(expr, n, max_len=4, prec=15):
    expr = sympify(expr)
    n = sympify(n)
    p = expr ** Rational(1, n)
    if not n.is_integer:
        return p
    if not _is_sum_surds(expr):
        return p
    surds = []
    coeff_muls = [x.as_coeff_Mul() for x in expr.args]
    for x, y in coeff_muls:
        if not x.is_rational:
            return p
        if y is S.One:
            continue
        if not (y.is_Pow and y.exp == S.Half and y.base.is_integer):
            return p
        surds.append(y)
    surds.sort()
    surds = surds[:max_len]
    if expr < 0 and n % 2 == 1:
        p = (-expr) ** Rational(1, n)
        a = nsimplify(p, constants=surds)
        res = a if _mexpand(a ** n) == _mexpand(-expr) else p
        return -res
    a = nsimplify(p, constants=surds)
    if _mexpand(a) is not _mexpand(p) and _mexpand(a ** n) == _mexpand(expr):
        return _mexpand(a)
    expr = _nthroot_solve(expr, n, prec)
    if expr is None:
        return p
    return expr

def nsimplify(expr, constants=(), tolerance=None, full=False, rational=None, rational_conversion='base10'):
    expr = sympify(expr)
    if isinstance(expr, Integer):
        return expr
    expr = expr.xreplace({Float('inf'): S.Infinity, Float('-inf'): S.NegativeInfinity})
    if expr is S.Infinity or expr is S.NegativeInfinity:
        return expr
    if rational or expr.free_symbols:
        return _real_to_rational(expr, tolerance, rational_conversion)
    if tolerance is None:
        tolerance = 10 ** (-min([15] + [prec_to_dps(n._prec) for n in expr.atoms(Float)]))
    prec = 30
    bprec = int(prec * 3.33)
    constants_dict = {}
    for constant in constants:
        constant = sympify(constant)
        v = constant.evalf(prec)
        if not v.is_Float:
            raise ValueError('constants must be real-valued')
        constants_dict[str(constant)] = v._to_mpmath(bprec)
    exprval = expr.evalf(prec, chop=True)
    re, im = exprval.as_real_imag()
    if not (re.is_Number and im.is_Number):
        return expr

    def nsimplify_real(x):
        xv = x._to_mpmath(bprec)
        with local_workprec(prec) as ctx:
            if not (tolerance or full):
                ctx.dps = 15
                rat = ctx.pslq([xv, 1])
                if rat is not None:
                    return Rational(-int(rat[1]), int(rat[0]))
            ctx.dps = prec
            newexpr = ctx.identify(xv, constants=constants_dict, tol=tolerance, full=full)
            if not newexpr:
                raise ValueError
            if full:
                newexpr = newexpr[0]
            expr = sympify(newexpr)
            if x and (not expr):
                raise ValueError
            if expr.is_finite is False and xv not in [_mpmath_inf, _mpmath_ninf]:
                raise ValueError
            return expr
    try:
        if re:
            re = nsimplify_real(re)
        if im:
            im = nsimplify_real(im)
    except ValueError:
        if rational is None:
            return _real_to_rational(expr, rational_conversion=rational_conversion)
        return expr
    rv = re + im * S.ImaginaryUnit
    if rv != expr or rational is False:
        return rv
    return _real_to_rational(expr, rational_conversion=rational_conversion)

def _real_to_rational(expr, tolerance=None, rational_conversion='base10'):
    expr = _sympify(expr)
    inf = Float('inf')
    p = expr
    reps = {}
    reduce_num = None
    if tolerance is not None and tolerance < 1:
        reduce_num = ceiling(1 / tolerance)
    for fl in p.atoms(Float):
        key = fl
        if reduce_num is not None:
            r = Rational(fl).limit_denominator(reduce_num)
        elif tolerance is not None and tolerance >= 1 and (fl.is_Integer is False):
            r = Rational(tolerance * round(fl / tolerance)).limit_denominator(int(tolerance))
        else:
            if rational_conversion == 'exact':
                r = Rational(fl)
                reps[key] = r
                continue
            elif rational_conversion != 'base10':
                raise ValueError("rational_conversion must be 'base10' or 'exact'")
            r = nsimplify(fl, rational=False)
            if fl and (not r):
                r = Rational(fl)
            elif not r.is_Rational:
                if fl in (inf, -inf):
                    r = S.ComplexInfinity
                elif fl < 0:
                    fl = -fl
                    with local_workprec(53) as ctx:
                        d = Pow(10, int(ctx.log(fl) / ctx.log(10)))
                    r = -Rational(str(fl / d)) * d
                elif fl > 0:
                    with local_workprec(53) as ctx:
                        d = Pow(10, int(ctx.log(fl) / ctx.log(10)))
                    r = Rational(str(fl / d)) * d
                else:
                    r = S.Zero
        reps[key] = r
    return p.subs(reps, simultaneous=True)

def clear_coefficients(expr: Expr, rhs: Expr=S.Zero) -> tuple[Expr, Expr]:
    was = None
    free = expr.free_symbols
    if expr.is_Rational:
        return (S.Zero, rhs - expr)
    while expr and was != expr:
        was = expr
        m, expr = expr.as_content_primitive() if free else factor_terms(expr).as_coeff_Mul(rational=True)
        rhs /= m
        c, expr = expr.as_coeff_Add(rational=True)
        rhs -= c
    expr = signsimp(expr, evaluate=False)
    if expr.could_extract_minus_sign():
        expr = -expr
        rhs = -rhs
    return (expr, rhs)

def nc_simplify(expr, deep=True):
    if isinstance(expr, MatrixExpr):
        expr = expr.doit(inv_expand=False)
        _Add, _Mul, _Pow, _Symbol = (MatAdd, MatMul, MatPow, MatrixSymbol)
    else:
        _Add, _Mul, _Pow, _Symbol = (Add, Mul, Pow, Symbol)

    def _overlaps(args):
        m = [[[1, 0] if a == args[0] else [0] for a in args[1:]]]
        for i in range(1, len(args)):
            overlaps = []
            j = 0
            for j in range(len(args) - i - 1):
                overlap = []
                for v in m[i - 1][j + 1]:
                    if j + i + 1 + v < len(args) and args[i] == args[j + i + 1 + v]:
                        overlap.append(v + 1)
                overlap += [0]
                overlaps.append(overlap)
            m.append(overlaps)
        return m

    def _reduce_inverses(_args):
        inv_tot = 0
        inverses = []
        args = []
        for arg in _args:
            if isinstance(arg, _Pow) and arg.args[1].is_extended_negative:
                inverses = [arg ** (-1)] + inverses
                inv_tot += 1
            else:
                if len(inverses) == 1:
                    args.append(inverses[0] ** (-1))
                elif len(inverses) > 1:
                    args.append(_Pow(_Mul(*inverses), -1))
                    inv_tot -= len(inverses) - 1
                inverses = []
                args.append(arg)
        if inverses:
            args.append(_Pow(_Mul(*inverses), -1))
            inv_tot -= len(inverses) - 1
        return (inv_tot, tuple(args))

    def get_score(s):
        if isinstance(s, _Pow):
            return get_score(s.args[0])
        elif isinstance(s, (_Add, _Mul)):
            return sum((get_score(a) for a in s.args))
        return 1

    def compare(s, alt_s):
        if s != alt_s and get_score(alt_s) < get_score(s):
            return alt_s
        return s
    if not isinstance(expr, (_Add, _Mul, _Pow)) or expr.is_commutative:
        return expr
    args = expr.args[:]
    if isinstance(expr, _Pow):
        if deep:
            return _Pow(nc_simplify(args[0]), args[1]).doit()
        else:
            return expr
    elif isinstance(expr, _Add):
        return _Add(*[nc_simplify(a, deep=deep) for a in args]).doit()
    else:
        c_args, args = expr.args_cnc()
        com_coeff = Mul(*c_args)
        if not equal_valued(com_coeff, 1):
            return com_coeff * nc_simplify(expr / com_coeff, deep=deep)
    inv_tot, args = _reduce_inverses(args)
    invert = False
    if inv_tot > len(args) / 2:
        invert = True
        args = [a ** (-1) for a in args[::-1]]
    if deep:
        args = tuple((nc_simplify(a) for a in args))
    m = _overlaps(args)
    simps = {}
    post = 1
    pre = 1
    max_simp_coeff = 0
    simp = None
    for i in range(1, len(args)):
        simp_coeff = 0
        l = 0
        p = 0
        if i < len(args) - 1:
            rep = m[i][0]
        start = i
        end = i + 1
        if i == len(args) - 1 or rep == [0]:
            if isinstance(args[i], _Pow) and (not isinstance(args[i].args[0], _Symbol)):
                subterm = args[i].args[0].args
                l = len(subterm)
                if args[i - l:i] == subterm and args[i].args[0] == _Mul(*subterm):
                    p += 1
                    start -= l
                if args[i + 1:i + 1 + l] == subterm and args[i].args[0] == _Mul(*subterm):
                    p += 1
                    end += l
            if p:
                p += args[i].args[1]
            else:
                continue
        else:
            l = rep[0]
            start -= l - 1
            subterm = args[start:end]
            p = 2
            end += l
        if subterm in simps and simps[subterm] >= start:
            continue
        while end < len(args):
            if l in m[end - 1][0]:
                p += 1
                end += l
            elif isinstance(args[end], _Pow) and args[end].args[0].args == subterm:
                p += args[end].args[1]
                end += 1
            else:
                break
        pre_exp = 0
        pre_arg = 1
        if start - l >= 0 and args[start - l + 1:start] == subterm[1:]:
            if isinstance(subterm[0], _Pow):
                pre_arg = subterm[0].args[0]
                exp = subterm[0].args[1]
            else:
                pre_arg = subterm[0]
                exp = 1
            if isinstance(args[start - l], _Pow) and args[start - l].args[0] == pre_arg:
                pre_exp = args[start - l].args[1] - exp
                start -= l
                p += 1
            elif args[start - l] == pre_arg:
                pre_exp = 1 - exp
                start -= l
                p += 1
        post_exp = 0
        post_arg = 1
        if end + l - 1 < len(args) and args[end:end + l - 1] == subterm[:-1]:
            if isinstance(subterm[-1], _Pow):
                post_arg = subterm[-1].args[0]
                exp = subterm[-1].args[1]
            else:
                post_arg = subterm[-1]
                exp = 1
            if isinstance(args[end + l - 1], _Pow) and args[end + l - 1].args[0] == post_arg:
                post_exp = args[end + l - 1].args[1] - exp
                end += l
                p += 1
            elif args[end + l - 1] == post_arg:
                post_exp = 1 - exp
                end += l
                p += 1
        if post_exp and exp % 2 == 0 and (start > 0):
            exp = exp / 2
            _pre_exp = 1
            _post_exp = 1
            if isinstance(args[start - 1], _Pow) and args[start - 1].args[0] == post_arg:
                _post_exp = post_exp + exp
                _pre_exp = args[start - 1].args[1] - exp
            elif args[start - 1] == post_arg:
                _post_exp = post_exp + exp
                _pre_exp = 1 - exp
            if _pre_exp == 0 or _post_exp == 0:
                if not pre_exp:
                    start -= 1
                post_exp = _post_exp
                pre_exp = _pre_exp
                pre_arg = post_arg
                subterm = (post_arg ** exp,) + subterm[:-1] + (post_arg ** exp,)
        simp_coeff += end - start
        if post_exp:
            simp_coeff -= 1
        if pre_exp:
            simp_coeff -= 1
        simps[subterm] = end
        if simp_coeff > max_simp_coeff:
            max_simp_coeff = simp_coeff
            simp = (start, _Mul(*subterm), p, end, l)
            pre = pre_arg ** pre_exp
            post = post_arg ** post_exp
    if simp:
        subterm = _Pow(nc_simplify(simp[1], deep=deep), simp[2])
        pre = nc_simplify(_Mul(*args[:simp[0]]) * pre, deep=deep)
        post = post * nc_simplify(_Mul(*args[simp[3]:]), deep=deep)
        simp = pre * subterm * post
        if pre != 1 or post != 1:
            simp = nc_simplify(simp, deep=False)
    else:
        simp = _Mul(*args)
    if invert:
        simp = _Pow(simp, -1)
    if not isinstance(expr, MatrixExpr):
        f_expr = factor_nc(expr)
        if f_expr != expr:
            alt_simp = nc_simplify(f_expr, deep=deep)
            simp = compare(simp, alt_simp)
    else:
        simp = simp.doit(inv_expand=False)
    return simp

@overload
def dotprodsimp(expr: Expr, withsimp: Literal[False]=False) -> Expr:
    pass

@overload
def dotprodsimp(expr: Expr, withsimp: Literal[True]) -> tuple[Expr, bool]:
    pass

@overload
def dotprodsimp(expr: Expr, withsimp: bool) -> Expr | tuple[Expr, bool]:
    pass

def dotprodsimp(expr: Expr, withsimp: bool=False) -> Expr | tuple[Expr, bool]:

    def count_ops_alg(expr: Expr) -> tuple[int, bool]:
        ops = 0
        args: list[Basic] = [expr]
        ratfunc = False
        while args:
            a = args.pop()
            if not isinstance(a, Basic):
                continue
            if isinstance(a, Rational):
                if a is not S.One:
                    ops += bool(a.p < 0) + bool(a.q != 1)
            elif isinstance(a, Mul):
                if a.could_extract_minus_sign():
                    ops += 1
                    if a.args[0] is S.NegativeOne:
                        a = a.as_two_terms()[1]
                    else:
                        a = -a
                n, d = fraction(a)
                if n.is_Integer:
                    ops += 1 + bool(n < 0)
                    args.append(d)
                elif d is not S.One:
                    if not d.is_Integer:
                        args.append(d)
                        ratfunc = True
                    ops += 1
                    args.append(n)
                else:
                    ops += len(a.args) - 1
                    args.extend(a.args)
            elif isinstance(a, Add):
                laargs = len(a.args)
                negs = 0
                for ai in a.args:
                    if ai.could_extract_minus_sign():
                        negs += 1
                        ai = -ai
                    args.append(ai)
                ops += laargs - (negs != laargs)
            elif isinstance(a, Pow):
                ops += 1
                args.append(a.base)
                if not ratfunc:
                    ratfunc = a.exp.is_negative is not False
        return (ops, ratfunc)

    def nonalg_subs_dummies(expr: Expr, dummies: dict[Expr, Dummy]) -> Expr:
        if not expr.args:
            return expr
        if isinstance(expr, (Add, Mul, Pow)):
            args = None
            for i, a in enumerate(expr.args):
                c = nonalg_subs_dummies(a, dummies)
                if c is a:
                    continue
                if args is None:
                    args = list(expr.args)
                args[i] = c
            if args is None:
                return expr
            return expr.func(*args)
        return dummies.setdefault(expr, Dummy())
    simplified = False
    if isinstance(expr, Basic) and (expr.is_Add or expr.is_Mul or expr.is_Pow):
        expr2 = expr.expand(deep=True, modulus=None, power_base=False, power_exp=False, mul=True, log=False, multinomial=True, basic=False)
        if expr2 != expr:
            expr = expr2
            simplified = True
        exprops, ratfunc = count_ops_alg(expr)
        if exprops >= 6:
            if ratfunc:
                dummies: dict[Expr, Dummy] = {}
                expr2 = nonalg_subs_dummies(expr, dummies)
                if expr2 is expr or count_ops_alg(expr2)[0] >= 6:
                    expr3 = cancel(expr2)
                    if expr3 != expr2:
                        expr = expr3.subs([(d, e) for e, d in dummies.items()])
                        simplified = True
        elif exprops == 5 and expr.is_Add and expr.args[0].is_Mul and expr.args[1].is_Mul and expr.args[0].args[-1].is_Pow and expr.args[1].args[-1].is_Pow and (expr.args[0].args[-1].exp is S.NegativeOne) and (expr.args[1].args[-1].exp is S.NegativeOne):
            expr2 = together(expr)
            expr2ops = count_ops_alg(expr2)[0]
            if expr2ops < exprops:
                expr = expr2
                simplified = True
        else:
            simplified = True
    return (expr, simplified) if withsimp else expr
bottom_up = deprecated('\nbottom_up', deprecated_since_version='1.10', active_deprecations_target='deprecated-traversal-functions-moved')(_bottom_up)
walk = deprecated('\nwalk    ', deprecated_since_version='1.10', active_deprecations_target='deprecated-traversal-functions-moved')(_walk)