from __future__ import annotations
from collections import defaultdict
from sympy.core import sympify, S, Mul, Derivative, Pow
from sympy.core.add import _unevaluated_Add, Add
from sympy.core.assumptions import assumptions
from sympy.core.exprtools import Factors, gcd_terms
from sympy.core.function import _mexpand, expand_mul, expand_power_base
from sympy.core.mul import _keep_coeff, _unevaluated_Mul, _mulsort
from sympy.core.numbers import Rational, zoo, nan
from sympy.core.parameters import global_parameters
from sympy.core.sorting import ordered, default_sort_key
from sympy.core.symbol import Dummy, Wild, symbols
from sympy.functions import exp, sqrt, log
from sympy.functions.elementary.complexes import Abs
from sympy.polys import gcd
from sympy.simplify.sqrtdenest import sqrtdenest
from sympy.utilities.iterables import iterable, sift

def collect(expr, syms, func=None, evaluate=None, exact=False, distribute_order_term=True):
    expr = sympify(expr)
    syms = [sympify(i) for i in (syms if iterable(syms) else [syms])]
    cond = lambda x: x.is_Symbol or (-x).is_Symbol or bool(x.atoms(Wild))
    _, nonsyms = sift(syms, cond, binary=True)
    if nonsyms:
        reps = dict(zip(nonsyms, [Dummy(**assumptions(i)) for i in nonsyms]))
        syms = [reps.get(s, s) for s in syms]
        rv = collect(expr.subs(reps), syms, func=func, evaluate=evaluate, exact=exact, distribute_order_term=distribute_order_term)
        urep = {v: k for k, v in reps.items()}
        if not isinstance(rv, dict):
            return rv.xreplace(urep)
        else:
            return {urep.get(k, k).xreplace(urep): v.xreplace(urep) for k, v in rv.items()}
    if exact is None:
        _syms = set()
        for i in Add.make_args(expr):
            if not i.has_free(*syms) or i in syms:
                continue
            if not i.is_Mul and i not in syms:
                _syms.add(i)
            else:
                g = i._new_rawargs(*i.as_coeff_mul(*syms)[1])
                if g not in syms:
                    _syms.add(g)
        simple = all((i.is_Pow and i.base in syms for i in _syms))
        syms = syms + list(ordered(_syms))
        if not simple:
            return collect(expr, syms, func=func, evaluate=evaluate, exact=False, distribute_order_term=distribute_order_term)
    if evaluate is None:
        evaluate = global_parameters.evaluate

    def make_expression(terms):
        product = []
        for term, rat, sym, deriv in terms:
            if deriv is not None:
                var, order = deriv
                for _ in range(order):
                    term = Derivative(term, var)
            if sym is None:
                if rat is S.One:
                    product.append(term)
                else:
                    product.append(Pow(term, rat))
            else:
                product.append(Pow(term, rat * sym))
        return Mul(*product)

    def parse_derivative(deriv):
        expr, sym, order = (deriv.expr, deriv.variables[0], 1)
        for s in deriv.variables[1:]:
            if s == sym:
                order += 1
            else:
                raise NotImplementedError('Improve MV Derivative support in collect')
        while isinstance(expr, Derivative):
            s0 = expr.variables[0]
            if any((s != s0 for s in expr.variables)):
                raise NotImplementedError('Improve MV Derivative support in collect')
            if s0 == sym:
                expr, order = (expr.expr, order + len(expr.variables))
            else:
                break
        return (expr, (sym, Rational(order)))

    def parse_term(expr):
        rat_expo, sym_expo = (S.One, None)
        sexpr, deriv = (expr, None)
        if expr.is_Pow:
            if isinstance(expr.base, Derivative):
                sexpr, deriv = parse_derivative(expr.base)
            else:
                sexpr = expr.base
            if expr.base == S.Exp1:
                arg = expr.exp
                if arg.is_Rational:
                    sexpr, rat_expo = (S.Exp1, arg)
                elif arg.is_Mul:
                    coeff, tail = arg.as_coeff_Mul(rational=True)
                    sexpr, rat_expo = (exp(tail), coeff)
            elif expr.exp.is_Number:
                rat_expo = expr.exp
            else:
                coeff, tail = expr.exp.as_coeff_Mul()
                if coeff.is_Number:
                    rat_expo, sym_expo = (coeff, tail)
                else:
                    sym_expo = expr.exp
        elif isinstance(expr, exp):
            arg = expr.exp
            if arg.is_Rational:
                sexpr, rat_expo = (S.Exp1, arg)
            elif arg.is_Mul:
                coeff, tail = arg.as_coeff_Mul(rational=True)
                sexpr, rat_expo = (exp(tail), coeff)
        elif isinstance(expr, Derivative):
            sexpr, deriv = parse_derivative(expr)
        return (sexpr, rat_expo, sym_expo, deriv)

    def parse_expression(terms, pattern):
        pattern = Mul.make_args(pattern)
        if len(terms) < len(pattern):
            return None
        else:
            pattern = [parse_term(elem) for elem in pattern]
            terms = terms[:]
            elems, common_expo, has_deriv = ([], None, False)
            for elem, e_rat, e_sym, e_ord in pattern:
                if elem.is_Number and e_rat == 1 and (e_sym is None):
                    continue
                for j in range(len(terms)):
                    if terms[j] is None:
                        continue
                    term, t_rat, t_sym, t_ord = terms[j]
                    if t_ord is not None:
                        has_deriv = True
                    if term.match(elem) is not None and (t_sym == e_sym or (t_sym is not None and e_sym is not None and (t_sym.match(e_sym) is not None))):
                        if exact is False:
                            expo = t_rat / e_rat
                            if common_expo is None:
                                common_expo = expo
                            elif common_expo != expo:
                                common_expo = 1
                        elif e_rat != t_rat or e_ord != t_ord:
                            continue
                        elems.append(terms[j])
                        terms[j] = None
                        break
                else:
                    return None
            return ([_f for _f in terms if _f], elems, common_expo, has_deriv)
    if evaluate:
        if expr.is_Add:
            o = expr.getO() or 0
            expr = expr.func(*[collect(a, syms, func, True, exact, distribute_order_term) for a in expr.args if a != o]) + o
        elif expr.is_Mul:
            return expr.func(*[collect(term, syms, func, True, exact, distribute_order_term) for term in expr.args])
        elif expr.is_Pow:
            b = collect(expr.base, syms, func, True, exact, distribute_order_term)
            return Pow(b, expr.exp)
    syms = [expand_power_base(i, deep=False) for i in syms]
    order_term = None
    if distribute_order_term:
        order_term = expr.getO()
        if order_term is not None:
            if order_term.has(*syms):
                order_term = None
            else:
                expr = expr.removeO()
    summa = [expand_power_base(i, deep=False) for i in Add.make_args(expr)]
    collected, disliked = (defaultdict(list), S.Zero)
    for product in summa:
        c, nc = product.args_cnc(split_1=False)
        args = list(ordered(c)) + nc
        terms = [parse_term(i) for i in args]
        small_first = True
        for symbol in syms:
            if isinstance(symbol, Derivative) and small_first:
                terms = list(reversed(terms))
                small_first = not small_first
            result = parse_expression(terms, symbol)
            if result is not None:
                if not symbol.is_commutative:
                    raise AttributeError('Can not collect noncommutative symbol')
                terms, elems, common_expo, has_deriv = result
                if not has_deriv:
                    margs = []
                    for elem in elems:
                        if elem[2] is None:
                            e = elem[1]
                        else:
                            e = elem[1] * elem[2]
                        margs.append(Pow(elem[0], e))
                    index = Mul(*margs)
                else:
                    index = make_expression(elems)
                terms = expand_power_base(make_expression(terms), deep=False)
                index = expand_power_base(index, deep=False)
                collected[index].append(terms)
                break
        else:
            disliked += product
    collected = {k: Add(*v) for k, v in collected.items()}
    if disliked is not S.Zero:
        collected[S.One] = disliked
    if order_term is not None:
        for key, val in collected.items():
            collected[key] = val + order_term
    if func is not None:
        collected = {key: func(val) for key, val in collected.items()}
    if evaluate:
        return Add(*[key * val for key, val in collected.items()])
    else:
        return collected

def rcollect(expr, *vars):
    if expr.is_Atom or not expr.has(*vars):
        return expr
    else:
        expr = expr.__class__(*[rcollect(arg, *vars) for arg in expr.args])
        if expr.is_Add:
            return collect(expr, vars)
        else:
            return expr

def collect_sqrt(expr, evaluate=None):
    if evaluate is None:
        evaluate = global_parameters.evaluate
    coeff, expr = expr.as_content_primitive()
    vars = set()
    for a in Add.make_args(expr):
        for m in a.args_cnc()[0]:
            if m.is_number and (m.is_Pow and m.exp.is_Rational and (m.exp.q == 2) or m is S.ImaginaryUnit):
                vars.add(m)
    d = collect_const(expr, *vars, Numbers=False)
    hit = expr != d
    if not evaluate:
        nrad = 0
        args = list(ordered(Add.make_args(d)))
        for i, m in enumerate(args):
            c, nc = m.args_cnc()
            for ci in c:
                if ci.is_Pow and ci.exp.is_Rational and (ci.exp.q == 2) or ci is S.ImaginaryUnit:
                    nrad += 1
                    break
            args[i] *= coeff
        if not (hit or nrad):
            args = [Add(*args)]
        return (tuple(args), nrad)
    return coeff * d

def collect_abs(expr):

    def _abs(mul):
        c, nc = mul.args_cnc()
        a = []
        o = []
        for i in c:
            if isinstance(i, Abs):
                a.append(i.args[0])
            elif isinstance(i, Pow) and isinstance(i.base, Abs) and i.exp.is_real:
                a.append(i.base.args[0] ** i.exp)
            else:
                o.append(i)
        if len(a) < 2 and (not any((i.exp.is_negative for i in a if isinstance(i, Pow)))):
            return mul
        absarg = Mul(*a)
        A = Abs(absarg)
        args = [A]
        args.extend(o)
        if not A.has(Abs):
            args.extend(nc)
            return Mul(*args)
        if not isinstance(A, Abs):
            A = Abs(absarg, evaluate=False)
        args[0] = A
        _mulsort(args)
        args.extend(nc)
        return Mul._from_args(args, is_commutative=not nc)
    return expr.replace(lambda x: isinstance(x, Mul), lambda x: _abs(x)).replace(lambda x: isinstance(x, Pow), lambda x: _abs(x))

def collect_const(expr, *vars, Numbers=True):
    if not expr.is_Add:
        return expr
    recurse = False
    if not vars:
        recurse = True
        vars = set()
        for a in expr.args:
            for m in Mul.make_args(a):
                if m.is_number:
                    vars.add(m)
    else:
        vars = sympify(vars)
    if not Numbers:
        vars = [v for v in vars if not v.is_Number]
    vars = list(ordered(vars))
    for v in vars:
        terms = defaultdict(list)
        Fv = Factors(v)
        for m in Add.make_args(expr):
            f = Factors(m)
            q, r = f.div(Fv)
            if r.is_one:
                fwas = f.factors.copy()
                fnow = q.factors
                if not any((k in fwas and fwas[k].is_Integer and (not fnow[k].is_Integer) for k in fnow)):
                    terms[v].append(q.as_expr())
                    continue
            terms[S.One].append(m)
        args = []
        hit = False
        uneval = False
        for k in ordered(terms):
            v = terms[k]
            if k is S.One:
                args.extend(v)
                continue
            if len(v) > 1:
                v = Add(*v)
                hit = True
                if recurse and v != expr:
                    vars.append(v)
            else:
                v = v[0]
            if Numbers and k.is_Number and v.is_Add:
                args.append(_keep_coeff(k, v, sign=True))
                uneval = True
            else:
                args.append(k * v)
        if hit:
            if uneval:
                expr = _unevaluated_Add(*args)
            else:
                expr = Add(*args)
            if not expr.is_Add:
                break
    return expr

def radsimp(expr, symbolic=True, max_terms=4):
    from sympy.core.expr import Expr
    from sympy.simplify.simplify import signsimp
    syms = symbols('a:d A:D')

    def _num(rterms):
        a, b, c, d, A, B, C, D = syms
        if len(rterms) == 2:
            reps = dict(list(zip([A, a, B, b], [j for i in rterms for j in i])))
            return (sqrt(A) * a - sqrt(B) * b).xreplace(reps)
        if len(rterms) == 3:
            reps = dict(list(zip([A, a, B, b, C, c], [j for i in rterms for j in i])))
            return ((sqrt(A) * a + sqrt(B) * b - sqrt(C) * c) * (2 * sqrt(A) * sqrt(B) * a * b - A * a ** 2 - B * b ** 2 + C * c ** 2)).xreplace(reps)
        elif len(rterms) == 4:
            reps = dict(list(zip([A, a, B, b, C, c, D, d], [j for i in rterms for j in i])))
            return ((sqrt(A) * a + sqrt(B) * b - sqrt(C) * c - sqrt(D) * d) * (2 * sqrt(A) * sqrt(B) * a * b - A * a ** 2 - B * b ** 2 - 2 * sqrt(C) * sqrt(D) * c * d + C * c ** 2 + D * d ** 2) * (-8 * sqrt(A) * sqrt(B) * sqrt(C) * sqrt(D) * a * b * c * d + A ** 2 * a ** 4 - 2 * A * B * a ** 2 * b ** 2 - 2 * A * C * a ** 2 * c ** 2 - 2 * A * D * a ** 2 * d ** 2 + B ** 2 * b ** 4 - 2 * B * C * b ** 2 * c ** 2 - 2 * B * D * b ** 2 * d ** 2 + C ** 2 * c ** 4 - 2 * C * D * c ** 2 * d ** 2 + D ** 2 * d ** 4)).xreplace(reps)
        elif len(rterms) == 1:
            return sqrt(rterms[0][0])
        else:
            raise NotImplementedError

    def ispow2(d, log2=False):
        if not d.is_Pow:
            return False
        e = d.exp
        if e.is_Rational and e.q == 2 or (symbolic and denom(e) == 2):
            return True
        if log2:
            q = 1
            if e.is_Rational:
                q = e.q
            elif symbolic:
                d = denom(e)
                if d.is_Integer:
                    q = d
            if q != 1 and log(q, 2).is_Integer:
                return True
        return False

    def handle(expr):
        from sympy.simplify.simplify import nsimplify
        if expr.is_Atom:
            return expr
        elif not isinstance(expr, Expr):
            return expr.func(*[handle(a) for a in expr.args])
        n, d = fraction(expr)
        if d.is_Atom and n.is_Atom:
            return expr
        elif not n.is_Atom:
            n = n.func(*[handle(a) for a in n.args])
            return _unevaluated_Mul(n, handle(1 / d))
        elif n is not S.One:
            return _unevaluated_Mul(n, handle(1 / d))
        elif d.is_Mul:
            return _unevaluated_Mul(*[handle(1 / d) for d in d.args])
        if not symbolic and d.free_symbols:
            return expr
        if ispow2(d):
            d2 = sqrtdenest(sqrt(d.base)) ** numer(d.exp)
            if d2 != d:
                return handle(1 / d2)
        elif d.is_Pow and (d.exp.is_integer or d.base.is_positive):
            return handle(1 / d.base) ** d.exp
        if not (d.is_Add or ispow2(d)):
            return 1 / d.func(*[handle(a) for a in d.args])
        keep = True
        d = _mexpand(d)
        if d.is_Atom:
            return 1 / d
        if d.is_number:
            _d = nsimplify(d)
            if _d.is_Number and _d.equals(d):
                return 1 / _d
        while True:
            collected = defaultdict(list)
            for m in Add.make_args(d):
                p2 = []
                other = []
                for i in Mul.make_args(m):
                    if ispow2(i, log2=True):
                        p2.append(i.base if i.exp is S.Half else i.base ** (2 * i.exp))
                    elif i is S.ImaginaryUnit:
                        p2.append(S.NegativeOne)
                    else:
                        other.append(i)
                collected[tuple(ordered(p2))].append(Mul(*other))
            rterms = list(ordered(list(collected.items())))
            rterms = [(Mul(*i), Add(*j)) for i, j in rterms]
            nrad = len(rterms) - (1 if rterms[0][0] is S.One else 0)
            if nrad < 1:
                break
            elif nrad > max_terms:
                keep = False
                break
            if len(rterms) > 4:
                if all((x.is_Integer and (y ** 2).is_Rational for x, y in rterms)):
                    nd, d = rad_rationalize(S.One, Add._from_args([sqrt(x) * y for x, y in rterms]))
                    n *= nd
                else:
                    keep = False
                break
            from sympy.simplify.powsimp import powsimp, powdenest
            num = powsimp(_num(rterms))
            n *= num
            d *= num
            d = powdenest(_mexpand(d), force=symbolic)
            if d.has(S.Zero, nan, zoo):
                return expr
            if d.is_Atom:
                break
        if not keep:
            return expr
        return _unevaluated_Mul(n, 1 / d)
    if not isinstance(expr, Expr):
        return expr.func(*[radsimp(a, symbolic=symbolic, max_terms=max_terms) for a in expr.args])
    coeff, expr = expr.as_coeff_Add()
    expr = expr.normal()
    old = fraction(expr)
    n, d = fraction(handle(expr))
    if old != (n, d):
        if not d.is_Atom:
            was = (n, d)
            n = signsimp(n, evaluate=False)
            d = signsimp(d, evaluate=False)
            u = Factors(_unevaluated_Mul(n, 1 / d))
            u = _unevaluated_Mul(*[k ** v for k, v in u.factors.items()])
            n, d = fraction(u)
            if old == (n, d):
                n, d = was
        n = expand_mul(n)
        if d.is_Number or d.is_Add:
            n2, d2 = fraction(gcd_terms(_unevaluated_Mul(n, 1 / d)))
            if d2.is_Number or d2.count_ops() <= d.count_ops():
                n, d = [signsimp(i) for i in (n2, d2)]
                if n.is_Mul and n.args[0].is_Number:
                    n = n.func(*n.args)
    return coeff + _unevaluated_Mul(n, 1 / d)

def rad_rationalize(num, den):
    if not den.is_Add:
        return (num, den)
    g, a, b = split_surds(den)
    a = a * sqrt(g)
    num = _mexpand((a - b) * num)
    den = _mexpand(a ** 2 - b ** 2)
    return rad_rationalize(num, den)

def fraction(expr, exact=False):
    expr = sympify(expr)
    numer, denom = ([], [])
    for term in Mul.make_args(expr):
        if term.is_commutative and (term.is_Pow or isinstance(term, exp)):
            b, ex = term.as_base_exp()
            if ex.is_negative:
                if ex is S.NegativeOne:
                    denom.append(b)
                elif exact:
                    if ex.is_constant():
                        denom.append(Pow(b, -ex))
                    else:
                        numer.append(term)
                else:
                    denom.append(Pow(b, -ex))
            elif ex.is_positive:
                numer.append(term)
            elif not exact and ex.is_Mul:
                n, d = term.as_numer_denom()
                if n != 1:
                    numer.append(n)
                denom.append(d)
            else:
                numer.append(term)
        elif term.is_Rational and (not term.is_Integer):
            if term.p != 1:
                numer.append(term.p)
            denom.append(term.q)
        else:
            numer.append(term)
    return (Mul(*numer, evaluate=not exact), Mul(*denom, evaluate=not exact))

def numer(expr, exact=False):
    return fraction(expr, exact=exact)[0]

def denom(expr, exact=False):
    return fraction(expr, exact=exact)[1]

def fraction_expand(expr, **hints):
    return expr.expand(frac=True, **hints)

def numer_expand(expr, **hints):
    a, b = fraction(expr, exact=hints.get('exact', False))
    return a.expand(numer=True, **hints) / b

def denom_expand(expr, **hints):
    a, b = fraction(expr, exact=hints.get('exact', False))
    return a / b.expand(denom=True, **hints)
expand_numer = numer_expand
expand_denom = denom_expand
expand_fraction = fraction_expand

def split_surds(expr):
    args = sorted(expr.args, key=default_sort_key)
    coeff_muls = [x.as_coeff_Mul() for x in args]
    surds = [x[1] ** 2 for x in coeff_muls if x[1].is_Pow]
    surds.sort(key=default_sort_key)
    g, b1, b2 = _split_gcd(*surds)
    g2 = g
    if not b2 and len(b1) >= 2:
        b1n = [x / g for x in b1]
        b1n = [x for x in b1n if x != 1]
        g1, b1n, b2 = _split_gcd(*b1n)
        g2 = g * g1
    a1v, a2v = ([], [])
    for c, s in coeff_muls:
        if s.is_Pow and s.exp == S.Half:
            s1 = s.base
            if s1 in b1:
                a1v.append(c * sqrt(s1 / g2))
            else:
                a2v.append(c * s)
        else:
            a2v.append(c * s)
    a = Add(*a1v)
    b = Add(*a2v)
    return (g2, a, b)

def _split_gcd(*a):
    g = a[0]
    b1 = [g]
    b2 = []
    for x in a[1:]:
        g1 = gcd(g, x)
        if g1 == 1:
            b2.append(x)
        else:
            g = g1
            b1.append(x)
    return (g, b1, b2)