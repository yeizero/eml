from __future__ import annotations
from itertools import combinations_with_replacement
from sympy.core import symbols, Add, Dummy
from sympy.core.numbers import Rational
from sympy.core.singleton import S
from sympy.polys import cancel, ComputationFailed, parallel_poly_from_expr, reduced, Poly
from sympy.polys.monomials import Monomial, monomial_div
from sympy.polys.polyerrors import DomainError, PolificationFailed
from sympy.utilities.memoization import recurrence_memo
from sympy.utilities.misc import debug, debugf

def ratsimp(expr):
    f, g = cancel(expr).as_numer_denom()
    try:
        Q, r = reduced(f, [g], field=True, expand=False)
    except ComputationFailed:
        return f / g
    return Add(*Q) + cancel(r / g)

def ratsimpmodprime(expr, G, *gens, quick=True, polynomial=False, **args):
    from sympy.solvers.solvers import solve
    debug('ratsimpmodprime', expr)
    num, denom = cancel(expr).as_numer_denom()
    try:
        polys, opt = parallel_poly_from_expr([num, denom] + G, *gens, **args)
    except PolificationFailed:
        return expr
    domain = opt.domain
    if domain.has_assoc_Field:
        opt.domain = domain.get_field()
    else:
        raise DomainError('Cannot compute rational simplification over %s' % domain)
    leading_monomials = [g.LM(opt.order) for g in polys[2:]]
    tested = set()

    @recurrence_memo([[S.One]])
    def staircase(n, prev):
        result = []
        for mi in combinations_with_replacement(range(len(opt.gens)), n):
            m = [0] * len(opt.gens)
            for i in mi:
                m[i] += 1
            if all((monomial_div(m, lmg) is None for lmg in leading_monomials)):
                result.append(Monomial(m).as_expr(*opt.gens))
        return result + prev[-1]

    def _ratsimpmodprime(a, b, allsol, N=0, D=0):
        c, d = (a, b)
        steps = 0
        maxdeg = a.total_degree() + b.total_degree()
        if quick:
            bound = maxdeg - 1
        else:
            bound = maxdeg
        while N + D <= bound and (N, D) not in tested:
            tested.add((N, D))
            M1 = staircase(N)
            M2 = staircase(D)
            debugf('%s / %s: %s, %s', (N, D, M1, M2))
            Cs = symbols('c:%d' % len(M1), cls=Dummy)
            Ds = symbols('d:%d' % len(M2), cls=Dummy)
            ng = Cs + Ds
            g_ng = opt.gens + ng
            c_hat = Poly(sum((Cs[i] * M1[i] for i in range(len(M1)))), g_ng)
            d_hat = Poly(sum((Ds[i] * M2[i] for i in range(len(M2)))), g_ng)
            r = reduced(a * d_hat - b * c_hat, G, g_ng, order=opt.order, polys=True)[1]
            s = Poly(r, gens=opt.gens).coeffs()
            sol = solve(s, ng, particular=True, quick=True)
            if sol and (not all((_s == 0 for _s in sol.values()))):
                c = c_hat.subs(sol)
                d = d_hat.subs(sol)
                subs_dic = dict.fromkeys(ng, S.One)
                c = c.subs(subs_dic)
                d = d.subs(subs_dic)
                c = Poly(c, opt.gens)
                d = Poly(d, opt.gens)
                if d == 0:
                    raise ValueError('Ideal not prime?')
                allsol.append((c_hat, d_hat, s, ng))
                if N + D != maxdeg:
                    allsol = [allsol[-1]]
                break
            steps += 1
            N += 1
            D += 1
        if steps > 0:
            c, d, allsol = _ratsimpmodprime(c, d, allsol, N, D - steps)
            c, d, allsol = _ratsimpmodprime(c, d, allsol, N - steps, D)
        return (c, d, allsol)
    num = reduced(num, G, opt.gens, order=opt.order)[1]
    denom = reduced(denom, G, opt.gens, order=opt.order)[1]
    if polynomial:
        return (num / denom).cancel()
    c, d, allsol = _ratsimpmodprime(Poly(num, opt.gens, domain=opt.domain), Poly(denom, opt.gens, domain=opt.domain), [])
    if not quick and allsol:
        debugf('Looking for best minimal solution. Got: %s', len(allsol))
        newsol = []
        for c_hat, d_hat, s, ng in allsol:
            sol = solve(s, ng, particular=True, quick=False)
            newsol.append((c_hat.subs(sol), d_hat.subs(sol)))
        c, d = min(newsol, key=lambda x: len(x[0].terms()) + len(x[1].terms()))
    if not domain.is_Field:
        cn, c = c.clear_denoms(convert=True)
        dn, d = d.clear_denoms(convert=True)
        r = Rational(cn, dn)
    else:
        r = S.One
    return c * r.q / (d * r.p)