from __future__ import annotations
from sympy.core.traversal import use as _use
from sympy.utilities.decorator import deprecated
use = deprecated('\n    Using use from the sympy.simplify.traversaltools submodule is\n    deprecated.\n\n    Instead, use use from the top-level sympy namespace, like\n\n        sympy.use\n    ', deprecated_since_version='1.10', active_deprecations_target='deprecated-traversal-functions-moved')(_use)