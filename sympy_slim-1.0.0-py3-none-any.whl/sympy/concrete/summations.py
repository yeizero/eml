from __future__ import annotations
from sympy.calculus.singularities import is_decreasing
from sympy.calculus.util import continuous_domain
from sympy.calculus.accumulationbounds import AccumulationBounds
from .expr_with_intlimits import ExprWithIntLimits
from .expr_with_limits import AddWithLimits
from .gosper import gosper_sum
from sympy.core.add import Add
from sympy.core.containers import Tuple
from sympy.core.function import Derivative, expand, expand_mul
from sympy.core.mul import Mul
from sympy.core.numbers import Float, _illegal
from sympy.core.relational import Eq
from sympy.core.singleton import S
from sympy.core.sorting import ordered
from sympy.core.symbol import Dummy, Wild, Symbol, symbols
from sympy.functions.combinatorial.factorials import factorial
from sympy.functions.combinatorial.numbers import bernoulli, harmonic
from sympy.functions.elementary.complexes import re
from sympy.functions.elementary.exponential import exp, log
from sympy.functions.elementary.piecewise import Piecewise
from sympy.functions.elementary.trigonometric import tan, sin, cot, csc
from sympy.functions.special.hyper import hyper
from sympy.functions.special.tensor_functions import KroneckerDelta
from sympy.functions.special.zeta_functions import zeta
from sympy.integrals.integrals import Integral
from sympy.logic.boolalg import And, Not
from sympy.matrices.expressions.special import ZeroMatrix
from sympy.polys.partfrac import apart
from sympy.polys.polyerrors import PolynomialError, PolificationFailed
from sympy.polys.polytools import parallel_poly_from_expr, Poly, factor
from sympy.polys.rationaltools import together
from sympy.series.limitseq import limit_seq
from sympy.series.order import O
from sympy.sets.contains import Contains
from sympy.sets.sets import FiniteSet, Interval
from sympy.utilities.iterables import sift
import itertools
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from sympy.core.expr import Expr

class Sum(AddWithLimits, ExprWithIntLimits):
    __slots__ = ()
    limits: tuple[tuple[Symbol, Expr, Expr]]

    def __new__(cls, function, *symbols, **assumptions) -> Sum:
        obj = AddWithLimits.__new__(cls, function, *symbols, **assumptions)
        if not hasattr(obj, 'limits'):
            return obj
        if any((len(l) != 3 or None in l for l in obj.limits)):
            raise ValueError('Sum requires values for lower and upper bounds.')
        return obj

    def _eval_is_zero(self):
        if self.function.is_zero:
            return True
        if self.has_empty_sequence and (not self.function.is_Matrix):
            return True

    def _eval_is_extended_real(self):
        if self.has_empty_sequence:
            return True
        return self.function.is_extended_real

    def _eval_is_positive(self):
        if self.has_finite_limits and self.has_reversed_limits is False:
            return self.function.is_positive

    def _eval_is_negative(self):
        if self.has_finite_limits and self.has_reversed_limits is False:
            return self.function.is_negative

    def _eval_is_finite(self):
        if self.has_finite_limits and self.function.is_finite:
            return True

    def doit(self, **hints):
        if hints.get('deep', True):
            f = self.function.doit(**hints)
        else:
            f = self.function
        reps = {}
        for xab in self.limits:
            d = _dummy_with_inherited_properties_concrete(xab)
            if d:
                reps[xab[0]] = d
        if reps:
            undo = {v: k for k, v in reps.items()}
            did = self.xreplace(reps).doit(**hints)
            if isinstance(did, tuple):
                did = tuple([i.xreplace(undo) for i in did])
            elif did is not None:
                did = did.xreplace(undo)
            else:
                did = self
            return did
        if self.function.is_Matrix:
            expanded = self.expand()
            if self != expanded:
                return expanded.doit()
            expr = _eval_matrix_sum(self)
            if expr is not None:
                return expr
        for n, limit in enumerate(self.limits):
            i, a, b = limit
            dif = b - a
            if dif == -1:
                return S.Zero
            if dif.is_integer and dif.is_negative:
                a, b = (b + 1, a - 1)
                f = -f
            newf = eval_sum(f, (i, a, b))
            if newf is None:
                if f == self.function:
                    zeta_function = self.eval_zeta_function(f, (i, a, b))
                    if zeta_function is not None:
                        return zeta_function
                    return self
                else:
                    return self.func(f, *self.limits[n:])
            f = newf
        if hints.get('deep', True):
            if not isinstance(f, Piecewise):
                return f.doit(**hints)
        return f

    def eval_zeta_function(self, f, limits):
        i, a, b = limits
        if a.is_comparable and b.is_comparable and (a > b):
            return self.eval_zeta_function(f, (i, b + S.One, a - S.One))
        if b is not S.Infinity:
            return
        w, y, z = (Wild('w', exclude=[i]), Wild('y', exclude=[i]), Wild('z', exclude=[i]))
        if (result := f.match((w * i + y) ** (-z))):
            coeff = 1 / result[w] ** result[z]
            s = result[z]
            q = result[y] / result[w] + a
            return Piecewise((coeff * zeta(s, q), And(Not(Contains(-q, S.Naturals0)), re(s) > S.One)), (self, True))

    def _eval_derivative(self, x):
        if isinstance(x, Symbol) and x not in self.free_symbols:
            return S.Zero
        f, limits = (self.function, list(self.limits))
        limit = limits.pop(-1)
        if limits:
            f = self.func(f, *limits)
        _, a, b = limit
        if x in a.free_symbols or x in b.free_symbols:
            return None
        df = Derivative(f, x, evaluate=True)
        rv = self.func(df, limit)
        return rv

    def _eval_difference_delta(self, n, step):
        k, _, upper = self.args[-1]
        new_upper = upper.subs(n, n + step)
        if len(self.args) == 2:
            f = self.args[0]
        else:
            f = self.func(*self.args[:-1])
        return Sum(f, (k, upper + 1, new_upper)).doit()

    def _eval_simplify(self, **kwargs):
        function = self.function
        if kwargs.get('deep', True):
            function = function.simplify(**kwargs)
        terms = Add.make_args(expand(function))
        s_t = []
        o_t = []
        for term in terms:
            if term.has(Sum):
                subterms = Mul.make_args(expand(term))
                out_terms = []
                for subterm in subterms:
                    if isinstance(subterm, Sum):
                        out_terms.append(subterm._eval_simplify(**kwargs))
                    else:
                        out_terms.append(subterm)
                s_t.append(Mul(*out_terms))
            else:
                o_t.append(term)
        from sympy.simplify.simplify import factor_sum, sum_combine
        result = Add(sum_combine(s_t), *o_t)
        return factor_sum(result, limits=self.limits)

    def is_convergent(self):
        p, q, r = symbols('p q r', cls=Wild)
        sym = self.limits[0][0]
        lower_limit = self.limits[0][1]
        upper_limit = self.limits[0][2]
        sequence_term = self.function.simplify()
        if len(sequence_term.free_symbols) > 1:
            raise NotImplementedError('convergence checking for more than one symbol containing series is not handled')
        if lower_limit.is_finite and upper_limit.is_finite:
            return S.true
        if lower_limit is S.NegativeInfinity:
            if upper_limit is S.Infinity:
                return Sum(sequence_term, (sym, 0, S.Infinity)).is_convergent() and Sum(sequence_term, (sym, S.NegativeInfinity, 0)).is_convergent()
            from sympy.simplify.simplify import simplify
            sequence_term = simplify(sequence_term.xreplace({sym: -sym}))
            lower_limit = -upper_limit
            upper_limit = S.Infinity
        sym_ = Dummy(sym.name, integer=True, positive=True)
        sequence_term = sequence_term.xreplace({sym: sym_})
        sym = sym_
        interval = Interval(lower_limit, upper_limit)
        if sequence_term.is_Piecewise:
            for func, cond in sequence_term.args:
                if cond == True or cond.as_set().sup is S.Infinity:
                    s = Sum(func, (sym, lower_limit, upper_limit))
                    return s.is_convergent()
            return S.true
        try:
            lim_val = limit_seq(sequence_term, sym)
            if lim_val is not None and lim_val.is_zero is False:
                return S.false
        except NotImplementedError:
            pass
        try:
            lim_val_abs = limit_seq(abs(sequence_term), sym)
            if lim_val_abs is not None and lim_val_abs.is_zero is False:
                return S.false
        except NotImplementedError:
            pass
        order = O(sequence_term, (sym, S.Infinity))
        p_series_test = order.expr.match(sym ** p)
        if p_series_test is not None:
            if p_series_test[p] < -1:
                return S.true
            if p_series_test[p] >= -1:
                return S.false
        n_log_test = order.expr.match(1 / (sym ** p * log(1 / sym) ** q * log(-log(1 / sym)) ** r)) or order.expr.match(1 / (sym ** p * (-log(1 / sym)) ** q * log(-log(1 / sym)) ** r))
        if n_log_test is not None:
            if n_log_test[p] > 1 or (n_log_test[p] == 1 and n_log_test[q] > 1) or (n_log_test[p] == n_log_test[q] == 1 and n_log_test[r] > 1):
                return S.true
            return S.false
        try:
            lim_comp = limit_seq(sym * sequence_term, sym)
            if lim_comp is not None and lim_comp.is_number and (lim_comp > 0):
                return S.false
        except NotImplementedError:
            pass
        next_sequence_term = sequence_term.xreplace({sym: sym + 1})
        from sympy.simplify.combsimp import combsimp
        from sympy.simplify.powsimp import powsimp
        ratio = combsimp(powsimp(next_sequence_term / sequence_term))
        try:
            lim_ratio = limit_seq(ratio, sym)
            if lim_ratio is not None and lim_ratio.is_number and (lim_ratio is not S.NaN):
                if abs(lim_ratio) > 1:
                    return S.false
                if abs(lim_ratio) < 1:
                    return S.true
        except NotImplementedError:
            lim_ratio = None
        if lim_ratio == 1:
            test_val = sym * (sequence_term / sequence_term.subs(sym, sym + 1) - 1)
            test_val = test_val.gammasimp()
            try:
                lim_val = limit_seq(test_val, sym)
                if lim_val is not None and lim_val.is_number:
                    if lim_val > 1:
                        return S.true
                    if lim_val < 1:
                        return S.false
            except NotImplementedError:
                pass
        try:
            lim_evaluated = limit_seq(abs(sequence_term) ** (1 / sym), sym)
            if lim_evaluated is not None and lim_evaluated.is_number:
                if lim_evaluated < 1:
                    return S.true
                if lim_evaluated > 1:
                    return S.false
        except NotImplementedError:
            pass
        dict_val = sequence_term.match(S.NegativeOne ** (sym + p) * q)
        if not dict_val[p].has(sym):
            try:
                cont_dom = continuous_domain(dict_val[q], sym, interval)
                if interval.is_subset(cont_dom) and is_decreasing(dict_val[q], interval):
                    return S.true
            except NotImplementedError:
                pass
        check_interval = None
        from sympy.solvers.solveset import solveset
        maxima = solveset(sequence_term.diff(sym), sym, interval)
        if not maxima:
            check_interval = interval
        elif isinstance(maxima, FiniteSet) and maxima.sup.is_number:
            check_interval = Interval(maxima.sup, interval.sup)
        if check_interval is not None:
            try:
                cont_dom = continuous_domain(sequence_term, sym, check_interval)
                if check_interval.is_subset(cont_dom) and (is_decreasing(sequence_term, check_interval) or is_decreasing(-sequence_term, check_interval)):
                    integral_val = Integral(sequence_term, (sym, lower_limit, upper_limit))
                    try:
                        integral_val_evaluated = integral_val.doit()
                        if integral_val_evaluated.is_number:
                            return S(integral_val_evaluated.is_finite)
                    except NotImplementedError:
                        pass
            except NotImplementedError:
                pass
        if order.expr.is_Mul:
            args = order.expr.args
            argset = set(args)
            m = Dummy('m', integer=True)

            def _dirichlet_test(g_n):
                try:
                    ing_val = limit_seq(Sum(g_n, (sym, interval.inf, m)).doit(), m)
                    if ing_val is not None and ing_val.is_finite:
                        return S.true
                except NotImplementedError:
                    pass

            def _bounded_convergent_test(g1_n, g2_n):
                try:
                    lim_val = limit_seq(g1_n, sym)
                    if lim_val is not None and (lim_val.is_finite or (isinstance(lim_val, AccumulationBounds) and (lim_val.max - lim_val.min).is_finite)):
                        if Sum(g2_n, (sym, lower_limit, upper_limit)).is_absolutely_convergent():
                            return S.true
                except NotImplementedError:
                    pass
            for n in range(1, len(argset)):
                for a_tuple in itertools.combinations(args, n):
                    b_set = argset - set(a_tuple)
                    a_n = Mul(*a_tuple)
                    b_n = Mul(*b_set)
                    try:
                        cont_dom = continuous_domain(a_n, sym, interval)
                        if interval.is_subset(cont_dom):
                            if is_decreasing(a_n, interval):
                                dirich = _dirichlet_test(b_n)
                                if dirich is not None:
                                    return dirich
                    except NotImplementedError:
                        pass
                    bc_test = _bounded_convergent_test(a_n, b_n)
                    if bc_test is not None:
                        return bc_test
        _sym = self.limits[0][0]
        sequence_term = sequence_term.xreplace({sym: _sym})
        raise NotImplementedError('The algorithm to find the Sum convergence of %s is not yet implemented' % sequence_term)

    def is_absolutely_convergent(self):
        return Sum(abs(self.function), self.limits).is_convergent()

    def euler_maclaurin(self, m=0, n=0, eps=0, eval_integral=True):
        m = int(m)
        n = int(n)
        f = self.function
        if len(self.limits) != 1:
            raise ValueError('More than 1 limit')
        i, a, b = self.limits[0]
        if (a > b) == True:
            if a - b == 1:
                return (S.Zero, S.Zero)
            a, b = (b + 1, a - 1)
            f = -f
        s = S.Zero
        if m:
            if b.is_Integer and a.is_Integer:
                m = min(m, b - a + 1)
            if not eps or f.is_polynomial(i):
                s = Add(*[f.subs(i, a + k) for k in range(m)])
            else:
                term = f.subs(i, a)
                if term:
                    test = abs(term.evalf(3)) < eps
                    if test == True:
                        return (s, abs(term))
                    elif not test == False:
                        return (term, S.Zero)
                s = term
                for k in range(1, m):
                    term = f.subs(i, a + k)
                    if abs(term.evalf(3)) < eps and term != 0:
                        return (s, abs(term))
                    s += term
            if b - a + 1 == m:
                return (s, S.Zero)
            a += m
        x = Dummy('x')
        I = Integral(f.subs(i, x), (x, a, b))
        if eval_integral:
            I = I.doit()
        s += I

        def fpoint(expr):
            if b is S.Infinity:
                return (expr.subs(i, a), 0)
            return (expr.subs(i, a), expr.subs(i, b))
        fa, fb = fpoint(f)
        iterm = (fa + fb) / 2
        g = f.diff(i)
        for k in range(1, n + 2):
            ga, gb = fpoint(g)
            term = bernoulli(2 * k) / factorial(2 * k) * (gb - ga)
            if k > n:
                break
            if eps and term:
                term_evalf = term.evalf(3)
                if term_evalf is S.NaN:
                    return (S.NaN, S.NaN)
                if abs(term_evalf) < eps:
                    break
            s += term
            g = g.diff(i, 2, simplify=False)
        return (s + iterm, abs(term))

    def reverse_order(self, *indices):
        l_indices = list(indices)
        for i, indx in enumerate(l_indices):
            if not isinstance(indx, int):
                l_indices[i] = self.index(indx)
        e = 1
        limits = []
        for i, limit in enumerate(self.limits):
            l = limit
            if i in l_indices:
                e = -e
                l = (limit[0], limit[2] + 1, limit[1] - 1)
            limits.append(l)
        return Sum(e * self.function, *limits)

    def _eval_rewrite_as_Product(self, *args, **kwargs):
        from sympy.concrete.products import Product
        if self.function.is_extended_real:
            return log(Product(exp(self.function), *self.limits))

def summation(f, *symbols, **kwargs):
    return Sum(f, *symbols, **kwargs).doit(deep=False)

def telescopic_direct(L, R, n, limits):
    i, a, b = limits
    return Add(*[L.subs(i, a + m) + R.subs(i, b - m) for m in range(n)])

def telescopic(L, R, limits):
    i, a, b = limits
    if L.is_Add or R.is_Add:
        return None
    k = Wild('k')
    sol = (-R).match(L.subs(i, i + k))
    s = None
    if sol and k in sol:
        s = sol[k]
        if not (s.is_Integer and L.subs(i, i + s) + R == 0):
            s = None
    if s is None:
        m = Dummy('m')
        try:
            from sympy.solvers.solvers import solve
            sol = solve(L.subs(i, i + m) + R, m) or []
        except NotImplementedError:
            return None
        sol = [si for si in sol if si.is_Integer and (L.subs(i, i + si) + R).expand().is_zero]
        if len(sol) != 1:
            return None
        s = sol[0]
    if s < 0:
        return telescopic_direct(R, L, abs(s), (i, a, b))
    elif s > 0:
        return telescopic_direct(L, R, s, (i, a, b))

def eval_sum(f, limits):
    i, a, b = limits
    if f.is_zero:
        return S.Zero
    if i not in f.free_symbols:
        return f * (b - a + 1)
    if a == b:
        return f.subs(i, a)
    if a.is_comparable and b.is_comparable and (a > b):
        return eval_sum(f, (i, b + S.One, a - S.One))
    if isinstance(f, Piecewise):
        if not any((i in arg.args[1].free_symbols for arg in f.args)):
            newargs = []
            for arg in f.args:
                newexpr = eval_sum(arg.expr, limits)
                if newexpr is None:
                    return None
                newargs.append((newexpr, arg.cond))
            return f.func(*newargs)
    if f.has(KroneckerDelta):
        from .delta import deltasummation, _has_simple_delta
        f = f.replace(lambda x: isinstance(x, Sum), lambda x: x.factor())
        if _has_simple_delta(f, limits[0]):
            return deltasummation(f, limits)
    dif = b - a
    definite = dif.is_Integer
    if definite and dif < 100:
        return eval_sum_direct(f, (i, a, b))
    if isinstance(f, Piecewise):
        return None
    value = eval_sum_symbolic(f.expand(), (i, a, b))
    if value is not None:
        return value
    if definite:
        return eval_sum_direct(f, (i, a, b))

def eval_sum_direct(expr, limits):
    i, a, b = limits
    dif = b - a
    if expr.is_Mul:
        without_i, with_i = expr.as_independent(i)
        if without_i != 1:
            s = eval_sum_direct(with_i, (i, a, b))
            if s:
                r = without_i * s
                if r is not S.NaN:
                    return r
        else:
            L, R = expr.as_two_terms()
            if not L.has(i):
                sR = eval_sum_direct(R, (i, a, b))
                if sR:
                    return L * sR
            if not R.has(i):
                sL = eval_sum_direct(L, (i, a, b))
                if sL:
                    return sL * R
    try:
        expr = apart(expr, i)
    except PolynomialError:
        pass
    if expr.is_Add:
        without_i, with_i = expr.as_independent(i)
        if without_i != 0:
            s = eval_sum_direct(with_i, (i, a, b))
            if s:
                r = without_i * (dif + 1) + s
                if r is not S.NaN:
                    return r
        else:
            L, R = expr.as_two_terms()
            lsum = eval_sum_direct(L, (i, a, b))
            rsum = eval_sum_direct(R, (i, a, b))
            if None not in (lsum, rsum):
                r = lsum + rsum
                if r is not S.NaN:
                    return r
    return Add(*[expr.subs(i, a + j) for j in range(dif + 1)])

def eval_sum_symbolic(f, limits):
    f_orig = f
    i, a, b = limits
    if not f.has(i):
        return f * (b - a + 1)
    if f.is_Mul:
        without_i, with_i = f.as_independent(i)
        if without_i != 1:
            s = eval_sum_symbolic(with_i, (i, a, b))
            if s:
                r = without_i * s
                if r is not S.NaN:
                    return r
        else:
            L, R = f.as_two_terms()
            if not L.has(i):
                sR = eval_sum_symbolic(R, (i, a, b))
                if sR:
                    return L * sR
            if not R.has(i):
                sL = eval_sum_symbolic(L, (i, a, b))
                if sL:
                    return sL * R
    try:
        f = apart(f, i)
    except PolynomialError:
        pass
    if f.is_Add:
        L, R = f.as_two_terms()
        lrsum = telescopic(L, R, (i, a, b))
        if lrsum:
            return lrsum
        without_i, with_i = f.as_independent(i)
        if without_i != 0:
            s = eval_sum_symbolic(with_i, (i, a, b))
            if s:
                r = without_i * (b - a + 1) + s
                if r is not S.NaN:
                    return r
        else:
            lsum = eval_sum_symbolic(L, (i, a, b))
            rsum = eval_sum_symbolic(R, (i, a, b))
            if None not in (lsum, rsum):
                r = lsum + rsum
                if r is not S.NaN:
                    return r
    n = Wild('n')
    result = f.match(i ** n)
    if result is not None:
        n = result[n]
        if n.is_Integer:
            if n >= 0:
                if b is S.Infinity and a is not S.NegativeInfinity or (a is S.NegativeInfinity and b is not S.Infinity):
                    return S.Infinity
                return ((bernoulli(n + 1, b + 1) - bernoulli(n + 1, a)) / (n + 1)).expand()
            elif a.is_Integer and a >= 1:
                if n == -1:
                    return harmonic(b) - harmonic(a - 1)
                else:
                    return harmonic(b, abs(n)) - harmonic(a - 1, abs(n))
    if not (a.has(S.Infinity, S.NegativeInfinity) or b.has(S.Infinity, S.NegativeInfinity)):
        c1 = Wild('c1', exclude=[i])
        c2 = Wild('c2', exclude=[i])
        c3 = Wild('c3', exclude=[i])
        wexp = Wild('wexp')
        e = f.powsimp().match(c1 ** wexp)
        if e is not None:
            e_exp = e.pop(wexp).expand().match(c2 * i + c3)
            if e_exp is not None:
                e.update(e_exp)
                p = (c1 ** c3).subs(e)
                q = (c1 ** c2).subs(e)
                r = p * (q ** a - q ** (b + 1)) / (1 - q)
                l = p * (b - a + 1)
                return Piecewise((l, Eq(q, S.One)), (r, True))
        r = gosper_sum(f, (i, a, b))
        if isinstance(r, (Mul, Add)):
            from sympy.simplify.radsimp import denom
            from sympy.solvers.solvers import solve
            non_limit = r.free_symbols - Tuple(*limits[1:]).free_symbols
            den = denom(together(r))
            den_sym = non_limit & den.free_symbols
            args = []
            for v in ordered(den_sym):
                try:
                    s = solve(den, v)
                    m = Eq(v, s[0]) if s else S.false
                    if m != False:
                        args.append((Sum(f_orig.subs(*m.args), limits).doit(), m))
                    break
                except NotImplementedError:
                    continue
            args.append((r, True))
            return Piecewise(*args)
        if r not in (None, S.NaN):
            return r
    h = eval_sum_hyper(f_orig, (i, a, b))
    if h is not None:
        return h
    r = eval_sum_residue(f_orig, (i, a, b))
    if r is not None:
        return r
    factored = f_orig.factor()
    if factored != f_orig:
        return eval_sum_symbolic(factored, (i, a, b))

def _eval_sum_hyper(f, i, a):
    if a != 0:
        return _eval_sum_hyper(f.subs(i, i + a), i, 0)
    if f.subs(i, 0) == 0:
        from sympy.simplify.simplify import simplify
        if simplify(f.subs(i, Dummy('i', integer=True, positive=True))) == 0:
            return (S.Zero, True)
        return _eval_sum_hyper(f.subs(i, i + 1), i, 0)
    from sympy.simplify.simplify import hypersimp
    hs = hypersimp(f, i)
    if hs is None:
        return None
    if isinstance(hs, Float):
        from sympy.simplify.simplify import nsimplify
        hs = nsimplify(hs)
    from sympy.simplify.combsimp import combsimp
    from sympy.simplify.hyperexpand import hyperexpand
    from sympy.simplify.radsimp import fraction
    numer, denom = fraction(factor(hs))
    top, topl = numer.as_coeff_mul(i)
    bot, botl = denom.as_coeff_mul(i)
    ab = [top, bot]
    factors = [topl, botl]
    params = [[], []]
    for k in range(2):
        for fac in factors[k]:
            mul = 1
            if fac.is_Pow:
                mul = fac.exp
                fac = fac.base
                if not mul.is_Integer:
                    return None
            p = Poly(fac, i)
            if p.degree() != 1:
                return None
            m, n = p.all_coeffs()
            ab[k] *= m ** mul
            params[k] += [n / m] * mul
    ap = params[0] + [1]
    bq = params[1]
    x = ab[0] / ab[1]
    h = hyper(ap, bq, x)
    f = combsimp(f)
    return (f.subs(i, 0) * hyperexpand(h), h.convergence_statement)

def eval_sum_hyper(f, i_a_b):
    i, a, b = i_a_b
    if f.is_hypergeometric(i) is False:
        return
    if (b - a).is_Integer:
        return None
    old_sum = Sum(f, (i, a, b))
    if b != S.Infinity:
        if a is S.NegativeInfinity:
            res = _eval_sum_hyper(f.subs(i, -i), i, -b)
            if res is not None:
                return Piecewise(res, (old_sum, True))
        else:
            n_illegal = lambda x: sum((x.count(_) for _ in _illegal))
            had = n_illegal(f)
            res1 = _eval_sum_hyper(f, i, a)
            if res1 is None or n_illegal(res1) > had:
                return
            res2 = _eval_sum_hyper(f, i, b + 1)
            if res2 is None or n_illegal(res2) > had:
                return
            (res1, cond1), (res2, cond2) = (res1, res2)
            cond = And(cond1, cond2)
            if cond == False:
                return None
            return Piecewise((res1 - res2, cond), (old_sum, True))
    if a is S.NegativeInfinity:
        res1 = _eval_sum_hyper(f.subs(i, -i), i, 1)
        res2 = _eval_sum_hyper(f, i, 0)
        if res1 is None or res2 is None:
            return None
        res1, cond1 = res1
        res2, cond2 = res2
        cond = And(cond1, cond2)
        if cond == False or cond.as_set() == S.EmptySet:
            return None
        return Piecewise((res1 + res2, cond), (old_sum, True))
    res = _eval_sum_hyper(f, i, a)
    if res is not None:
        r, c = res
        if c == False:
            if r.is_number:
                f = f.subs(i, Dummy('i', integer=True, positive=True) + a)
                if f.is_positive or f.is_zero:
                    return S.Infinity
                elif f.is_negative:
                    return S.NegativeInfinity
            return None
        return Piecewise(res, (old_sum, True))

def eval_sum_residue(f, i_a_b):
    i, a, b = i_a_b
    if f.free_symbols - {i}:
        return None
    if not (a.is_Integer or a in (S.Infinity, S.NegativeInfinity)):
        return None
    if not (b.is_Integer or b in (S.Infinity, S.NegativeInfinity)):
        return None
    if not any((x in (S.NegativeInfinity, S.Infinity) for x in (a, b))):
        return None
    if a > b:
        return -eval_sum_residue(f, (i, b + S.One, a - S.One))

    def is_even_function(numer, denom):
        numer_even = all((i % 2 == 0 for i, in numer.monoms()))
        denom_even = all((i % 2 == 0 for i, in denom.monoms()))
        numer_odd = all((i % 2 == 1 for i, in numer.monoms()))
        denom_odd = all((i % 2 == 1 for i, in denom.monoms()))
        return numer_even and denom_even or (numer_odd and denom_odd)

    def match_rational(f, i):
        numer, denom = f.as_numer_denom()
        try:
            (numer, denom), opt = parallel_poly_from_expr((numer, denom), i)
        except (PolificationFailed, PolynomialError):
            return None
        return (numer, denom)

    def get_poles(denom):
        roots = denom.sqf_part().all_roots()
        roots = sift(roots, lambda x: x.is_integer)
        if None in roots:
            return None
        int_roots, nonint_roots = (roots[True], roots[False])
        return (int_roots, nonint_roots)

    def get_shift(denom):
        n = denom.degree(i)
        a = denom.coeff_monomial(i ** n)
        b = denom.coeff_monomial(i ** (n - 1))
        shift = -b / a / n
        return shift

    def residues(numer, denom, alternating, poles):
        return [_get_residue(numer, denom, a, alternating) for a in poles]
    match = match_rational(f, i)
    if match:
        alternating = False
        numer, denom = match
    else:
        match = match_rational(f / S.NegativeOne ** i, i)
        if match:
            alternating = True
            numer, denom = match
        else:
            return None
    if denom.degree(i) - numer.degree(i) < 2:
        return None
    both_inf = (a, b) == (S.NegativeInfinity, S.Infinity)
    if not is_even_function(numer, denom):
        shift = get_shift(denom)
        if not shift:
            return None
        if shift.is_Integer:
            numer = numer.shift(shift)
            denom = denom.shift(shift)
            if not is_even_function(numer, denom):
                return None
            if alternating:
                f = S.NegativeOne ** i * (S.NegativeOne ** shift * numer.as_expr() / denom.as_expr())
            else:
                f = numer.as_expr() / denom.as_expr()
            return eval_sum_residue(f, (i, a - shift, b - shift))
        elif not both_inf:
            return None
    if both_inf:
        poles = get_poles(denom)
        if poles is None:
            return None
        int_roots, nonint_roots = poles
        if int_roots:
            return None
        return -S.Pi * sum(residues(numer, denom, alternating, nonint_roots))
    if a is S.NegativeInfinity:
        a, b = (-b, -a)
    assert a.is_Integer and b is S.Infinity
    poles = get_poles(denom)
    if poles is None:
        return None
    int_roots, nonint_roots = poles
    if int_roots:
        int_roots_max = max(int_roots)
        int_roots_min = min(int_roots)
        if not len(int_roots) == int_roots_max - int_roots_min + 1:
            return None
        if a <= max(int_roots):
            return None
    full_sum = -S.Pi * sum(residues(numer, denom, alternating, int_roots + nonint_roots))
    if not int_roots:
        half_sum = (full_sum + f.xreplace({i: 0})) / 2
        extraneous_neg = [f.xreplace({i: i0}) for i0 in range(int(a), 0)]
        extraneous_pos = [f.xreplace({i: i0}) for i0 in range(0, int(a))]
        result = half_sum + sum(extraneous_neg) - sum(extraneous_pos)
        return result
    half_sum = full_sum / 2
    extraneous = [f.xreplace({i: i0}) for i0 in range(max(int_roots) + 1, int(a))]
    result = half_sum - sum(extraneous)
    return result

def _get_residue(numer: Poly, denom: Poly, a: Expr, alternating: bool) -> Expr:
    x = denom.gen
    z = Dummy('z')
    if (2 * a).is_Integer:
        from sympy.series.residues import residue
        if not alternating:
            return residue(cot(S.Pi * z) * (numer(z) / denom(z)), z, a)
        else:
            return residue(csc(S.Pi * z) * (numer(z) / denom(z)), z, a)
    numer = numer.xreplace({x: z})
    denom = denom.xreplace({x: z})
    za = Poly(z - a, z, extension=True)
    za, denom = za.unify(denom)
    p = 0
    q, r = denom.div(za)
    while r == 0 and denom != 0:
        denom = q
        p += 1
        q, r = denom.div(za)
    assert p > 0, 'a is not a pole'
    if not alternating:
        expr = 1 / tan(S.Pi * z) * (numer / denom)
    else:
        expr = 1 / sin(S.Pi * z) * (numer / denom)
    if p > 1:
        expr = expr.diff((z, p - 1)) / factorial(p - 1)
    expr = expr.xreplace({S.Pi * z: expand_mul(S.Pi * a), z: a})
    return expr

def _eval_matrix_sum(expression):
    f = expression.function
    for limit in expression.limits:
        i, a, b = limit
        dif = b - a
        if dif == -1:
            return ZeroMatrix(*f.shape)
        if dif.is_Integer:
            if dif.is_negative:
                a, b = (b + 1, a - 1)
                f = -f
            newf = eval_sum_direct(f, (i, a, b))
            if newf is not None:
                return newf.doit()

def _dummy_with_inherited_properties_concrete(limits):
    x, a, b = limits
    l = [a, b]
    assumptions_to_consider = ['extended_nonnegative', 'nonnegative', 'extended_nonpositive', 'nonpositive', 'extended_positive', 'positive', 'extended_negative', 'negative', 'integer', 'rational', 'finite', 'zero', 'real', 'extended_real']
    assumptions_to_keep = {}
    assumptions_to_add = {}
    for assum in assumptions_to_consider:
        assum_true = x._assumptions.get(assum, None)
        if assum_true:
            assumptions_to_keep[assum] = True
        elif all((getattr(i, 'is_' + assum) for i in l)):
            assumptions_to_add[assum] = True
    if assumptions_to_add:
        assumptions_to_keep.update(assumptions_to_add)
        return Dummy('d', **assumptions_to_keep)