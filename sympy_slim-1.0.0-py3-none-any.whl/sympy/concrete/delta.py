from __future__ import annotations
from .products import product
from .summations import Sum, summation
from sympy.core import Add, Mul, S, Dummy
from sympy.core.cache import cacheit
from sympy.core.sorting import default_sort_key
from sympy.functions import KroneckerDelta, Piecewise, piecewise_fold
from sympy.polys.polytools import factor
from sympy.sets.sets import Interval
from sympy.solvers.solvers import solve

@cacheit
def _expand_delta(expr, index):
    if not expr.is_Mul:
        return expr
    delta = None
    func = Add
    terms = [S.One]
    for h in expr.args:
        if delta is None and h.is_Add and _has_simple_delta(h, index):
            delta = True
            func = h.func
            terms = [terms[0] * t for t in h.args]
        else:
            terms = [t * h for t in terms]
    return func(*terms)

@cacheit
def _extract_delta(expr, index):
    if not _has_simple_delta(expr, index):
        return (None, expr)
    if isinstance(expr, KroneckerDelta):
        return (expr, S.One)
    if not expr.is_Mul:
        raise ValueError('Incorrect expr')
    delta = None
    terms = []
    for arg in expr.args:
        if delta is None and _is_simple_delta(arg, index):
            delta = arg
        else:
            terms.append(arg)
    return (delta, expr.func(*terms))

@cacheit
def _has_simple_delta(expr, index):
    if expr.has(KroneckerDelta):
        if _is_simple_delta(expr, index):
            return True
        if expr.is_Add or expr.is_Mul:
            return any((_has_simple_delta(arg, index) for arg in expr.args))
    return False

@cacheit
def _is_simple_delta(delta, index):
    if isinstance(delta, KroneckerDelta) and delta.has(index):
        p = (delta.args[0] - delta.args[1]).as_poly(index)
        if p:
            return p.degree() == 1
    return False

@cacheit
def _remove_multiple_delta(expr):
    if expr.is_Add:
        return expr.func(*list(map(_remove_multiple_delta, expr.args)))
    if not expr.is_Mul:
        return expr
    eqs = []
    newargs = []
    for arg in expr.args:
        if isinstance(arg, KroneckerDelta):
            eqs.append(arg.args[0] - arg.args[1])
        else:
            newargs.append(arg)
    if not eqs:
        return expr
    solns = solve(eqs, dict=True)
    if len(solns) == 0:
        return S.Zero
    elif len(solns) == 1:
        newargs += [KroneckerDelta(k, v) for k, v in solns[0].items()]
        expr2 = expr.func(*newargs)
        if expr != expr2:
            return _remove_multiple_delta(expr2)
    return expr

@cacheit
def _simplify_delta(expr):
    if isinstance(expr, KroneckerDelta):
        try:
            slns = solve(expr.args[0] - expr.args[1], dict=True)
            if slns and len(slns) == 1:
                return Mul(*[KroneckerDelta(*(key, value)) for key, value in slns[0].items()])
        except NotImplementedError:
            pass
    return expr

@cacheit
def deltaproduct(f, limit):
    if (limit[2] - limit[1] < 0) == True:
        return S.One
    if not f.has(KroneckerDelta):
        return product(f, limit)
    if f.is_Add:
        delta = None
        terms = []
        for arg in sorted(f.args, key=default_sort_key):
            if delta is None and _has_simple_delta(arg, limit[0]):
                delta = arg
            else:
                terms.append(arg)
        newexpr = f.func(*terms)
        k = Dummy('kprime', integer=True)
        if isinstance(limit[1], int) and isinstance(limit[2], int):
            result = deltaproduct(newexpr, limit) + sum((deltaproduct(newexpr, (limit[0], limit[1], ik - 1)) * delta.subs(limit[0], ik) * deltaproduct(newexpr, (limit[0], ik + 1, limit[2])) for ik in range(int(limit[1]), int(limit[2] + 1))))
        else:
            result = deltaproduct(newexpr, limit) + deltasummation(deltaproduct(newexpr, (limit[0], limit[1], k - 1)) * delta.subs(limit[0], k) * deltaproduct(newexpr, (limit[0], k + 1, limit[2])), (k, limit[1], limit[2]), no_piecewise=_has_simple_delta(newexpr, limit[0]))
        return _remove_multiple_delta(result)
    delta, _ = _extract_delta(f, limit[0])
    if not delta:
        g = _expand_delta(f, limit[0])
        if f != g:
            try:
                return factor(deltaproduct(g, limit))
            except AssertionError:
                return deltaproduct(g, limit)
        return product(f, limit)
    return _remove_multiple_delta(f.subs(limit[0], limit[1]) * KroneckerDelta(limit[2], limit[1])) + S.One * _simplify_delta(KroneckerDelta(limit[2], limit[1] - 1))

@cacheit
def deltasummation(f, limit, no_piecewise=False):
    if (limit[2] - limit[1] < 0) == True:
        return S.Zero
    if not f.has(KroneckerDelta):
        return summation(f, limit)
    x = limit[0]
    g = _expand_delta(f, x)
    if g.is_Add:
        return piecewise_fold(g.func(*[deltasummation(h, limit, no_piecewise) for h in g.args]))
    delta, expr = _extract_delta(g, x)
    if delta is not None and delta.delta_range is not None:
        dinf, dsup = delta.delta_range
        if (limit[1] - dinf <= 0) == True and (limit[2] - dsup >= 0) == True:
            no_piecewise = True
    if not delta:
        return summation(f, limit)
    solns = solve(delta.args[0] - delta.args[1], x)
    if len(solns) == 0:
        return S.Zero
    elif len(solns) != 1:
        return Sum(f, limit)
    value = solns[0]
    if no_piecewise:
        return expr.subs(x, value)
    return Piecewise((expr.subs(x, value), Interval(*limit[1:3]).as_relational(value)), (S.Zero, True))