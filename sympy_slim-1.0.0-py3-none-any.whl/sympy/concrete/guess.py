from __future__ import annotations
from sympy.concrete.products import Product, product
from sympy.core import Function, S
from sympy.core.add import Add
from sympy.core.numbers import Integer, Rational
from sympy.core.symbol import Symbol, symbols
from sympy.core.sympify import sympify
from sympy.functions.elementary.exponential import exp
from sympy.functions.elementary.integers import floor
from sympy.integrals.integrals import integrate
from sympy.polys.polyfuncs import rational_interpolate as rinterp
from sympy.polys.polytools import lcm
from sympy.simplify.radsimp import denom
from sympy.utilities import public

@public
def find_simple_recurrence_vector(l):
    q1 = [0]
    q2 = [1]
    b, z = (0, len(l) >> 1)
    while len(q2) <= z:
        while l[b] == 0:
            b += 1
            if b == len(l):
                c = 1
                for x in q2:
                    c = lcm(c, denom(x))
                if q2[0] * c < 0:
                    c = -c
                for k in range(len(q2)):
                    q2[k] = int(q2[k] * c)
                return q2
        a = S.One / l[b]
        m = [a]
        for k in range(b + 1, len(l)):
            m.append(-sum((l[j + 1] * m[b - j - 1] for j in range(b, k))) * a)
        l, m = (m, [0] * max(len(q2), b + len(q1)))
        for k, q in enumerate(q2):
            m[k] = a * q
        for k, q in enumerate(q1):
            m[k + b] += q
        while m[-1] == 0:
            m.pop()
        q1, q2, b = (q2, m, 1)
    return [0]

@public
def find_simple_recurrence(v, A=Function('a'), N=Symbol('n')):
    p = find_simple_recurrence_vector(v)
    n = len(p)
    if n <= 1:
        return S.Zero
    return Add(*[A(N + n - 1 - k) * p[k] for k in range(n)])

@public
def rationalize(x, maxcoeff=10000):
    p0, p1 = (0, 1)
    q0, q1 = (1, 0)
    a = floor(x)
    while a < maxcoeff or q1 == 0:
        p = a * p1 + p0
        q = a * q1 + q0
        p0, p1 = (p1, p)
        q0, q1 = (q1, q)
        if x == a:
            break
        x = 1 / (x - a)
        a = floor(x)
    return sympify(p) / q

@public
def guess_generating_function_rational(v, X=Symbol('x')):
    q = find_simple_recurrence_vector(v)
    n = len(q)
    if n <= 1:
        return None
    p = [sum((v[i - k] * q[k] for k in range(min(i + 1, n)))) for i in range(len(v) >> 1)]
    return sum((p[k] * X ** k for k in range(len(p)))) / sum((q[k] * X ** k for k in range(n)))

@public
def guess_generating_function(v, X=Symbol('x'), types=['all'], maxsqrtn=2):
    if 'all' in types:
        types = ('ogf', 'egf', 'lgf', 'hlgf', 'lgdogf', 'lgdegf')
    result = {}
    if 'ogf' in types:
        t = [1] + [0] * (len(v) - 1)
        for d in range(max(1, maxsqrtn)):
            t = [sum((t[n - i] * v[i] for i in range(n + 1))) for n in range(len(v))]
            g = guess_generating_function_rational(t, X=X)
            if g:
                result['ogf'] = g ** Rational(1, d + 1)
                break
    if 'egf' in types:
        w, f = ([], S.One)
        for i, k in enumerate(v):
            f *= i if i else 1
            w.append(k / f)
        t = [1] + [0] * (len(w) - 1)
        for d in range(max(1, maxsqrtn)):
            t = [sum((t[n - i] * w[i] for i in range(n + 1))) for n in range(len(w))]
            g = guess_generating_function_rational(t, X=X)
            if g:
                result['egf'] = g ** Rational(1, d + 1)
                break
    if 'lgf' in types:
        w, f = ([], S.NegativeOne)
        for i, k in enumerate(v):
            f = -f
            w.append(f * k / Integer(i + 1))
        t = [1] + [0] * (len(w) - 1)
        for d in range(max(1, maxsqrtn)):
            t = [sum((t[n - i] * w[i] for i in range(n + 1))) for n in range(len(w))]
            g = guess_generating_function_rational(t, X=X)
            if g:
                result['lgf'] = g ** Rational(1, d + 1)
                break
    if 'hlgf' in types:
        w = []
        for i, k in enumerate(v):
            w.append(k / Integer(i + 1))
        t = [1] + [0] * (len(w) - 1)
        for d in range(max(1, maxsqrtn)):
            t = [sum((t[n - i] * w[i] for i in range(n + 1))) for n in range(len(w))]
            g = guess_generating_function_rational(t, X=X)
            if g:
                result['hlgf'] = g ** Rational(1, d + 1)
                break
    if v[0] != 0 and ('lgdogf' in types or ('ogf' in types and 'ogf' not in result)):
        a, w = (sympify(v[0]), [])
        for n in range(len(v) - 1):
            w.append((v[n + 1] * (n + 1) - sum((w[-i - 1] * v[i + 1] for i in range(n)))) / a)
        t = [1] + [0] * (len(w) - 1)
        for d in range(max(1, maxsqrtn)):
            t = [sum((t[n - i] * w[i] for i in range(n + 1))) for n in range(len(w))]
            g = guess_generating_function_rational(t, X=X)
            if g:
                result['lgdogf'] = g ** Rational(1, d + 1)
                if 'ogf' not in result:
                    result['ogf'] = exp(integrate(result['lgdogf'], X))
                break
    if v[0] != 0 and ('lgdegf' in types or ('egf' in types and 'egf' not in result)):
        z, f = ([], S.One)
        for i, k in enumerate(v):
            f *= i if i else 1
            z.append(k / f)
        a, w = (z[0], [])
        for n in range(len(z) - 1):
            w.append((z[n + 1] * (n + 1) - sum((w[-i - 1] * z[i + 1] for i in range(n)))) / a)
        t = [1] + [0] * (len(w) - 1)
        for d in range(max(1, maxsqrtn)):
            t = [sum((t[n - i] * w[i] for i in range(n + 1))) for n in range(len(w))]
            g = guess_generating_function_rational(t, X=X)
            if g:
                result['lgdegf'] = g ** Rational(1, d + 1)
                if 'egf' not in result:
                    result['egf'] = exp(integrate(result['lgdegf'], X))
                break
    return result

@public
def guess(l, all=False, evaluate=True, niter=2, variables=None):
    if any((a == 0 for a in l[:-1])):
        return []
    N = len(l)
    niter = min(N - 1, niter)
    myprod = product if evaluate else Product
    g = []
    res = []
    if variables is None:
        symb = symbols('i:' + str(niter))
    else:
        symb = variables
    for k, s in enumerate(symb):
        g.append(l)
        n, r = (len(l), [])
        for i in range(n - 2 - 1, -1, -1):
            ri = rinterp(enumerate(g[k][:-1], start=1), i, X=s)
            if denom(ri).subs({s: n}) != 0 and ri.subs({s: n}) - g[k][-1] == 0 and (ri not in r):
                r.append(ri)
        if r:
            for i in range(k - 1, -1, -1):
                r = [g[i][0] * myprod(v, (symb[i + 1], 1, symb[i] - 1)) for v in r]
            if not all:
                return r
            res += r
        l = [Rational(l[i + 1], l[i]) for i in range(N - k - 1)]
    return res