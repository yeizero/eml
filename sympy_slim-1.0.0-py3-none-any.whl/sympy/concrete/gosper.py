from __future__ import annotations
from sympy.core import S, Dummy, symbols
from sympy.polys import Poly, parallel_poly_from_expr, factor
from sympy.utilities.iterables import is_sequence

def gosper_normal(f, g, n, polys=True):
    (p, q), opt = parallel_poly_from_expr((f, g), n, field=True, extension=True)
    a, A = (p.LC(), p.monic())
    b, B = (q.LC(), q.monic())
    C, Z = (A.one, a / b)
    h = Dummy('h')
    D = Poly(n + h, n, h, domain=opt.domain)
    R = A.resultant(B.compose(D))
    roots = {r for r in R.ground_roots().keys() if r.is_Integer and r >= 0}
    for i in sorted(roots):
        d = A.gcd(B.shift(+i))
        A = A.quo(d)
        B = B.quo(d.shift(-i))
        for j in range(1, i + 1):
            C *= d.shift(-j)
    A = A.mul_ground(Z)
    if not polys:
        A = A.as_expr()
        B = B.as_expr()
        C = C.as_expr()
    return (A, B, C)

def gosper_term(f, n):
    from sympy.simplify import hypersimp
    r = hypersimp(f, n)
    if r is None:
        return None
    p, q = r.as_numer_denom()
    A, B, C = gosper_normal(p, q, n)
    B = B.shift(-1)
    N = S(A.degree())
    M = S(B.degree())
    K = S(C.degree())
    if N != M or A.LC() != B.LC():
        D = {K - max(N, M)}
    elif not N:
        D = {K - N + 1, S.Zero}
    else:
        D = {K - N + 1, (B.nth(N - 1) - A.nth(N - 1)) / A.LC()}
    for d in set(D):
        if not d.is_Integer or d < 0:
            D.remove(d)
    if not D:
        return None
    d = max(D)
    coeffs = symbols('c:%s' % (d + 1), cls=Dummy)
    domain = A.get_domain().inject(*coeffs)
    x = Poly(coeffs, n, domain=domain)
    H = A * x.shift(1) - B * x - C
    from sympy.solvers.solvers import solve
    solution = solve(H.coeffs(), coeffs)
    if solution is None:
        return None
    x = x.as_expr().subs(solution)
    for coeff in coeffs:
        if coeff not in solution:
            x = x.subs(coeff, 0)
    if x.is_zero:
        return None
    else:
        return B.as_expr() * x / C.as_expr()

def gosper_sum(f, k):
    indefinite = False
    if is_sequence(k):
        k, a, b = k
    else:
        indefinite = True
    g = gosper_term(f, k)
    if g is None:
        return None
    if indefinite:
        result = f * g
    else:
        result = (f * (g + 1)).subs(k, b) - (f * g).subs(k, a)
        if result is S.NaN:
            try:
                result = (f * (g + 1)).limit(k, b) - (f * g).limit(k, a)
            except NotImplementedError:
                result = None
    return factor(result)