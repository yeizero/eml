from __future__ import annotations
from sympy.concrete.expr_with_limits import ExprWithLimits
from sympy.core.singleton import S
from sympy.core.relational import Eq

class ReorderError(NotImplementedError):

    def __init__(self, expr, msg):
        super().__init__('%s could not be reordered: %s.' % (expr, msg))

class ExprWithIntLimits(ExprWithLimits):
    __slots__ = ()

    def change_index(self, var, trafo, newvar=None):
        if newvar is None:
            newvar = var
        limits = []
        for limit in self.limits:
            if limit[0] == var:
                p = trafo.as_poly(var)
                if p.degree() != 1:
                    raise ValueError('Index transformation is not linear')
                alpha = p.coeff_monomial(var)
                beta = p.coeff_monomial(S.One)
                if alpha.is_number:
                    if alpha == S.One:
                        limits.append((newvar, alpha * limit[1] + beta, alpha * limit[2] + beta))
                    elif alpha == S.NegativeOne:
                        limits.append((newvar, alpha * limit[2] + beta, alpha * limit[1] + beta))
                    else:
                        raise ValueError('Linear transformation results in non-linear summation stepsize')
                else:
                    limits.append((newvar, alpha * limit[2] + beta, alpha * limit[1] + beta))
            else:
                limits.append(limit)
        function = self.function.subs(var, (var - beta) / alpha)
        function = function.subs(var, newvar)
        return self.func(function, *limits)

    def index(expr, x):
        variables = [limit[0] for limit in expr.limits]
        if variables.count(x) != 1:
            raise ValueError(expr, 'Number of instances of variable not equal to one')
        else:
            return variables.index(x)

    def reorder(expr, *arg):
        new_expr = expr
        for r in arg:
            if len(r) != 2:
                raise ValueError(r, 'Invalid number of arguments')
            index1 = r[0]
            index2 = r[1]
            if not isinstance(r[0], int):
                index1 = expr.index(r[0])
            if not isinstance(r[1], int):
                index2 = expr.index(r[1])
            new_expr = new_expr.reorder_limit(index1, index2)
        return new_expr

    def reorder_limit(expr, x, y):
        var = {limit[0] for limit in expr.limits}
        limit_x = expr.limits[x]
        limit_y = expr.limits[y]
        if len(set(limit_x[1].free_symbols).intersection(var)) == 0 and len(set(limit_x[2].free_symbols).intersection(var)) == 0 and (len(set(limit_y[1].free_symbols).intersection(var)) == 0) and (len(set(limit_y[2].free_symbols).intersection(var)) == 0):
            limits = []
            for i, limit in enumerate(expr.limits):
                if i == x:
                    limits.append(limit_y)
                elif i == y:
                    limits.append(limit_x)
                else:
                    limits.append(limit)
            return type(expr)(expr.function, *limits)
        else:
            raise ReorderError(expr, 'could not interchange the two limits specified')

    @property
    def has_empty_sequence(self):
        ret_None = False
        for lim in self.limits:
            dif = lim[1] - lim[2]
            eq = Eq(dif, 1)
            if eq == True:
                return True
            elif eq == False:
                continue
            else:
                ret_None = True
        if ret_None:
            return None
        return False