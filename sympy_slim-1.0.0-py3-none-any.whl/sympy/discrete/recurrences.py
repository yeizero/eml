from __future__ import annotations
from sympy.core import S, sympify
from sympy.utilities.iterables import iterable
from sympy.utilities.misc import as_int

def linrec(coeffs, init, n):
    if not coeffs:
        return S.Zero
    if not iterable(coeffs):
        raise TypeError('Expected a sequence of coefficients for the recurrence')
    if not iterable(init):
        raise TypeError('Expected a sequence of values for the initialization of the recurrence')
    n = as_int(n)
    if n < 0:
        raise ValueError('Point of evaluation of recurrence must be a non-negative integer')
    c = [sympify(arg) for arg in coeffs]
    b = [sympify(arg) for arg in init]
    k = len(c)
    if len(b) > k:
        raise TypeError('Count of initial values should not exceed the order of the recurrence')
    else:
        b += [S.Zero] * (k - len(b))
    if n < k:
        return b[n]
    terms = [u * v for u, v in zip(linrec_coeffs(c, n), b)]
    return sum(terms[:-1], terms[-1])

def linrec_coeffs(c, n):
    k = len(c)

    def _square_and_reduce(u, offset):
        w = [S.Zero] * (2 * len(u) - 1 + offset)
        for i, p in enumerate(u):
            for j, q in enumerate(u):
                w[offset + i + j] += p * q
        for j in range(len(w) - 1, k - 1, -1):
            for i in range(k):
                w[j - i - 1] += w[j] * c[i]
        return w[:k]

    def _final_coeffs(n):
        if n < k:
            return [S.Zero] * n + [S.One] + [S.Zero] * (k - n - 1)
        else:
            return _square_and_reduce(_final_coeffs(n // 2), n % 2)
    return _final_coeffs(n)