from __future__ import annotations
from sympy.core import S, Symbol, sympify
from sympy.core.function import expand_mul
from sympy.core.numbers import pi, I
from sympy.functions.elementary.trigonometric import sin, cos
from sympy.ntheory import isprime, primitive_root
from sympy.utilities.iterables import ibin, iterable
from sympy.utilities.misc import as_int

def _fourier_transform(seq, dps, inverse=False):
    if not iterable(seq):
        raise TypeError('Expected a sequence of numeric coefficients for Fourier Transform')
    a = [sympify(arg) for arg in seq]
    if any((x.has(Symbol) for x in a)):
        raise ValueError('Expected non-symbolic coefficients')
    n = len(a)
    if n < 2:
        return a
    b = n.bit_length() - 1
    if n & n - 1:
        b += 1
        n = 2 ** b
    a += [S.Zero] * (n - len(a))
    for i in range(1, n):
        j = int(ibin(i, b, str=True)[::-1], 2)
        if i < j:
            a[i], a[j] = (a[j], a[i])
    ang = -2 * pi / n if inverse else 2 * pi / n
    if dps is not None:
        ang = ang.evalf(dps + 2)
    w = [cos(ang * i) + I * sin(ang * i) for i in range(n // 2)]
    h = 2
    while h <= n:
        hf, ut = (h // 2, n // h)
        for i in range(0, n, h):
            for j in range(hf):
                u, v = (a[i + j], expand_mul(a[i + j + hf] * w[ut * j]))
                a[i + j], a[i + j + hf] = (u + v, u - v)
        h *= 2
    if inverse:
        a = [(x / n).evalf(dps) for x in a] if dps is not None else [x / n for x in a]
    return a

def fft(seq, dps=None):
    return _fourier_transform(seq, dps=dps)

def ifft(seq, dps=None):
    return _fourier_transform(seq, dps=dps, inverse=True)
ifft.__doc__ = fft.__doc__

def _number_theoretic_transform(seq, prime, inverse=False):
    if not iterable(seq):
        raise TypeError('Expected a sequence of integer coefficients for Number Theoretic Transform')
    p = as_int(prime)
    if not isprime(p):
        raise ValueError('Expected prime modulus for Number Theoretic Transform')
    a = [as_int(x) % p for x in seq]
    n = len(a)
    if n < 1:
        return a
    b = n.bit_length() - 1
    if n & n - 1:
        b += 1
        n = 2 ** b
    if (p - 1) % n:
        raise ValueError('Expected prime modulus of the form (m*2**k + 1)')
    a += [0] * (n - len(a))
    for i in range(1, n):
        j = int(ibin(i, b, str=True)[::-1], 2)
        if i < j:
            a[i], a[j] = (a[j], a[i])
    pr = primitive_root(p)
    rt = pow(pr, (p - 1) // n, p)
    if inverse:
        rt = pow(rt, p - 2, p)
    w = [1] * (n // 2)
    for i in range(1, n // 2):
        w[i] = w[i - 1] * rt % p
    h = 2
    while h <= n:
        hf, ut = (h // 2, n // h)
        for i in range(0, n, h):
            for j in range(hf):
                u, v = (a[i + j], a[i + j + hf] * w[ut * j])
                a[i + j], a[i + j + hf] = ((u + v) % p, (u - v) % p)
        h *= 2
    if inverse:
        rv = pow(n, p - 2, p)
        a = [x * rv % p for x in a]
    return a

def ntt(seq, prime):
    return _number_theoretic_transform(seq, prime=prime)

def intt(seq, prime):
    return _number_theoretic_transform(seq, prime=prime, inverse=True)
intt.__doc__ = ntt.__doc__

def _walsh_hadamard_transform(seq, inverse=False):
    if not iterable(seq):
        raise TypeError('Expected a sequence of coefficients for Walsh Hadamard Transform')
    a = [sympify(arg) for arg in seq]
    n = len(a)
    if n < 2:
        return a
    if n & n - 1:
        n = 2 ** n.bit_length()
    a += [S.Zero] * (n - len(a))
    h = 2
    while h <= n:
        hf = h // 2
        for i in range(0, n, h):
            for j in range(hf):
                u, v = (a[i + j], a[i + j + hf])
                a[i + j], a[i + j + hf] = (u + v, u - v)
        h *= 2
    if inverse:
        a = [x / n for x in a]
    return a

def fwht(seq):
    return _walsh_hadamard_transform(seq)

def ifwht(seq):
    return _walsh_hadamard_transform(seq, inverse=True)
ifwht.__doc__ = fwht.__doc__

def _mobius_transform(seq, sgn, subset):
    if not iterable(seq):
        raise TypeError('Expected a sequence of coefficients')
    a = [sympify(arg) for arg in seq]
    n = len(a)
    if n < 2:
        return a
    if n & n - 1:
        n = 2 ** n.bit_length()
    a += [S.Zero] * (n - len(a))
    if subset:
        i = 1
        while i < n:
            for j in range(n):
                if j & i:
                    a[j] += sgn * a[j ^ i]
            i *= 2
    else:
        i = 1
        while i < n:
            for j in range(n):
                if j & i:
                    continue
                a[j] += sgn * a[j ^ i]
            i *= 2
    return a

def mobius_transform(seq, subset=True):
    return _mobius_transform(seq, sgn=+1, subset=subset)

def inverse_mobius_transform(seq, subset=True):
    return _mobius_transform(seq, sgn=-1, subset=subset)
inverse_mobius_transform.__doc__ = mobius_transform.__doc__