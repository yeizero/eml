from __future__ import annotations
from sympy.core.basic import Basic
from sympy.core.sympify import SympifyError
from ast import parse, NodeTransformer, Call, Name, Load, fix_missing_locations, Constant, Tuple

class Transform(NodeTransformer):

    def __init__(self, local_dict, global_dict):
        NodeTransformer.__init__(self)
        self.local_dict = local_dict
        self.global_dict = global_dict

    def visit_Constant(self, node):
        if isinstance(node.value, int):
            return fix_missing_locations(Call(func=Name('Integer', Load()), args=[node], keywords=[]))
        elif isinstance(node.value, float):
            return fix_missing_locations(Call(func=Name('Float', Load()), args=[node], keywords=[]))
        return node

    def visit_Name(self, node):
        if node.id in self.local_dict:
            return node
        elif node.id in self.global_dict:
            name_obj = self.global_dict[node.id]
            if isinstance(name_obj, (Basic, type)) or callable(name_obj):
                return node
        elif node.id in ['True', 'False']:
            return node
        return fix_missing_locations(Call(func=Name('Symbol', Load()), args=[Constant(node.id)], keywords=[]))

    def visit_Lambda(self, node):
        args = [self.visit(arg) for arg in node.args.args]
        body = self.visit(node.body)
        n = Call(func=Name('Lambda', Load()), args=[Tuple(args, Load()), body], keywords=[])
        return fix_missing_locations(n)

def parse_expr(s, local_dict):
    global_dict = {}
    exec('from sympy import *', global_dict)
    try:
        a = parse(s.strip(), mode='eval')
    except SyntaxError:
        raise SympifyError('Cannot parse %s.' % repr(s))
    a = Transform(local_dict, global_dict).visit(a)
    e = compile(a, '<string>', 'eval')
    return eval(e, global_dict, local_dict)