from __future__ import annotations
from sympy.external import import_module
from sympy.utilities.decorator import doctest_depends_on
from re import compile as rcompile
from sympy.parsing.latex.lark import LarkLaTeXParser, TransformToSymPyExpr, parse_latex_lark
from .errors import LaTeXParsingError
IGNORE_L = '\\s*[{]*\\s*'
IGNORE_R = '\\s*[}]*\\s*'
NO_LEFT = '(?<!\\\\left)'
BEGIN_AMS_MAT = '\\\\begin{matrix}'
END_AMS_MAT = '\\\\end{matrix}'
BEGIN_ARR = '\\\\begin{array}{.*?}'
END_ARR = '\\\\end{array}'
MATRIX_DELIMS = {f'\\\\left\\({IGNORE_L}{BEGIN_AMS_MAT}': f'{END_AMS_MAT}{IGNORE_R}\\\\right\\)', f'{NO_LEFT}\\({IGNORE_L}{BEGIN_AMS_MAT}': f'{END_AMS_MAT}{IGNORE_R}\\)', f'\\\\left\\[{IGNORE_L}{BEGIN_AMS_MAT}': f'{END_AMS_MAT}{IGNORE_R}\\\\right\\]', f'{NO_LEFT}\\[{IGNORE_L}{BEGIN_AMS_MAT}': f'{END_AMS_MAT}{IGNORE_R}\\]', f'\\\\left\\|{IGNORE_L}{BEGIN_AMS_MAT}': f'{END_AMS_MAT}{IGNORE_R}\\\\right\\|', f'{NO_LEFT}\\|{IGNORE_L}{BEGIN_AMS_MAT}': f'{END_AMS_MAT}{IGNORE_R}\\|', '\\\\begin{pmatrix}': '\\\\end{pmatrix}', '\\\\begin{bmatrix}': '\\\\end{bmatrix}', '\\\\begin{vmatrix}': '\\\\end{vmatrix}', f'\\\\left\\({IGNORE_L}{BEGIN_ARR}': f'{END_ARR}{IGNORE_R}\\\\right\\)', f'{NO_LEFT}\\({IGNORE_L}{BEGIN_ARR}': f'{END_ARR}{IGNORE_R}\\)', f'\\\\left\\[{IGNORE_L}{BEGIN_ARR}': f'{END_ARR}{IGNORE_R}\\\\right\\]', f'{NO_LEFT}\\[{IGNORE_L}{BEGIN_ARR}': f'{END_ARR}{IGNORE_R}\\]', f'\\\\left\\|{IGNORE_L}{BEGIN_ARR}': f'{END_ARR}{IGNORE_R}\\\\right\\|', f'{NO_LEFT}\\|{IGNORE_L}{BEGIN_ARR}': f'{END_ARR}{IGNORE_R}\\|'}
MATRIX_DELIMS_INV = {v: k for k, v in MATRIX_DELIMS.items()}
BEGIN_DELIM_REPR = {f'\\\\left\\({IGNORE_L}{BEGIN_AMS_MAT}': '\\left(\\begin{matrix}', f'{NO_LEFT}\\({IGNORE_L}{BEGIN_AMS_MAT}': '(\\begin{matrix}', f'\\\\left\\[{IGNORE_L}{BEGIN_AMS_MAT}': '\\left[\\begin{matrix}', f'{NO_LEFT}\\[{IGNORE_L}{BEGIN_AMS_MAT}': '[\\begin{matrix}', f'\\\\left\\|{IGNORE_L}{BEGIN_AMS_MAT}': '\\left|\\begin{matrix}', f'{NO_LEFT}\\|{IGNORE_L}{BEGIN_AMS_MAT}': '|\\begin{matrix}', '\\\\begin{pmatrix}': '\\begin{pmatrix}', '\\\\begin{bmatrix}': '\\begin{bmatrix}', '\\\\begin{vmatrix}': '\\begin{vmatrix}', f'\\\\left\\({IGNORE_L}{BEGIN_ARR}': '\\left(\\begin{array}{COLUMN_SPECIFIERS}', f'{NO_LEFT}\\({IGNORE_L}{BEGIN_ARR}': '(\\begin{array}{COLUMN_SPECIFIERS}', f'\\\\left\\[{IGNORE_L}{BEGIN_ARR}': '\\left[\\begin{array}{COLUMN_SPECIFIERS}', f'{NO_LEFT}\\[{IGNORE_L}{BEGIN_ARR}': '[\\begin{array}{COLUMN_SPECIFIERS}', f'\\\\left\\|{IGNORE_L}{BEGIN_ARR}': '\\left|\\begin{array}{COLUMN_SPECIFIERS}', f'{NO_LEFT}\\|{IGNORE_L}{BEGIN_ARR}': '|\\begin{array}{COLUMN_SPECIFIERS}'}
END_DELIM_REPR = {f'{END_AMS_MAT}{IGNORE_R}\\\\right\\)': '\\end{matrix}\\right)', f'{END_AMS_MAT}{IGNORE_R}\\)': '\\end{matrix})', f'{END_AMS_MAT}{IGNORE_R}\\\\right\\]': '\\end{matrix}\\right]', f'{END_AMS_MAT}{IGNORE_R}\\]': '\\end{matrix}]', f'{END_AMS_MAT}{IGNORE_R}\\\\right\\|': '\\end{matrix}\\right|', f'{END_AMS_MAT}{IGNORE_R}\\|': '\\end{matrix}|', '\\\\end{pmatrix}': '\\end{pmatrix}', '\\\\end{bmatrix}': '\\end{bmatrix}', '\\\\end{vmatrix}': '\\end{vmatrix}', f'{END_ARR}{IGNORE_R}\\\\right\\)': '\\end{array}\\right)', f'{END_ARR}{IGNORE_R}\\)': '\\end{array})', f'{END_ARR}{IGNORE_R}\\\\right\\]': '\\end{array}\\right]', f'{END_ARR}{IGNORE_R}\\]': '\\end{array}]', f'{END_ARR}{IGNORE_R}\\\\right\\|': '\\end{array}\\right|', f'{END_ARR}{IGNORE_R}\\|': '\\end{array}|'}

def check_matrix_delimiters(latex_str):
    spans = []
    for begin_delim in MATRIX_DELIMS:
        end_delim = MATRIX_DELIMS[begin_delim]
        p = rcompile(begin_delim)
        q = rcompile(end_delim)
        spans.extend([(*m.span(), m.group(), begin_delim) for m in p.finditer(latex_str)])
        spans.extend([(*m.span(), m.group(), end_delim) for m in q.finditer(latex_str)])
    spans.sort(key=lambda x: x[0])
    if len(spans) % 2 == 1:
        spans.append((None, None, None, None))
    spans = [(*x, *y) for x, y in zip(spans[::2], spans[1::2])]
    for x in spans:
        sellipsis = '...'
        s = x[0] - 10
        if s < 0:
            s = 0
            sellipsis = ''
        eellipsis = '...'
        e = x[1] + 10
        if e > len(latex_str):
            e = len(latex_str)
            eellipsis = ''
        if x[3] in END_DELIM_REPR:
            err = f"Extra '{x[2]}' at index {x[0]} or missing corresponding '{BEGIN_DELIM_REPR[MATRIX_DELIMS_INV[x[3]]]}' in LaTeX string: {sellipsis}{latex_str[s:e]}{eellipsis}"
            raise LaTeXParsingError(err)
        if x[7] is None:
            err = f"Extra '{x[2]}' at index {x[0]} or missing corresponding '{END_DELIM_REPR[MATRIX_DELIMS[x[3]]]}' in LaTeX string: {sellipsis}{latex_str[s:e]}{eellipsis}"
            raise LaTeXParsingError(err)
        correct_end_regex = MATRIX_DELIMS[x[3]]
        sellipsis = '...' if x[0] > 0 else ''
        eellipsis = '...' if x[5] < len(latex_str) else ''
        if x[7] != correct_end_regex:
            err = f"Expected '{END_DELIM_REPR[correct_end_regex]}' to close the '{x[2]}' at index {x[0]} but found '{x[6]}' at index {x[4]} of LaTeX string instead: {sellipsis}{latex_str[x[0]:x[5]]}{eellipsis}"
            raise LaTeXParsingError(err)

def check_cases_env(latex_str):
    if '\\begin{cases}' in latex_str:
        raise LaTeXParsingError("The 'cases' environment is not currently supported by parse_latex. \nIf you're trying to parse a piecewise function or a block of expressions, \nconsider breaking them into separate parse_latex calls.")
__doctest_requires__ = {('parse_latex',): ['antlr4', 'lark']}

@doctest_depends_on(modules=('antlr4', 'lark'))
def parse_latex(s, strict=False, backend='antlr'):
    check_cases_env(s)
    check_matrix_delimiters(s)
    if backend == 'antlr':
        _latex = import_module('sympy.parsing.latex._parse_latex_antlr', import_kwargs={'fromlist': ['X']})
        if _latex is not None:
            return _latex.parse_latex(s, strict)
    elif backend == 'lark':
        return parse_latex_lark(s)
    else:
        raise NotImplementedError(f"Using the '{backend}' backend in the LaTeX parser is not supported, backend must be one of ('antlr', 'lark')")