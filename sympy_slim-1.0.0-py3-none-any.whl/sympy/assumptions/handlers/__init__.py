from __future__ import annotations
from .common import test_closed_group
__all__ = ['test_closed_group']