from __future__ import annotations
from typing import TYPE_CHECKING, overload
from sympy.core import S, Add, Expr, Basic, Mul, Pow, Rational
from sympy.core.logic import fuzzy_not
from sympy.assumptions import ask, Q
if TYPE_CHECKING:
    from sympy.logic.boolalg import Boolean
    from typing import Callable

@overload
def refine(expr: Expr, assumptions: Boolean | bool=True) -> Expr:
    pass

@overload
def refine(expr: Basic, assumptions: Boolean | bool=True) -> Basic:
    pass

def refine(expr: Basic, assumptions: Boolean | bool=True) -> Basic:
    if not isinstance(expr, Basic):
        return expr
    if not expr.is_Atom:
        args = [refine(arg, assumptions) for arg in expr.args]
        expr = expr.func(*args)
    if hasattr(expr, '_eval_refine'):
        ref_expr = expr._eval_refine(assumptions)
        if ref_expr is not None:
            return ref_expr
    name = expr.__class__.__name__
    handler = handlers_dict.get(name, None)
    if handler is None:
        return expr
    new_expr = handler(expr, assumptions)
    if new_expr is None or expr == new_expr:
        return expr
    if not isinstance(new_expr, Expr):
        return new_expr
    return refine(new_expr, assumptions)

def refine_abs(expr, assumptions):
    from sympy.functions.elementary.complexes import Abs
    arg = expr.args[0]
    if ask(Q.real(arg), assumptions) and fuzzy_not(ask(Q.negative(arg), assumptions)):
        return arg
    if ask(Q.negative(arg), assumptions):
        return -arg
    if isinstance(arg, Mul):
        r = [refine(abs(a), assumptions) for a in arg.args]
        non_abs = []
        in_abs = []
        for i in r:
            if isinstance(i, Abs):
                in_abs.append(i.args[0])
            else:
                non_abs.append(i)
        return Mul(*non_abs) * Abs(Mul(*in_abs))

def refine_Pow(expr, assumptions):
    from sympy.functions.elementary.complexes import Abs
    from sympy.functions import sign
    if isinstance(expr.base, Abs):
        if ask(Q.real(expr.base.args[0]), assumptions) and ask(Q.even(expr.exp), assumptions):
            return expr.base.args[0] ** expr.exp
    if ask(Q.real(expr.base), assumptions):
        if expr.base.is_number:
            if ask(Q.even(expr.exp), assumptions):
                return abs(expr.base) ** expr.exp
            if ask(Q.odd(expr.exp), assumptions):
                return sign(expr.base) * abs(expr.base) ** expr.exp
        if isinstance(expr.exp, Rational):
            if isinstance(expr.base, Pow):
                return abs(expr.base.base) ** (expr.base.exp * expr.exp)
        if expr.base is S.NegativeOne:
            if expr.exp.is_Add:
                old = expr
                coeff, terms = expr.exp.as_coeff_add()
                terms = set(terms)
                even_terms = set()
                odd_terms = set()
                initial_number_of_terms = len(terms)
                for t in terms:
                    if ask(Q.even(t), assumptions):
                        even_terms.add(t)
                    elif ask(Q.odd(t), assumptions):
                        odd_terms.add(t)
                terms -= even_terms
                if len(odd_terms) % 2:
                    terms -= odd_terms
                    new_coeff = (coeff + S.One) % 2
                else:
                    terms -= odd_terms
                    new_coeff = coeff % 2
                if new_coeff != coeff or len(terms) < initial_number_of_terms:
                    terms.add(new_coeff)
                    expr = expr.base ** Add(*terms)
                e2 = 2 * expr.exp
                if ask(Q.even(e2), assumptions):
                    if e2.could_extract_minus_sign():
                        e2 *= expr.base
                if e2.is_Add:
                    i, p = e2.as_two_terms()
                    if p.is_Pow and p.base is S.NegativeOne:
                        if ask(Q.integer(p.exp), assumptions):
                            i = (i + 1) / 2
                            if ask(Q.even(i), assumptions):
                                return expr.base ** p.exp
                            elif ask(Q.odd(i), assumptions):
                                return expr.base ** (p.exp + 1)
                            else:
                                return expr.base ** (p.exp + i)
                if old != expr:
                    return expr

def refine_exp(expr, assumptions):
    coeff = expr.exp.as_coefficient(S.Pi * S.ImaginaryUnit)
    if coeff is None:
        return expr
    integer_terms = []
    remaining_terms = []
    terms = coeff.args if coeff.is_Add else (coeff,)
    for term in terms:
        if ask(Q.integer(term), assumptions):
            integer_terms.append(term)
        else:
            remaining_terms.append(term)
    if not integer_terms:
        return expr
    integer_part = Add(*integer_terms)
    remaining_part = Add(*remaining_terms)
    phase = expr.func(S.Pi * S.ImaginaryUnit * remaining_part)
    return (-1) ** integer_part * phase

def refine_atan2(expr, assumptions):
    from sympy.functions.elementary.trigonometric import atan
    y, x = expr.args
    if ask(Q.real(y) & Q.positive(x), assumptions):
        return atan(y / x)
    elif ask(Q.negative(y) & Q.negative(x), assumptions):
        return atan(y / x) - S.Pi
    elif ask(Q.positive(y) & Q.negative(x), assumptions):
        return atan(y / x) + S.Pi
    elif ask(Q.zero(y) & Q.negative(x), assumptions):
        return S.Pi
    elif ask(Q.positive(y) & Q.zero(x), assumptions):
        return S.Pi / 2
    elif ask(Q.negative(y) & Q.zero(x), assumptions):
        return -S.Pi / 2
    elif ask(Q.zero(y) & Q.zero(x), assumptions):
        return S.NaN
    else:
        return expr

def refine_re(expr, assumptions):
    arg = expr.args[0]
    if ask(Q.real(arg), assumptions):
        return arg
    if ask(Q.imaginary(arg), assumptions):
        return S.Zero
    return _refine_reim(expr, assumptions)

def refine_im(expr, assumptions):
    arg = expr.args[0]
    if ask(Q.real(arg), assumptions):
        return S.Zero
    if ask(Q.imaginary(arg), assumptions):
        return -S.ImaginaryUnit * arg
    return _refine_reim(expr, assumptions)

def refine_arg(expr, assumptions):
    rg = expr.args[0]
    if ask(Q.positive(rg), assumptions):
        return S.Zero
    if ask(Q.negative(rg), assumptions):
        return S.Pi
    return None

def _refine_reim(expr, assumptions):
    expanded = expr.expand(complex=True)
    if expanded != expr:
        refined = refine(expanded, assumptions)
        if refined != expanded:
            return refined
    return None

def refine_sign(expr, assumptions):
    arg = expr.args[0]
    if ask(Q.zero(arg), assumptions):
        return S.Zero
    if ask(Q.real(arg)):
        if ask(Q.positive(arg), assumptions):
            return S.One
        if ask(Q.negative(arg), assumptions):
            return S.NegativeOne
    if ask(Q.imaginary(arg)):
        arg_re, arg_im = arg.as_real_imag()
        if ask(Q.positive(arg_im), assumptions):
            return S.ImaginaryUnit
        if ask(Q.negative(arg_im), assumptions):
            return -S.ImaginaryUnit
    return expr

def refine_matrixelement(expr, assumptions):
    from sympy.matrices.expressions.matexpr import MatrixElement
    matrix, i, j = expr.args
    if ask(Q.symmetric(matrix), assumptions):
        if (i - j).could_extract_minus_sign():
            return expr
        return MatrixElement(matrix, j, i)

def refine_sin_cos(expr, assumptions):
    from sympy.functions.elementary.trigonometric import sin, cos
    from sympy.calculus.accumulationbounds import AccumBounds
    if not isinstance(expr, (sin, cos)):
        raise TypeError('refine_sin_cos expects a sin or cos function.')
    arg = expr.args[0]
    expr_is_sin = isinstance(expr, sin)
    if ask(Q.infinite(arg), assumptions) and ask(Q.extended_real(arg), assumptions):
        return AccumBounds(-1, 1)
    if ask(Q.zero(arg), assumptions):
        return 0 if expr_is_sin else 1
    integer_coeffs_of_pi_half = []
    remaining_terms = []
    terms = arg.args if arg.is_Add else (arg,)
    for term in terms:
        coeff_of_pi = term.coeff(S.Pi)
        if coeff_of_pi and ask(Q.integer(2 * coeff_of_pi), assumptions):
            coeff_of_pi_half = 2 * coeff_of_pi
            integer_coeffs_of_pi_half.append(coeff_of_pi_half)
        else:
            remaining_terms.append(term)
    if not integer_coeffs_of_pi_half:
        return expr
    sum_of_parity_known_coeffs = 0
    sum_of_parity_unknown_coeffs = 0
    sum_of_parity_known_coeffs_is_even = True
    for coeff in integer_coeffs_of_pi_half:
        coeff_is_even = ask(Q.even(coeff), assumptions)
        if coeff_is_even is None:
            sum_of_parity_unknown_coeffs += coeff
        else:
            sum_of_parity_known_coeffs += coeff
            sum_of_parity_known_coeffs_is_even = sum_of_parity_known_coeffs_is_even == coeff_is_even
    if sum_of_parity_known_coeffs == 0:
        return expr
    if expr_is_sin:
        k = sum_of_parity_known_coeffs - 1
        k_is_even = not sum_of_parity_known_coeffs_is_even
    else:
        k = sum_of_parity_known_coeffs
        k_is_even = sum_of_parity_known_coeffs_is_even
    rem = sum(remaining_terms) + sum_of_parity_unknown_coeffs * S.Pi / 2
    if k_is_even:
        pow_expr = (-1) ** (k / 2)
        refined_pow = refine_Pow(pow_expr, assumptions)
        return (pow_expr if refined_pow is None else refined_pow) * cos(rem)
    else:
        pow_expr = (-1) ** ((k + 1) / 2)
        refined_pow = refine_Pow(pow_expr, assumptions)
        return (pow_expr if refined_pow is None else refined_pow) * sin(rem)

def refine_Heaviside(expr, assumptions):
    arg, H0 = expr.args
    if ask(Q.positive(arg), assumptions):
        return S.One
    if ask(Q.negative(arg), assumptions):
        return S.Zero
    if ask(Q.zero(arg), assumptions):
        return H0
    return expr

def refine_floor_ceiling(expr, assumptions):
    from sympy.functions.elementary.integers import floor, ceiling
    arg = expr.args[0]
    if ask(Q.integer(arg), assumptions) or ask(Q.infinite(arg), assumptions):
        return arg
    if isinstance(arg, Add):
        gaussian_integer_terms = []
        nongausian_intergers_terms = []
        for term in arg.args:
            if ask(Q.integer(term), assumptions) or isinstance(term, (floor, ceiling)):
                gaussian_integer_terms.append(term)
            else:
                nongausian_intergers_terms.append(term)
        return Add(*gaussian_integer_terms) + expr.func(Add(*nongausian_intergers_terms))
    return expr
handlers_dict: dict[str, Callable[[Basic, Boolean | bool], Expr]] = {'Abs': refine_abs, 'Pow': refine_Pow, 'atan2': refine_atan2, 're': refine_re, 'im': refine_im, 'arg': refine_arg, 'sign': refine_sign, 'MatrixElement': refine_matrixelement, 'cos': refine_sin_cos, 'sin': refine_sin_cos, 'exp': refine_exp, 'Heaviside': refine_Heaviside, 'floor': refine_floor_ceiling, 'ceiling': refine_floor_ceiling}