from __future__ import annotations
__all__ = ['BinaryRelation', 'AppliedBinaryRelation']
from .binrel import BinaryRelation, AppliedBinaryRelation