from __future__ import annotations
from sympy.assumptions import Q
from sympy.core.relational import is_eq, is_neq, is_gt, is_ge, is_lt, is_le
from .binrel import BinaryRelation
__all__ = ['EqualityPredicate', 'UnequalityPredicate', 'StrictGreaterThanPredicate', 'GreaterThanPredicate', 'StrictLessThanPredicate', 'LessThanPredicate']

class EqualityPredicate(BinaryRelation):
    is_reflexive = True
    is_symmetric = True
    name = 'eq'
    handler = None

    @property
    def negated(self):
        return Q.ne

    def eval(self, args, assumptions=True):
        if assumptions == True:
            assumptions = None
        return is_eq(*args, assumptions)

class UnequalityPredicate(BinaryRelation):
    is_reflexive = False
    is_symmetric = True
    name = 'ne'
    handler = None

    @property
    def negated(self):
        return Q.eq

    def eval(self, args, assumptions=True):
        if assumptions == True:
            assumptions = None
        return is_neq(*args, assumptions)

class StrictGreaterThanPredicate(BinaryRelation):
    is_reflexive = False
    is_symmetric = False
    name = 'gt'
    handler = None

    @property
    def reversed(self):
        return Q.lt

    @property
    def negated(self):
        return Q.le

    def eval(self, args, assumptions=True):
        if assumptions == True:
            assumptions = None
        return is_gt(*args, assumptions)

class GreaterThanPredicate(BinaryRelation):
    is_reflexive = True
    is_symmetric = False
    name = 'ge'
    handler = None

    @property
    def reversed(self):
        return Q.le

    @property
    def negated(self):
        return Q.lt

    def eval(self, args, assumptions=True):
        if assumptions == True:
            assumptions = None
        return is_ge(*args, assumptions)

class StrictLessThanPredicate(BinaryRelation):
    is_reflexive = False
    is_symmetric = False
    name = 'lt'
    handler = None

    @property
    def reversed(self):
        return Q.gt

    @property
    def negated(self):
        return Q.ge

    def eval(self, args, assumptions=True):
        if assumptions == True:
            assumptions = None
        return is_lt(*args, assumptions)

class LessThanPredicate(BinaryRelation):
    is_reflexive = True
    is_symmetric = False
    name = 'le'
    handler = None

    @property
    def reversed(self):
        return Q.ge

    @property
    def negated(self):
        return Q.gt

    def eval(self, args, assumptions=True):
        if assumptions == True:
            assumptions = None
        return is_le(*args, assumptions)