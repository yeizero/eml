from __future__ import annotations
from sympy.core.singleton import S
from sympy.assumptions import AppliedPredicate, ask, Predicate, Q
from sympy.core.kind import BooleanKind
from sympy.core.relational import Eq, Ne, Gt, Lt, Ge, Le
from sympy.logic.boolalg import conjuncts, Not
__all__ = ['BinaryRelation', 'AppliedBinaryRelation']

class BinaryRelation(Predicate):
    is_reflexive: bool | None = None
    is_symmetric: bool | None = None

    def __call__(self, *args):
        if not len(args) == 2:
            raise TypeError(f'Q.{self.name} takes two arguments, but got {len(args)}.')
        return AppliedBinaryRelation(self, *args)

    @property
    def reversed(self):
        if self.is_symmetric:
            return self
        return None

    @property
    def negated(self):
        return None

    def _compare_reflexive(self, lhs, rhs):
        if lhs is S.NaN or rhs is S.NaN:
            return None
        reflexive = self.is_reflexive
        if reflexive is None:
            pass
        elif reflexive and lhs == rhs:
            return True
        elif not reflexive and lhs == rhs:
            return False
        return None

    def eval(self, args, assumptions=True):
        ret = self._compare_reflexive(*args)
        if ret is not None:
            return ret
        lhs, rhs = args
        ret = self.handler(lhs, rhs, assumptions=assumptions)
        if ret is not None:
            return ret
        if self.is_reflexive:
            types = (type(lhs), type(rhs))
            if self.handler.dispatch(*types) is not self.handler.dispatch(*reversed(types)):
                ret = self.handler(rhs, lhs, assumptions=assumptions)
        return ret

class AppliedBinaryRelation(AppliedPredicate):

    @property
    def lhs(self):
        return self.arguments[0]

    @property
    def rhs(self):
        return self.arguments[1]

    @property
    def reversed(self):
        revfunc = self.function.reversed
        if revfunc is None:
            return self
        return revfunc(self.rhs, self.lhs)

    @property
    def reversedsign(self):
        revfunc = self.function.reversed
        if revfunc is None:
            return self
        if not any((side.kind is BooleanKind for side in self.arguments)):
            return revfunc(-self.lhs, -self.rhs)
        return self

    @property
    def negated(self):
        neg_rel = self.function.negated
        if neg_rel is None:
            return Not(self, evaluate=False)
        return neg_rel(*self.arguments)

    def _eval_ask(self, assumptions):
        conj_assumps = set()
        binrelpreds = {Eq: Q.eq, Ne: Q.ne, Gt: Q.gt, Lt: Q.lt, Ge: Q.ge, Le: Q.le}
        for a in conjuncts(assumptions):
            if a.func in binrelpreds:
                conj_assumps.add(binrelpreds[type(a)](*a.args))
            else:
                conj_assumps.add(a)
        if any((rel in conj_assumps for rel in (self, self.reversed))):
            return True
        neg_rels = (self.negated, self.reversed.negated, Not(self, evaluate=False), Not(self.reversed, evaluate=False))
        if any((rel in conj_assumps for rel in neg_rels)):
            return False
        ret = self.function.eval(self.arguments, assumptions)
        if ret is not None:
            return ret
        args = tuple((a.simplify() for a in self.arguments))
        return self.function.eval(args, assumptions)

    def __bool__(self):
        ret = ask(self)
        if ret is None:
            raise TypeError(f'Cannot determine truth value of {self}')
        return ret