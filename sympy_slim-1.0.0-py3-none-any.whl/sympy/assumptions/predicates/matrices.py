from __future__ import annotations
from sympy.assumptions import Predicate
from sympy.multipledispatch import Dispatcher

class SquarePredicate(Predicate):
    name = 'square'
    handler = Dispatcher('SquareHandler', doc='Handler for Q.square.')

class SymmetricPredicate(Predicate):
    name = 'symmetric'
    handler = Dispatcher('SymmetricHandler', doc='Handler for Q.symmetric.')

class InvertiblePredicate(Predicate):
    name = 'invertible'
    handler = Dispatcher('InvertibleHandler', doc='Handler for Q.invertible.')

class OrthogonalPredicate(Predicate):
    name = 'orthogonal'
    handler = Dispatcher('OrthogonalHandler', doc="Handler for key 'orthogonal'.")

class UnitaryPredicate(Predicate):
    name = 'unitary'
    handler = Dispatcher('UnitaryHandler', doc="Handler for key 'unitary'.")

class FullRankPredicate(Predicate):
    name = 'fullrank'
    handler = Dispatcher('FullRankHandler', doc="Handler for key 'fullrank'.")

class PositiveDefinitePredicate(Predicate):
    name = 'positive_definite'
    handler = Dispatcher('PositiveDefiniteHandler', doc="Handler for key 'positive_definite'.")

class UpperTriangularPredicate(Predicate):
    name = 'upper_triangular'
    handler = Dispatcher('UpperTriangularHandler', doc="Handler for key 'upper_triangular'.")

class LowerTriangularPredicate(Predicate):
    name = 'lower_triangular'
    handler = Dispatcher('LowerTriangularHandler', doc="Handler for key 'lower_triangular'.")

class DiagonalPredicate(Predicate):
    name = 'diagonal'
    handler = Dispatcher('DiagonalHandler', doc="Handler for key 'diagonal'.")

class IntegerElementsPredicate(Predicate):
    name = 'integer_elements'
    handler = Dispatcher('IntegerElementsHandler', doc="Handler for key 'integer_elements'.")

class RealElementsPredicate(Predicate):
    name = 'real_elements'
    handler = Dispatcher('RealElementsHandler', doc="Handler for key 'real_elements'.")

class ComplexElementsPredicate(Predicate):
    name = 'complex_elements'
    handler = Dispatcher('ComplexElementsHandler', doc="Handler for key 'complex_elements'.")

class SingularPredicate(Predicate):
    name = 'singular'
    handler = Dispatcher('SingularHandler', doc="Predicate fore key 'singular'.")

class NormalPredicate(Predicate):
    name = 'normal'
    handler = Dispatcher('NormalHandler', doc="Predicate fore key 'normal'.")

class TriangularPredicate(Predicate):
    name = 'triangular'
    handler = Dispatcher('TriangularHandler', doc="Predicate fore key 'triangular'.")

class UnitTriangularPredicate(Predicate):
    name = 'unit_triangular'
    handler = Dispatcher('UnitTriangularHandler', doc="Predicate fore key 'unit_triangular'.")