from __future__ import annotations
from sympy.assumptions import Predicate
from sympy.multipledispatch import Dispatcher

class FinitePredicate(Predicate):
    name = 'finite'
    handler = Dispatcher('FiniteHandler', doc='Handler for Q.finite. Test that an expression is bounded respect to all its variables.')

class InfinitePredicate(Predicate):
    name = 'infinite'
    handler = Dispatcher('InfiniteHandler', doc='Handler for Q.infinite key.')

class PositiveInfinitePredicate(Predicate):
    name = 'positive_infinite'
    handler = Dispatcher('PositiveInfiniteHandler')

class NegativeInfinitePredicate(Predicate):
    name = 'negative_infinite'
    handler = Dispatcher('NegativeInfiniteHandler')