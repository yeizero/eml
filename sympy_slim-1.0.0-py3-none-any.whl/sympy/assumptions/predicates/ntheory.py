from __future__ import annotations
from sympy.assumptions import Predicate
from sympy.multipledispatch import Dispatcher

class PrimePredicate(Predicate):
    name = 'prime'
    handler = Dispatcher('PrimeHandler', doc="Handler for key 'prime'. Test that an expression represents a prime number. When the expression is an exact number, the result (when True) is subject to the limitations of isprime() which is used to return the result.")

class CompositePredicate(Predicate):
    name = 'composite'
    handler = Dispatcher('CompositeHandler', doc="Handler for key 'composite'.")

class EvenPredicate(Predicate):
    name = 'even'
    handler = Dispatcher('EvenHandler', doc="Handler for key 'even'.")

class OddPredicate(Predicate):
    name = 'odd'
    handler = Dispatcher('OddHandler', doc="Handler for key 'odd'. Test that an expression represents an odd number.")