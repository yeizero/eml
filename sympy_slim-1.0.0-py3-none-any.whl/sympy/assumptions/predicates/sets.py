from __future__ import annotations
from sympy.assumptions import Predicate
from sympy.multipledispatch import Dispatcher

class IntegerPredicate(Predicate):
    name = 'integer'
    handler = Dispatcher('IntegerHandler', doc='Handler for Q.integer.\n\nTest that an expression belongs to the field of integer numbers.')

class NonIntegerPredicate(Predicate):
    name = 'noninteger'
    handler = Dispatcher('NonIntegerHandler', doc='Handler for Q.noninteger.\n\nTest that an expression is a non-integer extended real number.')

class RationalPredicate(Predicate):
    name = 'rational'
    handler = Dispatcher('RationalHandler', doc='Handler for Q.rational.\n\nTest that an expression belongs to the field of rational numbers.')

class IrrationalPredicate(Predicate):
    name = 'irrational'
    handler = Dispatcher('IrrationalHandler', doc='Handler for Q.irrational.\n\nTest that an expression is irrational numbers.')

class RealPredicate(Predicate):
    name = 'real'
    handler = Dispatcher('RealHandler', doc='Handler for Q.real.\n\nTest that an expression belongs to the field of real numbers.')

class ExtendedRealPredicate(Predicate):
    name = 'extended_real'
    handler = Dispatcher('ExtendedRealHandler', doc='Handler for Q.extended_real.\n\nTest that an expression belongs to the field of extended real\nnumbers, that is real numbers union {Infinity, -Infinity}.')

class HermitianPredicate(Predicate):
    name = 'hermitian'
    handler = Dispatcher('HermitianHandler', doc='Handler for Q.hermitian.\n\nTest that an expression belongs to the field of Hermitian operators.')

class ComplexPredicate(Predicate):
    name = 'complex'
    handler = Dispatcher('ComplexHandler', doc='Handler for Q.complex.\n\nTest that an expression belongs to the field of complex numbers.')

class ImaginaryPredicate(Predicate):
    name = 'imaginary'
    handler = Dispatcher('ImaginaryHandler', doc='Handler for Q.imaginary.\n\nTest that an expression belongs to the field of imaginary numbers,\nthat is, numbers in the form x*I, where x is real.')

class AntihermitianPredicate(Predicate):
    name = 'antihermitian'
    handler = Dispatcher('AntiHermitianHandler', doc='Handler for Q.antihermitian.\n\nTest that an expression belongs to the field of anti-Hermitian\noperators, that is, operators in the form x*I, where x is Hermitian.')

class AlgebraicPredicate(Predicate):
    name = 'algebraic'
    AlgebraicHandler = Dispatcher('AlgebraicHandler', doc='Handler for Q.algebraic key.')

class TranscendentalPredicate(Predicate):
    name = 'transcendental'
    handler = Dispatcher('Transcendental', doc='Handler for Q.transcendental key.')