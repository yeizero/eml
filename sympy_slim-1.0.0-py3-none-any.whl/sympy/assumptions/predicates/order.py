from __future__ import annotations
from sympy.assumptions import Predicate
from sympy.multipledispatch import Dispatcher

class NegativePredicate(Predicate):
    name = 'negative'
    handler = Dispatcher('NegativeHandler', doc='Handler for Q.negative. Test that an expression is strictly less than zero.')

class NonNegativePredicate(Predicate):
    name = 'nonnegative'
    handler = Dispatcher('NonNegativeHandler', doc='Handler for Q.nonnegative.')

class NonZeroPredicate(Predicate):
    name = 'nonzero'
    handler = Dispatcher('NonZeroHandler', doc="Handler for key 'nonzero'. Test that an expression is not identically zero.")

class ZeroPredicate(Predicate):
    name = 'zero'
    handler = Dispatcher('ZeroHandler', doc="Handler for key 'zero'.")

class NonPositivePredicate(Predicate):
    name = 'nonpositive'
    handler = Dispatcher('NonPositiveHandler', doc="Handler for key 'nonpositive'.")

class PositivePredicate(Predicate):
    name = 'positive'
    handler = Dispatcher('PositiveHandler', doc="Handler for key 'positive'. Test that an expression is strictly greater than zero.")

class ExtendedPositivePredicate(Predicate):
    name = 'extended_positive'
    handler = Dispatcher('ExtendedPositiveHandler')

class ExtendedNegativePredicate(Predicate):
    name = 'extended_negative'
    handler = Dispatcher('ExtendedNegativeHandler')

class ExtendedNonZeroPredicate(Predicate):
    name = 'extended_nonzero'
    handler = Dispatcher('ExtendedNonZeroHandler')

class ExtendedNonPositivePredicate(Predicate):
    name = 'extended_nonpositive'
    handler = Dispatcher('ExtendedNonPositiveHandler')

class ExtendedNonNegativePredicate(Predicate):
    name = 'extended_nonnegative'
    handler = Dispatcher('ExtendedNonNegativeHandler')