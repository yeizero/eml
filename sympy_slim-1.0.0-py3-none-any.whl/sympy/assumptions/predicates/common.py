from __future__ import annotations
from sympy.assumptions import Predicate, AppliedPredicate, Q
from sympy.core.relational import Eq, Ne, Gt, Lt, Ge, Le
from sympy.multipledispatch import Dispatcher

class CommutativePredicate(Predicate):
    name = 'commutative'
    handler = Dispatcher('CommutativeHandler', doc="Handler for key 'commutative'.")
binrelpreds = {Eq: Q.eq, Ne: Q.ne, Gt: Q.gt, Lt: Q.lt, Ge: Q.ge, Le: Q.le}

class IsTruePredicate(Predicate):
    name = 'is_true'
    handler = Dispatcher('IsTrueHandler', doc='Wrapper allowing to query the truth value of a boolean expression.')

    def __call__(self, arg):
        if isinstance(arg, AppliedPredicate):
            return arg
        if getattr(arg, 'is_Relational', False):
            pred = binrelpreds[type(arg)]
            return pred(*arg.args)
        return super().__call__(arg)