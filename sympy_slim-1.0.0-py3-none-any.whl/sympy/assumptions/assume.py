from __future__ import annotations
from contextlib import contextmanager
from sympy.core.symbol import Str
from sympy.core.sympify import _sympify
from sympy.logic.boolalg import Boolean, false, true
from sympy.multipledispatch.dispatcher import Dispatcher, str_signature
from sympy.utilities.iterables import is_sequence

class AssumptionsContext(set):

    def add(self, *assumptions):
        for a in assumptions:
            super().add(a)

    def _sympystr(self, printer):
        if not self:
            return f'{self.__class__.__name__}()'
        return '{}({})'.format(self.__class__.__name__, printer._print_set(self))
global_assumptions = AssumptionsContext()

class AppliedPredicate(Boolean):
    __slots__ = ()

    def __new__(cls, predicate, *args):
        if not isinstance(predicate, Predicate):
            raise TypeError(f'{predicate} is not a Predicate.')
        args = map(_sympify, args)
        return super().__new__(cls, predicate, *args)

    @property
    def arg(self):
        args = self._args
        if len(args) == 2:
            return args[1]
        raise TypeError("'arg' property is allowed only for unary predicates.")

    @property
    def function(self):
        return self._args[0]

    @property
    def arguments(self):
        return self._args[1:]

    def _eval_ask(self, assumptions):
        return self.function.eval(self.arguments, assumptions)

    @property
    def binary_symbols(self):
        from .ask import Q
        if self.function == Q.is_true:
            i = self.arguments[0]
            if i.is_Boolean or i.is_Symbol:
                return i.binary_symbols
        if self.function in (Q.eq, Q.ne):
            if true in self.arguments or false in self.arguments:
                if self.arguments[0].is_Symbol:
                    return {self.arguments[0]}
                elif self.arguments[1].is_Symbol:
                    return {self.arguments[1]}
        return set()

class PredicateMeta(type):

    def __new__(cls, clsname, bases, dct):
        if 'handler' not in dct:
            name = f'Ask{clsname.capitalize()}Handler'
            handler = Dispatcher(name, doc=f'Handler for key {name}')
            dct['handler'] = handler
        dct['_orig_doc'] = dct.get('__doc__', '')
        return super().__new__(cls, clsname, bases, dct)

    @property
    def __doc__(cls):
        handler = cls.handler
        doc = cls._orig_doc
        if cls is not Predicate and handler is not None:
            doc += 'Handler\n'
            doc += '    =======\n\n'
            docs = [f'    Multiply dispatched method: {handler.name}']
            if handler.doc:
                for line in handler.doc.splitlines():
                    if not line:
                        continue
                    docs.append(f'    {line}')
            other = []
            for sig in handler.ordering[::-1]:
                func = handler.funcs[sig]
                if func.__doc__:
                    s = f'    Inputs: <{str_signature(sig)}>'
                    lines = []
                    for line in func.__doc__.splitlines():
                        lines.append(f'    {line}')
                    s += '\n'.join(lines)
                    docs.append(s)
                else:
                    other.append(str_signature(sig))
            if other:
                othersig = '    Other signatures:'
                for line in other:
                    othersig += f'\n        * {line}'
                docs.append(othersig)
            doc += '\n\n'.join(docs)
        return doc

class Predicate(Boolean, metaclass=PredicateMeta):
    is_Atom = True

    def __new__(cls, *args, **kwargs):
        if cls is Predicate:
            return UndefinedPredicate(*args, **kwargs)
        obj = super().__new__(cls, *args)
        return obj

    @property
    def name(self):
        return type(self).__name__

    @classmethod
    def register(cls, *types, **kwargs):
        if cls.handler is None:
            raise TypeError(f'{type(cls)} cannot be dispatched.')
        return cls.handler.register(*types, **kwargs)

    @classmethod
    def register_many(cls, *types, **kwargs):

        def _(func):
            for t in types:
                if not is_sequence(t):
                    t = (t,)
                cls.register(*t, **kwargs)(func)
        return _

    def __call__(self, *args):
        return AppliedPredicate(self, *args)

    def eval(self, args, assumptions=True):
        result = None
        try:
            result = self.handler(*args, assumptions=assumptions)
        except NotImplementedError:
            pass
        return result

    def _eval_refine(self, assumptions):
        return self

class UndefinedPredicate(Predicate):
    handler = None

    def __new__(cls, name, handlers=None):
        if not isinstance(name, Str):
            name = Str(name)
        obj = super(Boolean, cls).__new__(cls, name)
        obj.handlers = handlers or []
        return obj

    @property
    def name(self):
        return self.args[0]

    def _hashable_content(self):
        return (self.name,)

    def __getnewargs__(self):
        return (self.name,)

    def __call__(self, expr):
        return AppliedPredicate(self, expr)

    def eval(self, args, assumptions=True):
        return None

@contextmanager
def assuming(*assumptions):
    old_global_assumptions = global_assumptions.copy()
    global_assumptions.update(assumptions)
    try:
        yield
    finally:
        global_assumptions.clear()
        global_assumptions.update(old_global_assumptions)