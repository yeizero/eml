from __future__ import annotations
from sympy.core.singleton import S
from sympy.core.symbol import Symbol
from sympy.core.kind import NumberKind, UndefinedKind
from sympy.assumptions.ask_generated import get_all_known_matrix_facts, get_all_known_number_facts
from sympy.assumptions.assume import global_assumptions, AppliedPredicate
from sympy.assumptions.sathandlers import class_fact_registry
from sympy.core import oo
from sympy.logic.inference import satisfiable
from sympy.assumptions.cnf import CNF, EncodedCNF
from sympy.matrices.kind import MatrixKind

def satask(proposition, assumptions=True, context=global_assumptions, use_known_facts=True, iterations=oo):
    props = CNF.from_prop(proposition)
    _props = CNF.from_prop(~proposition)
    assumptions = CNF.from_prop(assumptions)
    context_cnf = CNF()
    if context:
        context_cnf = context_cnf.extend(context)
    sat = get_all_relevant_facts(props, assumptions, context_cnf, use_known_facts=use_known_facts, iterations=iterations)
    sat.add_from_cnf(assumptions)
    if context:
        sat.add_from_cnf(context_cnf)
    return check_satisfiability(props, _props, sat)

def check_satisfiability(prop, _prop, factbase):
    sat_true = factbase.copy()
    sat_false = factbase.copy()
    sat_true.add_from_cnf(prop)
    sat_false.add_from_cnf(_prop)
    can_be_true = satisfiable(sat_true)
    can_be_false = satisfiable(sat_false)
    if can_be_true and can_be_false:
        return None
    if can_be_true and (not can_be_false):
        return True
    if not can_be_true and can_be_false:
        return False
    if not can_be_true and (not can_be_false):
        raise ValueError('Inconsistent assumptions')

def extract_predargs(proposition, assumptions=None, context=None):
    req_keys = find_symbols(proposition)
    keys = proposition.all_predicates()
    lkeys = set()
    if assumptions:
        lkeys |= assumptions.all_predicates()
    if context:
        lkeys |= context.all_predicates()
    lkeys = lkeys - {S.true, S.false}
    tmp_keys = None
    while tmp_keys != set():
        tmp = set()
        for l in lkeys:
            syms = find_symbols(l)
            if syms & req_keys != set():
                tmp |= syms
        tmp_keys = tmp - req_keys
        req_keys |= tmp_keys
    keys |= {l for l in lkeys if find_symbols(l) & req_keys != set()}
    exprs = set()
    for key in keys:
        if isinstance(key, AppliedPredicate):
            exprs |= set(key.arguments)
        else:
            exprs.add(key)
    return exprs

def find_symbols(pred):
    if isinstance(pred, CNF):
        symbols = set()
        for a in pred.all_predicates():
            symbols |= find_symbols(a)
        return symbols
    return pred.atoms(Symbol)

def get_relevant_clsfacts(exprs, relevant_facts=None):
    if not relevant_facts:
        relevant_facts = CNF()
    newexprs = set()
    for expr in exprs:
        for fact in class_fact_registry(expr):
            newfact = CNF.to_CNF(fact)
            relevant_facts = relevant_facts._and(newfact)
            for key in newfact.all_predicates():
                if isinstance(key, AppliedPredicate):
                    newexprs |= set(key.arguments)
    return (newexprs - exprs, relevant_facts)

def get_all_relevant_facts(proposition, assumptions, context, use_known_facts=True, iterations=oo):
    i = 0
    relevant_facts = CNF()
    all_exprs = set()
    while True:
        if i == 0:
            exprs = extract_predargs(proposition, assumptions, context)
        all_exprs |= exprs
        exprs, relevant_facts = get_relevant_clsfacts(exprs, relevant_facts)
        i += 1
        if i >= iterations:
            break
        if not exprs:
            break
    if use_known_facts:
        known_facts_CNF = CNF()
        if any((expr.kind == MatrixKind(NumberKind) for expr in all_exprs)):
            known_facts_CNF.add_clauses(get_all_known_matrix_facts())
        if any((expr.kind == NumberKind or expr.kind == UndefinedKind for expr in all_exprs)):
            known_facts_CNF.add_clauses(get_all_known_number_facts())
        kf_encoded = EncodedCNF()
        kf_encoded.from_cnf(known_facts_CNF)

        def translate_literal(lit, delta):
            if lit > 0:
                return lit + delta
            else:
                return lit - delta

        def translate_data(data, delta):
            return [{translate_literal(i, delta) for i in clause} for clause in data]
        data = []
        symbols = []
        n_lit = len(kf_encoded.symbols)
        for i, expr in enumerate(all_exprs):
            symbols += [pred(expr) for pred in kf_encoded.symbols]
            data += translate_data(kf_encoded.data, i * n_lit)
        encoding = dict(list(zip(symbols, range(1, len(symbols) + 1))))
        ctx = EncodedCNF(data, encoding)
    else:
        ctx = EncodedCNF()
    ctx.add_from_cnf(relevant_facts)
    return ctx