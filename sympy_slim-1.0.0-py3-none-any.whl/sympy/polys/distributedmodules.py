from __future__ import annotations
from itertools import permutations
from sympy.polys.monomials import monomial_mul, monomial_lcm, monomial_div, monomial_deg
from sympy.polys.polytools import Poly
from sympy.polys.polyutils import parallel_dict_from_expr
from sympy.core.singleton import S
from sympy.core.sympify import sympify

def sdm_monomial_mul(M, X):
    return (M[0],) + monomial_mul(X, M[1:])

def sdm_monomial_deg(M):
    return monomial_deg(M[1:])

def sdm_monomial_lcm(A, B):
    return (A[0],) + monomial_lcm(A[1:], B[1:])

def sdm_monomial_divides(A, B):
    return A[0] == B[0] and all((a <= b for a, b in zip(A[1:], B[1:])))

def sdm_LC(f, K):
    if not f:
        return K.zero
    else:
        return f[0][1]

def sdm_to_dict(f):
    return dict(f)

def sdm_from_dict(d, O):
    return sdm_strip(sdm_sort(list(d.items()), O))

def sdm_sort(f, O):
    return sorted(f, key=lambda term: O(term[0]), reverse=True)

def sdm_strip(f):
    return [(monom, coeff) for monom, coeff in f if coeff]

def sdm_add(f, g, O, K):
    h = dict(f)
    for monom, c in g:
        if monom in h:
            coeff = h[monom] + c
            if not coeff:
                del h[monom]
            else:
                h[monom] = coeff
        else:
            h[monom] = c
    return sdm_from_dict(h, O)

def sdm_LM(f):
    return f[0][0]

def sdm_LT(f):
    return f[0]

def sdm_mul_term(f, term, O, K):
    X, c = term
    if not f or not c:
        return []
    elif K.is_one(c):
        return [(sdm_monomial_mul(f_M, X), f_c) for f_M, f_c in f]
    else:
        return [(sdm_monomial_mul(f_M, X), f_c * c) for f_M, f_c in f]

def sdm_zero():
    return []

def sdm_deg(f):
    return max((sdm_monomial_deg(M[0]) for M in f))

def sdm_from_vector(vec, O, K, **opts):
    dics, gens = parallel_dict_from_expr(sympify(vec), **opts)
    dic = {}
    for i, d in enumerate(dics):
        for k, v in d.items():
            dic[(i,) + k] = K.convert(v)
    return sdm_from_dict(dic, O)

def sdm_to_vector(f, gens, K, n=None):
    dic = sdm_to_dict(f)
    dics = {}
    for k, v in dic.items():
        dics.setdefault(k[0], []).append((k[1:], v))
    n = n or len(dics)
    res = []
    for k in range(n):
        if k in dics:
            res.append(Poly(dict(dics[k]), gens=gens, domain=K).as_expr())
        else:
            res.append(S.Zero)
    return res

def sdm_spoly(f, g, O, K, phantom=None):
    if not f or not g:
        return sdm_zero()
    LM1 = sdm_LM(f)
    LM2 = sdm_LM(g)
    if LM1[0] != LM2[0]:
        return sdm_zero()
    LM1 = LM1[1:]
    LM2 = LM2[1:]
    lcm = monomial_lcm(LM1, LM2)
    m1 = monomial_div(lcm, LM1)
    m2 = monomial_div(lcm, LM2)
    c = K.quo(-sdm_LC(f, K), sdm_LC(g, K))
    r1 = sdm_add(sdm_mul_term(f, (m1, K.one), O, K), sdm_mul_term(g, (m2, c), O, K), O, K)
    if phantom is None:
        return r1
    r2 = sdm_add(sdm_mul_term(phantom[0], (m1, K.one), O, K), sdm_mul_term(phantom[1], (m2, c), O, K), O, K)
    return (r1, r2)

def sdm_ecart(f):
    return sdm_deg(f) - sdm_monomial_deg(sdm_LM(f))

def sdm_nf_mora(f, G, O, K, phantom=None):
    from itertools import repeat
    h = f
    T = list(G)
    if phantom is not None:
        hp = phantom[0]
        Tp = list(phantom[1])
        phantom = True
    else:
        Tp = repeat([])
        phantom = False
    while h:
        Th = [(g, sdm_ecart(g), gp) for g, gp in zip(T, Tp) if sdm_monomial_divides(sdm_LM(g), sdm_LM(h))]
        if not Th:
            break
        g, _, gp = min(Th, key=lambda x: x[1])
        if sdm_ecart(g) > sdm_ecart(h):
            T.append(h)
            if phantom:
                Tp.append(hp)
        if phantom:
            h, hp = sdm_spoly(h, g, O, K, phantom=(hp, gp))
        else:
            h = sdm_spoly(h, g, O, K)
    if phantom:
        return (h, hp)
    return h

def sdm_nf_buchberger(f, G, O, K, phantom=None):
    from itertools import repeat
    h = f
    T = list(G)
    if phantom is not None:
        hp = phantom[0]
        Tp = list(phantom[1])
        phantom = True
    else:
        Tp = repeat([])
        phantom = False
    while h:
        try:
            g, gp = next(((g, gp) for g, gp in zip(T, Tp) if sdm_monomial_divides(sdm_LM(g), sdm_LM(h))))
        except StopIteration:
            break
        if phantom:
            h, hp = sdm_spoly(h, g, O, K, phantom=(hp, gp))
        else:
            h = sdm_spoly(h, g, O, K)
    if phantom:
        return (h, hp)
    return h

def sdm_nf_buchberger_reduced(f, G, O, K):
    h = sdm_zero()
    g = f
    while g:
        g = sdm_nf_buchberger(g, G, O, K)
        if g:
            h = sdm_add(h, [sdm_LT(g)], O, K)
            g = g[1:]
    return h

def sdm_groebner(G, NF, O, K, extended=False):
    P = []
    S = []
    Sugars = []

    def Ssugar(i, j):
        LMi = sdm_LM(S[i])
        LMj = sdm_LM(S[j])
        return max(Sugars[i] - sdm_monomial_deg(LMi), Sugars[j] - sdm_monomial_deg(LMj)) + sdm_monomial_deg(sdm_monomial_lcm(LMi, LMj))
    ourkey = lambda p: (p[2], O(p[3]), p[1])

    def update(f, sugar, P):
        if not f:
            return P
        k = len(S)
        S.append(f)
        Sugars.append(sugar)
        LMf = sdm_LM(f)

        def removethis(pair):
            i, j, s, t = pair
            if LMf[0] != t[0]:
                return False
            tik = sdm_monomial_lcm(LMf, sdm_LM(S[i]))
            tjk = sdm_monomial_lcm(LMf, sdm_LM(S[j]))
            return tik != t and tjk != t and sdm_monomial_divides(tik, t) and sdm_monomial_divides(tjk, t)
        P = [p for p in P if not removethis(p)]
        N = [(i, k, Ssugar(i, k), sdm_monomial_lcm(LMf, sdm_LM(S[i]))) for i in range(k) if LMf[0] == sdm_LM(S[i])[0]]
        N.sort(key=ourkey)
        remove = set()
        for i, p in enumerate(N):
            for j in range(i + 1, len(N)):
                if sdm_monomial_divides(p[3], N[j][3]):
                    remove.add(j)
        P.extend(reversed([p for i, p in enumerate(N) if i not in remove]))
        P.sort(key=ourkey, reverse=True)
        return P
    try:
        numgens = len(next((x[0] for x in G if x))[0]) - 1
    except StopIteration:
        if extended:
            return ([], [])
        return []
    coefficients = []
    for i, f in enumerate(G):
        if not f:
            continue
        P = update(f, sdm_deg(f), P)
        if extended:
            coefficients.append(sdm_from_dict({(i,) + (0,) * numgens: K(1)}, O))
    while P:
        i, j, s, t = P.pop()
        f, g = (S[i], S[j])
        if extended:
            sp, coeff = sdm_spoly(f, g, O, K, phantom=(coefficients[i], coefficients[j]))
            h, hcoeff = NF(sp, S, O, K, phantom=(coeff, coefficients))
            if h:
                coefficients.append(hcoeff)
        else:
            h = NF(sdm_spoly(f, g, O, K), S, O, K)
        P = update(h, Ssugar(i, j), P)
    S = {(tuple(f), i) for i, f in enumerate(S)}
    for (a, ai), (b, bi) in permutations(S, 2):
        A = sdm_LM(a)
        B = sdm_LM(b)
        if sdm_monomial_divides(A, B) and (b, bi) in S and ((a, ai) in S):
            S.remove((b, bi))
    L = sorted(((list(f), i) for f, i in S), key=lambda p: O(sdm_LM(p[0])), reverse=True)
    res = [x[0] for x in L]
    if extended:
        return (res, [coefficients[i] for _, i in L])
    return res