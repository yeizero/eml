from __future__ import annotations
from sympy.external.gmpy import MPQ
from sympy.polys.domains.groundtypes import SymPyRational, is_square, sqrtrem
from sympy.polys.domains.characteristiczero import CharacteristicZero
from sympy.polys.domains.field import Field
from sympy.polys.domains.simpledomain import SimpleDomain
from sympy.polys.polyerrors import CoercionFailed
from sympy.utilities import public

@public
class RationalField(Field[MPQ], CharacteristicZero, SimpleDomain):
    rep = 'QQ'
    alias = 'QQ'
    is_RationalField = is_QQ = True
    is_Numerical = True
    has_assoc_Ring = True
    has_assoc_Field = True
    dtype = MPQ
    zero = dtype(0)
    one = dtype(1)
    tp = type(one)

    def __init__(self):
        pass

    def __eq__(self, other):
        if isinstance(other, RationalField):
            return True
        else:
            return NotImplemented

    def __hash__(self):
        return hash('QQ')

    def get_ring(self):
        from sympy.polys.domains import ZZ
        return ZZ

    def to_sympy(self, a):
        return SymPyRational(int(a.numerator), int(a.denominator))

    def from_sympy(self, a):
        if a.is_Rational:
            return MPQ(a.p, a.q)
        elif a.is_Float:
            from sympy.polys.domains import RR
            return MPQ(*map(int, RR.to_rational(a)))
        else:
            raise CoercionFailed('expected `Rational` object, got %s' % a)

    def algebraic_field(self, *extension, alias=None):
        from sympy.polys.domains import AlgebraicField
        return AlgebraicField(self, *extension, alias=alias)

    def from_AlgebraicField(K1, a, K0):
        if a.is_ground:
            return K1.convert(a.LC(), K0.dom)

    def from_ZZ(K1, a, K0):
        return MPQ(a)

    def from_ZZ_python(K1, a, K0):
        return MPQ(a)

    def from_QQ(K1, a, K0):
        return MPQ(a.numerator, a.denominator)

    def from_QQ_python(K1, a, K0):
        return MPQ(a.numerator, a.denominator)

    def from_ZZ_gmpy(K1, a, K0):
        return MPQ(a)

    def from_QQ_gmpy(K1, a, K0):
        return a

    def from_GaussianRationalField(K1, a, K0):
        if a.y == 0:
            return MPQ(a.x)

    def from_RealField(K1, a, K0):
        return MPQ(*map(int, K0.to_rational(a)))

    def exquo(self, a, b):
        return MPQ(a) / MPQ(b)

    def quo(self, a, b):
        return MPQ(a) / MPQ(b)

    def rem(self, a, b):
        return self.zero

    def div(self, a, b):
        return (MPQ(a) / MPQ(b), self.zero)

    def numer(self, a):
        return a.numerator

    def denom(self, a):
        return a.denominator

    def is_square(self, a):
        return is_square(a.numerator) and is_square(a.denominator)

    def exsqrt(self, a):
        if a.numerator < 0:
            return None
        p_sqrt, p_rem = sqrtrem(a.numerator)
        if p_rem != 0:
            return None
        q_sqrt, q_rem = sqrtrem(a.denominator)
        if q_rem != 0:
            return None
        return MPQ(p_sqrt, q_sqrt)
QQ = RationalField()