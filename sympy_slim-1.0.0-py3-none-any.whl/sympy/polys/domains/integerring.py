from __future__ import annotations
from sympy.external.gmpy import MPZ, GROUND_TYPES
from sympy.core.numbers import int_valued
from sympy.polys.domains.groundtypes import SymPyInteger, factorial, gcdex, gcd, lcm, sqrt, is_square, sqrtrem
from sympy.polys.domains.characteristiczero import CharacteristicZero
from sympy.polys.domains.ring import Ring
from sympy.polys.domains.simpledomain import SimpleDomain
from sympy.polys.polyerrors import CoercionFailed
from sympy.utilities import public
import math

@public
class IntegerRing(Ring[MPZ], CharacteristicZero, SimpleDomain):
    rep = 'ZZ'
    alias = 'ZZ'
    dtype = MPZ
    zero = dtype(0)
    one = dtype(1)
    tp = type(one)
    is_IntegerRing = is_ZZ = True
    is_Numerical = True
    is_PID = True
    has_assoc_Ring = True
    has_assoc_Field = True

    def __init__(self):
        pass

    def __eq__(self, other):
        if isinstance(other, IntegerRing):
            return True
        else:
            return NotImplemented

    def __hash__(self):
        return hash('ZZ')

    def to_sympy(self, a):
        return SymPyInteger(int(a))

    def from_sympy(self, a):
        if a.is_Integer:
            return MPZ(a.p)
        elif int_valued(a):
            return MPZ(int(a))
        else:
            raise CoercionFailed('expected an integer, got %s' % a)

    def get_field(self):
        from sympy.polys.domains import QQ
        return QQ

    def algebraic_field(self, *extension, alias=None):
        return self.get_field().algebraic_field(*extension, alias=alias)

    def from_AlgebraicField(K1, a, K0):
        if a.is_ground:
            return K1.convert(a.LC(), K0.dom)

    def log(self, a, b):
        return self.dtype(int(math.log(int(a), b)))

    def from_FF(K1, a, K0):
        return MPZ(K0.to_int(a))

    def from_FF_python(K1, a, K0):
        return MPZ(K0.to_int(a))

    def from_ZZ(K1, a, K0):
        return MPZ(a)

    def from_ZZ_python(K1, a, K0):
        return MPZ(a)

    def from_QQ(K1, a, K0):
        if a.denominator == 1:
            return MPZ(a.numerator)

    def from_QQ_python(K1, a, K0):
        if a.denominator == 1:
            return MPZ(a.numerator)

    def from_FF_gmpy(K1, a, K0):
        return MPZ(K0.to_int(a))

    def from_ZZ_gmpy(K1, a, K0):
        return a

    def from_QQ_gmpy(K1, a, K0):
        if a.denominator == 1:
            return a.numerator

    def from_RealField(K1, a, K0):
        p, q = K0.to_rational(a)
        if q == 1:
            return MPZ(int(p))

    def from_GaussianIntegerRing(K1, a, K0):
        if a.y == 0:
            return a.x

    def from_EX(K1, a, K0):
        if a.is_Integer:
            return K1.from_sympy(a)

    def gcdex(self, a: MPZ, b: MPZ) -> tuple[MPZ, MPZ, MPZ]:
        h, s, t = gcdex(a, b)
        if GROUND_TYPES == 'gmpy':
            return (s, t, h)
        else:
            return (h, s, t)

    def gcd(self, a, b):
        return gcd(a, b)

    def lcm(self, a, b):
        return lcm(a, b)

    def sqrt(self, a):
        return sqrt(a)

    def is_square(self, a):
        return is_square(a)

    def exsqrt(self, a):
        if a < 0:
            return None
        root, rem = sqrtrem(a)
        if rem != 0:
            return None
        return root

    def factorial(self, a):
        return factorial(a)
ZZ = IntegerRing()