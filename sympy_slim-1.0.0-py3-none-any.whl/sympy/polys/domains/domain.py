from __future__ import annotations
from typing import Any, Generic, TypeVar, Protocol, Callable, Iterable, TYPE_CHECKING
from sympy.core.numbers import AlgebraicNumber
from sympy.core import Basic, Expr, sympify
from sympy.core.sorting import ordered
from sympy.external.gmpy import GROUND_TYPES, MPZ
from sympy.polys.domains.domainelement import DomainElement
from sympy.polys.orderings import lex, MonomialOrder
from sympy.polys.polyerrors import UnificationFailed, CoercionFailed, DomainError
from sympy.polys.polyutils import _unify_gens, _not_a_coeff
from sympy.utilities import public
from sympy.utilities.iterables import is_sequence
if TYPE_CHECKING:
    import sys
    if sys.version_info >= (3, 13):
        from typing import TypeIs
    else:
        from typing_extensions import TypeIs
    from sympy.polys.polytools import Poly
    from sympy.polys.domains.ring import Ring
    from sympy.polys.domains.field import Field
    from sympy.polys.domains.finitefield import FiniteField
    from sympy.polys.domains.integerring import IntegerRing
    from sympy.polys.domains.rationalfield import RationalField
    from sympy.polys.domains.algebraicfield import AlgebraicField
    from sympy.polys.domains.realfield import RealField
    from sympy.polys.domains.complexfield import ComplexField
    from sympy.polys.domains.polynomialring import PolynomialRing
    from sympy.polys.domains.powerseriesring import PowerSeriesRing
    from sympy.polys.domains.fractionfield import FractionField
    from sympy.polys.rings import PolyElement
    from sympy.polys.fields import FracElement
T = TypeVar('T')
if TYPE_CHECKING:
    from typing import Self

class RingElement(Protocol):

    def __pos__(self, /) -> Self:
        pass

    def __neg__(self, /) -> Self:
        pass

    def __add__(self, other: Self | int, /) -> Self:
        pass

    def __radd__(self, other: int, /) -> Self:
        pass

    def __sub__(self, other: Self | int, /) -> Self:
        pass

    def __rsub__(self, other: int, /) -> Self:
        pass

    def __mul__(self, other: Self | int, /) -> Self:
        pass

    def __rmul__(self, other: int, /) -> Self:
        pass

    def __pow__(self, other: int, /) -> Self:
        pass

class FieldElement(RingElement, Protocol):

    def __truediv__(self, other: Self | int, /) -> Self:
        pass

    def __rtruediv__(self, other: int, /) -> Self:
        pass

class EuclidElement(RingElement, Protocol):

    def __floordiv__(self, other: Self | int, /) -> Self:
        pass

    def __rfloordiv__(self, other: int, /) -> Self:
        pass

    def __mod__(self, other: Self | int, /) -> Self:
        pass

    def __rmod__(self, other: int, /) -> Self:
        pass

    def __divmod__(self, other: Self | int, /) -> tuple[Self, Self]:
        pass

    def __rdivmod__(self, other: int, /) -> tuple[Self, Self]:
        pass

class AbsElement(RingElement, Protocol):

    def __abs__(self, /) -> Self:
        pass

class OrderedElement(AbsElement, Protocol):

    def __lt__(self, other: Self, /) -> bool:
        pass

    def __le__(self, other: Self, /) -> bool:
        pass

    def __gt__(self, other: Self, /) -> bool:
        pass

    def __ge__(self, other: Self, /) -> bool:
        pass
Er = TypeVar('Er', bound=RingElement)
Es = TypeVar('Es', bound=RingElement)
Et = TypeVar('Et', bound=RingElement)
Eg = TypeVar('Eg', bound=RingElement)
Ef = TypeVar('Ef', bound=FieldElement)
Eeuclid = TypeVar('Eeuclid', bound=EuclidElement)
Eabs = TypeVar('Eabs', bound=AbsElement)
Eordered = TypeVar('Eordered', bound=OrderedElement)

@public
class Domain(Generic[Er]):
    dtype: type[Er] | Callable[..., Er]
    'The type (class) of the elements of this :py:class:`~.Domain`:\n\n    >>> from sympy import ZZ, QQ, Symbol\n    >>> ZZ.dtype\n    <class \'int\'>\n    >>> z = ZZ(2)\n    >>> z\n    2\n    >>> type(z)\n    <class \'int\'>\n    >>> type(z) == ZZ.dtype\n    True\n\n    Every domain has an associated **dtype** ("datatype") which is the\n    class of the associated domain elements.\n\n    See also\n    ========\n\n    of_type\n    '
    zero: Er
    'The zero element of the :py:class:`~.Domain`:\n\n    >>> from sympy import QQ\n    >>> QQ.zero\n    0\n    >>> QQ.of_type(QQ.zero)\n    True\n\n    See also\n    ========\n\n    of_type\n    one\n    '
    one: Er
    'The one element of the :py:class:`~.Domain`:\n\n    >>> from sympy import QQ\n    >>> QQ.one\n    1\n    >>> QQ.of_type(QQ.one)\n    True\n\n    See also\n    ========\n\n    of_type\n    zero\n    '
    is_Ring: bool = False
    'Boolean flag indicating if the domain is a :py:class:`~.Ring`.\n\n    >>> from sympy import ZZ\n    >>> ZZ.is_Ring\n    True\n\n    Basically every :py:class:`~.Domain` represents a ring so this flag is\n    not that useful.\n\n    See also\n    ========\n\n    is_PID\n    is_Field\n    get_ring\n    has_assoc_Ring\n    '
    is_Field: bool = False
    'Boolean flag indicating if the domain is a :py:class:`~.Field`.\n\n    >>> from sympy import ZZ, QQ\n    >>> ZZ.is_Field\n    False\n    >>> QQ.is_Field\n    True\n\n    See also\n    ========\n\n    is_PID\n    is_Ring\n    get_field\n    has_assoc_Field\n    '
    has_assoc_Ring: bool = False
    'Boolean flag indicating if the domain has an associated\n    :py:class:`~.Ring`.\n\n    >>> from sympy import QQ\n    >>> QQ.has_assoc_Ring\n    True\n    >>> QQ.get_ring()\n    ZZ\n\n    See also\n    ========\n\n    is_Field\n    get_ring\n    '
    has_assoc_Field: bool = False
    'Boolean flag indicating if the domain has an associated\n    :py:class:`~.Field`.\n\n    >>> from sympy import ZZ\n    >>> ZZ.has_assoc_Field\n    True\n    >>> ZZ.get_field()\n    QQ\n\n    See also\n    ========\n\n    is_Field\n    get_field\n    '
    is_FiniteField: bool = False
    'Boolean flag indicating if the domain is a :py:class:`~.FiniteField`.'
    is_FF: bool = False
    'Alias for :py:attr:`~.Domain.is_FiniteField`.'
    is_IntegerRing: bool = False
    'Boolean flag indicating if the domain is an :py:class:`~.IntegerRing`.'
    is_ZZ: bool = False
    'Alias for :py:attr:`~.Domain.is_IntegerRing`.'
    is_RationalField: bool = False
    'Boolean flag indicating if the domain is a :py:class:`~.RationalField`.'
    is_QQ: bool = False
    'Alias for :py:attr:`~.Domain.is_RationalField`.'
    is_GaussianRing: bool = False
    'Boolean flag indicating if the domain is a :py:class:`~.GaussianIntegerRing`.'
    is_ZZ_I: bool = False
    'Alias for :py:attr:`~.Domain.is_GaussianRing`.'
    is_GaussianField: bool = False
    'Boolean flag indicating if the domain is a :py:class:`~.GaussianRationalField`.'
    is_QQ_I: bool = False
    'Alias for :py:attr:`~.Domain.is_GaussianField`.'
    is_RealField: bool = False
    'Boolean flag indicating if the domain is a :py:class:`~.RealField`.'
    is_RR: bool = False
    'Alias for :py:attr:`~.Domain.is_RealField`.'
    is_ComplexField: bool = False
    'Boolean flag indicating if the domain is a :py:class:`~.ComplexField`.'
    is_CC: bool = False
    'Alias for :py:attr:`~.Domain.is_ComplexField`.'
    is_AlgebraicField: bool = False
    'Boolean flag indicating if the domain is an :py:class:`~.AlgebraicField`.'
    is_Algebraic: bool = False
    'Alias for :py:attr:`~.Domain.is_AlgebraicField`.'
    is_PolynomialRing: bool = False
    'Boolean flag indicating if the domain is a :py:class:`~.PolynomialRing`.'
    is_Poly: bool = False
    'Alias for :py:attr:`~.Domain.is_PolynomialRing`.'
    is_FractionField: bool = False
    'Boolean flag indicating if the domain is a :py:class:`~.FractionField`.'
    is_Frac: bool = False
    'Alias for :py:attr:`~.Domain.is_FractionField`.'
    is_SymbolicDomain: bool = False
    'Boolean flag indicating if the domain is a :py:class:`~.ExpressionDomain`.'
    is_EX: bool = False
    'Alias for :py:attr:`~.Domain.is_SymbolicDomain`.'
    is_SymbolicRawDomain: bool = False
    'Boolean flag indicating if the domain is a :py:class:`~.ExpressionRawDomain`.'
    is_EXRAW: bool = False
    'Alias for :py:attr:`~.Domain.is_SymbolicRawDomain`.'
    is_FiniteExtension: bool = False
    'Boolean flag indicating if the domain is a :py:class:`~.MonogenicFiniteExtension`. '
    is_Exact: bool = True
    'Boolean flag indicating if the domain is an exact domain.'
    is_Numerical: bool = False
    'Boolean flag indicating if the domain is a numerical domain.'
    is_Simple: bool = False
    'Boolean flag indicating if the domain is a simple domain.'
    is_Composite: bool = False
    'Boolean flag indicating if the domain is a composite domain.'
    is_RingExtension: bool = False
    'Boolean flag indicating if the domain is a ring extension domain.'
    is_PID: bool = False
    'Boolean flag indicating if the domain is a `principal ideal domain`_.\n\n    >>> from sympy import ZZ\n    >>> ZZ.is_PID\n    True\n\n    .. _principal ideal domain: https://en.wikipedia.org/wiki/Principal_ideal_domain\n\n    See also\n    ========\n\n    is_Field\n    get_field\n    '
    has_CharacteristicZero: bool = False
    'Boolean flag indicating if the domain has characteristic zero.'
    rep: str
    alias: str | None = None

    def __init__(self):
        raise NotImplementedError

    def __str__(self) -> str:
        return self.rep

    def __repr__(self) -> str:
        return str(self)

    def __hash__(self) -> int:
        return hash((self.__class__.__name__, self.dtype))

    def new(self, *args) -> Er:
        return self.dtype(*args)

    @property
    def tp(self) -> type[Er]:
        return self.dtype

    def __call__(self, *args) -> Er:
        return self.new(*args)

    def normal(self, *args: int | MPZ) -> Er:
        return self.dtype(*args)

    def convert_from(self, element: Es, base: Domain[Es]) -> Er:
        if base.alias is not None:
            method = 'from_' + base.alias
        else:
            method = 'from_' + base.__class__.__name__
        _convert = getattr(self, method)
        if _convert is not None:
            result = _convert(element, base)
            if result is not None:
                return result
        raise CoercionFailed('Cannot convert %s of type %s from %s to %s' % (element, type(element), base, self))

    def convert(self, element: Es | Expr | complex, base: Domain[Es] | None=None) -> Er:
        if base is not None:
            if _not_a_coeff(element):
                raise CoercionFailed('%s is not in any domain' % element)
            return self.convert_from(element, base)
        if self.of_type(element):
            return element
        if _not_a_coeff(element):
            raise CoercionFailed('%s is not in any domain' % element)
        from sympy.polys.domains import ZZ, QQ, RealField, ComplexField
        if ZZ.of_type(element):
            return self.convert_from(element, ZZ)
        if isinstance(element, int):
            return self.convert_from(ZZ(element), ZZ)
        if GROUND_TYPES != 'python':
            if isinstance(element, ZZ.tp):
                return self.convert_from(element, ZZ)
            if isinstance(element, QQ.tp):
                return self.convert_from(element, QQ)
        if isinstance(element, float):
            RR = RealField()
            return self.convert_from(RR(element), RR)
        if isinstance(element, complex):
            CC = ComplexField()
            return self.convert_from(CC(element), CC)
        if type(element).__name__ == 'mpf':
            RR = RealField()
            return self.convert_from(RR(element), RR)
        if type(element).__name__ == 'mpc':
            CC = ComplexField()
            return self.convert_from(CC(element), CC)
        if isinstance(element, DomainElement):
            return self.convert_from(element, element.parent())
        if self.is_Numerical and getattr(element, 'is_ground', False):
            return self.convert(element.LC())
        if isinstance(element, Basic):
            try:
                return self.from_sympy(element)
            except (TypeError, ValueError):
                pass
        elif not is_sequence(element):
            try:
                element = sympify(element, strict=True)
                if isinstance(element, Basic):
                    return self.from_sympy(element)
            except (TypeError, ValueError):
                pass
        raise CoercionFailed('Cannot convert %s of type %s to %s' % (element, type(element), self))

    def of_type(self, element: Any) -> TypeIs[Er]:
        return isinstance(element, self.tp)

    def __contains__(self, a: Any) -> bool:
        try:
            if _not_a_coeff(a):
                raise CoercionFailed
            self.convert(a)
        except CoercionFailed:
            return False
        return True

    def to_sympy(self, a: Er) -> Expr:
        raise NotImplementedError

    def from_sympy(self, a: Expr) -> Er:
        raise NotImplementedError

    def sum(self, args: Iterable[Er]) -> Er:
        return sum(args, start=self.zero)

    def from_FF(K1, a, K0: FiniteField) -> Er | None:
        return None

    def from_FF_python(K1, a, K0: FiniteField) -> Er | None:
        return None

    def from_ZZ_python(K1, a, K0: IntegerRing) -> Er | None:
        return None

    def from_QQ_python(K1, a, K0: RationalField) -> Er | None:
        return None

    def from_FF_gmpy(K1, a, K0: FiniteField) -> Er | None:
        return None

    def from_ZZ_gmpy(K1, a, K0: IntegerRing) -> Er | None:
        return None

    def from_QQ_gmpy(K1, a, K0: RationalField) -> Er | None:
        return None

    def from_RealField(K1, a, K0: RealField) -> Er | None:
        return None

    def from_ComplexField(K1, a, K0: ComplexField) -> Er | None:
        return None

    def from_AlgebraicField(K1, a, K0: AlgebraicField) -> Er | None:
        return None

    def from_PolynomialRing(K1, a: PolyElement[Es], K0: PolynomialRing[Es]) -> Er | None:
        if a.is_ground:
            return K1.convert(a.LC, K0.dom)
        return None

    def from_FractionField(K1, a: FracElement[Es], K0: FractionField[Es]) -> Er | None:
        return None

    def from_MonogenicFiniteExtension(K1, a, K0) -> Er | None:
        return K1.convert_from(a.rep, K0.ring)

    def from_ExpressionDomain(K1, a, K0) -> Er | None:
        return K1.from_sympy(a.ex)

    def from_ExpressionRawDomain(K1, a: Expr, K0) -> Er | None:
        return K1.from_sympy(a)

    def from_GlobalPolynomialRing(K1, a, K0) -> Er | None:
        if a.degree() <= 0:
            return K1.convert(a.LC(), K0.dom)
        return None

    def from_GeneralizedPolynomialRing(K1, a, K0) -> Er | None:
        return K1.from_FractionField(a, K0)

    def unify_with_symbols(K0, K1, symbols):
        if K0.is_Composite and set(K0.symbols) & set(symbols) or (K1.is_Composite and set(K1.symbols) & set(symbols)):
            raise UnificationFailed('Cannot unify %s with %s, given %s generators' % (K0, K1, tuple(symbols)))
        return K0.unify(K1)

    def unify_composite(K0, K1):
        K0_ground = K0.dom if K0.is_Composite else K0
        K1_ground = K1.dom if K1.is_Composite else K1
        K0_symbols = K0.symbols if K0.is_Composite else ()
        K1_symbols = K1.symbols if K1.is_Composite else ()
        domain = K0_ground.unify(K1_ground)
        symbols = _unify_gens(K0_symbols, K1_symbols)
        order = K0.order if K0.is_Composite else K1.order
        if (K0.is_FractionField and K1.is_PolynomialRing or (K1.is_FractionField and K0.is_PolynomialRing)) and (not K0_ground.is_Field or not K1_ground.is_Field) and domain.is_Field and domain.has_assoc_Ring:
            domain = domain.get_ring()
        if K0.is_Composite and (not K1.is_Composite or K0.is_FractionField or K1.is_PolynomialRing):
            cls = K0.__class__
        else:
            cls = K1.__class__
        from sympy.polys.domains.old_polynomialring import GlobalPolynomialRing
        if cls == GlobalPolynomialRing:
            return cls(domain, symbols)
        return cls(domain, symbols, order)

    def unify(K0, K1, symbols=None):
        if symbols is not None:
            return K0.unify_with_symbols(K1, symbols)
        if K0 == K1:
            return K0
        if not (K0.has_CharacteristicZero and K1.has_CharacteristicZero):
            if K0.characteristic() != K1.characteristic():
                raise UnificationFailed('Cannot unify %s with %s' % (K0, K1))
            return K0.unify_composite(K1)
        if K0.is_EXRAW:
            return K0
        if K1.is_EXRAW:
            return K1
        if K0.is_EX:
            return K0
        if K1.is_EX:
            return K1
        if K0.is_FiniteExtension or K1.is_FiniteExtension:
            if K1.is_FiniteExtension:
                K0, K1 = (K1, K0)
            if K1.is_FiniteExtension:
                if list(ordered([K0.modulus, K1.modulus]))[1] == K0.modulus:
                    K0, K1 = (K1, K0)
                return K1.set_domain(K0)
            else:
                K1 = K1.drop(K0.symbol)
                K1 = K0.domain.unify(K1)
                return K0.set_domain(K1)
        if K0.is_Composite or K1.is_Composite:
            return K0.unify_composite(K1)
        if K1.is_ComplexField:
            K0, K1 = (K1, K0)
        if K0.is_ComplexField:
            if K1.is_ComplexField or K1.is_RealField:
                if K0.precision >= K1.precision:
                    return K0
                else:
                    from sympy.polys.domains.complexfield import ComplexField
                    return ComplexField(prec=K1.precision)
            else:
                return K0
        if K1.is_RealField:
            K0, K1 = (K1, K0)
        if K0.is_RealField:
            if K1.is_RealField:
                if K0.precision >= K1.precision:
                    return K0
                else:
                    return K1
            elif K1.is_GaussianRing or K1.is_GaussianField:
                from sympy.polys.domains.complexfield import ComplexField
                return ComplexField(prec=K0.precision)
            else:
                return K0
        if K1.is_AlgebraicField:
            K0, K1 = (K1, K0)
        if K0.is_AlgebraicField:
            if K1.is_GaussianRing:
                K1 = K1.get_field()
            if K1.is_GaussianField:
                K1 = K1.as_AlgebraicField()
            if K1.is_AlgebraicField:
                return K0.__class__(K0.dom.unify(K1.dom), *_unify_gens(K0.orig_ext, K1.orig_ext))
            else:
                return K0
        if K0.is_GaussianField:
            return K0
        if K1.is_GaussianField:
            return K1
        if K0.is_GaussianRing:
            if K1.is_RationalField:
                K0 = K0.get_field()
            return K0
        if K1.is_GaussianRing:
            if K0.is_RationalField:
                K1 = K1.get_field()
            return K1
        if K0.is_RationalField:
            return K0
        if K1.is_RationalField:
            return K1
        if K0.is_IntegerRing:
            return K0
        if K1.is_IntegerRing:
            return K1
        from sympy.polys.domains import EX
        return EX

    def __eq__(self, other):
        return isinstance(other, Domain) and self.dtype == other.dtype

    def __ne__(self, other):
        return not self == other

    def map(self, seq: Iterable[int | Er]) -> list[Er]:
        result = []
        for elt in seq:
            if isinstance(elt, list):
                result.append(self.map(elt))
            else:
                result.append(self(elt))
        return result

    def get_ring(self) -> Ring:
        raise DomainError('there is no ring associated with %s' % self)

    def get_field(self) -> Field:
        raise DomainError('there is no field associated with %s' % self)

    def get_exact(self) -> Domain:
        return self

    def __getitem__(self, symbols: Expr | Iterable[Expr] | str | Iterable[str]) -> PolynomialRing[Er]:
        if isinstance(symbols, (str, Expr)):
            return self.poly_ring(symbols)
        else:
            return self.poly_ring(*symbols)

    def poly_ring(self, *symbols: str | Expr, order: str | MonomialOrder=lex) -> PolynomialRing:
        from sympy.polys.domains.polynomialring import PolynomialRing
        return PolynomialRing(self, symbols, order)

    def _power_series_ring(self, *symbols: str | Expr, prec: int=6) -> PowerSeriesRing:
        if len(symbols) != 1:
            raise ValueError('Power series ring supports only univariate series.')
        from sympy.polys.domains.powerseriesring import PowerSeriesRing
        return PowerSeriesRing(self, symbols[0], prec)

    def frac_field(self, *symbols: str | Expr, order: str | MonomialOrder=lex) -> FractionField:
        from sympy.polys.domains.fractionfield import FractionField
        return FractionField(self, symbols, order)

    def old_poly_ring(self, *symbols: str | Expr, **kwargs: Any):
        from sympy.polys.domains.old_polynomialring import PolynomialRing
        return PolynomialRing(self, *symbols, **kwargs)

    def old_frac_field(self, *symbols: str | Expr, **kwargs: Any):
        from sympy.polys.domains.old_fractionfield import FractionField
        return FractionField(self, *symbols, **kwargs)

    def algebraic_field(self, *extension: Expr, alias: str | None=None) -> AlgebraicField:
        raise DomainError('Cannot create algebraic field over %s' % self)

    def alg_field_from_poly(self, poly: Poly, alias: str | None=None, root_index: int=-1) -> AlgebraicField:
        from sympy.polys.rootoftools import CRootOf
        root = CRootOf(poly, root_index)
        alpha = AlgebraicNumber(root, alias=alias)
        return self.algebraic_field(alpha, alias=alias)

    def cyclotomic_field(self, n: int, ss: bool=False, alias: str='zeta', gen: Expr | None=None, root_index: int=-1) -> AlgebraicField:
        from sympy.polys.specialpolys import cyclotomic_poly
        if ss:
            alias += str(n)
        return self.alg_field_from_poly(cyclotomic_poly(n, gen), alias=alias, root_index=root_index)

    def inject(self, *symbols) -> PolynomialRing:
        raise NotImplementedError

    def drop(self, *symbols: Expr | str) -> Domain:
        if self.is_Simple:
            return self
        raise NotImplementedError

    def is_zero(self, a: Er) -> bool:
        return not a

    def is_one(self, a: Er) -> bool:
        return a == self.one

    def is_positive(self, a: Er) -> bool:
        return a > 0

    def is_negative(self, a: Er) -> bool:
        return a < 0

    def is_nonpositive(self, a: Er) -> bool:
        return a <= 0

    def is_nonnegative(self, a: Er) -> bool:
        return a >= 0

    def is_unit(self, a: Er) -> bool:
        raise NotImplementedError

    def canonical_unit(self, a: Er) -> Er:
        if self.is_negative(a):
            return -self.one
        else:
            return self.one

    def abs(self, a: Er) -> Er:
        return abs(a)

    def neg(self, a: Er) -> Er:
        return -a

    def pos(self, a: Er) -> Er:
        return +a

    def add(self, a: Er, b: Er) -> Er:
        return a + b

    def sub(self, a: Er, b: Er) -> Er:
        return a - b

    def mul(self, a: Er, b: Er) -> Er:
        return a * b

    def pow(self, a: Er, b: int) -> Er:
        return a ** b

    def exquo(self, a: Er, b: Er) -> Er:
        raise NotImplementedError

    def quo(self, a: Er, b: Er) -> Er:
        raise NotImplementedError

    def rem(self, a: Er, b: Er) -> Er:
        raise NotImplementedError

    def div(self, a: Er, b: Er) -> tuple[Er, Er]:
        raise NotImplementedError

    def invert(self, a: Er, b: Er) -> Er:
        raise NotImplementedError

    def revert(self, a: Er) -> Er:
        raise NotImplementedError

    def numer(self, a: Er) -> Any:
        raise NotImplementedError

    def denom(self, a: Er) -> Any:
        raise NotImplementedError

    def half_gcdex(self, a: Er, b: Er) -> tuple[Er, Er]:
        s, t, h = self.gcdex(a, b)
        return (s, h)

    def gcdex(self, a: Er, b: Er) -> tuple[Er, Er, Er]:
        raise NotImplementedError

    def cofactors(self, a: Er, b: Er) -> tuple[Er, Er, Er]:
        gcd = self.gcd(a, b)
        cfa = self.quo(a, gcd)
        cfb = self.quo(b, gcd)
        return (gcd, cfa, cfb)

    def gcd(self, a: Er, b: Er) -> Er:
        raise NotImplementedError

    def lcm(self, a: Er, b: Er) -> Er:
        raise NotImplementedError

    def log(self, a: Er, b: Er) -> Er:
        raise NotImplementedError

    def sqrt(self, a: Er) -> Er:
        raise NotImplementedError

    def is_square(self, a: Er) -> bool:
        raise NotImplementedError

    def exsqrt(self, a: Er) -> Er | None:
        raise NotImplementedError

    def evalf(self, a: Er, prec: int | None=None, **options: Any):
        return self.to_sympy(a).evalf(prec, **options)
    n = evalf

    def real(self, a) -> Er:
        return a

    def imag(self, a) -> Er:
        return self.zero

    def almosteq(self, a: Er, b: Er, tolerance: float | None=None):
        return a == b

    def characteristic(self) -> int:
        raise NotImplementedError('characteristic()')
__all__ = ['Domain']