from __future__ import annotations
from typing import TYPE_CHECKING
from sympy.polys.domains.domain import Domain, Er
from sympy.polys.polyerrors import GeneratorsError
from sympy.utilities import public
if TYPE_CHECKING:
    from sympy.core.expr import Expr

@public
class CompositeDomain(Domain[Er]):
    is_Composite = True
    gens: Er
    ngens: int
    symbols: tuple[Expr, ...]
    domain: Domain[Er]

    def inject(self, *symbols):
        if not set(self.symbols) & set(symbols):
            return self.__class__(self.domain, self.symbols + symbols, self.order)
        else:
            raise GeneratorsError('common generators in %s and %s' % (self.symbols, symbols))

    def drop(self, *symbols):
        symset = set(symbols)
        newsyms = tuple((s for s in self.symbols if s not in symset))
        domain = self.domain.drop(*symbols)
        if not newsyms:
            return domain
        else:
            return self.__class__(domain, newsyms, self.order)

    def set_domain(self, domain, /):
        return self.__class__(domain, self.symbols, self.order)

    @property
    def is_Exact(self):
        return self.domain.is_Exact

    def get_exact(self):
        return self.set_domain(self.domain.get_exact())

    @property
    def has_CharacteristicZero(self):
        return self.domain.has_CharacteristicZero

    def characteristic(self):
        return self.domain.characteristic()