from __future__ import annotations
from typing import TYPE_CHECKING
from sympy.polys.domains.domain import Er, Domain
from sympy.polys.domains.ring import Ring
from sympy.polys.domains.ringextension import RingExtension
from sympy.polys.domains.compositedomain import CompositeDomain
from sympy.polys.polyerrors import CoercionFailed, GeneratorsError
from sympy.utilities import public
if TYPE_CHECKING:
    from sympy.polys.orderings import MonomialOrder
    from sympy.core.expr import Expr
    import sys
    if sys.version_info >= (3, 13):
        from typing import TypeIs
    else:
        from typing_extensions import TypeIs
    from sympy.polys.rings import PolyRing, PolyElement

@public
class PolynomialRing(Ring['PolyElement[Er]'], RingExtension['PolyElement[Er]', Er], CompositeDomain):
    is_PolynomialRing = is_Poly = True
    has_assoc_Ring = True
    has_assoc_Field = True

    def __init__(self, domain_or_ring: Domain[Er] | PolyRing[Er], symbols=None, order=None):
        from sympy.polys.rings import PolyRing
        if isinstance(domain_or_ring, PolyRing) and symbols is None and (order is None):
            ring = domain_or_ring
        else:
            ring = PolyRing(symbols, domain_or_ring, order)
        self.ring = ring
        self.dtype = ring.dtype
        self.gens: tuple[PolyElement[Er], ...] = ring.gens
        self.ngens: int = ring.ngens
        self.symbols: tuple[Expr, ...] = ring.symbols
        self.domain: Domain[Er] = ring.domain
        if symbols:
            if ring.domain.is_Field and ring.domain.is_Exact and (len(symbols) == 1):
                self.is_PID = True
        self.dom = self.domain

    def to_dict(self, element: PolyElement[Er]) -> dict[tuple[int, ...], Er]:
        return element.to_dict()

    def new(self, element) -> PolyElement[Er]:
        return self.ring.ring_new(element)

    def of_type(self, element) -> TypeIs[PolyElement[Er]]:
        return self.ring.is_element(element)

    @property
    def zero(self) -> PolyElement[Er]:
        return self.ring.zero

    @property
    def one(self) -> PolyElement[Er]:
        return self.ring.one

    @property
    def order(self) -> MonomialOrder:
        return self.ring.order

    def __str__(self):
        return str(self.domain) + '[' + ','.join(map(str, self.symbols)) + ']'

    def __hash__(self):
        return hash((self.__class__.__name__, self.ring, self.domain, self.symbols))

    def __eq__(self, other):
        if not isinstance(other, PolynomialRing):
            return NotImplemented
        return self.ring == other.ring

    def is_unit(self, a) -> bool:
        if not a.is_ground:
            return False
        K = self.domain
        return K.is_unit(K.convert_from(a, self))

    def canonical_unit(self, a) -> PolyElement[Er]:
        u = self.domain.canonical_unit(a.LC)
        return self.ring.ground_new(u)

    def to_sympy(self, a: PolyElement[Er]) -> Expr:
        return a.as_expr()

    def from_sympy(self, a: Expr) -> PolyElement[Er]:
        return self.ring.from_expr(a)

    def from_ZZ(K1, a, K0):
        return K1(K1.domain.convert(a, K0))

    def from_ZZ_python(K1, a, K0):
        return K1(K1.domain.convert(a, K0))

    def from_QQ(K1, a, K0):
        return K1(K1.domain.convert(a, K0))

    def from_QQ_python(K1, a, K0):
        return K1(K1.domain.convert(a, K0))

    def from_ZZ_gmpy(K1, a, K0):
        return K1(K1.domain.convert(a, K0))

    def from_QQ_gmpy(K1, a, K0):
        return K1(K1.domain.convert(a, K0))

    def from_GaussianIntegerRing(K1, a, K0):
        return K1(K1.domain.convert(a, K0))

    def from_GaussianRationalField(K1, a, K0):
        return K1(K1.domain.convert(a, K0))

    def from_RealField(K1, a, K0):
        return K1(K1.domain.convert(a, K0))

    def from_ComplexField(K1, a, K0):
        return K1(K1.domain.convert(a, K0))

    def from_AlgebraicField(K1, a, K0):
        if K1.domain != K0:
            a = K1.domain.convert_from(a, K0)
        if a is not None:
            return K1.new(a)

    def from_PolynomialRing(K1, a, K0):
        try:
            return a.set_ring(K1.ring)
        except (CoercionFailed, GeneratorsError):
            return None

    def from_FractionField(K1, a, K0):
        if K1.domain == K0:
            return K1.ring.from_list([a])
        q, r = K0.numer(a).div(K0.denom(a))
        if r.is_zero:
            return K1.from_PolynomialRing(q, K0.field.ring.to_domain())
        else:
            return None

    def from_GlobalPolynomialRing(K1, a, K0):
        if K1.symbols == K0.gens:
            ad = a.to_dict()
            if K1.domain != K0.domain:
                ad = {m: K1.domain.convert(c) for m, c in ad.items()}
            return K1(ad)
        elif a.is_ground and K0.domain == K1:
            return K1.convert_from(a.to_list()[0], K0.domain)

    def get_field(self):
        return self.ring.to_field().to_domain()

    def is_positive(self, a):
        return self.domain.is_positive(a.LC)

    def is_negative(self, a):
        return self.domain.is_negative(a.LC)

    def is_nonpositive(self, a):
        return self.domain.is_nonpositive(a.LC)

    def is_nonnegative(self, a):
        return self.domain.is_nonnegative(a.LC)

    def gcdex(self, a, b):
        return a.gcdex(b)

    def gcd(self, a, b):
        return a.gcd(b)

    def lcm(self, a, b):
        return a.lcm(b)

    def factorial(self, a):
        return self.dtype(self.domain.factorial(a))