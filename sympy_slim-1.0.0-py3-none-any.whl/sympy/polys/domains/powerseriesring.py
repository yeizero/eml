from __future__ import annotations
from functools import cached_property
from sympy.polys.domains.ring import Ring
from sympy.polys.domains.compositedomain import CompositeDomain
from sympy.polys.domains.domain import Er, Domain
from sympy.polys.series.ring import power_series_ring, PowerSeriesElement
from typing import TYPE_CHECKING, Protocol
if TYPE_CHECKING:
    from sympy.core.expr import Expr
    import sys
    if sys.version_info >= (3, 13):
        from typing import TypeIs
    else:
        from typing_extensions import TypeIs
    from sympy.polys.densebasic import dup
    from sympy.polys.series.tring import TSeriesElement
    from sympy.polys.series.base import PowerSeriesRingProto

class SeriesRingProto(Protocol[Er]):
    ring: PowerSeriesRingProto[TSeriesElement[Er], Er]
    dtype: type[PowerSeriesElement[Er]]
    domain: Domain[Er]
    symbol: Expr
    prec: int
    one: PowerSeriesElement[Er]
    zero: PowerSeriesElement[Er]
    gen: PowerSeriesElement[Er]

    def __init__(self, domain: Domain[Er], symbol: str | Expr='x', prec: int=6):
        pass

    def __repr__(self) -> str:
        pass

    def __eq__(self, other) -> bool:
        pass

    def __hash__(self) -> int:
        pass

    def is_element(self, element: object) -> TypeIs[PowerSeriesElement[Er]]:
        pass

    def order_term(self) -> PowerSeriesElement[Er]:
        pass

    def from_expr(self, expr: Expr) -> PowerSeriesElement[Er]:
        pass

    def from_list(self, lst: list[Er], prec: int | None=None) -> PowerSeriesElement[Er]:
        pass

    def from_element(self, element: TSeriesElement[Er]) -> PowerSeriesElement[Er]:
        pass

    def from_int(self, arg: int) -> PowerSeriesElement[Er]:
        pass

    def from_ground(self, arg: Er) -> PowerSeriesElement[Er]:
        pass

    def to_expr(self, element: PowerSeriesElement[Er]) -> Expr:
        pass

    def to_list(self, element: PowerSeriesElement[Er]) -> list[Er]:
        pass

    def to_dense(self, element: PowerSeriesElement[Er]) -> dup[Er]:
        pass

    def domain_new(self, arg: Er | int) -> Er:
        pass

    def ring_new(self, arg: Expr | Er | int) -> PowerSeriesElement[Er]:
        pass

class PowerSeriesRing(Ring[PowerSeriesElement[Er]], CompositeDomain):
    is_PowerSeriesRing = is_Series = True
    has_assoc_Ring = True
    has_assoc_Field = False
    ring: SeriesRingProto[Er]
    dtype: type[PowerSeriesElement[Er]]
    gen: PowerSeriesElement[Er]
    symbol: Expr
    domain: Domain[Er]

    def __init__(self, domain: Domain[Er], symbol: Expr | str='x', prec: int=6):
        ring, gen = power_series_ring(str(symbol), domain, prec)
        self.ring = ring
        self.gen = gen
        self.dtype = ring.dtype
        self.domain = ring.domain
        self.symbol = ring.symbol

    def __eq__(self, other: object) -> bool:
        if isinstance(other, PowerSeriesRing):
            return self.ring == other.ring
        else:
            return NotImplemented

    def __hash__(self) -> int:
        return hash((self.__class__.__name__, self.ring, self.domain, self.symbol))

    def __repr__(self) -> str:
        return f'{self.domain}[[{self.symbol}], {self.prec}]'

    def new(self, element: Expr | Er | int) -> PowerSeriesElement[Er]:
        return self.ring.ring_new(element)

    def of_type(self, element) -> TypeIs[PowerSeriesElement[Er]]:
        return self.ring.is_element(element)

    @cached_property
    def zero(self) -> PowerSeriesElement[Er]:
        return self.ring.zero

    @cached_property
    def one(self) -> PowerSeriesElement[Er]:
        return self.ring.one

    @cached_property
    def prec(self) -> int:
        return self.ring.prec

    def is_unit(self, a: PowerSeriesElement[Er]) -> bool:
        if not a.is_ground:
            return False
        K = self.domain
        return K.is_unit(a.constant_coefficient())

    def canonical_unit(self, a: PowerSeriesElement[Er]) -> PowerSeriesElement[Er]:
        u = self.domain.canonical_unit(a.constant_coefficient())
        return self.ring.from_ground(u)

    def to_sympy(self, a: PowerSeriesElement[Er]) -> Expr:
        return self.ring.to_expr(a)

    def from_sympy(self, a: Expr) -> PowerSeriesElement[Er]:
        return self.ring.from_expr(a)

    def from_ZZ(K1, a, K0):
        return K1.ring.from_ground(K1.domain.convert(a, K0))

    def from_ZZ_python(K1, a, K0):
        return K1.ring.from_ground(K1.domain.convert(a, K0))

    def from_QQ(K1, a, K0):
        return K1.ring.from_ground(K1.domain.convert(a, K0))

    def from_QQ_python(K1, a, K0):
        return K1.ring.from_ground(K1.domain.convert(a, K0))

    def from_ZZ_gmpy(K1, a, K0):
        return K1.ring.from_ground(K1.domain.convert(a, K0))

    def from_QQ_gmpy(K1, a, K0):
        return K1.ring.from_ground(K1.domain.convert(a, K0))

    def is_positive(self, a: PowerSeriesElement[Er]) -> bool:
        c = a.constant_coefficient()
        return self.domain.is_positive(c)

    def is_negative(self, a: PowerSeriesElement[Er]) -> bool:
        c = a.constant_coefficient()
        return self.domain.is_negative(c)

    def is_nonpositive(self, a: PowerSeriesElement[Er]) -> bool:
        c = a.constant_coefficient()
        return self.domain.is_nonpositive(c)

    def is_nonnegative(self, a: PowerSeriesElement[Er]) -> bool:
        c = a.constant_coefficient()
        return self.domain.is_nonnegative(c)