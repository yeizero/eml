from __future__ import annotations
from sympy.core.add import Add
from sympy.core.mul import Mul
from sympy.core.singleton import S
from sympy.core.symbol import Dummy, symbols
from sympy.external.gmpy import MPQ
from sympy.polys.domains.characteristiczero import CharacteristicZero
from sympy.polys.domains.field import Field
from sympy.polys.domains.simpledomain import SimpleDomain
from sympy.polys.domains.ringextension import RingExtension
from sympy.polys.polyclasses import ANP, DMP
from sympy.polys.polyerrors import CoercionFailed, DomainError, NotAlgebraic, IsomorphismFailed
from sympy.utilities import public
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from sympy.polys.domains.domain import Domain
    from sympy.core.expr import Expr
Alg = ANP[MPQ]

@public
class AlgebraicField(Field[Alg], CharacteristicZero, SimpleDomain[Alg], RingExtension[Alg, MPQ]):
    dtype: type[Alg] = ANP
    is_AlgebraicField = is_Algebraic = True
    is_Numerical = True
    has_assoc_Ring = False
    has_assoc_Field = True
    dom: Domain[MPQ]
    mod: DMP[MPQ]

    def __init__(self, dom: Domain[MPQ], *ext: Expr, alias: str | None=None) -> None:
        if not dom.is_QQ:
            raise DomainError('ground domain must be a rational field')
        from sympy.polys.numberfields import to_number_field
        if len(ext) == 1 and isinstance(ext[0], tuple):
            orig_ext = ext[0][1:]
        else:
            orig_ext = ext
        if alias is None and len(ext) == 1:
            alias = getattr(ext[0], 'alias', None)
        self.orig_ext = orig_ext
        '\n        Original elements given to generate the extension.\n\n        >>> from sympy import QQ, sqrt\n        >>> K = QQ.algebraic_field(sqrt(2), sqrt(3))\n        >>> K.orig_ext\n        (sqrt(2), sqrt(3))\n        '
        self.ext = to_number_field(ext, alias=alias)
        '\n        Primitive element used for the extension.\n\n        >>> from sympy import QQ, sqrt\n        >>> K = QQ.algebraic_field(sqrt(2), sqrt(3))\n        >>> K.ext\n        sqrt(2) + sqrt(3)\n        '
        self.mod = self.ext.minpoly.rep
        '\n        Minimal polynomial for the primitive element of the extension.\n\n        >>> from sympy import QQ, sqrt\n        >>> K = QQ.algebraic_field(sqrt(2))\n        >>> K.mod\n        DMP([1, 0, -2], QQ)\n        '
        self.domain = self.dom = dom
        self.ngens = 1
        self.symbols = self.gens = (self.ext,)
        self.unit = self([dom(1), dom(0)])
        self.zero = self.dtype.zero(self.mod.to_list(), dom)
        self.one = self.dtype.one(self.mod.to_list(), dom)
        self._maximal_order = None
        self._discriminant = None
        self._nilradicals_mod_p: dict = {}

    def new(self, element):
        return self.dtype(element, self.mod.to_list(), self.dom)

    def __str__(self):
        return str(self.dom) + '<' + str(self.ext) + '>'

    def __hash__(self):
        return hash((self.__class__.__name__, self.dtype, self.dom, self.ext))

    def __eq__(self, other):
        if isinstance(other, AlgebraicField):
            return self.dtype == other.dtype and self.ext == other.ext
        else:
            return NotImplemented

    def algebraic_field(self, *extension, alias=None):
        return AlgebraicField(self.dom, *(self.ext,) + extension, alias=alias)

    def to_dict(self, element: Alg) -> dict[tuple[int, ...], MPQ]:
        return element.to_dict()

    def to_alg_num(self, a):
        return self.ext.field_element(a)

    def to_sympy(self, a):
        if not hasattr(self, '_converter'):
            self._converter = _make_converter(self)
        return self._converter(a)

    def from_sympy(self, a):
        try:
            return self([self.dom.from_sympy(a)])
        except CoercionFailed:
            pass
        from sympy.polys.numberfields import to_number_field
        try:
            return self(to_number_field(a, self.ext).native_coeffs())
        except (NotAlgebraic, IsomorphismFailed):
            raise CoercionFailed('%s is not a valid algebraic number in %s' % (a, self))

    def from_ZZ(K1, a, K0):
        return K1(K1.dom.convert(a, K0))

    def from_ZZ_python(K1, a, K0):
        return K1(K1.dom.convert(a, K0))

    def from_QQ(K1, a, K0):
        return K1(K1.dom.convert(a, K0))

    def from_QQ_python(K1, a, K0):
        return K1(K1.dom.convert(a, K0))

    def from_ZZ_gmpy(K1, a, K0):
        return K1(K1.dom.convert(a, K0))

    def from_QQ_gmpy(K1, a, K0):
        return K1(K1.dom.convert(a, K0))

    def from_RealField(K1, a, K0):
        return K1(K1.dom.convert(a, K0))

    def get_ring(self):
        raise DomainError('there is no ring associated with %s' % self)

    def is_positive(self, a):
        return self.dom.is_positive(a.LC())

    def is_negative(self, a):
        return self.dom.is_negative(a.LC())

    def is_nonpositive(self, a):
        return self.dom.is_nonpositive(a.LC())

    def is_nonnegative(self, a):
        return self.dom.is_nonnegative(a.LC())

    def numer(self, a):
        return a

    def denom(self, a):
        return self.one

    def from_AlgebraicField(K1, a, K0):
        return K1.from_sympy(K0.to_sympy(a))

    def from_GaussianIntegerRing(K1, a, K0):
        return K1.from_sympy(K0.to_sympy(a))

    def from_GaussianRationalField(K1, a, K0):
        return K1.from_sympy(K0.to_sympy(a))

    def _do_round_two(self):
        from sympy.polys.numberfields.basis import round_two
        ZK, dK = round_two(self, radicals=self._nilradicals_mod_p)
        self._maximal_order = ZK
        self._discriminant = dK

    def maximal_order(self):
        if self._maximal_order is None:
            self._do_round_two()
        return self._maximal_order

    def integral_basis(self, fmt=None):
        ZK = self.maximal_order()
        M = ZK.QQ_matrix
        n = M.shape[1]
        B = [self.new(list(reversed(M[:, j].flat()))) for j in range(n)]
        if fmt == 'sympy':
            return [self.to_sympy(b) for b in B]
        elif fmt == 'alg':
            return [self.to_alg_num(b) for b in B]
        return B

    def discriminant(self):
        if self._discriminant is None:
            self._do_round_two()
        return self._discriminant

    def primes_above(self, p):
        from sympy.polys.numberfields.primes import prime_decomp
        ZK = self.maximal_order()
        dK = self.discriminant()
        rad = self._nilradicals_mod_p.get(p)
        return prime_decomp(p, ZK=ZK, dK=dK, radical=rad)

    def galois_group(self, by_name=False, max_tries=30, randomize=False):
        return self.ext.minpoly_of_element().galois_group(by_name=by_name, max_tries=max_tries, randomize=randomize)

def _make_converter(K):
    ext = K.ext.as_expr()
    todom = K.dom.from_sympy
    toexpr = K.dom.to_sympy
    if not ext.is_Add:
        powers = [ext ** n for n in range(K.mod.degree())]
    else:
        from sympy.polys.numberfields.minpoly import minpoly
        gens, coeffs = zip(*ext.as_coefficients_dict().items())
        syms = symbols(f'a:{len(gens)}', cls=Dummy)
        sym2gen = dict(zip(syms, gens))
        R = K.dom[syms]
        monoms = [R.ring.monomial_basis(i) for i in range(R.ngens)]
        ext_dict = {m: todom(c) for m, c in zip(monoms, coeffs)}
        ext_poly = R.ring.from_dict(ext_dict)
        minpolys = [R.from_sympy(minpoly(g, s)) for s, g in sym2gen.items()]
        powers = [R.one, ext_poly]
        for n in range(2, K.mod.degree()):
            ext_poly_n = (powers[-1] * ext_poly).rem(minpolys)
            powers.append(ext_poly_n)
        powers = [p.as_expr().xreplace(sym2gen) for p in powers]
    powers = [p.expand() for p in powers]
    terms = [dict((t.as_coeff_Mul()[::-1] for t in Add.make_args(p))) for p in powers]
    algebraics = set().union(*terms)
    matrix = [[todom(t.get(a, S.Zero)) for t in terms] for a in algebraics]

    def converter(a):
        ai = a.to_list()[::-1]
        coeffs_dom = [sum((mij * aj for mij, aj in zip(mi, ai))) for mi in matrix]
        coeffs_sympy = [toexpr(c) for c in coeffs_dom]
        res = Add(*(Mul(c, a) for c, a in zip(coeffs_sympy, algebraics)))
        return res
    return converter