from __future__ import annotations
from sympy.polys.domains.domain import Domain, Er
from sympy.utilities import public

@public
class SimpleDomain(Domain[Er]):
    is_Simple = True

    def inject(self, *gens):
        return self.poly_ring(*gens)