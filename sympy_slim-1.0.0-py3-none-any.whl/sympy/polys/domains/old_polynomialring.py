from __future__ import annotations
from sympy.polys.agca.modules import FreeModulePolyRing
from sympy.polys.domains.compositedomain import CompositeDomain
from sympy.polys.domains.old_fractionfield import FractionField
from sympy.polys.domains.ring import Ring
from sympy.polys.orderings import monomial_key, build_product_order
from sympy.polys.polyclasses import DMP, DMF
from sympy.polys.polyerrors import GeneratorsNeeded, PolynomialError, CoercionFailed, ExactQuotientFailed, NotReversible
from sympy.polys.polyutils import dict_from_basic, basic_from_dict, _dict_reorder
from sympy.utilities import public
from sympy.utilities.iterables import iterable

@public
class PolynomialRingBase(Ring, CompositeDomain):
    has_assoc_Ring = True
    has_assoc_Field = True
    default_order = 'grevlex'

    def __init__(self, dom, *gens, **opts):
        if not gens:
            raise GeneratorsNeeded('generators not specified')
        lev = len(gens) - 1
        self.ngens = len(gens)
        self.zero = self.dtype.zero(lev, dom)
        self.one = self.dtype.one(lev, dom)
        self.domain = self.dom = dom
        self.symbols = self.gens = gens
        self.order = opts.get('order', monomial_key(self.default_order))

    def set_domain(self, dom, /):
        return self.__class__(dom, *self.gens, order=self.order)

    def new(self, element, /):
        return self.dtype(element, self.dom, len(self.gens) - 1)

    def _ground_new(self, element):
        return self.one.ground_new(element)

    def _from_dict(self, element):
        return DMP.from_dict(element, len(self.gens) - 1, self.dom)

    def __str__(self):
        s_order = str(self.order)
        orderstr = ' order=' + s_order if s_order != self.default_order else ''
        return str(self.dom) + '[' + ','.join(map(str, self.gens)) + orderstr + ']'

    def __hash__(self):
        return hash((self.__class__.__name__, self.dtype, self.dom, self.gens, self.order))

    def __eq__(self, other):
        return isinstance(other, PolynomialRingBase) and self.dtype == other.dtype and (self.dom == other.dom) and (self.gens == other.gens) and (self.order == other.order)

    def from_ZZ(K1, a, K0):
        return K1._ground_new(K1.dom.convert(a, K0))

    def from_ZZ_python(K1, a, K0):
        return K1._ground_new(K1.dom.convert(a, K0))

    def from_QQ(K1, a, K0):
        return K1._ground_new(K1.dom.convert(a, K0))

    def from_QQ_python(K1, a, K0):
        return K1._ground_new(K1.dom.convert(a, K0))

    def from_ZZ_gmpy(K1, a, K0):
        return K1._ground_new(K1.dom.convert(a, K0))

    def from_QQ_gmpy(K1, a, K0):
        return K1._ground_new(K1.dom.convert(a, K0))

    def from_RealField(K1, a, K0):
        return K1._ground_new(K1.dom.convert(a, K0))

    def from_AlgebraicField(K1, a, K0):
        if K1.dom == K0:
            return K1._ground_new(a)

    def from_PolynomialRing(K1, a, K0):
        if K1.gens == K0.symbols:
            if K1.dom == K0.dom:
                return K1(dict(a))
            else:
                convert_dom = lambda c: K1.dom.convert_from(c, K0.dom)
                return K1._from_dict({m: convert_dom(c) for m, c in a.items()})
        else:
            monoms, coeffs = _dict_reorder(a.to_dict(), K0.symbols, K1.gens)
            if K1.dom != K0.dom:
                coeffs = [K1.dom.convert(c, K0.dom) for c in coeffs]
            return K1._from_dict(dict(zip(monoms, coeffs)))

    def from_GlobalPolynomialRing(K1, a, K0):
        if K1.gens == K0.gens:
            if K1.dom != K0.dom:
                a = a.convert(K1.dom)
            return K1(a.to_list())
        else:
            monoms, coeffs = _dict_reorder(a.to_dict(), K0.gens, K1.gens)
            if K1.dom != K0.dom:
                coeffs = [K1.dom.convert(c, K0.dom) for c in coeffs]
            return K1(dict(zip(monoms, coeffs)))

    def get_field(self):
        return FractionField(self.dom, *self.gens)

    def poly_ring(self, *gens):
        raise NotImplementedError('nested domains not allowed')

    def frac_field(self, *gens):
        raise NotImplementedError('nested domains not allowed')

    def revert(self, a):
        try:
            return self.exquo(self.one, a)
        except (ExactQuotientFailed, ZeroDivisionError):
            raise NotReversible('%s is not a unit' % a)

    def gcdex(self, a, b):
        return a.gcdex(b)

    def gcd(self, a, b):
        return a.gcd(b)

    def lcm(self, a, b):
        return a.lcm(b)

    def factorial(self, a):
        return self.dtype(self.dom.factorial(a))

    def _vector_to_sdm(self, v, order):
        raise NotImplementedError

    def _sdm_to_dics(self, s, n):
        from sympy.polys.distributedmodules import sdm_to_dict
        dic = sdm_to_dict(s)
        res = [{} for _ in range(n)]
        for k, v in dic.items():
            res[k[0]][k[1:]] = v
        return res

    def _sdm_to_vector(self, s, n):
        dics = self._sdm_to_dics(s, n)
        return [self(x) for x in dics]

    def free_module(self, rank):
        return FreeModulePolyRing(self, rank)

def _vector_to_sdm_helper(v, order):
    from sympy.polys.distributedmodules import sdm_from_dict
    d = {}
    for i, e in enumerate(v):
        for key, value in e.to_dict().items():
            d[(i,) + key] = value
    return sdm_from_dict(d, order)

@public
class GlobalPolynomialRing(PolynomialRingBase):
    is_PolynomialRing = is_Poly = True
    dtype = DMP

    def new(self, element):
        if isinstance(element, dict):
            return DMP.from_dict(element, len(self.gens) - 1, self.dom)
        elif element in self.dom:
            return self._ground_new(self.dom.convert(element))
        else:
            return self.dtype(element, self.dom, len(self.gens) - 1)

    def from_FractionField(K1, a, K0):
        if a.denom().is_one:
            return K1.from_GlobalPolynomialRing(a.numer(), K0)

    def to_sympy(self, a):
        return basic_from_dict(a.to_sympy_dict(), *self.gens)

    def from_sympy(self, a):
        try:
            rep, _ = dict_from_basic(a, gens=self.gens)
        except PolynomialError:
            raise CoercionFailed('Cannot convert %s to type %s' % (a, self))
        for k, v in rep.items():
            rep[k] = self.dom.from_sympy(v)
        return DMP.from_dict(rep, self.ngens - 1, self.dom)

    def is_positive(self, a):
        return self.dom.is_positive(a.LC())

    def is_negative(self, a):
        return self.dom.is_negative(a.LC())

    def is_nonpositive(self, a):
        return self.dom.is_nonpositive(a.LC())

    def is_nonnegative(self, a):
        return self.dom.is_nonnegative(a.LC())

    def _vector_to_sdm(self, v, order):
        return _vector_to_sdm_helper(v, order)

class GeneralizedPolynomialRing(PolynomialRingBase):
    dtype = DMF

    def new(self, a):
        res = self.dtype(a, self.dom, len(self.gens) - 1)
        if res.denom().terms(order=self.order)[0][0] != (0,) * len(self.gens):
            from sympy.printing.str import sstr
            raise CoercionFailed('denominator %s not allowed in %s' % (sstr(res), self))
        return res

    def __contains__(self, a):
        try:
            a = self.convert(a)
        except CoercionFailed:
            return False
        return a.denom().terms(order=self.order)[0][0] == (0,) * len(self.gens)

    def to_sympy(self, a):
        return basic_from_dict(a.numer().to_sympy_dict(), *self.gens) / basic_from_dict(a.denom().to_sympy_dict(), *self.gens)

    def from_sympy(self, a):
        p, q = a.as_numer_denom()
        num, _ = dict_from_basic(p, gens=self.gens)
        den, _ = dict_from_basic(q, gens=self.gens)
        for k, v in num.items():
            num[k] = self.dom.from_sympy(v)
        for k, v in den.items():
            den[k] = self.dom.from_sympy(v)
        return self((num, den)).cancel()

    def exquo(self, a, b):
        r = a / b
        try:
            r = self.new((r.num, r.den))
        except CoercionFailed:
            raise ExactQuotientFailed(a, b, self)
        return r

    def from_FractionField(K1, a, K0):
        dmf = K1.get_field().from_FractionField(a, K0)
        return K1((dmf.num, dmf.den))

    def _vector_to_sdm(self, v, order):
        u = self.one.numer()
        for x in v:
            u *= x.denom()
        return _vector_to_sdm_helper([x.numer() * u / x.denom() for x in v], order)

@public
def PolynomialRing(dom, *gens, **opts):
    order = opts.get('order', GeneralizedPolynomialRing.default_order)
    if iterable(order):
        order = build_product_order(order, gens)
    order = monomial_key(order)
    opts['order'] = order
    if order.is_global:
        return GlobalPolynomialRing(dom, *gens, **opts)
    else:
        return GeneralizedPolynomialRing(dom, *gens, **opts)