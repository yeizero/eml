from __future__ import annotations
from sympy.polys.domains.finitefield import FiniteField
from sympy.polys.domains.gmpyintegerring import GMPYIntegerRing
from sympy.utilities import public

@public
class GMPYFiniteField(FiniteField):
    alias = 'FF_gmpy'

    def __init__(self, mod, symmetric=True):
        super().__init__(mod, GMPYIntegerRing(), symmetric)