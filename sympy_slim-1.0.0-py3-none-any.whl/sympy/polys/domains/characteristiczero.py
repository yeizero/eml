from __future__ import annotations
from sympy.polys.domains.domain import Domain
from sympy.utilities import public

@public
class CharacteristicZero(Domain):
    has_CharacteristicZero = True

    def characteristic(self):
        return 0