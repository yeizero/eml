from __future__ import annotations
from sympy.core.numbers import int_valued
from sympy.polys.domains.groundtypes import PythonInteger, SymPyInteger, sqrt as python_sqrt, factorial as python_factorial, python_gcdex, python_gcd, python_lcm
from sympy.polys.domains.integerring import IntegerRing
from sympy.polys.polyerrors import CoercionFailed
from sympy.utilities import public

@public
class PythonIntegerRing(IntegerRing):
    dtype = PythonInteger
    zero = dtype(0)
    one = dtype(1)
    alias = 'ZZ_python'

    def __init__(self):
        pass

    def to_sympy(self, a):
        return SymPyInteger(a)

    def from_sympy(self, a):
        if a.is_Integer:
            return PythonInteger(a.p)
        elif int_valued(a):
            return PythonInteger(int(a))
        else:
            raise CoercionFailed('expected an integer, got %s' % a)

    def from_FF_python(K1, a, K0):
        return K0.to_int(a)

    def from_ZZ_python(K1, a, K0):
        return a

    def from_QQ(K1, a, K0):
        if a.denominator == 1:
            return a.numerator

    def from_QQ_python(K1, a, K0):
        if a.denominator == 1:
            return a.numerator

    def from_FF_gmpy(K1, a, K0):
        return PythonInteger(K0.to_int(a))

    def from_ZZ_gmpy(K1, a, K0):
        return PythonInteger(a)

    def from_QQ_gmpy(K1, a, K0):
        if a.denom() == 1:
            return PythonInteger(a.numer())

    def from_RealField(K1, a, K0):
        p, q = K0.to_rational(a)
        if q == 1:
            return PythonInteger(p)

    def gcdex(self, a, b):
        return python_gcdex(a, b)

    def gcd(self, a, b):
        return python_gcd(a, b)

    def lcm(self, a, b):
        return python_lcm(a, b)

    def sqrt(self, a):
        return python_sqrt(a)

    def factorial(self, a):
        return python_factorial(a)