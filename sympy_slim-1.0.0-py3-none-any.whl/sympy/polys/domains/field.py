from __future__ import annotations
from typing import TYPE_CHECKING
from sympy.polys.domains.domain import Ef
from sympy.polys.domains.ring import Ring
from sympy.polys.polyerrors import NotReversible, DomainError
from sympy.utilities import public
if TYPE_CHECKING:
    from typing import Self

@public
class Field(Ring[Ef]):
    is_Field = True
    is_PID = True

    def get_ring(self):
        raise DomainError('there is no ring associated with %s' % self)

    def get_field(self) -> Self:
        return self

    def exquo(self, a: Ef, b: Ef) -> Ef:
        return a / b

    def quo(self, a, b):
        return a / b

    def rem(self, a, b):
        return self.zero

    def div(self, a, b):
        return (a / b, self.zero)

    def gcd(self, a, b) -> Ef:
        try:
            ring = self.get_ring()
        except DomainError:
            return self.one
        p = ring.gcd(self.numer(a), self.numer(b))
        q = ring.lcm(self.denom(a), self.denom(b))
        return self.convert(p, ring) / q

    def gcdex(self, a, b) -> tuple[Ef, Ef, Ef]:
        d = self.gcd(a, b)
        if a == self.zero:
            if b == self.zero:
                return (self.zero, self.one, self.zero)
            else:
                return (self.zero, d / b, d)
        else:
            return (d / a, self.zero, d)

    def lcm(self, a, b):
        try:
            ring = self.get_ring()
        except DomainError:
            return a * b
        p = ring.lcm(self.numer(a), self.numer(b))
        q = ring.gcd(self.denom(a), self.denom(b))
        return self.convert(p, ring) / q

    def revert(self, a):
        if a:
            return 1 / a
        else:
            raise NotReversible('zero is not reversible')

    def is_unit(self, a):
        return bool(a)