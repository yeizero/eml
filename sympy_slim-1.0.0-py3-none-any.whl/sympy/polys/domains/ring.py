from __future__ import annotations
from sympy.polys.domains.domain import Domain, Er
from sympy.polys.polyerrors import ExactQuotientFailed, NotInvertible, NotReversible
from sympy.utilities import public

@public
class Ring(Domain[Er]):
    is_Ring = True

    def get_ring(self):
        return self

    def exquo(self, a, b):
        if a % b:
            raise ExactQuotientFailed(a, b, self)
        else:
            return a // b

    def quo(self, a, b):
        return a // b

    def rem(self, a, b):
        return a % b

    def div(self, a, b):
        return divmod(a, b)

    def invert(self, a, b):
        s, t, h = self.gcdex(a, b)
        if self.is_one(h):
            return s % b
        else:
            raise NotInvertible('zero divisor')

    def revert(self, a):
        if self.is_one(a) or self.is_one(-a):
            return a
        else:
            raise NotReversible('only units are reversible in a ring')

    def is_unit(self, a):
        try:
            self.revert(a)
            return True
        except NotReversible:
            return False

    def numer(self, a):
        return a

    def denom(self, a):
        return self.one

    def free_module(self, rank):
        raise NotImplementedError

    def ideal(self, *gens):
        from sympy.polys.agca.ideals import ModuleImplementedIdeal
        return ModuleImplementedIdeal(self, self.free_module(1).submodule(*[[x] for x in gens]))

    def quotient_ring(self, e):
        from sympy.polys.agca.ideals import Ideal
        from sympy.polys.domains.quotientring import QuotientRing
        if not isinstance(e, Ideal):
            e = self.ideal(*e)
        return QuotientRing(self, e)

    def __truediv__(self, e):
        return self.quotient_ring(e)