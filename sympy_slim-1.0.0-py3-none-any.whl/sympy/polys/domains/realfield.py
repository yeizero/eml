from __future__ import annotations
from sympy.external.gmpy import SYMPY_INTS, MPQ
from sympy.external.mpmath import to_rational as _mpmath_to_rational, MPContext
from sympy.core.numbers import Float
from sympy.polys.domains.field import Field
from sympy.polys.domains.simpledomain import SimpleDomain
from sympy.polys.domains.characteristiczero import CharacteristicZero
from sympy.polys.polyerrors import CoercionFailed
from sympy.utilities import public

def to_rational(s, max_denom, limit=True):
    p, q = _mpmath_to_rational(s._mpf_)
    p = int(p)
    q = int(q)
    if not limit or q <= max_denom:
        return (p, q)
    p0, q0, p1, q1 = (0, 1, 1, 0)
    n, d = (p, q)
    while True:
        a = n // d
        q2 = q0 + a * q1
        if q2 > max_denom:
            break
        p0, q0, p1, q1 = (p1, q1, p0 + a * p1, q2)
        n, d = (d, n - a * d)
    k = (max_denom - q0) // q1
    number = MPQ(p, q)
    bound1 = MPQ(p0 + k * p1, q0 + k * q1)
    bound2 = MPQ(p1, q1)
    if not bound2 or not bound1:
        return (p, q)
    elif abs(bound2 - number) <= abs(bound1 - number):
        return (bound2.numerator, bound2.denominator)
    else:
        return (bound1.numerator, bound1.denominator)

@public
class RealField(Field, CharacteristicZero, SimpleDomain):
    rep = 'RR'
    is_RealField = is_RR = True
    is_Exact = False
    is_Numerical = True
    is_PID = False
    has_assoc_Ring = False
    has_assoc_Field = True
    _default_precision = 53

    @property
    def has_default_precision(self):
        return self.precision == self._default_precision

    @property
    def precision(self):
        return self._context.prec

    @property
    def dps(self):
        return self._context.dps

    @property
    def tolerance(self):
        return self._tolerance

    def __init__(self, prec=None, dps=None, tol=None):
        context = MPContext()
        if prec is None and dps is None:
            context.prec = self._default_precision
        elif dps is None:
            context.prec = prec
        elif prec is None:
            context.dps = dps
        else:
            raise TypeError('Cannot set both prec and dps')
        self._context = context
        self._dtype = context.mpf
        self.zero = self.dtype(0)
        self.one = self.dtype(1)
        self._max_denom = max(2 ** context.prec // 200, 99)
        self._tolerance = self.one / self._max_denom

    @property
    def tp(self):
        return self._dtype

    def dtype(self, arg):
        if isinstance(arg, SYMPY_INTS):
            arg = int(arg)
        return self._dtype(arg)

    def __eq__(self, other):
        return isinstance(other, RealField) and self.precision == other.precision

    def __hash__(self):
        return hash((self.__class__.__name__, self._dtype, self.precision))

    def to_sympy(self, element):
        return Float(element, self.dps)

    def from_sympy(self, expr):
        number = expr.evalf(n=self.dps)
        if number.is_Number:
            return self.dtype(number)
        else:
            raise CoercionFailed('expected real number, got %s' % expr)

    def from_ZZ(self, element, base):
        return self.dtype(element)

    def from_ZZ_python(self, element, base):
        return self.dtype(element)

    def from_ZZ_gmpy(self, element, base):
        return self.dtype(int(element))

    def from_QQ(self, element, base):
        return self.dtype(element.numerator) / int(element.denominator)

    def from_QQ_python(self, element, base):
        return self.dtype(element.numerator) / int(element.denominator)

    def from_QQ_gmpy(self, element, base):
        return self.dtype(int(element.numerator)) / int(element.denominator)

    def from_AlgebraicField(self, element, base):
        return self.from_sympy(base.to_sympy(element).evalf(self.dps))

    def from_RealField(self, element, base):
        return self.dtype(element)

    def from_ComplexField(self, element, base):
        if not element.imag:
            return self.dtype(element.real)

    def to_rational(self, element, limit=True):
        return to_rational(element, self._max_denom, limit=limit)

    def get_ring(self):
        return self

    def get_exact(self):
        from sympy.polys.domains import QQ
        return QQ

    def gcd(self, a, b):
        return self.one

    def lcm(self, a, b):
        return a * b

    def almosteq(self, a, b, tolerance=None):
        return self._context.almosteq(a, b, tolerance)

    def is_square(self, a):
        return a >= 0

    def exsqrt(self, a):
        return a ** 0.5 if a >= 0 else None
RR = RealField()