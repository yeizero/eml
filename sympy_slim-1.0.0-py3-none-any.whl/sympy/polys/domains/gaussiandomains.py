from __future__ import annotations
from typing import Generic, TypeVar, Any, TYPE_CHECKING
from sympy.external.gmpy import MPZ, MPQ
from sympy.core.numbers import I
from sympy.polys.polyclasses import DMP
from sympy.polys.polyerrors import CoercionFailed
from sympy.polys.domains.integerring import ZZ, IntegerRing
from sympy.polys.domains.rationalfield import QQ, RationalField
from sympy.polys.domains.algebraicfield import AlgebraicField
from sympy.polys.domains.domainelement import DomainElement
from sympy.polys.domains.field import Field
from sympy.polys.domains.ring import Ring
from sympy.polys.domains.ringextension import RingExtension
Tdom = TypeVar('Tdom', MPZ, MPQ)
Telem = TypeVar('Telem', bound='GaussianElement')
if TYPE_CHECKING:
    from sympy.core.expr import Expr
    from sympy.polys.domains.polynomialring import PolynomialRing
    from sympy.polys.domains.domain import Domain
    from typing import Self

class GaussianElement(DomainElement, Generic[Tdom]):
    base: Domain[Tdom]
    _parent: GaussianDomain[Self, Tdom]
    x: Tdom
    y: Tdom
    __slots__ = ('x', 'y')

    def __new__(cls, x: Tdom | int, y: Tdom | int=0):
        conv = cls.base.convert
        return cls.new(conv(x), conv(y))

    @classmethod
    def new(cls, x: Tdom, y: Tdom) -> Self:
        obj = super().__new__(cls)
        obj.x = x
        obj.y = y
        return obj

    def parent(self) -> Domain[Self]:
        return self._parent

    def __hash__(self) -> int:
        return hash((self.x, self.y))

    def __eq__(self, other) -> bool:
        if isinstance(other, self.__class__):
            return self.x == other.x and self.y == other.y
        else:
            return NotImplemented

    def __lt__(self, other) -> bool:
        if not isinstance(other, GaussianElement):
            return NotImplemented
        return [self.y, self.x] < [other.y, other.x]

    def __pos__(self) -> Self:
        return self

    def __neg__(self) -> Self:
        return self.new(-self.x, -self.y)

    def __repr__(self) -> str:
        return '%s(%s, %s)' % (self._parent.rep, self.x, self.y)

    def __str__(self) -> str:
        return str(self._parent.to_sympy(self))

    @classmethod
    def _get_xy(cls, other: GaussianElement[Tdom] | int) -> tuple[Tdom, Tdom] | None:
        if isinstance(other, cls):
            return (other.x, other.y)
        else:
            try:
                other_convert = cls._parent.convert(other)
            except CoercionFailed:
                return None
            return (other_convert.x, other_convert.y)

    def __add__(self, other: Self | int) -> Self:
        other_conv = self._get_xy(other)
        if other_conv is None:
            return NotImplemented
        x, y = other_conv
        return self.new(self.x + x, self.y + y)
    __radd__ = __add__

    def __sub__(self, other: Self | int) -> Self:
        other_conv = self._get_xy(other)
        if other_conv is None:
            return NotImplemented
        x, y = other_conv
        return self.new(self.x - x, self.y - y)

    def __rsub__(self, other: Self | int) -> Self:
        other_conv = self._get_xy(other)
        if other_conv is None:
            return NotImplemented
        x, y = other_conv
        return self.new(x - self.x, y - self.y)

    def __mul__(self, other: Self | int) -> Self:
        other_conv = self._get_xy(other)
        if other_conv is None:
            return NotImplemented
        x, y = other_conv
        return self.new(self.x * x - self.y * y, self.x * y + self.y * x)
    __rmul__ = __mul__

    def __pow__(self, exp: int) -> Self:
        if exp == 0:
            return self.new(self.base(1), self.base(0))
        if exp < 0:
            self, exp = (1 / self, -exp)
        if exp == 1:
            return self
        pow2 = self
        prod = self if exp % 2 else self._parent.one
        exp //= 2
        while exp:
            pow2 *= pow2
            if exp % 2:
                prod *= pow2
            exp //= 2
        return prod

    def __bool__(self) -> bool:
        return bool(self.x) or bool(self.y)

    def quadrant(self) -> int:
        if self.y > 0:
            return 0 if self.x > 0 else 1
        elif self.y < 0:
            return 2 if self.x < 0 else 3
        else:
            return 0 if self.x >= 0 else 2

    def __divmod__(self, other: Self | int) -> tuple[Self, Self]:
        raise NotImplementedError

    def __rdivmod__(self, other: Self | int) -> tuple[Self, Self]:
        try:
            other_convert = self._parent.convert(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return other_convert.__divmod__(self)

    def __rtruediv__(self, other: GaussianElement | int) -> GaussianRational:
        try:
            other = QQ_I.convert(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return other.__truediv__(self)

    def __floordiv__(self, other: Self | int) -> Self:
        qr = self.__divmod__(other)
        if qr is NotImplemented:
            return NotImplemented
        return qr[0]

    def __rfloordiv__(self, other: Self | int) -> Self:
        qr = self.__rdivmod__(other)
        if qr is NotImplemented:
            return NotImplemented
        return qr[0]

    def __mod__(self, other: Self | int) -> Self:
        qr = self.__divmod__(other)
        if qr is NotImplemented:
            return NotImplemented
        return qr[1]

    def __rmod__(self, other: Self | int) -> Self:
        qr = self.__rdivmod__(other)
        if qr is NotImplemented:
            return NotImplemented
        return qr[1]

class GaussianInteger(GaussianElement[MPZ]):
    base = ZZ

    def __truediv__(self, other: GaussianElement | int) -> GaussianRational:
        return QQ_I.convert(self) / other

    def __divmod__(self, other: GaussianInteger | int) -> tuple[GaussianInteger, GaussianInteger]:
        if not other:
            raise ZeroDivisionError('divmod({}, 0)'.format(self))
        other_conv = self._get_xy(other)
        if other_conv is None:
            return NotImplemented
        x, y = other_conv
        a, b = (self.x * x + self.y * y, -self.x * y + self.y * x)
        c = x * x + y * y
        qx = (2 * a + c) // (2 * c)
        qy = (2 * b + c) // (2 * c)
        q = GaussianInteger(qx, qy)
        return (q, self - q * other)

class GaussianRational(GaussianElement[MPQ]):
    base = QQ

    def __truediv__(self, other: GaussianElement | int) -> Self:
        if not other:
            raise ZeroDivisionError('{} / 0'.format(self))
        other_conv = self._get_xy(other)
        if other_conv is None:
            return NotImplemented
        x, y = other_conv
        c = x * x + y * y
        return self.new((self.x * x + self.y * y) / c, (-self.x * y + self.y * x) / c)

    def __divmod__(self, other: Self | int) -> tuple[Self, Self]:
        try:
            other = self._parent.convert(other)
        except CoercionFailed:
            return NotImplemented
        if not other:
            raise ZeroDivisionError('{} % 0'.format(self))
        else:
            return (self / other, self._parent.zero)

class GaussianDomain(RingExtension[Telem, Tdom]):
    dom: Domain
    units: tuple[Telem, Telem, Telem, Telem]
    is_Numerical = True
    is_Exact = True
    has_assoc_Ring = True
    has_assoc_Field = True

    def to_dict(self, element: Telem) -> dict[tuple[int, ...], Tdom]:
        return {(0,): element.x, (1,): element.y}

    def to_sympy(self, a: Telem) -> Expr:
        conv = self.dom.to_sympy
        return conv(a.x) + I * conv(a.y)

    def from_sympy(self, a: Expr) -> Telem:
        r, b = a.as_coeff_Add()
        x = self.dom.from_sympy(r)
        if not b:
            return self.new(x, 0)
        r, b = b.as_coeff_Mul()
        y = self.dom.from_sympy(r)
        if b is I:
            return self.new(x, y)
        else:
            raise CoercionFailed('{} is not Gaussian'.format(a))

    def inject(self, *gens: Any) -> PolynomialRing[Telem]:
        return self.poly_ring(*gens)

    def canonical_unit(self, a: Telem) -> Telem:
        unit = self.units[-a.quadrant()]
        return unit

    def is_negative(self, a: Telem) -> bool:
        return False

    def is_positive(self, a: Telem) -> bool:
        return False

    def is_nonnegative(self, a: Telem) -> bool:
        return False

    def is_nonpositive(self, a: Telem) -> bool:
        return False

    def from_ZZ_gmpy(K1, a, K0) -> Telem:
        return K1(a)

    def from_ZZ(K1, a, K0) -> Telem:
        return K1(a)

    def from_ZZ_python(K1, a, K0) -> Telem:
        return K1(a)

    def from_QQ(K1, a, K0) -> Telem:
        return K1(a)

    def from_QQ_gmpy(K1, a, K0) -> Telem:
        return K1(a)

    def from_QQ_python(K1, a, K0) -> Telem:
        return K1(a)

    def from_AlgebraicField(K1, a, K0) -> Telem | None:
        if K0.ext.args[0] == I:
            return K1.from_sympy(K0.to_sympy(a))
        return None

class GaussianIntegerRing(GaussianDomain[GaussianInteger, MPZ], Ring[MPZ]):
    dom: IntegerRing = ZZ
    mod = DMP([ZZ.one, ZZ.zero, ZZ.one], ZZ)
    dtype = GaussianInteger
    zero = dtype(ZZ(0), ZZ(0))
    one = dtype(ZZ(1), ZZ(0))
    imag_unit = dtype(ZZ(0), ZZ(1))
    units = (one, imag_unit, -one, -imag_unit)
    rep = 'ZZ_I'
    is_GaussianRing = True
    is_ZZ_I = True
    is_PID = True

    def __init__(self):
        pass

    def __eq__(self, other):
        if isinstance(other, GaussianIntegerRing):
            return True
        else:
            return NotImplemented

    def __hash__(self) -> int:
        return hash('ZZ_I')

    @property
    def has_CharacteristicZero(self):
        return True

    def characteristic(self) -> int:
        return 0

    def get_ring(self) -> Self:
        return self

    def get_field(self) -> GaussianRationalField:
        return QQ_I

    def normalize(self, d: GaussianInteger, *args: GaussianInteger):
        unit = self.canonical_unit(d)
        d *= unit
        args = tuple((a * unit for a in args))
        return (d,) + args if args else d

    def gcd(self, a: GaussianInteger, b: GaussianInteger) -> GaussianInteger:
        while b:
            a, b = (b, a % b)
        unit = self.canonical_unit(a)
        return a * unit

    def gcdex(self, a: GaussianInteger, b: GaussianInteger) -> tuple[GaussianInteger, GaussianInteger, GaussianInteger]:
        x_a = self.one
        x_b = self.zero
        y_a = self.zero
        y_b = self.one
        while b:
            q = a // b
            a, b = (b, a - q * b)
            x_a, x_b = (x_b, x_a - q * x_b)
            y_a, y_b = (y_b, y_a - q * y_b)
        unit = self.canonical_unit(a)
        a, x_a, y_a = (a * unit, x_a * unit, y_a * unit)
        return (x_a, y_a, a)

    def lcm(self, a: GaussianInteger, b: GaussianInteger) -> GaussianInteger:
        return a * b // self.gcd(a, b)

    def from_GaussianIntegerRing(K1, a, K0) -> GaussianInteger:
        return a

    def from_GaussianRationalField(K1, a, K0) -> GaussianInteger:
        return K1.new(ZZ.convert(a.x), ZZ.convert(a.y))
ZZ_I = GaussianInteger._parent = GaussianIntegerRing()

class GaussianRationalField(GaussianDomain[GaussianRational, MPQ], Field[GaussianRational]):
    dom: RationalField = QQ
    mod = DMP([QQ.one, QQ.zero, QQ.one], QQ)
    dtype = GaussianRational
    zero = dtype(QQ(0), QQ(0))
    one = dtype(QQ(1), QQ(0))
    imag_unit = dtype(QQ(0), QQ(1))
    units = (one, imag_unit, -one, -imag_unit)
    rep = 'QQ_I'
    is_GaussianField = True
    is_QQ_I = True

    def __init__(self):
        pass

    def __eq__(self, other) -> bool:
        if isinstance(other, GaussianRationalField):
            return True
        else:
            return NotImplemented

    def __hash__(self) -> int:
        return hash('QQ_I')

    @property
    def has_CharacteristicZero(self) -> bool:
        return True

    def characteristic(self) -> int:
        return 0

    def get_ring(self) -> GaussianIntegerRing:
        return ZZ_I

    def get_field(self) -> Self:
        return self

    def as_AlgebraicField(self) -> AlgebraicField:
        return AlgebraicField(self.dom, I)

    def numer(self, a: GaussianRational) -> GaussianInteger:
        ZZ_I = self.get_ring()
        return ZZ_I.convert(a * self.denom(a))

    def denom(self, a: GaussianRational) -> GaussianInteger:
        ZZ = self.dom.get_ring()
        QQ = self.dom
        ZZ_I = self.get_ring()
        denom_ZZ = ZZ.lcm(QQ.denom(a.x), QQ.denom(a.y))
        return ZZ_I(denom_ZZ, ZZ.zero)

    def from_GaussianIntegerRing(K1, a, K0) -> GaussianRational:
        return K1.new(a.x, a.y)

    def from_GaussianRationalField(K1, a, K0) -> GaussianRational:
        return a

    def from_ComplexField(K1, a, K0) -> GaussianRational:
        return K1.new(QQ.convert(a.real), QQ.convert(a.imag))
QQ_I = GaussianRational._parent = GaussianRationalField()