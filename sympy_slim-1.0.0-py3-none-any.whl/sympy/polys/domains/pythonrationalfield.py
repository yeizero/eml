from __future__ import annotations
from sympy.polys.domains.groundtypes import PythonInteger, PythonRational, SymPyRational
from sympy.polys.domains.rationalfield import RationalField
from sympy.polys.polyerrors import CoercionFailed
from sympy.utilities import public

@public
class PythonRationalField(RationalField):
    dtype = PythonRational
    zero = dtype(0)
    one = dtype(1)
    alias = 'QQ_python'

    def __init__(self):
        pass

    def get_ring(self):
        from sympy.polys.domains import PythonIntegerRing
        return PythonIntegerRing()

    def to_sympy(self, a):
        return SymPyRational(a.numerator, a.denominator)

    def from_sympy(self, a):
        if a.is_Rational:
            return PythonRational(a.p, a.q)
        elif a.is_Float:
            from sympy.polys.domains import RR
            p, q = RR.to_rational(a)
            return PythonRational(int(p), int(q))
        else:
            raise CoercionFailed('expected `Rational` object, got %s' % a)

    def from_ZZ_python(K1, a, K0):
        return PythonRational(a)

    def from_QQ_python(K1, a, K0):
        return a

    def from_ZZ_gmpy(K1, a, K0):
        return PythonRational(PythonInteger(a))

    def from_QQ_gmpy(K1, a, K0):
        return PythonRational(PythonInteger(a.numer()), PythonInteger(a.denom()))

    def from_RealField(K1, a, K0):
        p, q = K0.to_rational(a)
        return PythonRational(int(p), int(q))

    def numer(self, a):
        return a.numerator

    def denom(self, a):
        return a.denominator