from __future__ import annotations
from sympy.polys.domains.groundtypes import GMPYRational, SymPyRational, gmpy_numer, gmpy_denom, factorial as gmpy_factorial
from sympy.polys.domains.rationalfield import RationalField
from sympy.polys.polyerrors import CoercionFailed
from sympy.utilities import public

@public
class GMPYRationalField(RationalField):
    dtype = GMPYRational
    zero = dtype(0)
    one = dtype(1)
    tp = type(one)
    alias = 'QQ_gmpy'

    def __init__(self):
        pass

    def get_ring(self):
        from sympy.polys.domains import GMPYIntegerRing
        return GMPYIntegerRing()

    def to_sympy(self, a):
        return SymPyRational(int(gmpy_numer(a)), int(gmpy_denom(a)))

    def from_sympy(self, a):
        if a.is_Rational:
            return GMPYRational(a.p, a.q)
        elif a.is_Float:
            from sympy.polys.domains import RR
            return GMPYRational(*map(int, RR.to_rational(a)))
        else:
            raise CoercionFailed('expected ``Rational`` object, got %s' % a)

    def from_ZZ_python(K1, a, K0):
        return GMPYRational(a)

    def from_QQ_python(K1, a, K0):
        return GMPYRational(a.numerator, a.denominator)

    def from_ZZ_gmpy(K1, a, K0):
        return GMPYRational(a)

    def from_QQ_gmpy(K1, a, K0):
        return a

    def from_GaussianRationalField(K1, a, K0):
        if a.y == 0:
            return GMPYRational(a.x)

    def from_RealField(K1, a, K0):
        return GMPYRational(*map(int, K0.to_rational(a)))

    def exquo(self, a, b):
        return GMPYRational(a) / GMPYRational(b)

    def quo(self, a, b):
        return GMPYRational(a) / GMPYRational(b)

    def rem(self, a, b):
        return self.zero

    def div(self, a, b):
        return (GMPYRational(a) / GMPYRational(b), self.zero)

    def numer(self, a):
        return a.numerator

    def denom(self, a):
        return a.denominator

    def factorial(self, a):
        return GMPYRational(gmpy_factorial(int(a)))