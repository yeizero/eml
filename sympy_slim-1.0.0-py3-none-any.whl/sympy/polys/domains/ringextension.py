from __future__ import annotations
from abc import abstractmethod
from typing import Generic
from sympy.polys.domains.domain import Domain, Er, Eg
from sympy.utilities import public

@public
class RingExtension(Domain[Er], Generic[Er, Eg]):
    is_RingExtension = True
    dom: Domain[Eg]
    'The ground domain of the ring extension.'
    ngens: int
    'The number of generators of the ring extension.'

    @abstractmethod
    def to_dict(self, element: Er) -> dict[tuple[int, ...], Eg]:
        raise NotImplementedError