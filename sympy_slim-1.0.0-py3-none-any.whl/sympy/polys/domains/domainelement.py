from __future__ import annotations
from sympy.utilities import public

@public
class DomainElement:
    __slots__ = ()

    def parent(self):
        raise NotImplementedError('abstract method')