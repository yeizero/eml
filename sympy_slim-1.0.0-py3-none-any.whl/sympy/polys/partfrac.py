from __future__ import annotations
from sympy.core import S, Add, sympify, Function, Lambda, Dummy
from sympy.core.traversal import preorder_traversal
from sympy.polys import Poly, RootSum, cancel, factor
from sympy.polys.polyerrors import PolynomialError
from sympy.polys.polyoptions import allowed_flags, set_defaults
from sympy.polys.polytools import parallel_poly_from_expr
from sympy.utilities import numbered_symbols, take, xthreaded, public

@xthreaded
@public
def apart(f, x=None, full=False, **options):
    allowed_flags(options, [])
    f = sympify(f)
    if f.is_Atom:
        return f
    else:
        P, Q = f.as_numer_denom()
    _options = options.copy()
    options = set_defaults(options, extension=True)
    try:
        (P, Q), opt = parallel_poly_from_expr((P, Q), x, **options)
    except PolynomialError as msg:
        if f.is_commutative:
            raise PolynomialError(msg)
        if f.is_Mul:
            c, nc = f.args_cnc(split_1=False)
            nc = f.func(*nc)
            if c:
                c = apart(f.func._from_args(c), x=x, full=full, **_options)
                return c * nc
            else:
                return nc
        elif f.is_Add:
            c = []
            nc = []
            for i in f.args:
                if i.is_commutative:
                    c.append(i)
                else:
                    try:
                        nc.append(apart(i, x=x, full=full, **_options))
                    except NotImplementedError:
                        nc.append(i)
            return apart(f.func(*c), x=x, full=full, **_options) + f.func(*nc)
        else:
            reps = []
            pot = preorder_traversal(f)
            next(pot)
            for e in pot:
                try:
                    reps.append((e, apart(e, x=x, full=full, **_options)))
                    pot.skip()
                except NotImplementedError:
                    pass
            return f.xreplace(dict(reps))
    if P.is_multivariate:
        fc = f.cancel()
        if fc != f:
            return apart(fc, x=x, full=full, **_options)
        raise NotImplementedError('multivariate partial fraction decomposition')
    common, P, Q = P.cancel(Q)
    poly, P = P.div(Q, auto=True)
    P, Q = P.rat_clear_denoms(Q)
    if Q.degree() <= 1:
        partial = P / Q
    elif not full:
        partial = apart_undetermined_coeffs(P, Q)
    else:
        partial = apart_full_decomposition(P, Q)
    terms = S.Zero
    for term in Add.make_args(partial):
        if term.has(RootSum):
            terms += term
        else:
            terms += factor(term)
    return common * (poly.as_expr() + terms)

def apart_undetermined_coeffs(P, Q):
    X = numbered_symbols(cls=Dummy)
    partial, symbols = ([], [])
    _, factors = Q.factor_list()
    for f, k in factors:
        n, q = (f.degree(), Q)
        for i in range(1, k + 1):
            coeffs, q = (take(X, n), q.quo(f))
            partial.append((coeffs, q, f, i))
            symbols.extend(coeffs)
    dom = Q.get_domain().inject(*symbols)
    F = Poly(0, Q.gen, domain=dom)
    for i, (coeffs, q, f, k) in enumerate(partial):
        h = Poly(coeffs, Q.gen, domain=dom)
        partial[i] = (h, f, k)
        q = q.set_domain(dom)
        F += h * q
    system, result = ([], S.Zero)
    for (k,), coeff in F.terms():
        system.append(coeff - P.nth(k))
    from sympy.solvers import solve
    solution = solve(system, symbols)
    for h, f, k in partial:
        h = h.as_expr().subs(solution)
        result += h / f.as_expr() ** k
    return result

def apart_full_decomposition(P, Q):
    return assemble_partfrac_list(apart_list(P / Q, P.gens[0]))

@public
def apart_list(f, x=None, dummies=None, **options):
    allowed_flags(options, [])
    f = sympify(f)
    if f.is_Atom:
        return f
    else:
        P, Q = f.as_numer_denom()
    options = set_defaults(options, extension=True)
    (P, Q), opt = parallel_poly_from_expr((P, Q), x, **options)
    if P.is_multivariate:
        raise NotImplementedError('multivariate partial fraction decomposition')
    common, P, Q = P.cancel(Q)
    poly, P = P.div(Q, auto=True)
    P, Q = P.rat_clear_denoms(Q)
    polypart = poly
    if dummies is None:

        def dummies(name):
            d = Dummy(name)
            while True:
                yield d
        dummies = dummies('w')
    rationalpart = apart_list_full_decomposition(P, Q, dummies)
    return (common, polypart, rationalpart)

def apart_list_full_decomposition(P, Q, dummygen):
    P_orig, Q_orig, x, U = (P, Q, P.gen, [])
    u = Function('u')(x)
    a = Dummy('a')
    partial = []
    for d, n in Q.sqf_list_include(all=True):
        b = d.as_expr()
        U += [u.diff(x, n - 1)]
        h = cancel(P_orig / Q_orig.quo(d ** n)) / u ** n
        H, subs = ([h], [])
        for j in range(1, n):
            H += [H[-1].diff(x) / j]
        for j in range(1, n + 1):
            subs += [(U[j - 1], b.diff(x, j) / j)]
        for j in range(0, n):
            P, Q = cancel(H[j]).as_numer_denom()
            for i in range(0, j + 1):
                P = P.subs(*subs[j - i])
            Q = Q.subs(*subs[0])
            P = Poly(P, x)
            Q = Poly(Q, x)
            G = P.gcd(d)
            D = d.quo(G)
            B, g = Q.half_gcdex(D)
            b = (P * B.quo(g)).rem(D)
            Dw = D.subs(x, next(dummygen))
            numer = Lambda(a, b.as_expr().subs(x, a))
            denom = Lambda(a, x - a)
            exponent = n - j
            partial.append((Dw, numer, denom, exponent))
    return partial

@public
def assemble_partfrac_list(partial_list):
    common = partial_list[0]
    polypart = partial_list[1]
    pfd = polypart.as_expr()
    for r, nf, df, ex in partial_list[2]:
        if isinstance(r, Poly):
            an, nu = (nf.variables, nf.expr)
            ad, de = (df.variables, df.expr)
            de = de.subs(ad[0], an[0])
            func = Lambda(tuple(an), nu / de ** ex)
            pfd += RootSum(r, func, auto=False, quadratic=False)
        else:
            for root in r:
                pfd += nf(root) / df(root) ** ex
    return common * pfd