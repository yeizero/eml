from __future__ import annotations
from sympy.polys.densearith import dup_mul_ground, dup_sub_ground, dup_exquo_ground
from sympy.polys.densetools import dup_eval, dup_integrate
from sympy.polys.domains import ZZ, QQ
from sympy.polys.polytools import named_poly
from sympy.utilities import public

def dup_bernoulli(n, K):
    if n < 1:
        return [K.one]
    p = [K.one, K(-1, 2)]
    for i in range(2, n + 1):
        p = dup_integrate(dup_mul_ground(p, K(i), K), 1, K)
        if i % 2 == 0:
            p = dup_sub_ground(p, dup_eval(p, K(1, 2), K) * K(1 << i - 1, (1 << i) - 1), K)
    return p

@public
def bernoulli_poly(n, x=None, polys=False):
    return named_poly(n, dup_bernoulli, QQ, 'Bernoulli polynomial', (x,), polys)

def dup_bernoulli_c(n, K):
    p = [K.one]
    for i in range(1, n + 1):
        p = dup_integrate(dup_mul_ground(p, K(i), K), 1, K)
        if i % 2 == 0:
            p = dup_sub_ground(p, dup_eval(p, K.one, K) * K((1 << i - 1) - 1, (1 << i) - 1), K)
    return p

@public
def bernoulli_c_poly(n, x=None, polys=False):
    return named_poly(n, dup_bernoulli_c, QQ, 'central Bernoulli polynomial', (x,), polys)

def dup_genocchi(n, K):
    if n < 1:
        return [K.zero]
    p = [-K.one]
    for i in range(2, n + 1):
        p = dup_integrate(dup_mul_ground(p, K(i), K), 1, K)
        if i % 2 == 0:
            p = dup_sub_ground(p, dup_eval(p, K.one, K) // K(2), K)
    return p

@public
def genocchi_poly(n, x=None, polys=False):
    return named_poly(n, dup_genocchi, ZZ, 'Genocchi polynomial', (x,), polys)

def dup_euler(n, K):
    return dup_exquo_ground(dup_genocchi(n + 1, ZZ), K(-n - 1), K)

@public
def euler_poly(n, x=None, polys=False):
    return named_poly(n, dup_euler, QQ, 'Euler polynomial', (x,), polys)

def dup_andre(n, K):
    p = [K.one]
    for i in range(1, n + 1):
        p = dup_integrate(dup_mul_ground(p, K(i), K), 1, K)
        if i % 2 == 0:
            p = dup_sub_ground(p, dup_eval(p, K.one, K), K)
    return p

@public
def andre_poly(n, x=None, polys=False):
    return named_poly(n, dup_andre, ZZ, 'Andre polynomial', (x,), polys)