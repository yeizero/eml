from __future__ import annotations
from sympy.polys.polyerrors import CoercionFailed
from sympy.polys.polyutils import IntegerPowerable

class Ideal(IntegerPowerable):

    def _contains_elem(self, x):
        raise NotImplementedError

    def _contains_ideal(self, I):
        raise NotImplementedError

    def _quotient(self, J):
        raise NotImplementedError

    def _intersect(self, J):
        raise NotImplementedError

    def is_whole_ring(self):
        raise NotImplementedError

    def is_zero(self):
        raise NotImplementedError

    def _equals(self, J):
        return self._contains_ideal(J) and J._contains_ideal(self)

    def is_prime(self):
        raise NotImplementedError

    def is_maximal(self):
        raise NotImplementedError

    def is_radical(self):
        raise NotImplementedError

    def is_primary(self):
        raise NotImplementedError

    def is_principal(self):
        raise NotImplementedError

    def radical(self):
        raise NotImplementedError

    def depth(self):
        raise NotImplementedError

    def height(self):
        raise NotImplementedError

    def __init__(self, ring):
        self.ring = ring

    def _check_ideal(self, J):
        if not isinstance(J, Ideal) or J.ring != self.ring:
            raise ValueError('J must be an ideal of %s, got %s' % (self.ring, J))

    def contains(self, elem):
        return self._contains_elem(self.ring.convert(elem))

    def subset(self, other):
        if isinstance(other, Ideal):
            return self._contains_ideal(other)
        return all((self._contains_elem(x) for x in other))

    def quotient(self, J, **opts):
        self._check_ideal(J)
        return self._quotient(J, **opts)

    def intersect(self, J):
        self._check_ideal(J)
        return self._intersect(J)

    def saturate(self, J):
        raise NotImplementedError

    def union(self, J):
        self._check_ideal(J)
        return self._union(J)

    def product(self, J):
        self._check_ideal(J)
        return self._product(J)

    def reduce_element(self, x):
        return x

    def __add__(self, e):
        if not isinstance(e, Ideal):
            R = self.ring.quotient_ring(self)
            if isinstance(e, R.dtype):
                return e
            if isinstance(e, R.ring.dtype):
                return R(e)
            return R.convert(e)
        self._check_ideal(e)
        return self.union(e)
    __radd__ = __add__

    def __mul__(self, e):
        if not isinstance(e, Ideal):
            try:
                e = self.ring.ideal(e)
            except CoercionFailed:
                return NotImplemented
        self._check_ideal(e)
        return self.product(e)
    __rmul__ = __mul__

    def _zeroth_power(self):
        return self.ring.ideal(1)

    def _first_power(self):
        return self * 1

    def __eq__(self, e):
        if not isinstance(e, Ideal) or e.ring != self.ring:
            return False
        return self._equals(e)

    def __ne__(self, e):
        return not self == e

class ModuleImplementedIdeal(Ideal):

    def __init__(self, ring, module):
        Ideal.__init__(self, ring)
        self._module = module

    def _contains_elem(self, x):
        return self._module.contains([x])

    def _contains_ideal(self, J):
        if not isinstance(J, ModuleImplementedIdeal):
            raise NotImplementedError
        return self._module.is_submodule(J._module)

    def _intersect(self, J):
        if not isinstance(J, ModuleImplementedIdeal):
            raise NotImplementedError
        return self.__class__(self.ring, self._module.intersect(J._module))

    def _quotient(self, J, **opts):
        if not isinstance(J, ModuleImplementedIdeal):
            raise NotImplementedError
        return self._module.module_quotient(J._module, **opts)

    def _union(self, J):
        if not isinstance(J, ModuleImplementedIdeal):
            raise NotImplementedError
        return self.__class__(self.ring, self._module.union(J._module))

    @property
    def gens(self):
        return (x[0] for x in self._module.gens)

    def is_zero(self):
        return self._module.is_zero()

    def is_whole_ring(self):
        return self._module.is_full_module()

    def __repr__(self):
        from sympy.printing.str import sstr
        gens = [self.ring.to_sympy(x) for [x] in self._module.gens]
        return '<' + ','.join((sstr(g) for g in gens)) + '>'

    def _product(self, J):
        if not isinstance(J, ModuleImplementedIdeal):
            raise NotImplementedError
        return self.__class__(self.ring, self._module.submodule(*[[x * y] for [x] in self._module.gens for [y] in J._module.gens]))

    def in_terms_of_generators(self, e):
        return self._module.in_terms_of_generators([e])

    def reduce_element(self, x, **options):
        return self._module.reduce_element([x], **options)[0]