from __future__ import annotations
from sympy.polys.agca.modules import Module, FreeModule, QuotientModule, SubModule, SubQuotientModule
from sympy.polys.polyerrors import CoercionFailed

class ModuleHomomorphism:

    def __init__(self, domain, codomain):
        if not isinstance(domain, Module):
            raise TypeError('Source must be a module, got %s' % domain)
        if not isinstance(codomain, Module):
            raise TypeError('Target must be a module, got %s' % codomain)
        if domain.ring != codomain.ring:
            raise ValueError('Source and codomain must be over same ring, got %s != %s' % (domain, codomain))
        self.domain = domain
        self.codomain = codomain
        self.ring = domain.ring
        self._ker = None
        self._img = None

    def kernel(self):
        if self._ker is None:
            self._ker = self._kernel()
        return self._ker

    def image(self):
        if self._img is None:
            self._img = self._image()
        return self._img

    def _kernel(self):
        raise NotImplementedError

    def _image(self):
        raise NotImplementedError

    def _restrict_domain(self, sm):
        raise NotImplementedError

    def _restrict_codomain(self, sm):
        raise NotImplementedError

    def _quotient_domain(self, sm):
        raise NotImplementedError

    def _quotient_codomain(self, sm):
        raise NotImplementedError

    def restrict_domain(self, sm):
        if not self.domain.is_submodule(sm):
            raise ValueError('sm must be a submodule of %s, got %s' % (self.domain, sm))
        if sm == self.domain:
            return self
        return self._restrict_domain(sm)

    def restrict_codomain(self, sm):
        if not sm.is_submodule(self.image()):
            raise ValueError('the image %s must contain sm, got %s' % (self.image(), sm))
        if sm == self.codomain:
            return self
        return self._restrict_codomain(sm)

    def quotient_domain(self, sm):
        if not self.kernel().is_submodule(sm):
            raise ValueError('kernel %s must contain sm, got %s' % (self.kernel(), sm))
        if sm.is_zero():
            return self
        return self._quotient_domain(sm)

    def quotient_codomain(self, sm):
        if not self.codomain.is_submodule(sm):
            raise ValueError('sm must be a submodule of codomain %s, got %s' % (self.codomain, sm))
        if sm.is_zero():
            return self
        return self._quotient_codomain(sm)

    def _apply(self, elem):
        raise NotImplementedError

    def __call__(self, elem):
        return self.codomain.convert(self._apply(self.domain.convert(elem)))

    def _compose(self, oth):
        raise NotImplementedError

    def _mul_scalar(self, c):
        raise NotImplementedError

    def _add(self, oth):
        raise NotImplementedError

    def _check_hom(self, oth):
        if not isinstance(oth, ModuleHomomorphism):
            return False
        return oth.domain == self.domain and oth.codomain == self.codomain

    def __mul__(self, oth):
        if isinstance(oth, ModuleHomomorphism) and self.domain == oth.codomain:
            return oth._compose(self)
        try:
            return self._mul_scalar(self.ring.convert(oth))
        except CoercionFailed:
            return NotImplemented
    __rmul__ = __mul__

    def __truediv__(self, oth):
        try:
            return self._mul_scalar(1 / self.ring.convert(oth))
        except CoercionFailed:
            return NotImplemented

    def __add__(self, oth):
        if self._check_hom(oth):
            return self._add(oth)
        return NotImplemented

    def __sub__(self, oth):
        if self._check_hom(oth):
            return self._add(oth._mul_scalar(self.ring.convert(-1)))
        return NotImplemented

    def is_injective(self):
        return self.kernel().is_zero()

    def is_surjective(self):
        return self.image() == self.codomain

    def is_isomorphism(self):
        return self.is_injective() and self.is_surjective()

    def is_zero(self):
        return self.image().is_zero()

    def __eq__(self, oth):
        try:
            return (self - oth).is_zero()
        except TypeError:
            return False

    def __ne__(self, oth):
        return not self == oth

class MatrixHomomorphism(ModuleHomomorphism):

    def __init__(self, domain, codomain, matrix):
        ModuleHomomorphism.__init__(self, domain, codomain)
        if len(matrix) != domain.rank:
            raise ValueError('Need to provide %s elements, got %s' % (domain.rank, len(matrix)))
        converter = self.codomain.convert
        if isinstance(self.codomain, (SubModule, SubQuotientModule)):
            converter = self.codomain.container.convert
        self.matrix = tuple((converter(x) for x in matrix))

    def _sympy_matrix(self):
        from sympy.matrices import Matrix
        c = lambda x: x
        if isinstance(self.codomain, (QuotientModule, SubQuotientModule)):
            c = lambda x: x.data
        return Matrix([[self.ring.to_sympy(y) for y in c(x)] for x in self.matrix]).T

    def __repr__(self):
        lines = repr(self._sympy_matrix()).split('\n')
        t = ' : %s -> %s' % (self.domain, self.codomain)
        s = ' ' * len(t)
        n = len(lines)
        for i in range(n // 2):
            lines[i] += s
        lines[n // 2] += t
        for i in range(n // 2 + 1, n):
            lines[i] += s
        return '\n'.join(lines)

    def _restrict_domain(self, sm):
        return SubModuleHomomorphism(sm, self.codomain, self.matrix)

    def _restrict_codomain(self, sm):
        return self.__class__(self.domain, sm, self.matrix)

    def _quotient_domain(self, sm):
        return self.__class__(self.domain / sm, self.codomain, self.matrix)

    def _quotient_codomain(self, sm):
        Q = self.codomain / sm
        converter = Q.convert
        if isinstance(self.codomain, SubModule):
            converter = Q.container.convert
        return self.__class__(self.domain, self.codomain / sm, [converter(x) for x in self.matrix])

    def _add(self, oth):
        return self.__class__(self.domain, self.codomain, [x + y for x, y in zip(self.matrix, oth.matrix)])

    def _mul_scalar(self, c):
        return self.__class__(self.domain, self.codomain, [c * x for x in self.matrix])

    def _compose(self, oth):
        return self.__class__(self.domain, oth.codomain, [oth(x) for x in self.matrix])

class FreeModuleHomomorphism(MatrixHomomorphism):

    def _apply(self, elem):
        if isinstance(self.domain, QuotientModule):
            elem = elem.data
        return sum((x * e for x, e in zip(elem, self.matrix)))

    def _image(self):
        return self.codomain.submodule(*self.matrix)

    def _kernel(self):
        syz = self.image().syzygy_module()
        return self.domain.submodule(*syz.gens)

class SubModuleHomomorphism(MatrixHomomorphism):

    def _apply(self, elem):
        if isinstance(self.domain, SubQuotientModule):
            elem = elem.data
        return sum((x * e for x, e in zip(elem, self.matrix)))

    def _image(self):
        return self.codomain.submodule(*[self(x) for x in self.domain.gens])

    def _kernel(self):
        syz = self.image().syzygy_module()
        return self.domain.submodule(*[sum((xi * gi for xi, gi in zip(s, self.domain.gens))) for s in syz.gens])

def homomorphism(domain, codomain, matrix):

    def freepres(module):
        if isinstance(module, FreeModule):
            return (module, module, module.submodule(), lambda x: module.convert(x))
        if isinstance(module, QuotientModule):
            return (module.base, module.base, module.killed_module, lambda x: module.convert(x).data)
        if isinstance(module, SubQuotientModule):
            return (module.base.container, module.base, module.killed_module, lambda x: module.container.convert(x).data)
        return (module.container, module, module.submodule(), lambda x: module.container.convert(x))
    SF, SS, SQ, _ = freepres(domain)
    TF, TS, TQ, c = freepres(codomain)
    return FreeModuleHomomorphism(SF, TF, [c(x) for x in matrix]).restrict_domain(SS).restrict_codomain(TS).quotient_codomain(TQ).quotient_domain(SQ)