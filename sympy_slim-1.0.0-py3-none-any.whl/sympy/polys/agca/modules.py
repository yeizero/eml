from __future__ import annotations
from copy import copy
from functools import reduce
from sympy.polys.agca.ideals import Ideal
from sympy.polys.domains.field import Field
from sympy.polys.orderings import ProductOrder, monomial_key
from sympy.polys.polyclasses import DMP
from sympy.polys.polyerrors import CoercionFailed
from sympy.core.basic import _aresame
from sympy.utilities.iterables import iterable

class Module:

    def __init__(self, ring):
        self.ring = ring

    def convert(self, elem, M=None):
        if not isinstance(elem, self.dtype):
            raise CoercionFailed
        return elem

    def submodule(self, *gens):
        raise NotImplementedError

    def quotient_module(self, other):
        raise NotImplementedError

    def __truediv__(self, e):
        if not isinstance(e, Module):
            e = self.submodule(*e)
        return self.quotient_module(e)

    def contains(self, elem):
        try:
            self.convert(elem)
            return True
        except CoercionFailed:
            return False

    def __contains__(self, elem):
        return self.contains(elem)

    def subset(self, other):
        return all((self.contains(x) for x in other))

    def __eq__(self, other):
        return self.is_submodule(other) and other.is_submodule(self)

    def __ne__(self, other):
        return not self == other

    def is_zero(self):
        raise NotImplementedError

    def is_submodule(self, other):
        raise NotImplementedError

    def multiply_ideal(self, other):
        raise NotImplementedError

    def __mul__(self, e):
        if not isinstance(e, Ideal):
            try:
                e = self.ring.ideal(e)
            except (CoercionFailed, NotImplementedError):
                return NotImplemented
        return self.multiply_ideal(e)
    __rmul__ = __mul__

    def identity_hom(self):
        raise NotImplementedError

class ModuleElement:

    def __init__(self, module, data):
        self.module = module
        self.data = data

    def add(self, d1, d2):
        return d1 + d2

    def mul(self, m, d):
        return m * d

    def div(self, m, d):
        return m / d

    def eq(self, d1, d2):
        return d1 == d2

    def __add__(self, om):
        if not isinstance(om, self.__class__) or om.module != self.module:
            try:
                om = self.module.convert(om)
            except CoercionFailed:
                return NotImplemented
        return self.__class__(self.module, self.add(self.data, om.data))
    __radd__ = __add__

    def __neg__(self):
        return self.__class__(self.module, self.mul(self.data, self.module.ring.convert(-1)))

    def __sub__(self, om):
        if not isinstance(om, self.__class__) or om.module != self.module:
            try:
                om = self.module.convert(om)
            except CoercionFailed:
                return NotImplemented
        return self.__add__(-om)

    def __rsub__(self, om):
        return (-self).__add__(om)

    def __mul__(self, o):
        if not isinstance(o, self.module.ring.dtype):
            try:
                o = self.module.ring.convert(o)
            except CoercionFailed:
                return NotImplemented
        return self.__class__(self.module, self.mul(self.data, o))
    __rmul__ = __mul__

    def __truediv__(self, o):
        if not isinstance(o, self.module.ring.dtype):
            try:
                o = self.module.ring.convert(o)
            except CoercionFailed:
                return NotImplemented
        return self.__class__(self.module, self.div(self.data, o))

    def __eq__(self, om):
        if not isinstance(om, self.__class__) or om.module != self.module:
            try:
                om = self.module.convert(om)
            except CoercionFailed:
                return False
        return self.eq(self.data, om.data)

    def __ne__(self, om):
        return not self == om

class FreeModuleElement(ModuleElement):

    def add(self, d1, d2):
        return tuple((x + y for x, y in zip(d1, d2)))

    def mul(self, d, p):
        return tuple((x * p for x in d))

    def div(self, d, p):
        return tuple((x / p for x in d))

    def __repr__(self):
        from sympy.printing.str import sstr
        data = self.data
        if any((isinstance(x, DMP) for x in data)):
            data = [self.module.ring.to_sympy(x) for x in data]
        return '[' + ', '.join((sstr(x) for x in data)) + ']'

    def __iter__(self):
        return self.data.__iter__()

    def __getitem__(self, idx):
        return self.data[idx]

class FreeModule(Module):
    dtype = FreeModuleElement

    def __init__(self, ring, rank):
        Module.__init__(self, ring)
        self.rank = rank

    def __repr__(self):
        return repr(self.ring) + '**' + repr(self.rank)

    def is_submodule(self, other):
        if isinstance(other, SubModule):
            return other.container == self
        if isinstance(other, FreeModule):
            return other.ring == self.ring and other.rank == self.rank
        return False

    def convert(self, elem, M=None):
        if isinstance(elem, FreeModuleElement):
            if elem.module is self:
                return elem
            if elem.module.rank != self.rank:
                raise CoercionFailed
            return FreeModuleElement(self, tuple((self.ring.convert(x, elem.module.ring) for x in elem.data)))
        elif iterable(elem):
            tpl = tuple((self.ring.convert(x) for x in elem))
            if len(tpl) != self.rank:
                raise CoercionFailed
            return FreeModuleElement(self, tpl)
        elif _aresame(elem, 0):
            return FreeModuleElement(self, (self.ring.convert(0),) * self.rank)
        else:
            raise CoercionFailed

    def is_zero(self):
        return self.rank == 0

    def basis(self):
        from sympy.matrices import eye
        M = eye(self.rank)
        return tuple((self.convert(M.row(i)) for i in range(self.rank)))

    def quotient_module(self, submodule):
        return QuotientModule(self.ring, self, submodule)

    def multiply_ideal(self, other):
        return self.submodule(*self.basis()).multiply_ideal(other)

    def identity_hom(self):
        from sympy.polys.agca.homomorphisms import homomorphism
        return homomorphism(self, self, self.basis())

class FreeModulePolyRing(FreeModule):

    def __init__(self, ring, rank):
        from sympy.polys.domains.old_polynomialring import PolynomialRingBase
        FreeModule.__init__(self, ring, rank)
        if not isinstance(ring, PolynomialRingBase):
            raise NotImplementedError('This implementation only works over ' + 'polynomial rings, got %s' % ring)
        if not isinstance(ring.dom, Field):
            raise NotImplementedError('Ground domain must be a field, ' + 'got %s' % ring.dom)

    def submodule(self, *gens, **opts):
        return SubModulePolyRing(gens, self, **opts)

class FreeModuleQuotientRing(FreeModule):

    def __init__(self, ring, rank):
        from sympy.polys.domains.quotientring import QuotientRing
        FreeModule.__init__(self, ring, rank)
        if not isinstance(ring, QuotientRing):
            raise NotImplementedError('This implementation only works over ' + 'quotient rings, got %s' % ring)
        F = self.ring.ring.free_module(self.rank)
        self.quot = F / (self.ring.base_ideal * F)

    def __repr__(self):
        return '(' + repr(self.ring) + ')' + '**' + repr(self.rank)

    def submodule(self, *gens, **opts):
        return SubModuleQuotientRing(gens, self, **opts)

    def lift(self, elem):
        return self.quot.convert([x.data for x in elem])

    def unlift(self, elem):
        return self.convert(elem.data)

class SubModule(Module):

    def __init__(self, gens, container):
        Module.__init__(self, container.ring)
        self.gens = tuple((container.convert(x) for x in gens))
        self.container = container
        self.rank = container.rank
        self.ring = container.ring
        self.dtype = container.dtype

    def __repr__(self):
        return '<' + ', '.join((repr(x) for x in self.gens)) + '>'

    def _contains(self, other):
        raise NotImplementedError

    def _syzygies(self):
        raise NotImplementedError

    def _in_terms_of_generators(self, e):
        raise NotImplementedError

    def convert(self, elem, M=None):
        if isinstance(elem, self.container.dtype) and elem.module is self:
            return elem
        r = copy(self.container.convert(elem, M))
        r.module = self
        if not self._contains(r):
            raise CoercionFailed
        return r

    def _intersect(self, other):
        raise NotImplementedError

    def _module_quotient(self, other):
        raise NotImplementedError

    def intersect(self, other, **options):
        if not isinstance(other, SubModule):
            raise TypeError('%s is not a SubModule' % other)
        if other.container != self.container:
            raise ValueError('%s is contained in a different free module' % other)
        return self._intersect(other, **options)

    def module_quotient(self, other, **options):
        if not isinstance(other, SubModule):
            raise TypeError('%s is not a SubModule' % other)
        if other.container != self.container:
            raise ValueError('%s is contained in a different free module' % other)
        return self._module_quotient(other, **options)

    def union(self, other):
        if not isinstance(other, SubModule):
            raise TypeError('%s is not a SubModule' % other)
        if other.container != self.container:
            raise ValueError('%s is contained in a different free module' % other)
        return self.__class__(self.gens + other.gens, self.container)

    def is_zero(self):
        return all((x == 0 for x in self.gens))

    def submodule(self, *gens):
        if not self.subset(gens):
            raise ValueError('%s not a subset of %s' % (gens, self))
        return self.__class__(gens, self.container)

    def is_full_module(self):
        return all((self.contains(x) for x in self.container.basis()))

    def is_submodule(self, other):
        if isinstance(other, SubModule):
            return self.container == other.container and all((self.contains(x) for x in other.gens))
        if isinstance(other, (FreeModule, QuotientModule)):
            return self.container == other and self.is_full_module()
        return False

    def syzygy_module(self, **opts):
        F = self.ring.free_module(len(self.gens))
        return F.submodule(*[x for x in self._syzygies() if F.convert(x) != 0], **opts)

    def in_terms_of_generators(self, e):
        try:
            e = self.convert(e)
        except CoercionFailed:
            raise ValueError('%s is not an element of %s' % (e, self))
        return self._in_terms_of_generators(e)

    def reduce_element(self, x):
        return x

    def quotient_module(self, other, **opts):
        if not self.is_submodule(other):
            raise ValueError('%s not a submodule of %s' % (other, self))
        return SubQuotientModule(self.gens, self.container.quotient_module(other), **opts)

    def __add__(self, oth):
        return self.container.quotient_module(self).convert(oth)
    __radd__ = __add__

    def multiply_ideal(self, I):
        return self.submodule(*[x * g for [x] in I._module.gens for g in self.gens])

    def inclusion_hom(self):
        return self.container.identity_hom().restrict_domain(self)

    def identity_hom(self):
        return self.container.identity_hom().restrict_domain(self).restrict_codomain(self)

class SubQuotientModule(SubModule):

    def __init__(self, gens, container, **opts):
        SubModule.__init__(self, gens, container)
        self.killed_module = self.container.killed_module
        self.base = self.container.base.submodule(*[x.data for x in self.gens], **opts).union(self.killed_module)

    def _contains(self, elem):
        return self.base.contains(elem.data)

    def _syzygies(self):
        return [X[:len(self.gens)] for X in self.base._syzygies()]

    def _in_terms_of_generators(self, e):
        return self.base._in_terms_of_generators(e.data)[:len(self.gens)]

    def is_full_module(self):
        return self.base.is_full_module()

    def quotient_hom(self):
        return self.base.identity_hom().quotient_codomain(self.killed_module)
_subs0 = lambda x: x[0]
_subs1 = lambda x: x[1:]

class ModuleOrder(ProductOrder):

    def __init__(self, o1, o2, TOP):
        if TOP:
            ProductOrder.__init__(self, (o2, _subs1), (o1, _subs0))
        else:
            ProductOrder.__init__(self, (o1, _subs0), (o2, _subs1))

class SubModulePolyRing(SubModule):

    def __init__(self, gens, container, order='lex', TOP=True):
        SubModule.__init__(self, gens, container)
        if not isinstance(container, FreeModulePolyRing):
            raise NotImplementedError('This implementation is for submodules of ' + 'FreeModulePolyRing, got %s' % container)
        self.order = ModuleOrder(monomial_key(order), self.ring.order, TOP)
        self._gb = None
        self._gbe = None

    def __eq__(self, other):
        if isinstance(other, SubModulePolyRing) and self.order != other.order:
            return False
        return SubModule.__eq__(self, other)

    def _groebner(self, extended=False):
        from sympy.polys.distributedmodules import sdm_groebner, sdm_nf_mora
        if self._gbe is None and extended:
            gb, gbe = sdm_groebner([self.ring._vector_to_sdm(x, self.order) for x in self.gens], sdm_nf_mora, self.order, self.ring.dom, extended=True)
            self._gb, self._gbe = (tuple(gb), tuple(gbe))
        if self._gb is None:
            self._gb = tuple(sdm_groebner([self.ring._vector_to_sdm(x, self.order) for x in self.gens], sdm_nf_mora, self.order, self.ring.dom))
        if extended:
            return (self._gb, self._gbe)
        else:
            return self._gb

    def _groebner_vec(self, extended=False):
        if not extended:
            return [FreeModuleElement(self, tuple(self.ring._sdm_to_vector(x, self.rank))) for x in self._groebner()]
        gb, gbe = self._groebner(extended=True)
        return ([self.convert(self.ring._sdm_to_vector(x, self.rank)) for x in gb], [self.ring._sdm_to_vector(x, len(self.gens)) for x in gbe])

    def _contains(self, x):
        from sympy.polys.distributedmodules import sdm_zero, sdm_nf_mora
        return sdm_nf_mora(self.ring._vector_to_sdm(x, self.order), self._groebner(), self.order, self.ring.dom) == sdm_zero()

    def _syzygies(self):
        k = len(self.gens)
        r = self.rank
        zero = self.ring.convert(0)
        one = self.ring.convert(1)
        Rkr = self.ring.free_module(r + k)
        newgens = []
        for j, f in enumerate(self.gens):
            m = [0] * (r + k)
            for i, v in enumerate(f):
                m[i] = v
            for i in range(k):
                m[r + i] = one if j == i else zero
            m = FreeModuleElement(Rkr, tuple(m))
            newgens.append(m)
        F = Rkr.submodule(*newgens, order='ilex', TOP=False)
        G = F._groebner_vec()
        G0 = [x[r:] for x in G if all((y == zero for y in x[:r]))]
        return G0

    def _in_terms_of_generators(self, e):
        M = self.ring.free_module(self.rank).submodule(*(e,) + self.gens)
        S = M.syzygy_module(order='ilex', TOP=False)
        G = S._groebner_vec()
        e = [x for x in G if self.ring.is_unit(x[0])][0]
        return [-x / e[0] for x in e[1:]]

    def reduce_element(self, x, NF=None):
        from sympy.polys.distributedmodules import sdm_nf_mora
        if NF is None:
            NF = sdm_nf_mora
        return self.container.convert(self.ring._sdm_to_vector(NF(self.ring._vector_to_sdm(x, self.order), self._groebner(), self.order, self.ring.dom), self.rank))

    def _intersect(self, other, relations=False):
        fi = self.gens
        hi = other.gens
        r = self.rank
        ci = [[0] * (2 * r) for _ in range(r)]
        for k in range(r):
            ci[k][k] = 1
            ci[k][r + k] = 1
        di = [list(f) + [0] * r for f in fi]
        ei = [[0] * r + list(h) for h in hi]
        syz = self.ring.free_module(2 * r).submodule(*ci + di + ei)._syzygies()
        nonzero = [x for x in syz if any((y != self.ring.zero for y in x[:r]))]
        res = self.container.submodule(*([-y for y in x[:r]] for x in nonzero))
        reln1 = [x[r:r + len(fi)] for x in nonzero]
        reln2 = [x[r + len(fi):] for x in nonzero]
        if relations:
            return (res, reln1, reln2)
        return res

    def _module_quotient(self, other, relations=False):
        if relations and len(other.gens) != 1:
            raise NotImplementedError
        if len(other.gens) == 0:
            return self.ring.ideal(1)
        elif len(other.gens) == 1:
            g1 = list(other.gens[0]) + [1]
            gi = [list(x) + [0] for x in self.gens]
            M = self.ring.free_module(self.rank + 1).submodule(*[g1] + gi, order='ilex', TOP=False)
            if not relations:
                return self.ring.ideal(*[x[-1] for x in M._groebner_vec() if all((y == self.ring.zero for y in x[:-1]))])
            else:
                G, R = M._groebner_vec(extended=True)
                indices = [i for i, x in enumerate(G) if all((y == self.ring.zero for y in x[:-1]))]
                return (self.ring.ideal(*[G[i][-1] for i in indices]), [[-x for x in R[i][1:]] for i in indices])
        return reduce(lambda x, y: x.intersect(y), (self._module_quotient(self.container.submodule(x)) for x in other.gens))

class SubModuleQuotientRing(SubModule):

    def __init__(self, gens, container):
        SubModule.__init__(self, gens, container)
        self.quot = self.container.quot.submodule(*[self.container.lift(x) for x in self.gens])

    def _contains(self, elem):
        return self.quot._contains(self.container.lift(elem))

    def _syzygies(self):
        return [tuple((self.ring.convert(y, self.quot.ring) for y in x)) for x in self.quot._syzygies()]

    def _in_terms_of_generators(self, elem):
        return [self.ring.convert(x, self.quot.ring) for x in self.quot._in_terms_of_generators(self.container.lift(elem))]

class QuotientModuleElement(ModuleElement):

    def eq(self, d1, d2):
        return self.module.killed_module.contains(d1 - d2)

    def __repr__(self):
        return repr(self.data) + ' + ' + repr(self.module.killed_module)

class QuotientModule(Module):
    dtype = QuotientModuleElement

    def __init__(self, ring, base, submodule):
        Module.__init__(self, ring)
        if not base.is_submodule(submodule):
            raise ValueError('%s is not a submodule of %s' % (submodule, base))
        self.base = base
        self.killed_module = submodule
        self.rank = base.rank

    def __repr__(self):
        return repr(self.base) + '/' + repr(self.killed_module)

    def is_zero(self):
        return self.base == self.killed_module

    def is_submodule(self, other):
        if isinstance(other, QuotientModule):
            return self.killed_module == other.killed_module and self.base.is_submodule(other.base)
        if isinstance(other, SubQuotientModule):
            return other.container == self
        return False

    def submodule(self, *gens, **opts):
        return SubQuotientModule(gens, self, **opts)

    def convert(self, elem, M=None):
        if isinstance(elem, QuotientModuleElement):
            if elem.module is self:
                return elem
            if self.killed_module.is_submodule(elem.module.killed_module):
                return QuotientModuleElement(self, self.base.convert(elem.data))
            raise CoercionFailed
        return QuotientModuleElement(self, self.base.convert(elem))

    def identity_hom(self):
        return self.base.identity_hom().quotient_codomain(self.killed_module).quotient_domain(self.killed_module)

    def quotient_hom(self):
        return self.base.identity_hom().quotient_codomain(self.killed_module)