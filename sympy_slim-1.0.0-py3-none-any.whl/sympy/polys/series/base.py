from __future__ import annotations
from typing import Protocol, Sequence, TypeVar, TYPE_CHECKING
from sympy.polys.domains.domain import Ef, Er
from sympy.polys.densebasic import dup, dup_pretty
if TYPE_CHECKING:
    from sympy.polys.domains import Domain
TSeries = TypeVar('TSeries')

def series_pprint(series: dup[Er], prec: int | None, *, sym: str='x', ascending: bool=True) -> str:
    if prec == 0:
        return f'O({sym}**{prec})'
    poly = dup_pretty(series, sym, ascending=ascending)
    if not poly or poly == '0':
        if prec is not None:
            return f'O({sym}**{prec})'
        else:
            return '0'
    if prec is not None:
        return f'{poly} + O({sym}**{prec})'
    return poly

class PowerSeriesRingProto(Protocol[TSeries, Er]):

    def __init__(self, prec: int=6, /) -> None:
        pass

    def __repr__(self, /) -> str:
        pass

    def __call__(self, coeffs: Sequence[Er | int], prec: int | None=None) -> TSeries:
        pass

    @property
    def domain(self, /) -> Domain[Er]:
        pass

    @property
    def prec(self, /) -> int:
        pass

    @property
    def one(self, /) -> TSeries:
        pass

    @property
    def zero(self, /) -> TSeries:
        pass

    @property
    def gen(self, /) -> TSeries:
        pass

    def pretty(self, s: TSeries, /, *, symbol: str='x', ascending: bool=True) -> str:
        pass

    def print(self, s: TSeries, /, *, symbol: str='x', ascending: bool=True) -> None:
        pass

    def from_list(self, coeffs: list[Er], prec: int | None=None, /) -> TSeries:
        pass

    def from_element(self, s: TSeries, /) -> TSeries:
        pass

    def to_list(self, s: TSeries, /) -> list[Er]:
        pass

    def to_dense(self, s: TSeries, /) -> dup[Er]:
        pass

    def series_prec(self, s: TSeries, /) -> int | None:
        pass

    def equal(self, s1: TSeries, s2: TSeries, /) -> bool | None:
        pass

    def equal_repr(self, s1: TSeries, s2: TSeries, /) -> bool:
        pass

    def is_ground(self, arg: TSeries) -> bool | None:
        pass

    def constant_coefficient(self, s: TSeries) -> Er:
        pass

    def positive(self, s: TSeries, /) -> TSeries:
        pass

    def negative(self, s: TSeries, /) -> TSeries:
        pass

    def add(self, s1: TSeries, s2: TSeries, /) -> TSeries:
        pass

    def add_ground(self, s: TSeries, n: Er, /) -> TSeries:
        pass

    def subtract(self, s1: TSeries, s2: TSeries, /) -> TSeries:
        pass

    def subtract_ground(self, s: TSeries, n: Er, /) -> TSeries:
        pass

    def rsubtract_ground(self, s: TSeries, n: Er, /) -> TSeries:
        pass

    def multiply(self, s1: TSeries, s2: TSeries, /) -> TSeries:
        pass

    def multiply_ground(self, s: TSeries, n: Er, /) -> TSeries:
        pass

    def divide(self, s1: TSeries, s2: TSeries, /) -> TSeries:
        pass

    def pow_int(self, s: TSeries, n: int, /) -> TSeries:
        pass

    def square(self, s: TSeries, /) -> TSeries:
        pass

    def truncate(self, s: TSeries, n: int, /) -> TSeries:
        pass

    def compose(self, s1: TSeries, s2: TSeries, /) -> TSeries:
        pass

    def inverse(self, s: TSeries, /) -> TSeries:
        pass

    def reversion(self, s: TSeries, /) -> TSeries:
        pass

    def differentiate(self, s: TSeries, /) -> TSeries:
        pass

class PowerSeriesRingFieldProto(PowerSeriesRingProto[TSeries, Ef], Protocol[TSeries, Ef]):

    def __call__(self, coeffs: Sequence[Ef | int | tuple[int, int]], prec: int | None=None) -> TSeries:
        pass

    def integrate(self, s: TSeries, /) -> TSeries:
        pass

    def sqrt(self, s: TSeries, /) -> TSeries:
        pass

    def log(self, s: TSeries, /) -> TSeries:
        pass

    def log1p(self, s: TSeries, /) -> TSeries:
        pass

    def exp(self, s: TSeries, /) -> TSeries:
        pass

    def expm1(self, s: TSeries, /) -> TSeries:
        pass

    def atan(self, s: TSeries, /) -> TSeries:
        pass

    def atanh(self, s: TSeries, /) -> TSeries:
        pass

    def asin(self, s: TSeries, /) -> TSeries:
        pass

    def asinh(self, s: TSeries, /) -> TSeries:
        pass

    def tan(self, s: TSeries, /) -> TSeries:
        pass

    def tanh(self, s: TSeries, /) -> TSeries:
        pass

    def sin(self, s: TSeries, /) -> TSeries:
        pass

    def sinh(self, s: TSeries, /) -> TSeries:
        pass

    def cos(self, s: TSeries, /) -> TSeries:
        pass

    def cosh(self, s: TSeries, /) -> TSeries:
        pass

    def hypot(self, s1: TSeries, s2: TSeries, /) -> TSeries:
        pass