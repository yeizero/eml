from __future__ import annotations
from contextlib import contextmanager
from typing import Sequence, TYPE_CHECKING
from sympy.polys.densebasic import dup, dup_reverse
from sympy.polys.domains import Domain, QQ, ZZ
from sympy.polys.series.ringpython import _useries_valuation
from sympy.polys.series.base import series_pprint
from sympy.external.gmpy import GROUND_TYPES, MPZ, MPQ
from sympy.utilities.decorator import doctest_depends_on
from sympy.polys.polyerrors import NotReversible
_require_flint_version = False
if TYPE_CHECKING:
    from flint import ctx
    from flint.utils.flint_exceptions import DomainError
    from sympy.external.gmpy import FMPQ_POLY as fmpq_poly
    from sympy.external.gmpy import FMPQ_SERIES as fmpq_series
    from sympy.external.gmpy import FMPZ_POLY as fmpz_poly
    from sympy.external.gmpy import FMPZ_SERIES as fmpz_series
    ZZSeries = fmpz_series | fmpz_poly
    QQSeries = fmpq_series | fmpq_poly
elif GROUND_TYPES == 'flint':
    from flint import fmpq_poly, fmpq_series, fmpz_poly, fmpz_series, ctx
    from flint.utils.flint_exceptions import DomainError
    import flint
    _major, _minor, *_ = flint.__version__.split('.')
    if (int(_major), int(_minor)) >= (0, 8):
        _require_flint_version = True
    ZZSeries = fmpz_series | fmpz_poly
    QQSeries = fmpq_series | fmpq_poly
else:
    fmpq_poly = fmpq_series = fmpz_poly = fmpz_series = ctx = None
    ZZSeries = QQSeries = None

def _get_series_precision(s: fmpz_series | fmpq_series) -> int:
    prec = getattr(s, 'prec', None)
    if prec is not None:
        return prec
    rep = s.repr()
    prec = int(rep.split('prec=')[1].split(')')[0].strip())
    return prec

@contextmanager
def _global_cap(cap: int):
    old_cap, ctx.cap = (ctx.cap, cap)
    try:
        yield
    finally:
        ctx.cap = old_cap

@doctest_depends_on(ground_types=['flint'])
class FlintPowerSeriesRingZZ:
    _domain = ZZ

    def __init__(self, prec: int=6) -> None:
        if prec < 0:
            raise ValueError('Power series precision must be non-negative')
        self._prec = prec

    def __repr__(self) -> str:
        return f'Flint Power Series Ring over {self._domain} with precision {self._prec}'

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, FlintPowerSeriesRingZZ):
            return NotImplemented
        return self._prec == other.prec

    def __hash__(self) -> int:
        return hash((self._domain, self._prec))

    def __call__(self, coeffs: Sequence[MPZ | int], prec: int | None=None) -> ZZSeries:
        s: list[MPZ] = []
        for c in coeffs:
            if isinstance(c, MPZ):
                s.append(c)
            elif isinstance(c, int):
                s.append(self._domain(c))
            else:
                raise TypeError(f'Unsupported coefficient type: {type(c)}')
        return self.from_list(s, prec)

    @property
    def domain(self) -> Domain[MPZ]:
        return self._domain

    @property
    def prec(self) -> int:
        return self._prec

    @property
    def one(self) -> ZZSeries:
        if self._prec == 0:
            return fmpz_series([1], prec=0)
        return fmpz_poly([1])

    @property
    def zero(self) -> ZZSeries:
        if self._prec == 0:
            return fmpz_series([0], prec=0)
        return fmpz_poly([0])

    @property
    def gen(self) -> ZZSeries:
        if self._prec < 2:
            return fmpz_series([0, 1], prec=self._prec)
        return fmpz_poly([0, 1])

    def pretty(self, s: ZZSeries, *, symbol: str='x', ascending: bool=True) -> str:
        coeffs = dup_reverse(s.coeffs(), ZZ)
        if isinstance(s, fmpz_poly):
            return series_pprint(coeffs, None)
        prec = self.series_prec(s)
        return series_pprint(coeffs, prec, sym=symbol, ascending=ascending)

    def print(self, s: ZZSeries, *, symbol: str='x', ascending: bool=True) -> None:
        print(self.pretty(s, symbol=symbol, ascending=ascending))

    def from_list(self, coeffs: list[MPZ], prec: int | None=None) -> ZZSeries:
        if prec is None:
            if len(coeffs) <= self._prec:
                return fmpz_poly(coeffs)
            prec = self._prec
        return fmpz_series(coeffs, prec=prec)

    def from_element(self, s: ZZSeries) -> ZZSeries:
        ring_prec = self._prec
        if isinstance(s, fmpz_poly):
            if s.degree() >= ring_prec:
                return fmpz_series(s, prec=ring_prec)
            return s
        prec = min(_get_series_precision(s), ring_prec)
        if _require_flint_version:
            return fmpz_series(s, prec=prec)
        else:
            return fmpz_series(s.coeffs(), prec=prec)

    def to_list(self, s: ZZSeries) -> list[MPZ]:
        return s.coeffs()

    def to_dense(self, s: ZZSeries) -> dup[MPZ]:
        return s.coeffs()[::-1]

    def series_prec(self, s: ZZSeries) -> int | None:
        if isinstance(s, fmpz_poly):
            return None
        return _get_series_precision(s)

    def equal(self, s1: ZZSeries, s2: ZZSeries) -> bool | None:
        if isinstance(s1, fmpz_poly) and isinstance(s2, fmpz_poly):
            return s1 == s2
        elif isinstance(s1, fmpz_poly):
            min_prec = self.series_prec(s2)
        elif isinstance(s2, fmpz_poly):
            min_prec = self.series_prec(s1)
        else:
            min_prec = min(_get_series_precision(s1), _get_series_precision(s2))
        coeffs1 = s1.coeffs()[:min_prec]
        coeffs2 = s2.coeffs()[:min_prec]
        if coeffs1 != coeffs2:
            return False
        return None

    def equal_repr(self, s1: ZZSeries, s2: ZZSeries) -> bool:
        if isinstance(s1, fmpz_poly) and isinstance(s2, fmpz_poly):
            return s1 == s2
        elif isinstance(s1, fmpz_series) and isinstance(s2, fmpz_series):
            return s1._equal_repr(s2)
        else:
            return False

    def is_ground(self, arg: ZZSeries) -> bool | None:
        if self.prec == 0:
            return None
        return len(arg) <= 1

    def constant_coefficient(self, s: ZZSeries) -> MPZ:
        return s[0]

    def positive(self, s: ZZSeries) -> ZZSeries:
        ring_prec = self._prec
        if isinstance(s, fmpz_poly):
            if s.degree() >= ring_prec:
                return fmpz_series(s, prec=ring_prec)
            return s
        prec = min(_get_series_precision(s), ring_prec)
        return fmpz_series(s.coeffs(), prec=prec)

    def negative(self, s: ZZSeries) -> ZZSeries:
        with _global_cap(self._prec):
            return self.positive(-s)

    def add(self, s1: ZZSeries, s2: ZZSeries) -> ZZSeries:
        ring_prec = self._prec
        if isinstance(s1, fmpz_poly) and isinstance(s2, fmpz_poly):
            poly = s1 + s2
            if poly.degree() < ring_prec:
                return poly
            return fmpz_series(poly, prec=ring_prec)
        with _global_cap(ring_prec):
            return s1 + s2

    def add_ground(self, s: ZZSeries, n: MPZ) -> ZZSeries:
        with _global_cap(self._prec):
            return s + n

    def subtract(self, s1: ZZSeries, s2: ZZSeries) -> ZZSeries:
        ring_prec = self._prec
        if isinstance(s1, fmpz_poly) and isinstance(s2, fmpz_poly):
            poly = s1 - s2
            if poly.degree() < ring_prec:
                return poly
            return fmpz_series(poly, prec=ring_prec)
        with _global_cap(ring_prec):
            return s1 - s2

    def subtract_ground(self, s: ZZSeries, n: MPZ) -> ZZSeries:
        with _global_cap(self._prec):
            return s - n

    def rsubtract_ground(self, s: ZZSeries, n: MPZ) -> ZZSeries:
        with _global_cap(self._prec):
            return n - s

    def multiply(self, s1: ZZSeries, s2: ZZSeries) -> ZZSeries:
        ring_prec = self._prec
        if isinstance(s1, fmpz_poly) and isinstance(s2, fmpz_poly):
            deg1 = s1.degree()
            deg2 = s2.degree()
            if deg1 + deg2 < ring_prec:
                return s1 * s2
            else:
                if deg1 >= ring_prec:
                    s1 = self.truncate(s1, ring_prec)
                if deg2 >= ring_prec:
                    s2 = self.truncate(s2, ring_prec)
                return fmpz_series(s1 * s2, prec=ring_prec)
        with _global_cap(ring_prec):
            return s1 * s2

    def multiply_ground(self, s: ZZSeries, n: MPZ) -> ZZSeries:
        ring_prec = self._prec
        if isinstance(s, fmpz_poly):
            poly = s * n
            if poly.degree() < ring_prec:
                return poly
            return fmpz_series(poly, prec=ring_prec)
        with _global_cap(ring_prec):
            return s * n

    def divide(self, s1: ZZSeries, s2: ZZSeries) -> ZZSeries:
        ring_prec = self._prec
        if isinstance(s1, fmpz_poly) and isinstance(s2, fmpz_poly):
            try:
                return s1 / s2
            except DomainError:
                ring_prec = ring_prec + _useries_valuation((s2.coeffs()[::-1], None), self._domain)
                s1 = fmpz_series(s1, prec=ring_prec)
                s2 = fmpz_series(s2, prec=ring_prec)
        with _global_cap(ring_prec):
            return s1 / s2

    def pow_int(self, s: ZZSeries, n: int) -> ZZSeries:
        ring_prec = self._prec
        if n < 0:
            n = -n
            s = self.pow_int(s, n)
            try:
                inv = self.inverse(s)
                return inv
            except NotReversible:
                raise ValueError('Result would not be a power series')
        if isinstance(s, fmpz_poly):
            if s.degree() * n < ring_prec:
                return s ** n
            if s.degree() > ring_prec:
                s = self.truncate(s, ring_prec)
            poly = s ** n
            return fmpz_series(poly, prec=ring_prec)
        with _global_cap(ring_prec):
            return s ** n

    def square(self, s: ZZSeries) -> ZZSeries:
        return self.pow_int(s, 2)

    def compose(self, s1: ZZSeries, s2: ZZSeries) -> ZZSeries:
        dom: Domain[MPZ] = self._domain
        ring_prec: int = self._prec
        if s2 and (not dom.is_zero(s2[0])):
            raise ValueError('Series composition requires the second series to have a zero constant term.')
        if isinstance(s1, fmpz_poly) and isinstance(s2, fmpz_poly):
            deg1: int = s1.degree()
            deg2: int = s2.degree()
            if deg1 * deg2 < ring_prec:
                return s1(s2)
            if deg1 <= ring_prec and deg2 <= ring_prec:
                return self.truncate(s1(s2), ring_prec)
            else:
                s1 = fmpz_series(s1, prec=ring_prec)
                s2 = fmpz_series(s2, prec=ring_prec)
                with _global_cap(ring_prec):
                    return s1(s2)
        if isinstance(s1, fmpz_poly):
            prec2 = self.series_prec(s2)
            s1 = fmpz_series(s1, prec=prec2)
        if isinstance(s2, fmpz_poly):
            prec1 = self.series_prec(s1)
            s2 = fmpz_series(s2, prec=prec1)
        with _global_cap(ring_prec):
            return s1(s2)

    def inverse(self, s: ZZSeries) -> ZZSeries:
        dom: Domain[MPZ] = self._domain
        ring_prec: int = self._prec
        if not s or not dom.is_unit(s[0]):
            raise NotReversible('Series inverse requires the constant term to be a unit')
        if isinstance(s, fmpz_poly):
            if len(s) == 1:
                return 1 / s
            s = fmpz_series(s, prec=ring_prec)
        with _global_cap(ring_prec):
            return 1 / s

    def reversion(self, s: ZZSeries) -> ZZSeries:
        dom = self._domain
        if not s or not dom.is_zero(s[0]):
            raise NotReversible('Series compositional inverse requires the constant term to be zero.')
        if len(s) >= 2 and (not dom.is_unit(s[1])):
            raise NotReversible('Series compositional inverse requires the linear term to be unit.')
        if isinstance(s, fmpz_poly):
            s = fmpz_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.reversion()

    def truncate(self, s: ZZSeries, n: int) -> ZZSeries:
        if n < 0:
            raise ValueError('Truncation precision must be non-negative')
        if len(s) <= n:
            return s
        coeffs = s.coeffs()[:n]
        return fmpz_series(coeffs, prec=n)

    def differentiate(self, s: ZZSeries) -> ZZSeries:
        if isinstance(s, fmpz_poly):
            poly = s.derivative()
            if poly.degree() < self._prec:
                return poly
            return fmpz_series(poly, prec=self._prec)
        poly = fmpz_poly(s.coeffs())
        derivative = poly.derivative()
        prec = min(_get_series_precision(s) - 1, self._prec)
        return fmpz_series(derivative, prec=prec)

@doctest_depends_on(ground_types=['flint'])
class FlintPowerSeriesRingQQ:
    _domain = QQ

    def __init__(self, prec: int=6) -> None:
        if prec < 0:
            raise ValueError('Power series precision must be non-negative')
        self._prec = prec

    def __repr__(self) -> str:
        return f'Flint Power Series Ring over {self._domain} with precision {self._prec}'

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, FlintPowerSeriesRingQQ):
            return NotImplemented
        return self._prec == other.prec

    def __hash__(self) -> int:
        return hash((self._domain, self._prec))

    def __call__(self, coeffs: Sequence[MPQ | int | tuple[int, int]], prec: int | None=None) -> QQSeries:
        s: list[MPQ] = []
        for c in coeffs:
            if isinstance(c, MPQ):
                s.append(c)
            elif isinstance(c, int):
                s.append(self._domain(c))
            elif isinstance(c, tuple):
                s.append(self._domain(*c))
            else:
                raise TypeError(f'Unsupported coefficient type: {type(c)}')
        return self.from_list(s, prec)

    @property
    def domain(self) -> Domain[MPQ]:
        return self._domain

    @property
    def prec(self) -> int:
        return self._prec

    @property
    def one(self) -> QQSeries:
        if self._prec == 0:
            return fmpq_series([1], prec=0)
        return fmpq_poly([1])

    @property
    def zero(self) -> QQSeries:
        if self._prec == 0:
            return fmpq_series([0], prec=0)
        return fmpq_poly([0])

    @property
    def gen(self) -> QQSeries:
        if self._prec < 2:
            return fmpq_series([0, 1], prec=self._prec)
        return fmpq_poly([0, 1])

    def pretty(self, s: QQSeries, *, symbol: str='x', ascending: bool=True) -> str:
        coeffs = dup_reverse(s.coeffs(), QQ)
        if isinstance(s, fmpq_poly):
            return series_pprint(coeffs, None)
        prec = self.series_prec(s)
        return series_pprint(coeffs, prec, sym=symbol, ascending=ascending)

    def print(self, s: QQSeries, *, symbol: str='x', ascending: bool=True) -> None:
        print(self.pretty(s, symbol=symbol, ascending=ascending))

    def from_list(self, coeffs: list[MPQ], prec: int | None=None) -> QQSeries:
        if prec is None:
            if len(coeffs) <= self._prec:
                return fmpq_poly(coeffs)
            prec = self._prec
        return fmpq_series(coeffs, prec=prec)

    def from_element(self, s: QQSeries) -> QQSeries:
        ring_prec = self._prec
        if isinstance(s, fmpq_poly):
            if s.degree() >= ring_prec:
                return fmpq_series(s, prec=ring_prec)
            return s
        prec = min(_get_series_precision(s), ring_prec)
        if _require_flint_version:
            return fmpq_series(s, prec=prec)
        else:
            return fmpq_series(s.coeffs(), prec=prec)

    def to_list(self, s: QQSeries) -> list[MPQ]:
        return s.coeffs()

    def to_dense(self, s: QQSeries) -> dup[MPQ]:
        return s.coeffs()[::-1]

    def series_prec(self, s: QQSeries) -> int | None:
        if isinstance(s, fmpq_poly):
            return None
        return _get_series_precision(s)

    def equal(self, s1: QQSeries, s2: QQSeries) -> bool | None:
        if isinstance(s1, fmpq_poly) and isinstance(s2, fmpq_poly):
            return s1 == s2
        elif isinstance(s1, fmpq_poly):
            min_prec = self.series_prec(s2)
        elif isinstance(s2, fmpq_poly):
            min_prec = self.series_prec(s1)
        else:
            min_prec = min(_get_series_precision(s1), _get_series_precision(s2))
        coeffs1 = s1.coeffs()[:min_prec]
        coeffs2 = s2.coeffs()[:min_prec]
        if coeffs1 != coeffs2:
            return False
        return None

    def equal_repr(self, s1: QQSeries, s2: QQSeries) -> bool:
        if isinstance(s1, fmpq_poly) and isinstance(s2, fmpq_poly):
            return s1 == s2
        elif isinstance(s1, fmpq_series) and isinstance(s2, fmpq_series):
            return s1._equal_repr(s2)
        else:
            return False

    def is_ground(self, arg: QQSeries) -> bool | None:
        if self.prec == 0:
            return None
        return len(arg) <= 1

    def constant_coefficient(self, s: QQSeries) -> MPQ:
        return s[0]

    def positive(self, s: QQSeries) -> QQSeries:
        ring_prec = self._prec
        if isinstance(s, fmpq_poly):
            if s.degree() >= ring_prec:
                return fmpq_series(s, prec=ring_prec)
            return s
        prec = min(_get_series_precision(s), ring_prec)
        return fmpq_series(s.coeffs(), prec=prec)

    def negative(self, s: QQSeries) -> QQSeries:
        with _global_cap(self._prec):
            return self.positive(-s)

    def add(self, s1: QQSeries, s2: QQSeries) -> QQSeries:
        ring_prec = self._prec
        if isinstance(s1, fmpq_poly) and isinstance(s2, fmpq_poly):
            poly = s1 + s2
            if poly.degree() < ring_prec:
                return poly
            return fmpq_series(poly, prec=ring_prec)
        with _global_cap(ring_prec):
            return s1 + s2

    def add_ground(self, s: QQSeries, n: MPQ) -> QQSeries:
        with _global_cap(self._prec):
            return s + n

    def subtract(self, s1: QQSeries, s2: QQSeries) -> QQSeries:
        ring_prec = self._prec
        if isinstance(s1, fmpq_poly) and isinstance(s2, fmpq_poly):
            poly = s1 - s2
            if poly.degree() < ring_prec:
                return poly
            return fmpq_series(poly, prec=ring_prec)
        with _global_cap(ring_prec):
            return s1 - s2

    def subtract_ground(self, s: QQSeries, n: MPQ) -> QQSeries:
        with _global_cap(self._prec):
            return s - n

    def rsubtract_ground(self, s: QQSeries, n: MPQ) -> QQSeries:
        with _global_cap(self._prec):
            return n - s

    def multiply(self, s1: QQSeries, s2: QQSeries) -> QQSeries:
        ring_prec = self._prec
        if isinstance(s1, fmpq_poly) and isinstance(s2, fmpq_poly):
            deg1 = s1.degree()
            deg2 = s2.degree()
            if deg1 + deg2 < ring_prec:
                return s1 * s2
            else:
                if deg1 >= ring_prec:
                    s1 = self.truncate(s1, ring_prec)
                if deg2 >= ring_prec:
                    s2 = self.truncate(s2, ring_prec)
                return fmpq_series(s1 * s2, prec=ring_prec)
        with _global_cap(ring_prec):
            return s1 * s2

    def multiply_ground(self, s: QQSeries, n: MPQ) -> QQSeries:
        ring_prec = self._prec
        if isinstance(s, fmpq_poly):
            poly = s * n
            if poly.degree() < ring_prec:
                return poly
            return fmpq_series(poly, prec=ring_prec)
        with _global_cap(ring_prec):
            return s * n

    def divide(self, s1: QQSeries, s2: QQSeries) -> QQSeries:
        ring_prec = self._prec
        if isinstance(s1, fmpq_poly) and isinstance(s2, fmpq_poly):
            try:
                return s1 / s2
            except DomainError:
                ring_prec = ring_prec + _useries_valuation((s2.coeffs()[::-1], None), self._domain)
                s1 = fmpq_series(s1, prec=ring_prec)
                s2 = fmpq_series(s2, prec=ring_prec)
        with _global_cap(ring_prec):
            return s1 / s2

    def pow_int(self, s: QQSeries, n: int) -> QQSeries:
        ring_prec = self._prec
        if n < 0:
            n = -n
            s = self.pow_int(s, n)
            try:
                inv = self.inverse(s)
                return inv
            except NotReversible:
                raise ValueError('Result would not be a power series')
        if isinstance(s, fmpq_poly):
            if s.degree() * n < ring_prec:
                return s ** n
            if s.degree() > ring_prec:
                s = self.truncate(s, ring_prec)
            poly = s ** n
            return fmpq_series(poly, prec=ring_prec)
        with _global_cap(ring_prec):
            return s ** n

    def square(self, s: QQSeries) -> QQSeries:
        return self.pow_int(s, 2)

    def sqrt(self, s: QQSeries) -> QQSeries:
        if not s:
            return s
        if isinstance(s, fmpq_poly):
            try:
                return s.sqrt()
            except DomainError:
                s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.sqrt()

    def compose(self, s1: QQSeries, s2: QQSeries) -> QQSeries:
        dom: Domain[MPQ] = self._domain
        ring_prec: int = self._prec
        if s2 and (not dom.is_zero(s2[0])):
            raise ValueError('Series composition requires the second series to have a zero constant term.')
        if isinstance(s1, fmpq_poly) and isinstance(s2, fmpq_poly):
            deg1: int = s1.degree()
            deg2: int = s2.degree()
            if deg1 * deg2 < ring_prec:
                return s1(s2)
            if deg1 <= ring_prec and deg2 <= ring_prec:
                return self.truncate(s1(s2), ring_prec)
            else:
                s1 = fmpq_series(s1, prec=ring_prec)
                s2 = fmpq_series(s2, prec=ring_prec)
                with _global_cap(ring_prec):
                    return s1(s2)
        if isinstance(s1, fmpq_poly):
            prec2 = self.series_prec(s2)
            s1 = fmpq_series(s1, prec=prec2)
        if isinstance(s2, fmpq_poly):
            prec1 = self.series_prec(s1)
            s2 = fmpq_series(s2, prec=prec1)
        with _global_cap(ring_prec):
            return s1(s2)

    def inverse(self, s: QQSeries) -> QQSeries:
        dom: Domain[MPQ] = self._domain
        ring_prec: int = self._prec
        if not s or not dom.is_unit(s[0]):
            raise NotReversible('Series inverse requires the constant term to be a unit')
        if isinstance(s, fmpq_poly):
            if len(s) == 1:
                return 1 / s
            s = fmpq_series(s, prec=ring_prec)
        with _global_cap(ring_prec):
            return s.inv()

    def reversion(self, s: QQSeries) -> QQSeries:
        dom = self._domain
        if not s or not dom.is_zero(s[0]):
            raise NotReversible('Series compositional inverse requires the constant term to be zero.')
        if len(s) >= 2 and (not dom.is_unit(s[1])):
            raise NotReversible('Series compositional inverse requires the linear term to be unit.')
        if isinstance(s, fmpq_poly):
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.reversion()

    def truncate(self, s: QQSeries, n: int) -> QQSeries:
        if n < 0:
            raise ValueError('Truncation precision must be non-negative')
        if len(s) <= n:
            return s
        coeffs = s.coeffs()[:n]
        return fmpq_series(coeffs, prec=n)

    def differentiate(self, s: QQSeries) -> QQSeries:
        if isinstance(s, fmpq_poly):
            poly = s.derivative()
            if poly.degree() < self._prec:
                return poly
            return fmpq_series(poly, prec=self._prec)
        poly = fmpq_poly(s.coeffs())
        derivative = poly.derivative()
        prec = min(_get_series_precision(s) - 1, self._prec)
        return fmpq_series(derivative, prec=prec)

    def integrate(self, s: QQSeries) -> QQSeries:
        if isinstance(s, fmpq_poly):
            poly = s.integral()
            if poly.degree() < self._prec:
                return poly
            return fmpq_series(poly, prec=self._prec)
        else:
            s_prec = _get_series_precision(s)
            if s_prec >= self._prec:
                s = fmpq_series(s, prec=self._prec - 1)
        with _global_cap(self._prec):
            return s.integral()

    def log(self, s: QQSeries) -> QQSeries:
        if isinstance(s, fmpq_poly):
            if s == 1:
                return fmpq_poly([])
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.log()

    def log1p(self, s: QQSeries) -> QQSeries:
        if s[0] != 0:
            raise ValueError('Log1p requires the constant term of the input series to be zero.')
        with _global_cap(self._prec):
            s = s + 1
        return self.log(s)

    def exp(self, s: QQSeries) -> QQSeries:
        if isinstance(s, fmpq_poly):
            if not s:
                return fmpq_poly([1])
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.exp()

    def expm1(self, s: QQSeries) -> QQSeries:
        if isinstance(s, fmpq_poly):
            if not s:
                return fmpq_poly([])
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.exp() - 1

    def atan(self, s: QQSeries) -> QQSeries:
        if not s:
            return s
        if isinstance(s, fmpq_poly):
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.atan()

    def atanh(self, s: QQSeries) -> QQSeries:
        if not s:
            return s
        if isinstance(s, fmpq_poly):
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.atanh()

    def asin(self, s: QQSeries) -> QQSeries:
        if not s:
            return s
        if isinstance(s, fmpq_poly):
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.asin()

    def asinh(self, s: QQSeries) -> QQSeries:
        if not s:
            return s
        if isinstance(s, fmpq_poly):
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.asinh()

    def tan(self, s: QQSeries) -> QQSeries:
        if not s:
            return s
        if isinstance(s, fmpq_poly):
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.tan()

    def tanh(self, s: QQSeries) -> QQSeries:
        if not s:
            return s
        if isinstance(s, fmpq_poly):
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.tanh()

    def sin(self, s: QQSeries) -> QQSeries:
        if not s:
            return s
        if isinstance(s, fmpq_poly):
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.sin()

    def sinh(self, s: QQSeries) -> QQSeries:
        if not s:
            return s
        if isinstance(s, fmpq_poly):
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.sinh()

    def cos(self, s: QQSeries) -> QQSeries:
        if isinstance(s, fmpq_poly):
            if not s:
                return fmpq_poly([1])
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.cos()

    def cosh(self, s: QQSeries) -> QQSeries:
        if isinstance(s, fmpq_poly):
            if not s:
                return fmpq_poly([1])
            s = fmpq_series(s, prec=self._prec)
        with _global_cap(self._prec):
            return s.cosh()

    def hypot(self, s1: QQSeries, s2: QQSeries) -> QQSeries:
        with _global_cap(self._prec):
            sqr_s1 = s1 ** 2
            sqr_s2 = s2 ** 2
            add = sqr_s1 + sqr_s2
        return self.sqrt(add)