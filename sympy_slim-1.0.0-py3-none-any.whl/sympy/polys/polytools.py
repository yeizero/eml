from __future__ import annotations
from typing import TYPE_CHECKING, overload, Literal, Any, cast, Callable
from functools import wraps, reduce
from operator import mul
from collections import Counter, defaultdict
from sympy.core import S, Expr, Add, Tuple
from sympy.core.basic import Basic
from sympy.core.decorators import _sympifyit
from sympy.core.exprtools import Factors, factor_nc, factor_terms
from sympy.core.evalf import pure_complex, evalf, fastlog, _evalf_with_bounded_error, quad_to_mpmath
from sympy.core.function import Derivative
from sympy.core.mul import Mul, _keep_coeff
from sympy.core.intfunc import ilcm
from sympy.core.numbers import I, Integer, equal_valued, NegativeInfinity
from sympy.core.relational import Relational, Equality
from sympy.core.symbol import Dummy, Symbol
from sympy.core.sympify import sympify, _sympify
from sympy.core.traversal import preorder_traversal, bottom_up
from sympy.logic.boolalg import BooleanAtom
from sympy.polys import polyoptions as options
from sympy.polys.constructor import construct_domain
from sympy.polys.domains import FF, QQ, ZZ
from sympy.polys.domains.domainelement import DomainElement
from sympy.polys.fglmtools import matrix_fglm
from sympy.polys.groebnertools import groebner as _groebner
from sympy.polys.monomials import Monomial
from sympy.polys.orderings import monomial_key
from sympy.polys.polyclasses import DMP, DMF, ANP
from sympy.polys.polyerrors import OperationNotSupported, DomainError, CoercionFailed, UnificationFailed, GeneratorsNeeded, PolynomialError, MultivariatePolynomialError, ExactQuotientFailed, PolificationFailed, ComputationFailed, GeneratorsError
from sympy.polys.polyutils import basic_from_dict, _sort_gens, _unify_gens, _dict_reorder, _dict_from_expr, _parallel_dict_from_expr
from sympy.polys.rationaltools import together
from sympy.polys.rootisolation import dup_isolate_real_roots_list
from sympy.utilities import group, public, filldedent
from sympy.utilities.exceptions import sympy_deprecation_warning
from sympy.utilities.iterables import iterable, sift
import sympy.polys
from sympy.external.mpmath import local_workdps, NoConvergence
if TYPE_CHECKING:
    from sympy.polys.domains.domain import Domain
    from collections.abc import Iterator
    from typing import Self

def _polifyit(func):

    @wraps(func)
    def wrapper(f, g):
        g = _sympify(g)
        if isinstance(g, Poly):
            return func(f, g)
        elif isinstance(g, Integer):
            g = f.from_expr(g, *f.gens, domain=f.domain)
            return func(f, g)
        elif isinstance(g, Expr):
            try:
                g = f.from_expr(g, *f.gens)
            except PolynomialError:
                if g.is_Matrix:
                    return NotImplemented
                expr_method = getattr(f.as_expr(), func.__name__)
                result = expr_method(g)
                if result is not NotImplemented:
                    sympy_deprecation_warning('\n                        Mixing Poly with non-polynomial expressions in binary\n                        operations is deprecated. Either explicitly convert\n                        the non-Poly operand to a Poly with as_poly() or\n                        convert the Poly to an Expr with as_expr().\n                        ', deprecated_since_version='1.6', active_deprecations_target='deprecated-poly-nonpoly-binary-operations')
                return result
            else:
                return func(f, g)
        else:
            return NotImplemented
    return wrapper

@public
class Poly(Basic):
    __slots__ = ('rep', 'gens')
    is_commutative = True
    is_Poly = True
    _op_priority = 10.001
    rep: DMP
    gens: tuple[Expr, ...]

    def __new__(cls, rep, *gens, **args) -> Self:
        opt = options.build_options(gens, args)
        if 'order' in opt:
            raise NotImplementedError("'order' keyword is not implemented yet")
        if isinstance(rep, (DMP, DMF, ANP, DomainElement)):
            return cls._from_domain_element(rep, opt)
        elif iterable(rep, exclude=str):
            if isinstance(rep, dict):
                return cls._from_dict(rep, opt)
            else:
                return cls._from_list(list(rep), opt)
        else:
            rep = sympify(rep, evaluate=type(rep) is not str)
            if rep.is_Poly:
                return cls._from_poly(rep, opt)
            else:
                return cls._from_expr(rep, opt)

    @classmethod
    def new(cls, rep, *gens):
        if not isinstance(rep, DMP):
            raise PolynomialError('invalid polynomial representation: %s' % rep)
        elif rep.lev != len(gens) - 1:
            raise PolynomialError('invalid arguments: %s, %s' % (rep, gens))
        obj = Basic.__new__(cls)
        obj.rep = rep
        obj.gens = gens
        return obj

    @property
    def expr(self):
        return basic_from_dict(self.rep.to_sympy_dict(), *self.gens)

    @property
    def args(self):
        return (self.expr,) + self.gens

    def _hashable_content(self):
        return (self.rep,) + self.gens

    @classmethod
    def from_dict(cls, rep: dict[tuple[int, ...], Any] | dict[int, Any], *gens, **args):
        opt = options.build_options(gens, args)
        return cls._from_dict(rep, opt)

    @classmethod
    def from_list(cls, rep, *gens, **args):
        opt = options.build_options(gens, args)
        return cls._from_list(rep, opt)

    @classmethod
    def from_poly(cls, rep, *gens, **args):
        opt = options.build_options(gens, args)
        return cls._from_poly(rep, opt)

    @classmethod
    def from_expr(cls, rep, *gens, **args):
        opt = options.build_options(gens, args)
        return cls._from_expr(rep, opt)

    @classmethod
    def _from_dict(cls, rep: dict[tuple[int, ...], Any] | dict[int, Any], opt):
        gens = opt.gens
        if not gens:
            raise GeneratorsNeeded("Cannot initialize from 'dict' without generators")
        level = len(gens) - 1
        domain = opt.domain
        if domain is None:
            domain, rep_d = construct_domain(rep, opt=opt)
        else:
            convert = domain.convert
            rep_d = {monom: convert(coeff) for monom, coeff in rep.items()}
        n = None
        for n in rep_d:
            break
        if isinstance(n, int):
            raw_dict = cast(dict[int, Any], rep_d)
            return cls.new(DMP.from_raw_dict(raw_dict, domain), *gens)
        else:
            multi_dict = cast(dict[tuple[int, ...], Any], rep_d)
            return cls.new(DMP.from_dict(multi_dict, level, domain), *gens)

    @classmethod
    def _from_list(cls, rep, opt):
        gens = opt.gens
        if not gens:
            raise GeneratorsNeeded("Cannot initialize from 'list' without generators")
        elif len(gens) != 1:
            raise MultivariatePolynomialError("'list' representation not supported")
        level = len(gens) - 1
        domain = opt.domain
        if domain is None:
            domain, rep = construct_domain(rep, opt=opt)
        else:
            rep = list(map(domain.convert, rep))
        return cls.new(DMP.from_list(rep, level, domain), *gens)

    @classmethod
    def _from_poly(cls, rep, opt):
        if cls != rep.__class__:
            rep = cls.new(rep.rep, *rep.gens)
        gens = opt.gens
        field = opt.field
        domain = opt.domain
        if gens and rep.gens != gens:
            if set(rep.gens) != set(gens):
                return cls._from_expr(rep.as_expr(), opt)
            else:
                rep = rep.reorder(*gens)
        if 'domain' in opt and domain:
            rep = rep.set_domain(domain)
        elif field is True:
            rep = rep.to_field()
        return rep

    @classmethod
    def _from_expr(cls, rep, opt):
        rep, opt = _dict_from_expr(rep, opt)
        return cls._from_dict(rep, opt)

    @classmethod
    def _from_domain_element(cls, rep, opt):
        gens = opt.gens
        domain = opt.domain
        level = len(gens) - 1
        rep = [domain.convert(rep)]
        return cls.new(DMP.from_list(rep, level, domain), *gens)

    def __hash__(self):
        return super().__hash__()

    @property
    def free_symbols(self):
        symbols = set()
        gens = self.gens
        for i in range(len(gens)):
            for monom in self.monoms():
                if monom[i]:
                    symbols |= gens[i].free_symbols
                    break
        return symbols | self.free_symbols_in_domain

    @property
    def free_symbols_in_domain(self):
        domain, symbols = (self.rep.dom, set())
        if domain.is_Composite:
            for gen in domain.symbols:
                symbols |= gen.free_symbols
        elif domain.is_EX:
            for coeff in self.coeffs():
                symbols |= coeff.free_symbols
        return symbols

    @property
    def gen(self):
        return self.gens[0]

    @property
    def domain(self):
        return self.get_domain()

    @property
    def zero(self):
        return self.new(self.rep.zero(self.rep.lev, self.rep.dom), *self.gens)

    @property
    def one(self):
        return self.new(self.rep.one(self.rep.lev, self.rep.dom), *self.gens)

    def unify(f, g: Poly | Expr | complex) -> tuple[Poly, Poly]:
        _, per, F, G = f._unify(g)
        return (per(F), per(G))

    def _unify(f, g: Poly | Expr | complex) -> tuple[Domain, Callable[[DMP], Poly], DMP, DMP]:
        gs = cast('Poly | Expr', sympify(g))
        if not isinstance(gs, Poly):
            try:
                g_coeff = f.rep.dom.from_sympy(gs)
            except CoercionFailed:
                raise UnificationFailed('Cannot unify %s with %s' % (f, gs))
            else:
                return (f.rep.dom, f.per, f.rep, f.rep.ground_new(g_coeff))
        if isinstance(f.rep, DMP) and isinstance(gs.rep, DMP):
            gens = _unify_gens(f.gens, gs.gens)
            dom, lev = (f.rep.dom.unify(gs.rep.dom, gens), len(gens) - 1)
            if f.gens != gens:
                f_monoms, f_coeffs = _dict_reorder(f.rep.to_dict(), f.gens, gens)
                if f.rep.dom != dom:
                    f_coeffs = [dom.convert(c, f.rep.dom) for c in f_coeffs]
                F = DMP.from_dict(dict(list(zip(f_monoms, f_coeffs))), lev, dom)
            else:
                F = f.rep.convert(dom)
            if gs.gens != gens:
                g_monoms, g_coeffs = _dict_reorder(gs.rep.to_dict(), gs.gens, gens)
                if gs.rep.dom != dom:
                    g_coeffs = [dom.convert(c, gs.rep.dom) for c in g_coeffs]
                G = DMP.from_dict(dict(list(zip(g_monoms, g_coeffs))), lev, dom)
            else:
                G = gs.rep.convert(dom)
        else:
            raise UnificationFailed('Cannot unify %s with %s' % (f, gs))
        cls = f.__class__

        def per(rep, dom=dom, gens=gens, remove=None):
            if remove is not None:
                gens = gens[:remove] + gens[remove + 1:]
                if not gens:
                    return dom.to_sympy(rep)
            return cls.new(rep, *gens)
        return (dom, per, F, G)

    @overload
    def per(f, rep: DMP, gens: tuple[Expr, ...] | None=None, *, remove: int) -> Poly | Expr:
        pass

    @overload
    def per(f, rep: DMP, gens: tuple[Expr, ...] | None=None, remove: None=None) -> Poly:
        pass

    def per(f, rep: DMP, gens: tuple[Expr, ...] | None=None, remove: int | None=None) -> Poly | Expr:
        if gens is None:
            gens = f.gens
        if remove is not None:
            gens = gens[:remove] + gens[remove + 1:]
            if not gens:
                return f.rep.dom.to_sympy(rep)
        return f.__class__.new(rep, *gens)

    def set_domain(f, domain):
        opt = options.build_options(f.gens, {'domain': domain})
        return f.per(f.rep.convert(opt.domain))

    def get_domain(f):
        return f.rep.dom

    def set_modulus(f, modulus):
        modulus = options.Modulus.preprocess(modulus)
        return f.set_domain(FF(modulus))

    def get_modulus(f):
        domain = f.get_domain()
        if domain.is_FiniteField:
            return Integer(domain.characteristic())
        else:
            raise PolynomialError('not a polynomial over a Galois field')

    def _eval_subs(f, old, new):
        if old in f.gens:
            if new.is_number:
                return f.eval(old, new)
            else:
                try:
                    return f.replace(old, new)
                except PolynomialError:
                    pass
        return f.as_expr().subs(old, new)

    def exclude(f):
        J, new = f.rep.exclude()
        gens = [gen for j, gen in enumerate(f.gens) if j not in J]
        return f.per(new, gens=gens)

    def replace(f, x, y=None, **_ignore):
        if y is None:
            if f.is_univariate:
                x, y = (f.gen, x)
            else:
                raise PolynomialError('syntax supported only in univariate case')
        if x == y or x not in f.gens:
            return f
        if x in f.gens and y not in f.gens:
            dom = f.get_domain()
            if not dom.is_Composite or y not in dom.symbols:
                gens = list(f.gens)
                gens[gens.index(x)] = y
                return f.per(f.rep, gens=gens)
        raise PolynomialError('Cannot replace %s with %s in %s' % (x, y, f))

    def match(f, *args, **kwargs):
        return f.as_expr().match(*args, **kwargs)

    def reorder(f, *gens, **args):
        opt = options.Options((), args)
        if not gens:
            gens = _sort_gens(f.gens, opt=opt)
        elif set(f.gens) != set(gens):
            raise PolynomialError('generators list can differ only up to order of elements')
        rep = dict(list(zip(*_dict_reorder(f.rep.to_dict(), f.gens, gens))))
        return f.per(DMP.from_dict(rep, len(gens) - 1, f.rep.dom), gens=gens)

    def ltrim(f, gen):
        rep = f.as_dict(native=True)
        j = f._gen_to_level(gen)
        terms = {}
        for monom, coeff in rep.items():
            if any(monom[:j]):
                raise PolynomialError('Cannot left trim %s' % f)
            terms[monom[j:]] = coeff
        gens = f.gens[j:]
        return f.new(DMP.from_dict(terms, len(gens) - 1, f.rep.dom), *gens)

    def has_only_gens(f, *gens):
        indices = set()
        for gen in gens:
            try:
                index = f.gens.index(gen)
            except ValueError:
                raise GeneratorsError("%s doesn't have %s as generator" % (f, gen))
            else:
                indices.add(index)
        for monom in f.monoms():
            for i, elt in enumerate(monom):
                if i not in indices and elt:
                    return False
        return True

    def to_ring(f):
        if hasattr(f.rep, 'to_ring'):
            result = f.rep.to_ring()
        else:
            raise OperationNotSupported(f, 'to_ring')
        return f.per(result)

    def to_field(f):
        if hasattr(f.rep, 'to_field'):
            result = f.rep.to_field()
        else:
            raise OperationNotSupported(f, 'to_field')
        return f.per(result)

    def to_exact(f):
        if hasattr(f.rep, 'to_exact'):
            result = f.rep.to_exact()
        else:
            raise OperationNotSupported(f, 'to_exact')
        return f.per(result)

    def retract(f, field=None):
        dom, rep = construct_domain(f.as_dict(zero=True), field=field, composite=f.domain.is_Composite or None)
        return f.from_dict(rep, f.gens, domain=dom)

    def slice(f, x, m, n=None):
        if n is None:
            j, m, n = (0, x, m)
        else:
            j = f._gen_to_level(x)
        m, n = (int(m), int(n))
        if hasattr(f.rep, 'slice'):
            result = f.rep.slice(m, n, j)
        else:
            raise OperationNotSupported(f, 'slice')
        return f.per(result)

    def coeffs(f, order=None):
        return [f.rep.dom.to_sympy(c) for c in f.rep.coeffs(order=order)]

    def monoms(f, order=None):
        return f.rep.monoms(order=order)

    def terms(f, order=None):
        return [(m, f.rep.dom.to_sympy(c)) for m, c in f.rep.terms(order=order)]

    def all_coeffs(f):
        return [f.rep.dom.to_sympy(c) for c in f.rep.all_coeffs()]

    def all_monoms(f):
        return f.rep.all_monoms()

    def all_terms(f):
        return [(m, f.rep.dom.to_sympy(c)) for m, c in f.rep.all_terms()]

    def termwise(f, func, *gens, **args):
        terms = {}
        for monom, coeff in f.terms():
            result = func(monom, coeff)
            if isinstance(result, tuple):
                monom, coeff = result
            else:
                coeff = result
            if coeff:
                if monom not in terms:
                    terms[monom] = coeff
                else:
                    raise PolynomialError('%s monomial was generated twice' % monom)
        return f.from_dict(terms, *(gens or f.gens), **args)

    def length(f):
        return len(f.as_dict())

    def as_dict(f, native=False, zero=False):
        if native:
            return f.rep.to_dict(zero=zero)
        else:
            return f.rep.to_sympy_dict(zero=zero)

    def as_list(f, native=False):
        if native:
            return f.rep.to_list()
        else:
            return f.rep.to_sympy_list()

    def as_expr(f, *gens):
        if not gens:
            return f.expr
        if len(gens) == 1 and isinstance(gens[0], dict):
            mapping = gens[0]
            gens = list(f.gens)
            for gen, value in mapping.items():
                try:
                    index = gens.index(gen)
                except ValueError:
                    raise GeneratorsError("%s doesn't have %s as generator" % (f, gen))
                else:
                    gens[index] = value
        return basic_from_dict(f.rep.to_sympy_dict(), *gens)

    def as_poly(self, *gens, **args):
        try:
            poly = Poly(self, *gens, **args)
            if not poly.is_Poly:
                return None
            else:
                return poly
        except PolynomialError:
            return None

    def lift(f):
        if hasattr(f.rep, 'lift'):
            result = f.rep.lift()
        else:
            raise OperationNotSupported(f, 'lift')
        return f.per(result)

    def deflate(f):
        if hasattr(f.rep, 'deflate'):
            J, result = f.rep.deflate()
        else:
            raise OperationNotSupported(f, 'deflate')
        return (J, f.per(result))

    def inject(f, front=False):
        dom = f.rep.dom
        if dom.is_Numerical:
            return f
        elif not dom.is_Poly:
            raise DomainError('Cannot inject generators over %s' % dom)
        if hasattr(f.rep, 'inject'):
            result = f.rep.inject(front=front)
        else:
            raise OperationNotSupported(f, 'inject')
        if front:
            gens = dom.symbols + f.gens
        else:
            gens = f.gens + dom.symbols
        return f.new(result, *gens)

    def eject(f, *gens):
        dom = f.rep.dom
        if not dom.is_Numerical:
            raise DomainError('Cannot eject generators over %s' % dom)
        k = len(gens)
        if f.gens[:k] == gens:
            _gens, front = (f.gens[k:], True)
        elif f.gens[-k:] == gens:
            _gens, front = (f.gens[:-k], False)
        else:
            raise NotImplementedError('can only eject front or back generators')
        dom = dom.inject(*gens)
        if hasattr(f.rep, 'eject'):
            result = f.rep.eject(dom, front=front)
        else:
            raise OperationNotSupported(f, 'eject')
        return f.new(result, *_gens)

    def terms_gcd(f):
        if hasattr(f.rep, 'terms_gcd'):
            J, result = f.rep.terms_gcd()
        else:
            raise OperationNotSupported(f, 'terms_gcd')
        return (J, f.per(result))

    def add_ground(f, coeff):
        if hasattr(f.rep, 'add_ground'):
            result = f.rep.add_ground(coeff)
        else:
            raise OperationNotSupported(f, 'add_ground')
        return f.per(result)

    def sub_ground(f, coeff):
        if hasattr(f.rep, 'sub_ground'):
            result = f.rep.sub_ground(coeff)
        else:
            raise OperationNotSupported(f, 'sub_ground')
        return f.per(result)

    def mul_ground(f, coeff):
        if hasattr(f.rep, 'mul_ground'):
            result = f.rep.mul_ground(coeff)
        else:
            raise OperationNotSupported(f, 'mul_ground')
        return f.per(result)

    def quo_ground(f, coeff):
        if hasattr(f.rep, 'quo_ground'):
            result = f.rep.quo_ground(coeff)
        else:
            raise OperationNotSupported(f, 'quo_ground')
        return f.per(result)

    def exquo_ground(f, coeff):
        if hasattr(f.rep, 'exquo_ground'):
            result = f.rep.exquo_ground(coeff)
        else:
            raise OperationNotSupported(f, 'exquo_ground')
        return f.per(result)

    def abs(f):
        if hasattr(f.rep, 'abs'):
            result = f.rep.abs()
        else:
            raise OperationNotSupported(f, 'abs')
        return f.per(result)

    def neg(f):
        if hasattr(f.rep, 'neg'):
            result = f.rep.neg()
        else:
            raise OperationNotSupported(f, 'neg')
        return f.per(result)

    def add(f, g):
        g = sympify(g)
        if not g.is_Poly:
            return f.add_ground(g)
        _, per, F, G = f._unify(g)
        if hasattr(f.rep, 'add'):
            result = F.add(G)
        else:
            raise OperationNotSupported(f, 'add')
        return per(result)

    def sub(f, g):
        g = sympify(g)
        if not g.is_Poly:
            return f.sub_ground(g)
        _, per, F, G = f._unify(g)
        if hasattr(f.rep, 'sub'):
            result = F.sub(G)
        else:
            raise OperationNotSupported(f, 'sub')
        return per(result)

    def mul(f, g):
        g = sympify(g)
        if not g.is_Poly:
            return f.mul_ground(g)
        _, per, F, G = f._unify(g)
        if hasattr(f.rep, 'mul'):
            result = F.mul(G)
        else:
            raise OperationNotSupported(f, 'mul')
        return per(result)

    def sqr(f):
        if hasattr(f.rep, 'sqr'):
            result = f.rep.sqr()
        else:
            raise OperationNotSupported(f, 'sqr')
        return f.per(result)

    def pow(f, n):
        n = int(n)
        if hasattr(f.rep, 'pow'):
            result = f.rep.pow(n)
        else:
            raise OperationNotSupported(f, 'pow')
        return f.per(result)

    def pdiv(f, g):
        _, per, F, G = f._unify(g)
        if hasattr(f.rep, 'pdiv'):
            q, r = F.pdiv(G)
        else:
            raise OperationNotSupported(f, 'pdiv')
        return (per(q), per(r))

    def prem(f, g):
        _, per, F, G = f._unify(g)
        if hasattr(f.rep, 'prem'):
            result = F.prem(G)
        else:
            raise OperationNotSupported(f, 'prem')
        return per(result)

    def pquo(f, g):
        _, per, F, G = f._unify(g)
        if hasattr(f.rep, 'pquo'):
            result = F.pquo(G)
        else:
            raise OperationNotSupported(f, 'pquo')
        return per(result)

    def pexquo(f, g):
        _, per, F, G = f._unify(g)
        if hasattr(f.rep, 'pexquo'):
            try:
                result = F.pexquo(G)
            except ExactQuotientFailed as exc:
                raise exc.new(f.as_expr(), g.as_expr())
        else:
            raise OperationNotSupported(f, 'pexquo')
        return per(result)

    def div(f, g, auto=True):
        dom, per, F, G = f._unify(g)
        retract = False
        if auto and dom.is_Ring and (not dom.is_Field):
            F, G = (F.to_field(), G.to_field())
            retract = True
        if hasattr(f.rep, 'div'):
            q, r = F.div(G)
        else:
            raise OperationNotSupported(f, 'div')
        if retract:
            try:
                Q, R = (q.to_ring(), r.to_ring())
            except CoercionFailed:
                pass
            else:
                q, r = (Q, R)
        return (per(q), per(r))

    def rem(f, g, auto=True):
        dom, per, F, G = f._unify(g)
        retract = False
        if auto and dom.is_Ring and (not dom.is_Field):
            F, G = (F.to_field(), G.to_field())
            retract = True
        if hasattr(f.rep, 'rem'):
            r = F.rem(G)
        else:
            raise OperationNotSupported(f, 'rem')
        if retract:
            try:
                r = r.to_ring()
            except CoercionFailed:
                pass
        return per(r)

    def quo(f, g, auto=True):
        dom, per, F, G = f._unify(g)
        retract = False
        if auto and dom.is_Ring and (not dom.is_Field):
            F, G = (F.to_field(), G.to_field())
            retract = True
        if hasattr(f.rep, 'quo'):
            q = F.quo(G)
        else:
            raise OperationNotSupported(f, 'quo')
        if retract:
            try:
                q = q.to_ring()
            except CoercionFailed:
                pass
        return per(q)

    def exquo(f, g, auto=True):
        dom, per, F, G = f._unify(g)
        retract = False
        if auto and dom.is_Ring and (not dom.is_Field):
            F, G = (F.to_field(), G.to_field())
            retract = True
        if hasattr(f.rep, 'exquo'):
            try:
                q = F.exquo(G)
            except ExactQuotientFailed as exc:
                raise exc.new(f.as_expr(), g.as_expr())
        else:
            raise OperationNotSupported(f, 'exquo')
        if retract:
            try:
                q = q.to_ring()
            except CoercionFailed:
                pass
        return per(q)

    def _gen_to_level(f, gen):
        if isinstance(gen, int):
            length = len(f.gens)
            if -length <= gen < length:
                if gen < 0:
                    return length + gen
                else:
                    return gen
            else:
                raise PolynomialError('-%s <= gen < %s expected, got %s' % (length, length, gen))
        else:
            try:
                return f.gens.index(sympify(gen))
            except ValueError:
                raise PolynomialError('a valid generator expected, got %s' % gen)

    def degree(f, gen: int=0) -> int | NegativeInfinity:
        j = f._gen_to_level(gen)
        if hasattr(f.rep, 'degree'):
            d = f.rep.degree(j)
            if d < 0:
                return S.NegativeInfinity
            return d
        else:
            raise OperationNotSupported(f, 'degree')

    def degree_list(f) -> tuple[int | NegativeInfinity, ...]:
        if hasattr(f.rep, 'degree_list'):
            degrees = f.rep.degree_list()
            return tuple((d if d >= 0 else S.NegativeInfinity for d in degrees))
        else:
            raise OperationNotSupported(f, 'degree_list')

    def total_degree(f) -> int | NegativeInfinity:
        if hasattr(f.rep, 'total_degree'):
            d = f.rep.total_degree()
            return d if d >= 0 else S.NegativeInfinity
        else:
            raise OperationNotSupported(f, 'total_degree')

    def homogenize(f, s):
        if not isinstance(s, Symbol):
            raise TypeError('``Symbol`` expected, got %s' % type(s))
        if s in f.gens:
            i = f.gens.index(s)
            gens = f.gens
        else:
            i = len(f.gens)
            gens = f.gens + (s,)
        if hasattr(f.rep, 'homogenize'):
            return f.per(f.rep.homogenize(i), gens=gens)
        raise OperationNotSupported(f, 'homogeneous_order')

    def homogeneous_order(f):
        if hasattr(f.rep, 'homogeneous_order'):
            return f.rep.homogeneous_order()
        else:
            raise OperationNotSupported(f, 'homogeneous_order')

    def LC(f, order=None):
        if order is not None:
            return f.coeffs(order)[0]
        if hasattr(f.rep, 'LC'):
            result = f.rep.LC()
        else:
            raise OperationNotSupported(f, 'LC')
        return f.rep.dom.to_sympy(result)

    def TC(f):
        if hasattr(f.rep, 'TC'):
            result = f.rep.TC()
        else:
            raise OperationNotSupported(f, 'TC')
        return f.rep.dom.to_sympy(result)

    def EC(f, order=None):
        if hasattr(f.rep, 'coeffs'):
            return f.coeffs(order)[-1]
        else:
            raise OperationNotSupported(f, 'EC')

    def coeff_monomial(f, monom):
        return f.nth(*Monomial(monom, f.gens).exponents)

    def nth(f, *N):
        if hasattr(f.rep, 'nth'):
            if len(N) != len(f.gens):
                raise ValueError('exponent of each generator must be specified')
            result = f.rep.nth(*list(map(int, N)))
        else:
            raise OperationNotSupported(f, 'nth')
        return f.rep.dom.to_sympy(result)

    def coeff(f, x, n=1, right=False):
        raise NotImplementedError("Either convert to Expr with `as_expr` method to use Expr's coeff method or else use the `coeff_monomial` method of Polys.")

    def LM(f, order=None):
        return Monomial(f.monoms(order)[0], f.gens)

    def EM(f, order=None):
        return Monomial(f.monoms(order)[-1], f.gens)

    def LT(f, order=None):
        monom, coeff = f.terms(order)[0]
        return (Monomial(monom, f.gens), coeff)

    def ET(f, order=None):
        monom, coeff = f.terms(order)[-1]
        return (Monomial(monom, f.gens), coeff)

    def max_norm(f):
        if hasattr(f.rep, 'max_norm'):
            result = f.rep.max_norm()
        else:
            raise OperationNotSupported(f, 'max_norm')
        return f.rep.dom.to_sympy(result)

    def l1_norm(f):
        if hasattr(f.rep, 'l1_norm'):
            result = f.rep.l1_norm()
        else:
            raise OperationNotSupported(f, 'l1_norm')
        return f.rep.dom.to_sympy(result)

    def clear_denoms(self, convert=False):
        f = self
        if not f.rep.dom.is_Field:
            return (S.One, f)
        dom = f.get_domain()
        if dom.has_assoc_Ring:
            dom = f.rep.dom.get_ring()
        if hasattr(f.rep, 'clear_denoms'):
            coeff, result = f.rep.clear_denoms()
        else:
            raise OperationNotSupported(f, 'clear_denoms')
        coeff, f = (dom.to_sympy(coeff), f.per(result))
        if not convert or not dom.has_assoc_Ring:
            return (coeff, f)
        else:
            return (coeff, f.to_ring())

    def rat_clear_denoms(self, g):
        f = self
        dom, per, f, g = f._unify(g)
        f = per(f)
        g = per(g)
        if not (dom.is_Field and dom.has_assoc_Ring):
            return (f, g)
        a, f = f.clear_denoms(convert=True)
        b, g = g.clear_denoms(convert=True)
        f = f.mul_ground(b)
        g = g.mul_ground(a)
        return (f, g)

    def integrate(self, *specs, **args):
        f = self
        if args.get('auto', True) and f.rep.dom.is_Ring:
            f = f.to_field()
        if hasattr(f.rep, 'integrate'):
            if not specs:
                return f.per(f.rep.integrate(m=1))
            rep = f.rep
            for spec in specs:
                if isinstance(spec, tuple):
                    gen, m = spec
                else:
                    gen, m = (spec, 1)
                rep = rep.integrate(int(m), f._gen_to_level(gen))
            return f.per(rep)
        else:
            raise OperationNotSupported(f, 'integrate')

    def diff(f, *specs, **kwargs):
        if not kwargs.get('evaluate', True):
            return Derivative(f, *specs, **kwargs)
        if hasattr(f.rep, 'diff'):
            if not specs:
                return f.per(f.rep.diff(m=1))
            rep = f.rep
            for spec in specs:
                if isinstance(spec, tuple):
                    gen, m = spec
                else:
                    gen, m = (spec, 1)
                rep = rep.diff(int(m), f._gen_to_level(gen))
            return f.per(rep)
        else:
            raise OperationNotSupported(f, 'diff')
    _eval_derivative = diff

    def eval(self, x, a=None, auto=True):
        f = self
        if a is None:
            if isinstance(x, dict):
                mapping = x
                for gen, value in mapping.items():
                    f = f.eval(gen, value)
                return f
            elif isinstance(x, (tuple, list)):
                values = x
                if len(values) > len(f.gens):
                    raise ValueError('too many values provided')
                for gen, value in zip(f.gens, values):
                    f = f.eval(gen, value)
                return f
            else:
                j, a = (0, x)
        else:
            j = f._gen_to_level(x)
        if not hasattr(f.rep, 'eval'):
            raise OperationNotSupported(f, 'eval')
        try:
            result = f.rep.eval(a, j)
        except CoercionFailed:
            if not auto:
                raise DomainError('Cannot evaluate at %s in %s' % (a, f.rep.dom))
            else:
                a_domain, [a] = construct_domain([a])
                new_domain = f.get_domain().unify_with_symbols(a_domain, f.gens)
                f = f.set_domain(new_domain)
                a = new_domain.convert(a, a_domain)
                result = f.rep.eval(a, j)
        return f.per(result, remove=j)

    def __call__(f, *values):
        return f.eval(values)

    def half_gcdex(f, g, auto=True):
        dom, per, F, G = f._unify(g)
        if auto and dom.is_Ring:
            F, G = (F.to_field(), G.to_field())
        if hasattr(f.rep, 'half_gcdex'):
            s, h = F.half_gcdex(G)
        else:
            raise OperationNotSupported(f, 'half_gcdex')
        return (per(s), per(h))

    def gcdex(f, g, auto=True):
        dom, per, F, G = f._unify(g)
        if auto and dom.is_Ring:
            F, G = (F.to_field(), G.to_field())
        if hasattr(f.rep, 'gcdex'):
            s, t, h = F.gcdex(G)
        else:
            raise OperationNotSupported(f, 'gcdex')
        return (per(s), per(t), per(h))

    def invert(f, g: Poly, auto: bool=True) -> Poly:
        dom, per, F, G = f._unify(g)
        if auto and dom.is_Ring:
            F, G = (F.to_field(), G.to_field())
        if hasattr(f.rep, 'invert'):
            result = F.invert(G)
        else:
            raise OperationNotSupported(f, 'invert')
        return per(result)

    def revert(f, n: int) -> Poly:
        if hasattr(f.rep, 'revert'):
            result = f.rep.revert(int(n))
        else:
            raise OperationNotSupported(f, 'revert')
        return f.per(result)

    def subresultants(f, g):
        _, per, F, G = f._unify(g)
        if hasattr(f.rep, 'subresultants'):
            result = F.subresultants(G)
        else:
            raise OperationNotSupported(f, 'subresultants')
        return list(map(per, result))

    def resultant(f, g, includePRS=False):
        _, per, F, G = f._unify(g)
        if hasattr(f.rep, 'resultant'):
            if includePRS:
                result, R = F.resultant(G, includePRS=includePRS)
            else:
                result = F.resultant(G)
        else:
            raise OperationNotSupported(f, 'resultant')
        if includePRS:
            return (per(result, remove=0), list(map(per, R)))
        return per(result, remove=0)

    def discriminant(f):
        if hasattr(f.rep, 'discriminant'):
            result = f.rep.discriminant()
        else:
            raise OperationNotSupported(f, 'discriminant')
        return f.per(result, remove=0)

    def dispersionset(f, g=None):
        from sympy.polys.dispersion import dispersionset
        return dispersionset(f, g)

    def dispersion(f, g=None):
        from sympy.polys.dispersion import dispersion
        return dispersion(f, g)

    def cofactors(f, g):
        _, per, F, G = f._unify(g)
        if hasattr(f.rep, 'cofactors'):
            h, cff, cfg = F.cofactors(G)
        else:
            raise OperationNotSupported(f, 'cofactors')
        return (per(h), per(cff), per(cfg))

    def gcd(f, g: Poly | Expr | complex) -> Poly:
        _, per, F, G = f._unify(g)
        if hasattr(f.rep, 'gcd'):
            result = F.gcd(G)
        else:
            raise OperationNotSupported(f, 'gcd')
        return per(result)

    def lcm(f, g: Poly | Expr | complex) -> Poly:
        _, per, F, G = f._unify(g)
        if hasattr(f.rep, 'lcm'):
            result = F.lcm(G)
        else:
            raise OperationNotSupported(f, 'lcm')
        return per(result)

    def trunc(f, p: Expr | int) -> Poly:
        p = f.rep.dom.convert(p)
        if hasattr(f.rep, 'trunc'):
            result = f.rep.trunc(p)
        else:
            raise OperationNotSupported(f, 'trunc')
        return f.per(result)

    def monic(self, auto: bool=True) -> Poly:
        f = self
        if auto and f.rep.dom.is_Ring:
            f = f.to_field()
        if hasattr(f.rep, 'monic'):
            result = f.rep.monic()
        else:
            raise OperationNotSupported(f, 'monic')
        return f.per(result)

    def content(f):
        if hasattr(f.rep, 'content'):
            result = f.rep.content()
        else:
            raise OperationNotSupported(f, 'content')
        return f.rep.dom.to_sympy(result)

    def primitive(f):
        if hasattr(f.rep, 'primitive'):
            cont, result = f.rep.primitive()
        else:
            raise OperationNotSupported(f, 'primitive')
        return (f.rep.dom.to_sympy(cont), f.per(result))

    def compose(f, g: Poly | Expr) -> Poly:
        _, per, F, G = f._unify(g)
        if hasattr(f.rep, 'compose'):
            result = F.compose(G)
        else:
            raise OperationNotSupported(f, 'compose')
        return per(result)

    def decompose(f) -> list[Poly]:
        if hasattr(f.rep, 'decompose'):
            result = f.rep.decompose()
        else:
            raise OperationNotSupported(f, 'decompose')
        return list(map(f.per, result))

    def shift(f, a: Expr) -> Poly:
        return f.per(f.rep.shift(a))

    def shift_list(f, a: list[Expr]) -> Poly:
        return f.per(f.rep.shift_list(a))

    def transform(f, p: Poly, q: Poly) -> Poly:
        P, Q = p.unify(q)
        F, P = f.unify(P)
        F, Q = F.unify(Q)
        if hasattr(F.rep, 'transform'):
            result = F.rep.transform(P.rep, Q.rep)
        else:
            raise OperationNotSupported(F, 'transform')
        return F.per(result)

    def sturm(self, auto=True):
        f = self
        if auto and f.rep.dom.is_Ring:
            f = f.to_field()
        if hasattr(f.rep, 'sturm'):
            result = f.rep.sturm()
        else:
            raise OperationNotSupported(f, 'sturm')
        return list(map(f.per, result))

    def gff_list(f):
        if hasattr(f.rep, 'gff_list'):
            result = f.rep.gff_list()
        else:
            raise OperationNotSupported(f, 'gff_list')
        return [(f.per(g), k) for g, k in result]

    def norm(f):
        if hasattr(f.rep, 'norm'):
            r = f.rep.norm()
        else:
            raise OperationNotSupported(f, 'norm')
        return f.per(r)

    def sqf_norm(f):
        if hasattr(f.rep, 'sqf_norm'):
            s, g, r = f.rep.sqf_norm()
        else:
            raise OperationNotSupported(f, 'sqf_norm')
        return (s, f.per(g), f.per(r))

    def sqf_part(f):
        if hasattr(f.rep, 'sqf_part'):
            result = f.rep.sqf_part()
        else:
            raise OperationNotSupported(f, 'sqf_part')
        return f.per(result)

    def sqf_list(f, all=False):
        if hasattr(f.rep, 'sqf_list'):
            coeff, factors = f.rep.sqf_list(all)
        else:
            raise OperationNotSupported(f, 'sqf_list')
        return (f.rep.dom.to_sympy(coeff), [(f.per(g), k) for g, k in factors])

    def sqf_list_include(f, all=False):
        if hasattr(f.rep, 'sqf_list_include'):
            factors = f.rep.sqf_list_include(all)
        else:
            raise OperationNotSupported(f, 'sqf_list_include')
        return [(f.per(g), k) for g, k in factors]

    def factor_list(f) -> tuple[Expr, list[tuple[Poly, int]]]:
        if hasattr(f.rep, 'factor_list'):
            try:
                coeff, factors = f.rep.factor_list()
            except DomainError:
                if f.degree() == 0:
                    return (f.as_expr(), [])
                else:
                    return (S.One, [(f, 1)])
        else:
            raise OperationNotSupported(f, 'factor_list')
        return (f.rep.dom.to_sympy(coeff), [(f.per(g), k) for g, k in factors])

    def factor_list_include(f):
        if hasattr(f.rep, 'factor_list_include'):
            try:
                factors = f.rep.factor_list_include()
            except DomainError:
                return [(f, 1)]
        else:
            raise OperationNotSupported(f, 'factor_list_include')
        return [(f.per(g), k) for g, k in factors]

    def intervals(f, all=False, eps=None, inf=None, sup=None, fast=False, sqf=False):
        if eps is not None:
            eps = QQ.convert(eps)
            if eps <= 0:
                raise ValueError("'eps' must be a positive rational")
        if inf is not None:
            inf = QQ.convert(inf)
        if sup is not None:
            sup = QQ.convert(sup)
        if hasattr(f.rep, 'intervals'):
            result = f.rep.intervals(all=all, eps=eps, inf=inf, sup=sup, fast=fast, sqf=sqf)
        else:
            raise OperationNotSupported(f, 'intervals')
        if sqf:

            def _real(interval):
                s, t = interval
                return (QQ.to_sympy(s), QQ.to_sympy(t))
            if not all:
                return list(map(_real, result))

            def _complex(rectangle):
                (u, v), (s, t) = rectangle
                return (QQ.to_sympy(u) + I * QQ.to_sympy(v), QQ.to_sympy(s) + I * QQ.to_sympy(t))
            real_part, complex_part = result
            return (list(map(_real, real_part)), list(map(_complex, complex_part)))
        else:

            def _real(interval):
                (s, t), k = interval
                return ((QQ.to_sympy(s), QQ.to_sympy(t)), k)
            if not all:
                return list(map(_real, result))

            def _complex(rectangle):
                ((u, v), (s, t)), k = rectangle
                return ((QQ.to_sympy(u) + I * QQ.to_sympy(v), QQ.to_sympy(s) + I * QQ.to_sympy(t)), k)
            real_part, complex_part = result
            return (list(map(_real, real_part)), list(map(_complex, complex_part)))

    def refine_root(f, s, t, eps=None, steps=None, fast=False, check_sqf=False):
        if check_sqf and (not f.is_sqf):
            raise PolynomialError('only square-free polynomials supported')
        s, t = (QQ.convert(s), QQ.convert(t))
        if eps is not None:
            eps = QQ.convert(eps)
            if eps <= 0:
                raise ValueError("'eps' must be a positive rational")
        if steps is not None:
            steps = int(steps)
        elif eps is None:
            steps = 1
        if hasattr(f.rep, 'refine_root'):
            S, T = f.rep.refine_root(s, t, eps=eps, steps=steps, fast=fast)
        else:
            raise OperationNotSupported(f, 'refine_root')
        return (QQ.to_sympy(S), QQ.to_sympy(T))

    def count_roots(f, inf=None, sup=None):
        inf_real, sup_real = (True, True)
        if inf is not None:
            inf = sympify(inf)
            if inf is S.NegativeInfinity:
                inf = None
            else:
                re, im = inf.as_real_imag()
                if not im:
                    inf = QQ.convert(inf)
                else:
                    inf, inf_real = (list(map(QQ.convert, (re, im))), False)
        if sup is not None:
            sup = sympify(sup)
            if sup is S.Infinity:
                sup = None
            else:
                re, im = sup.as_real_imag()
                if not im:
                    sup = QQ.convert(sup)
                else:
                    sup, sup_real = (list(map(QQ.convert, (re, im))), False)
        if inf_real and sup_real:
            if hasattr(f.rep, 'count_real_roots'):
                count = f.rep.count_real_roots(inf=inf, sup=sup)
            else:
                raise OperationNotSupported(f, 'count_real_roots')
        else:
            if inf_real and inf is not None:
                inf = (inf, QQ.zero)
            if sup_real and sup is not None:
                sup = (sup, QQ.zero)
            if hasattr(f.rep, 'count_complex_roots'):
                count = f.rep.count_complex_roots(inf=inf, sup=sup)
            else:
                raise OperationNotSupported(f, 'count_complex_roots')
        return Integer(count)

    def root(f, index, radicals=True):
        return sympy.polys.rootoftools.rootof(f, index, radicals=radicals)

    def real_roots(f, multiple=True, radicals=True):
        reals = sympy.polys.rootoftools.CRootOf.real_roots(f, radicals=radicals)
        if multiple:
            return reals
        else:
            return group(reals, multiple=False)

    @overload
    def all_roots(f, multiple: Literal[True]=True, radicals: bool=True) -> list[Expr]:
        pass

    @overload
    def all_roots(f, multiple: Literal[False], *, radicals: bool=True) -> list[tuple[Expr, int]]:
        pass

    def all_roots(f, multiple: bool=True, radicals: bool=True) -> list[Expr] | list[tuple[Expr, int]]:
        roots = sympy.polys.rootoftools.CRootOf.all_roots(f, radicals=radicals)
        if multiple:
            return roots
        else:
            return group(roots, multiple=False)

    def nroots(f, n=15, maxsteps=50, cleanup=True):
        if f.is_multivariate:
            raise MultivariatePolynomialError('Cannot compute numerical roots of %s' % f)
        if f.degree() <= 0:
            return []
        if f.rep.dom is ZZ:
            coeffs = [int(coeff) for coeff in f.all_coeffs()]
        elif f.rep.dom is QQ:
            denoms = [coeff.q for coeff in f.all_coeffs()]
            fac = ilcm(*denoms)
            coeffs = [int(coeff * fac) for coeff in f.all_coeffs()]
        else:
            coeffs = [coeff.evalf(n=n).as_real_imag() for coeff in f.all_coeffs()]
            with local_workdps(n) as ctx:
                try:
                    coeffs = [ctx.mpc(*coeff) for coeff in coeffs]
                except TypeError:
                    raise DomainError('Numerical domain expected, got %s' % f.rep.dom)
        from sympy.functions.elementary.complexes import sign
        opts = {'maxsteps': maxsteps, 'cleanup': cleanup, 'error': False}
        from mpmath import __version__ as mpver
        if not any((mpver.startswith(prefix) for prefix in ('0.', '1.0.', '1.1.', '1.2.', '1.3.'))):
            opts['asc'] = True
            coeffs = coeffs[::-1]
        for prec in [f.degree() * 10, f.degree() * 15]:
            try:
                with local_workdps(n) as ctx:
                    roots = ctx.polyroots(coeffs, **opts, extraprec=prec)
                    key = lambda r: (1 if r.imag else 0, r.real, abs(r.imag), sign(r.imag))
                    roots = [sympify(r) for r in sorted(roots, key=key)]
                    break
            except NoConvergence:
                continue
        else:
            msg = 'convergence to root failed; try n < %s or maxsteps > %s'
            raise NoConvergence(msg % (n, maxsteps))
        return roots

    def ground_roots(f):
        if f.is_multivariate:
            raise MultivariatePolynomialError('Cannot compute ground roots of %s' % f)
        roots = {}
        for factor, k in f.factor_list()[1]:
            if factor.is_linear:
                a, b = factor.all_coeffs()
                roots[-b / a] = k
        return roots

    def nth_power_roots_poly(f, n):
        if f.is_multivariate:
            raise MultivariatePolynomialError('must be a univariate polynomial')
        N = sympify(n)
        if N.is_Integer and N >= 1:
            n = int(N)
        else:
            raise ValueError("'n' must an integer and n >= 1, got %s" % n)
        x = f.gen
        t = Dummy('t')
        r = f.resultant(f.__class__.from_expr(x ** n - t, x, t))
        return r.replace(t, x)

    def which_real_roots(f, candidates):
        if f.is_multivariate:
            raise MultivariatePolynomialError('Must be a univariate polynomial')
        dom = f.get_domain()
        if not (dom.is_ZZ or dom.is_QQ or dom.is_AlgebraicField):
            raise NotImplementedError('root counting not supported over %s' % dom)
        return f._which_roots(candidates, f.count_roots())

    def which_all_roots(f, candidates):
        if f.is_multivariate:
            raise MultivariatePolynomialError('Must be a univariate polynomial')
        return f._which_roots(candidates, f.degree())

    def _which_roots(f, candidates, num_roots):
        fe = f.as_expr()
        x = f.gens[0]
        prec = 10
        candidates = list(Counter(candidates).keys())
        while len(candidates) > num_roots:
            potential_candidates = []
            for r in candidates:
                f_r = fe.xreplace({x: r}).evalf(prec, maxn=2 * prec)
                if abs(f_r)._prec < 2:
                    potential_candidates.append(r)
            candidates = potential_candidates
            prec *= 2
        return candidates

    def same_root(f, a, b):
        if f.is_multivariate:
            raise MultivariatePolynomialError('Must be a univariate polynomial')
        dom_delta_sq = f.rep.mignotte_sep_bound_squared()
        delta_sq = f.domain.get_field().to_sympy(dom_delta_sq)
        eps_sq = delta_sq / 9
        r, _, _, _ = evalf(1 / eps_sq, 1, {})
        n = fastlog(r)
        m = n // 2 + n % 2
        ev = lambda x: quad_to_mpmath(_evalf_with_bounded_error(x, m=m))
        A, B = (ev(a), ev(b))
        return (A.real - B.real) ** 2 + (A.imag - B.imag) ** 2 < eps_sq

    def cancel(f, g, include=False):
        dom, per, F, G = f._unify(g)
        if hasattr(F, 'cancel'):
            result = F.cancel(G, include=include)
        else:
            raise OperationNotSupported(f, 'cancel')
        if not include:
            if dom.has_assoc_Ring:
                dom = dom.get_ring()
            cp, cq, p, q = result
            cp = dom.to_sympy(cp)
            cq = dom.to_sympy(cq)
            return (cp / cq, per(p), per(q))
        else:
            return tuple(map(per, result))

    def make_monic_over_integers_by_scaling_roots(f):
        if not f.is_univariate or f.domain not in [ZZ, QQ]:
            raise ValueError('Polynomial must be univariate over ZZ or QQ.')
        if f.is_monic and f.domain == ZZ:
            return (f, ZZ.one)
        else:
            fm = f.monic()
            c, _ = fm.clear_denoms()
            return (fm.transform(Poly(fm.gen), c).to_ring(), c)

    def galois_group(f, by_name=False, max_tries=30, randomize=False):
        from sympy.polys.numberfields.galoisgroups import _galois_group_degree_3, _galois_group_degree_4_lookup, _galois_group_degree_5_lookup_ext_factor, _galois_group_degree_6_lookup
        if not f.is_univariate or not f.is_irreducible or f.domain not in [ZZ, QQ]:
            raise ValueError('Polynomial must be irreducible and univariate over ZZ or QQ.')
        gg = {3: _galois_group_degree_3, 4: _galois_group_degree_4_lookup, 5: _galois_group_degree_5_lookup_ext_factor, 6: _galois_group_degree_6_lookup}
        max_supported = max(gg.keys())
        n = f.degree()
        if n > max_supported:
            raise ValueError(f'Only polynomials up to degree {max_supported} are supported.')
        elif n < 1:
            raise ValueError('Constant polynomial has no Galois group.')
        elif n == 1:
            from sympy.combinatorics.galois import S1TransitiveSubgroups
            name, alt = (S1TransitiveSubgroups.S1, True)
        elif n == 2:
            from sympy.combinatorics.galois import S2TransitiveSubgroups
            name, alt = (S2TransitiveSubgroups.S2, False)
        else:
            g, _ = f.make_monic_over_integers_by_scaling_roots()
            name, alt = gg[n](g, max_tries=max_tries, randomize=randomize)
        G = name if by_name else name.get_perm_group()
        return (G, alt)

    def hurwitz_conditions(f):
        conds = f.rep.hurwitz_conditions()
        return [f.domain.to_sympy(cond) for cond in conds]

    def schur_conditions(f):
        conds = f.rep.schur_conditions()
        return [f.domain.to_sympy(cond) for cond in conds]

    @property
    def is_zero(f):
        return f.rep.is_zero

    @property
    def is_one(f):
        return f.rep.is_one

    @property
    def is_sqf(f):
        return f.rep.is_sqf

    @property
    def is_monic(f):
        return f.rep.is_monic

    @property
    def is_primitive(f):
        return f.rep.is_primitive

    @property
    def is_ground(f):
        return f.rep.is_ground

    @property
    def is_linear(f):
        return f.rep.is_linear

    @property
    def is_quadratic(f):
        return f.rep.is_quadratic

    @property
    def is_monomial(f):
        return f.rep.is_monomial

    @property
    def is_homogeneous(f):
        return f.rep.is_homogeneous

    @property
    def is_irreducible(f):
        return f.rep.is_irreducible

    @property
    def is_univariate(f):
        return len(f.gens) == 1

    @property
    def is_multivariate(f):
        return len(f.gens) != 1

    @property
    def is_cyclotomic(f):
        return f.rep.is_cyclotomic

    def __abs__(f):
        return f.abs()

    def __neg__(f):
        return f.neg()

    @_polifyit
    def __add__(f, g):
        return f.add(g)

    @_polifyit
    def __radd__(f, g):
        return g.add(f)

    @_polifyit
    def __sub__(f, g):
        return f.sub(g)

    @_polifyit
    def __rsub__(f, g):
        return g.sub(f)

    @_polifyit
    def __mul__(f, g):
        return f.mul(g)

    @_polifyit
    def __rmul__(f, g):
        return g.mul(f)

    @_sympifyit('n', NotImplemented)
    def __pow__(f, n):
        if n.is_Integer and n >= 0:
            return f.pow(n)
        else:
            return NotImplemented

    @_polifyit
    def __divmod__(f, g):
        return f.div(g)

    @_polifyit
    def __rdivmod__(f, g):
        return g.div(f)

    @_polifyit
    def __mod__(f, g):
        return f.rem(g)

    @_polifyit
    def __rmod__(f, g):
        return g.rem(f)

    @_polifyit
    def __floordiv__(f, g):
        return f.quo(g)

    @_polifyit
    def __rfloordiv__(f, g):
        return g.quo(f)

    @_sympifyit('g', NotImplemented)
    def __truediv__(f, g):
        return f.as_expr() / g.as_expr()

    @_sympifyit('g', NotImplemented)
    def __rtruediv__(f, g):
        return g.as_expr() / f.as_expr()

    @_sympifyit('other', NotImplemented)
    def __eq__(self, other):
        f, g = (self, other)
        if not g.is_Poly:
            try:
                g = f.__class__(g, f.gens, domain=f.get_domain())
            except (PolynomialError, DomainError, CoercionFailed):
                return False
        if f.gens != g.gens:
            return False
        if f.rep.dom != g.rep.dom:
            return False
        return f.rep == g.rep

    @_sympifyit('g', NotImplemented)
    def __ne__(f, g):
        return not f == g

    def __bool__(f):
        return not f.is_zero

    def eq(f, g, strict=False):
        if not strict:
            return f == g
        else:
            return f._strict_eq(sympify(g))

    def ne(f, g, strict=False):
        return not f.eq(g, strict=strict)

    def _strict_eq(f, g):
        return isinstance(g, f.__class__) and f.gens == g.gens and f.rep.eq(g.rep, strict=True)

@public
class PurePoly(Poly):

    def _hashable_content(self):
        return (self.rep,)

    def __hash__(self):
        return super().__hash__()

    @property
    def free_symbols(self):
        return self.free_symbols_in_domain

    @_sympifyit('other', NotImplemented)
    def __eq__(self, other):
        f, g = (self, other)
        if not g.is_Poly:
            try:
                g = f.__class__(g, f.gens, domain=f.get_domain())
            except (PolynomialError, DomainError, CoercionFailed):
                return False
        if len(f.gens) != len(g.gens):
            return False
        if f.rep.dom != g.rep.dom:
            try:
                dom = f.rep.dom.unify(g.rep.dom, f.gens)
            except UnificationFailed:
                return False
            f = f.set_domain(dom)
            g = g.set_domain(dom)
        return f.rep == g.rep

    def _strict_eq(f, g):
        return isinstance(g, f.__class__) and f.rep.eq(g.rep, strict=True)

    def _unify(f, g):
        g = sympify(g)
        if not g.is_Poly:
            try:
                return (f.rep.dom, f.per, f.rep, f.rep.per(f.rep.dom.from_sympy(g)))
            except CoercionFailed:
                raise UnificationFailed('Cannot unify %s with %s' % (f, g))
        if len(f.gens) != len(g.gens):
            raise UnificationFailed('Cannot unify %s with %s' % (f, g))
        if not (isinstance(f.rep, DMP) and isinstance(g.rep, DMP)):
            raise UnificationFailed('Cannot unify %s with %s' % (f, g))
        cls = f.__class__
        gens = f.gens
        dom = f.rep.dom.unify(g.rep.dom, gens)
        F = f.rep.convert(dom)
        G = g.rep.convert(dom)

        def per(rep, dom=dom, gens=gens, remove=None):
            if remove is not None:
                gens = gens[:remove] + gens[remove + 1:]
                if not gens:
                    return dom.to_sympy(rep)
            return cls.new(rep, *gens)
        return (dom, per, F, G)

@public
def poly_from_expr(expr, *gens, **args):
    opt = options.build_options(gens, args)
    return _poly_from_expr(expr, opt)

def _poly_from_expr(expr, opt):
    orig, expr = (expr, sympify(expr))
    if not isinstance(expr, Basic):
        raise PolificationFailed(opt, orig, expr)
    elif expr.is_Poly:
        poly = expr.__class__._from_poly(expr, opt)
        opt.gens = poly.gens
        opt.domain = poly.domain
        if opt.polys is None:
            opt.polys = True
        return (poly, opt)
    elif opt.expand:
        expr = expr.expand()
    rep, opt = _dict_from_expr(expr, opt)
    if not opt.gens:
        raise PolificationFailed(opt, orig, expr)
    monoms, coeffs = list(zip(*list(rep.items())))
    domain = opt.domain
    if domain is None:
        opt.domain, coeffs = construct_domain(coeffs, opt=opt)
    else:
        coeffs = list(map(domain.from_sympy, coeffs))
    rep = dict(list(zip(monoms, coeffs)))
    poly = Poly._from_dict(rep, opt)
    if opt.polys is None:
        opt.polys = False
    return (poly, opt)

@public
def parallel_poly_from_expr(exprs, *gens, **args):
    opt = options.build_options(gens, args)
    return _parallel_poly_from_expr(exprs, opt)

def _parallel_poly_from_expr(exprs, opt):
    if len(exprs) == 2:
        f, g = exprs
        if isinstance(f, Poly) and isinstance(g, Poly):
            f = f.__class__._from_poly(f, opt)
            g = g.__class__._from_poly(g, opt)
            f, g = f.unify(g)
            opt.gens = f.gens
            opt.domain = f.domain
            if opt.polys is None:
                opt.polys = True
            return ([f, g], opt)
    origs, exprs = (list(exprs), [])
    _exprs, _polys = ([], [])
    failed = False
    for i, expr in enumerate(origs):
        expr = sympify(expr)
        if isinstance(expr, Basic):
            if expr.is_Poly:
                _polys.append(i)
            else:
                _exprs.append(i)
                if opt.expand:
                    expr = expr.expand()
        else:
            failed = True
        exprs.append(expr)
    if failed:
        raise PolificationFailed(opt, origs, exprs, True)
    if _polys:
        for i in _polys:
            exprs[i] = exprs[i].as_expr()
    reps, opt = _parallel_dict_from_expr(exprs, opt)
    if not opt.gens:
        raise PolificationFailed(opt, origs, exprs, True)
    from sympy.functions.elementary.piecewise import Piecewise
    for k in opt.gens:
        if isinstance(k, Piecewise):
            raise PolynomialError('Piecewise generators do not make sense')
    coeffs_list, lengths = ([], [])
    all_monoms = []
    all_coeffs = []
    for rep in reps:
        monoms, coeffs = list(zip(*list(rep.items())))
        coeffs_list.extend(coeffs)
        all_monoms.append(monoms)
        lengths.append(len(coeffs))
    domain = opt.domain
    if domain is None:
        opt.domain, coeffs_list = construct_domain(coeffs_list, opt=opt)
    else:
        coeffs_list = list(map(domain.from_sympy, coeffs_list))
    for k in lengths:
        all_coeffs.append(coeffs_list[:k])
        coeffs_list = coeffs_list[k:]
    polys = []
    for monoms, coeffs in zip(all_monoms, all_coeffs):
        rep = dict(list(zip(monoms, coeffs)))
        poly = Poly._from_dict(rep, opt)
        polys.append(poly)
    if opt.polys is None:
        opt.polys = bool(_polys)
    return (polys, opt)

def _update_args(args, key, value):
    args = dict(args)
    if key not in args:
        args[key] = value
    return args

@public
def degree(f, gen=0):
    _degree = lambda x: Integer(x) if type(x) is int else x
    f = sympify(f, strict=True)
    if type(gen) is int:
        if isinstance(f, Poly):
            return _degree(f.degree(gen))
        if f.is_Number:
            return S.NegativeInfinity if f.is_zero else S.Zero
        try:
            p = Poly(f, expand=False)
        except GeneratorsNeeded:
            gens = ()
        else:
            gens = p.gens
        free = f.free_symbols
        if not (gen == 0 and len(gens) == 1 and (len(free) < 2) and f.is_polynomial((gen := next(iter(gens)))) and gen.is_Atom):
            raise TypeError(filldedent('\n                To avoid ambiguity, this expression requires either\n                a symbol (not int) generator or a Poly (which identifies\n                the generators).'))
        return p.degree(gen)
    gen = sympify(gen, strict=True)
    if not isinstance(f, Poly) or gen not in f.gens:
        f = poly_from_expr(f, gen)[0]
    return _degree(f.degree(gen))

@public
def total_degree(f, *gens):
    p = sympify(f)
    if p.is_Poly:
        p = p.as_expr()
    if p.is_Number:
        rv = 0
    else:
        if f.is_Poly:
            gens = gens or f.gens
        rv = Poly(p, gens).total_degree()
    return Integer(rv)

@public
def degree_list(f, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('degree_list', 1, exc)
    degrees = F.degree_list()
    return tuple(map(Integer, degrees))

@public
def LC(f, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('LC', 1, exc)
    return F.LC(order=opt.order)

@public
def LM(f, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('LM', 1, exc)
    monom = F.LM(order=opt.order)
    return monom.as_expr()

@public
def LT(f, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('LT', 1, exc)
    monom, coeff = F.LT(order=opt.order)
    return coeff * monom.as_expr()

@public
def pdiv(f, g, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('pdiv', 2, exc)
    q, r = F.pdiv(G)
    if not opt.polys:
        return (q.as_expr(), r.as_expr())
    else:
        return (q, r)

@public
def prem(f, g, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('prem', 2, exc)
    r = F.prem(G)
    if not opt.polys:
        return r.as_expr()
    else:
        return r

@public
def pquo(f, g, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('pquo', 2, exc)
    try:
        q = F.pquo(G)
    except ExactQuotientFailed:
        raise ExactQuotientFailed(f, g)
    if not opt.polys:
        return q.as_expr()
    else:
        return q

@public
def pexquo(f, g, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('pexquo', 2, exc)
    q = F.pexquo(G)
    if not opt.polys:
        return q.as_expr()
    else:
        return q

@public
def div(f, g, *gens, **args):
    options.allowed_flags(args, ['auto', 'polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('div', 2, exc)
    q, r = F.div(G, auto=opt.auto)
    if not opt.polys:
        return (q.as_expr(), r.as_expr())
    else:
        return (q, r)

@public
def rem(f, g, *gens, **args):
    options.allowed_flags(args, ['auto', 'polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('rem', 2, exc)
    r = F.rem(G, auto=opt.auto)
    if not opt.polys:
        return r.as_expr()
    else:
        return r

@public
def quo(f, g, *gens, **args):
    options.allowed_flags(args, ['auto', 'polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('quo', 2, exc)
    q = F.quo(G, auto=opt.auto)
    if not opt.polys:
        return q.as_expr()
    else:
        return q

@public
def exquo(f, g, *gens, **args):
    options.allowed_flags(args, ['auto', 'polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('exquo', 2, exc)
    q = F.exquo(G, auto=opt.auto)
    if not opt.polys:
        return q.as_expr()
    else:
        return q

@public
def half_gcdex(f, g, *gens, **args):
    options.allowed_flags(args, ['auto', 'polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        domain, (a, b) = construct_domain(exc.exprs)
        try:
            s, h = domain.half_gcdex(a, b)
        except NotImplementedError:
            raise ComputationFailed('half_gcdex', 2, exc)
        else:
            return (domain.to_sympy(s), domain.to_sympy(h))
    s, h = F.half_gcdex(G, auto=opt.auto)
    if not opt.polys:
        return (s.as_expr(), h.as_expr())
    else:
        return (s, h)

def _gcdex_steps_domain(a, b, K):
    if not K.is_PID:
        raise DomainError('gcdex_steps is only for Euclidean domains')
    s1, s2 = (K.one, K.zero)
    t1, t2 = (K.zero, K.one)
    while b:
        yield (s2, t2, b)
        quotient, remainder = K.div(a, b)
        a, b = (b, remainder)
        s1, s2 = (s2, s1 - quotient * s2)
        t1, t2 = (t2, t1 - quotient * t2)

def _gcdex_steps_polynomial(f, g, auto):
    if auto and f.domain.is_Ring:
        f, g = (f.to_field(), g.to_field())
    if not f.domain.is_Field:
        raise DomainError('gcdex_steps is only for Euclidean domains')
    if not f.is_univariate:
        raise ValueError('univariate polynomial expected')
    s1, s2 = (f.one, f.zero)
    t1, t2 = (f.zero, f.one)
    r1, r2 = (f, g)
    if f.degree() < g.degree():
        s1, t1 = (t1, s1)
        s2, t2 = (t2, s2)
        r1, r2 = (r2, r1)
    for _ in range(max(f.degree(), g.degree()) + 1):
        yield (s2, t2, r2)
        quotient, remainder = divmod(r1, r2)
        if remainder == 0:
            break
        r1, r2 = (r2, remainder)
        s1, s2 = (s2, s1 - quotient * s2)
        t1, t2 = (t2, t1 - quotient * t2)

@overload
def gcdex_steps(f: Expr, g: Expr, *gens: Expr, polys: Literal[False]=False, **args: Any) -> Iterator[tuple[Expr, Expr, Expr]]:
    pass

@overload
def gcdex_steps(f: Expr, g: Expr, *gens: Expr, polys: Literal[True], **args: Any) -> Iterator[tuple[Poly, Poly, Poly]]:
    pass

@overload
def gcdex_steps(f: Poly, g: Poly, *gens: Expr, **args: Any) -> Iterator[tuple[Poly, Poly, Poly]]:
    pass

@public
def gcdex_steps(f: Expr | Poly, g: Expr | Poly, *gens: Expr, **args: Any) -> Iterator[tuple[Expr, Expr, Expr]] | Iterator[tuple[Poly, Poly, Poly]]:
    options.allowed_flags(args, ['auto', 'polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        domain, (a, b) = construct_domain(exc.exprs)
        try:
            for s, t, r in _gcdex_steps_domain(a, b, domain):
                yield (domain.to_sympy(s), domain.to_sympy(t), domain.to_sympy(r))
            return
        except DomainError as exc:
            raise ComputationFailed('gcdex_steps', 2, exc)
    for s, t, r in _gcdex_steps_polynomial(F, G, auto=opt.auto):
        if opt.polys:
            yield (s, t, r)
        else:
            yield (s.as_expr(), t.as_expr(), r.as_expr())

@public
def gcdex(f, g, *gens, **args):
    options.allowed_flags(args, ['auto', 'polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        domain, (a, b) = construct_domain(exc.exprs)
        try:
            s, t, h = domain.gcdex(a, b)
        except NotImplementedError:
            raise ComputationFailed('gcdex', 2, exc)
        else:
            return (domain.to_sympy(s), domain.to_sympy(t), domain.to_sympy(h))
    s, t, h = F.gcdex(G, auto=opt.auto)
    if not opt.polys:
        return (s.as_expr(), t.as_expr(), h.as_expr())
    else:
        return (s, t, h)

@public
def invert(f, g, *gens, **args):
    options.allowed_flags(args, ['auto', 'polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        domain, (a, b) = construct_domain(exc.exprs)
        try:
            return domain.to_sympy(domain.invert(a, b))
        except NotImplementedError:
            raise ComputationFailed('invert', 2, exc)
    h = F.invert(G, auto=opt.auto)
    if not opt.polys:
        return h.as_expr()
    else:
        return h

@public
def subresultants(f, g, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('subresultants', 2, exc)
    result = F.subresultants(G)
    if not opt.polys:
        return [r.as_expr() for r in result]
    else:
        return result

@public
def resultant(f, g, *gens, includePRS=False, **args):
    options.allowed_flags(args, ['polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('resultant', 2, exc)
    if includePRS:
        result, R = F.resultant(G, includePRS=includePRS)
    else:
        result = F.resultant(G)
    if not opt.polys:
        if includePRS:
            return (result.as_expr(), [r.as_expr() for r in R])
        return result.as_expr()
    else:
        if includePRS:
            return (result, R)
        return result

@public
def discriminant(f, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('discriminant', 1, exc)
    result = F.discriminant()
    if not opt.polys:
        return result.as_expr()
    else:
        return result

@public
def cofactors(f, g, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        domain, (a, b) = construct_domain(exc.exprs)
        try:
            h, cff, cfg = domain.cofactors(a, b)
        except NotImplementedError:
            raise ComputationFailed('cofactors', 2, exc)
        else:
            return (domain.to_sympy(h), domain.to_sympy(cff), domain.to_sympy(cfg))
    h, cff, cfg = F.cofactors(G)
    if not opt.polys:
        return (h.as_expr(), cff.as_expr(), cfg.as_expr())
    else:
        return (h, cff, cfg)

@public
def gcd_list(seq, *gens, **args):
    seq = sympify(seq)

    def try_non_polynomial_gcd(seq):
        if not gens and (not args):
            domain, numbers = construct_domain(seq)
            if not numbers:
                return domain.zero
            elif domain.is_Numerical:
                result, numbers = (numbers[0], numbers[1:])
                for number in numbers:
                    result = domain.gcd(result, number)
                    if domain.is_one(result):
                        break
                return domain.to_sympy(result)
        return None
    result = try_non_polynomial_gcd(seq)
    if result is not None:
        return result
    options.allowed_flags(args, ['polys'])
    try:
        polys, opt = parallel_poly_from_expr(seq, *gens, **args)
        if len(seq) > 1 and all((elt.is_algebraic and elt.is_irrational for elt in seq)):
            a = seq[-1]
            lst = [(a / elt).ratsimp() for elt in seq[:-1]]
            if all((frc.is_rational for frc in lst)):
                lc = 1
                for frc in lst:
                    lc = lcm(lc, frc.as_numer_denom()[0])
                return abs(a / lc)
    except PolificationFailed as exc:
        result = try_non_polynomial_gcd(exc.exprs)
        if result is not None:
            return result
        else:
            raise ComputationFailed('gcd_list', len(seq), exc)
    if not polys:
        if not opt.polys:
            return S.Zero
        else:
            return Poly(0, opt=opt)
    result, polys = (polys[0], polys[1:])
    for poly in polys:
        result = result.gcd(poly)
        if result.is_one:
            break
    if not opt.polys:
        return result.as_expr()
    else:
        return result

@public
def gcd(f, g=None, *gens, **args):
    if hasattr(f, '__iter__'):
        if g is not None:
            gens = (g,) + gens
        return gcd_list(f, *gens, **args)
    elif g is None:
        raise TypeError('gcd() takes 2 arguments or a sequence of arguments')
    options.allowed_flags(args, ['polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
        a, b = map(sympify, (f, g))
        if a.is_algebraic and a.is_irrational and b.is_algebraic and b.is_irrational:
            frc = (a / b).ratsimp()
            if frc.is_rational:
                return abs(a / frc.as_numer_denom()[0])
    except PolificationFailed as exc:
        domain, (a, b) = construct_domain(exc.exprs)
        try:
            return domain.to_sympy(domain.gcd(a, b))
        except NotImplementedError:
            raise ComputationFailed('gcd', 2, exc)
    result = F.gcd(G)
    if not opt.polys:
        return result.as_expr()
    else:
        return result

@public
def lcm_list(seq, *gens, **args):
    seq = sympify(seq)

    def try_non_polynomial_lcm(seq) -> Expr | None:
        if not gens and (not args):
            domain, numbers = construct_domain(seq)
            if not numbers:
                return domain.to_sympy(domain.one)
            elif domain.is_Numerical:
                result, numbers = (numbers[0], numbers[1:])
                for number in numbers:
                    result = domain.lcm(result, number)
                return domain.to_sympy(result)
        return None
    result = try_non_polynomial_lcm(seq)
    if result is not None:
        return result
    options.allowed_flags(args, ['polys'])
    try:
        polys, opt = parallel_poly_from_expr(seq, *gens, **args)
        if len(seq) > 1 and all((elt.is_algebraic and elt.is_irrational for elt in seq)):
            a = seq[-1]
            lst = [(a / elt).ratsimp() for elt in seq[:-1]]
            if all((frc.is_rational for frc in lst)):
                lc = 1
                for frc in lst:
                    lc = lcm(lc, frc.as_numer_denom()[1])
                return a * lc
    except PolificationFailed as exc:
        result = try_non_polynomial_lcm(exc.exprs)
        if result is not None:
            return result
        else:
            raise ComputationFailed('lcm_list', len(seq), exc)
    if not polys:
        if not opt.polys:
            return S.One
        else:
            return Poly(1, opt=opt)
    result, polys = (polys[0], polys[1:])
    for poly in polys:
        result = result.lcm(poly)
    if not opt.polys:
        return result.as_expr()
    else:
        return result

@public
def lcm(f, g=None, *gens, **args):
    if hasattr(f, '__iter__'):
        if g is not None:
            gens = (g,) + gens
        return lcm_list(f, *gens, **args)
    elif g is None:
        raise TypeError('lcm() takes 2 arguments or a sequence of arguments')
    options.allowed_flags(args, ['polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
        a, b = map(sympify, (f, g))
        if a.is_algebraic and a.is_irrational and b.is_algebraic and b.is_irrational:
            frc = (a / b).ratsimp()
            if frc.is_rational:
                return a * frc.as_numer_denom()[1]
    except PolificationFailed as exc:
        domain, (a, b) = construct_domain(exc.exprs)
        try:
            return domain.to_sympy(domain.lcm(a, b))
        except NotImplementedError:
            raise ComputationFailed('lcm', 2, exc)
    result = F.lcm(G)
    if not opt.polys:
        return result.as_expr()
    else:
        return result

@public
def terms_gcd(f, *gens, **args):
    orig = sympify(f)
    if isinstance(f, Equality):
        return Equality(*(terms_gcd(s, *gens, **args) for s in [f.lhs, f.rhs]))
    elif isinstance(f, Relational):
        raise TypeError('Inequalities cannot be used with terms_gcd. Found: %s' % (f,))
    if not isinstance(f, Expr) or f.is_Atom:
        return orig
    if args.get('deep', False):
        new = f.func(*[terms_gcd(a, *gens, **args) for a in f.args])
        args.pop('deep')
        args['expand'] = False
        return terms_gcd(new, *gens, **args)
    clear = args.pop('clear', True)
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        return exc.expr
    J, f = F.terms_gcd()
    if opt.domain.is_Ring:
        if opt.domain.is_Field:
            denom, f = f.clear_denoms(convert=True)
        coeff, f = f.primitive()
        if opt.domain.is_Field:
            coeff /= denom
    else:
        coeff = S.One
    term = Mul(*[x ** j for x, j in zip(f.gens, J)])
    if equal_valued(coeff, 1):
        coeff = S.One
        if term == 1:
            return orig
    if clear:
        return _keep_coeff(coeff, term * f.as_expr())
    coeff, f = _keep_coeff(coeff, f.as_expr(), clear=False).as_coeff_Mul()
    return _keep_coeff(coeff, term * f, clear=False)

@public
def trunc(f, p, *gens, **args):
    options.allowed_flags(args, ['auto', 'polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('trunc', 1, exc)
    result = F.trunc(sympify(p))
    if not opt.polys:
        return result.as_expr()
    else:
        return result

@public
def monic(f, *gens, **args):
    options.allowed_flags(args, ['auto', 'polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('monic', 1, exc)
    result = F.monic(auto=opt.auto)
    if not opt.polys:
        return result.as_expr()
    else:
        return result

@public
def content(f, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('content', 1, exc)
    return F.content()

@public
def primitive(f, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('primitive', 1, exc)
    cont, result = F.primitive()
    if not opt.polys:
        return (cont, result.as_expr())
    else:
        return (cont, result)

@public
def compose(f, g, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        (F, G), opt = parallel_poly_from_expr((f, g), *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('compose', 2, exc)
    result = F.compose(G)
    if not opt.polys:
        return result.as_expr()
    else:
        return result

@public
def decompose(f, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('decompose', 1, exc)
    result = F.decompose()
    if not opt.polys:
        return [r.as_expr() for r in result]
    else:
        return result

@public
def sturm(f, *gens, **args):
    options.allowed_flags(args, ['auto', 'polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('sturm', 1, exc)
    result = F.sturm(auto=opt.auto)
    if not opt.polys:
        return [r.as_expr() for r in result]
    else:
        return result

@public
def gff_list(f, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('gff_list', 1, exc)
    factors = F.gff_list()
    if not opt.polys:
        return [(g.as_expr(), k) for g, k in factors]
    else:
        return factors

@public
def gff(f, *gens, **args):
    raise NotImplementedError('symbolic falling factorial')

@public
def sqf_norm(f, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('sqf_norm', 1, exc)
    s, g, r = F.sqf_norm()
    s_expr = [Integer(si) for si in s]
    if not opt.polys:
        return (s_expr, g.as_expr(), r.as_expr())
    else:
        return (s_expr, g, r)

@public
def sqf_part(f, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('sqf_part', 1, exc)
    result = F.sqf_part()
    if not opt.polys:
        return result.as_expr()
    else:
        return result

def _poly_sort_key(poly):
    rep = poly.rep.to_list()
    return (len(rep), len(poly.gens), str(poly.domain), rep)

def _sorted_factors(factors, method):
    if method == 'sqf':

        def key(obj):
            poly, exp = obj
            rep = poly.rep.to_list()
            return (exp, len(rep), len(poly.gens), str(poly.domain), rep)
    else:

        def key(obj):
            poly, exp = obj
            rep = poly.rep.to_list()
            return (len(rep), len(poly.gens), exp, str(poly.domain), rep)
    return sorted(factors, key=key)

def _factors_product(factors):
    return Mul(*[f.as_expr() ** k for f, k in factors])

def _symbolic_factor_list(expr, opt, method):
    coeff, factors = (S.One, [])
    args = [i._eval_factor() if hasattr(i, '_eval_factor') else i for i in Mul.make_args(expr)]
    for arg in args:
        if arg.is_Number or (isinstance(arg, Expr) and pure_complex(arg)):
            coeff *= arg
            continue
        elif arg.is_Pow and arg.base != S.Exp1:
            base, exp = arg.args
            if base.is_Number and exp.is_Number:
                coeff *= arg
                continue
            if base.is_Number:
                factors.append((base, exp))
                continue
        else:
            base, exp = (arg, S.One)
        try:
            poly, _ = _poly_from_expr(base, opt)
        except PolificationFailed as exc:
            factors.append((exc.expr, exp))
        else:
            func = getattr(poly, method + '_list')
            _coeff, _factors = func()
            if _coeff is not S.One:
                if exp.is_Integer:
                    coeff *= _coeff ** exp
                elif _coeff.is_positive:
                    factors.append((_coeff, exp))
                else:
                    _factors.append((_coeff, S.One))
            if exp is S.One:
                factors.extend(_factors)
            elif exp.is_integer:
                factors.extend([(f, k * exp) for f, k in _factors])
            else:
                other = []
                for f, k in _factors:
                    if f.as_expr().is_positive:
                        factors.append((f, k * exp))
                    else:
                        other.append((f, k))
                factors.append((_factors_product(other), exp))
    if method == 'sqf':
        factors = [(reduce(mul, (f for f, _ in factors if _ == k)), k) for k in {i for _, i in factors}]
    rv = defaultdict(int)
    for k, v in factors:
        rv[k] += v
    return (coeff, list(rv.items()))

def _symbolic_factor(expr, opt, method):
    if isinstance(expr, Expr):
        if hasattr(expr, '_eval_factor'):
            return expr._eval_factor()
        coeff, factors = _symbolic_factor_list(together(expr, fraction=opt['fraction']), opt, method)
        return _keep_coeff(coeff, _factors_product(factors))
    elif hasattr(expr, 'args'):
        return expr.func(*[_symbolic_factor(arg, opt, method) for arg in expr.args])
    elif hasattr(expr, '__iter__'):
        return expr.__class__([_symbolic_factor(arg, opt, method) for arg in expr])
    else:
        return expr

def _generic_factor_list(expr, gens, args, method):
    options.allowed_flags(args, ['frac', 'polys'])
    opt = options.build_options(gens, args)
    expr = sympify(expr)
    if isinstance(expr, (Expr, Poly)):
        if isinstance(expr, Poly):
            numer, denom = (expr, 1)
        else:
            numer, denom = together(expr).as_numer_denom()
        cp, fp = _symbolic_factor_list(numer, opt, method)
        cq, fq = _symbolic_factor_list(denom, opt, method)
        if fq and (not opt.frac):
            raise PolynomialError('a polynomial expected, got %s' % expr)
        _opt = opt.clone({'expand': True})
        for factors in (fp, fq):
            for i, (f, k) in enumerate(factors):
                if not f.is_Poly:
                    f, _ = _poly_from_expr(f, _opt)
                    factors[i] = (f, k)
        fp = _sorted_factors(fp, method)
        fq = _sorted_factors(fq, method)
        if not opt.polys:
            fp = [(f.as_expr(), k) for f, k in fp]
            fq = [(f.as_expr(), k) for f, k in fq]
        coeff = cp / cq
        if not opt.frac:
            return (coeff, fp)
        else:
            return (coeff, fp, fq)
    else:
        raise PolynomialError('a polynomial expected, got %s' % expr)

def _generic_factor(expr, gens, args, method):
    fraction = args.pop('fraction', True)
    options.allowed_flags(args, [])
    opt = options.build_options(gens, args)
    opt['fraction'] = fraction
    return _symbolic_factor(sympify(expr), opt, method)

def to_rational_coeffs(f):
    from sympy.simplify.simplify import simplify

    def _try_rescale(f, f1=None):
        if not len(f.gens) == 1 or not f.gens[0].is_Atom:
            return (None, f)
        n = f.degree()
        lc = f.LC()
        f1 = f1 or f1.monic()
        coeffs = f1.all_coeffs()[1:]
        coeffs = [simplify(coeffx) for coeffx in coeffs]
        if len(coeffs) > 1 and coeffs[-2]:
            rescale1_x = simplify(coeffs[-2] / coeffs[-1])
            coeffs1 = []
            for i in range(len(coeffs)):
                coeffx = simplify(coeffs[i] * rescale1_x ** (i + 1))
                if not coeffx.is_rational:
                    break
                coeffs1.append(coeffx)
            else:
                rescale_x = simplify(1 / rescale1_x)
                x = f.gens[0]
                v = [x ** n]
                for i in range(1, n + 1):
                    v.append(coeffs1[i - 1] * x ** (n - i))
                f = Add(*v)
                f = Poly(f)
                return (lc, rescale_x, f)
        return None

    def _try_translate(f, f1=None):
        if not len(f.gens) == 1 or not f.gens[0].is_Atom:
            return (None, f)
        n = f.degree()
        f1 = f1 or f1.monic()
        coeffs = f1.all_coeffs()[1:]
        c = simplify(coeffs[0])
        if c.is_Add and (not c.is_rational):
            rat, nonrat = sift(c.args, lambda z: z.is_rational is True, binary=True)
            alpha = -c.func(*nonrat) / n
            f2 = f1.shift(alpha)
            return (alpha, f2)
        return None

    def _has_square_roots(p):
        coeffs = p.coeffs()
        has_sq = False
        for y in coeffs:
            for x in Add.make_args(y):
                f = Factors(x).factors
                r = [wx.q for b, wx in f.items() if b.is_number and wx.is_Rational and (wx.q >= 2)]
                if not r:
                    continue
                if min(r) == 2:
                    has_sq = True
                if max(r) > 2:
                    return False
        return has_sq
    if f.get_domain().is_EX and _has_square_roots(f):
        f1 = f.monic()
        r = _try_rescale(f, f1)
        if r:
            return (r[0], r[1], None, r[2])
        else:
            r = _try_translate(f, f1)
            if r:
                return (None, None, r[0], r[1])
    return None

def _torational_factor_list(p, x):
    from sympy.simplify.simplify import simplify
    p1 = Poly(p, x, domain='EX')
    n = p1.degree()
    res = to_rational_coeffs(p1)
    if not res:
        return None
    lc, r, t, g = res
    factors = factor_list(g.as_expr())
    if lc:
        c = simplify(factors[0] * lc * r ** n)
        r1 = simplify(1 / r)
        a = []
        for z in factors[1:][0]:
            a.append((simplify(z[0].subs({x: x * r1})), z[1]))
    else:
        c = factors[0]
        a = []
        for z in factors[1:][0]:
            a.append((z[0].subs({x: x - t}), z[1]))
    return (c, a)

@public
def sqf_list(f, *gens, **args):
    return _generic_factor_list(f, gens, args, method='sqf')

@public
def sqf(f, *gens, **args):
    return _generic_factor(f, gens, args, method='sqf')

@public
def factor_list(f, *gens, **args):
    return _generic_factor_list(f, gens, args, method='factor')

@public
def factor(f, *gens, deep=False, **args):
    f = sympify(f)
    if deep:

        def _try_factor(expr):
            fac = factor(expr, *gens, **args)
            if fac.is_Mul or fac.is_Pow:
                return fac
            return expr
        f = bottom_up(f, _try_factor)
        partials = {}
        muladd = f.atoms(Mul, Add)
        for p in muladd:
            fac = factor(p, *gens, **args)
            if (fac.is_Mul or fac.is_Pow) and fac != p:
                partials[p] = fac
        return f.xreplace(partials)
    try:
        return _generic_factor(f, gens, args, method='factor')
    except PolynomialError:
        if not f.is_commutative:
            return factor_nc(f)
        else:
            raise

@public
def intervals(F, all=False, eps=None, inf=None, sup=None, strict=False, fast=False, sqf=False):
    if not hasattr(F, '__iter__'):
        try:
            F = Poly(F)
        except GeneratorsNeeded:
            return []
        return F.intervals(all=all, eps=eps, inf=inf, sup=sup, fast=fast, sqf=sqf)
    else:
        polys, opt = parallel_poly_from_expr(F, domain='QQ')
        if len(opt.gens) > 1:
            raise MultivariatePolynomialError
        for i, poly in enumerate(polys):
            polys[i] = poly.rep.to_list()
        if eps is not None:
            eps = opt.domain.convert(eps)
            if eps <= 0:
                raise ValueError("'eps' must be a positive rational")
        if inf is not None:
            inf = opt.domain.convert(inf)
        if sup is not None:
            sup = opt.domain.convert(sup)
        intervals = dup_isolate_real_roots_list(polys, opt.domain, eps=eps, inf=inf, sup=sup, strict=strict, fast=fast)
        result = []
        for (s, t), indices in intervals:
            s, t = (opt.domain.to_sympy(s), opt.domain.to_sympy(t))
            result.append(((s, t), indices))
        return result

@public
def refine_root(f, s, t, eps=None, steps=None, fast=False, check_sqf=False):
    try:
        F = Poly(f)
        if not isinstance(f, Poly) and (not F.gen.is_Symbol):
            raise PolynomialError('generator must be a Symbol')
    except GeneratorsNeeded:
        raise PolynomialError('Cannot refine a root of %s, not a polynomial' % f)
    return F.refine_root(s, t, eps=eps, steps=steps, fast=fast, check_sqf=check_sqf)

@public
def count_roots(f, inf=None, sup=None):
    try:
        F = Poly(f, greedy=False)
        if not isinstance(f, Poly) and (not F.gen.is_Symbol):
            raise PolynomialError('generator must be a Symbol')
    except GeneratorsNeeded:
        raise PolynomialError('Cannot count roots of %s, not a polynomial' % f)
    return F.count_roots(inf=inf, sup=sup)

@public
def all_roots(f, multiple=True, radicals=True, extension=False):
    try:
        if isinstance(f, Poly):
            if extension and (not f.domain.is_AlgebraicField):
                F = Poly(f.expr, extension=True)
            else:
                F = f
        elif extension:
            F = Poly(f, extension=True)
        else:
            F = Poly(f, greedy=False)
        if not isinstance(f, Poly) and (not F.gen.is_Symbol):
            raise PolynomialError('generator must be a Symbol')
    except GeneratorsNeeded:
        raise PolynomialError('Cannot compute real roots of %s, not a polynomial' % f)
    return F.all_roots(multiple=multiple, radicals=radicals)

@public
def real_roots(f, multiple=True, radicals=True, extension=False):
    try:
        if isinstance(f, Poly):
            if extension and (not f.domain.is_AlgebraicField):
                F = Poly(f.expr, extension=True)
            else:
                F = f
        elif extension:
            F = Poly(f, extension=True)
        else:
            F = Poly(f, greedy=False)
        if not isinstance(f, Poly) and (not F.gen.is_Symbol):
            raise PolynomialError('generator must be a Symbol')
    except GeneratorsNeeded:
        raise PolynomialError('Cannot compute real roots of %s, not a polynomial' % f)
    return F.real_roots(multiple=multiple, radicals=radicals)

@public
def nroots(f, n=15, maxsteps=50, cleanup=True):
    try:
        F = Poly(f, greedy=False)
        if not isinstance(f, Poly) and (not F.gen.is_Symbol):
            raise PolynomialError('generator must be a Symbol')
    except GeneratorsNeeded:
        raise PolynomialError('Cannot compute numerical roots of %s, not a polynomial' % f)
    return F.nroots(n=n, maxsteps=maxsteps, cleanup=cleanup)

@public
def ground_roots(f, *gens, **args):
    options.allowed_flags(args, [])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
        if not isinstance(f, Poly) and (not F.gen.is_Symbol):
            raise PolynomialError('generator must be a Symbol')
    except PolificationFailed as exc:
        raise ComputationFailed('ground_roots', 1, exc)
    return F.ground_roots()

@public
def nth_power_roots_poly(f, n, *gens, **args):
    options.allowed_flags(args, [])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
        if not isinstance(f, Poly) and (not F.gen.is_Symbol):
            raise PolynomialError('generator must be a Symbol')
    except PolificationFailed as exc:
        raise ComputationFailed('nth_power_roots_poly', 1, exc)
    result = F.nth_power_roots_poly(n)
    if not opt.polys:
        return result.as_expr()
    else:
        return result

@public
def cancel(f, *gens, _signsimp=True, **args):
    from sympy.simplify.simplify import signsimp
    from sympy.polys.rings import sring
    options.allowed_flags(args, ['polys'])
    f = sympify(f)
    if _signsimp:
        f = signsimp(f)
    opt = {}
    if 'polys' in args:
        opt['polys'] = args['polys']
    if not isinstance(f, Tuple):
        if f.is_Number or isinstance(f, Relational) or (not isinstance(f, Expr)):
            return f
        f = factor_terms(f, radical=True)
        p, q = f.as_numer_denom()
    elif len(f) == 2:
        p, q = f
        if isinstance(p, Poly) and isinstance(q, Poly):
            opt['gens'] = p.gens
            opt['domain'] = p.domain
            opt['polys'] = opt.get('polys', True)
        p, q = (p.as_expr(), q.as_expr())
    else:
        raise ValueError('unexpected argument: %s' % f)
    from sympy.functions.elementary.piecewise import Piecewise
    try:
        if f.has(Piecewise):
            raise PolynomialError()
        R, (F, G) = sring((p, q), *gens, **args)
        if not R.ngens:
            if not isinstance(f, Tuple):
                return f.expand()
            else:
                return (S.One, p, q)
    except PolynomialError as msg:
        if f.is_commutative and (not f.has(Piecewise)):
            raise PolynomialError(msg)
        if f.is_Add or f.is_Mul:
            c, nc = sift(f.args, lambda x: x.is_commutative is True and (not x.has(Piecewise)), binary=True)
            nc = [cancel(i) for i in nc]
            return f.func(cancel(f.func(*c)), *nc)
        else:
            reps = []
            pot = preorder_traversal(f)
            next(pot)
            for e in pot:
                if isinstance(e, BooleanAtom) or not isinstance(e, Expr):
                    continue
                try:
                    reps.append((e, cancel(e)))
                    pot.skip()
                except NotImplementedError:
                    pass
            return f.xreplace(dict(reps))
    c, (P, Q) = (1, F.cancel(G))
    if opt.get('polys', False) and 'gens' not in opt:
        opt['gens'] = R.symbols
    if not isinstance(f, Tuple):
        return c * (P.as_expr() / Q.as_expr())
    else:
        P, Q = (P.as_expr(), Q.as_expr())
        if not opt.get('polys', False):
            return (c, P, Q)
        else:
            return (c, Poly(P, *gens, **opt), Poly(Q, *gens, **opt))

@public
def reduced(f, G, *gens, **args):
    options.allowed_flags(args, ['polys', 'auto'])
    try:
        polys, opt = parallel_poly_from_expr([f] + list(G), *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('reduced', 0, exc)
    domain = opt.domain
    retract = False
    if opt.auto and domain.is_Ring and (not domain.is_Field):
        opt = opt.clone({'domain': domain.get_field()})
        retract = True
    from sympy.polys.rings import xring
    _ring, _ = xring(opt.gens, opt.domain, opt.order)
    for i, poly in enumerate(polys):
        poly = poly.set_domain(opt.domain).rep.to_dict()
        polys[i] = _ring.from_dict(poly)
    Q, r = polys[0].div(polys[1:])
    Q = [Poly._from_dict(dict(q), opt) for q in Q]
    r = Poly._from_dict(dict(r), opt)
    if retract:
        try:
            _Q, _r = ([q.to_ring() for q in Q], r.to_ring())
        except CoercionFailed:
            pass
        else:
            Q, r = (_Q, _r)
    if not opt.polys:
        return ([q.as_expr() for q in Q], r.as_expr())
    else:
        return (Q, r)

@public
def groebner(F, *gens, **args):
    return GroebnerBasis(F, *gens, **args)

@public
def is_zero_dimensional(F, *gens, **args):
    return GroebnerBasis(F, *gens, **args).is_zero_dimensional

@public
def hurwitz_conditions(f, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('hurwitz_conditions', 1, exc)
    return F.hurwitz_conditions()

@public
def schur_conditions(f, *gens, **args):
    options.allowed_flags(args, ['polys'])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('schur_conditions', 1, exc)
    return F.schur_conditions()

@public
class GroebnerBasis(Basic):

    def __new__(cls, F, *gens, **args):
        options.allowed_flags(args, ['polys', 'method'])
        try:
            polys, opt = parallel_poly_from_expr(F, *gens, **args)
        except PolificationFailed as exc:
            raise ComputationFailed('groebner', len(F), exc)
        from sympy.polys.rings import PolyRing
        ring = PolyRing(opt.gens, opt.domain, opt.order)
        polys = [ring.from_dict(poly.rep.to_dict()) for poly in polys if poly]
        G = _groebner(polys, ring, method=opt.method)
        G = [Poly._from_dict(g, opt) for g in G]
        return cls._new(G, opt)

    @classmethod
    def _new(cls, basis, options):
        obj = Basic.__new__(cls)
        obj._basis = tuple(basis)
        obj._options = options
        return obj

    @property
    def args(self):
        basis = (p.as_expr() for p in self._basis)
        return (Tuple(*basis), Tuple(*self._options.gens))

    @property
    def exprs(self):
        return [poly.as_expr() for poly in self._basis]

    @property
    def polys(self):
        return list(self._basis)

    @property
    def gens(self):
        return self._options.gens

    @property
    def domain(self):
        return self._options.domain

    @property
    def order(self):
        return self._options.order

    def __len__(self):
        return len(self._basis)

    def __iter__(self):
        if self._options.polys:
            return iter(self.polys)
        else:
            return iter(self.exprs)

    def __getitem__(self, item):
        if self._options.polys:
            basis = self.polys
        else:
            basis = self.exprs
        return basis[item]

    def __hash__(self):
        return hash((self._basis, tuple(self._options.items())))

    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return self._basis == other._basis and self._options == other._options
        elif iterable(other):
            return self.polys == list(other) or self.exprs == list(other)
        else:
            return False

    def __ne__(self, other):
        return not self == other

    @property
    def is_zero_dimensional(self):

        def single_var(monomial):
            return sum(map(bool, monomial)) == 1
        exponents = Monomial([0] * len(self.gens))
        order = self._options.order
        for poly in self.polys:
            monomial = poly.LM(order=order)
            if single_var(monomial):
                exponents *= monomial
        return all(exponents)

    def fglm(self, order):
        opt = self._options
        src_order = opt.order
        dst_order = monomial_key(order)
        if src_order == dst_order:
            return self
        if not self.is_zero_dimensional:
            raise NotImplementedError('Cannot convert Groebner bases of ideals with positive dimension')
        polys = list(self._basis)
        domain = opt.domain
        opt = opt.clone({'domain': domain.get_field(), 'order': dst_order})
        from sympy.polys.rings import xring
        _ring, _ = xring(opt.gens, opt.domain, src_order)
        for i, poly in enumerate(polys):
            poly = poly.set_domain(opt.domain).rep.to_dict()
            polys[i] = _ring.from_dict(poly)
        G = matrix_fglm(polys, _ring, dst_order)
        G = [Poly._from_dict(dict(g), opt) for g in G]
        if not domain.is_Field:
            G = [g.clear_denoms(convert=True)[1] for g in G]
            opt.domain = domain
        return self._new(G, opt)

    def reduce(self, expr, auto=True):
        if isinstance(expr, Poly):
            if expr.gens != self._options.gens:
                raise ValueError("Polynomial generators don't match Groebner basis generators")
            poly = expr.set_domain(self._options.domain)
        else:
            poly = Poly._from_expr(expr, self._options)
        polys = [poly] + list(self._basis)
        opt = self._options
        domain = opt.domain
        retract = False
        if auto and domain.is_Ring and (not domain.is_Field):
            opt = opt.clone({'domain': domain.get_field()})
            retract = True
        from sympy.polys.rings import xring
        _ring, _ = xring(opt.gens, opt.domain, opt.order)
        for i, poly in enumerate(polys):
            poly = poly.set_domain(opt.domain).rep.to_dict()
            polys[i] = _ring.from_dict(poly)
        Q, r = polys[0].div(polys[1:])
        Q = [Poly._from_dict(dict(q), opt) for q in Q]
        r = Poly._from_dict(dict(r), opt)
        if retract:
            try:
                _Q, _r = ([q.to_ring() for q in Q], r.to_ring())
            except CoercionFailed:
                pass
            else:
                Q, r = (_Q, _r)
        if not opt.polys:
            return ([q.as_expr() for q in Q], r.as_expr())
        else:
            return (Q, r)

    def contains(self, poly):
        return self.reduce(poly)[1] == 0

@public
def poly(expr, *gens, **args):
    options.allowed_flags(args, [])

    def _poly(expr, opt):
        terms, poly_terms = ([], [])
        for term in Add.make_args(expr):
            factors, poly_factors = ([], [])
            for factor in Mul.make_args(term):
                if factor.is_Add:
                    poly_factors.append(_poly(factor, opt))
                elif factor.is_Pow and factor.base.is_Add and factor.exp.is_Integer and (factor.exp >= 0):
                    poly_factors.append(_poly(factor.base, opt).pow(factor.exp))
                else:
                    factors.append(factor)
            if not poly_factors:
                terms.append(term)
            else:
                product = poly_factors[0]
                for factor in poly_factors[1:]:
                    product = product.mul(factor)
                if factors:
                    factor = Mul(*factors)
                    if factor.is_Number:
                        product *= factor
                    else:
                        product = product.mul(Poly._from_expr(factor, opt))
                poly_terms.append(product)
        if not poly_terms:
            result = Poly._from_expr(expr, opt)
        else:
            result = poly_terms[0]
            for term in poly_terms[1:]:
                result = result.add(term)
            if terms:
                term = Add(*terms)
                if term.is_Number:
                    result += term
                else:
                    result = result.add(Poly._from_expr(term, opt))
        return result.reorder(*opt.get('gens', ()), **args)
    expr = sympify(expr)
    if expr.is_Poly:
        return Poly(expr, *gens, **args)
    if 'expand' not in args:
        args['expand'] = False
    opt = options.build_options(gens, args)
    return _poly(expr, opt)

def named_poly(n, f, K, name, x, polys):
    if n < 0:
        raise ValueError('Cannot generate %s of index %s' % (name, n))
    head, tail = (x[0], x[1:])
    if K is None:
        K, tail = construct_domain(tail, field=True)
    poly = DMP(f(int(n), *tail, K), K)
    if head is None:
        poly = PurePoly.new(poly, Dummy('x'))
    else:
        poly = Poly.new(poly, head)
    return poly if polys else poly.as_expr()