from __future__ import annotations
from sympy.core import S
from sympy.polys import Poly

def dispersionset(p, q=None, *gens, **args):
    same = False if q is not None else True
    if same:
        q = p
    p = Poly(p, *gens, **args)
    q = Poly(q, *gens, **args)
    if not p.is_univariate or not q.is_univariate:
        raise ValueError('Polynomials need to be univariate')
    if not p.gen == q.gen:
        raise ValueError('Polynomials must have the same generator')
    gen = p.gen
    if p.degree() < 1 or q.degree() < 1:
        return {0}
    fp = p.factor_list()
    fq = q.factor_list() if not same else fp
    J = set()
    for s, unused in fp[1]:
        for t, unused in fq[1]:
            m = s.degree()
            n = t.degree()
            if n != m:
                continue
            an = s.LC()
            bn = t.LC()
            if not (an - bn).is_zero:
                continue
            anm1 = s.coeff_monomial(gen ** (m - 1))
            bnm1 = t.coeff_monomial(gen ** (n - 1))
            alpha = (anm1 - bnm1) / S(n * bn)
            if not alpha.is_integer:
                continue
            if alpha < 0 or alpha in J:
                continue
            if n > 1 and (not (s - t.shift(alpha)).is_zero):
                continue
            J.add(alpha)
    return J

def dispersion(p, q=None, *gens, **args):
    J = dispersionset(p, q, *gens, **args)
    if not J:
        j = S.NegativeInfinity
    else:
        j = max(J)
    return j