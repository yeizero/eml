from __future__ import annotations
from sympy.polys.polytools import Poly
from sympy.polys.domains.finitefield import FF
from sympy.polys.domains.rationalfield import QQ
from sympy.polys.domains.integerring import ZZ
from sympy.polys.matrices.domainmatrix import DomainMatrix
from sympy.polys.polyerrors import CoercionFailed
from sympy.polys.polyutils import IntegerPowerable
from sympy.utilities.decorator import public
from .basis import round_two, nilradical_mod_p
from .exceptions import StructureError
from .modules import ModuleEndomorphism, find_min_poly
from .utilities import coeff_search, supplement_a_subspace

def _check_formal_conditions_for_maximal_order(submodule):
    prefix = 'The submodule representing the maximal order should '
    cond = None
    if not submodule.is_power_basis_submodule():
        cond = 'be a direct submodule of a power basis.'
    elif not submodule.starts_with_unity():
        cond = 'have 1 as its first generator.'
    elif not submodule.is_sq_maxrank_HNF():
        cond = 'have square matrix, of maximal rank, in Hermite Normal Form.'
    if cond is not None:
        raise StructureError(prefix + cond)

class PrimeIdeal(IntegerPowerable):

    def __init__(self, ZK, p, alpha, f, e=None):
        _check_formal_conditions_for_maximal_order(ZK)
        self.ZK = ZK
        self.p = p
        self.alpha = alpha
        self.f = f
        self._test_factor = None
        self.e = e if e is not None else self.valuation(p * ZK)

    def __str__(self):
        if self.is_inert:
            return f'({self.p})'
        return f'({self.p}, {self.alpha.as_expr()})'

    @property
    def is_inert(self):
        return self.f == self.ZK.n

    def repr(self, field_gen=None, just_gens=False):
        field_gen = field_gen or self.ZK.parent.T.gen
        p, alpha, e, f = (self.p, self.alpha, self.e, self.f)
        alpha_rep = str(alpha.numerator(x=field_gen).as_expr())
        if alpha.denom > 1:
            alpha_rep = f'({alpha_rep})/{alpha.denom}'
        gens = f'({p}, {alpha_rep})'
        if just_gens:
            return gens
        return f'[ {gens} e={e}, f={f} ]'

    def __repr__(self):
        return self.repr()

    def as_submodule(self):
        M = self.p * self.ZK + self.alpha * self.ZK
        M._starts_with_unity = False
        M._is_sq_maxrank_HNF = True
        return M

    def __eq__(self, other):
        if isinstance(other, PrimeIdeal):
            return self.as_submodule() == other.as_submodule()
        return NotImplemented

    def __add__(self, other):
        return self.as_submodule() + other
    __radd__ = __add__

    def __mul__(self, other):
        return self.as_submodule() * other
    __rmul__ = __mul__

    def _zeroth_power(self):
        return self.ZK

    def _first_power(self):
        return self

    def test_factor(self):
        if self._test_factor is None:
            self._test_factor = _compute_test_factor(self.p, [self.alpha], self.ZK)
        return self._test_factor

    def valuation(self, I):
        return prime_valuation(I, self)

    def reduce_element(self, elt):
        return self.as_submodule().reduce_element(elt)

    def reduce_ANP(self, a):
        elt = self.ZK.parent.element_from_ANP(a)
        red = self.reduce_element(elt)
        return red.to_ANP()

    def reduce_alg_num(self, a):
        elt = self.ZK.parent.element_from_alg_num(a)
        red = self.reduce_element(elt)
        return a.field_element(list(reversed(red.QQ_col.flat())))

def _compute_test_factor(p, gens, ZK):
    _check_formal_conditions_for_maximal_order(ZK)
    E = ZK.endomorphism_ring()
    matrices = [E.inner_endomorphism(g).matrix(modulus=p) for g in gens]
    B = DomainMatrix.zeros((0, ZK.n), FF(p)).vstack(*matrices)
    x = B.nullspace()[0, :].transpose()
    beta = ZK.parent(ZK.matrix * x.convert_to(ZZ), denom=ZK.denom)
    return beta

@public
def prime_valuation(I, P):
    p, ZK = (P.p, P.ZK)
    n, W, d = (ZK.n, ZK.matrix, ZK.denom)
    A = W.convert_to(QQ).inv() * I.matrix * d / I.denom
    A = A.convert_to(ZZ)
    D = A.det()
    if D % p != 0:
        return 0
    beta = P.test_factor()
    f = d ** n // W.det()
    need_complete_test = f % p == 0
    v = 0
    while True:
        A = W * A
        for j in range(n):
            c = ZK.parent(A[:, j], denom=d)
            c *= beta
            c = ZK.represent(c).flat()
            for i in range(n):
                A[i, j] = c[i]
        if A[n - 1, n - 1].element % p != 0:
            break
        A = A / p
        if need_complete_test:
            try:
                A = A.convert_to(ZZ)
            except CoercionFailed:
                break
        else:
            A = A.convert_to(ZZ)
        v += 1
    return v

def _two_elt_rep(gens, ZK, p, f=None, Np=None):
    _check_formal_conditions_for_maximal_order(ZK)
    pb = ZK.parent
    T = pb.T
    if all(((g % p).equiv(0) for g in gens)):
        return pb.zero()
    if Np is None:
        if f is not None:
            Np = p ** f
        else:
            Np = abs(pb.submodule_from_gens(gens).matrix.det())
    omega = ZK.basis_element_pullbacks()
    beta = [p * om for om in omega[1:]]
    beta += gens
    search = coeff_search(len(beta), 1)
    for c in search:
        alpha = sum((ci * betai for ci, betai in zip(c, beta)))
        n = alpha.norm(T) // Np
        if n % p != 0:
            return alpha % p

def _prime_decomp_easy_case(p, ZK):
    T = ZK.parent.T
    T_bar = Poly(T, modulus=p)
    lc, fl = T_bar.factor_list()
    if len(fl) == 1 and fl[0][1] == 1:
        return [PrimeIdeal(ZK, p, ZK.parent.zero(), ZK.n, 1)]
    return [PrimeIdeal(ZK, p, ZK.parent.element_from_poly(Poly(t, domain=ZZ)), t.degree(), e) for t, e in fl]

def _prime_decomp_compute_kernel(I, p, ZK):
    W = I.matrix
    n, r = W.shape
    if r == 0:
        B = W.eye(n, ZZ)
    else:
        B = W.hstack(W.eye(n, ZZ)[:, 0])
    if B.shape[1] < n:
        B = supplement_a_subspace(B.convert_to(FF(p))).convert_to(ZZ)
    G = ZK.submodule_from_matrix(B)
    G.compute_mult_tab()
    G = G.discard_before(r)
    phi = ModuleEndomorphism(G, lambda x: x ** p - x)
    N = phi.kernel(modulus=p)
    assert N.starts_with_unity()
    return (N, G)

def _prime_decomp_maximal_ideal(I, p, ZK):
    m, n = I.matrix.shape
    f = m - n
    G = ZK.matrix * I.matrix
    gens = [ZK.parent(G[:, j], denom=ZK.denom) for j in range(G.shape[1])]
    alpha = _two_elt_rep(gens, ZK, p, f=f)
    return PrimeIdeal(ZK, p, alpha, f)

def _prime_decomp_split_ideal(I, p, N, G, ZK):
    assert I.parent == ZK and G.parent is ZK and (N.parent is G)
    alpha = N(1).to_parent()
    assert alpha.module is G
    alpha_powers = []
    m = find_min_poly(alpha, FF(p), powers=alpha_powers)
    lc, fl = m.factor_list()
    m1 = fl[0][0]
    m2 = m.quo(m1)
    U, V, g = m1.gcdex(m2)
    assert g == 1
    E = list(reversed(Poly(U * m1, domain=ZZ).rep.to_list()))
    eps1 = sum((E[i] * alpha_powers[i] for i in range(len(E))))
    eps2 = 1 - eps1
    idemps = [eps1, eps2]
    factors = []
    for eps in idemps:
        e = eps.to_parent()
        assert e.module is ZK
        D = I.matrix.convert_to(FF(p)).hstack(*[(e * om).column(domain=FF(p)) for om in ZK.basis_elements()])
        W = D.columnspace().convert_to(ZZ)
        H = ZK.submodule_from_matrix(W)
        factors.append(H)
    return factors

@public
def prime_decomp(p, T=None, ZK=None, dK=None, radical=None):
    if T is None and ZK is None:
        raise ValueError('At least one of T or ZK must be provided.')
    if ZK is not None:
        _check_formal_conditions_for_maximal_order(ZK)
    if T is None:
        T = ZK.parent.T
    radicals = {}
    if dK is None or ZK is None:
        ZK, dK = round_two(T, radicals=radicals)
    dT = T.discriminant()
    f_squared = dT // dK
    if f_squared % p != 0:
        return _prime_decomp_easy_case(p, ZK)
    radical = radical or radicals.get(p) or nilradical_mod_p(ZK, p)
    stack = [radical]
    primes = []
    while stack:
        I = stack.pop()
        N, G = _prime_decomp_compute_kernel(I, p, ZK)
        if N.n == 1:
            P = _prime_decomp_maximal_ideal(I, p, ZK)
            primes.append(P)
        else:
            I1, I2 = _prime_decomp_split_ideal(I, p, N, G, ZK)
            stack.extend([I1, I2])
    return primes