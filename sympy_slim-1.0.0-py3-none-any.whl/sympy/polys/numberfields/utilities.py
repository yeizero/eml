from __future__ import annotations
from sympy.core.sympify import sympify
from sympy.external.mpmath import local_workprec
from sympy.ntheory.factor_ import factorint
from sympy.polys.domains.rationalfield import QQ
from sympy.polys.domains.integerring import ZZ
from sympy.polys.matrices.exceptions import DMRankError
from sympy.polys.numberfields.minpoly import minpoly
from sympy.printing.lambdarepr import IntervalPrinter
from sympy.utilities.decorator import public
from sympy.utilities.lambdify import lambdify

def is_rat(c):
    return isinstance(c, int) or ZZ.of_type(c) or QQ.of_type(c)

def is_int(c):
    return isinstance(c, int) or ZZ.of_type(c)

def get_num_denom(c):
    r = QQ(c)
    return (r.numerator, r.denominator)

@public
def extract_fundamental_discriminant(a):
    if a % 4 not in [0, 1]:
        raise ValueError('To extract fundamental discriminant, number must be 0 or 1 mod 4.')
    if a == 0:
        return ({}, {0: 1})
    if a == 1:
        return ({}, {})
    a_factors = factorint(a)
    D = {}
    F = {}
    num_3_mod_4 = 0
    for p, e in a_factors.items():
        if e % 2 == 1:
            D[p] = 1
            if p % 4 == 3:
                num_3_mod_4 += 1
            if e >= 3:
                F[p] = (e - 1) // 2
        else:
            F[p] = e // 2
    even = 2 in D
    if even or num_3_mod_4 % 2 == 1:
        e2 = F[2]
        assert e2 > 0
        if e2 == 1:
            del F[2]
        else:
            F[2] = e2 - 1
        D[2] = 3 if even else 2
    return (D, F)

@public
class AlgIntPowers:

    def __init__(self, T, modulus=None):
        self.T = T
        self.modulus = modulus
        self.n = T.degree()
        self.powers_n_and_up = [[-c % self for c in reversed(T.rep.to_list())][:-1]]
        self.max_so_far = self.n

    def red(self, exp):
        return exp if self.modulus is None else exp % self.modulus

    def __rmod__(self, other):
        return self.red(other)

    def compute_up_through(self, e):
        m = self.max_so_far
        if e <= m:
            return
        n = self.n
        r = self.powers_n_and_up
        c = r[0]
        for k in range(m + 1, e + 1):
            b = r[k - 1 - n][n - 1]
            r.append([c[0] * b % self] + [(r[k - 1 - n][i - 1] + c[i] * b) % self for i in range(1, n)])
        self.max_so_far = e

    def get(self, e):
        n = self.n
        if e < 0:
            raise ValueError('Exponent must be non-negative.')
        elif e < n:
            return [1 if i == e else 0 for i in range(n)]
        else:
            self.compute_up_through(e)
            return self.powers_n_and_up[e - n]

    def __getitem__(self, item):
        return self.get(item)

@public
def coeff_search(m, R):
    R0 = R
    c = [R] * m
    while True:
        if R == R0 or R in c or -R in c:
            yield c[:]
        j = m - 1
        while c[j] == -R:
            j -= 1
        c[j] -= 1
        for i in range(j + 1, m):
            c[i] = R
        for j in range(m):
            if c[j] != 0:
                break
        else:
            R += 1
            c = [R] * m

def supplement_a_subspace(M):
    n, r = M.shape
    Maug = M.hstack(M.eye(n, M.domain))
    R, pivots = Maug.rref()
    if pivots[:r] != tuple(range(r)):
        raise DMRankError('M was not of maximal rank')
    A = R[:, r:]
    B = A.inv()
    return B

@public
def isolate(alg, eps=None, fast=False):
    alg = sympify(alg)
    if alg.is_Rational:
        return (alg, alg)
    elif not alg.is_real:
        raise NotImplementedError('complex algebraic numbers are not supported')
    with local_workprec(53) as mp:
        func = lambdify((), alg, modules=mp, printer=IntervalPrinter())
        poly = minpoly(alg, polys=True)
        intervals = poly.intervals(sqf=True)
        done = False
        while not done:
            alg = func()
            for a, b in intervals:
                if a <= alg.a and alg.b <= b:
                    done = True
                    break
            else:
                mp.prec *= 2
    if eps is not None:
        a, b = poly.refine_root(a, b, eps=eps, fast=fast)
    return (a, b)