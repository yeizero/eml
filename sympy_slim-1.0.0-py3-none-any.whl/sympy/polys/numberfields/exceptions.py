from __future__ import annotations

class ClosureFailure(Exception):
    pass

class StructureError(Exception):
    pass

class MissingUnityError(StructureError):
    pass
__all__ = ['ClosureFailure', 'StructureError', 'MissingUnityError']