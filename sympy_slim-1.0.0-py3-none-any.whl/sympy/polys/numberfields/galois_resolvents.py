from __future__ import annotations
from sympy.core.evalf import evalf, fastlog, _evalf_with_bounded_error, quad_to_mpmath
from sympy.core.symbol import symbols, Dummy
from sympy.external.mpmath import prec_to_dps, local_workprec
from sympy.polys.densetools import dup_eval
from sympy.polys.domains import ZZ
from sympy.polys.orderings import lex
from sympy.polys.polyroots import preprocess_roots
from sympy.polys.polytools import Poly
from sympy.polys.rings import xring
from sympy.polys.specialpolys import symmetric_poly
from sympy.utilities.lambdify import lambdify

class GaloisGroupException(Exception):
    pass

class ResolventException(GaloisGroupException):
    pass

class Resolvent:

    def __init__(self, F, X, s):
        self.F = F
        self.X = X
        self.s = s
        self.m = len(s)
        self.t = None
        self.r = 0
        for monom, coeff in Poly(F).terms():
            if abs(coeff) != 1:
                raise ResolventException('Resolvent class expects forms with unit coeffs')
            t = sum(monom)
            if t != self.t and self.t is not None:
                raise ResolventException('Resolvent class expects homogeneous forms')
            self.t = t
            self.r += 1
        m, t, r = (self.m, self.t, self.r)
        if not m < r * 2 ** t:
            raise ResolventException('Resolvent class expects m < r*2^t')
        M = symbols('M')
        self.coeff_prec_func = Poly(r ** m * (m * t + 1) * M ** (m * t - 1))
        self.root_prec_func = Poly(r * (t + 1) * M ** (t - 1))
        self.root_lambdas = [lambdify((~s[j])(X), F) for j in range(self.m)]
        Y = symbols('Y')
        R = symbols(' '.join((f'R{i}' for i in range(m))))
        f = 1
        for r in R:
            f *= Y - r
        C = Poly(f, Y).coeffs()
        self.esf_lambdas = [lambdify(R, c) for c in C]

    def get_prec(self, M, target='coeffs'):
        M = max(M, 2)
        f = self.coeff_prec_func if target == 'coeffs' else self.root_prec_func
        r, _, _, _ = evalf(2 * f(M), 1, {})
        return fastlog(r) + 1

    def approximate_roots_of_poly(self, T, target='coeffs'):
        with local_workprec(53) as mp:
            coeff, T = preprocess_roots(T)
            coeff = mp.mpf(str(coeff))
            scaled_roots = T.all_roots(radicals=False)
            approx0 = [coeff * quad_to_mpmath(_evalf_with_bounded_error(r, m=0), mp) for r in scaled_roots]
            M = mp.fadd(max((mp.fabs(b) for b in approx0)), 1)
            m = self.get_prec(M, target=target)
            n = fastlog(M._mpf_) + 1
            p = m + n + 1
            mp.prec = p
            d = prec_to_dps(p)
            approx1 = [r.eval_approx(d, return_mpmath=True) for r in scaled_roots]
            approx1 = [mp.fmul(coeff, mp.mpc(r)) for r in approx1]
            return approx1

    @staticmethod
    def round_mpf(a):
        if isinstance(a, int):
            return a
        return ZZ(int(a.context.nint(a)))

    def round_roots_to_integers_for_poly(self, T):
        approx_roots_of_T = self.approximate_roots_of_poly(T, target='roots')
        approx_roots_of_self = [r(*approx_roots_of_T) for r in self.root_lambdas]
        return {i: self.round_mpf(r.real) for i, r in enumerate(approx_roots_of_self) if self.round_mpf(r.imag) == 0}

    def eval_for_poly(self, T, find_integer_root=False):
        approx_roots_of_T = self.approximate_roots_of_poly(T, target='coeffs')
        approx_roots_of_self = [r(*approx_roots_of_T) for r in self.root_lambdas]
        approx_coeffs_of_self = [c(*approx_roots_of_self) for c in self.esf_lambdas]
        R = []
        for c in approx_coeffs_of_self:
            if self.round_mpf(c.imag) != 0:
                raise ResolventException(f'Got non-integer coeff for resolvent: {c}')
            R.append(self.round_mpf(c.real))
        a0, i0 = (None, None)
        if find_integer_root:
            for i, r in enumerate(approx_roots_of_self):
                if self.round_mpf(r.imag) != 0:
                    continue
                if not dup_eval(R, (a := self.round_mpf(r.real)), ZZ):
                    a0, i0 = (a, i)
                    break
        return (R, a0, i0)

def wrap(text, width=80):
    out = ''
    col = 0
    for c in text:
        if c == ' ' and col > width:
            c, col = ('\n', 0)
        else:
            col += 1
        out += c
    return out

def s_vars(n):
    return symbols([f's{i + 1}' for i in range(n)])

def sparse_symmetrize_resolvent_coeffs(F, X, s, verbose=False):
    import time, sys
    root_forms = [F.compose(list(zip(X, sigma(X)))) for sigma in s]
    Y = [Dummy(f'Y{i}') for i in range(len(s))]
    coeff_forms = []
    for i in range(1, len(s) + 1):
        if verbose:
            print('----')
            print(f'Computing symmetric poly of degree {i}...')
            sys.stdout.flush()
        t0 = time.time()
        G = symmetric_poly(i, *Y)
        t1 = time.time()
        if verbose:
            print(f'took {t1 - t0} seconds')
            print('lambdifying...')
            sys.stdout.flush()
        t0 = time.time()
        C = lambdify(Y, (-1) ** i * G)
        t1 = time.time()
        if verbose:
            print(f'took {t1 - t0} seconds')
            sys.stdout.flush()
        coeff_forms.append(C)
    coeffs = []
    for i, f in enumerate(coeff_forms):
        if verbose:
            print('----')
            print(f'Plugging root forms into elem symm poly {i + 1}...')
            sys.stdout.flush()
        t0 = time.time()
        g = f(*root_forms)
        t1 = time.time()
        coeffs.append(g)
        if verbose:
            print(f'took {t1 - t0} seconds')
            sys.stdout.flush()
    symmetrized = []
    symmetrization_times = []
    ss = s_vars(len(X))
    for i, A in list(enumerate(coeffs)):
        if verbose:
            print('-----')
            print(f'Coeff {i + 1}...')
            sys.stdout.flush()
        t0 = time.time()
        B, rem, _ = A.symmetrize()
        t1 = time.time()
        if rem != 0:
            msg = f'Got nonzero remainder {rem} for resolvent (F, X, s) = ({F}, {X}, {s})'
            raise ResolventException(msg)
        B_str = str(B.as_expr(*ss))
        symmetrized.append(B_str)
        symmetrization_times.append(t1 - t0)
        if verbose:
            print(wrap(B_str))
            print(f'took {t1 - t0} seconds')
            sys.stdout.flush()
    return (symmetrized, symmetrization_times)

def define_resolvents():
    from sympy.combinatorics.galois import PGL2F5
    from sympy.combinatorics.permutations import Permutation
    R4, X4 = xring('X0,X1,X2,X3', ZZ, lex)
    X = X4
    F40 = X[0] * X[1] ** 2 + X[1] * X[2] ** 2 + X[2] * X[3] ** 2 + X[3] * X[0] ** 2
    s40 = [Permutation(3), Permutation(3)(0, 1), Permutation(3)(0, 2), Permutation(3)(0, 3), Permutation(3)(1, 2), Permutation(3)(2, 3)]
    F41 = X[0] * X[2] + X[1] * X[3]
    s41 = [Permutation(3), Permutation(3)(0, 1), Permutation(3)(0, 3)]
    R5, X5 = xring('X0,X1,X2,X3,X4', ZZ, lex)
    X = X5
    F51 = X[0] ** 2 * (X[1] * X[4] + X[2] * X[3]) + X[1] ** 2 * (X[2] * X[0] + X[3] * X[4]) + X[2] ** 2 * (X[3] * X[1] + X[4] * X[0]) + X[3] ** 2 * (X[4] * X[2] + X[0] * X[1]) + X[4] ** 2 * (X[0] * X[3] + X[1] * X[2])
    s51 = [Permutation(4), Permutation(4)(0, 1), Permutation(4)(0, 2), Permutation(4)(0, 3), Permutation(4)(0, 4), Permutation(4)(1, 4)]
    R6, X6 = xring('X0,X1,X2,X3,X4,X5', ZZ, lex)
    X = X6
    H = PGL2F5()
    term0 = X[0] ** 2 * X[5] ** 2 * (X[1] * X[4] + X[2] * X[3])
    terms = {term0.compose(list(zip(X, s(X)))) for s in H.elements}
    F61 = sum(terms)
    s61 = [Permutation(5)] + [Permutation(5)(0, n) for n in range(1, 6)]
    F62 = X[0] * X[1] * X[2] + X[3] * X[4] * X[5]
    s62 = [Permutation(5)] + [Permutation(5)(i, j + 3) for i in range(3) for j in range(3)]
    return {(4, 0): (F40, X4, s40), (4, 1): (F41, X4, s41), (5, 1): (F51, X5, s51), (6, 1): (F61, X6, s61), (6, 2): (F62, X6, s62)}

def generate_lambda_lookup(verbose=False, trial_run=False):
    jobs = define_resolvents()
    lambda_lists = {}
    total_time = 0
    time_for_61 = 0
    time_for_61_last = 0
    for k, (F, X, s) in jobs.items():
        symmetrized, times = sparse_symmetrize_resolvent_coeffs(F, X, s, verbose=verbose)
        total_time += sum(times)
        if k == (6, 1):
            time_for_61 = sum(times)
            time_for_61_last = times[-1]
        sv = s_vars(len(X))
        head = f"lambda {', '.join((str(v) for v in sv))}:"
        lambda_lists[k] = ',\n        '.join([f'{head} ({wrap(f)})' for f in symmetrized])
        if trial_run:
            break
    table = f'# This table was generated by a call to\n# `sympy.polys.numberfields.galois_resolvents.generate_lambda_lookup()`.\n# The entire job took {total_time:.2f}s.\n# Of this, Case (6, 1) took {time_for_61:.2f}s.\n# The final polynomial of Case (6, 1) alone took {time_for_61_last:.2f}s.\nresolvent_coeff_lambdas = {{\n'
    for k, L in lambda_lists.items():
        table += f'    {k}: [\n'
        table += '        ' + L + '\n'
        table += '    ],\n'
    table += '}\n'
    return table

def get_resolvent_by_lookup(T, number):
    from sympy.polys.numberfields.resolvent_lookup import resolvent_coeff_lambdas
    degree = T.degree()
    L = resolvent_coeff_lambdas[degree, number]
    T_coeffs = T.rep.to_list()[1:]
    return [ZZ(1)] + [c(*T_coeffs) for c in L]
if __name__ == '__main__':
    import sys
    verbose = '-v' in sys.argv[1:]
    trial_run = '-t' in sys.argv[1:]
    table = generate_lambda_lookup(verbose=verbose, trial_run=trial_run)
    print(table)