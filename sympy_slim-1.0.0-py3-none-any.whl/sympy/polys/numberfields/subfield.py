from __future__ import annotations
from sympy.core.add import Add
from sympy.core.numbers import AlgebraicNumber
from sympy.core.singleton import S
from sympy.core.symbol import Dummy
from sympy.core.sympify import sympify, _sympify
from sympy.external.mpmath import local_workprec
from sympy.ntheory import sieve
from sympy.polys.densetools import dup_eval
from sympy.polys.domains import QQ
from sympy.polys.numberfields.minpoly import _choose_factor, minimal_polynomial
from sympy.polys.polyerrors import IsomorphismFailed
from sympy.polys.polytools import Poly, PurePoly, factor_list
from sympy.utilities import public

def is_isomorphism_possible(a, b):
    n = a.minpoly.degree()
    m = b.minpoly.degree()
    if m % n != 0:
        return False
    if n == m:
        return True
    da = a.minpoly.discriminant()
    db = b.minpoly.discriminant()
    i, k, half = (1, m // n, db // 2)
    while True:
        p = sieve[i]
        P = p ** k
        if P > half:
            break
        if da % p % 2 and (not db % P):
            return False
        i += 1
    return True

def field_isomorphism_pslq(a, b):
    if not a.root.is_real or not b.root.is_real:
        raise NotImplementedError("PSLQ doesn't support complex coefficients")
    f = a.minpoly
    g = b.minpoly.replace(f.gen)
    n, m, prev = (100, b.minpoly.degree(), None)
    with local_workprec(53) as ctx:
        for i in range(1, 5):
            A = a.root.evalf(n)
            B = b.root.evalf(n)
            basis = [1, B] + [B ** i for i in range(2, m)] + [-A]
            ctx.dps = n
            coeffs = ctx.pslq(basis, maxcoeff=10 ** 10, maxsteps=1000)
            if coeffs is None:
                break
            if coeffs != prev:
                prev = coeffs
            else:
                break
            coeffs = [S(c) / coeffs[-1] for c in coeffs[:-1]]
            while not coeffs[-1]:
                coeffs.pop()
            coeffs = list(reversed(coeffs))
            h = Poly(coeffs, f.gen, domain='QQ')
            if f.compose(h).rem(g).is_zero:
                return coeffs
            else:
                n *= 2
        return None

def field_isomorphism_factor(a, b):
    _, factors = factor_list(a.minpoly, extension=b)
    for f, _ in factors:
        if f.degree() == 1:
            c = -f.rep.TC()
            coeffs = c.to_sympy_list()
            d, terms = (len(coeffs) - 1, [])
            for i, coeff in enumerate(coeffs):
                terms.append(coeff * b.root ** (d - i))
            r = Add(*terms)
            if a.minpoly.same_root(r, a):
                return coeffs
    return None

@public
def field_isomorphism(a, b, *, fast=True):
    a, b = (sympify(a), sympify(b))
    if not a.is_AlgebraicNumber:
        a = AlgebraicNumber(a)
    if not b.is_AlgebraicNumber:
        b = AlgebraicNumber(b)
    a = a.to_primitive_element()
    b = b.to_primitive_element()
    if a == b:
        return a.coeffs()
    n = a.minpoly.degree()
    m = b.minpoly.degree()
    if n == 1:
        return [a.root]
    if m % n != 0:
        return None
    if fast:
        try:
            result = field_isomorphism_pslq(a, b)
            if result is not None:
                return result
        except NotImplementedError:
            pass
    return field_isomorphism_factor(a, b)

def _switch_domain(g, K):
    frep = g.rep.inject()
    hrep = frep.eject(K, front=True)
    return g.new(hrep, g.gens[0])

def _linsolve(p):
    c, d = p.rep.to_list()
    return -d / c

@public
def primitive_element(extension, x=None, *, ex=False, polys=False):
    if not extension:
        raise ValueError('Cannot compute primitive element for empty extension')
    extension = [_sympify(ext) for ext in extension]
    if x is not None:
        x, cls = (sympify(x), Poly)
    else:
        x, cls = (Dummy('x'), PurePoly)

    def _canonicalize(f):
        _, f = f.primitive()
        if f.LC() < 0:
            f = -f
        return f
    if not ex:
        gen, coeffs = (extension[0], [1])
        g = minimal_polynomial(gen, x, polys=True)
        for ext in extension[1:]:
            if ext.is_Rational:
                coeffs.append(0)
                continue
            _, factors = factor_list(g, extension=ext)
            g = _choose_factor(factors, x, gen)
            [s], _, g = g.sqf_norm()
            gen += s * ext
            coeffs.append(s)
        g = _canonicalize(g)
        if not polys:
            return (g.as_expr(), coeffs)
        else:
            return (cls(g), coeffs)
    gen, coeffs = (extension[0], [1])
    f = minimal_polynomial(gen, x, polys=True)
    K = QQ.algebraic_field((f, gen))
    reps = [K.unit]
    for ext in extension[1:]:
        if ext.is_Rational:
            coeffs.append(0)
            reps.append(K.convert(ext))
            continue
        p = minimal_polynomial(ext, x, polys=True)
        L = QQ.algebraic_field((p, ext))
        _, factors = factor_list(f, domain=L)
        f = _choose_factor(factors, x, gen)
        [s], g, f = f.sqf_norm()
        gen += s * ext
        coeffs.append(s)
        K = QQ.algebraic_field((f, gen))
        h = _switch_domain(g, K)
        erep = _linsolve(h.gcd(p))
        ogen = K.unit - s * erep
        reps = [dup_eval(_.to_list(), ogen, K) for _ in reps] + [erep]
    if K.ext.root.is_Rational:
        H = [K.convert(_).rep for _ in extension]
        coeffs = [0] * len(extension)
        f = cls(x, domain=QQ)
    else:
        H = [_.to_list() for _ in reps]
    f = _canonicalize(f)
    if not polys:
        return (f.as_expr(), coeffs, H)
    else:
        return (f, coeffs, H)

@public
def to_number_field(extension, theta=None, *, gen=None, alias=None):
    if hasattr(extension, '__iter__'):
        extension = list(extension)
    else:
        extension = [extension]
    if len(extension) == 1 and isinstance(extension[0], tuple):
        return AlgebraicNumber(extension[0], alias=alias)
    minpoly, coeffs = primitive_element(extension, gen, polys=True)
    root = sum((coeff * ext for coeff, ext in zip(coeffs, extension)))
    if theta is None:
        return AlgebraicNumber((minpoly, root), alias=alias)
    else:
        theta = sympify(theta)
        if not theta.is_AlgebraicNumber:
            theta = AlgebraicNumber(theta, gen=gen, alias=alias)
        coeffs = field_isomorphism(root, theta)
        if coeffs is not None:
            return AlgebraicNumber(theta, coeffs, alias=alias)
        else:
            raise IsomorphismFailed('%s is not in a subfield of %s' % (root, theta.root))