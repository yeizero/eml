from __future__ import annotations
from sympy.core.intfunc import igcd, ilcm
from sympy.core.symbol import Dummy
from sympy.polys.polyclasses import ANP
from sympy.polys.polytools import Poly
from sympy.polys.densetools import dup_clear_denoms
from sympy.polys.domains.algebraicfield import AlgebraicField
from sympy.polys.domains.finitefield import FF
from sympy.polys.domains.rationalfield import QQ
from sympy.polys.domains.integerring import ZZ
from sympy.polys.matrices.domainmatrix import DomainMatrix
from sympy.polys.matrices.exceptions import DMBadInputError
from sympy.polys.matrices.normalforms import hermite_normal_form
from sympy.polys.polyerrors import CoercionFailed, UnificationFailed
from sympy.polys.polyutils import IntegerPowerable
from .exceptions import ClosureFailure, MissingUnityError, StructureError
from .utilities import AlgIntPowers, is_rat, get_num_denom

def to_col(coeffs):
    return DomainMatrix([[ZZ(c) for c in coeffs]], (1, len(coeffs)), ZZ).transpose()

class Module:

    @property
    def n(self):
        raise NotImplementedError

    def mult_tab(self):
        raise NotImplementedError

    @property
    def parent(self):
        return None

    def represent(self, elt):
        raise NotImplementedError

    def ancestors(self, include_self=False):
        c = self.parent
        a = [] if c is None else c.ancestors(include_self=True)
        if include_self:
            a.append(self)
        return a

    def power_basis_ancestor(self):
        if isinstance(self, PowerBasis):
            return self
        c = self.parent
        if c is not None:
            return c.power_basis_ancestor()
        return None

    def nearest_common_ancestor(self, other):
        sA = self.ancestors(include_self=True)
        oA = other.ancestors(include_self=True)
        nca = None
        for sa, oa in zip(sA, oA):
            if sa == oa:
                nca = sa
            else:
                break
        return nca

    @property
    def number_field(self):
        return self.power_basis_ancestor().number_field

    def is_compat_col(self, col):
        return isinstance(col, DomainMatrix) and col.shape == (self.n, 1) and col.domain.is_ZZ

    def __call__(self, spec, denom=1):
        if isinstance(spec, int) and 0 <= spec < self.n:
            spec = DomainMatrix.eye(self.n, ZZ)[:, spec].to_dense()
        if not self.is_compat_col(spec):
            raise ValueError('Compatible column vector required.')
        return make_mod_elt(self, spec, denom=denom)

    def starts_with_unity(self):
        raise NotImplementedError

    def basis_elements(self):
        return [self(j) for j in range(self.n)]

    def zero(self):
        return self(0) * 0

    def one(self):
        return self.element_from_rational(1)

    def element_from_rational(self, a):
        raise NotImplementedError

    def submodule_from_gens(self, gens, hnf=True, hnf_modulus=None):
        if not all((g.module == self for g in gens)):
            raise ValueError('Generators must belong to this module.')
        n = len(gens)
        if n == 0:
            raise ValueError('Need at least one generator.')
        m = gens[0].n
        d = gens[0].denom if n == 1 else ilcm(*[g.denom for g in gens])
        B = DomainMatrix.zeros((m, 0), ZZ).hstack(*[d // g.denom * g.col for g in gens])
        if hnf:
            B = hermite_normal_form(B, D=hnf_modulus)
        return self.submodule_from_matrix(B, denom=d)

    def submodule_from_matrix(self, B, denom=1):
        m, n = B.shape
        if not B.domain.is_ZZ:
            raise ValueError('Matrix must be over ZZ.')
        if not m == self.n:
            raise ValueError('Matrix row count must match base module.')
        return Submodule(self, B, denom=denom)

    def whole_submodule(self):
        B = DomainMatrix.eye(self.n, ZZ)
        return self.submodule_from_matrix(B)

    def endomorphism_ring(self):
        return EndomorphismRing(self)

class PowerBasis(Module):

    def __init__(self, T):
        K = None
        if isinstance(T, AlgebraicField):
            K, T = (T, T.ext.minpoly_of_element())
        T = T.set_domain(ZZ)
        self.K = K
        self.T = T
        self._n = T.degree()
        self._mult_tab = None

    @property
    def number_field(self):
        return self.K

    def __repr__(self):
        return f'PowerBasis({self.T.as_expr()})'

    def __eq__(self, other):
        if isinstance(other, PowerBasis):
            return self.T == other.T
        return NotImplemented

    @property
    def n(self):
        return self._n

    def mult_tab(self):
        if self._mult_tab is None:
            self.compute_mult_tab()
        return {i: {j: coeffs[:] for j, coeffs in row.items()} for i, row in self._mult_tab.items()}

    def compute_mult_tab(self):
        theta_pow = AlgIntPowers(self.T)
        M = {}
        n = self.n
        for u in range(n):
            M[u] = {}
            for v in range(u, n):
                M[u][v] = theta_pow[u + v]
        self._mult_tab = M

    def represent(self, elt):
        if elt.module == self and elt.denom == 1:
            return elt.column()
        else:
            raise ClosureFailure('Element not representable in ZZ[theta].')

    def starts_with_unity(self):
        return True

    def element_from_rational(self, a):
        return self(0) * a

    def element_from_poly(self, f):
        n, k = (self.n, f.degree())
        if k >= n:
            f = f % self.T
        if f == 0:
            return self.zero()
        d, c = dup_clear_denoms(f.rep.to_list(), QQ, convert=True)
        c = list(reversed(c))
        ell = len(c)
        z = [ZZ(0)] * (n - ell)
        col = to_col(c + z)
        return self(col, denom=d)

    def _element_from_rep_and_mod(self, rep, mod):
        if mod != self.T.rep.to_list():
            raise UnificationFailed('Element does not appear to be in the same field.')
        return self.element_from_poly(Poly(rep, self.T.gen))

    def element_from_ANP(self, a):
        return self._element_from_rep_and_mod(a.to_list(), a.mod_to_list())

    def element_from_alg_num(self, a):
        return self._element_from_rep_and_mod(a.rep.to_list(), a.minpoly.rep.to_list())

class Submodule(Module, IntegerPowerable):

    def __init__(self, parent, matrix, denom=1, mult_tab=None):
        self._parent = parent
        self._matrix = matrix
        self._denom = denom
        self._mult_tab = mult_tab
        self._n = matrix.shape[1]
        self._QQ_matrix = None
        self._starts_with_unity = None
        self._is_sq_maxrank_HNF = None

    def __repr__(self):
        r = 'Submodule' + repr(self.matrix.transpose().to_Matrix().tolist())
        if self.denom > 1:
            r += f'/{self.denom}'
        return r

    def reduced(self):
        if self.denom == 1:
            return self
        g = igcd(self.denom, *self.coeffs)
        if g == 1:
            return self
        return type(self)(self.parent, (self.matrix / g).convert_to(ZZ), denom=self.denom // g, mult_tab=self._mult_tab)

    def discard_before(self, r):
        W = self.matrix[:, r:]
        s = self.n - r
        M = None
        mt = self._mult_tab
        if mt is not None:
            M = {}
            for u in range(s):
                M[u] = {}
                for v in range(u, s):
                    M[u][v] = mt[r + u][r + v][r:]
        return Submodule(self.parent, W, denom=self.denom, mult_tab=M)

    @property
    def n(self):
        return self._n

    def mult_tab(self):
        if self._mult_tab is None:
            self.compute_mult_tab()
        return {i: {j: coeffs[:] for j, coeffs in row.items()} for i, row in self._mult_tab.items()}

    def compute_mult_tab(self):
        gens = self.basis_element_pullbacks()
        M = {}
        n = self.n
        for u in range(n):
            M[u] = {}
            for v in range(u, n):
                M[u][v] = self.represent(gens[u] * gens[v]).flat()
        self._mult_tab = M

    @property
    def parent(self):
        return self._parent

    @property
    def matrix(self):
        return self._matrix

    @property
    def coeffs(self):
        return self.matrix.flat()

    @property
    def denom(self):
        return self._denom

    @property
    def QQ_matrix(self):
        if self._QQ_matrix is None:
            self._QQ_matrix = (self.matrix / self.denom).to_dense()
        return self._QQ_matrix

    def starts_with_unity(self):
        if self._starts_with_unity is None:
            self._starts_with_unity = self(0).equiv(1)
        return self._starts_with_unity

    def is_sq_maxrank_HNF(self):
        if self._is_sq_maxrank_HNF is None:
            self._is_sq_maxrank_HNF = is_sq_maxrank_HNF(self._matrix)
        return self._is_sq_maxrank_HNF

    def is_power_basis_submodule(self):
        return isinstance(self.parent, PowerBasis)

    def element_from_rational(self, a):
        if self.starts_with_unity():
            return self(0) * a
        else:
            return self.parent.element_from_rational(a)

    def basis_element_pullbacks(self):
        return [e.to_parent() for e in self.basis_elements()]

    def represent(self, elt):
        if elt.module == self:
            return elt.column()
        elif elt.module == self.parent:
            try:
                A = self.QQ_matrix
                b = elt.QQ_col
                x = A._solve(b)[0].transpose()
                x = x.convert_to(ZZ)
            except DMBadInputError:
                raise ClosureFailure('Element outside QQ-span of this basis.')
            except CoercionFailed:
                raise ClosureFailure('Element in QQ-span but not ZZ-span of this basis.')
            return x
        elif isinstance(self.parent, Submodule):
            coeffs_in_parent = self.parent.represent(elt)
            parent_element = self.parent(coeffs_in_parent)
            return self.represent(parent_element)
        else:
            raise ClosureFailure('Element outside ancestor chain of this module.')

    def is_compat_submodule(self, other):
        return isinstance(other, Submodule) and other.parent == self.parent

    def __eq__(self, other):
        if self.is_compat_submodule(other):
            return other.QQ_matrix == self.QQ_matrix
        return NotImplemented

    def add(self, other, hnf=True, hnf_modulus=None):
        d, e = (self.denom, other.denom)
        m = ilcm(d, e)
        a, b = (m // d, m // e)
        B = (a * self.matrix).hstack(b * other.matrix)
        if hnf:
            B = hermite_normal_form(B, D=hnf_modulus)
        return self.parent.submodule_from_matrix(B, denom=m)

    def __add__(self, other):
        if self.is_compat_submodule(other):
            return self.add(other)
        return NotImplemented
    __radd__ = __add__

    def mul(self, other, hnf=True, hnf_modulus=None):
        if is_rat(other):
            a, b = get_num_denom(other)
            if a == b == 1:
                return self
            else:
                return Submodule(self.parent, self.matrix * a, denom=self.denom * b, mult_tab=None).reduced()
        elif isinstance(other, ModuleElement) and other.module == self.parent:
            gens = [other * e for e in self.basis_element_pullbacks()]
            return self.parent.submodule_from_gens(gens, hnf=hnf, hnf_modulus=hnf_modulus)
        elif self.is_compat_submodule(other):
            alphas, betas = (self.basis_element_pullbacks(), other.basis_element_pullbacks())
            gens = [a * b for a in alphas for b in betas]
            return self.parent.submodule_from_gens(gens, hnf=hnf, hnf_modulus=hnf_modulus)
        return NotImplemented

    def __mul__(self, other):
        return self.mul(other)
    __rmul__ = __mul__

    def _first_power(self):
        return self

    def reduce_element(self, elt):
        if not elt.module == self.parent:
            raise NotImplementedError
        if not self.is_sq_maxrank_HNF():
            msg = 'Reduction not implemented unless matrix square max-rank HNF'
            raise StructureError(msg)
        B = self.basis_element_pullbacks()
        a = elt
        for i in range(self.n - 1, -1, -1):
            b = B[i]
            q = a.coeffs[i] * b.denom // (b.coeffs[i] * a.denom)
            a -= q * b
        return a

def is_sq_maxrank_HNF(dm):
    if dm.domain.is_ZZ and dm.is_square and dm.is_upper:
        n = dm.shape[0]
        for i in range(n):
            d = dm[i, i].element
            if d <= 0:
                return False
            for j in range(i + 1, n):
                if not 0 <= dm[i, j].element < d:
                    return False
        return True
    return False

def make_mod_elt(module, col, denom=1):
    if isinstance(module, PowerBasis):
        return PowerBasisElement(module, col, denom=denom)
    else:
        return ModuleElement(module, col, denom=denom)

class ModuleElement(IntegerPowerable):

    def __init__(self, module, col, denom=1):
        self.module = module
        self.col = col
        self.denom = denom
        self._QQ_col = None

    def __repr__(self):
        r = str([int(c) for c in self.col.flat()])
        if self.denom > 1:
            r += f'/{self.denom}'
        return r

    def reduced(self):
        if self.denom == 1:
            return self
        g = igcd(self.denom, *self.coeffs)
        if g == 1:
            return self
        return type(self)(self.module, (self.col / g).convert_to(ZZ), denom=self.denom // g)

    def reduced_mod_p(self, p):
        return make_mod_elt(self.module, self.col.convert_to(FF(p)).convert_to(ZZ), denom=self.denom)

    @classmethod
    def from_int_list(cls, module, coeffs, denom=1):
        col = to_col(coeffs)
        return cls(module, col, denom=denom)

    @property
    def n(self):
        return self.module.n

    def __len__(self):
        return self.n

    def column(self, domain=None):
        if domain is None:
            return self.col.copy()
        else:
            return self.col.convert_to(domain)

    @property
    def coeffs(self):
        return self.col.flat()

    @property
    def QQ_col(self):
        if self._QQ_col is None:
            self._QQ_col = (self.col / self.denom).to_dense()
        return self._QQ_col

    def to_parent(self):
        if not isinstance(self.module, Submodule):
            raise ValueError('Not an element of a Submodule.')
        return make_mod_elt(self.module.parent, self.module.matrix * self.col, denom=self.module.denom * self.denom)

    def to_ancestor(self, anc):
        if anc == self.module:
            return self
        else:
            return self.to_parent().to_ancestor(anc)

    def over_power_basis(self):
        e = self
        while not isinstance(e.module, PowerBasis):
            e = e.to_parent()
        return e

    def is_compat(self, other):
        return isinstance(other, ModuleElement) and other.module == self.module

    def unify(self, other):
        if self.module == other.module:
            return (self, other)
        nca = self.module.nearest_common_ancestor(other.module)
        if nca is not None:
            return (self.to_ancestor(nca), other.to_ancestor(nca))
        raise UnificationFailed(f'Cannot unify {self} with {other}')

    def __eq__(self, other):
        if self.is_compat(other):
            return self.QQ_col == other.QQ_col
        return NotImplemented

    def equiv(self, other):
        if self == other:
            return True
        elif isinstance(other, ModuleElement):
            a, b = self.unify(other)
            return a == b
        elif is_rat(other):
            if isinstance(self, PowerBasisElement):
                return self == self.module(0) * other
            else:
                return self.over_power_basis().equiv(other)
        return False

    def __add__(self, other):
        if self.is_compat(other):
            d, e = (self.denom, other.denom)
            m = ilcm(d, e)
            u, v = (m // d, m // e)
            col = to_col([u * a + v * b for a, b in zip(self.coeffs, other.coeffs)])
            return type(self)(self.module, col, denom=m).reduced()
        elif isinstance(other, ModuleElement):
            try:
                a, b = self.unify(other)
            except UnificationFailed:
                return NotImplemented
            return a + b
        elif is_rat(other):
            return self + self.module.element_from_rational(other)
        return NotImplemented
    __radd__ = __add__

    def __neg__(self):
        return self * -1

    def __sub__(self, other):
        return self + -other

    def __rsub__(self, other):
        return -self + other

    def __mul__(self, other):
        if self.is_compat(other):
            M = self.module.mult_tab()
            A, B = (self.col.flat(), other.col.flat())
            n = self.n
            C = [0] * n
            for u in range(n):
                for v in range(u, n):
                    c = A[u] * B[v]
                    if v > u:
                        c += A[v] * B[u]
                    if c != 0:
                        R = M[u][v]
                        for k in range(n):
                            C[k] += c * R[k]
            d = self.denom * other.denom
            return self.from_int_list(self.module, C, denom=d)
        elif isinstance(other, ModuleElement):
            try:
                a, b = self.unify(other)
            except UnificationFailed:
                return NotImplemented
            return a * b
        elif is_rat(other):
            a, b = get_num_denom(other)
            if a == b == 1:
                return self
            else:
                return make_mod_elt(self.module, self.col * a, denom=self.denom * b).reduced()
        return NotImplemented
    __rmul__ = __mul__

    def _zeroth_power(self):
        return self.module.one()

    def _first_power(self):
        return self

    def __floordiv__(self, a):
        if is_rat(a):
            a = QQ(a)
            return self * (1 / a)
        elif isinstance(a, ModuleElement):
            return self * (1 // a)
        return NotImplemented

    def __rfloordiv__(self, a):
        return a // self.over_power_basis()

    def __mod__(self, m):
        if is_rat(m):
            m = m * self.module.whole_submodule()
        if isinstance(m, Submodule) and m.parent == self.module:
            return m.reduce_element(self)
        return NotImplemented

class PowerBasisElement(ModuleElement):

    @property
    def T(self):
        return self.module.T

    def numerator(self, x=None):
        x = x or self.T.gen
        return Poly(reversed(self.coeffs), x, domain=ZZ)

    def poly(self, x=None):
        return self.numerator(x=x) // self.denom

    @property
    def is_rational(self):
        return self.col[1:, :].is_zero_matrix

    @property
    def generator(self):
        K = self.module.number_field
        return K.ext.alias if K and K.ext.is_aliased else self.T.gen

    def as_expr(self, x=None):
        return self.poly(x or self.generator).as_expr()

    def norm(self, T=None):
        T = T or self.T
        x = T.gen
        A = self.numerator(x=x)
        return T.resultant(A) // self.denom ** self.n

    def inverse(self):
        f = self.poly()
        f_inv = f.invert(self.T)
        return self.module.element_from_poly(f_inv)

    def __rfloordiv__(self, a):
        return self.inverse() * a

    def _negative_power(self, e, modulo=None):
        return self.inverse() ** abs(e)

    def to_ANP(self):
        return ANP(list(reversed(self.QQ_col.flat())), QQ.map(self.T.rep.to_list()), QQ)

    def to_alg_num(self):
        K = self.module.number_field
        if K:
            return K.to_alg_num(self.to_ANP())
        raise StructureError('No associated AlgebraicField')

class ModuleHomomorphism:

    def __init__(self, domain, codomain, mapping):
        self.domain = domain
        self.codomain = codomain
        self.mapping = mapping

    def matrix(self, modulus=None):
        basis = self.domain.basis_elements()
        cols = [self.codomain.represent(self.mapping(elt)) for elt in basis]
        if not cols:
            return DomainMatrix.zeros((self.codomain.n, 0), ZZ).to_dense()
        M = cols[0].hstack(*cols[1:])
        if modulus:
            M = M.convert_to(FF(modulus))
        return M

    def kernel(self, modulus=None):
        M = self.matrix(modulus=modulus)
        if modulus is None:
            M = M.convert_to(QQ)
        K = M.nullspace().convert_to(ZZ).transpose()
        return self.domain.submodule_from_matrix(K)

class ModuleEndomorphism(ModuleHomomorphism):

    def __init__(self, domain, mapping):
        super().__init__(domain, domain, mapping)

class InnerEndomorphism(ModuleEndomorphism):

    def __init__(self, domain, multiplier):
        super().__init__(domain, lambda x: multiplier * x)
        self.multiplier = multiplier

class EndomorphismRing:

    def __init__(self, domain):
        self.domain = domain

    def inner_endomorphism(self, multiplier):
        return InnerEndomorphism(self.domain, multiplier)

    def represent(self, element):
        if isinstance(element, ModuleEndomorphism) and element.domain == self.domain:
            M = element.matrix()
            m, n = M.shape
            if n == 0:
                return M
            return M[:, 0].vstack(*[M[:, j] for j in range(1, n)])
        raise NotImplementedError

def find_min_poly(alpha, domain, x=None, powers=None):
    R = alpha.module
    if not R.starts_with_unity():
        raise MissingUnityError('alpha must belong to finitely generated ring with unity.')
    if powers is None:
        powers = []
    one = R(0)
    powers.append(one)
    powers_matrix = one.column(domain=domain)
    ak = alpha
    m = None
    for k in range(1, R.n + 1):
        powers.append(ak)
        ak_col = ak.column(domain=domain)
        try:
            X = powers_matrix._solve(ak_col)[0]
        except DMBadInputError:
            powers_matrix = powers_matrix.hstack(ak_col)
            ak *= alpha
        else:
            coeffs = [1] + [-c for c in reversed(X.to_list_flat())]
            x = x or Dummy('x')
            if domain.is_FF:
                m = Poly(coeffs, x, modulus=domain.mod)
            else:
                m = Poly(coeffs, x, domain=domain)
            break
    return m