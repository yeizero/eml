from __future__ import annotations
from sympy.utilities.exceptions import sympy_deprecation_warning
from sympy.utilities.iterables import connected_components
from sympy.core.sympify import sympify
from sympy.core.numbers import Integer, Rational
from sympy.matrices.dense import MutableDenseMatrix
from sympy.polys.domains import ZZ, QQ
from sympy.polys.domains import EX
from sympy.polys.rings import sring
from sympy.polys.polyerrors import NotInvertible
from sympy.polys.domainmatrix import DomainMatrix

class PolyNonlinearError(Exception):
    pass

class RawMatrix(MutableDenseMatrix):
    _sympify = staticmethod(lambda x, *args, **kwargs: x)

    def __init__(self, *args, **kwargs):
        sympy_deprecation_warning('\n            The RawMatrix class is deprecated. Use either DomainMatrix or\n            Matrix instead.\n            ', deprecated_since_version='1.9', active_deprecations_target='deprecated-rawmatrix')
        domain = ZZ
        for i in range(self.rows):
            for j in range(self.cols):
                val = self[i, j]
                if getattr(val, 'is_Poly', False):
                    K = val.domain[val.gens]
                    val_sympy = val.as_expr()
                elif hasattr(val, 'parent'):
                    K = val.parent()
                    val_sympy = K.to_sympy(val)
                elif isinstance(val, (int, Integer)):
                    K = ZZ
                    val_sympy = sympify(val)
                elif isinstance(val, Rational):
                    K = QQ
                    val_sympy = val
                else:
                    for K in (ZZ, QQ):
                        if K.of_type(val):
                            val_sympy = K.to_sympy(val)
                            break
                    else:
                        raise TypeError
                domain = domain.unify(K)
                self[i, j] = val_sympy
        self.ring = domain

def eqs_to_matrix(eqs_coeffs, eqs_rhs, gens, domain):
    sym2index = {x: n for n, x in enumerate(gens)}
    nrows = len(eqs_coeffs)
    ncols = len(gens) + 1
    rows = [[domain.zero] * ncols for _ in range(nrows)]
    for row, eq_coeff, eq_rhs in zip(rows, eqs_coeffs, eqs_rhs):
        for sym, coeff in eq_coeff.items():
            row[sym2index[sym]] = domain.convert(coeff)
        row[-1] = -domain.convert(eq_rhs)
    return DomainMatrix(rows, (nrows, ncols), domain)

def sympy_eqs_to_ring(eqs, symbols):
    try:
        K, eqs_K = sring(eqs, symbols, field=True, extension=True)
    except NotInvertible:
        K, eqs_K = sring(eqs, symbols, domain=EX)
    return (eqs_K, K.to_domain())

def solve_lin_sys(eqs, ring, _raw=True):
    as_expr = not _raw
    assert ring.domain.is_Field
    eqs_dict = [dict(eq) for eq in eqs]
    one_monom = ring.one.monoms()[0]
    zero = ring.domain.zero
    eqs_rhs = []
    eqs_coeffs = []
    for eq_dict in eqs_dict:
        eq_rhs = eq_dict.pop(one_monom, zero)
        eq_coeffs = {}
        for monom, coeff in eq_dict.items():
            if sum(monom) != 1:
                msg = 'Nonlinear term encountered in solve_lin_sys'
                raise PolyNonlinearError(msg)
            eq_coeffs[ring.gens[monom.index(1)]] = coeff
        if not eq_coeffs:
            if not eq_rhs:
                continue
            else:
                return None
        eqs_rhs.append(eq_rhs)
        eqs_coeffs.append(eq_coeffs)
    result = _solve_lin_sys(eqs_coeffs, eqs_rhs, ring)
    if result is not None and as_expr:

        def to_sympy(x):
            as_expr = getattr(x, 'as_expr', None)
            if as_expr:
                return as_expr()
            else:
                return ring.domain.to_sympy(x)
        tresult = {to_sympy(sym): to_sympy(val) for sym, val in result.items()}
        result = {}
        for k, v in tresult.items():
            if k.is_Mul:
                c, s = k.as_coeff_Mul()
                result[s] = v / c
            else:
                result[k] = v
    return result

def _solve_lin_sys(eqs_coeffs, eqs_rhs, ring):
    V = ring.gens
    E = []
    for eq_coeffs in eqs_coeffs:
        syms = list(eq_coeffs)
        E.extend(zip(syms[:-1], syms[1:]))
    G = (V, E)
    components = connected_components(G)
    sym2comp = {}
    for n, component in enumerate(components):
        for sym in component:
            sym2comp[sym] = n
    subsystems = [([], []) for _ in range(len(components))]
    for eq_coeff, eq_rhs in zip(eqs_coeffs, eqs_rhs):
        sym = next(iter(eq_coeff), None)
        sub_coeff, sub_rhs = subsystems[sym2comp[sym]]
        sub_coeff.append(eq_coeff)
        sub_rhs.append(eq_rhs)
    sol = {}
    for subsystem in subsystems:
        subsol = _solve_lin_sys_component(subsystem[0], subsystem[1], ring)
        if subsol is None:
            return None
        sol.update(subsol)
    return sol

def _solve_lin_sys_component(eqs_coeffs, eqs_rhs, ring):
    matrix = eqs_to_matrix(eqs_coeffs, eqs_rhs, ring.gens, ring.domain)
    if not matrix.domain.is_Field:
        matrix = matrix.to_field()
    echelon, pivots = matrix.rref()
    keys = ring.gens
    if pivots and pivots[-1] == len(keys):
        return None
    if len(pivots) == len(keys):
        sol = []
        for s in [row[-1] for row in echelon.rep.to_ddm()]:
            a = s
            sol.append(a)
        sols = dict(zip(keys, sol))
    else:
        sols = {}
        g = ring.gens
        if hasattr(ring, 'ring'):
            convert = ring.ring.ground_new
        else:
            convert = ring.ground_new
        echelon = echelon.rep.to_ddm()
        vals_set = {v for row in echelon for v in row}
        vals_map = {v: convert(v) for v in vals_set}
        echelon = [[vals_map[eij] for eij in ei] for ei in echelon]
        for i, p in enumerate(pivots):
            v = echelon[i][-1] - sum((echelon[i][j] * g[j] for j in range(p + 1, len(g)) if echelon[i][j]))
            sols[keys[p]] = v
    return sols