from __future__ import annotations
from sympy.core import S, Basic, symbols, Dummy
from sympy.polys.polyerrors import PolificationFailed, ComputationFailed, MultivariatePolynomialError, OptionError
from sympy.polys.polyoptions import allowed_flags, build_options
from sympy.polys.polytools import poly_from_expr, Poly
from sympy.polys.specialpolys import symmetric_poly, interpolating_poly
from sympy.polys.rings import sring
from sympy.utilities import numbered_symbols, take, public

@public
def symmetrize(F, *gens, **args):
    allowed_flags(args, ['formal', 'symbols'])
    iterable = True
    if not hasattr(F, '__iter__'):
        iterable = False
        F = [F]
    R, F = sring(F, *gens, **args)
    gens = R.symbols
    opt = build_options(gens, args)
    symbols = opt.symbols
    symbols = [next(symbols) for i in range(len(gens))]
    result = []
    for f in F:
        p, r, m = f.symmetrize()
        result.append((p.as_expr(*symbols), r.as_expr(*gens)))
    polys = [(s, g.as_expr()) for s, (_, g) in zip(symbols, m)]
    if not opt.formal:
        for i, (sym, non_sym) in enumerate(result):
            result[i] = (sym.subs(polys), non_sym)
    if not iterable:
        result, = result
    if not opt.formal:
        return result
    elif iterable:
        return (result, polys)
    else:
        return result + (polys,)

@public
def horner(f, *gens, **args):
    allowed_flags(args, [])
    try:
        F, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        return exc.expr
    form, gen = (S.Zero, F.gen)
    if F.is_univariate:
        for coeff in F.all_coeffs():
            form = form * gen + coeff
    else:
        F, gens = (Poly(F, gen), gens[1:])
        for coeff in F.all_coeffs():
            form = form * gen + horner(coeff, *gens, **args)
    return form

@public
def interpolate(data, x):
    n = len(data)
    if isinstance(data, dict):
        if x in data:
            return S(data[x])
        X, Y = list(zip(*data.items()))
    elif isinstance(data[0], tuple):
        X, Y = list(zip(*data))
        if x in X:
            return S(Y[X.index(x)])
    else:
        if x in range(1, n + 1):
            return S(data[x - 1])
        Y = list(data)
        X = list(range(1, n + 1))
    try:
        return interpolating_poly(n, x, X, Y).expand()
    except ValueError:
        d = Dummy()
        return interpolating_poly(n, d, X, Y).expand().subs(d, x)

@public
def rational_interpolate(data, degnum, X=symbols('x')):
    from sympy.matrices.dense import ones
    xdata, ydata = list(zip(*data))
    k = len(xdata) - degnum - 1
    if k < 0:
        raise OptionError('Too few values for the required degree.')
    c = ones(degnum + k + 1, degnum + k + 2)
    for j in range(max(degnum, k)):
        for i in range(degnum + k + 1):
            c[i, j + 1] = c[i, j] * xdata[i]
    for j in range(k + 1):
        for i in range(degnum + k + 1):
            c[i, degnum + k + 1 - j] = -c[i, k - j] * ydata[i]
    r = c.nullspace()[0]
    return sum((r[i] * X ** i for i in range(degnum + 1))) / sum((r[i + degnum + 1] * X ** i for i in range(k + 1)))

@public
def viete(f, roots=None, *gens, **args):
    allowed_flags(args, [])
    if isinstance(roots, Basic):
        gens, roots = ((roots,) + gens, None)
    try:
        f, opt = poly_from_expr(f, *gens, **args)
    except PolificationFailed as exc:
        raise ComputationFailed('viete', 1, exc)
    if f.is_multivariate:
        raise MultivariatePolynomialError('multivariate polynomials are not allowed')
    n = f.degree()
    if n < 1:
        raise ValueError("Cannot derive Viete's formulas for a constant polynomial")
    if roots is None:
        roots = numbered_symbols('r', start=1)
    roots = take(roots, n)
    if n != len(roots):
        raise ValueError('required %s roots, got %s' % (n, len(roots)))
    lc, coeffs = (f.LC(), f.all_coeffs())
    result, sign = ([], -1)
    for i, coeff in enumerate(coeffs[1:]):
        poly = symmetric_poly(i + 1, roots)
        coeff = sign * (coeff / lc)
        result.append((poly, coeff))
        sign = -sign
    return result