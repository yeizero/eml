from __future__ import annotations
from sympy.external.gmpy import GROUND_TYPES
if GROUND_TYPES == 'flint':
    from ._dfm import DFM
else:

    class DFM_dummy:

        def __init__(*args, **kwargs):
            raise NotImplementedError('DFM requires GROUND_TYPES=flint.')

        @classmethod
        def _supports_domain(cls, domain):
            return False

        @classmethod
        def _get_flint_func(cls, domain):
            raise NotImplementedError('DFM requires GROUND_TYPES=flint.')
    DFM = DFM_dummy