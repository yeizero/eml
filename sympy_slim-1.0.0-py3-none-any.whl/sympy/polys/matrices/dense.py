from __future__ import annotations
from operator import mul
from .exceptions import DMShapeError, DMDomainError, DMNonInvertibleMatrixError, DMNonSquareMatrixError
from typing import Sequence, TypeVar
from sympy.polys.matrices._typing import RingElement
T = TypeVar('T')
R = TypeVar('R', bound=RingElement)

def ddm_transpose(matrix: Sequence[Sequence[T]]) -> list[list[T]]:
    return list(map(list, zip(*matrix)))

def ddm_iadd(a: list[list[R]], b: Sequence[Sequence[R]]) -> None:
    for ai, bi in zip(a, b):
        for j, bij in enumerate(bi):
            ai[j] += bij

def ddm_isub(a: list[list[R]], b: Sequence[Sequence[R]]) -> None:
    for ai, bi in zip(a, b):
        for j, bij in enumerate(bi):
            ai[j] -= bij

def ddm_ineg(a: list[list[R]]) -> None:
    for ai in a:
        for j, aij in enumerate(ai):
            ai[j] = -aij

def ddm_imul(a: list[list[R]], b: R) -> None:
    for ai in a:
        for j, aij in enumerate(ai):
            ai[j] = aij * b

def ddm_irmul(a: list[list[R]], b: R) -> None:
    for ai in a:
        for j, aij in enumerate(ai):
            ai[j] = b * aij

def ddm_imatmul(a: list[list[R]], b: Sequence[Sequence[R]], c: Sequence[Sequence[R]]) -> None:
    cT = list(zip(*c))
    for bi, ai in zip(b, a):
        for j, cTj in enumerate(cT):
            ai[j] = sum(map(mul, bi, cTj), ai[j])

def ddm_irref(a, _partial_pivot=False):
    m = len(a)
    if not m:
        return []
    n = len(a[0])
    i = 0
    pivots = []
    for j in range(n):
        if _partial_pivot:
            ip = max(range(i, m), key=lambda ip: abs(a[ip][j]))
            a[i], a[ip] = (a[ip], a[i])
        aij = a[i][j]
        if not aij:
            for ip in range(i + 1, m):
                aij = a[ip][j]
                if aij:
                    a[i], a[ip] = (a[ip], a[i])
                    break
            else:
                continue
        ai = a[i]
        aijinv = aij ** (-1)
        for l in range(j, n):
            ai[l] *= aijinv
        for k, ak in enumerate(a):
            if k == i or not ak[j]:
                continue
            akj = ak[j]
            ak[j] -= akj
            for l in range(j + 1, n):
                ak[l] -= akj * ai[l]
        pivots.append(j)
        i += 1
        if i >= m:
            break
    return pivots

def ddm_irref_den(a, K):
    m = len(a)
    if not m:
        return (K.one, [])
    n = len(a[0])
    d = None
    pivots = []
    no_pivots = []
    i = 0
    for j in range(n):
        aij = a[i][j]
        if not aij:
            for ip in range(i + 1, m):
                aij = a[ip][j]
                if aij:
                    a[i], a[ip] = (a[ip], a[i])
                    break
            else:
                no_pivots.append(j)
                continue
        if pivots:
            pivot_val = aij * a[0][pivots[0]]
            if d is not None:
                pivot_val = K.exquo(pivot_val, d)
            for ip, jp in enumerate(pivots):
                a[ip][jp] = pivot_val
        for jnp in no_pivots:
            for ip in range(i):
                aijp = a[ip][jnp]
                if aijp:
                    aijp *= aij
                    if d is not None:
                        aijp = K.exquo(aijp, d)
                    a[ip][jnp] = aijp
        for jp, aj in enumerate(a):
            if jp == i:
                continue
            for kp in range(j + 1, n):
                ajk = aij * aj[kp] - aj[j] * a[i][kp]
                if d is not None:
                    ajk = K.exquo(ajk, d)
                aj[kp] = ajk
            aj[j] = K.zero
        pivots.append(j)
        i += 1
        if i >= m:
            break
        if not K.is_one(aij):
            d = aij
        else:
            d = None
    if not pivots:
        denom = K.one
    else:
        denom = a[0][pivots[0]]
    return (denom, pivots)

def ddm_idet(a, K):
    m = len(a)
    if not m:
        return K.one
    n = len(a[0])
    exquo = K.exquo
    uf = K.one
    for k in range(n - 1):
        if not a[k][k]:
            for i in range(k + 1, n):
                if a[i][k]:
                    a[k], a[i] = (a[i], a[k])
                    uf = -uf
                    break
            else:
                return K.zero
        akkm1 = a[k - 1][k - 1] if k else K.one
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                a[i][j] = exquo(a[i][j] * a[k][k] - a[i][k] * a[k][j], akkm1)
    return uf * a[-1][-1]

def ddm_iinv(ainv, a, K):
    if not K.is_Field:
        raise DMDomainError('Not a field')
    m = len(a)
    if not m:
        return
    n = len(a[0])
    if m != n:
        raise DMNonSquareMatrixError
    eye = [[K.one if i == j else K.zero for j in range(n)] for i in range(n)]
    Aaug = [row + eyerow for row, eyerow in zip(a, eye)]
    pivots = ddm_irref(Aaug)
    if pivots != list(range(n)):
        raise DMNonInvertibleMatrixError('Matrix det == 0; not invertible.')
    ainv[:] = [row[n:] for row in Aaug]

def ddm_ilu_split(L, U, K):
    m = len(U)
    if not m:
        return []
    n = len(U[0])
    swaps = ddm_ilu(U)
    zeros = [K.zero] * min(m, n)
    for i in range(1, m):
        j = min(i, n)
        L[i][:j] = U[i][:j]
        U[i][:j] = zeros[:j]
    return swaps

def ddm_ilu(a):
    m = len(a)
    if not m:
        return []
    n = len(a[0])
    swaps = []
    for i in range(min(m, n)):
        if not a[i][i]:
            for ip in range(i + 1, m):
                if a[ip][i]:
                    swaps.append((i, ip))
                    a[i], a[ip] = (a[ip], a[i])
                    break
            else:
                continue
        for j in range(i + 1, m):
            l_ji = a[j][i] / a[i][i]
            a[j][i] = l_ji
            for k in range(i + 1, n):
                a[j][k] -= l_ji * a[i][k]
    return swaps

def ddm_ilu_solve(x, L, U, swaps, b):
    m = len(U)
    if not m:
        return
    n = len(U[0])
    m2 = len(b)
    if not m2:
        raise DMShapeError('Shape mismtch')
    o = len(b[0])
    if m != m2:
        raise DMShapeError('Shape mismtch')
    if m < n:
        raise NotImplementedError('Underdetermined')
    if swaps:
        b = [row[:] for row in b]
        for i1, i2 in swaps:
            b[i1], b[i2] = (b[i2], b[i1])
    y = [[None] * o for _ in range(m)]
    for k in range(o):
        for i in range(m):
            rhs = b[i][k]
            for j in range(i):
                rhs -= L[i][j] * y[j][k]
            y[i][k] = rhs
    if m > n:
        for i in range(n, m):
            for j in range(o):
                if y[i][j]:
                    raise DMNonInvertibleMatrixError
    for k in range(o):
        for i in reversed(range(n)):
            if not U[i][i]:
                raise DMNonInvertibleMatrixError
            rhs = y[i][k]
            for j in range(i + 1, n):
                rhs -= U[i][j] * x[j][k]
            x[i][k] = rhs / U[i][i]

def ddm_berk(M, K):
    m = len(M)
    if not m:
        return [[K.one]]
    n = len(M[0])
    if m != n:
        raise DMShapeError('Not square')
    if n == 1:
        return [[K.one], [-M[0][0]]]
    a = M[0][0]
    R = [M[0][1:]]
    C = [[row[0]] for row in M[1:]]
    A = [row[1:] for row in M[1:]]
    q = ddm_berk(A, K)
    T = [[K.zero] * n for _ in range(n + 1)]
    for i in range(n):
        T[i][i] = K.one
        T[i + 1][i] = -a
    for i in range(2, n + 1):
        if i == 2:
            AnC = C
        else:
            C = AnC
            AnC = [[K.zero] for row in C]
            ddm_imatmul(AnC, A, C)
        RAnC = [[K.zero]]
        ddm_imatmul(RAnC, R, AnC)
        for j in range(0, n + 1 - i):
            T[i + j][j] = -RAnC[0][0]
    qout = [[K.zero] for _ in range(n + 1)]
    ddm_imatmul(qout, T, q)
    return qout