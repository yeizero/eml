from __future__ import annotations
from sympy.external.gmpy import GROUND_TYPES
from sympy.external.importtools import import_module
from sympy.utilities.decorator import doctest_depends_on
from sympy.polys.domains import ZZ, QQ
from .exceptions import DMBadInputError, DMDomainError, DMNonSquareMatrixError, DMNonInvertibleMatrixError, DMRankError, DMShapeError, DMValueError
if GROUND_TYPES != 'flint':
    __doctest_skip__ = ['*']
flint = import_module('flint')
__all__ = ['DFM']

@doctest_depends_on(ground_types=['flint'])
class DFM:
    fmt = 'dense'
    is_DFM = True
    is_DDM = False

    def __new__(cls, rowslist, shape, domain):
        flint_mat = cls._get_flint_func(domain)
        if 0 not in shape:
            try:
                rep = flint_mat(rowslist)
            except (ValueError, TypeError):
                raise DMBadInputError(f'Input should be a list of list of {domain}')
        else:
            rep = flint_mat(*shape)
        return cls._new(rep, shape, domain)

    @classmethod
    def _new(cls, rep, shape, domain):
        cls._check(rep, shape, domain)
        obj = object.__new__(cls)
        obj.rep = rep
        obj.shape = obj.rows, obj.cols = shape
        obj.domain = domain
        return obj

    def _new_rep(self, rep):
        return self._new(rep, self.shape, self.domain)

    @classmethod
    def _check(cls, rep, shape, domain):
        repshape = (rep.nrows(), rep.ncols())
        if repshape != shape:
            raise DMBadInputError('Shape of rep does not match shape of DFM')
        if domain == ZZ and (not isinstance(rep, flint.fmpz_mat)):
            raise RuntimeError('Rep is not a flint.fmpz_mat')
        elif domain == QQ and (not isinstance(rep, flint.fmpq_mat)):
            raise RuntimeError('Rep is not a flint.fmpq_mat')
        elif domain.is_FF and (not isinstance(rep, (flint.fmpz_mod_mat, flint.nmod_mat))):
            raise RuntimeError('Rep is not a flint.fmpz_mod_mat or flint.nmod_mat')
        elif domain not in (ZZ, QQ) and (not domain.is_FF):
            raise NotImplementedError('Only ZZ and QQ are supported by DFM')

    @classmethod
    def _supports_domain(cls, domain):
        return domain in (ZZ, QQ) or (domain.is_FF and domain._is_flint)

    @classmethod
    def _get_flint_func(cls, domain):
        if domain == ZZ:
            return flint.fmpz_mat
        elif domain == QQ:
            return flint.fmpq_mat
        elif domain.is_FF:
            c = domain.characteristic()
            if isinstance(domain.one, flint.nmod):
                _cls = flint.nmod_mat

                def _func(*e):
                    if len(e) == 1 and isinstance(e[0], flint.nmod_mat):
                        return _cls(e[0])
                    else:
                        return _cls(*e, c)
            else:
                m = flint.fmpz_mod_ctx(c)
                _func = lambda *e: flint.fmpz_mod_mat(*e, m)
            return _func
        else:
            raise NotImplementedError('Only ZZ and QQ are supported by DFM')

    @property
    def _func(self):
        return self._get_flint_func(self.domain)

    def __str__(self):
        return str(self.to_ddm())

    def __repr__(self):
        return f'DFM{repr(self.to_ddm())[3:]}'

    def __eq__(self, other):
        if not isinstance(other, DFM):
            return NotImplemented
        return self.domain == other.domain and self.rep == other.rep

    @classmethod
    def from_list(cls, rowslist, shape, domain):
        return cls(rowslist, shape, domain)

    def to_list(self):
        return self.rep.tolist()

    def copy(self):
        return self._new_rep(self._func(self.rep))

    def to_ddm(self):
        return DDM.from_list(self.to_list(), self.shape, self.domain)

    def to_sdm(self):
        return SDM.from_list(self.to_list(), self.shape, self.domain)

    def to_dfm(self):
        return self

    def to_dfm_or_ddm(self):
        return self

    @classmethod
    def from_ddm(cls, ddm):
        return cls.from_list(ddm.to_list(), ddm.shape, ddm.domain)

    @classmethod
    def from_list_flat(cls, elements, shape, domain):
        func = cls._get_flint_func(domain)
        try:
            rep = func(*shape, elements)
        except ValueError:
            raise DMBadInputError(f'Incorrect number of elements for shape {shape}')
        except TypeError:
            raise DMBadInputError(f'Input should be a list of {domain}')
        return cls(rep, shape, domain)

    def to_list_flat(self):
        return self.rep.entries()

    def to_flat_nz(self):
        return self.to_ddm().to_flat_nz()

    @classmethod
    def from_flat_nz(cls, elements, data, domain):
        return DDM.from_flat_nz(elements, data, domain).to_dfm()

    def to_dod(self):
        return self.to_ddm().to_dod()

    @classmethod
    def from_dod(cls, dod, shape, domain):
        return DDM.from_dod(dod, shape, domain).to_dfm()

    def to_dok(self):
        return self.to_ddm().to_dok()

    @classmethod
    def from_dok(cls, dok, shape, domain):
        return DDM.from_dok(dok, shape, domain).to_dfm()

    def iter_values(self):
        m, n = self.shape
        rep = self.rep
        for i in range(m):
            for j in range(n):
                repij = rep[i, j]
                if repij:
                    yield rep[i, j]

    def iter_items(self):
        m, n = self.shape
        rep = self.rep
        for i in range(m):
            for j in range(n):
                repij = rep[i, j]
                if repij:
                    yield ((i, j), repij)

    def convert_to(self, domain):
        if domain == self.domain:
            return self.copy()
        elif domain == QQ and self.domain == ZZ:
            return self._new(flint.fmpq_mat(self.rep), self.shape, domain)
        elif self._supports_domain(domain):
            return self.to_ddm().convert_to(domain).to_dfm()
        else:
            raise NotImplementedError('Only ZZ and QQ are supported by DFM')

    def getitem(self, i, j):
        m, n = self.shape
        if i < 0:
            i += m
        if j < 0:
            j += n
        try:
            return self.rep[i, j]
        except ValueError:
            raise IndexError(f'Invalid indices ({i}, {j}) for Matrix of shape {self.shape}')

    def setitem(self, i, j, value):
        m, n = self.shape
        if i < 0:
            i += m
        if j < 0:
            j += n
        try:
            self.rep[i, j] = value
        except ValueError:
            raise IndexError(f'Invalid indices ({i}, {j}) for Matrix of shape {self.shape}')

    def _extract(self, i_indices, j_indices):
        M = self.rep
        lol = [[M[i, j] for j in j_indices] for i in i_indices]
        shape = (len(i_indices), len(j_indices))
        return self.from_list(lol, shape, self.domain)

    def extract(self, rowslist, colslist):
        m, n = self.shape
        new_rows = []
        new_cols = []
        for i in rowslist:
            if i < 0:
                i_pos = i + m
            else:
                i_pos = i
            if not 0 <= i_pos < m:
                raise IndexError(f'Invalid row index {i} for Matrix of shape {self.shape}')
            new_rows.append(i_pos)
        for j in colslist:
            if j < 0:
                j_pos = j + n
            else:
                j_pos = j
            if not 0 <= j_pos < n:
                raise IndexError(f'Invalid column index {j} for Matrix of shape {self.shape}')
            new_cols.append(j_pos)
        return self._extract(new_rows, new_cols)

    def extract_slice(self, rowslice, colslice):
        m, n = self.shape
        i_indices = range(m)[rowslice]
        j_indices = range(n)[colslice]
        return self._extract(i_indices, j_indices)

    def neg(self):
        return self._new_rep(-self.rep)

    def add(self, other):
        return self._new_rep(self.rep + other.rep)

    def sub(self, other):
        return self._new_rep(self.rep - other.rep)

    def mul(self, other):
        return self._new_rep(self.rep * other)

    def rmul(self, other):
        return self._new_rep(other * self.rep)

    def mul_elementwise(self, other):
        return self.to_ddm().mul_elementwise(other.to_ddm()).to_dfm()

    def matmul(self, other):
        shape = (self.rows, other.cols)
        return self._new(self.rep * other.rep, shape, self.domain)

    def __neg__(self):
        return self.neg()

    @classmethod
    def zeros(cls, shape, domain):
        func = cls._get_flint_func(domain)
        return cls._new(func(*shape), shape, domain)

    @classmethod
    def ones(cls, shape, domain):
        return DDM.ones(shape, domain).to_dfm()

    @classmethod
    def eye(cls, n, domain):
        return DDM.eye(n, domain).to_dfm()

    @classmethod
    def diag(cls, elements, domain):
        return DDM.diag(elements, domain).to_dfm()

    def applyfunc(self, func, domain):
        return self.to_ddm().applyfunc(func, domain).to_dfm()

    def transpose(self):
        return self._new(self.rep.transpose(), (self.cols, self.rows), self.domain)

    def hstack(self, *others):
        return self.to_ddm().hstack(*[o.to_ddm() for o in others]).to_dfm()

    def vstack(self, *others):
        return self.to_ddm().vstack(*[o.to_ddm() for o in others]).to_dfm()

    def diagonal(self):
        M = self.rep
        m, n = self.shape
        return [M[i, i] for i in range(min(m, n))]

    def is_upper(self):
        M = self.rep
        for i in range(self.rows):
            for j in range(min(i, self.cols)):
                if M[i, j]:
                    return False
        return True

    def is_lower(self):
        M = self.rep
        for i in range(self.rows):
            for j in range(i + 1, self.cols):
                if M[i, j]:
                    return False
        return True

    def is_diagonal(self):
        return self.is_upper() and self.is_lower()

    def is_zero_matrix(self):
        M = self.rep
        for i in range(self.rows):
            for j in range(self.cols):
                if M[i, j]:
                    return False
        return True

    def nnz(self):
        return self.to_ddm().nnz()

    def scc(self):
        return self.to_ddm().scc()

    @doctest_depends_on(ground_types='flint')
    def det(self):
        return self.rep.det()

    @doctest_depends_on(ground_types='flint')
    def charpoly(self):
        return self.rep.charpoly().coeffs()[::-1]

    @doctest_depends_on(ground_types='flint')
    def inv(self):
        K = self.domain
        m, n = self.shape
        if m != n:
            raise DMNonSquareMatrixError('cannot invert a non-square matrix')
        if K == ZZ:
            raise DMDomainError('field expected, got %s' % K)
        elif K == QQ or K.is_FF:
            try:
                return self._new_rep(self.rep.inv())
            except ZeroDivisionError:
                raise DMNonInvertibleMatrixError('matrix is not invertible')
        else:
            raise NotImplementedError('DFM.inv() is not implemented for %s' % K)

    def lu(self):
        L, U, swaps = self.to_ddm().lu()
        return (L.to_dfm(), U.to_dfm(), swaps)

    def qr(self):
        Q, R = self.to_ddm().qr()
        return (Q.to_dfm(), R.to_dfm())

    @doctest_depends_on(ground_types='flint')
    def lu_solve(self, rhs):
        if not self.domain == rhs.domain:
            raise DMDomainError('Domains must match: %s != %s' % (self.domain, rhs.domain))
        if not self.domain.is_Field:
            raise DMDomainError('Field expected, got %s' % self.domain)
        m, n = self.shape
        j, k = rhs.shape
        if m != j:
            raise DMShapeError('Matrix size mismatch: %s * %s vs %s * %s' % (m, n, j, k))
        sol_shape = (n, k)
        if m != n:
            return self.to_ddm().lu_solve(rhs.to_ddm()).to_dfm()
        try:
            sol = self.rep.solve(rhs.rep)
        except ZeroDivisionError:
            raise DMNonInvertibleMatrixError('Matrix det == 0; not invertible.')
        return self._new(sol, sol_shape, self.domain)

    def fflu(self):
        if self.domain == ZZ:
            fflu = getattr(self.rep, 'fflu', None)
            if fflu is not None:
                P, L, D, U = self.rep.fflu()
                m, n = self.shape
                return (self._new(P, (m, m), self.domain), self._new(L, (m, m), self.domain), self._new(D, (m, m), self.domain), self._new(U, self.shape, self.domain))
        ddm_p, ddm_l, ddm_d, ddm_u = self.to_ddm().fflu()
        P = ddm_p.to_dfm()
        L = ddm_l.to_dfm()
        D = ddm_d.to_dfm()
        U = ddm_u.to_dfm()
        return (P, L, D, U)

    def nullspace(self):
        ddm, nonpivots = self.to_ddm().nullspace()
        return (ddm.to_dfm(), nonpivots)

    def nullspace_from_rref(self, pivots=None):
        sdm, nonpivots = self.to_sdm().nullspace_from_rref(pivots=pivots)
        return (sdm.to_dfm(), nonpivots)

    def particular(self):
        return self.to_ddm().particular().to_dfm()

    def _lll(self, transform=False, delta=0.99, eta=0.51, rep='zbasis', gram='approx'):

        def to_float(x):
            if QQ.of_type(x):
                return float(x.numerator) / float(x.denominator)
            else:
                return float(x)
        delta = to_float(delta)
        eta = to_float(eta)
        if not 0.25 < delta < 1:
            raise DMValueError('delta must be between 0.25 and 1')
        m, n = self.shape
        if self.rep.rank() != m:
            raise DMRankError('Matrix must have full row rank for Flint LLL.')
        return self.rep.lll(transform=transform, delta=delta, eta=eta, rep=rep, gram=gram)

    @doctest_depends_on(ground_types='flint')
    def lll(self, delta=0.75):
        if self.domain != ZZ:
            raise DMDomainError('ZZ expected, got %s' % self.domain)
        elif self.rows > self.cols:
            raise DMShapeError('Matrix must not have more rows than columns.')
        rep = self._lll(delta=delta)
        return self._new_rep(rep)

    @doctest_depends_on(ground_types='flint')
    def lll_transform(self, delta=0.75):
        if self.domain != ZZ:
            raise DMDomainError('ZZ expected, got %s' % self.domain)
        elif self.rows > self.cols:
            raise DMShapeError('Matrix must not have more rows than columns.')
        rep, T = self._lll(transform=True, delta=delta)
        basis = self._new_rep(rep)
        T_dfm = self._new(T, (self.rows, self.rows), self.domain)
        return (basis, T_dfm)
from sympy.polys.matrices.ddm import DDM
from sympy.polys.matrices.ddm import SDM