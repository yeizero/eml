from __future__ import annotations
from typing import overload, TYPE_CHECKING
from collections import Counter
from functools import reduce
from sympy.external.gmpy import GROUND_TYPES
from sympy.utilities.decorator import doctest_depends_on
from sympy.core.sympify import _sympify
from ..constructor import construct_domain
from .exceptions import DMFormatError, DMBadInputError, DMShapeError, DMDomainError, DMNotAField, DMNonSquareMatrixError, DMNonInvertibleMatrixError
from .domainscalar import DomainScalar
from sympy.polys.domains import ZZ, EXRAW, QQ
from sympy.polys.densearith import dup_mul, dup_exquo_ground
from sympy.polys.densebasic import dup_convert
from sympy.polys.densetools import dup_mul_ground, dup_content, dup_clear_denoms, dup_primitive, dup_transform
from sympy.polys.factortools import dup_factor_list
from sympy.polys.polyutils import _sort_factors
from .ddm import DDM
from .sdm import SDM
from .dfm import DFM
from .rref import _dm_rref, _dm_rref_den
if TYPE_CHECKING:
    from ..domains import Domain
if GROUND_TYPES != 'flint':
    __doctest_skip__ = ['DomainMatrix.to_dfm', 'DomainMatrix.to_dfm_or_ddm']
else:
    __doctest_skip__ = ['DomainMatrix.from_list']

def DM(rows, domain):
    return DomainMatrix.from_list(rows, domain)

class DomainMatrix:
    rep: SDM | DDM | DFM
    shape: tuple[int, int]
    domain: Domain

    def __new__(cls, rows, shape, domain, *, fmt=None):
        if isinstance(rows, (DDM, SDM, DFM)):
            raise TypeError('Use from_rep to initialise from SDM/DDM')
        elif isinstance(rows, list):
            rep = DDM(rows, shape, domain)
        elif isinstance(rows, dict):
            rep = SDM(rows, shape, domain)
        else:
            msg = 'Input should be list-of-lists or dict-of-dicts'
            raise TypeError(msg)
        if fmt is not None:
            if fmt == 'sparse':
                rep = rep.to_sdm()
            elif fmt == 'dense':
                rep = rep.to_ddm()
            else:
                raise ValueError("fmt should be 'sparse' or 'dense'")
        if rep.fmt == 'dense' and DFM._supports_domain(domain):
            rep = rep.to_dfm()
        return cls.from_rep(rep)

    def __reduce__(self):
        rep = self.rep
        if rep.fmt == 'dense':
            arg = self.to_list()
        elif rep.fmt == 'sparse':
            arg = dict(rep)
        else:
            raise RuntimeError
        args = (arg, rep.shape, rep.domain)
        return (self.__class__, args)

    @overload
    def __getitem__(self, key: tuple[int, int]) -> DomainScalar:
        pass

    @overload
    def __getitem__(self, key: tuple[slice, int]) -> DomainMatrix:
        pass

    @overload
    def __getitem__(self, key: tuple[int, slice]) -> DomainMatrix:
        pass

    @overload
    def __getitem__(self, key: tuple[slice, slice]) -> DomainMatrix:
        pass

    def __getitem__(self, key: tuple[slice | int, slice | int]) -> DomainMatrix | DomainScalar:
        i, j = key
        m, n = self.shape
        if not (isinstance(i, slice) or isinstance(j, slice)):
            return DomainScalar(self.rep.getitem(i, j), self.domain)
        if not isinstance(i, slice):
            if not -m <= i < m:
                raise IndexError('Row index out of range')
            i = i % m
            i = slice(i, i + 1)
        if not isinstance(j, slice):
            if not -n <= j < n:
                raise IndexError('Column index out of range')
            j = j % n
            j = slice(j, j + 1)
        return self.from_rep(self.rep.extract_slice(i, j))

    def getitem_sympy(self, i, j):
        return self.domain.to_sympy(self.rep.getitem(i, j))

    def extract(self, rowslist, colslist):
        return self.from_rep(self.rep.extract(rowslist, colslist))

    def __setitem__(self, key, value):
        i, j = key
        if not self.domain.of_type(value):
            raise TypeError
        if isinstance(i, int) and isinstance(j, int):
            self.rep.setitem(i, j, value)
        else:
            raise NotImplementedError

    @classmethod
    def from_rep(cls, rep):
        if not (isinstance(rep, (DDM, SDM)) or (DFM is not None and isinstance(rep, DFM))):
            raise TypeError('rep should be of type DDM or SDM')
        self = super().__new__(cls)
        self.rep = rep
        self.shape = rep.shape
        self.domain = rep.domain
        return self

    @classmethod
    @doctest_depends_on(ground_types=['python', 'gmpy'])
    def from_list(cls, rows, domain):
        nrows = len(rows)
        ncols = 0 if not nrows else len(rows[0])
        conv = lambda e: domain(*e) if isinstance(e, tuple) else domain(e)
        domain_rows = [[conv(e) for e in row] for row in rows]
        return DomainMatrix(domain_rows, (nrows, ncols), domain)

    @classmethod
    def from_list_sympy(cls, nrows, ncols, rows, **kwargs):
        assert len(rows) == nrows
        assert all((len(row) == ncols for row in rows))
        items_sympy = [_sympify(item) for row in rows for item in row]
        domain, items_domain = cls.get_domain(items_sympy, **kwargs)
        domain_rows = [[items_domain[ncols * r + c] for c in range(ncols)] for r in range(nrows)]
        return DomainMatrix(domain_rows, (nrows, ncols), domain)

    @classmethod
    def from_dict_sympy(cls, nrows, ncols, elemsdict, **kwargs):
        if not all((0 <= r < nrows for r in elemsdict)):
            raise DMBadInputError('Row out of range')
        if not all((0 <= c < ncols for row in elemsdict.values() for c in row)):
            raise DMBadInputError('Column out of range')
        items_sympy = [_sympify(item) for row in elemsdict.values() for item in row.values()]
        domain, items_domain = cls.get_domain(items_sympy, **kwargs)
        idx = 0
        items_dict = {}
        for i, row in elemsdict.items():
            items_dict[i] = {}
            for j in row:
                items_dict[i][j] = items_domain[idx]
                idx += 1
        return DomainMatrix(items_dict, (nrows, ncols), domain)

    @classmethod
    def from_Matrix(cls, M, fmt='sparse', **kwargs):
        if fmt == 'dense':
            return cls.from_list_sympy(*M.shape, M.tolist(), **kwargs)
        return cls.from_dict_sympy(*M.shape, M.todod(), **kwargs)

    @classmethod
    def get_domain(cls, items_sympy, **kwargs):
        K, items_K = construct_domain(items_sympy, **kwargs)
        return (K, items_K)

    def choose_domain(self, **opts):
        elements, data = self.to_sympy().to_flat_nz()
        dom, elements_dom = construct_domain(elements, **opts)
        return self.from_flat_nz(elements_dom, data, dom)

    def copy(self):
        return self.from_rep(self.rep.copy())

    def convert_to(self, K):
        if K == self.domain:
            return self.copy()
        rep = self.rep
        if rep.is_DFM and (not DFM._supports_domain(K)):
            rep_K = rep.to_ddm().convert_to(K)
        elif rep.is_DDM and DFM._supports_domain(K):
            rep_K = rep.convert_to(K).to_dfm()
        else:
            rep_K = rep.convert_to(K)
        return self.from_rep(rep_K)

    def to_sympy(self):
        return self.convert_to(EXRAW)

    def to_field(self):
        K = self.domain.get_field()
        return self.convert_to(K)

    def to_sparse(self):
        if self.rep.fmt == 'sparse':
            return self
        return self.from_rep(self.rep.to_sdm())

    def to_dense(self):
        rep = self.rep
        if rep.fmt == 'dense':
            return self
        return self.from_rep(rep.to_dfm_or_ddm())

    def to_ddm(self):
        return self.rep.to_ddm()

    def to_sdm(self):
        return self.rep.to_sdm()

    @doctest_depends_on(ground_types=['flint'])
    def to_dfm(self):
        return self.rep.to_dfm()

    @doctest_depends_on(ground_types=['flint'])
    def to_dfm_or_ddm(self):
        return self.rep.to_dfm_or_ddm()

    @classmethod
    def _unify_domain(cls, *matrices):
        domains = {matrix.domain for matrix in matrices}
        if len(domains) == 1:
            return matrices
        domain = reduce(lambda x, y: x.unify(y), domains)
        return tuple((matrix.convert_to(domain) for matrix in matrices))

    @classmethod
    def _unify_fmt(cls, *matrices, fmt=None):
        formats = {matrix.rep.fmt for matrix in matrices}
        if len(formats) == 1:
            return matrices
        if fmt == 'sparse':
            return tuple((matrix.to_sparse() for matrix in matrices))
        elif fmt == 'dense':
            return tuple((matrix.to_dense() for matrix in matrices))
        else:
            raise ValueError("fmt should be 'sparse' or 'dense'")

    def unify(self, *others, fmt=None):
        matrices = (self,) + others
        matrices = DomainMatrix._unify_domain(*matrices)
        if fmt is not None:
            matrices = DomainMatrix._unify_fmt(*matrices, fmt=fmt)
        return matrices

    def to_Matrix(self):
        from sympy.matrices.dense import MutableDenseMatrix
        if self.domain in (ZZ, QQ, EXRAW):
            if self.rep.fmt == 'sparse':
                rep = self.copy()
            else:
                rep = self.to_sparse()
        else:
            rep = self.convert_to(EXRAW).to_sparse()
        return MutableDenseMatrix._fromrep(rep)

    def to_list(self):
        return self.rep.to_list()

    def to_list_flat(self):
        return self.rep.to_list_flat()

    @classmethod
    def from_list_flat(cls, elements, shape, domain):
        ddm = DDM.from_list_flat(elements, shape, domain)
        return cls.from_rep(ddm.to_dfm_or_ddm())

    def to_flat_nz(self):
        return self.rep.to_flat_nz()

    def from_flat_nz(self, elements, data, domain):
        rep = self.rep.from_flat_nz(elements, data, domain)
        return self.from_rep(rep)

    def to_dod(self):
        return self.rep.to_dod()

    @classmethod
    def from_dod(cls, dod, shape, domain):
        return cls.from_rep(SDM.from_dod(dod, shape, domain))

    def from_dod_like(self, dod, domain=None):
        if domain is None:
            domain = self.domain
        return self.from_rep(self.rep.from_dod(dod, self.shape, domain))

    def to_dok(self):
        return self.rep.to_dok()

    @classmethod
    def from_dok(cls, dok, shape, domain):
        return cls.from_rep(SDM.from_dok(dok, shape, domain))

    def iter_values(self):
        return self.rep.iter_values()

    def iter_items(self):
        return self.rep.iter_items()

    def nnz(self):
        return self.rep.nnz()

    def __repr__(self):
        return 'DomainMatrix(%s, %r, %r)' % (str(self.rep), self.shape, self.domain)

    def transpose(self):
        return self.from_rep(self.rep.transpose())

    def flat(self):
        rows, cols = self.shape
        return [self[i, j].element for i in range(rows) for j in range(cols)]

    @property
    def is_zero_matrix(self):
        return self.rep.is_zero_matrix()

    @property
    def is_upper(self):
        return self.rep.is_upper()

    @property
    def is_lower(self):
        return self.rep.is_lower()

    @property
    def is_diagonal(self):
        return self.rep.is_diagonal()

    def diagonal(self):
        return self.rep.diagonal()

    @property
    def is_square(self):
        return self.shape[0] == self.shape[1]

    def rank(self):
        rref, pivots = self.rref()
        return len(pivots)

    def hstack(A, *B):
        A, *B = A.unify(*B, fmt=A.rep.fmt)
        return DomainMatrix.from_rep(A.rep.hstack(*(Bk.rep for Bk in B)))

    def vstack(A, *B):
        A, *B = A.unify(*B, fmt='dense')
        return DomainMatrix.from_rep(A.rep.vstack(*(Bk.rep for Bk in B)))

    def applyfunc(self, func, domain=None):
        if domain is None:
            domain = self.domain
        return self.from_rep(self.rep.applyfunc(func, domain))

    def __add__(A, B):
        if not isinstance(B, DomainMatrix):
            return NotImplemented
        A, B = A.unify(B, fmt='dense')
        return A.add(B)

    def __sub__(A, B):
        if not isinstance(B, DomainMatrix):
            return NotImplemented
        A, B = A.unify(B, fmt='dense')
        return A.sub(B)

    def __neg__(A):
        return A.neg()

    def __mul__(A, B):
        if isinstance(B, DomainMatrix):
            A, B = A.unify(B, fmt='dense')
            return A.matmul(B)
        elif B in A.domain:
            return A.scalarmul(B)
        elif isinstance(B, DomainScalar):
            A, B = A.unify(B)
            return A.scalarmul(B.element)
        else:
            return NotImplemented

    def __rmul__(A, B):
        if B in A.domain:
            return A.rscalarmul(B)
        elif isinstance(B, DomainScalar):
            A, B = A.unify(B)
            return A.rscalarmul(B.element)
        else:
            return NotImplemented

    def __pow__(A, n):
        if not isinstance(n, int):
            return NotImplemented
        return A.pow(n)

    def _check(a, op, b, ashape, bshape):
        if a.domain != b.domain:
            msg = 'Domain mismatch: %s %s %s' % (a.domain, op, b.domain)
            raise DMDomainError(msg)
        if ashape != bshape:
            msg = 'Shape mismatch: %s %s %s' % (a.shape, op, b.shape)
            raise DMShapeError(msg)
        if a.rep.fmt != b.rep.fmt:
            msg = 'Format mismatch: %s %s %s' % (a.rep.fmt, op, b.rep.fmt)
            raise DMFormatError(msg)
        if type(a.rep) != type(b.rep):
            msg = 'Type mismatch: %s %s %s' % (type(a.rep), op, type(b.rep))
            raise DMFormatError(msg)

    def add(A, B):
        A._check('+', B, A.shape, B.shape)
        return A.from_rep(A.rep.add(B.rep))

    def sub(A, B):
        A._check('-', B, A.shape, B.shape)
        return A.from_rep(A.rep.sub(B.rep))

    def neg(A):
        return A.from_rep(A.rep.neg())

    def mul(A, b):
        return A.from_rep(A.rep.mul(b))

    def rmul(A, b):
        return A.from_rep(A.rep.rmul(b))

    def matmul(A, B):
        A._check('*', B, A.shape[1], B.shape[0])
        return A.from_rep(A.rep.matmul(B.rep))

    def _scalarmul(A, lamda, reverse):
        if lamda == A.domain.zero and (not A.domain.is_EXRAW):
            return DomainMatrix.zeros(A.shape, A.domain)
        elif lamda == A.domain.one:
            return A.copy()
        elif reverse:
            return A.rmul(lamda)
        else:
            return A.mul(lamda)

    def scalarmul(A, lamda):
        return A._scalarmul(lamda, reverse=False)

    def rscalarmul(A, lamda):
        return A._scalarmul(lamda, reverse=True)

    def mul_elementwise(A, B):
        assert A.domain == B.domain
        return A.from_rep(A.rep.mul_elementwise(B.rep))

    def __truediv__(A, lamda):
        if isinstance(lamda, int) or ZZ.of_type(lamda):
            lamda = DomainScalar(ZZ(lamda), ZZ)
        elif A.domain.is_Field and lamda in A.domain:
            K = A.domain
            lamda = DomainScalar(K.convert(lamda), K)
        if not isinstance(lamda, DomainScalar):
            return NotImplemented
        A, lamda = A.to_field().unify(lamda)
        if lamda.element == lamda.domain.zero:
            raise ZeroDivisionError
        if lamda.element == lamda.domain.one:
            return A
        return A.mul(1 / lamda.element)

    def pow(A, n):
        nrows, ncols = A.shape
        if nrows != ncols:
            raise DMNonSquareMatrixError('Power of a nonsquare matrix')
        if n < 0:
            raise NotImplementedError('Negative powers')
        elif n == 0:
            return A.eye(nrows, A.domain)
        elif n == 1:
            return A
        elif n % 2 == 1:
            return A * A ** (n - 1)
        else:
            sqrtAn = A ** (n // 2)
            return sqrtAn * sqrtAn

    def scc(self):
        if not self.is_square:
            raise DMNonSquareMatrixError('Matrix must be square for scc')
        return self.rep.scc()

    def clear_denoms(self, convert=False):
        elems0, data = self.to_flat_nz()
        K0 = self.domain
        K1 = K0.get_ring() if K0.has_assoc_Ring else K0
        den, elems1 = dup_clear_denoms(elems0, K0, K1, convert=convert)
        if convert:
            Kden, Knum = (K1, K1)
        else:
            Kden, Knum = (K1, K0)
        den = DomainScalar(den, Kden)
        num = self.from_flat_nz(elems1, data, Knum)
        return (den, num)

    def clear_denoms_rowwise(self, convert=False):
        dod = self.to_dod()
        K0 = self.domain
        K1 = K0.get_ring() if K0.has_assoc_Ring else K0
        diagonals = [K0.one] * self.shape[0]
        dod_num = {}
        for i, rowi in dod.items():
            indices, elems = zip(*rowi.items())
            den, elems_num = dup_clear_denoms(elems, K0, K1, convert=convert)
            rowi_num = dict(zip(indices, elems_num))
            diagonals[i] = den
            dod_num[i] = rowi_num
        if convert:
            Kden, Knum = (K1, K1)
        else:
            Kden, Knum = (K1, K0)
        den = self.diag(diagonals, Kden)
        num = self.from_dod_like(dod_num, Knum)
        return (den, num)

    def cancel_denom(self, denom):
        M = self
        K = self.domain
        if K.is_zero(denom):
            raise ZeroDivisionError('denominator is zero')
        elif K.is_one(denom):
            return (M.copy(), denom)
        elements, data = M.to_flat_nz()
        if K.is_negative(denom):
            u = -K.one
        else:
            u = K.canonical_unit(denom)
        content = dup_content(elements, K)
        common = K.gcd(content, denom)
        if not K.is_one(content):
            common = K.gcd(content, denom)
            if not K.is_one(common):
                elements = dup_exquo_ground(elements, common, K)
                denom = K.quo(denom, common)
        if not K.is_one(u):
            elements = dup_mul_ground(elements, u, K)
            denom = u * denom
        elif K.is_one(common):
            return (M.copy(), denom)
        M_cancelled = M.from_flat_nz(elements, data, K)
        return (M_cancelled, denom)

    def cancel_denom_elementwise(self, denom):
        K = self.domain
        M = self
        if K.is_zero(denom):
            raise ZeroDivisionError('denominator is zero')
        elif K.is_one(denom):
            M_numers = M.copy()
            M_denoms = M.ones(M.shape, M.domain)
            return (M_numers, M_denoms)
        elements, data = M.to_flat_nz()
        cofactors = [K.cofactors(numer, denom) for numer in elements]
        gcds, numers, denoms = zip(*cofactors)
        M_numers = M.from_flat_nz(list(numers), data, K)
        M_denoms = M.from_flat_nz(list(denoms), data, K)
        return (M_numers, M_denoms)

    def content(self):
        K = self.domain
        elements, _ = self.to_flat_nz()
        return dup_content(elements, K)

    def primitive(self):
        K = self.domain
        elements, data = self.to_flat_nz()
        content, prims = dup_primitive(elements, K)
        M_primitive = self.from_flat_nz(prims, data, K)
        return (content, M_primitive)

    def rref(self, *, method='auto'):
        return _dm_rref(self, method=method)

    def rref_den(self, *, method='auto', keep_domain=True):
        return _dm_rref_den(self, method=method, keep_domain=keep_domain)

    def columnspace(self):
        if not self.domain.is_Field:
            raise DMNotAField('Not a field')
        rref, pivots = self.rref()
        rows, cols = self.shape
        return self.extract(range(rows), pivots)

    def rowspace(self):
        if not self.domain.is_Field:
            raise DMNotAField('Not a field')
        rref, pivots = self.rref()
        rows, cols = self.shape
        return self.extract(range(len(pivots)), range(cols))

    def nullspace(self, divide_last=False):
        A = self
        K = A.domain
        if divide_last and (not K.is_Field):
            raise DMNotAField('Cannot normalize vectors over a non-field')
        if divide_last:
            A_rref, pivots = A.rref()
        else:
            A_rref, den, pivots = A.rref_den()
            u = K.canonical_unit(den)
            if u != K.one:
                A_rref *= u
        A_null = A_rref.nullspace_from_rref(pivots)
        return A_null

    def nullspace_from_rref(self, pivots=None):
        null_rep, nonpivots = self.rep.nullspace_from_rref(pivots)
        return self.from_rep(null_rep)

    def inv(self):
        if not self.domain.is_Field:
            raise DMNotAField('Not a field')
        m, n = self.shape
        if m != n:
            raise DMNonSquareMatrixError
        inv = self.rep.inv()
        return self.from_rep(inv)

    def det(self):
        m, n = self.shape
        if m != n:
            raise DMNonSquareMatrixError
        return self.rep.det()

    def adj_det(self):
        m, n = self.shape
        I_m = self.eye((m, m), self.domain)
        adjA, detA = self.solve_den_charpoly(I_m, check=False)
        if self.rep.fmt == 'dense':
            adjA = adjA.to_dense()
        return (adjA, detA)

    def adjugate(self):
        adjA, detA = self.adj_det()
        return adjA

    def inv_den(self, method=None):
        I = self.eye(self.shape, self.domain)
        return self.solve_den(I, method=method)

    def solve_den(self, b, method=None):
        m, n = self.shape
        bm, bn = b.shape
        if m != bm:
            raise DMShapeError('Matrix equation shape mismatch.')
        if method is None:
            method = 'rref'
        elif method == 'charpoly' and m != n:
            raise DMNonSquareMatrixError("method='charpoly' requires a square matrix.")
        if method == 'charpoly':
            xnum, xden = self.solve_den_charpoly(b)
        elif method == 'rref':
            xnum, xden = self.solve_den_rref(b)
        else:
            raise DMBadInputError("method should be 'rref' or 'charpoly'")
        return (xnum, xden)

    def solve_den_rref(self, b):
        A = self
        m, n = A.shape
        bm, bn = b.shape
        if m != bm:
            raise DMShapeError('Matrix equation shape mismatch.')
        if m < n:
            raise DMShapeError('Underdetermined matrix equation.')
        Aaug = A.hstack(b)
        Aaug_rref, denom, pivots = Aaug.rref_den()
        if len(pivots) != n or (pivots and pivots[-1] >= n):
            raise DMNonInvertibleMatrixError('Non-unique solution.')
        xnum = Aaug_rref[:n, n:]
        xden = denom
        return (xnum, xden)

    def solve_den_charpoly(self, b, cp=None, check=True):
        A, b = self.unify(b)
        m, n = self.shape
        mb, nb = b.shape
        if m != n:
            raise DMNonSquareMatrixError('Matrix must be square')
        if mb != m:
            raise DMShapeError('Matrix and vector must have the same number of rows')
        f, detA = self.adj_poly_det(cp=cp)
        if check and (not detA):
            raise DMNonInvertibleMatrixError('Matrix is not invertible')
        adjA_b = self.eval_poly_mul(f, b)
        return (adjA_b, detA)

    def adj_poly_det(self, cp=None):
        A = self
        m, n = self.shape
        if m != n:
            raise DMNonSquareMatrixError('Matrix must be square')
        if cp is None:
            cp = A.charpoly()
        if len(cp) % 2:
            detA = cp[-1]
            f = [-cpi for cpi in cp[:-1]]
        else:
            detA = -cp[-1]
            f = cp[:-1]
        return (f, detA)

    def eval_poly(self, p):
        A = self
        m, n = A.shape
        if m != n:
            raise DMNonSquareMatrixError('Matrix must be square')
        if not p:
            return self.zeros(self.shape, self.domain)
        elif len(p) == 1:
            return p[0] * self.eye(self.shape, self.domain)
        I = A.eye(A.shape, A.domain)
        p_A = p[0] * I
        for pi in p[1:]:
            p_A = A * p_A + pi * I
        return p_A

    def eval_poly_mul(self, p, B):
        A = self
        m, n = A.shape
        mb, nb = B.shape
        if m != n:
            raise DMNonSquareMatrixError('Matrix must be square')
        if mb != n:
            raise DMShapeError('Matrices are not aligned')
        if A.domain != B.domain:
            raise DMDomainError('Matrices must have the same domain')
        if not p:
            return B.zeros(B.shape, B.domain, fmt=B.rep.fmt)
        p_A_B = p[0] * B
        for p_i in p[1:]:
            p_A_B = A * p_A_B + p_i * B
        return p_A_B

    def lu(self):
        if not self.domain.is_Field:
            raise DMNotAField('Not a field')
        L, U, swaps = self.rep.lu()
        return (self.from_rep(L), self.from_rep(U), swaps)

    def qr(self):
        ddm_q, ddm_r = self.rep.qr()
        Q = self.from_rep(ddm_q)
        R = self.from_rep(ddm_r)
        return (Q, R)

    def lu_solve(self, rhs):
        if self.shape[0] != rhs.shape[0]:
            raise DMShapeError('Shape')
        if not self.domain.is_Field:
            raise DMNotAField('Not a field')
        sol = self.rep.lu_solve(rhs.rep)
        return self.from_rep(sol)

    def fflu(self):
        from_rep = self.from_rep
        P, L, D, U = self.rep.fflu()
        return (from_rep(P), from_rep(L), from_rep(D), from_rep(U))

    def _solve(A, b):
        if A.shape[0] != b.shape[0]:
            raise DMShapeError('Shape')
        if A.domain != b.domain or not A.domain.is_Field:
            raise DMNotAField('Not a field')
        Aaug = A.hstack(b)
        Arref, pivots = Aaug.rref()
        particular = Arref.from_rep(Arref.rep.particular())
        nullspace_rep, nonpivots = Arref[:, :-1].rep.nullspace()
        nullspace = Arref.from_rep(nullspace_rep)
        return (particular, nullspace)

    def charpoly(self):
        M = self
        K = M.domain
        factors = M.charpoly_factor_blocks()
        cp = [K.one]
        for f, mult in factors:
            for _ in range(mult):
                cp = dup_mul(cp, f, K)
        return cp

    def charpoly_factor_list(self):
        M = self
        K = M.domain
        factors = M.charpoly_factor_blocks()
        factors_irreducible = []
        for factor_i, mult_i in factors:
            _, factors_list = dup_factor_list(factor_i, K)
            for factor_j, mult_j in factors_list:
                factors_irreducible.append((factor_j, mult_i * mult_j))
        return _collect_factors(factors_irreducible)

    def charpoly_factor_blocks(self):
        M = self
        if not M.is_square:
            raise DMNonSquareMatrixError('not square')
        components = M.scc()
        block_factors = []
        for indices in components:
            block = M.extract(indices, indices)
            block_factors.append((block.charpoly_base(), 1))
        return _collect_factors(block_factors)

    def charpoly_base(self):
        M = self
        K = M.domain
        density = self.nnz() / self.shape[0] ** 2
        if density < 0.5:
            M = M.to_sparse()
        else:
            M = M.to_dense()
        clear_denoms = K.is_Field and K.has_assoc_Ring
        if clear_denoms:
            clear_denoms = True
            d, M = M.clear_denoms(convert=True)
            d = d.element
            K_f = K
            K_r = M.domain
        cp = M.charpoly_berk()
        if clear_denoms:
            cp = dup_convert(cp, K_r, K_f)
            p = [K_f.one, K_f.zero]
            q = [K_f.one / d]
            cp = dup_transform(cp, p, q, K_f)
        return cp

    def charpoly_berk(self):
        return self.rep.charpoly()

    @classmethod
    def eye(cls, shape, domain):
        if isinstance(shape, int):
            shape = (shape, shape)
        return cls.from_rep(SDM.eye(shape, domain))

    @classmethod
    def diag(cls, diagonal, domain, shape=None):
        if shape is None:
            N = len(diagonal)
            shape = (N, N)
        return cls.from_rep(SDM.diag(diagonal, domain, shape))

    @classmethod
    def zeros(cls, shape, domain, *, fmt='sparse'):
        return cls.from_rep(SDM.zeros(shape, domain))

    @classmethod
    def ones(cls, shape, domain):
        return cls.from_rep(DDM.ones(shape, domain).to_dfm_or_ddm())

    def __eq__(A, B):
        if not isinstance(A, type(B)):
            return NotImplemented
        return A.domain == B.domain and A.rep == B.rep

    def unify_eq(A, B):
        if A.shape != B.shape:
            return False
        if A.domain != B.domain:
            A, B = A.unify(B)
        return A == B

    def lll(A, delta=QQ(3, 4)):
        return DomainMatrix.from_rep(A.rep.lll(delta=delta))

    def lll_transform(A, delta=QQ(3, 4)):
        reduced, transform = A.rep.lll_transform(delta=delta)
        return (DomainMatrix.from_rep(reduced), DomainMatrix.from_rep(transform))

def _collect_factors(factors_list):
    factors = Counter()
    for factor, exponent in factors_list:
        factors[tuple(factor)] += exponent
    factors_list = [(list(f), e) for f, e in factors.items()]
    return _sort_factors(factors_list)