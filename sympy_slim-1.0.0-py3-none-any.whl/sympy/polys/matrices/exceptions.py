from __future__ import annotations

class DMError(Exception):
    pass

class DMBadInputError(DMError):
    pass

class DMDomainError(DMError):
    pass

class DMNotAField(DMDomainError):
    pass

class DMFormatError(DMError):
    pass

class DMNonInvertibleMatrixError(DMError):
    pass

class DMRankError(DMError):
    pass

class DMShapeError(DMError):
    pass

class DMNonSquareMatrixError(DMShapeError):
    pass

class DMValueError(DMError):
    pass
__all__ = ['DMError', 'DMBadInputError', 'DMDomainError', 'DMFormatError', 'DMRankError', 'DMShapeError', 'DMNotAField', 'DMNonInvertibleMatrixError', 'DMNonSquareMatrixError', 'DMValueError']