from __future__ import annotations
from itertools import chain
from sympy.external.gmpy import GROUND_TYPES
from sympy.utilities.decorator import doctest_depends_on
from .exceptions import DMBadInputError, DMDomainError, DMNonSquareMatrixError, DMShapeError
from sympy.polys.domains import QQ
from .dense import ddm_transpose, ddm_iadd, ddm_isub, ddm_ineg, ddm_imul, ddm_irmul, ddm_imatmul, ddm_irref, ddm_irref_den, ddm_idet, ddm_iinv, ddm_ilu_split, ddm_ilu_solve, ddm_berk
from .lll import ddm_lll, ddm_lll_transform
if GROUND_TYPES != 'flint':
    __doctest_skip__ = ['DDM.to_dfm', 'DDM.to_dfm_or_ddm']

class DDM(list):
    fmt = 'dense'
    is_DFM = False
    is_DDM = True

    def __init__(self, rowslist, shape, domain):
        if not (isinstance(rowslist, list) and all((type(row) is list for row in rowslist))):
            raise DMBadInputError('rowslist must be a list of lists')
        m, n = shape
        if len(rowslist) != m or any((len(row) != n for row in rowslist)):
            raise DMBadInputError('Inconsistent row-list/shape')
        super().__init__([i.copy() for i in rowslist])
        self.shape = (m, n)
        self.rows = m
        self.cols = n
        self.domain = domain

    def getitem(self, i, j):
        return self[i][j]

    def setitem(self, i, j, value):
        self[i][j] = value

    def extract_slice(self, slice1, slice2):
        ddm = [row[slice2] for row in self[slice1]]
        rows = len(ddm)
        cols = len(ddm[0]) if ddm else len(range(self.shape[1])[slice2])
        return DDM(ddm, (rows, cols), self.domain)

    def extract(self, rows, cols):
        ddm = []
        for i in rows:
            rowi = self[i]
            ddm.append([rowi[j] for j in cols])
        return DDM(ddm, (len(rows), len(cols)), self.domain)

    @classmethod
    def from_list(cls, rowslist, shape, domain):
        return cls(rowslist, shape, domain)

    @classmethod
    def from_ddm(cls, other):
        return other.copy()

    def to_list(self):
        return [row[:] for row in self]

    def to_list_flat(self):
        flat = []
        for row in self:
            flat.extend(row)
        return flat

    @classmethod
    def from_list_flat(cls, flat, shape, domain):
        assert type(flat) is list
        rows, cols = shape
        if not len(flat) == rows * cols:
            raise DMBadInputError('Inconsistent flat-list shape')
        lol = [flat[i * cols:(i + 1) * cols] for i in range(rows)]
        return cls(lol, shape, domain)

    def flatiter(self):
        return chain.from_iterable(self)

    def flat(self):
        items = []
        for row in self:
            items.extend(row)
        return items

    def to_flat_nz(self):
        return self.to_sdm().to_flat_nz()

    @classmethod
    def from_flat_nz(cls, elements, data, domain):
        return SDM.from_flat_nz(elements, data, domain).to_ddm()

    def to_dod(self):
        dod = {}
        for i, row in enumerate(self):
            row = {j: e for j, e in enumerate(row) if e}
            if row:
                dod[i] = row
        return dod

    @classmethod
    def from_dod(cls, dod, shape, domain):
        rows, cols = shape
        lol = [[domain.zero] * cols for _ in range(rows)]
        for i, row in dod.items():
            for j, element in row.items():
                lol[i][j] = element
        return DDM(lol, shape, domain)

    def to_dok(self):
        dok = {}
        for i, row in enumerate(self):
            for j, element in enumerate(row):
                if element:
                    dok[i, j] = element
        return dok

    @classmethod
    def from_dok(cls, dok, shape, domain):
        rows, cols = shape
        lol = [[domain.zero] * cols for _ in range(rows)]
        for (i, j), element in dok.items():
            lol[i][j] = element
        return DDM(lol, shape, domain)

    def iter_values(self):
        for row in self:
            yield from filter(None, row)

    def iter_items(self):
        for i, row in enumerate(self):
            for j, element in enumerate(row):
                if element:
                    yield ((i, j), element)

    def to_ddm(self):
        return self

    def to_sdm(self):
        return SDM.from_list(self, self.shape, self.domain)

    @doctest_depends_on(ground_types=['flint'])
    def to_dfm(self):
        return DFM(list(self), self.shape, self.domain)

    @doctest_depends_on(ground_types=['flint'])
    def to_dfm_or_ddm(self):
        if DFM._supports_domain(self.domain):
            return self.to_dfm()
        return self

    def convert_to(self, K):
        Kold = self.domain
        if K == Kold:
            return self.copy()
        rows = [[K.convert_from(e, Kold) for e in row] for row in self]
        return DDM(rows, self.shape, K)

    def __str__(self):
        rowsstr = ['[%s]' % ', '.join(map(str, row)) for row in self]
        return '[%s]' % ', '.join(rowsstr)

    def __repr__(self):
        cls = type(self).__name__
        rows = list.__repr__(self)
        return '%s(%s, %s, %s)' % (cls, rows, self.shape, self.domain)

    def __eq__(self, other):
        if not isinstance(other, DDM):
            return False
        return super().__eq__(other) and self.domain == other.domain

    def __ne__(self, other):
        return not self.__eq__(other)

    @classmethod
    def zeros(cls, shape, domain):
        z = domain.zero
        m, n = shape
        rowslist = [[z] * n for _ in range(m)]
        return DDM(rowslist, shape, domain)

    @classmethod
    def ones(cls, shape, domain):
        one = domain.one
        m, n = shape
        rowlist = [[one] * n for _ in range(m)]
        return DDM(rowlist, shape, domain)

    @classmethod
    def eye(cls, size, domain):
        if isinstance(size, tuple):
            m, n = size
        elif isinstance(size, int):
            m = n = size
        one = domain.one
        ddm = cls.zeros((m, n), domain)
        for i in range(min(m, n)):
            ddm[i][i] = one
        return ddm

    def copy(self):
        copyrows = [row[:] for row in self]
        return DDM(copyrows, self.shape, self.domain)

    def transpose(self):
        rows, cols = self.shape
        if rows:
            ddmT = ddm_transpose(self)
        else:
            ddmT = [[]] * cols
        return DDM(ddmT, (cols, rows), self.domain)

    def __add__(a, b):
        if not isinstance(b, DDM):
            return NotImplemented
        return a.add(b)

    def __sub__(a, b):
        if not isinstance(b, DDM):
            return NotImplemented
        return a.sub(b)

    def __neg__(a):
        return a.neg()

    def __mul__(a, b):
        if b in a.domain:
            return a.mul(b)
        else:
            return NotImplemented

    def __rmul__(a, b):
        if b in a.domain:
            return a.mul(b)
        else:
            return NotImplemented

    def __matmul__(a, b):
        if isinstance(b, DDM):
            return a.matmul(b)
        else:
            return NotImplemented

    @classmethod
    def _check(cls, a, op, b, ashape, bshape):
        if a.domain != b.domain:
            msg = 'Domain mismatch: %s %s %s' % (a.domain, op, b.domain)
            raise DMDomainError(msg)
        if ashape != bshape:
            msg = 'Shape mismatch: %s %s %s' % (a.shape, op, b.shape)
            raise DMShapeError(msg)

    def add(a, b):
        a._check(a, '+', b, a.shape, b.shape)
        c = a.copy()
        ddm_iadd(c, b)
        return c

    def sub(a, b):
        a._check(a, '-', b, a.shape, b.shape)
        c = a.copy()
        ddm_isub(c, b)
        return c

    def neg(a):
        b = a.copy()
        ddm_ineg(b)
        return b

    def mul(a, b):
        c = a.copy()
        ddm_imul(c, b)
        return c

    def rmul(a, b):
        c = a.copy()
        ddm_irmul(c, b)
        return c

    def matmul(a, b):
        m, o = a.shape
        o2, n = b.shape
        a._check(a, '*', b, o, o2)
        c = a.zeros((m, n), a.domain)
        ddm_imatmul(c, a, b)
        return c

    def mul_elementwise(a, b):
        assert a.shape == b.shape
        assert a.domain == b.domain
        c = [[aij * bij for aij, bij in zip(ai, bi)] for ai, bi in zip(a, b)]
        return DDM(c, a.shape, a.domain)

    def hstack(A, *B):
        Anew = list(A.copy())
        rows, cols = A.shape
        domain = A.domain
        for Bk in B:
            Bkrows, Bkcols = Bk.shape
            assert Bkrows == rows
            assert Bk.domain == domain
            cols += Bkcols
            for i, Bki in enumerate(Bk):
                Anew[i].extend(Bki)
        return DDM(Anew, (rows, cols), A.domain)

    def vstack(A, *B):
        Anew = list(A.copy())
        rows, cols = A.shape
        domain = A.domain
        for Bk in B:
            Bkrows, Bkcols = Bk.shape
            assert Bkcols == cols
            assert Bk.domain == domain
            rows += Bkrows
            Anew.extend(Bk.copy())
        return DDM(Anew, (rows, cols), A.domain)

    def applyfunc(self, func, domain):
        elements = [list(map(func, row)) for row in self]
        return DDM(elements, self.shape, domain)

    def nnz(a):
        return sum((sum(map(bool, row)) for row in a))

    def scc(a):
        return a.to_sdm().scc()

    @classmethod
    def diag(cls, values, domain):
        return SDM.diag(values, domain).to_ddm()

    def rref(a):
        b = a.copy()
        K = a.domain
        partial_pivot = K.is_RealField or K.is_ComplexField
        pivots = ddm_irref(b, _partial_pivot=partial_pivot)
        return (b, pivots)

    def rref_den(a):
        b = a.copy()
        K = a.domain
        denom, pivots = ddm_irref_den(b, K)
        return (b, denom, pivots)

    def nullspace(a):
        rref, pivots = a.rref()
        return rref.nullspace_from_rref(pivots)

    def nullspace_from_rref(a, pivots=None):
        m, n = a.shape
        K = a.domain
        if pivots is None:
            pivots = []
            last_pivot = -1
            for i in range(m):
                ai = a[i]
                for j in range(last_pivot + 1, n):
                    if ai[j]:
                        last_pivot = j
                        pivots.append(j)
                        break
        if not pivots:
            return (a.eye(n, K), list(range(n)))
        pivot_val = a[0][pivots[0]]
        basis = []
        nonpivots = []
        for i in range(n):
            if i in pivots:
                continue
            nonpivots.append(i)
            vec = [pivot_val if i == j else K.zero for j in range(n)]
            for ii, jj in enumerate(pivots):
                vec[jj] -= a[ii][i]
            basis.append(vec)
        basis_ddm = DDM(basis, (len(basis), n), K)
        return (basis_ddm, nonpivots)

    def particular(a):
        return a.to_sdm().particular().to_ddm()

    def det(a):
        m, n = a.shape
        if m != n:
            raise DMNonSquareMatrixError('Determinant of non-square matrix')
        b = a.copy()
        K = b.domain
        deta = ddm_idet(b, K)
        return deta

    def inv(a):
        m, n = a.shape
        if m != n:
            raise DMNonSquareMatrixError('Determinant of non-square matrix')
        ainv = a.copy()
        K = a.domain
        ddm_iinv(ainv, a, K)
        return ainv

    def lu(a):
        m, n = a.shape
        K = a.domain
        U = a.copy()
        L = a.eye(m, K)
        swaps = ddm_ilu_split(L, U, K)
        return (L, U, swaps)

    def _fflu(self):
        rows, cols = self.shape
        K = self.domain
        LU = self.copy()
        perm = list(range(rows))
        rank = 0
        for j in range(min(rows, cols)):
            if all((LU[i][j] == K.zero for i in range(rows))):
                continue
            pivot_row = -1
            for i in range(rank, rows):
                if LU[i][j] != K.zero:
                    pivot_row = i
                    break
            if pivot_row == -1:
                continue
            if pivot_row != rank:
                LU[rank], LU[pivot_row] = (LU[pivot_row], LU[rank])
                perm[rank], perm[pivot_row] = (perm[pivot_row], perm[rank])
            pivot = LU[rank][j]
            for i in range(rank + 1, rows):
                multiplier = LU[i][j]
                denominator = LU[rank - 1][rank - 1] if rank > 0 else K.one
                for k in range(j + 1, cols):
                    LU[i][k] = K.exquo(pivot * LU[i][k] - LU[rank][k] * multiplier, denominator)
                LU[i][j] = multiplier
            rank += 1
        return (LU, perm)

    def fflu(self):
        rows, cols = self.shape
        K = self.domain
        U, perm = self._fflu()
        P = self.zeros((rows, rows), K)
        for i, pi in enumerate(perm):
            P[i][pi] = K.one
        L = self.zeros((rows, rows), K)
        i = j = 0
        while i < rows and j < cols:
            if U[i][j] != K.zero:
                L[i][i] = U[i][j]
                for l in range(i + 1, rows):
                    L[l][i] = U[l][j]
                    U[l][j] = K.zero
                i += 1
            j += 1
        for i in range(i, rows):
            L[i][i] = K.one
        D = self.zeros((rows, rows), K)
        if rows >= 1:
            D[0][0] = L[0][0]
        di = K.one
        for i in range(1, rows):
            di = L[i - 1][i - 1] * L[i][i]
            D[i][i] = di
        return (P, L, D, U)

    def qr(self):
        rows, cols = self.shape
        K = self.domain
        Q = self.copy()
        R = self.zeros((min(rows, cols), cols), K)
        if not K.is_Field:
            raise DMDomainError('QR decomposition requires a field (e.g. QQ).')
        dot_cols = lambda i, j: K.sum((Q[k][i] * Q[k][j] for k in range(rows)))
        for j in range(cols):
            for i in range(min(j, rows)):
                dot_ii = dot_cols(i, i)
                if dot_ii != K.zero:
                    R[i][j] = dot_cols(i, j) / dot_ii
                    for k in range(rows):
                        Q[k][j] -= R[i][j] * Q[k][i]
            if j < rows:
                dot_jj = dot_cols(j, j)
                if dot_jj != K.zero:
                    R[j][j] = K.one
        Q = Q.extract(range(rows), range(min(rows, cols)))
        return (Q, R)

    def lu_solve(a, b):
        m, n = a.shape
        m2, o = b.shape
        a._check(a, 'lu_solve', b, m, m2)
        if not a.domain.is_Field:
            raise DMDomainError('lu_solve requires a field')
        L, U, swaps = a.lu()
        x = a.zeros((n, o), a.domain)
        ddm_ilu_solve(x, L, U, swaps, b)
        return x

    def charpoly(a):
        K = a.domain
        m, n = a.shape
        if m != n:
            raise DMNonSquareMatrixError('Charpoly of non-square matrix')
        vec = ddm_berk(a, K)
        coeffs = [vec[i][0] for i in range(n + 1)]
        return coeffs

    def is_zero_matrix(self):
        zero = self.domain.zero
        return all((Mij == zero for Mij in self.flatiter()))

    def is_upper(self):
        zero = self.domain.zero
        return all((Mij == zero for i, Mi in enumerate(self) for Mij in Mi[:i]))

    def is_lower(self):
        zero = self.domain.zero
        return all((Mij == zero for i, Mi in enumerate(self) for Mij in Mi[i + 1:]))

    def is_diagonal(self):
        return self.is_upper() and self.is_lower()

    def diagonal(self):
        m, n = self.shape
        return [self[i][i] for i in range(min(m, n))]

    def lll(A, delta=QQ(3, 4)):
        return ddm_lll(A, delta=delta)

    def lll_transform(A, delta=QQ(3, 4)):
        return ddm_lll_transform(A, delta=delta)
from .sdm import SDM
from .dfm import DFM