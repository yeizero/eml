from __future__ import annotations
from typing import TypeVar, Protocol
T = TypeVar('T')

class RingElement(Protocol):

    def __add__(self: T, other: T, /) -> T:
        pass

    def __sub__(self: T, other: T, /) -> T:
        pass

    def __mul__(self: T, other: T, /) -> T:
        pass

    def __pow__(self: T, other: int, /) -> T:
        pass

    def __neg__(self: T, /) -> T:
        pass