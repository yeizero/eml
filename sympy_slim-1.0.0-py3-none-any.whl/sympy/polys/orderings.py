from __future__ import annotations
from typing import Callable, Any, Sequence, overload
__all__ = ['lex', 'grlex', 'grevlex', 'ilex', 'igrlex', 'igrevlex']
from sympy.core import Symbol, Expr
from sympy.utilities.iterables import iterable
MonomKey = Callable[[tuple[int, ...]], Any]

class MonomialOrder:
    alias: str | None = None
    is_global: bool | None = None
    is_default = False

    def __repr__(self):
        return self.__class__.__name__ + '()'

    def __str__(self):
        return self.alias

    def __call__(self, monomial: tuple[int, ...]) -> Any:
        raise NotImplementedError

    def __eq__(self, other):
        return self.__class__ == other.__class__

    def __hash__(self):
        return hash(self.__class__)

    def __ne__(self, other):
        return not self == other

class LexOrder(MonomialOrder):
    alias = 'lex'
    is_global = True
    is_default = True

    def __call__(self, monomial):
        return monomial

class GradedLexOrder(MonomialOrder):
    alias = 'grlex'
    is_global = True

    def __call__(self, monomial):
        return (sum(monomial), monomial)

class ReversedGradedLexOrder(MonomialOrder):
    alias = 'grevlex'
    is_global = True

    def __call__(self, monomial):
        return (sum(monomial), tuple(reversed([-m for m in monomial])))

class ProductOrder(MonomialOrder):

    def __init__(self, *args):
        self.args = args

    def __call__(self, monomial):
        return tuple((O(lamda(monomial)) for O, lamda in self.args))

    def __repr__(self):
        contents = [repr(x[0]) for x in self.args]
        return self.__class__.__name__ + '(' + ', '.join(contents) + ')'

    def __str__(self):
        contents = [str(x[0]) for x in self.args]
        return self.__class__.__name__ + '(' + ', '.join(contents) + ')'

    def __eq__(self, other):
        if not isinstance(other, ProductOrder):
            return False
        return self.args == other.args

    def __hash__(self):
        return hash((self.__class__, self.args))

    @property
    def is_global(self):
        if all((o.is_global is True for o, _ in self.args)):
            return True
        if all((o.is_global is False for o, _ in self.args)):
            return False
        return None

class InverseOrder(MonomialOrder):

    def __init__(self, O):
        self.O = O

    def __str__(self):
        return 'i' + str(self.O)

    def __call__(self, monomial):

        def inv(l):
            if iterable(l):
                return tuple((inv(x) for x in l))
            return -l
        return inv(self.O(monomial))

    @property
    def is_global(self):
        if self.O.is_global is True:
            return False
        if self.O.is_global is False:
            return True
        return None

    def __eq__(self, other):
        return isinstance(other, InverseOrder) and other.O == self.O

    def __hash__(self):
        return hash((self.__class__, self.O))
lex = LexOrder()
grlex = GradedLexOrder()
grevlex = ReversedGradedLexOrder()
ilex = InverseOrder(lex)
igrlex = InverseOrder(grlex)
igrevlex = InverseOrder(grevlex)
_monomial_key: dict[str, MonomialOrder] = {'lex': lex, 'grlex': grlex, 'grevlex': grevlex, 'ilex': ilex, 'igrlex': igrlex, 'igrevlex': igrevlex}

@overload
def monomial_key(order: str | Symbol | None=None, gens: None=None) -> MonomialOrder:
    pass

@overload
def monomial_key(order: MonomKey, gens: None=None) -> MonomKey:
    pass

@overload
def monomial_key(order: str | Symbol | MonomKey | None=None, *, gens: Sequence[Symbol]) -> Callable[[Expr], Any]:
    pass

@overload
def monomial_key(order: str | Symbol | MonomKey | None, gens: Sequence[Symbol]) -> Callable[[Expr], Any]:
    pass

def monomial_key(order: str | Symbol | MonomKey | None=None, gens: Sequence[Symbol] | None=None) -> MonomKey | MonomialOrder | Callable[[Expr], Any]:
    func: Callable[[tuple[int, ...]], Any]
    if order is None:
        func = lex
    elif isinstance(order, (str, Symbol)):
        order = str(order)
        try:
            func = _monomial_key[order]
        except KeyError:
            raise ValueError("supported monomial orderings are 'lex', 'grlex' and 'grevlex', got %r" % order)
    elif hasattr(order, '__call__'):
        func = order
    else:
        raise ValueError('monomial ordering specification must be a string or a callable, got %s' % order)
    if gens is not None:

        def _func(expr: Expr):
            return func(expr.as_poly(*gens).degree_list())
        return _func
    return func

class _ItemGetter:

    def __init__(self, seq):
        self.seq = tuple(seq)

    def __call__(self, m):
        return tuple((m[idx] for idx in self.seq))

    def __eq__(self, other):
        if not isinstance(other, _ItemGetter):
            return False
        return self.seq == other.seq

def build_product_order(arg, gens):
    gens2idx = {}
    for i, g in enumerate(gens):
        gens2idx[g] = i
    order = []
    for expr in arg:
        name = expr[0]
        var = expr[1:]

        def makelambda(var):
            return _ItemGetter((gens2idx[g] for g in var))
        order.append((monomial_key(name), makelambda(var)))
    return ProductOrder(*order)