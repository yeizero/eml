from __future__ import annotations
from sympy.core.basic import Basic
from sympy.core import S, Expr, Integer, Float, I, oo, Add, Lambda, symbols, sympify, Rational, Dummy
from sympy.core.cache import cacheit
from sympy.core.relational import is_le
from sympy.core.sorting import ordered
from sympy.external.mpmath import local_workprec, dps_to_prec, prec_to_dps
from sympy.polys.domains import QQ
from sympy.polys.polyerrors import MultivariatePolynomialError, GeneratorsNeeded, PolynomialError, DomainError
from sympy.polys.polyfuncs import symmetrize, viete
from sympy.polys.polyroots import roots_linear, roots_quadratic, roots_binomial, preprocess_roots, roots
from sympy.polys.polytools import Poly, factor
from sympy.polys.rationaltools import together
from sympy.polys.rootisolation import dup_isolate_complex_roots_sqf, dup_isolate_real_roots_sqf
from sympy.utilities import lambdify, public, sift, numbered_symbols
from sympy.multipledispatch import dispatch
from itertools import chain
__all__ = ['CRootOf']

class _pure_key_dict:

    def __init__(self):
        self._dict = {}

    def __getitem__(self, k):
        if not isinstance(k, Poly):
            try:
                k = Poly(k, expand=False)
            except (GeneratorsNeeded, PolynomialError):
                raise KeyError
        return self._dict[k]

    def __setitem__(self, k, v):
        if not isinstance(k, Poly):
            try:
                k = Poly(k, expand=False)
            except (GeneratorsNeeded, PolynomialError):
                raise ValueError('expecting univariate expression')
        self._dict[k] = v

    def __contains__(self, k):
        try:
            self[k]
            return True
        except KeyError:
            return False
_reals_cache = _pure_key_dict()
_complexes_cache = _pure_key_dict()
_rootof_dummy = Dummy('x')
_rootsum_dummy = Dummy('w')

def _pure_factors(poly):
    _, factors = poly.factor_list()
    return [(Poly(f, expand=False).retract(), m) for f, m in factors]

def _imag_count_of_factor(f):
    terms = [(i, j) for (i,), j in f.terms()]
    if any((i % 2 for i, j in terms)):
        return 0
    even = [(i, I ** i * j) for i, j in terms]
    even = Poly.from_dict(dict(even), Dummy('x'))
    return int(even.count_roots(-oo, oo))

@public
def rootof(f, x, index=None, radicals=True, expand=True):
    return CRootOf(f, x, index=index, radicals=radicals, expand=expand)

@public
class RootOf(Expr):
    __slots__ = ('poly',)

    def __new__(cls, f, x, index=None, radicals=True, expand=True):
        return rootof(f, x, index=index, radicals=radicals, expand=expand)

@public
class ComplexRootOf(RootOf):
    __slots__ = ('index',)
    is_complex = True
    is_number = True
    is_finite = True
    is_algebraic = True

    def __new__(cls, f, x, index=None, radicals=False, expand=True):
        x = sympify(x)
        if index is None and x.is_Integer:
            x, index = (None, x)
        else:
            index = sympify(index)
        if index is not None and index.is_Integer:
            index = int(index)
        else:
            raise ValueError('expected an integer root index, got %s' % index)
        poly = Poly(f, x, greedy=False, expand=expand)
        if not poly.is_univariate:
            raise PolynomialError('only univariate polynomials are allowed')
        if not poly.gen.is_Symbol:
            raise PolynomialError('generator must be a Symbol')
        degree = poly.degree()
        if degree <= 0:
            raise PolynomialError('Cannot construct CRootOf object for %s' % f)
        if index < -degree or index >= degree:
            raise IndexError('root index out of [%d, %d] range, got %d' % (-degree, degree - 1, index))
        elif index < 0:
            index += degree
        dom = poly.get_domain()
        if not dom.is_Exact:
            poly = poly.to_exact()
        roots = cls._roots_trivial(poly, radicals)
        if roots is not None:
            return roots[index]
        coeff, poly = preprocess_roots(poly)
        dom = poly.get_domain()
        if not dom.is_ZZ:
            raise NotImplementedError('CRootOf is not supported over %s' % dom)
        poly = Poly(poly.replace(poly.gen, _rootof_dummy))
        root = cls._indexed_root(poly, index, lazy=True)
        return coeff * cls._postprocess_root(root, radicals)

    @classmethod
    def _new(cls, poly, index):
        obj = Expr.__new__(cls)
        poly = poly.replace(poly.gen, _rootof_dummy)
        obj.poly = Poly(poly)
        obj.index = index
        try:
            _reals_cache[obj.poly] = _reals_cache[poly]
            _complexes_cache[obj.poly] = _complexes_cache[poly]
        except KeyError:
            pass
        return obj

    def _hashable_content(self):
        return (self.poly, self.index)

    @property
    def expr(self):
        return self.poly.as_expr()

    @property
    def args(self):
        return (self.expr, Integer(self.index))

    @property
    def free_symbols(self):
        return set()

    def _eval_is_real(self):
        self._ensure_reals_init()
        return self.index < len(_reals_cache[self.poly])

    def _eval_is_imaginary(self):
        self._ensure_reals_init()
        if self.index >= len(_reals_cache[self.poly]):
            ivl = self._get_interval()
            return ivl.ax * ivl.bx <= 0
        return False

    @classmethod
    def real_roots(cls, poly, radicals=True):
        return cls._get_roots('_real_roots', poly, radicals)

    @classmethod
    def all_roots(cls, poly, radicals=True):
        return cls._get_roots('_all_roots', poly, radicals)

    @classmethod
    def _get_reals_sqf(cls, currentfactor, use_cache=True):
        if use_cache and currentfactor in _reals_cache:
            real_part = _reals_cache[currentfactor]
        else:
            _reals_cache[currentfactor] = real_part = dup_isolate_real_roots_sqf(currentfactor.rep.to_list(), currentfactor.rep.dom, blackbox=True)
        return real_part

    @classmethod
    def _get_complexes_sqf(cls, currentfactor, use_cache=True):
        if use_cache and currentfactor in _complexes_cache:
            complex_part = _complexes_cache[currentfactor]
        else:
            _complexes_cache[currentfactor] = complex_part = dup_isolate_complex_roots_sqf(currentfactor.rep.to_list(), currentfactor.rep.dom, blackbox=True)
        return complex_part

    @classmethod
    def _get_reals(cls, factors, use_cache=True):
        reals = []
        for currentfactor, k in factors:
            try:
                if not use_cache:
                    raise KeyError
                r = _reals_cache[currentfactor]
                reals.extend([(i, currentfactor, k) for i in r])
            except KeyError:
                real_part = cls._get_reals_sqf(currentfactor, use_cache)
                new = [(root, currentfactor, k) for root in real_part]
                reals.extend(new)
        reals = cls._reals_sorted(reals)
        return reals

    @classmethod
    def _get_complexes(cls, factors, use_cache=True):
        complexes = []
        for currentfactor, k in ordered(factors):
            try:
                if not use_cache:
                    raise KeyError
                c = _complexes_cache[currentfactor]
                complexes.extend([(i, currentfactor, k) for i in c])
            except KeyError:
                complex_part = cls._get_complexes_sqf(currentfactor, use_cache)
                new = [(root, currentfactor, k) for root in complex_part]
                complexes.extend(new)
        complexes = cls._complexes_sorted(complexes)
        return complexes

    @classmethod
    def _reals_sorted(cls, reals):
        cache = {}
        for i, (u, f, k) in enumerate(reals):
            for j, (v, g, m) in enumerate(reals[i + 1:]):
                u, v = u.refine_disjoint(v)
                reals[i + j + 1] = (v, g, m)
            reals[i] = (u, f, k)
        reals = sorted(reals, key=lambda r: r[0].a)
        for root, currentfactor, _ in reals:
            if currentfactor in cache:
                cache[currentfactor].append(root)
            else:
                cache[currentfactor] = [root]
        for currentfactor, root in cache.items():
            _reals_cache[currentfactor] = root
        return reals

    @classmethod
    def _refine_imaginary(cls, complexes):
        sifted = sift(complexes, lambda c: c[1])
        complexes = []
        for f in ordered(sifted):
            nimag = _imag_count_of_factor(f)
            if nimag == 0:
                for u, f, k in sifted[f]:
                    while u.ax * u.bx <= 0:
                        u = u._inner_refine()
                    complexes.append((u, f, k))
            else:
                potential_imag = list(range(len(sifted[f])))
                while True:
                    assert len(potential_imag) > 1
                    for i in list(potential_imag):
                        u, f, k = sifted[f][i]
                        if u.ax * u.bx > 0:
                            potential_imag.remove(i)
                        elif u.ax != u.bx:
                            u = u._inner_refine()
                            sifted[f][i] = (u, f, k)
                    if len(potential_imag) == nimag:
                        break
                complexes.extend(sifted[f])
        return complexes

    @classmethod
    def _refine_complexes(cls, complexes):
        for i, (u, f, k) in enumerate(complexes):
            for j, (v, g, m) in enumerate(complexes[i + 1:]):
                u, v = u.refine_disjoint(v)
                complexes[i + j + 1] = (v, g, m)
            complexes[i] = (u, f, k)
        complexes = cls._refine_imaginary(complexes)
        for i, (u, f, k) in enumerate(complexes):
            while u.ay * u.by <= 0:
                u = u.refine()
            complexes[i] = (u, f, k)
        return complexes

    @classmethod
    def _complexes_sorted(cls, complexes):
        complexes = cls._refine_complexes(complexes)
        C, F = (0, 1)
        fs = {i[F] for i in complexes}
        for i in range(1, len(complexes)):
            if complexes[i][F] != complexes[i - 1][F]:
                fs.remove(complexes[i - 1][F])
        for i, cmplx in enumerate(complexes):
            assert cmplx[C].conj is (i % 2 == 0)
        cache = {}
        for root, currentfactor, _ in complexes:
            cache.setdefault(currentfactor, []).append(root)
        for currentfactor, root in cache.items():
            _complexes_cache[currentfactor] = root
        return complexes

    @classmethod
    def _reals_index(cls, reals, index):
        i = 0
        for j, (_, currentfactor, k) in enumerate(reals):
            if index < i + k:
                poly, index = (currentfactor, 0)
                for _, currentfactor, _ in reals[:j]:
                    if currentfactor == poly:
                        index += 1
                return (poly, index)
            else:
                i += k

    @classmethod
    def _complexes_index(cls, complexes, index):
        i = 0
        for j, (_, currentfactor, k) in enumerate(complexes):
            if index < i + k:
                poly, index = (currentfactor, 0)
                for _, currentfactor, _ in complexes[:j]:
                    if currentfactor == poly:
                        index += 1
                index += len(_reals_cache[poly])
                return (poly, index)
            else:
                i += k

    @classmethod
    def _count_roots(cls, roots):
        return sum((k for _, _, k in roots))

    @classmethod
    def _indexed_root(cls, poly, index, lazy=False):
        factors = _pure_factors(poly)
        if lazy and len(factors) == 1 and (factors[0][1] == 1):
            return (factors[0][0], index)
        reals = cls._get_reals(factors)
        reals_count = cls._count_roots(reals)
        if index < reals_count:
            return cls._reals_index(reals, index)
        else:
            complexes = cls._get_complexes(factors)
            return cls._complexes_index(complexes, index - reals_count)

    def _ensure_reals_init(self):
        if self.poly not in _reals_cache:
            self._indexed_root(self.poly, self.index)

    def _ensure_complexes_init(self):
        if self.poly not in _complexes_cache:
            self._indexed_root(self.poly, self.index)

    @classmethod
    def _real_roots(cls, poly):
        factors = _pure_factors(poly)
        reals = cls._get_reals(factors)
        reals_count = cls._count_roots(reals)
        roots = []
        for index in range(0, reals_count):
            roots.append(cls._reals_index(reals, index))
        return roots

    def _reset(self):
        factors = _pure_factors(self.poly)
        self._get_reals(factors, use_cache=False)
        self._get_complexes(factors, use_cache=False)

    @classmethod
    def _all_roots(cls, poly, use_cache=True):
        factors = _pure_factors(poly)
        roots = []
        if len(factors) == 1:
            f, multiplicity = factors[0]
            deg = f.degree()
            roots.extend(((f, i) for i in range(deg) for _ in range(multiplicity)))
        else:
            reals = cls._get_reals(factors, use_cache=use_cache)
            reals_count = cls._count_roots(reals)
            for index in range(0, reals_count):
                roots.append(cls._reals_index(reals, index))
            complexes = cls._get_complexes(factors, use_cache=use_cache)
            complexes_count = cls._count_roots(complexes)
            for index in range(0, complexes_count):
                roots.append(cls._complexes_index(complexes, index))
        return roots

    @classmethod
    @cacheit
    def _roots_trivial(cls, poly, radicals):
        if poly.degree() == 1:
            return roots_linear(poly)
        if not radicals:
            return None
        if poly.degree() == 2:
            return roots_quadratic(poly)
        elif poly.length() == 2 and poly.TC():
            return roots_binomial(poly)
        else:
            return None

    @classmethod
    def _preprocess_roots(cls, poly):
        dom = poly.get_domain()
        if not dom.is_Exact:
            poly = poly.to_exact()
        coeff, poly = preprocess_roots(poly)
        dom = poly.get_domain()
        if not dom.is_ZZ:
            raise NotImplementedError('sorted roots not supported over %s' % dom)
        return (coeff, poly)

    @classmethod
    def _postprocess_root(cls, root, radicals):
        poly, index = root
        roots = cls._roots_trivial(poly, radicals)
        if roots is not None:
            return roots[index]
        else:
            return cls._new(poly, index)

    @classmethod
    def _get_roots(cls, method: str, poly: Poly, radicals: bool) -> list[Expr]:
        if not poly.is_univariate:
            raise PolynomialError('only univariate polynomials are allowed')
        dom = poly.get_domain()
        d = Dummy()
        poly = poly.per(poly.rep, gens=(d,))
        x = symbols('x')
        free_names = {str(i) for i in poly.free_symbols}
        for x in chain((symbols('x'),), numbered_symbols('x')):
            if x.name not in free_names:
                poly = poly.replace(d, x)
                break
        if dom.is_QQ or dom.is_ZZ:
            return cls._get_roots_qq(method, poly, radicals)
        elif dom.is_ZZ_I or dom.is_QQ_I:
            coeffs = poly.rep.to_list()
            if all((c.y == 0 for c in coeffs)):
                poly = poly.set_domain(dom.dom)
                return cls._get_roots_qq(method, poly, radicals)
            elif all((c.x == 0 for c in coeffs)):
                poly = (I * poly).set_domain(dom.dom)
                return cls._get_roots_qq(method, poly, radicals)
            else:
                return cls._get_roots_alg(method, poly, radicals)
        elif dom.is_AlgebraicField:
            return cls._get_roots_alg(method, poly, radicals)
        else:
            return cls._get_roots_qq(method, poly, radicals)

    @classmethod
    def _get_roots_qq(cls, method, poly, radicals):
        coeff, poly = cls._preprocess_roots(poly)
        roots = []
        for root in getattr(cls, method)(poly):
            roots.append(coeff * cls._postprocess_root(root, radicals))
        return roots

    @classmethod
    def _get_roots_alg(cls, method, poly, radicals):
        roots = cls._get_roots_qq(method, poly.lift(), radicals)
        subroots = {}
        for f, m in poly.sqf_list()[1]:
            if method == '_real_roots':
                roots_filt = f.which_real_roots(roots)
            elif method == '_all_roots':
                roots_filt = f.which_all_roots(roots)
            else:
                raise TypeError('Unknown method')
            for r in roots_filt:
                subroots[r] = m
        roots_seen = set()
        roots_flat = []
        for r in roots:
            if r in subroots and r not in roots_seen:
                m = subroots[r]
                roots_flat.extend([r] * m)
                roots_seen.add(r)
        return roots_flat

    @classmethod
    def clear_cache(cls):
        global _reals_cache, _complexes_cache
        _reals_cache = _pure_key_dict()
        _complexes_cache = _pure_key_dict()

    def _get_interval(self):
        self._ensure_reals_init()
        if self.is_real:
            return _reals_cache[self.poly][self.index]
        else:
            reals_count = len(_reals_cache[self.poly])
            self._ensure_complexes_init()
            return _complexes_cache[self.poly][self.index - reals_count]

    def _set_interval(self, interval):
        self._ensure_reals_init()
        if self.is_real:
            _reals_cache[self.poly][self.index] = interval
        else:
            reals_count = len(_reals_cache[self.poly])
            self._ensure_complexes_init()
            _complexes_cache[self.poly][self.index - reals_count] = interval

    def _eval_subs(self, old, new):
        return self

    def _eval_conjugate(self):
        if self.is_real:
            return self
        expr, i = self.args
        return self.func(expr, i + (1 if self._get_interval().conj else -1))

    def eval_approx(self, n, return_mpmath=False):
        prec = dps_to_prec(n)
        with local_workprec(prec) as mp:
            g = self.poly.gen
            if not g.is_Symbol:
                d = Dummy('x')
                if self.is_imaginary:
                    d *= I
                func = lambdify(d, self.expr.subs(g, d), modules=mp)
            else:
                expr = self.expr
                if self.is_imaginary:
                    expr = self.expr.subs(g, I * g)
                func = lambdify(g, expr, modules=mp)
            interval = self._get_interval()
            while True:
                if self.is_real:
                    a = mp.mpf(str(interval.a))
                    b = mp.mpf(str(interval.b))
                    if a == b:
                        root = a
                        break
                    x0 = mp.mpf(str(interval.center))
                    x1 = mp.fadd(x0, mp.fdiv(mp.mpf(str(interval.dx)), 4))
                elif self.is_imaginary:
                    a = mp.mpf(str(interval.ay))
                    b = mp.mpf(str(interval.by))
                    if a == b:
                        root = mp.mpc(mp.mpf('0'), a)
                        break
                    x0 = mp.mpf(str(interval.center[1]))
                    x1 = mp.fadd(x0, mp.fdiv(mp.mpf(str(interval.dy)), 4))
                else:
                    ax = mp.mpf(str(interval.ax))
                    bx = mp.mpf(str(interval.bx))
                    ay = mp.mpf(str(interval.ay))
                    by = mp.mpf(str(interval.by))
                    if ax == bx and ay == by:
                        root = mp.mpc(ax, ay)
                        break
                    x0 = mp.mpc(*map(str, interval.center))
                    x1 = mp.fadd(x0, mp.fdiv(mp.mpc(*map(str, (interval.dx, interval.dy))), 4))
                try:
                    root = mp.findroot(func, (x0, x1))
                    if self.is_real or self.is_imaginary:
                        if not bool(root.imag) == self.is_real and a <= root <= b:
                            if self.is_imaginary:
                                root = mp.mpc(mp.mpf('0'), root.real)
                            break
                    elif ax <= root.real <= bx and ay <= root.imag <= by:
                        break
                except (UnboundLocalError, ValueError):
                    pass
                interval = interval.refine()
        self._set_interval(interval)
        if return_mpmath:
            return root
        return Float._new(root.real._mpf_, prec) + I * Float._new(root.imag._mpf_, prec)

    def _eval_evalf(self, prec, **kwargs):
        return self.eval_rational(n=prec_to_dps(prec))._evalf(prec)

    def eval_rational(self, dx=None, dy=None, n=15):
        dy = dy or dx
        if dx:
            rtol = None
            dx = dx if isinstance(dx, Rational) else Rational(str(dx))
            dy = dy if isinstance(dy, Rational) else Rational(str(dy))
        else:
            rtol = S(10) ** (-(n + 2))
        interval = self._get_interval()
        while True:
            if self.is_real:
                if rtol:
                    dx = abs(interval.center * rtol)
                interval = interval.refine_size(dx=dx)
                c = interval.center
                real = Rational(c)
                imag = S.Zero
                if not rtol or interval.dx < abs(c * rtol):
                    break
            elif self.is_imaginary:
                if rtol:
                    dy = abs(interval.center[1] * rtol)
                    dx = 1
                interval = interval.refine_size(dx=dx, dy=dy)
                c = interval.center[1]
                imag = Rational(c)
                real = S.Zero
                if not rtol or interval.dy < abs(c * rtol):
                    break
            else:
                if rtol:
                    dx = abs(interval.center[0] * rtol)
                    dy = abs(interval.center[1] * rtol)
                interval = interval.refine_size(dx, dy)
                c = interval.center
                real, imag = map(Rational, c)
                if not rtol or (interval.dx < abs(c[0] * rtol) and interval.dy < abs(c[1] * rtol)):
                    break
        self._set_interval(interval)
        return real + I * imag
CRootOf = ComplexRootOf

@dispatch(ComplexRootOf, ComplexRootOf)
def _eval_is_eq(lhs, rhs):
    return lhs == rhs

@dispatch(ComplexRootOf, Basic)
def _eval_is_eq(lhs, rhs):
    if not rhs.is_number:
        return None
    if not rhs.is_finite:
        return False
    z = lhs.expr.subs(lhs.expr.free_symbols.pop(), rhs).is_zero
    if z is False:
        return False
    o = (rhs.is_real, rhs.is_imaginary)
    s = (lhs.is_real, lhs.is_imaginary)
    assert None not in s
    if o != s and None not in o:
        return False
    re, im = rhs.as_real_imag()
    if lhs.is_real:
        if im:
            return False
        i = lhs._get_interval()
        a, b = [Rational(str(_)) for _ in (i.a, i.b)]
        return sympify(a <= rhs and rhs <= b)
    i = lhs._get_interval()
    r1, r2, i1, i2 = [Rational(str(j)) for j in (i.ax, i.bx, i.ay, i.by)]
    return is_le(r1, re) and is_le(re, r2) and is_le(i1, im) and is_le(im, i2)

@public
class RootSum(Expr):
    __slots__ = ('poly', 'fun', 'auto')

    def __new__(cls, expr, func=None, x=None, auto=True, quadratic=False):
        coeff, poly = cls._transform(expr, x)
        if not poly.is_univariate:
            raise MultivariatePolynomialError('only univariate polynomials are allowed')
        poly = Poly(poly.replace(poly.gen, _rootsum_dummy))
        if func is None:
            func = Lambda(_rootsum_dummy, _rootsum_dummy)
        else:
            is_func = getattr(func, 'is_Function', False)
            if is_func and 1 in func.nargs:
                func = Lambda(_rootsum_dummy, func(_rootsum_dummy))
            else:
                raise ValueError('expected a univariate function, got %s' % func)
        var, expr = (func.variables[0], func.expr)
        if coeff is not S.One:
            expr = expr.subs(var, coeff * var)
        deg = poly.degree()
        if not expr.has(var):
            return deg * expr
        if expr.is_Add:
            add_const, expr = expr.as_independent(var)
        else:
            add_const = S.Zero
        if expr.is_Mul:
            mul_const, expr = expr.as_independent(var)
        else:
            mul_const = S.One
        func = Lambda(var, expr)
        rational = cls._is_func_rational(poly, func)
        factors, terms = (_pure_factors(poly), [])
        for poly, k in factors:
            if poly.is_linear:
                term = func(roots_linear(poly)[0])
            elif quadratic and poly.is_quadratic:
                term = sum(map(func, roots_quadratic(poly)))
            elif not rational or not auto:
                term = cls._new(poly, func, auto)
            else:
                term = cls._rational_case(poly, func)
            terms.append(k * term)
        return mul_const * Add(*terms) + deg * add_const

    @classmethod
    def _new(cls, poly, func, auto=True):
        obj = Expr.__new__(cls)
        obj.poly = poly
        obj.fun = func
        obj.auto = auto
        return obj

    @classmethod
    def new(cls, poly, func, auto=True):
        if not func.expr.has(*func.variables):
            return func.expr
        rational = cls._is_func_rational(poly, func)
        if not rational or not auto:
            return cls._new(poly, func, auto)
        else:
            return cls._rational_case(poly, func)

    @classmethod
    def _transform(cls, expr, x):
        poly = Poly(expr, x, greedy=False)
        return preprocess_roots(poly)

    @classmethod
    def _is_func_rational(cls, poly, func):
        var, expr = (func.variables[0], func.expr)
        return expr.is_rational_function(var)

    @classmethod
    def _rational_case(cls, poly, func):
        roots = symbols('r:%d' % poly.degree())
        var, expr = (func.variables[0], func.expr)
        f = sum((expr.subs(var, r) for r in roots))
        p, q = together(f).as_numer_denom()
        domain = QQ[roots]
        p = p.expand()
        q = q.expand()
        try:
            p = Poly(p, domain=domain, expand=False)
        except GeneratorsNeeded:
            p, p_coeff = (None, (p,))
        else:
            p_monom, p_coeff = zip(*p.terms())
        try:
            q = Poly(q, domain=domain, expand=False)
        except GeneratorsNeeded:
            q, q_coeff = (None, (q,))
        else:
            q_monom, q_coeff = zip(*q.terms())
        coeffs, mapping = symmetrize(p_coeff + q_coeff, formal=True)
        formulas, values = (viete(poly, roots), [])
        for (sym, _), (_, val) in zip(mapping, formulas):
            values.append((sym, val))
        for i, (coeff, _) in enumerate(coeffs):
            coeffs[i] = coeff.subs(values)
        n = len(p_coeff)
        p_coeff = coeffs[:n]
        q_coeff = coeffs[n:]
        if p is not None:
            p = Poly(dict(zip(p_monom, p_coeff)), *p.gens).as_expr()
        else:
            p, = p_coeff
        if q is not None:
            q = Poly(dict(zip(q_monom, q_coeff)), *q.gens).as_expr()
        else:
            q, = q_coeff
        return factor(p / q)

    def _hashable_content(self):
        return (self.poly, self.fun)

    @property
    def expr(self):
        return self.poly.as_expr()

    @property
    def args(self):
        return (self.expr, self.fun, self.poly.gen)

    @property
    def free_symbols(self):
        poly_syms = self.poly.free_symbols - {self.poly.gen}
        return poly_syms | self.fun.free_symbols

    @property
    def is_commutative(self):
        return True

    def doit(self, **hints):
        if not hints.get('roots', True):
            return self
        _roots = roots(self.poly, multiple=True)
        if len(_roots) < self.poly.degree():
            return self
        else:
            return Add(*[self.fun(r) for r in _roots])

    def _eval_evalf(self, prec):
        try:
            _roots = self.poly.nroots(n=prec_to_dps(prec))
        except (DomainError, PolynomialError):
            return self
        else:
            return Add(*[self.fun(r) for r in _roots])

    def _eval_derivative(self, x):
        var, expr = self.fun.args
        func = Lambda(var, expr.diff(x))
        return self.new(self.poly, func, self.auto)