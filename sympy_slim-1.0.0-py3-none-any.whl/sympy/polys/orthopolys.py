from __future__ import annotations
from sympy.core.symbol import Dummy
from sympy.polys.densearith import dup_mul, dup_mul_ground, dup_lshift, dup_sub, dup_add, dup_sub_term, dup_sub_ground, dup_sqr
from sympy.polys.domains import ZZ, QQ
from sympy.polys.polytools import named_poly
from sympy.utilities import public

def dup_jacobi(n, a, b, K):
    if n < 1:
        return [K.one]
    m2, m1 = ([K.one], [(a + b) / K(2) + K.one, (a - b) / K(2)])
    for i in range(2, n + 1):
        den = K(i) * (a + b + i) * (a + b + K(2) * i - K(2))
        f0 = (a + b + K(2) * i - K.one) * (a * a - b * b) / (K(2) * den)
        f1 = (a + b + K(2) * i - K.one) * (a + b + K(2) * i - K(2)) * (a + b + K(2) * i) / (K(2) * den)
        f2 = (a + i - K.one) * (b + i - K.one) * (a + b + K(2) * i) / den
        p0 = dup_mul_ground(m1, f0, K)
        p1 = dup_mul_ground(dup_lshift(m1, 1, K), f1, K)
        p2 = dup_mul_ground(m2, f2, K)
        m2, m1 = (m1, dup_sub(dup_add(p0, p1, K), p2, K))
    return m1

@public
def jacobi_poly(n, a, b, x=None, polys=False):
    return named_poly(n, dup_jacobi, None, 'Jacobi polynomial', (x, a, b), polys)

def dup_gegenbauer(n, a, K):
    if n < 1:
        return [K.one]
    m2, m1 = ([K.one], [K(2) * a, K.zero])
    for i in range(2, n + 1):
        p1 = dup_mul_ground(dup_lshift(m1, 1, K), K(2) * (a - K.one) / K(i) + K(2), K)
        p2 = dup_mul_ground(m2, K(2) * (a - K.one) / K(i) + K.one, K)
        m2, m1 = (m1, dup_sub(p1, p2, K))
    return m1

def gegenbauer_poly(n, a, x=None, polys=False):
    return named_poly(n, dup_gegenbauer, None, 'Gegenbauer polynomial', (x, a), polys)

def dup_chebyshevt(n, K):
    if n < 1:
        return [K.one]
    if n < 64:
        return _dup_chebyshevt_rec(n, K)
    return _dup_chebyshevt_prod(n, K)

def _dup_chebyshevt_rec(n, K):
    m2, m1 = ([K.one], [K.one, K.zero])
    for _ in range(n - 1):
        m2, m1 = (m1, dup_sub(dup_mul_ground(dup_lshift(m1, 1, K), K(2), K), m2, K))
    return m1

def _dup_chebyshevt_prod(n, K):
    m2, m1 = ([K.one, K.zero], [K(2), K.zero, -K.one])
    for i in bin(n)[3:]:
        c = dup_sub_term(dup_mul_ground(dup_mul(m1, m2, K), K(2), K), K.one, 1, K)
        if i == '1':
            m2, m1 = (c, dup_sub_ground(dup_mul_ground(dup_sqr(m1, K), K(2), K), K.one, K))
        else:
            m2, m1 = (dup_sub_ground(dup_mul_ground(dup_sqr(m2, K), K(2), K), K.one, K), c)
    return m2

def dup_chebyshevu(n, K):
    if n < 1:
        return [K.one]
    m2, m1 = ([K.one], [K(2), K.zero])
    for i in range(2, n + 1):
        m2, m1 = (m1, dup_sub(dup_mul_ground(dup_lshift(m1, 1, K), K(2), K), m2, K))
    return m1

@public
def chebyshevt_poly(n, x=None, polys=False):
    return named_poly(n, dup_chebyshevt, ZZ, 'Chebyshev polynomial of the first kind', (x,), polys)

@public
def chebyshevu_poly(n, x=None, polys=False):
    return named_poly(n, dup_chebyshevu, ZZ, 'Chebyshev polynomial of the second kind', (x,), polys)

def dup_hermite(n, K):
    if n < 1:
        return [K.one]
    m2, m1 = ([K.one], [K(2), K.zero])
    for i in range(2, n + 1):
        a = dup_lshift(m1, 1, K)
        b = dup_mul_ground(m2, K(i - 1), K)
        m2, m1 = (m1, dup_mul_ground(dup_sub(a, b, K), K(2), K))
    return m1

def dup_hermite_prob(n, K):
    if n < 1:
        return [K.one]
    m2, m1 = ([K.one], [K.one, K.zero])
    for i in range(2, n + 1):
        a = dup_lshift(m1, 1, K)
        b = dup_mul_ground(m2, K(i - 1), K)
        m2, m1 = (m1, dup_sub(a, b, K))
    return m1

@public
def hermite_poly(n, x=None, polys=False):
    return named_poly(n, dup_hermite, ZZ, 'Hermite polynomial', (x,), polys)

@public
def hermite_prob_poly(n, x=None, polys=False):
    return named_poly(n, dup_hermite_prob, ZZ, "probabilist's Hermite polynomial", (x,), polys)

def dup_legendre(n, K):
    if n < 1:
        return [K.one]
    m2, m1 = ([K.one], [K.one, K.zero])
    for i in range(2, n + 1):
        a = dup_mul_ground(dup_lshift(m1, 1, K), K(2 * i - 1, i), K)
        b = dup_mul_ground(m2, K(i - 1, i), K)
        m2, m1 = (m1, dup_sub(a, b, K))
    return m1

@public
def legendre_poly(n, x=None, polys=False):
    return named_poly(n, dup_legendre, QQ, 'Legendre polynomial', (x,), polys)

def dup_laguerre(n, alpha, K):
    m2, m1 = ([K.zero], [K.one])
    for i in range(1, n + 1):
        a = dup_mul(m1, [-K.one / K(i), (alpha - K.one) / K(i) + K(2)], K)
        b = dup_mul_ground(m2, (alpha - K.one) / K(i) + K.one, K)
        m2, m1 = (m1, dup_sub(a, b, K))
    return m1

@public
def laguerre_poly(n, x=None, alpha=0, polys=False):
    return named_poly(n, dup_laguerre, None, 'Laguerre polynomial', (x, alpha), polys)

def dup_spherical_bessel_fn(n, K):
    if n < 1:
        return [K.one, K.zero]
    m2, m1 = ([K.one], [K.one, K.zero])
    for i in range(2, n + 1):
        m2, m1 = (m1, dup_sub(dup_mul_ground(dup_lshift(m1, 1, K), K(2 * i - 1), K), m2, K))
    return dup_lshift(m1, 1, K)

def dup_spherical_bessel_fn_minus(n, K):
    m2, m1 = ([K.one, K.zero], [K.zero])
    for i in range(2, n + 1):
        m2, m1 = (m1, dup_sub(dup_mul_ground(dup_lshift(m1, 1, K), K(3 - 2 * i), K), m2, K))
    return m1

def spherical_bessel_fn(n, x=None, polys=False):
    if x is None:
        x = Dummy('x')
    f = dup_spherical_bessel_fn_minus if n < 0 else dup_spherical_bessel_fn
    return named_poly(abs(n), f, ZZ, '', (QQ(1) / x,), polys)