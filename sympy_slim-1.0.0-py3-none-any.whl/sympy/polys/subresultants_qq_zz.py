from __future__ import annotations
from sympy.concrete.summations import summation
from sympy.core.function import expand
from sympy.core.numbers import nan
from sympy.core.singleton import S
from sympy.core.symbol import Dummy as var
from sympy.functions.elementary.complexes import Abs, sign
from sympy.functions.elementary.integers import floor
from sympy.matrices.dense import eye, Matrix, zeros
from sympy.printing.pretty.pretty import pretty_print as pprint
from sympy.simplify.simplify import simplify
from sympy.polys.domains import QQ
from sympy.polys.polytools import degree, LC, Poly, pquo, quo, prem, rem
from sympy.polys.polyerrors import PolynomialError

def sylvester(f, g, x, method=1):
    m, n = (degree(Poly(f, x), x), degree(Poly(g, x), x))
    if m == n and n < 0:
        return Matrix([])
    if m == n and n == 0:
        return Matrix([])
    if m == 0 and n < 0 or (m < 0 and n == 0):
        return Matrix([])
    if m >= 1 and n < 0 or (m < 0 and n >= 1):
        return Matrix([0])
    fp = Poly(f, x).all_coeffs()
    gp = Poly(g, x).all_coeffs()
    if method <= 1:
        M = zeros(m + n)
        for i in range(n):
            for j, coeff in enumerate(fp, i):
                M[i, j] = coeff
        for i in range(n, m + n):
            for j, coeff in enumerate(gp, i - n):
                M[i, j] = coeff
        return M
    else:
        if len(fp) < len(gp):
            h = []
            for i in range(len(gp) - len(fp)):
                h.append(0)
            fp[:0] = h
        else:
            h = []
            for i in range(len(fp) - len(gp)):
                h.append(0)
            gp[:0] = h
        mx = max(m, n)
        dim = 2 * mx
        M = zeros(dim)
        for i in range(mx):
            for j, coeff in enumerate(fp, i):
                M[2 * i, j] = coeff
            for j, coeff in enumerate(gp, i):
                M[2 * i + 1, j] = coeff
        return M

def process_matrix_output(poly_seq, x):
    L = poly_seq[:]
    d = degree(L[1], x)
    i = 2
    while i < len(L):
        d_i = degree(L[i], x)
        if d_i < 0:
            L.remove(L[i])
            i = i - 1
        if d == d_i:
            L.remove(L[i])
            i = i - 1
        if d_i >= 0:
            d = d_i
        i = i + 1
    return L

def subresultants_sylv(f, g, x):
    if f == 0 or g == 0:
        return [f, g]
    n = degF = degree(f, x)
    m = degG = degree(g, x)
    if n == 0 and m == 0:
        return [f, g]
    if n < m:
        n, m, degF, degG, f, g = (m, n, degG, degF, g, f)
    if n > 0 and m == 0:
        return [f, g]
    SR_L = [f, g]
    S = sylvester(f, g, x, 1)
    for j in range(m - 1, 0, -1):
        Sp = S[:, :]
        for ind in range(m + n - j, m + n):
            Sp.row_del(m + n - j)
        for ind in range(m - j, m):
            Sp.row_del(m - j)
        coeff_L, k = ([], Sp.rows)
        for l in range(j + 1):
            coeff_L.append(Sp[:, 0:k].det())
            Sp.col_swap(k - 1, k + l)
        SR_L.append(Poly(coeff_L, x).as_expr())
    SR_L.append(S.det())
    return process_matrix_output(SR_L, x)

def modified_subresultants_sylv(f, g, x):
    if f == 0 or g == 0:
        return [f, g]
    n = degF = degree(f, x)
    m = degG = degree(g, x)
    if n == 0 and m == 0:
        return [f, g]
    if n < m:
        n, m, degF, degG, f, g = (m, n, degG, degF, g, f)
    if n > 0 and m == 0:
        return [f, g]
    SR_L = [f, g]
    S = sylvester(f, g, x, 2)
    for j in range(m - 1, 0, -1):
        Sp = S[0:2 * n - 2 * j, :]
        coeff_L, k = ([], Sp.rows)
        for l in range(j + 1):
            coeff_L.append(Sp[:, 0:k].det())
            Sp.col_swap(k - 1, k + l)
        SR_L.append(Poly(coeff_L, x).as_expr())
    SR_L.append(S.det())
    return process_matrix_output(SR_L, x)

def res(f, g, x):
    if f == 0 or g == 0:
        raise PolynomialError('The resultant of %s and %s is not defined' % (f, g))
    else:
        return sylvester(f, g, x, 1).det()

def res_q(f, g, x):
    m = degree(f, x)
    n = degree(g, x)
    if m < n:
        return (-1) ** (m * n) * res_q(g, f, x)
    elif n == 0:
        return g ** m
    else:
        r = rem(f, g, x)
        if r == 0:
            return 0
        else:
            s = degree(r, x)
            l = LC(g, x)
            return (-1) ** (m * n) * l ** (m - s) * res_q(g, r, x)

def res_z(f, g, x):
    m = degree(f, x)
    n = degree(g, x)
    if m < n:
        return (-1) ** (m * n) * res_z(g, f, x)
    elif n == 0:
        return g ** m
    else:
        r = prem(f, g, x)
        if r == 0:
            return 0
        else:
            delta = m - n + 1
            w = (-1) ** (m * n) * res_z(g, r, x)
            s = degree(r, x)
            l = LC(g, x)
            k = delta * n - m + s
            return quo(w, l ** k, x)

def sign_seq(poly_seq, x):
    return [sign(LC(poly_seq[i], x)) for i in range(len(poly_seq))]

def bezout(p, q, x, method='bz'):
    m, n = (degree(Poly(p, x), x), degree(Poly(q, x), x))
    if m == n and n < 0:
        return Matrix([])
    if m == n and n == 0:
        return Matrix([])
    if m == 0 and n < 0 or (m < 0 and n == 0):
        return Matrix([])
    if m >= 1 and n < 0 or (m < 0 and n >= 1):
        return Matrix([0])
    y = var('y')
    expr = p * q.subs({x: y}) - p.subs({x: y}) * q
    poly = Poly(quo(expr, x - y), x, y)
    mx = max(m, n)
    B = zeros(mx)
    for i in range(mx):
        for j in range(mx):
            if method == 'prs':
                B[mx - 1 - i, mx - 1 - j] = poly.nth(i, j)
            else:
                B[i, j] = poly.nth(i, j)
    return B

def backward_eye(n):
    M = eye(n)
    for i in range(int(M.rows / 2)):
        M.row_swap(0 + i, M.rows - 1 - i)
    return M

def subresultants_bezout(p, q, x):
    if p == 0 or q == 0:
        return [p, q]
    f, g = (p, q)
    n = degF = degree(f, x)
    m = degG = degree(g, x)
    if n == 0 and m == 0:
        return [f, g]
    if n < m:
        n, m, degF, degG, f, g = (m, n, degG, degF, g, f)
    if n > 0 and m == 0:
        return [f, g]
    SR_L = [f, g]
    F = LC(f, x) ** (degF - degG)
    B = bezout(f, g, x, 'prs')
    if degF > degG:
        j = 2
    if degF == degG:
        j = 1
    while j <= degF:
        M = B[0:j, :]
        k, coeff_L = (j - 1, [])
        while k <= degF - 1:
            coeff_L.append(M[:, 0:j].det())
            if k < degF - 1:
                M.col_swap(j - 1, k + 1)
            k = k + 1
        SR_L.append(int((-1) ** (j * (j - 1) / 2)) * (Poly(coeff_L, x) / F).as_expr())
        j = j + 1
    return process_matrix_output(SR_L, x)

def modified_subresultants_bezout(p, q, x):
    if p == 0 or q == 0:
        return [p, q]
    f, g = (p, q)
    n = degF = degree(f, x)
    m = degG = degree(g, x)
    if n == 0 and m == 0:
        return [f, g]
    if n < m:
        n, m, degF, degG, f, g = (m, n, degG, degF, g, f)
    if n > 0 and m == 0:
        return [f, g]
    SR_L = [f, g]
    B = bezout(f, g, x, 'prs')
    for j in range(2 if degF > degG else 1, degF + 1):
        M = B[0:j, :]
        coeff_L = []
        for k in range(j - 1, degF):
            coeff_L.append(M[:, 0:j].det())
            if k < degF - 1:
                M.col_swap(j - 1, k + 1)
        SR_L.append(Poly(coeff_L, x).as_expr())
    return process_matrix_output(SR_L, x)

def sturm_pg(p, q, x, method=0):
    if p == 0 or q == 0:
        return [p, q]
    d0 = degree(p, x)
    d1 = degree(q, x)
    if d0 == 0 and d1 == 0:
        return [p, q]
    if d1 > d0:
        d0, d1 = (d1, d0)
        p, q = (q, p)
    if d0 > 0 and d1 == 0:
        return [p, q]
    flag = 0
    if LC(p, x) < 0:
        flag = 1
        p = -p
        q = -q
    lcf = LC(p, x) ** (d0 - d1)
    a0, a1 = (p, q)
    sturm_seq = [a0, a1]
    del0 = d0 - d1
    rho1 = LC(a1, x)
    exp_deg = d1 - 1
    a2 = -rem(a0, a1, domain=QQ)
    rho2 = LC(a2, x)
    d2 = degree(a2, x)
    deg_diff_new = exp_deg - d2
    del1 = d1 - d2
    mul_fac_old = rho1 ** (del0 + del1 - deg_diff_new)
    if method == 0:
        sturm_seq.append(simplify(lcf * a2 * Abs(mul_fac_old)))
    else:
        sturm_seq.append(simplify(a2 * Abs(mul_fac_old)))
    deg_diff_old = deg_diff_new
    while d2 > 0:
        a0, a1, d0, d1 = (a1, a2, d1, d2)
        del0 = del1
        exp_deg = d1 - 1
        a2 = -rem(a0, a1, domain=QQ)
        rho3 = LC(a2, x)
        d2 = degree(a2, x)
        deg_diff_new = exp_deg - d2
        del1 = d1 - d2
        expo_old = deg_diff_old
        expo_new = del0 + del1 - deg_diff_new
        mul_fac_new = rho2 ** expo_new * rho1 ** expo_old * mul_fac_old
        deg_diff_old, mul_fac_old = (deg_diff_new, mul_fac_new)
        rho1, rho2 = (rho2, rho3)
        if method == 0:
            sturm_seq.append(simplify(lcf * a2 * Abs(mul_fac_old)))
        else:
            sturm_seq.append(simplify(a2 * Abs(mul_fac_old)))
    if flag:
        sturm_seq = [-i for i in sturm_seq]
    m = len(sturm_seq)
    if sturm_seq[m - 1] == nan or sturm_seq[m - 1] == 0:
        sturm_seq.pop(m - 1)
    return sturm_seq

def sturm_q(p, q, x):
    if p == 0 or q == 0:
        return [p, q]
    d0 = degree(p, x)
    d1 = degree(q, x)
    if d0 == 0 and d1 == 0:
        return [p, q]
    if d1 > d0:
        d0, d1 = (d1, d0)
        p, q = (q, p)
    if d0 > 0 and d1 == 0:
        return [p, q]
    flag = 0
    if LC(p, x) < 0:
        flag = 1
        p = -p
        q = -q
    a0, a1 = (p, q)
    sturm_seq = [a0, a1]
    a2 = -rem(a0, a1, domain=QQ)
    d2 = degree(a2, x)
    sturm_seq.append(a2)
    while d2 > 0:
        a0, a1, d0, d1 = (a1, a2, d1, d2)
        a2 = -rem(a0, a1, domain=QQ)
        d2 = degree(a2, x)
        sturm_seq.append(a2)
    if flag:
        sturm_seq = [-i for i in sturm_seq]
    m = len(sturm_seq)
    if sturm_seq[m - 1] == nan or sturm_seq[m - 1] == 0:
        sturm_seq.pop(m - 1)
    return sturm_seq

def sturm_amv(p, q, x, method=0):
    prs = euclid_amv(p, q, x)
    if prs == [] or len(prs) == 2:
        return prs
    lcf = Abs(LC(prs[0]) ** (degree(prs[0], x) - degree(prs[1], x)))
    sturm_seq = [prs[0], prs[1]]
    flag = 0
    m = len(prs)
    i = 2
    while i <= m - 1:
        if flag == 0:
            sturm_seq.append(-prs[i])
            i = i + 1
            if i == m:
                break
            sturm_seq.append(-prs[i])
            i = i + 1
            flag = 1
        elif flag == 1:
            sturm_seq.append(prs[i])
            i = i + 1
            if i == m:
                break
            sturm_seq.append(prs[i])
            i = i + 1
            flag = 0
    if method == 0 and lcf > 1:
        aux_seq = [sturm_seq[0], sturm_seq[1]]
        for i in range(2, m):
            aux_seq.append(simplify(sturm_seq[i] * lcf))
        sturm_seq = aux_seq
    return sturm_seq

def euclid_pg(p, q, x):
    prs = sturm_pg(p, q, x, 1)
    if prs == [] or len(prs) == 2:
        return prs
    euclid_seq = [prs[0], prs[1]]
    flag = 0
    m = len(prs)
    i = 2
    while i <= m - 1:
        if flag == 0:
            euclid_seq.append(-prs[i])
            i = i + 1
            if i == m:
                break
            euclid_seq.append(-prs[i])
            i = i + 1
            flag = 1
        elif flag == 1:
            euclid_seq.append(prs[i])
            i = i + 1
            if i == m:
                break
            euclid_seq.append(prs[i])
            i = i + 1
            flag = 0
    return euclid_seq

def euclid_q(p, q, x):
    if p == 0 or q == 0:
        return [p, q]
    d0 = degree(p, x)
    d1 = degree(q, x)
    if d0 == 0 and d1 == 0:
        return [p, q]
    if d1 > d0:
        d0, d1 = (d1, d0)
        p, q = (q, p)
    if d0 > 0 and d1 == 0:
        return [p, q]
    flag = 0
    if LC(p, x) < 0:
        flag = 1
        p = -p
        q = -q
    a0, a1 = (p, q)
    euclid_seq = [a0, a1]
    a2 = rem(a0, a1, domain=QQ)
    d2 = degree(a2, x)
    euclid_seq.append(a2)
    while d2 > 0:
        a0, a1, d0, d1 = (a1, a2, d1, d2)
        a2 = rem(a0, a1, domain=QQ)
        d2 = degree(a2, x)
        euclid_seq.append(a2)
    if flag:
        euclid_seq = [-i for i in euclid_seq]
    m = len(euclid_seq)
    if euclid_seq[m - 1] == nan or euclid_seq[m - 1] == 0:
        euclid_seq.pop(m - 1)
    return euclid_seq

def euclid_amv(f, g, x):
    if f == 0 or g == 0:
        return [f, g]
    d0 = degree(f, x)
    d1 = degree(g, x)
    if d0 == 0 and d1 == 0:
        return [f, g]
    if d1 > d0:
        d0, d1 = (d1, d0)
        f, g = (g, f)
    if d0 > 0 and d1 == 0:
        return [f, g]
    a0 = f
    a1 = g
    euclid_seq = [a0, a1]
    deg_dif_p1, c = (degree(a0, x) - degree(a1, x) + 1, -1)
    i = 1
    a2 = rem_z(a0, a1, x) / Abs((-1) ** deg_dif_p1)
    euclid_seq.append(a2)
    d2 = degree(a2, x)
    while d2 >= 1:
        a0, a1, d0, d1 = (a1, a2, d1, d2)
        i += 1
        sigma0 = -LC(a0)
        c = sigma0 ** (deg_dif_p1 - 1) / c ** (deg_dif_p1 - 2)
        deg_dif_p1 = degree(a0, x) - d2 + 1
        a2 = rem_z(a0, a1, x) / Abs(c ** (deg_dif_p1 - 1) * sigma0)
        euclid_seq.append(a2)
        d2 = degree(a2, x)
    m = len(euclid_seq)
    if euclid_seq[m - 1] == nan or euclid_seq[m - 1] == 0:
        euclid_seq.pop(m - 1)
    return euclid_seq

def modified_subresultants_pg(p, q, x):
    if p == 0 or q == 0:
        return [p, q]
    d0 = degree(p, x)
    d1 = degree(q, x)
    if d0 == 0 and d1 == 0:
        return [p, q]
    if d1 > d0:
        d0, d1 = (d1, d0)
        p, q = (q, p)
    if d0 > 0 and d1 == 0:
        return [p, q]
    k = var('k')
    u_list = []
    subres_l = [p, q]
    a0, a1 = (p, q)
    del0 = d0 - d1
    degdif = del0
    rho_1 = LC(a0)
    rho_list_minus_1 = sign(LC(a0, x))
    rho1 = LC(a1, x)
    rho_list = [sign(rho1)]
    p_list = [del0]
    u = summation(k, (k, 1, p_list[0]))
    u_list.append(u)
    v = sum(p_list)
    exp_deg = d1 - 1
    a2 = -rem(a0, a1, domain=QQ)
    rho2 = LC(a2, x)
    d2 = degree(a2, x)
    deg_diff_new = exp_deg - d2
    del1 = d1 - d2
    mul_fac_old = rho1 ** (del0 + del1 - deg_diff_new)
    p_list.append(1 + deg_diff_new)
    num = 1
    for u in u_list:
        num *= (-1) ** u
    num = num * (-1) ** v
    if deg_diff_new == 0:
        den = 1
        for k in range(len(rho_list)):
            den *= rho_list[k] ** (p_list[k] + p_list[k + 1])
        den = den * rho_list_minus_1
    else:
        den = 1
        for k in range(len(rho_list) - 1):
            den *= rho_list[k] ** (p_list[k] + p_list[k + 1])
        den = den * rho_list_minus_1
        expo = p_list[len(rho_list) - 1] + p_list[len(rho_list)] - deg_diff_new
        den = den * rho_list[len(rho_list) - 1] ** expo
    if sign(num / den) > 0:
        subres_l.append(simplify(rho_1 ** degdif * a2 * Abs(mul_fac_old)))
    else:
        subres_l.append(-simplify(rho_1 ** degdif * a2 * Abs(mul_fac_old)))
    k = var('k')
    rho_list.append(sign(rho2))
    u = summation(k, (k, 1, p_list[len(p_list) - 1]))
    u_list.append(u)
    v = sum(p_list)
    deg_diff_old = deg_diff_new
    while d2 > 0:
        a0, a1, d0, d1 = (a1, a2, d1, d2)
        del0 = del1
        exp_deg = d1 - 1
        a2 = -rem(a0, a1, domain=QQ)
        rho3 = LC(a2, x)
        d2 = degree(a2, x)
        deg_diff_new = exp_deg - d2
        del1 = d1 - d2
        expo_old = deg_diff_old
        expo_new = del0 + del1 - deg_diff_new
        mul_fac_new = rho2 ** expo_new * rho1 ** expo_old * mul_fac_old
        deg_diff_old, mul_fac_old = (deg_diff_new, mul_fac_new)
        rho1, rho2 = (rho2, rho3)
        p_list.append(1 + deg_diff_new)
        num = 1
        for u in u_list:
            num *= (-1) ** u
        num = num * (-1) ** v
        if deg_diff_new == 0:
            den = 1
            for k in range(len(rho_list)):
                den *= rho_list[k] ** (p_list[k] + p_list[k + 1])
            den = den * rho_list_minus_1
        else:
            den = 1
            for k in range(len(rho_list) - 1):
                den *= rho_list[k] ** (p_list[k] + p_list[k + 1])
            den = den * rho_list_minus_1
            expo = p_list[len(rho_list) - 1] + p_list[len(rho_list)] - deg_diff_new
            den = den * rho_list[len(rho_list) - 1] ** expo
        if sign(num / den) > 0:
            subres_l.append(simplify(rho_1 ** degdif * a2 * Abs(mul_fac_old)))
        else:
            subres_l.append(-simplify(rho_1 ** degdif * a2 * Abs(mul_fac_old)))
        k = var('k')
        rho_list.append(sign(rho2))
        u = summation(k, (k, 1, p_list[len(p_list) - 1]))
        u_list.append(u)
        v = sum(p_list)
    m = len(subres_l)
    if subres_l[m - 1] == nan or subres_l[m - 1] == 0:
        subres_l.pop(m - 1)
    m = len(subres_l)
    if LC(p) < 0:
        aux_seq = [subres_l[0], subres_l[1]]
        for i in range(2, m):
            aux_seq.append(simplify(subres_l[i] * -1))
        subres_l = aux_seq
    return subres_l

def subresultants_pg(p, q, x):
    lst = modified_subresultants_pg(p, q, x)
    if lst == [] or len(lst) == 2:
        return lst
    lcf = LC(lst[0]) ** (degree(lst[0], x) - degree(lst[1], x))
    subr_seq = [lst[0], lst[1]]
    deg_seq = [degree(Poly(poly, x), x) for poly in lst]
    deg = deg_seq[0]
    deg_seq_s = deg_seq[1:-1]
    m_seq = [m - 1 for m in deg_seq_s]
    j_seq = [deg - m for m in m_seq]
    fact = [(-1) ** (j * (j - 1) / S(2)) for j in j_seq]
    lst_s = lst[2:]
    m = len(fact)
    for k in range(m):
        if sign(fact[k]) == -1:
            subr_seq.append(-lst_s[k] / lcf)
        else:
            subr_seq.append(lst_s[k] / lcf)
    return subr_seq

def subresultants_amv_q(p, q, x):
    if p == 0 or q == 0:
        return [p, q]
    d0 = degree(p, x)
    d1 = degree(q, x)
    if d0 == 0 and d1 == 0:
        return [p, q]
    if d1 > d0:
        d0, d1 = (d1, d0)
        p, q = (q, p)
    if d0 > 0 and d1 == 0:
        return [p, q]
    i, s = (0, 0)
    p_odd_index_sum = 0
    subres_l = [p, q]
    a0, a1 = (p, q)
    sigma1 = LC(a1, x)
    p0 = d0 - d1
    if p0 % 2 == 1:
        s += 1
    phi = floor((s + 1) / 2)
    mul_fac = 1
    d2 = d1
    while d2 > 0:
        i += 1
        a2 = rem(a0, a1, domain=QQ)
        if i == 1:
            sigma2 = LC(a2, x)
        else:
            sigma3 = LC(a2, x)
            sigma1, sigma2 = (sigma2, sigma3)
        d2 = degree(a2, x)
        p1 = d1 - d2
        psi = i + phi + p_odd_index_sum
        mul_fac = sigma1 ** (p0 + 1) * mul_fac
        num = (-1) ** psi
        den = sign(mul_fac)
        if sign(num / den) > 0:
            subres_l.append(simplify(expand(a2 * Abs(mul_fac))))
        else:
            subres_l.append(-simplify(expand(a2 * Abs(mul_fac))))
        if p1 - 1 > 0:
            mul_fac = mul_fac * sigma1 ** (p1 - 1)
        a0, a1, d0, d1 = (a1, a2, d1, d2)
        p0 = p1
        if p0 % 2 == 1:
            s += 1
        phi = floor((s + 1) / 2)
        if i % 2 == 1:
            p_odd_index_sum += p0
    m = len(subres_l)
    if subres_l[m - 1] == nan or subres_l[m - 1] == 0:
        subres_l.pop(m - 1)
    return subres_l

def compute_sign(base, expo):
    sb = sign(base)
    if sb == 1:
        return 1
    pe = expo % 2
    if pe == 0:
        return -sb
    else:
        return sb

def rem_z(p, q, x):
    if p.as_poly().is_univariate and q.as_poly().is_univariate and (p.as_poly().gens == q.as_poly().gens):
        delta = degree(p, x) - degree(q, x) + 1
        return rem(Abs(LC(q, x)) ** delta * p, q, x)
    else:
        return prem(p, q, x)

def quo_z(p, q, x):
    if p.as_poly().is_univariate and q.as_poly().is_univariate and (p.as_poly().gens == q.as_poly().gens):
        delta = degree(p, x) - degree(q, x) + 1
        return quo(Abs(LC(q, x)) ** delta * p, q, x)
    else:
        return pquo(p, q, x)

def subresultants_amv(f, g, x):
    if f == 0 or g == 0:
        return [f, g]
    d0 = degree(f, x)
    d1 = degree(g, x)
    if d0 == 0 and d1 == 0:
        return [f, g]
    if d1 > d0:
        d0, d1 = (d1, d0)
        f, g = (g, f)
    if d0 > 0 and d1 == 0:
        return [f, g]
    a0 = f
    a1 = g
    subres_l = [a0, a1]
    deg_dif_p1, c = (degree(a0, x) - degree(a1, x) + 1, -1)
    sigma1 = LC(a1, x)
    i, s = (0, 0)
    p_odd_index_sum = 0
    p0 = deg_dif_p1 - 1
    if p0 % 2 == 1:
        s += 1
    phi = floor((s + 1) / 2)
    i += 1
    a2 = rem_z(a0, a1, x) / Abs((-1) ** deg_dif_p1)
    sigma2 = LC(a2, x)
    d2 = degree(a2, x)
    p1 = d1 - d2
    sgn_den = compute_sign(sigma1, p0 + 1)
    psi = i + phi + p_odd_index_sum
    num = (-1) ** psi
    den = sgn_den
    if sign(num / den) > 0:
        subres_l.append(a2)
    else:
        subres_l.append(-a2)
    if p1 % 2 == 1:
        s += 1
    if p1 - 1 > 0:
        sgn_den = sgn_den * compute_sign(sigma1, p1 - 1)
    while d2 >= 1:
        phi = floor((s + 1) / 2)
        if i % 2 == 1:
            p_odd_index_sum += p1
        a0, a1, d0, d1 = (a1, a2, d1, d2)
        p0 = p1
        i += 1
        sigma0 = -LC(a0)
        c = sigma0 ** (deg_dif_p1 - 1) / c ** (deg_dif_p1 - 2)
        deg_dif_p1 = degree(a0, x) - d2 + 1
        a2 = rem_z(a0, a1, x) / Abs(c ** (deg_dif_p1 - 1) * sigma0)
        sigma3 = LC(a2, x)
        d2 = degree(a2, x)
        p1 = d1 - d2
        psi = i + phi + p_odd_index_sum
        sigma1, sigma2 = (sigma2, sigma3)
        sgn_den = compute_sign(sigma1, p0 + 1) * sgn_den
        num = (-1) ** psi
        den = sgn_den
        if sign(num / den) > 0:
            subres_l.append(a2)
        else:
            subres_l.append(-a2)
        if p1 % 2 == 1:
            s += 1
        if p1 - 1 > 0:
            sgn_den = sgn_den * compute_sign(sigma1, p1 - 1)
    m = len(subres_l)
    if subres_l[m - 1] == nan or subres_l[m - 1] == 0:
        subres_l.pop(m - 1)
    return subres_l

def modified_subresultants_amv(p, q, x):
    lst = subresultants_amv(p, q, x)
    if lst == [] or len(lst) == 2:
        return lst
    lcf = LC(lst[0]) ** (degree(lst[0], x) - degree(lst[1], x))
    subr_seq = [lst[0], lst[1]]
    deg_seq = [degree(Poly(poly, x), x) for poly in lst]
    deg = deg_seq[0]
    deg_seq_s = deg_seq[1:-1]
    m_seq = [m - 1 for m in deg_seq_s]
    j_seq = [deg - m for m in m_seq]
    fact = [(-1) ** (j * (j - 1) / S(2)) for j in j_seq]
    lst_s = lst[2:]
    m = len(fact)
    for k in range(m):
        if sign(fact[k]) == -1:
            subr_seq.append(simplify(-lst_s[k] * lcf))
        else:
            subr_seq.append(simplify(lst_s[k] * lcf))
    return subr_seq

def correct_sign(deg_f, deg_g, s1, rdel, cdel):
    M = s1[:, :]
    for i in range(M.rows - deg_f - 1, M.rows - deg_f - rdel - 1, -1):
        M.row_del(i)
    for i in range(M.rows - 1, M.rows - rdel - 1, -1):
        M.row_del(i)
    for i in range(cdel):
        M.col_del(M.rows - 1)
    Md = M[:, 0:M.rows]
    return Md.det()

def subresultants_rem(p, q, x):
    if p == 0 or q == 0:
        return [p, q]
    f, g = (p, q)
    n = deg_f = degree(f, x)
    m = deg_g = degree(g, x)
    if n == 0 and m == 0:
        return [f, g]
    if n < m:
        n, m, deg_f, deg_g, f, g = (m, n, deg_g, deg_f, g, f)
    if n > 0 and m == 0:
        return [f, g]
    s1 = sylvester(f, g, x, 1)
    sr_list = [f, g]
    while deg_g > 0:
        r = rem(p, q, x)
        d = degree(r, x)
        if d < 0:
            return sr_list
        exp_deg = deg_g - 1
        sign_value = correct_sign(n, m, s1, exp_deg, exp_deg - d)
        r = simplify(r / LC(r, x) * sign_value)
        sr_list.append(r)
        deg_f, deg_g = (deg_g, d)
        p, q = (q, r)
    m = len(sr_list)
    if sr_list[m - 1] == nan or sr_list[m - 1] == 0:
        sr_list.pop(m - 1)
    return sr_list

def pivot(M, i, j):
    ma = M[:, :]
    rs = ma.rows
    cs = ma.cols
    for r in range(i + 1, rs):
        if ma[r, j] != 0:
            for c in range(j + 1, cs):
                ma[r, c] = ma[i, j] * ma[r, c] - ma[i, c] * ma[r, j]
            ma[r, j] = 0
    return ma

def rotate_r(L, k):
    ll = list(L)
    if ll == []:
        return []
    for i in range(k):
        el = ll.pop(len(ll) - 1)
        ll.insert(0, el)
    return ll if isinstance(L, list) else Matrix([ll])

def rotate_l(L, k):
    ll = list(L)
    if ll == []:
        return []
    for i in range(k):
        el = ll.pop(0)
        ll.insert(len(ll) - 1, el)
    return ll if isinstance(L, list) else Matrix([ll])

def row2poly(row, deg, x):
    k = 0
    poly = []
    leng = len(row)
    while row[k] == 0:
        k = k + 1
    for j in range(deg + 1):
        if k + j <= leng:
            poly.append(row[k + j])
    return Poly(poly, x)

def create_ma(deg_f, deg_g, row1, row2, col_num):
    if deg_g - deg_f >= 1:
        print('Reverse degrees')
        return
    m = zeros(deg_f - deg_g + 2, col_num)
    for i in range(deg_f - deg_g + 1):
        m[i, :] = rotate_r(row1, i)
    m[deg_f - deg_g + 1, :] = row2
    return m

def find_degree(M, deg_f):
    j = deg_f
    for i in range(0, M.cols):
        if M[M.rows - 1, i] == 0:
            j = j - 1
        else:
            return max(j, 0)

def final_touches(s2, r, deg_g):
    R = s2.row(r - 1)
    for i in range(s2.cols):
        if R[0, i] == 0:
            continue
        else:
            break
    mr = s2.cols - (i + deg_g + 1)
    i = 0
    while mr != 0 and r + i < s2.rows:
        s2[r + i, :] = rotate_r(R, i + 1)
        i += 1
        mr -= 1
    return s2

def subresultants_vv(p, q, x, method=0):
    if p == 0 or q == 0:
        return [p, q]
    f, g = (p, q)
    n = deg_f = degree(f, x)
    m = deg_g = degree(g, x)
    if n == 0 and m == 0:
        return [f, g]
    if n < m:
        n, m, deg_f, deg_g, f, g = (m, n, deg_g, deg_f, g, f)
    if n > 0 and m == 0:
        return [f, g]
    s1 = sylvester(f, g, x, 1)
    s2 = sylvester(f, g, x, 2)
    sr_list = [f, g]
    col_num = 2 * n
    row0 = Poly(f, x, domain=QQ).all_coeffs()
    leng0 = len(row0)
    for i in range(col_num - leng0):
        row0.append(0)
    row0 = Matrix([row0])
    row1 = Poly(g, x, domain=QQ).all_coeffs()
    leng1 = len(row1)
    for i in range(col_num - leng1):
        row1.append(0)
    row1 = Matrix([row1])
    r = 2
    if deg_f - deg_g > 1:
        r = 1
        for i in range(deg_f - deg_g - 1):
            s2[r + i, :] = rotate_r(row0, i + 1)
        r = r + deg_f - deg_g - 1
        for i in range(deg_f - deg_g):
            s2[r + i, :] = rotate_r(row1, r + i)
        r = r + deg_f - deg_g
    if deg_f - deg_g == 0:
        r = 0
    while deg_g > 0:
        M = create_ma(deg_f, deg_g, row1, row0, col_num)
        for i in range(deg_f - deg_g + 1):
            M1 = pivot(M, i, i)
            M = M1[:, :]
        d = find_degree(M, deg_f)
        if d is None:
            break
        exp_deg = deg_g - 1
        sign_value = correct_sign(n, m, s1, exp_deg, exp_deg - d)
        poly = row2poly(M[M.rows - 1, :], d, x)
        temp2 = LC(poly, x)
        poly = simplify(poly / temp2 * sign_value)
        row0 = M[0, :]
        for i in range(deg_g - d):
            s2[r + i, :] = rotate_r(row0, r + i)
        r = r + deg_g - d
        row1 = rotate_l(M[M.rows - 1, :], deg_f - d)
        row1 = row1 / temp2 * sign_value
        for i in range(deg_g - d):
            s2[r + i, :] = rotate_r(row1, r + i)
        r = r + deg_g - d
        deg_f, deg_g = (deg_g, d)
        sr_list.append(poly)
    if method != 0 and s2.rows > 2:
        s2 = final_touches(s2, r, deg_g)
        pprint(s2)
    elif method != 0 and s2.rows == 2:
        s2[1, :] = rotate_r(s2.row(1), 1)
        pprint(s2)
    return sr_list

def subresultants_vv_2(p, q, x):
    if p == 0 or q == 0:
        return [p, q]
    f, g = (p, q)
    n = deg_f = degree(f, x)
    m = deg_g = degree(g, x)
    if n == 0 and m == 0:
        return [f, g]
    if n < m:
        n, m, deg_f, deg_g, f, g = (m, n, deg_g, deg_f, g, f)
    if n > 0 and m == 0:
        return [f, g]
    s1 = sylvester(f, g, x, 1)
    sr_list = [f, g]
    col_num = 2 * n
    row0 = Poly(f, x, domain=QQ).all_coeffs()
    leng0 = len(row0)
    for i in range(col_num - leng0):
        row0.append(0)
    row0 = Matrix([row0])
    row1 = Poly(g, x, domain=QQ).all_coeffs()
    leng1 = len(row1)
    for i in range(col_num - leng1):
        row1.append(0)
    row1 = Matrix([row1])
    while deg_g > 0:
        M = create_ma(deg_f, deg_g, row1, row0, col_num)
        for i in range(deg_f - deg_g + 1):
            M1 = pivot(M, i, i)
            M = M1[:, :]
        d = find_degree(M, deg_f)
        if d is None:
            return sr_list
        exp_deg = deg_g - 1
        sign_value = correct_sign(n, m, s1, exp_deg, exp_deg - d)
        poly = row2poly(M[M.rows - 1, :], d, x)
        poly = simplify(poly / LC(poly, x) * sign_value)
        sr_list.append(poly)
        deg_f, deg_g = (deg_g, d)
        row0 = row1
        row1 = Poly(poly, x, domain=QQ).all_coeffs()
        leng1 = len(row1)
        for i in range(col_num - leng1):
            row1.append(0)
        row1 = Matrix([row1])
    return sr_list