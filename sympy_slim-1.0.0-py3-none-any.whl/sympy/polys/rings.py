from __future__ import annotations
from typing import Generic, overload, Callable, Iterable, Iterator, TYPE_CHECKING, Mapping, cast, Sequence
from operator import add, mul, lt, le, gt, ge
from functools import reduce
from types import GeneratorType
from sympy.core.cache import cacheit
from sympy.core.expr import Expr
from sympy.core.intfunc import igcd
from sympy.core.symbol import Symbol, symbols as _symbols
from sympy.core.sympify import CantSympify, sympify
from sympy.ntheory.multinomial import multinomial_coefficients
from sympy.polys.compatibility import IPolys
from sympy.polys.constructor import construct_domain
from sympy.polys.densebasic import dup, dmp, dmp_to_dict, dup_from_dict, dmp_from_dict
from sympy.polys.domains.compositedomain import CompositeDomain
from sympy.polys.domains.domain import Domain, Er, Es, Et
from sympy.polys.domains.domainelement import DomainElement
from sympy.polys.domains.polynomialring import PolynomialRing
from sympy.polys.heuristicgcd import heugcd
from sympy.polys.monomials import MonomialOps
from sympy.polys.orderings import lex, MonomialOrder
from sympy.polys.polyerrors import CoercionFailed, GeneratorsError, ExactQuotientFailed, MultivariatePolynomialError
from sympy.polys.polyoptions import Domain as DomainOpt, Order as OrderOpt, build_options
from sympy.polys.polyutils import expr_from_dict, _dict_reorder, _parallel_dict_from_expr
from sympy.printing.defaults import DefaultPrinting
from sympy.utilities import public, subsets
from sympy.utilities.iterables import is_sequence
from sympy.utilities.magic import pollute
if TYPE_CHECKING:
    from sympy.external.gmpy import MPQ
    import sys
    if sys.version_info >= (3, 13):
        from typing import TypeIs
    else:
        from typing_extensions import TypeIs
    from sympy.polys.fields import FracField
    from types import NotImplementedType
    _str = str
Mon = tuple[int, ...]
ninf = float('-inf')

@public
def ring(symbols, domain, order: MonomialOrder | str=lex):
    _ring = PolyRing(symbols, domain, order)
    return (_ring,) + _ring.gens

@public
def xring(symbols, domain, order=lex):
    _ring = PolyRing(symbols, domain, order)
    return (_ring, _ring.gens)

@public
def vring(symbols, domain, order=lex):
    _ring = PolyRing(symbols, domain, order)
    pollute([sym.name for sym in _ring.symbols], _ring.gens)
    return _ring

@public
def sring(exprs, *symbols, **options):
    single = False
    if not is_sequence(exprs):
        exprs, single = ([exprs], True)
    exprs = list(map(sympify, exprs))
    opt = build_options(symbols, options)
    reps, opt = _parallel_dict_from_expr(exprs, opt)
    if opt.domain is None:
        coeffs = sum([list(rep.values()) for rep in reps], [])
        opt.domain, coeffs_dom = construct_domain(coeffs, opt=opt)
        coeff_map = dict(zip(coeffs, coeffs_dom))
        reps = [{m: coeff_map[c] for m, c in rep.items()} for rep in reps]
    _ring = PolyRing(opt.gens, opt.domain, opt.order)
    polys = list(map(_ring.from_dict, reps))
    if single:
        return (_ring, polys[0])
    else:
        return (_ring, polys)

def _parse_symbols(symbols: str | Expr | Sequence[str] | Sequence[Expr]) -> Sequence[Expr]:
    if isinstance(symbols, str):
        return _symbols(symbols, seq=True) if symbols else ()
    elif isinstance(symbols, Expr):
        return (symbols,)
    elif is_sequence(symbols):
        if all((isinstance(s, str) for s in symbols)):
            return _symbols(symbols)
        elif all((isinstance(s, Expr) for s in symbols)):
            return cast('Sequence[Expr]', symbols)
    raise GeneratorsError('expected a string, Symbol or expression or a non-empty sequence of strings, Symbols or expressions')

class PolyRing(DefaultPrinting, IPolys[Er], Generic[Er]):
    symbols: tuple[Expr, ...]
    gens: tuple[PolyElement[Er], ...]
    ngens: int
    _gens_set: set[PolyElement]
    domain: Domain[Er]
    order: MonomialOrder
    _hash: int
    _hash_tuple: tuple
    _one: list[tuple[Mon, Er]]
    dtype: Callable[[Iterable[tuple[Mon, Er]] | dict[Mon, Er]], PolyElement[Er]]
    monomial_mul: Callable[[Mon, Mon], Mon]
    monomial_pow: Callable[[Mon, int], Mon]
    monomial_mulpow: Callable[[Mon, Mon, int], Mon]
    monomial_ldiv: Callable[[Mon, Mon], Mon]
    monomial_div: Callable[[Mon, Mon], Mon]
    monomial_lcm: Callable[[Mon, Mon], Mon]
    monomial_gcd: Callable[[Mon, Mon], Mon]
    leading_expv: Callable[[PolyElement[Er]], Mon]
    zero_monom: Mon

    @overload
    def __new__(cls, symbols: str | Expr | Sequence[str] | Sequence[Expr], domain: Domain[Er], order: str | MonomialOrder | None=lex) -> PolyRing[Er]:
        pass

    @overload
    def __new__(cls, symbols: str | Expr | Sequence[str] | Sequence[Expr], domain: PolyRing[Es], order: str | MonomialOrder | None=lex) -> PolyRing[PolyElement[Es]]:
        pass

    def __new__(cls, symbols: str | Expr | Sequence[str] | Sequence[Expr], domain: Domain[Er] | PolyRing[Es], order: str | MonomialOrder | None=lex) -> PolyRing[Er] | PolyRing[PolyElement[Es]]:
        symbols = tuple(_parse_symbols(symbols))
        ngens = len(symbols)
        domain = DomainOpt.preprocess(domain)
        morder = OrderOpt.preprocess(order)
        if isinstance(domain, CompositeDomain) and set(symbols) & set(domain.symbols):
            raise GeneratorsError("polynomial ring and it's ground domain share generators")
        obj = object.__new__(cls)
        obj._hash_tuple = (cls.__name__, symbols, ngens, domain, order)
        obj._hash = hash(obj._hash_tuple)
        obj.symbols = symbols
        obj.ngens = ngens
        obj.domain = domain
        obj.order = morder
        obj.dtype = PolyElement(obj, ()).new
        obj.zero_monom = (0,) * ngens
        obj.gens = obj._gens()
        obj._gens_set = set(obj.gens)
        obj._one = [(obj.zero_monom, domain.one)]
        obj._init_monomial_operations()
        obj._init_leading_expv_function(order)
        obj._add_generator_attributes()
        return obj

    def _init_monomial_operations(self) -> None:
        if self.ngens:
            codegen = MonomialOps(self.ngens)
            self.monomial_mul = codegen.mul()
            self.monomial_pow = codegen.pow()
            self.monomial_mulpow = codegen.mulpow()
            self.monomial_ldiv = codegen.ldiv()
            self.monomial_div = codegen.div()
            self.monomial_lcm = codegen.lcm()
            self.monomial_gcd = codegen.gcd()
        else:
            monunit = lambda a, b: ()
            self.monomial_mul = monunit
            self.monomial_pow = monunit
            self.monomial_mulpow = lambda a, b, c: ()
            self.monomial_ldiv = monunit
            self.monomial_div = monunit
            self.monomial_lcm = monunit
            self.monomial_gcd = monunit

    def _init_leading_expv_function(self, order) -> None:
        if order is lex:
            self.leading_expv = max
        else:
            self.leading_expv = lambda f: max(f, key=order)

    def _add_generator_attributes(self) -> None:
        for symbol, generator in zip(self.symbols, self.gens):
            if isinstance(symbol, Symbol):
                name = symbol.name
                if not hasattr(self, name):
                    setattr(self, name, generator)

    def __getnewargs__(self) -> tuple[tuple[Expr, ...], Domain[Er], MonomialOrder]:
        return (self.symbols, self.domain, self.order)

    def __hash__(self) -> int:
        return self._hash

    def __eq__(self, other):
        return isinstance(other, PolyRing) and self._ring_equality(other)

    def __ne__(self, other):
        return not self == other

    @overload
    def __getitem__(self, key: int) -> PolyRing[Er]:
        pass

    @overload
    def __getitem__(self, key: slice) -> PolyRing[Er] | Domain[Er]:
        pass

    def __getitem__(self, key: slice | int) -> PolyRing[Er] | Domain[Er]:
        symbols = self.symbols[key]
        if not symbols:
            return self.domain
        else:
            return self.clone(symbols=symbols)

    @property
    def zero(self) -> PolyElement[Er]:
        return self.dtype([])

    @property
    def one(self) -> PolyElement[Er]:
        return self.dtype(self._one)

    @property
    def is_univariate(self) -> bool:
        return self.ngens == 1

    @property
    def is_multivariate(self) -> bool:
        return self.ngens > 1

    @overload
    def clone(self, symbols: Expr | list[Expr] | tuple[Expr, ...] | None=None, domain: None=None, order: None=None) -> PolyRing[Er]:
        pass

    @overload
    def clone(self, symbols: Expr | list[Expr] | tuple[Expr, ...] | None=None, *, domain: Domain[Es], order: None=None) -> PolyRing[Es]:
        pass

    @overload
    def clone(self, symbols: Expr | list[Expr] | tuple[Expr, ...] | None=None, *, domain: PolyRing[Es], order: None=None) -> PolyRing[PolyElement[Es]]:
        pass

    def clone(self, symbols: Expr | list[Expr] | tuple[Expr, ...] | None=None, domain: PolyRing[Es] | Domain[Es] | None=None, order: str | MonomialOrder | None=None) -> PolyRing[Er] | PolyRing[Es] | PolyRing[PolyElement[Es]]:
        if symbols is not None and isinstance(symbols, list):
            symbols = tuple(symbols)
        return self._clone(symbols, domain, order)

    @cacheit
    def _clone(self, symbols: Expr | tuple[Expr, ...] | None, domain: PolyRing[Es] | Domain[Et] | None, order: str | MonomialOrder | None) -> PolyRing[Er] | PolyRing[Et] | PolyRing[PolyElement[Es]]:
        return PolyRing(symbols or self.symbols, domain or self.domain, order or self.order)

    def compose(self, other: PolyRing[Er]) -> PolyRing[Er]:
        if self != other:
            syms = set(self.symbols).union(set(other.symbols))
            return self.clone(symbols=list(syms))
        else:
            return self

    def to_domain(self) -> PolynomialRing[Er]:
        return PolynomialRing(self)

    def to_field(self) -> FracField[Er]:
        from sympy.polys.fields import FracField
        return FracField(self.symbols, self.domain, self.order)

    def to_ground(self: PolyRing[PolyElement[Es]]) -> PolyRing[Es]:
        if isinstance(self.domain, CompositeDomain) or hasattr(self.domain, 'domain'):
            return self.clone(domain=self.domain.domain)
        else:
            raise ValueError(f'{self.domain} is not a composite domain')

    def is_element(self, element) -> TypeIs[PolyElement[Er]]:
        return isinstance(element, PolyElement) and element.ring == self

    def domain_new(self, element, orig_domain=None) -> Er:
        return self.domain.convert(element, orig_domain)

    def ground_new(self, coeff) -> PolyElement[Er]:
        return self.term_new(self.zero_monom, coeff)

    def term_new(self, monom: Mon, coeff: int | Er) -> PolyElement[Er]:
        coeff = self.domain_new(coeff)
        poly = self.zero
        if coeff:
            poly[monom] = coeff
        return poly

    def from_dict(self, element: Mapping[Mon, int | Er | Expr] | PolyElement[Er], orig_domain: Domain[Er] | None=None) -> PolyElement[Er]:
        if not isinstance(element, dict):
            raise TypeError('Input must be a dictionary mapping monomials to coefficients')
        return self._from_dict_ground(element, orig_domain)

    def from_terms(self, element: Iterable[tuple[Mon, Er]], orig_domain: Domain[Er] | None=None) -> PolyElement[Er]:
        return self.from_dict(dict(element), orig_domain)

    def from_list(self, element: dmp[Er]) -> PolyElement[Er]:
        poly_dict = dmp_to_dict(element, self.ngens - 1, self.domain)
        return self.from_dict(poly_dict)

    def from_expr(self, expr) -> PolyElement[Er]:
        mapping = dict(zip(self.symbols, self.gens))
        try:
            poly = self._rebuild_expr(expr, mapping)
        except CoercionFailed:
            raise ValueError(f'expected an expression convertible to a polynomial in {self}, got {expr}')
        else:
            return self.ring_new(poly)

    def _rebuild_expr(self, expr, mapping) -> PolyElement[Er]:
        domain = self.domain

        def _rebuild(expr):
            generator = mapping.get(expr)
            if generator is not None:
                return generator
            elif expr.is_Add:
                return reduce(add, map(_rebuild, expr.args))
            elif expr.is_Mul:
                return reduce(mul, map(_rebuild, expr.args))
            else:
                base, exp = expr.as_base_exp()
                if exp.is_Integer and exp > 1:
                    return _rebuild(base) ** int(exp)
                else:
                    return self.ground_new(domain.convert(expr))
        return _rebuild(sympify(expr))

    def monomial_basis(self, i) -> tuple[int, ...]:
        basis = [0] * self.ngens
        basis[i] = 1
        return tuple(basis)

    def index(self, gen: PolyElement[Er] | int | str | None) -> int:
        if gen is None:
            return 0 if self.ngens else -1
        elif isinstance(gen, (int, str)):
            return self._gen_index(gen)
        elif self.is_element(gen):
            try:
                return self.gens.index(gen)
            except ValueError:
                raise ValueError(f'invalid generator: {gen}')
        else:
            raise ValueError(f'expected a polynomial generator, an integer, a string or None, got {gen}')

    def _gen_index(self, gen: int | str) -> int:
        if isinstance(gen, int):
            if 0 <= gen < self.ngens:
                return gen
            else:
                raise ValueError(f'invalid generator index: {gen}')
        else:
            try:
                return self.symbols.index(gen)
            except ValueError:
                raise ValueError(f'invalid generator: {gen}')

    def add_gens(self, symbols: Iterable[Symbol]) -> PolyRing[Er]:
        syms = set(self.symbols).union(set(symbols))
        return self.clone(symbols=list(syms))

    def drop(self, *gens: PolyElement[Er] | int | str) -> PolyRing[Er] | Domain[Er]:
        indices = set(map(self.index, gens))
        symbols = [s for i, s in enumerate(self.symbols) if i not in indices]
        if not symbols:
            return self.domain
        else:
            return self.clone(symbols=symbols)

    def drop_to_ground(self, *gens: PolyElement[Er] | int | str | None) -> PolyRing[PolyElement[Er]] | PolyRing[Er]:
        indices = set(map(self.index, gens))
        symbols = [s for i, s in enumerate(self.symbols) if i not in indices]
        gens_to_drop = [gen for i, gen in enumerate(self.gens) if i not in indices]
        if not symbols:
            return self
        else:
            return self.clone(symbols=symbols, domain=self.drop(*gens_to_drop))

    def add(self, *objs):
        result = self.zero
        for obj in objs:
            if is_sequence(obj, include=GeneratorType):
                result += self.add(*obj)
            else:
                result += obj
        return result

    def mul(self, *objs):
        result = self.one
        for obj in objs:
            if is_sequence(obj, include=GeneratorType):
                result *= self.mul(*obj)
            else:
                result *= obj
        return result

    def symmetric_poly(self, n: int) -> PolyElement[Er]:
        if n < 0 or n > self.ngens:
            raise ValueError(f'Cannot generate symmetric polynomial of order {n} for {self.gens}')
        elif not n:
            return self.one
        else:
            poly = self.zero
            for s in subsets(range(self.ngens), int(n)):
                monom = tuple((int(i in s) for i in range(self.ngens)))
                poly += self.term_new(monom, self.domain.one)
            return poly

    def ring_new(self, element) -> PolyElement[Er]:
        if isinstance(element, PolyElement):
            if self == element.ring:
                return element
            elif isinstance(self.domain, PolynomialRing) and self.domain.ring == element.ring:
                return self.ground_new(element)
            else:
                raise NotImplementedError('conversion')
        elif isinstance(element, str):
            raise NotImplementedError('parsing')
        elif isinstance(element, dict):
            return self.from_dict(element)
        elif isinstance(element, list):
            try:
                return self.from_terms(element)
            except ValueError:
                return self.from_list(element)
        elif isinstance(element, Expr):
            return self.from_expr(element)
        else:
            return self.ground_new(element)
    __call__ = ring_new

    def __getstate__(self):
        state = self.__dict__.copy()
        del state['leading_expv']
        for key in state:
            if key.startswith('monomial_'):
                del state[key]
        return state

    def _gens(self) -> tuple[PolyElement[Er], ...]:
        one = self.domain.one
        generators = []
        for i in range(self.ngens):
            expv = self.monomial_basis(i)
            poly = self.zero
            poly[expv] = one
            generators.append(poly)
        return tuple(generators)

    def _ring_equality(self, other: PolyRing[Er]) -> bool:
        return (self.symbols, self.domain, self.ngens, self.order) == (other.symbols, other.domain, other.ngens, other.order)

    def _from_dict_ground(self, element: Mapping[Mon, int | Er | Expr], orig_domain=None) -> PolyElement[Er]:
        poly = self.zero
        domain_new = self.domain_new
        for monom, coeff in element.items():
            if coeff:
                coeff = domain_new(coeff, orig_domain)
                poly[monom] = coeff
        return poly

class PolyElement(DomainElement, DefaultPrinting, CantSympify, dict[tuple[int, ...], Er], Generic[Er]):

    def __init__(self, ring: PolyRing[Er], init: dict[Mon, Er] | Iterable[tuple[Mon, Er]]):
        super().__init__(init)
        self.ring = ring

    def __getnewargs__(self):
        return (self.ring, list(self.iterterms()))
    _hash = None

    def __hash__(self) -> int:
        _hash = self._hash
        if _hash is None:
            self._hash = _hash = hash((self.ring, frozenset(self.items())))
        return _hash

    def __ne__(self, other) -> bool:
        return not self == other

    def __pos__(self) -> PolyElement[Er]:
        return self

    def __lt__(self, other) -> bool:
        return self._cmp(other, lt)

    def __le__(self, other) -> bool:
        return self._cmp(other, le)

    def __gt__(self, other) -> bool:
        return self._cmp(other, gt)

    def __ge__(self, other) -> bool:
        return self._cmp(other, ge)

    def as_expr(self, *symbols: Expr) -> Expr:
        if not symbols:
            symbols = self.ring.symbols
        elif len(symbols) != self.ring.ngens:
            raise ValueError('Wrong number of symbols, expected %s got %s' % (self.ring.ngens, len(symbols)))
        return expr_from_dict(self.as_expr_dict(), *symbols)

    @overload
    def __add__(self, other: PolyElement[Er] | Er | int, /) -> PolyElement[Er]:
        pass

    @overload
    def __add__(self, other: PolyElement[PolyElement[Er]], /) -> PolyElement[PolyElement[Er]]:
        pass

    def __add__(self, other: PolyElement[Er] | Er | int | PolyElement[PolyElement[Er]], /) -> PolyElement[Er] | PolyElement[PolyElement[Er]]:
        if self.ring.is_element(other):
            return self._add(other)
        if isinstance(other, PolyElement):
            domain = other.ring.domain
            if isinstance(domain, PolynomialRing) and domain.ring.is_element(self):
                return cast('PolyElement[PolyElement[Er]]', other)._add_ground(self)
        res = self._try_add_ground(other)
        if res is not NotImplemented:
            return res
        if isinstance(other, PolyElement):
            return other._try_add_ground(self)
        return NotImplemented

    def __radd__(self, other: Er | int) -> PolyElement[Er]:
        return self._try_add_ground(other)

    def _try_add_ground(self, other: object) -> PolyElement[Er] | NotImplementedType:
        ring = self.ring
        domain = ring.domain
        if domain.of_type(other):
            return self._add_ground(other)
        try:
            cp2 = ring.domain_new(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return self._add_ground(cp2)

    @overload
    def __sub__(self, other: PolyElement[Er] | Er | int, /) -> PolyElement[Er]:
        pass

    @overload
    def __sub__(self, other: PolyElement[PolyElement[Er]], /) -> PolyElement[PolyElement[Er]]:
        pass

    def __sub__(self, other: PolyElement[Er] | Er | int | PolyElement[PolyElement[Er]], /) -> PolyElement[Er] | PolyElement[PolyElement[Er]]:
        if self.ring.is_element(other):
            return self._sub(other)
        if isinstance(other, PolyElement):
            domain = other.ring.domain
            if isinstance(domain, PolynomialRing) and domain.ring.is_element(self):
                return cast('PolyElement[PolyElement[Er]]', other)._sub_ground(self)
        res = self._try_sub_ground(other)
        if res is not NotImplemented:
            return res
        if isinstance(other, PolyElement):
            return other._try_rsub_ground(self)
        return NotImplemented

    def __rsub__(self, other: Er | int) -> PolyElement[Er]:
        return self._try_rsub_ground(other)

    def _try_sub_ground(self, other: object) -> PolyElement[Er] | NotImplementedType:
        ring = self.ring
        domain = ring.domain
        if domain.of_type(other):
            return self._sub_ground(other)
        try:
            cp2 = ring.domain_new(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return self._sub_ground(cp2)

    def _try_rsub_ground(self, other: object) -> PolyElement[Er] | NotImplementedType:
        ring = self.ring
        domain = ring.domain
        if domain.of_type(other):
            return self._rsub_ground(other)
        try:
            cp2 = ring.domain_new(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return self._rsub_ground(cp2)

    @overload
    def __mul__(self, other: PolyElement[Er] | Er | int, /) -> PolyElement[Er]:
        pass

    @overload
    def __mul__(self, other: PolyElement[PolyElement[Er]], /) -> PolyElement[PolyElement[Er]]:
        pass

    def __mul__(self, other: PolyElement[Er] | Er | int | PolyElement[PolyElement[Er]], /) -> PolyElement[Er] | PolyElement[PolyElement[Er]]:
        if not self or not other:
            return self.ring.zero
        if self.ring.is_element(other):
            return self._mul(other)
        if isinstance(other, PolyElement):
            domain = other.ring.domain
            if isinstance(domain, PolynomialRing) and domain.ring.is_element(self):
                return cast('PolyElement[PolyElement[Er]]', other).mul_ground(self)
        res = self._try_mul_ground(other)
        if res is not NotImplemented:
            return res
        if isinstance(other, PolyElement):
            return other._try_mul_ground(self)
        return NotImplemented

    def __rmul__(self, other: Er | int) -> PolyElement[Er]:
        return self._try_mul_ground(other)

    def _try_mul_ground(self, other: object) -> PolyElement[Er] | NotImplementedType:
        ring = self.ring
        domain = ring.domain
        if domain.of_type(other):
            return self.mul_ground(other)
        try:
            cp2 = ring.domain_new(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return self.mul_ground(cp2)

    def __pow__(self, n: int) -> PolyElement[Er]:
        if not isinstance(n, int):
            raise TypeError('exponent must be an integer, got %s' % n)
        elif n < 0:
            raise ValueError('exponent must be a non-negative integer, got %s' % n)
        if not n:
            if self:
                return self.ring.one
            else:
                raise ValueError('0**0')
        return self._pow_int(n)

    def __divmod__(self, other: PolyElement[Er] | Er | int) -> tuple[PolyElement[Er], PolyElement[Er]]:
        ring = self.ring
        if not other:
            raise ZeroDivisionError('polynomial division')
        if isinstance(other, PolyElement):
            if other.ring == ring:
                return self._divmod(other)
            elif isinstance(ring.domain, PolynomialRing) and ring.domain.ring == other.ring:
                pass
            elif isinstance(other.ring.domain, PolynomialRing) and other.ring.domain.ring == ring:
                return other.__rdivmod__(self)
            else:
                return NotImplemented
        try:
            cp2 = ring.domain_new(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return self._divmod_ground(cp2)

    def __rdivmod__(self, other: Er | int) -> tuple[PolyElement[Er], PolyElement[Er]]:
        ring = self.ring
        try:
            other_poly = ring.ground_new(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return other_poly._divmod(self)

    def __mod__(self, other: PolyElement[Er] | Er | int) -> PolyElement[Er]:
        ring = self.ring
        if not other:
            raise ZeroDivisionError('polynomial division')
        if isinstance(other, PolyElement):
            if other.ring == ring:
                return self._mod(other)
            elif isinstance(ring.domain, PolynomialRing) and ring.domain.ring == other.ring:
                pass
            elif isinstance(other.ring.domain, PolynomialRing) and other.ring.domain.ring == ring:
                return other.__rmod__(self)
            else:
                return NotImplemented
        try:
            cp2 = ring.domain_new(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return self._mod_ground(cp2)

    def __rmod__(self, other: Er | int) -> PolyElement[Er]:
        ring = self.ring
        try:
            other_poly = ring.ground_new(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return other_poly._mod(self)

    def __floordiv__(self, other: PolyElement[Er] | Er | int) -> PolyElement[Er]:
        ring = self.ring
        if not other:
            raise ZeroDivisionError('polynomial division')
        elif ring.is_element(other):
            return self._floordiv(other)
        elif isinstance(other, PolyElement):
            if isinstance(ring.domain, PolynomialRing) and ring.domain.ring == other.ring:
                pass
            elif isinstance(other.ring.domain, PolynomialRing) and other.ring.domain.ring == ring:
                return other.__rtruediv__(self)
            else:
                return NotImplemented
        try:
            other = ring.domain_new(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return self._floordiv_ground(other)

    def __rfloordiv__(self, other: Er | int) -> PolyElement[Er]:
        ring = self.ring
        try:
            other_poly = ring.ground_new(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return other_poly._floordiv(self)

    def __truediv__(self, other: PolyElement[Er] | Er | int) -> PolyElement[Er]:
        ring = self.ring
        if not other:
            raise ZeroDivisionError('polynomial division')
        elif ring.is_element(other):
            return self._truediv(cast('Er', other))
        elif isinstance(other, PolyElement):
            if isinstance(ring.domain, PolynomialRing) and ring.domain.ring == other.ring:
                pass
            elif isinstance(other.ring.domain, PolynomialRing) and other.ring.domain.ring == ring:
                return other.__rtruediv__(self)
            else:
                return NotImplemented
        try:
            other = ring.domain_new(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return self._floordiv_ground(other)

    def __rtruediv__(self, other: Er | int) -> PolyElement[Er]:
        ring = self.ring
        try:
            other_poly = ring.ground_new(other)
        except CoercionFailed:
            return NotImplemented
        else:
            return other_poly._truediv(self)

    @property
    def is_generator(self) -> bool:
        return self in self.ring._gens_set

    @property
    def is_monomial(self) -> bool:
        return not self or (len(self) == 1 and self.LC == 1)

    @property
    def is_term(self) -> bool:
        return len(self) <= 1

    @property
    def is_negative(self) -> bool:
        return self.ring.domain.is_negative(self.LC)

    @property
    def is_positive(self) -> bool:
        return self.ring.domain.is_positive(self.LC)

    @property
    def is_nonnegative(self) -> bool:
        return self.ring.domain.is_nonnegative(self.LC)

    @property
    def is_nonpositive(self) -> bool:
        return self.ring.domain.is_nonpositive(self.LC)

    @property
    def is_monic(self) -> bool:
        return self.ring.domain.is_one(self.LC)

    @property
    def is_primitive(self) -> bool:
        return self.ring.domain.is_one(self.content())

    @property
    def is_linear(self) -> bool:
        return all((sum(monom) <= 1 for monom in self.itermonoms()))

    @property
    def is_quadratic(self) -> bool:
        return all((sum(monom) <= 2 for monom in self.itermonoms()))

    def _check(self) -> None:
        assert isinstance(self, PolyElement)
        assert isinstance(self.ring, PolyRing)
        dom = self.ring.domain
        assert isinstance(dom, Domain)
        for monom, coeff in self.iterterms():
            assert dom.of_type(coeff)
            assert len(monom) == self.ring.ngens
            assert all((isinstance(exp, int) and exp >= 0 for exp in monom))

    def new(self, init) -> PolyElement[Er]:
        return self.__class__(self.ring, init)

    def parent(self) -> PolynomialRing[Er]:
        return self.ring.to_domain()

    def copy(self) -> PolyElement[Er]:
        return self.new(self)

    def set_ring(self, new_ring: PolyRing[Es]) -> PolyElement[Es]:
        if self.ring == new_ring:
            return cast('PolyElement[Es]', self)
        return self._change_ring(new_ring)

    def strip_zero(self) -> None:
        for monom, coeff in self.listterms():
            if not coeff:
                del self[monom]

    def almosteq(self, other: PolyElement[Er] | Er | int, tolerance: float | None=None) -> bool:
        ring = self.ring
        if ring.is_element(other):
            if set(self.itermonoms()) != set(other.itermonoms()):
                return False
            almosteq = ring.domain.almosteq
            for monom in self.itermonoms():
                if not almosteq(self[monom], other[monom], tolerance):
                    return False
            return True
        elif len(self) > 1:
            return False
        else:
            try:
                other = ring.domain.convert(other)
            except CoercionFailed:
                return False
            else:
                return ring.domain.almosteq(self.const(), other, tolerance)

    def sort_key(self) -> tuple[int, list[tuple[Mon, Er]]]:
        return (len(self), self.terms())

    def _drop(self, gen: PolyElement[Er] | int | str) -> tuple[int, PolyRing[Er] | Domain[Er]]:
        ring = self.ring
        i = ring.index(gen)
        if ring.ngens == 1:
            return (i, ring.domain)
        else:
            new_ring = ring.drop(gen)
            return (i, new_ring)

    def _drop_multi(self, i: int) -> PolyElement[Er]:
        assert self.ring.ngens > 1
        return cast('PolyElement[Er]', self.drop(i))

    def drop(self, gen: PolyElement[Er] | int | str) -> PolyElement[Er] | Er:
        i, ring = self._drop(gen)
        if self.ring.ngens == 1:
            if self.is_ground:
                return self.coeff(1)
            else:
                raise ValueError(f'Cannot drop {gen}')
        else:
            if not isinstance(ring, PolyRing):
                raise TypeError('Ring after drop must be a PolyRing')
            poly = ring.zero
            for k, v in self.iterterms():
                if k[i] == 0:
                    K = list(k)
                    del K[i]
                    poly[tuple(K)] = v
                else:
                    raise ValueError(f'Cannot drop {gen}')
            return poly

    def drop_to_ground(self, gen: PolyElement[Er] | int | str | None) -> PolyElement[PolyElement[Er]]:
        ring = self.ring
        if ring.ngens == 1:
            raise ValueError('Cannot drop only generator to ground')
        i = ring.index(gen)
        new_syms = list(ring.symbols)
        ground_sym = new_syms[i]
        del new_syms[i]
        new_ground = PolyRing([ground_sym], ring.domain, ring.order)
        new_ring = PolyRing(new_syms, new_ground, ring.order)
        poly = new_ring.zero
        gen = new_ground.gens[0]
        for monom, coeff in self.iterterms():
            mon = monom[:i] + monom[i + 1:]
            term = (gen ** monom[i]).mul_ground(coeff)
            if mon not in poly:
                poly[mon] = term
            else:
                poly[mon] = poly[mon] + term
        return poly

    def square(self) -> PolyElement[Er]:
        return self._square()

    def degree(self, x: PolyElement[Er] | int | str | None=None) -> float:
        i = self.ring.index(x)
        if not self:
            return ninf
        elif i < 0:
            return 0
        else:
            return self._degree(i)

    def degrees(self) -> tuple[float, ...]:
        if not self:
            return (ninf,) * self.ring.ngens
        else:
            return self._degrees()

    def tail_degree(self, x: PolyElement[Er] | int | str | None=None) -> float:
        i = self.ring.index(x)
        if not self:
            return ninf
        elif i < 0:
            return 0
        else:
            return min((monom[i] for monom in self.itermonoms()))

    def tail_degrees(self) -> tuple[float, ...]:
        if not self:
            return (ninf,) * self.ring.ngens
        else:
            return tuple(map(min, list(zip(*self.itermonoms()))))

    def monic(self) -> PolyElement[Er]:
        if not self:
            return self
        else:
            return self.quo_ground(self.LC)

    @overload
    def div(self, fv: PolyElement[Er]) -> tuple[PolyElement[Er], PolyElement[Er]]:
        pass

    @overload
    def div(self, fv: Iterable[PolyElement[Er]]) -> tuple[list[PolyElement[Er]], PolyElement[Er]]:
        pass

    def div(self, fv: PolyElement[Er] | Iterable[PolyElement[Er]]) -> tuple[PolyElement[Er], PolyElement[Er]] | tuple[list[PolyElement[Er]], PolyElement[Er]]:
        ring = self.ring
        if isinstance(fv, PolyElement):
            if fv.ring != ring:
                raise ValueError('self and f must have the same ring')
            if not fv:
                raise ZeroDivisionError('polynomial division')
            if not self:
                return (ring.zero, ring.zero)
            return self._div(fv)
        else:
            fv_list = list(fv)
            if not all((f.ring == ring for f in fv_list)):
                raise ValueError('self and f must have the same ring')
            if not all(fv_list):
                raise ZeroDivisionError('polynomial division')
            if not self:
                return ([], ring.zero)
            return self._div_list(fv_list)

    def quo_ground(self, x: Er) -> PolyElement[Er]:
        domain = self.ring.domain
        if not x:
            raise ZeroDivisionError('polynomial division')
        if not self or x == domain.one:
            return self
        return self._quo_ground(x)

    def extract_ground(self, g: PolyElement[Er]) -> tuple[Er, PolyElement[Er], PolyElement[Er]]:
        f = self
        fc = f.content()
        gc = g.content()
        gcd = f.ring.domain.gcd(fc, gc)
        f = f.quo_ground(gcd)
        g = g.quo_ground(gcd)
        return (gcd, f, g)

    def quo_term(self, term: tuple[Mon, Er]) -> PolyElement[Er]:
        monom, coeff = term
        if not coeff:
            raise ZeroDivisionError('polynomial division')
        elif not self:
            return self.ring.zero
        elif monom == self.ring.zero_monom:
            return self.quo_ground(coeff)
        return self._quo_term(term)

    def _norm(self, norm_func):
        if not self:
            return self.ring.domain.zero
        else:
            ground_abs = self.ring.domain.abs
            return norm_func([ground_abs(coeff) for coeff in self.itercoeffs()])

    def max_norm(self):
        return self._norm(max)

    def l1_norm(self):
        return self._norm(sum)

    def deflate(self, *G: PolyElement[Er]) -> tuple[tuple[int, ...], list[PolyElement[Er]]]:
        ring = self.ring
        polys = [self] + list(G)
        J = [0] * ring.ngens
        for p in polys:
            for monom in p.itermonoms():
                for i, m in enumerate(monom):
                    J[i] = igcd(J[i], m)
        for i, b in enumerate(J):
            if not b:
                J[i] = 1
        J2 = tuple(J)
        if all((b == 1 for b in J2)):
            return (J2, polys)
        return (J2, self._deflate(J2, polys))

    def canonical_unit(self):
        domain = self.ring.domain
        return domain.canonical_unit(self.LC)

    def diff(self, x: int | str | PolyElement[Er]) -> PolyElement[Er]:
        ring = self.ring
        i = ring.index(x)
        return self._diff(i)

    def trunc_ground(self, p: Er) -> PolyElement[Er]:
        if self.ring.domain.is_ZZ:
            terms = []
            for monom, coeff in self.iterterms():
                coeff = coeff % p
                if coeff > p // 2:
                    coeff = coeff - p
                terms.append((monom, coeff))
        else:
            terms = [(monom, coeff % p) for monom, coeff in self.iterterms()]
        poly = self.new(terms)
        poly.strip_zero()
        return poly
    rem_ground = trunc_ground

    def lcm(self, g: PolyElement[Er]) -> PolyElement[Er]:
        f = self
        domain = f.ring.domain
        if not domain.is_Field:
            fc, f = f.primitive()
            gc, g = g.primitive()
            c = domain.lcm(fc, gc)
            h = (f * g).quo(f.gcd(g))
            return h.mul_ground(c)
        else:
            h = (f * g).quo(f.gcd(g))
            return h.monic()

    def coeff_wrt(self, x: int | str | PolyElement[Er], deg: int) -> PolyElement[Er]:
        p = self
        i = p.ring.index(x)
        terms = [(m, c) for m, c in p.iterterms() if m[i] == deg]
        if not terms:
            return p.ring.zero
        monoms, coeffs = zip(*terms)
        monoms_list = [m[:i] + (0,) + m[i + 1:] for m in monoms]
        return p.ring.from_dict(dict(zip(monoms_list, coeffs)))

    def compose(self, x, a=None):
        ring = self.ring
        poly = ring.zero
        gens_map = dict(zip(ring.gens, range(ring.ngens)))
        if a is not None:
            replacements = [(x, a)]
        elif isinstance(x, list):
            replacements = list(x)
        elif isinstance(x, dict):
            replacements = sorted(x.items(), key=lambda k: gens_map[k[0]])
        else:
            raise ValueError('expected a generator, value pair a sequence of such pairs')
        replacements = [(gens_map[x], ring.ring_new(g)) for x, g in replacements]
        return self._compose(replacements, initial_poly=poly)

    def __call__(self, *values):
        if 0 < len(values) <= self.ring.ngens:
            return self.evaluate(list(zip(self.ring.gens, values)))
        else:
            raise ValueError('expected at least 1 and at most %s values, got %s' % (self.ring.ngens, len(values)))

    @overload
    def evaluate(self, values: list[tuple[PolyElement[Er], Er | int]]) -> PolyElement[Er] | Er:
        pass

    @overload
    def evaluate(self, x: PolyElement[Er] | int | str, a: Er | int) -> PolyElement[Er] | Er:
        pass

    def evaluate(self, *args, **kwargs) -> PolyElement[Er] | Er:
        eval_dict = {}
        ring = self.ring
        if len(args) == 1 and isinstance(args[0], list) and (not kwargs):
            for gen, val in args[0]:
                idx = ring.index(gen)
                eval_dict[idx] = ring.domain.convert(val)
        elif len(args) == 2 and (not kwargs):
            x, a = args
            idx = ring.index(x)
            eval_dict[idx] = ring.domain.convert(a)
        else:
            raise ValueError('Invalid arguments for evaluate()')
        if not eval_dict:
            return self
        elif len(eval_dict) == ring.ngens:
            return self._evaluate(eval_dict)
        else:
            temp_result = self._subs(eval_dict)
            new_ring = ring.drop(*[ring.gens[i] for i in eval_dict.keys()])
            return temp_result.set_ring(new_ring)

    @overload
    def subs(self, values: list[tuple[Expr, Er | int]]) -> PolyElement[Er]:
        pass

    @overload
    def subs(self, x: PolyElement[Er] | int | str, a: Er | int) -> PolyElement[Er]:
        pass

    def subs(self, *args, **kwargs) -> PolyElement[Er]:
        subs_dict = {}
        ring = self.ring
        if len(args) == 1 and isinstance(args[0], list) and (not kwargs):
            for gen, val in args[0]:
                idx = ring.index(gen)
                subs_dict[idx] = ring.domain.convert(val)
        elif len(args) == 2 and (not kwargs):
            x, a = args
            idx = ring.index(x)
            subs_dict[idx] = ring.domain.convert(a)
        else:
            raise ValueError('Invalid arguments for subs()')
        if not subs_dict:
            return self
        elif len(subs_dict) == ring.ngens:
            result = self._evaluate(subs_dict)
            return ring.ground_new(result)
        else:
            return self._subs(subs_dict)

    def prem(self, g: PolyElement[Er], x: PolyElement[Er] | int | None=None) -> PolyElement[Er]:
        x_index = self.ring.index(x)
        return self._prem(g, x_index)

    def pdiv(self, g: PolyElement[Er], x: PolyElement[Er] | int | None=None) -> tuple[PolyElement[Er], PolyElement[Er]]:
        x_index = self.ring.index(x)
        return self._pdiv(g, x_index)

    def pquo(self, g: PolyElement[Er], x: PolyElement[Er] | int | None=None):
        x_index = self.ring.index(x)
        return self._pquo(g, x_index)

    def pexquo(self, g: PolyElement[Er], x: PolyElement[Er] | int | None=None):
        x_index = self.ring.index(x)
        return self._pexquo(g, x_index)

    def subresultants(self, g: PolyElement[Er], x: PolyElement[Er] | int | None=None):
        x_index = self.ring.index(x)
        return self._subresultants(g, x_index)

    def symmetrize(self) -> tuple[PolyElement[Er], PolyElement[Er], list[tuple[PolyElement[Er], PolyElement[Er]]]]:
        return self._symmetrize()

    def __eq__(self, other: object) -> bool:
        if not other:
            return not self
        elif self.ring.is_element(other):
            return dict.__eq__(self, other)
        elif len(self) > 1:
            return False
        else:
            return self.get(self.ring.zero_monom) == other

    def __neg__(self) -> PolyElement[Er]:
        return self.new([(monom, -coeff) for monom, coeff in self.iterterms()])

    def _add(self, p2: PolyElement[Er]) -> PolyElement[Er]:
        p = self.copy()
        get = p.get
        zero = self.ring.domain.zero
        for k, v in p2.items():
            v = get(k, zero) + v
            if v:
                p[k] = v
            else:
                del p[k]
        return p

    def _add_ground(self, cp2: Er) -> PolyElement[Er]:
        p = self.copy()
        if not cp2:
            return p
        ring = self.ring
        zm = ring.zero_monom
        v = self.get(zm, ring.domain.zero) + cp2
        if v:
            p[zm] = v
        else:
            del p[zm]
        return p

    def _sub(self, p2: PolyElement[Er]) -> PolyElement[Er]:
        p = self.copy()
        get = p.get
        zero = self.ring.domain.zero
        for k, v in p2.items():
            v = get(k, zero) - v
            if v:
                p[k] = v
            else:
                del p[k]
        return p

    def _sub_ground(self, cp2: Er) -> PolyElement[Er]:
        p = self.copy()
        if not cp2:
            return p
        ring = self.ring
        zm = ring.zero_monom
        v = self.get(zm, ring.domain.zero) - cp2
        if v:
            p[zm] = v
        else:
            del p[zm]
        return p

    def _rsub_ground(self, cp2: Er) -> PolyElement[Er]:
        return self.__neg__()._add_ground(cp2)

    def _mul(self, other: PolyElement[Er]) -> PolyElement[Er]:
        ring = self.ring
        p = ring.zero
        for exp1, v1 in self.iterterms():
            for exp2, v2 in other.iterterms():
                exp = ring.monomial_mul(exp1, exp2)
                v = v1 * v2
                p[exp] = p.get(exp, ring.domain.zero) + v
        p.strip_zero()
        return p

    def mul_ground(self, x: Er) -> PolyElement[Er]:
        if not x:
            return self.ring.zero
        terms = [(monom, coeff * x) for monom, coeff in self.iterterms()]
        return self.new(terms)

    def _pow_int(self, n: int) -> PolyElement[Er]:
        if n == 1:
            return self.copy()
        elif n == 2:
            return self.square()
        elif n == 3:
            return self * self.square()
        elif len(self) <= 5:
            return self._pow_multinomial(n)
        else:
            return self._pow_generic(n)

    def _pow_generic(self, n: int) -> PolyElement[Er]:
        p = self.ring.one
        c = self
        while True:
            if n & 1:
                p = p * c
                n -= 1
                if not n:
                    break
            c = c.square()
            n = n // 2
        return p

    def _pow_multinomial(self, n: int) -> PolyElement[Er]:
        multinomials = multinomial_coefficients(len(self), n).items()
        monomial_mulpow = self.ring.monomial_mulpow
        zero_monom = self.ring.zero_monom
        terms = self.items()
        zero = self.ring.domain.zero
        poly = self.ring.zero
        for multinomial, multinomial_coeff in multinomials:
            product_monom = zero_monom
            product_coeff = self.ring.domain_new(multinomial_coeff)
            for exp, (monom, coeff) in zip(multinomial, terms):
                if exp:
                    product_monom = monomial_mulpow(product_monom, monom, exp)
                    product_coeff *= coeff ** exp
            monom = tuple(product_monom)
            coeff = product_coeff
            coeff = poly.get(monom, zero) + coeff
            if coeff:
                poly[monom] = coeff
            elif monom in poly:
                del poly[monom]
        return poly

    def _square(self) -> PolyElement[Er]:
        ring = self.ring
        p = ring.zero
        get = p.get
        keys = list(self.keys())
        zero = ring.domain.zero
        monomial_mul = ring.monomial_mul
        for i in range(len(keys)):
            k1 = keys[i]
            pk = self[k1]
            for j in range(i):
                k2 = keys[j]
                exp = monomial_mul(k1, k2)
                p[exp] = get(exp, zero) + pk * self[k2]
        p = p.imul_num(2)
        get = p.get
        for k, v in self.items():
            k2 = monomial_mul(k, k)
            p[k2] = get(k2, zero) + v ** 2
        p.strip_zero()
        return p

    def _divmod(self, other: PolyElement[Er]) -> tuple[PolyElement[Er], PolyElement[Er]]:
        return self.div(other)

    def _divmod_ground(self, x: Er) -> tuple[PolyElement[Er], PolyElement[Er]]:
        return (self.quo_ground(x), self.rem_ground(x))

    def _floordiv(self, p2: PolyElement[Er]) -> PolyElement[Er]:
        return self.quo(p2)

    def _floordiv_ground(self, p2: Er) -> PolyElement[Er]:
        return self.quo_ground(p2)

    @overload
    def _truediv(self, p2: PolyElement[Er]) -> PolyElement[Er]:
        pass

    @overload
    def _truediv(self, p2: list[PolyElement[Er]]) -> list[PolyElement[Er]]:
        pass

    @overload
    def _truediv(self, p2: Er) -> PolyElement[Er]:
        pass

    def _truediv(self, p2):
        return self.exquo(p2)

    def _term_div(self):
        zm = self.ring.zero_monom
        domain = self.ring.domain
        domain_quo = domain.quo
        monomial_div = self.ring.monomial_div
        if domain.is_Field:

            def term_div(a_lm_a_lc, b_lm_b_lc):
                a_lm, a_lc = a_lm_a_lc
                b_lm, b_lc = b_lm_b_lc
                if b_lm == zm:
                    monom = a_lm
                else:
                    monom = monomial_div(a_lm, b_lm)
                if monom is not None:
                    return (monom, domain_quo(a_lc, b_lc))
                else:
                    return None
        else:

            def term_div(a_lm_a_lc, b_lm_b_lc):
                a_lm, a_lc = a_lm_a_lc
                b_lm, b_lc = b_lm_b_lc
                if b_lm == zm:
                    monom = a_lm
                else:
                    monom = monomial_div(a_lm, b_lm)
                if not (monom is None or a_lc % b_lc):
                    return (monom, domain_quo(a_lc, b_lc))
                else:
                    return None
        return term_div

    @overload
    def rem(self, G: PolyElement[Er]) -> PolyElement[Er]:
        pass

    @overload
    def rem(self, G: list[PolyElement[Er]]) -> list[PolyElement[Er]]:
        pass

    def rem(self, G: PolyElement[Er] | list[PolyElement[Er]]) -> PolyElement[Er] | list[PolyElement[Er]]:
        f = self
        if isinstance(G, PolyElement):
            return f._rem(G)
        else:
            if not all(G):
                raise ZeroDivisionError('polynomial division')
            return f._rem_list(G)

    @overload
    def quo(self, G: PolyElement[Er]) -> PolyElement[Er]:
        pass

    @overload
    def quo(self, G: list[PolyElement[Er]]) -> list[PolyElement[Er]]:
        pass

    def quo(self, G):
        return self.div(G)[0]

    @overload
    def exquo(self, G: list[PolyElement[Er]]) -> list[PolyElement[Er]]:
        pass

    @overload
    def exquo(self, G: PolyElement[Er]) -> PolyElement[Er]:
        pass

    def exquo(self, G: PolyElement[Er] | list[PolyElement[Er]]) -> PolyElement[Er] | list[PolyElement[Er]]:
        q, r = self.div(G)
        if not r:
            return q
        else:
            raise ExactQuotientFailed(self, G)

    def _iadd_monom(self, mc: tuple[Mon, Er]) -> PolyElement[Er]:
        if self in self.ring._gens_set:
            cpself = self.copy()
        else:
            cpself = self
        expv, coeff = mc
        c = cpself.get(expv)
        if c is None:
            cpself[expv] = coeff
        else:
            c += coeff
            if c:
                cpself[expv] = c
            else:
                del cpself[expv]
        return cpself

    def _iadd_poly_monom(self, p2: PolyElement[Er], mc: tuple[Mon, Er]) -> PolyElement[Er]:
        p1 = self
        if p1 in p1.ring._gens_set:
            p1 = p1.copy()
        m, c = mc
        get = p1.get
        zero = p1.ring.domain.zero
        monomial_mul = p1.ring.monomial_mul
        for k, v in p2.items():
            ka = monomial_mul(k, m)
            coeff = get(ka, zero) + v * c
            if coeff:
                p1[ka] = coeff
            else:
                del p1[ka]
        return p1

    def imul_num(self, c: Er | int) -> PolyElement[Er]:
        if self in self.ring._gens_set:
            return self * c
        if not c:
            self.clear()
            return self
        for exp in self:
            self[exp] *= c
        return self

    def _rem(self, g: PolyElement[Er]) -> PolyElement[Er]:
        return self._rem_list([g])

    def _rem_list(self, G: list[PolyElement[Er]]) -> PolyElement[Er]:
        ring = self.ring
        domain = ring.domain
        zero = domain.zero
        monomial_mul = ring.monomial_mul
        r = ring.zero
        term_div = self._term_div()
        ltf = self.LT
        f = self.copy()
        get = f.get
        while f:
            for g in G:
                tq = term_div(ltf, g.LT)
                if tq is not None:
                    m, c = tq
                    for mg, cg in g.iterterms():
                        m1 = monomial_mul(mg, m)
                        c1 = get(m1, zero) - c * cg
                        if not c1:
                            del f[m1]
                        else:
                            f[m1] = c1
                    ltm = f.leading_expv()
                    if ltm is not None:
                        ltf = (ltm, f[ltm])
                    break
            else:
                ltm, ltc = ltf
                if ltm in r:
                    r[ltm] += ltc
                else:
                    r[ltm] = ltc
                del f[ltm]
                ltm = f.leading_expv()
                if ltm is not None:
                    ltf = (ltm, f[ltm])
        return r

    def _mod(self, other: PolyElement[Er]) -> PolyElement[Er]:
        return self.rem(other)

    def _mod_ground(self, x: Er) -> PolyElement[Er]:
        return self.rem_ground(x)

    @property
    def is_ground(self) -> bool:
        return not self or (len(self) == 1 and self.ring.zero_monom in self)

    @property
    def is_zero(self) -> bool:
        return not self

    @property
    def is_one(self) -> bool:
        return self == self.ring.one

    @property
    def is_squarefree(self) -> bool:
        if not self.ring.ngens:
            return True
        return self.ring.dmp_sqf_p(self)

    @property
    def is_irreducible(self) -> bool:
        if not self.ring.ngens:
            return True
        return self.ring.dmp_irreducible_p(self)

    @property
    def is_cyclotomic(self) -> bool:
        if self.ring.is_univariate:
            return self.ring.dup_cyclotomic_p(self)
        else:
            raise MultivariatePolynomialError('cyclotomic polynomial')

    @property
    def LC(self) -> Er:
        return self._get_coeff(self.leading_expv())

    @property
    def LM(self) -> Mon:
        expv = self.leading_expv()
        if expv is None:
            return self.ring.zero_monom
        else:
            return expv

    @property
    def LT(self) -> tuple[Mon, Er]:
        expv = self.leading_expv()
        if expv is None:
            return (self.ring.zero_monom, self.ring.domain.zero)
        else:
            return (expv, self._get_coeff(expv))

    def clear_denoms(self) -> tuple[Er, PolyElement[Er]]:
        domain = self.ring.domain
        if not domain.is_Field or not domain.has_assoc_Ring:
            return (domain.one, self)
        ground_ring = domain.get_ring()
        common = ground_ring.one
        lcm = ground_ring.lcm
        denom = domain.denom
        for coeff in self.values():
            common = lcm(common, denom(coeff))
        poly = self.new([(monom, coeff * common) for monom, coeff in self.items()])
        return (common, poly)

    def _change_ring(self, new_ring):
        if self.ring.symbols != new_ring.symbols:
            terms = list(zip(*_dict_reorder(self, self.ring.symbols, new_ring.symbols)))
            return new_ring.from_terms(terms, self.ring.domain)
        else:
            return new_ring.from_dict(self, self.ring.domain)

    def as_expr_dict(self) -> dict[tuple[int, ...], Expr]:
        to_sympy = self.ring.domain.to_sympy
        return {monom: to_sympy(coeff) for monom, coeff in self.iterterms()}

    def _cmp(self, other: PolyElement[Er], op: Callable[[tuple[int, list[tuple[Mon, Er]]], tuple[int, list[tuple[Mon, Er]]]], bool]) -> bool:
        if self.ring.is_element(other):
            return op(self.sort_key(), other.sort_key())
        else:
            return NotImplemented

    def to_dense(self) -> dmp[Er]:
        return dmp_from_dict(self, self.ring.ngens - 1, self.ring.domain)

    def to_dup(self) -> dup[Er]:
        assert self.ring.ngens == 1
        return dup_from_dict(self, self.ring.domain)

    def to_dict(self) -> dict[Mon, Er]:
        return dict(self)

    def str(self, printer, precedence, exp_pattern, mul_symbol) -> str:
        if not self:
            return printer._print(self.ring.domain.zero)
        prec_mul = precedence['Mul']
        prec_atom = precedence['Atom']
        ring = self.ring
        symbols = ring.symbols
        ngens = ring.ngens
        zm = ring.zero_monom
        sexpvs = []
        for expv, coeff in self.terms():
            negative = ring.domain.is_negative(coeff)
            sign = ' - ' if negative else ' + '
            sexpvs.append(sign)
            if expv == zm:
                scoeff = printer._print(coeff)
                if negative and scoeff.startswith('-'):
                    scoeff = scoeff[1:]
            else:
                if negative:
                    coeff = -coeff
                if coeff != self.ring.domain.one:
                    scoeff = printer.parenthesize(coeff, prec_mul, strict=True)
                else:
                    scoeff = ''
            sexpv = []
            for i in range(ngens):
                exp = expv[i]
                if not exp:
                    continue
                symbol = printer.parenthesize(symbols[i], prec_atom, strict=True)
                if exp != 1:
                    if exp != int(exp) or exp < 0:
                        sexp = printer.parenthesize(exp, prec_atom, strict=False)
                    else:
                        sexp = exp
                    sexpv.append(exp_pattern % (symbol, sexp))
                else:
                    sexpv.append('%s' % symbol)
            if scoeff:
                sexpv = [scoeff] + sexpv
            sexpvs.append(mul_symbol.join(sexpv))
        if sexpvs[0] in [' + ', ' - ']:
            head = sexpvs.pop(0)
            if head == ' - ':
                sexpvs.insert(0, '-')
        return ''.join(sexpvs)

    def _degree(self, i: int) -> int:
        return max((monom[i] for monom in self.itermonoms()))

    def _degree_int(self, x: int | PolyElement[Er] | None=None) -> int:
        i = self.ring.index(x)
        if not self:
            return -1
        elif i < 0:
            return 0
        else:
            return self._degree(i)

    def _degrees(self) -> tuple[int, ...]:
        return tuple(map(max, list(zip(*self.itermonoms()))))

    def leading_expv(self) -> Mon | None:
        try:
            return self._leading_expv()
        except KeyError:
            return None

    def _leading_expv(self) -> Mon:
        if not self:
            raise KeyError
        else:
            return self.ring.leading_expv(self)

    def _get_coeff(self, expv) -> Er:
        return self.get(expv, self.ring.domain.zero)

    def const(self) -> Er:
        return self._get_coeff(self.ring.zero_monom)

    def coeff(self, element: PolyElement[Er] | int) -> Er:
        if element == 1:
            return self._get_coeff(self.ring.zero_monom)
        elif self.ring.is_element(element):
            terms = list(cast('PolyElement[Er]', element).iterterms())
            if len(terms) == 1:
                monom, coeff = terms[0]
                if coeff == self.ring.domain.one:
                    return self._get_coeff(monom)
        raise ValueError('expected a monomial, got %s' % element)

    def leading_monom(self) -> PolyElement[Er]:
        p = self.ring.zero
        expv = self.leading_expv()
        if expv:
            p[expv] = self.ring.domain.one
        return p

    def leading_term(self) -> PolyElement[Er]:
        p = self.ring.zero
        expv = self.leading_expv()
        if expv is not None:
            p[expv] = self[expv]
        return p

    def coeffs(self, order: _str | None=None) -> list[Er]:
        return [coeff for _, coeff in self.terms(order)]

    def monoms(self, order: _str | None=None) -> list[Mon]:
        return [monom for monom, _ in self.terms(order)]

    def terms(self, order: _str | None=None) -> list[tuple[Mon, Er]]:
        return self._sorted(list(self.items()), order)

    def _sorted(self, seq: list[tuple[Mon, Er]], order: _str | None) -> list[tuple[Mon, Er]]:
        if order is None:
            ordering = self.ring.order
        else:
            ordering = OrderOpt.preprocess(order)
        if ordering is lex:
            return sorted(seq, key=lambda monom: monom[0], reverse=True)
        else:
            return sorted(seq, key=lambda monom: ordering(monom[0]), reverse=True)

    def itercoeffs(self):
        return iter(self.values())

    def itermonoms(self):
        return iter(self.keys())

    def iterterms(self) -> Iterator[tuple[Mon, Er]]:
        return iter(self.items())

    def listcoeffs(self) -> list[Er]:
        return list(self.values())

    def listmonoms(self) -> list[Mon]:
        return list(self.keys())

    def listterms(self) -> list[tuple[Mon, Er]]:
        return list(self.items())

    def content(self) -> Er:
        domain = self.ring.domain
        cont = domain.zero
        gcd = domain.gcd
        for coeff in self.itercoeffs():
            cont = gcd(cont, coeff)
        return cont

    def primitive(self) -> tuple[Er, PolyElement[Er]]:
        cont = self.content()
        if cont == self.ring.domain.zero:
            return (cont, self)
        return (cont, self.quo_ground(cont))

    def mul_monom(self, monom: Mon) -> PolyElement[Er]:
        monomial_mul = self.ring.monomial_mul
        terms = [(monomial_mul(f_monom, monom), f_coeff) for f_monom, f_coeff in self.items()]
        return self.new(terms)

    def mul_term(self, term: tuple[Mon, Er]) -> PolyElement[Er]:
        monom, coeff = term
        if not self or not coeff:
            return self.ring.zero
        elif monom == self.ring.zero_monom:
            return self.mul_ground(coeff)
        monomial_mul = self.ring.monomial_mul
        terms = [(monomial_mul(f_monom, monom), f_coeff * coeff) for f_monom, f_coeff in self.items()]
        return self.new(terms)

    def _quo_ground(self, x: Er) -> PolyElement[Er]:
        domain = self.ring.domain
        if domain.is_Field:
            quo = domain.quo
            terms = [(monom, quo(coeff, x)) for monom, coeff in self.iterterms()]
        else:
            terms = [(monom, coeff // x) for monom, coeff in self.iterterms() if not coeff % x]
        return self.new(terms)

    def _quo_term(self, term: tuple[Mon, Er]) -> PolyElement[Er]:
        term_div = self._term_div()
        terms = [term_div(t, term) for t in self.iterterms()]
        return self.new([t for t in terms if t is not None])

    def _deflate(self, J: tuple[int, ...], polys: list[PolyElement[Er]]) -> list[PolyElement[Er]]:
        ring = self.ring
        H = []
        for p in polys:
            h = ring.zero
            for I, coeff in p.iterterms():
                N = [i // j for i, j in zip(I, J)]
                h[tuple(N)] = coeff
            H.append(h)
        return H

    def inflate(self, J: Sequence[int]) -> PolyElement[Er]:
        poly = self.ring.zero
        for I, coeff in self.iterterms():
            N = [i * j for i, j in zip(I, J)]
            poly[tuple(N)] = coeff
        return poly

    def gcd(self, other: PolyElement[Er]) -> PolyElement[Er]:
        return self.cofactors(other)[0]

    def _diff(self, i: int) -> PolyElement[Er]:
        ring = self.ring
        m = ring.monomial_basis(i)
        g = ring.zero
        for expv, coeff in self.iterterms():
            if expv[i]:
                e = ring.monomial_ldiv(expv, m)
                g[e] = ring.domain_new(coeff * expv[i])
        return g

    def cofactors(self: PolyElement[Er], other: PolyElement[Er]) -> tuple[PolyElement[Er], PolyElement[Er], PolyElement[Er]]:
        if not self and (not other):
            zero = self.ring.zero
            return (zero, zero, zero)
        elif not self:
            h, cff, cfg = self._gcd_zero(other)
            return (h, cff, cfg)
        elif not other:
            h, cfg, cff = other._gcd_zero(self)
            return (h, cff, cfg)
        elif len(self) == 1:
            h, cff, cfg = self._gcd_monom(other)
            return (h, cff, cfg)
        elif len(other) == 1:
            h, cfg, cff = other._gcd_monom(self)
            return (h, cff, cfg)
        J, (self, other) = self.deflate(other)
        h, cff, cfg = self._gcd(other)
        return (h.inflate(J), cff.inflate(J), cfg.inflate(J))

    def _gcd_zero(self, other: PolyElement[Er]) -> tuple[PolyElement[Er], PolyElement[Er], PolyElement[Er]]:
        one, zero = (self.ring.one, self.ring.zero)
        if other.is_nonnegative:
            return (other, zero, one)
        else:
            return (-other, zero, -one)

    def _gcd_monom(self, other: PolyElement[Er]) -> tuple[PolyElement[Er], PolyElement[Er], PolyElement[Er]]:
        ring = self.ring
        ground_gcd = ring.domain.gcd
        ground_quo = ring.domain.quo
        monomial_gcd = ring.monomial_gcd
        monomial_ldiv = ring.monomial_ldiv
        mf, cf = self.listterms()[0]
        _mgcd, _cgcd = (mf, cf)
        for mg, cg in other.iterterms():
            _mgcd = monomial_gcd(_mgcd, mg)
            _cgcd = ground_gcd(_cgcd, cg)
        h = self.new([(_mgcd, _cgcd)])
        cff = self.new([(monomial_ldiv(mf, _mgcd), ground_quo(cf, _cgcd))])
        cfg = self.new([(monomial_ldiv(mg, _mgcd), ground_quo(cg, _cgcd)) for mg, cg in other.iterterms()])
        return (h, cff, cfg)

    def _gcd(self, other: PolyElement[Er]) -> tuple[PolyElement[Er], PolyElement[Er], PolyElement[Er]]:
        ring = self.ring
        if ring.domain.is_QQ:
            return self._gcd_QQ(other)
        elif ring.domain.is_ZZ:
            return self._gcd_ZZ(other)
        else:
            return ring.dmp_inner_gcd(self, other)

    def _gcd_ZZ(self, other: PolyElement[Er]) -> tuple[PolyElement[Er], PolyElement[Er], PolyElement[Er]]:
        return heugcd(self, other)

    def _gcd_QQ(self, g: PolyElement[Er]) -> tuple[PolyElement[Er], PolyElement[Er], PolyElement[Er]]:
        f = self
        ring = f.ring
        new_ring = ring.clone(domain=ring.domain.get_ring())
        cf, f = f.clear_denoms()
        cg, g = g.clear_denoms()
        f = f.set_ring(new_ring)
        g = g.set_ring(new_ring)
        h, cff, cfg = f._gcd_ZZ(g)
        h = h.set_ring(ring)
        c, h = (h.LC, h.monic())
        cff = cff.set_ring(ring).mul_ground(ring.domain.quo(c, cf))
        cfg = cfg.set_ring(ring).mul_ground(ring.domain.quo(c, cg))
        return (h, cff, cfg)

    def cancel(self, g: PolyElement[Er]) -> tuple[PolyElement[Er], PolyElement[Er]]:
        f = self
        ring = f.ring
        if not f:
            return (f, ring.one)
        domain = ring.domain
        if not (domain.is_Field and domain.has_assoc_Ring):
            _, p, q = f.cofactors(g)
        else:
            new_ring = ring.clone(domain=domain.get_ring())
            cq, f = f.clear_denoms()
            cp, g = g.clear_denoms()
            f = f.set_ring(new_ring)
            g = g.set_ring(new_ring)
            _, p, q = f.cofactors(g)
            _, cp, cq = new_ring.domain.cofactors(cp, cq)
            p = p.set_ring(ring)
            q = q.set_ring(ring)
            p = p.mul_ground(cp)
            q = q.mul_ground(cq)
        u = q.canonical_unit()
        if u == domain.one:
            pass
        elif u == -domain.one:
            p, q = (-p, -q)
        else:
            p = p.mul_ground(u)
            q = q.mul_ground(u)
        return (p, q)

    def _compose(self, replacements, initial_poly):
        ring = self.ring
        poly = initial_poly
        for monom, coeff in self.iterterms():
            monom = list(monom)
            subpoly = ring.one
            for i, g in replacements:
                n, monom[i] = (monom[i], 0)
                if n:
                    subpoly *= g ** n
            subpoly = subpoly.mul_term((tuple(monom), coeff))
            poly += subpoly
        return poly

    def _div(self, fv: PolyElement[Er]) -> tuple[PolyElement[Er], PolyElement[Er]]:
        [q], r = self._div_list([fv])
        return (q, r)

    def _div_list(self, fv: list[PolyElement[Er]]) -> tuple[list[PolyElement[Er]], PolyElement[Er]]:
        ring = self.ring
        s = len(fv)
        qv = [ring.zero for i in range(s)]
        p = self.copy()
        r = ring.zero
        term_div = self._term_div()
        expvs = [fx._leading_expv() for fx in fv]
        while p:
            i = 0
            divoccurred = 0
            while i < s and divoccurred == 0:
                expv = p._leading_expv()
                term = term_div((expv, p[expv]), (expvs[i], fv[i][expvs[i]]))
                if term is not None:
                    expv1, c = term
                    qv[i] = qv[i]._iadd_monom((expv1, c))
                    p = p._iadd_poly_monom(fv[i], (expv1, -c))
                    divoccurred = 1
                else:
                    i += 1
            if not divoccurred:
                expv = p._leading_expv()
                r = r._iadd_monom((expv, p[expv]))
                del p[expv]
        if expv == ring.zero_monom:
            r += p
        return (qv, r)

    def _prem(self, g: PolyElement[Er], x: int) -> PolyElement[Er]:
        f = self
        df = f._degree_int(x)
        dg = g._degree_int(x)
        if dg < 0:
            raise ZeroDivisionError('polynomial division')
        r, dr = (f, df)
        if df < dg:
            return r
        N = df - dg + 1
        lc_g = g.coeff_wrt(x, dg)
        xp = f.ring.gens[x]
        while True:
            lc_r = r.coeff_wrt(x, dr)
            j, N = (dr - dg, N - 1)
            R = r * lc_g
            G = g * lc_r * xp ** j
            r = R - G
            dr = r._degree_int(x)
            if dr < dg:
                break
        c = lc_g ** N
        return r * c

    def _pdiv(self, g: PolyElement[Er], x: int) -> tuple[PolyElement[Er], PolyElement[Er]]:
        f = self
        df = f._degree_int(x)
        dg = g._degree_int(x)
        if dg < 0:
            raise ZeroDivisionError('polynomial division')
        q, r, dr = (self.ring(x), f, df)
        if df < dg:
            return (q, r)
        N = df - dg + 1
        lc_g = g.coeff_wrt(x, dg)
        xp = f.ring.gens[x]
        while True:
            lc_r = r.coeff_wrt(x, dr)
            j, N = (dr - dg, N - 1)
            Q = q * lc_g
            q = Q + lc_r * xp ** j
            R = r * lc_g
            G = g * lc_r * xp ** j
            r = R - G
            dr = r._degree_int(x)
            if dr < dg:
                break
        c = lc_g ** N
        q = q * c
        r = r * c
        return (q, r)

    def _pquo(self, g: PolyElement[Er], x: int) -> PolyElement[Er]:
        f = self
        return f.pdiv(g, x)[0]

    def _pexquo(self, g: PolyElement[Er], x: int):
        f = self
        q, r = f.pdiv(g, x)
        if r.is_zero:
            return q
        else:
            raise ExactQuotientFailed(f, g)

    def _subresultants(self, g: PolyElement[Er], x: int):
        f = self
        n = f._degree_int(x)
        m = g._degree_int(x)
        if n < m:
            f, g = (g, f)
            n, m = (m, n)
        if f == 0:
            return [0, 0]
        if g == 0:
            return [f, 1]
        R = [f, g]
        d = n - m
        b = (-1) ** (d + 1)
        h = f.prem(g, x)
        h = h * b
        lc = g.coeff_wrt(x, m)
        c = lc ** d
        S = [1, c]
        c = -c
        while h:
            k = h.degree(x)
            R.append(h)
            f, g, m, d = (g, h, k, m - k)
            b = -lc * c ** d
            h = f.prem(g, x)
            h = h.exquo(b)
            lc = g.coeff_wrt(x, k)
            if d > 1:
                p = (-lc) ** d
                q = c ** (d - 1)
                c = p.exquo(q)
            else:
                c = -lc
            S.append(-c)
        return R

    def _subs(self, subs_dict: Mapping[int, Er]) -> PolyElement[Er]:
        ring = self.ring
        result_poly = ring.zero
        for monom, coeff in self.iterterms():
            new_coeff = coeff
            new_monom_list = list(monom)
            for i, val in subs_dict.items():
                exp = monom[i]
                if exp > 0:
                    new_coeff *= val ** exp
                new_monom_list[i] = 0
            if new_coeff:
                new_monom = tuple(new_monom_list)
                if new_monom in result_poly:
                    result_poly[new_monom] += new_coeff
                    if not result_poly[new_monom]:
                        del result_poly[new_monom]
                else:
                    result_poly[new_monom] = new_coeff
        return result_poly

    def _evaluate(self, eval_dict: Mapping[int, Er]) -> Er:
        result = self.ring.domain.zero
        for monom, coeff in self.iterterms():
            monom_value = self.ring.domain.one
            for i, exp in enumerate(monom):
                if exp > 0:
                    monom_value *= eval_dict[i] ** exp
            result += coeff * monom_value
        return result

    def _symmetrize(self) -> tuple[PolyElement[Er], PolyElement[Er], list[tuple[PolyElement[Er], PolyElement[Er]]]]:
        f = self.copy()
        ring = f.ring
        n = ring.ngens
        if not n:
            return (f, ring.zero, [])
        polys = [ring.symmetric_poly(i + 1) for i in range(n)]
        poly_powers = {}

        def get_poly_power(i, n):
            if (i, n) not in poly_powers:
                poly_powers[i, n] = polys[i] ** n
            return poly_powers[i, n]
        indices = list(range(n - 1))
        weights = list(range(n, 0, -1))
        symmetric = ring.zero
        while f:
            _height, _monom, _coeff = (-1, None, None)
            for i, (monom, coeff) in enumerate(f.terms()):
                if all((monom[i] >= monom[i + 1] for i in indices)):
                    height = max((n * m for n, m in zip(weights, monom)))
                    if height > _height:
                        _height, _monom, _coeff = (height, monom, coeff)
            if _height != -1:
                monom, coeff = (cast('Mon', _monom), cast('Er', _coeff))
            else:
                break
            exponents = []
            for m1, m2 in zip(monom, monom[1:] + (0,)):
                exponents.append(m1 - m2)
            symmetric += ring.term_new(tuple(exponents), coeff)
            product = coeff
            for i, n in enumerate(exponents):
                product *= get_poly_power(i, n)
            f -= product
        mapping = list(zip(ring.gens, polys))
        return (symmetric, f, mapping)

    def half_gcdex(self, other: PolyElement[Er]) -> tuple[PolyElement[Er], PolyElement[Er]]:
        return self.ring.dmp_half_gcdex(self, other)

    def gcdex(self, other: PolyElement[Er]) -> tuple[PolyElement[Er], PolyElement[Er], PolyElement[Er]]:
        return self.ring.dmp_gcdex(self, other)

    def resultant(self, other: PolyElement[Er]) -> PolyElement[Er] | Er:
        return self.ring.dmp_resultant(self, other)

    def discriminant(self) -> PolyElement[Er] | Er:
        return self.ring.dmp_discriminant(self)

    def decompose(self) -> list[PolyElement[Er]]:
        if self.ring.is_univariate:
            return self.ring.dup_decompose(self)
        else:
            raise MultivariatePolynomialError('polynomial decomposition')

    def shift(self, a: Er) -> PolyElement[Er]:
        if self.ring.is_univariate:
            return self.ring.dup_shift(self, a)
        else:
            raise MultivariatePolynomialError('shift: use shift_list instead')

    def shift_list(self, a: list[Er]) -> PolyElement[Er]:
        return self.ring.dmp_shift(self, a)

    def sturm(self) -> list[PolyElement[Er]]:
        if self.ring.is_univariate:
            return self.ring.dup_sturm(self)
        else:
            raise MultivariatePolynomialError('sturm sequence')

    def gff_list(self) -> list[tuple[PolyElement[Er], int]]:
        return self.ring.dmp_gff_list(self)

    def norm(self) -> PolyElement[MPQ]:
        return self.ring.dmp_norm(self)

    def sqf_norm(self) -> tuple[list[int], PolyElement[Er], PolyElement[MPQ]]:
        return self.ring.dmp_sqf_norm(self)

    def sqf_part(self) -> PolyElement[Er]:
        return self.ring.dmp_sqf_part(self)

    def sqf_list(self, all: bool=False) -> tuple[Er, list[tuple[PolyElement[Er], int]]]:
        return self.ring.dmp_sqf_list(self, all=all)

    def factor_list(self) -> tuple[Er, list[tuple[PolyElement[Er], int]]]:
        return self.ring.dmp_factor_list(self)