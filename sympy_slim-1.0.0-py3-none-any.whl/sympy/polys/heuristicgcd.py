from __future__ import annotations
from .polyerrors import HeuristicGCDFailed
HEU_GCD_MAX = 6

def heugcd(f, g):
    assert f.ring == g.ring and f.ring.domain.is_ZZ
    ring = f.ring
    x0 = ring.gens[0]
    domain = ring.domain
    gcd, f, g = f.extract_ground(g)
    f_norm = f.max_norm()
    g_norm = g.max_norm()
    B = domain(2 * min(f_norm, g_norm) + 29)
    x = max(min(B, 99 * domain.sqrt(B)), 2 * min(f_norm // abs(f.LC), g_norm // abs(g.LC)) + 4)
    for i in range(0, HEU_GCD_MAX):
        ff = f.evaluate(x0, x)
        gg = g.evaluate(x0, x)
        if ff and gg:
            if ring.ngens == 1:
                h, cff, cfg = domain.cofactors(ff, gg)
            else:
                h, cff, cfg = heugcd(ff, gg)
            h = _gcd_interpolate(h, x, ring)
            h = h.primitive()[1]
            cff_, r = f.div(h)
            if not r:
                cfg_, r = g.div(h)
                if not r:
                    h = h.mul_ground(gcd)
                    return (h, cff_, cfg_)
            cff = _gcd_interpolate(cff, x, ring)
            h, r = f.div(cff)
            if not r:
                cfg_, r = g.div(h)
                if not r:
                    h = h.mul_ground(gcd)
                    return (h, cff, cfg_)
            cfg = _gcd_interpolate(cfg, x, ring)
            h, r = g.div(cfg)
            if not r:
                cff_, r = f.div(h)
                if not r:
                    h = h.mul_ground(gcd)
                    return (h, cff_, cfg)
        x = 73794 * x * domain.sqrt(domain.sqrt(x)) // 27011
    raise HeuristicGCDFailed('no luck')

def _gcd_interpolate(h, x, ring):
    f, i = (ring.zero, 0)
    if ring.ngens == 1:
        while h:
            g = h % x
            if g > x // 2:
                g -= x
            h = (h - g) // x
            if g:
                f[i,] = g
            i += 1
    else:
        while h:
            g = h.trunc_ground(x)
            h = (h - g).quo_ground(x)
            if g:
                for monom, coeff in g.iterterms():
                    f[(i,) + monom] = coeff
            i += 1
    if f.LC < 0:
        return -f
    else:
        return f