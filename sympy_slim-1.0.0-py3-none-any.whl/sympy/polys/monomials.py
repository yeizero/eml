from __future__ import annotations
from itertools import combinations_with_replacement, product
from textwrap import dedent
from sympy.core.cache import cacheit
from sympy.core import Mul, S, Tuple, sympify
from sympy.polys.polyerrors import ExactQuotientFailed
from sympy.polys.polyutils import PicklableWithSlots, dict_from_expr
from sympy.utilities import public
from sympy.utilities.iterables import is_sequence, iterable
monom = tuple[int, ...]

@public
def itermonomials(variables, max_degrees, min_degrees=None):
    if is_sequence(max_degrees):
        n = len(variables)
        if len(max_degrees) != n:
            raise ValueError('Argument sizes do not match')
        if min_degrees is None:
            min_degrees = [0] * n
        elif not is_sequence(min_degrees):
            raise ValueError('min_degrees is not a list')
        else:
            if len(min_degrees) != n:
                raise ValueError('Argument sizes do not match')
            if any((i < 0 for i in min_degrees)):
                raise ValueError('min_degrees cannot contain negative numbers')
        if any((min_degrees[i] > max_degrees[i] for i in range(n))):
            raise ValueError('min_degrees[i] must be <= max_degrees[i] for all i')
        power_lists = []
        for var, min_d, max_d in zip(variables, min_degrees, max_degrees):
            power_lists.append([var ** i for i in range(min_d, max_d + 1)])
        for powers in product(*power_lists):
            yield Mul(*powers)
    else:
        max_degree = max_degrees
        if max_degree < 0:
            raise ValueError('max_degrees cannot be negative')
        if min_degrees is None:
            min_degree = 0
        else:
            if min_degrees < 0:
                raise ValueError('min_degrees cannot be negative')
            min_degree = min_degrees
        if min_degree > max_degree:
            return
        if not variables or max_degree == 0:
            yield S.One
            return
        variables = list(variables) + [S.One]
        if all((variable.is_commutative for variable in variables)):
            it = combinations_with_replacement(variables, max_degree)
        else:
            it = product(variables, repeat=max_degree)
        monomials_set = set()
        d = max_degree - min_degree
        for item in it:
            count = 0
            for variable in item:
                if variable == 1:
                    count += 1
                    if d < count:
                        break
            else:
                monomials_set.add(Mul(*item))
        yield from monomials_set

def monomial_count(V, N):
    from sympy.functions.combinatorial.factorials import factorial
    return factorial(V + N) / factorial(V) / factorial(N)

def monomial_mul(A, B):
    return tuple([a + b for a, b in zip(A, B)])

def monomial_div(A: monom, B: monom) -> monom | None:
    C = monomial_ldiv(A, B)
    if all((c >= 0 for c in C)):
        return tuple(C)
    else:
        return None

def monomial_ldiv(A: monom, B: monom) -> monom:
    return tuple([a - b for a, b in zip(A, B)])

def monomial_pow(A, n):
    return tuple([a * n for a in A])

def monomial_gcd(A, B):
    return tuple([min(a, b) for a, b in zip(A, B)])

def monomial_lcm(A, B):
    return tuple([max(a, b) for a, b in zip(A, B)])

def monomial_divides(A, B):
    return all((a <= b for a, b in zip(A, B)))

def monomial_max(*monoms):
    M = list(monoms[0])
    for N in monoms[1:]:
        for i, n in enumerate(N):
            M[i] = max(M[i], n)
    return tuple(M)

def monomial_min(*monoms: monom) -> monom:
    M = list(monoms[0])
    for N in monoms[1:]:
        for i, n in enumerate(N):
            M[i] = min(M[i], n)
    return tuple(M)

def monomial_deg(M):
    return sum(M)

def term_div(a, b, domain):
    a_lm, a_lc = a
    b_lm, b_lc = b
    monom = monomial_div(a_lm, b_lm)
    if domain.is_Field:
        if monom is not None:
            return (monom, domain.quo(a_lc, b_lc))
        else:
            return None
    elif not (monom is None or a_lc % b_lc):
        return (monom, domain.quo(a_lc, b_lc))
    else:
        return None

class MonomialOps:

    @cacheit
    def __new__(cls, ngens):
        obj = super().__new__(cls)
        obj.ngens = ngens
        return obj

    def __getnewargs__(self):
        return (self.ngens,)

    def _build(self, code, name):
        ns = {}
        exec(code, ns)
        return ns[name]

    def _vars(self, name):
        return ['%s%s' % (name, i) for i in range(self.ngens)]

    @cacheit
    def mul(self):
        name = 'monomial_mul'
        template = dedent('        def %(name)s(A, B):\n            (%(A)s,) = A\n            (%(B)s,) = B\n            return (%(AB)s,)\n        ')
        A = self._vars('a')
        B = self._vars('b')
        AB = ['%s + %s' % (a, b) for a, b in zip(A, B)]
        code = template % {'name': name, 'A': ', '.join(A), 'B': ', '.join(B), 'AB': ', '.join(AB)}
        return self._build(code, name)

    @cacheit
    def pow(self):
        name = 'monomial_pow'
        template = dedent('        def %(name)s(A, k):\n            (%(A)s,) = A\n            return (%(Ak)s,)\n        ')
        A = self._vars('a')
        Ak = ['%s*k' % a for a in A]
        code = template % {'name': name, 'A': ', '.join(A), 'Ak': ', '.join(Ak)}
        return self._build(code, name)

    @cacheit
    def mulpow(self):
        name = 'monomial_mulpow'
        template = dedent('        def %(name)s(A, B, k):\n            (%(A)s,) = A\n            (%(B)s,) = B\n            return (%(ABk)s,)\n        ')
        A = self._vars('a')
        B = self._vars('b')
        ABk = ['%s + %s*k' % (a, b) for a, b in zip(A, B)]
        code = template % {'name': name, 'A': ', '.join(A), 'B': ', '.join(B), 'ABk': ', '.join(ABk)}
        return self._build(code, name)

    @cacheit
    def ldiv(self):
        name = 'monomial_ldiv'
        template = dedent('        def %(name)s(A, B):\n            (%(A)s,) = A\n            (%(B)s,) = B\n            return (%(AB)s,)\n        ')
        A = self._vars('a')
        B = self._vars('b')
        AB = ['%s - %s' % (a, b) for a, b in zip(A, B)]
        code = template % {'name': name, 'A': ', '.join(A), 'B': ', '.join(B), 'AB': ', '.join(AB)}
        return self._build(code, name)

    @cacheit
    def div(self):
        name = 'monomial_div'
        template = dedent('        def %(name)s(A, B):\n            (%(A)s,) = A\n            (%(B)s,) = B\n            %(RAB)s\n            return (%(R)s,)\n        ')
        A = self._vars('a')
        B = self._vars('b')
        RAB = ['r%(i)s = a%(i)s - b%(i)s\n    if r%(i)s < 0: return None' % {'i': i} for i in range(self.ngens)]
        R = self._vars('r')
        code = template % {'name': name, 'A': ', '.join(A), 'B': ', '.join(B), 'RAB': '\n    '.join(RAB), 'R': ', '.join(R)}
        return self._build(code, name)

    @cacheit
    def lcm(self):
        name = 'monomial_lcm'
        template = dedent('        def %(name)s(A, B):\n            (%(A)s,) = A\n            (%(B)s,) = B\n            return (%(AB)s,)\n        ')
        A = self._vars('a')
        B = self._vars('b')
        AB = ['%s if %s >= %s else %s' % (a, a, b, b) for a, b in zip(A, B)]
        code = template % {'name': name, 'A': ', '.join(A), 'B': ', '.join(B), 'AB': ', '.join(AB)}
        return self._build(code, name)

    @cacheit
    def gcd(self):
        name = 'monomial_gcd'
        template = dedent('        def %(name)s(A, B):\n            (%(A)s,) = A\n            (%(B)s,) = B\n            return (%(AB)s,)\n        ')
        A = self._vars('a')
        B = self._vars('b')
        AB = ['%s if %s <= %s else %s' % (a, a, b, b) for a, b in zip(A, B)]
        code = template % {'name': name, 'A': ', '.join(A), 'B': ', '.join(B), 'AB': ', '.join(AB)}
        return self._build(code, name)

@public
class Monomial(PicklableWithSlots):
    __slots__ = ('exponents', 'gens')

    def __init__(self, monom, gens=None):
        if not iterable(monom):
            rep, gens = dict_from_expr(sympify(monom), gens=gens)
            if len(rep) == 1 and list(rep.values())[0] == 1:
                monom = list(rep.keys())[0]
            else:
                raise ValueError('Expected a monomial got {}'.format(monom))
        self.exponents = tuple(map(int, monom))
        self.gens = gens

    def rebuild(self, exponents, gens=None):
        return self.__class__(exponents, gens or self.gens)

    def __len__(self):
        return len(self.exponents)

    def __iter__(self):
        return iter(self.exponents)

    def __getitem__(self, item):
        return self.exponents[item]

    def __hash__(self):
        return hash((self.__class__.__name__, self.exponents, self.gens))

    def __str__(self):
        if self.gens:
            return '*'.join(['%s**%s' % (gen, exp) for gen, exp in zip(self.gens, self.exponents)])
        else:
            return '%s(%s)' % (self.__class__.__name__, self.exponents)

    def as_expr(self, *gens):
        gens = gens or self.gens
        if not gens:
            raise ValueError('Cannot convert %s to an expression without generators' % self)
        return Mul(*[gen ** exp for gen, exp in zip(gens, self.exponents)])

    def __eq__(self, other):
        if isinstance(other, Monomial):
            exponents = other.exponents
        elif isinstance(other, (tuple, Tuple)):
            exponents = other
        else:
            return False
        return self.exponents == exponents

    def __ne__(self, other):
        return not self == other

    def __mul__(self, other):
        if isinstance(other, Monomial):
            exponents = other.exponents
        elif isinstance(other, (tuple, Tuple)):
            exponents = other
        else:
            raise NotImplementedError
        return self.rebuild(monomial_mul(self.exponents, exponents))

    def __truediv__(self, other):
        if isinstance(other, Monomial):
            exponents = other.exponents
        elif isinstance(other, (tuple, Tuple)):
            exponents = other
        else:
            raise NotImplementedError
        result = monomial_div(self.exponents, exponents)
        if result is not None:
            return self.rebuild(result)
        else:
            raise ExactQuotientFailed(self, Monomial(other))
    __floordiv__ = __truediv__

    def __pow__(self, other):
        n = int(other)
        if n < 0:
            raise ValueError('a non-negative integer expected, got %s' % other)
        return self.rebuild(monomial_pow(self.exponents, n))

    def gcd(self, other):
        if isinstance(other, Monomial):
            exponents = other.exponents
        elif isinstance(other, (tuple, Tuple)):
            exponents = other
        else:
            raise TypeError('an instance of Monomial class expected, got %s' % other)
        return self.rebuild(monomial_gcd(self.exponents, exponents))

    def lcm(self, other):
        if isinstance(other, Monomial):
            exponents = other.exponents
        elif isinstance(other, (tuple, Tuple)):
            exponents = other
        else:
            raise TypeError('an instance of Monomial class expected, got %s' % other)
        return self.rebuild(monomial_lcm(self.exponents, exponents))