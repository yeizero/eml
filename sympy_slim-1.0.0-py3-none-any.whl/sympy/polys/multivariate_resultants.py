from __future__ import annotations
from math import prod
from sympy.core.mul import Mul
from sympy.matrices.dense import Matrix, diag
from sympy.polys.polytools import Poly, degree_list, rem
from sympy.simplify.simplify import simplify
from sympy.tensor.indexed import IndexedBase
from sympy.polys.monomials import itermonomials, monomial_deg
from sympy.polys.orderings import monomial_key
from sympy.polys.polytools import poly_from_expr, total_degree
from sympy.functions.combinatorial.factorials import binomial
from itertools import combinations_with_replacement
from sympy.utilities.exceptions import sympy_deprecation_warning

class DixonResultant:

    def __init__(self, polynomials, variables):
        self.polynomials = polynomials
        self.variables = variables
        self.n = len(self.variables)
        self.m = len(self.polynomials)
        a = IndexedBase('alpha')
        self.dummy_variables = [a[i] for i in range(self.n)]
        self._max_degrees = [max((degree_list(poly)[i] for poly in self.polynomials)) for i in range(self.n)]

    @property
    def max_degrees(self):
        sympy_deprecation_warning('\n            The max_degrees property of DixonResultant is deprecated.\n            ', deprecated_since_version='1.5', active_deprecations_target='deprecated-dixonresultant-properties')
        return self._max_degrees

    def get_dixon_polynomial(self):
        if self.m != self.n + 1:
            raise ValueError('Method invalid for given combination.')
        rows = [self.polynomials]
        temp = list(self.variables)
        for idx in range(self.n):
            temp[idx] = self.dummy_variables[idx]
            substitution = dict(zip(self.variables, temp))
            rows.append([f.subs(substitution) for f in self.polynomials])
        A = Matrix(rows)
        terms = zip(self.variables, self.dummy_variables)
        product_of_differences = Mul(*[a - b for a, b in terms])
        dixon_polynomial = (A.det() / product_of_differences).factor()
        return poly_from_expr(dixon_polynomial, self.dummy_variables)[0]

    def get_upper_degree(self):
        sympy_deprecation_warning('\n            The get_upper_degree() method of DixonResultant is deprecated. Use\n            get_max_degrees() instead.\n            ', deprecated_since_version='1.5', active_deprecations_target='deprecated-dixonresultant-properties')
        list_of_products = [self.variables[i] ** self._max_degrees[i] for i in range(self.n)]
        product = prod(list_of_products)
        product = Poly(product).monoms()
        return monomial_deg(*product)

    def get_max_degrees(self, polynomial):
        deg_lists = [degree_list(Poly(poly, self.variables)) for poly in polynomial.coeffs()]
        max_degrees = [max(degs) for degs in zip(*deg_lists)]
        return max_degrees

    def get_dixon_matrix(self, polynomial):
        max_degrees = self.get_max_degrees(polynomial)
        monomials = itermonomials(self.variables, max_degrees)
        monomials = sorted(monomials, reverse=True, key=monomial_key('lex', self.variables))
        dixon_matrix = Matrix([[Poly(c, *self.variables).coeff_monomial(m) for m in monomials] for c in polynomial.coeffs()])
        if dixon_matrix.shape[0] != dixon_matrix.shape[1]:
            keep = [column for column in range(dixon_matrix.shape[-1]) if any((element != 0 for element in dixon_matrix[:, column]))]
            dixon_matrix = dixon_matrix[:, keep]
        return dixon_matrix

    def KSY_precondition(self, matrix):
        if matrix.is_zero_matrix:
            return False
        m, n = matrix.shape
        matrix = simplify(matrix.rref()[0])
        rows = [i for i in range(m) if any((matrix[i, j] != 0 for j in range(n)))]
        matrix = matrix[rows, :]
        condition = Matrix([[0] * (n - 1) + [1]])
        if matrix[-1, :] == condition:
            return True
        else:
            return False

    def delete_zero_rows_and_columns(self, matrix):
        rows = [i for i in range(matrix.rows) if not matrix.row(i).is_zero_matrix]
        cols = [j for j in range(matrix.cols) if not matrix.col(j).is_zero_matrix]
        return matrix[rows, cols]

    def product_leading_entries(self, matrix):
        res = 1
        for row in range(matrix.rows):
            for el in matrix.row(row):
                if el != 0:
                    res = res * el
                    break
        return res

    def get_KSY_Dixon_resultant(self, matrix):
        matrix = self.delete_zero_rows_and_columns(matrix)
        _, U, _ = matrix.LUdecomposition()
        matrix = self.delete_zero_rows_and_columns(simplify(U))
        return self.product_leading_entries(matrix)

class MacaulayResultant:

    def __init__(self, polynomials, variables):
        self.polynomials = polynomials
        self.variables = variables
        self.n = len(variables)
        self.degrees = [total_degree(poly, *self.variables) for poly in self.polynomials]
        self.degree_m = self._get_degree_m()
        self.monomials_size = self.get_size()
        self.monomial_set = self.get_monomials_of_certain_degree(self.degree_m)

    def _get_degree_m(self):
        return 1 + sum((d - 1 for d in self.degrees))

    def get_size(self):
        return binomial(self.degree_m + self.n - 1, self.n - 1)

    def get_monomials_of_certain_degree(self, degree):
        monomials = [Mul(*monomial) for monomial in combinations_with_replacement(self.variables, degree)]
        return sorted(monomials, reverse=True, key=monomial_key('lex', self.variables))

    def get_row_coefficients(self):
        row_coefficients = []
        divisible = []
        for i in range(self.n):
            if i == 0:
                degree = self.degree_m - self.degrees[i]
                monomial = self.get_monomials_of_certain_degree(degree)
                row_coefficients.append(monomial)
            else:
                divisible.append(self.variables[i - 1] ** self.degrees[i - 1])
                degree = self.degree_m - self.degrees[i]
                poss_rows = self.get_monomials_of_certain_degree(degree)
                for div in divisible:
                    for p in poss_rows:
                        if rem(p, div) == 0:
                            poss_rows = [item for item in poss_rows if item != p]
                row_coefficients.append(poss_rows)
        return row_coefficients

    def get_matrix(self):
        rows = []
        row_coefficients = self.get_row_coefficients()
        for i in range(self.n):
            for multiplier in row_coefficients[i]:
                coefficients = []
                poly = Poly(self.polynomials[i] * multiplier, *self.variables)
                for mono in self.monomial_set:
                    coefficients.append(poly.coeff_monomial(mono))
                rows.append(coefficients)
        macaulay_matrix = Matrix(rows)
        return macaulay_matrix

    def get_reduced_nonreduced(self):
        divisible = []
        for m in self.monomial_set:
            temp = []
            for i, v in enumerate(self.variables):
                temp.append(bool(total_degree(m, v) >= self.degrees[i]))
            divisible.append(temp)
        reduced = [i for i, r in enumerate(divisible) if sum(r) < self.n - 1]
        non_reduced = [i for i, r in enumerate(divisible) if sum(r) >= self.n - 1]
        return (reduced, non_reduced)

    def get_submatrix(self, matrix):
        reduced, non_reduced = self.get_reduced_nonreduced()
        if reduced == []:
            return diag([1])
        reduction_set = [v ** self.degrees[i] for i, v in enumerate(self.variables)]
        ais = [self.polynomials[i].coeff(reduction_set[i]) for i in range(self.n)]
        reduced_matrix = matrix[:, reduced]
        keep = []
        for row in range(reduced_matrix.rows):
            check = [ai in reduced_matrix[row, :] for ai in ais]
            if True not in check:
                keep.append(row)
        return matrix[keep, non_reduced]