from __future__ import annotations
from sympy.core.function import Lambda
from sympy.core.numbers import I
from sympy.core.singleton import S
from sympy.core.symbol import Dummy, Symbol
from sympy.functions.elementary.exponential import log
from sympy.functions.elementary.trigonometric import atan
from sympy.polys.polyroots import roots
from sympy.polys.polytools import cancel
from sympy.polys.rootoftools import RootSum
from sympy.polys import Poly, resultant, ZZ

def ratint(f, x, **flags):
    if isinstance(f, tuple):
        p, q = f
    else:
        p, q = f.as_numer_denom()
    p, q = (Poly(p, x, composite=False, field=True), Poly(q, x, composite=False, field=True))
    coeff, p, q = p.cancel(q)
    poly, p = p.div(q)
    result = poly.integrate(x).as_expr()
    if p.is_zero:
        return coeff * result
    g, h = ratint_ratpart(p, q, x)
    P, Q = h.as_numer_denom()
    P = Poly(P, x)
    Q = Poly(Q, x)
    q, r = P.div(Q)
    result += g + q.integrate(x).as_expr()
    if not r.is_zero:
        symbol = flags.get('symbol', 't')
        if not isinstance(symbol, Symbol):
            t = Dummy(symbol)
        else:
            t = symbol.as_dummy()
        L = ratint_logpart(r, Q, x, t)
        real = flags.get('real')
        if real is None:
            if isinstance(f, tuple):
                p, q = f
                atoms = p.atoms() | q.atoms()
            else:
                atoms = f.atoms()
            for elt in atoms - {x}:
                if not elt.is_extended_real:
                    real = False
                    break
            else:
                real = True
        eps = S.Zero
        if not real:
            for h, q in L:
                _, h = h.primitive()
                eps += RootSum(q, Lambda(t, t * log(h.as_expr())), quadratic=True)
        else:
            for h, q in L:
                _, h = h.primitive()
                R = log_to_real(h, q, x, t)
                if R is not None:
                    eps += R
                else:
                    eps += RootSum(q, Lambda(t, t * log(h.as_expr())), quadratic=True)
        result += eps
    return coeff * result

def ratint_ratpart(f, g, x):
    from sympy.solvers.solvers import solve
    f = Poly(f, x)
    g = Poly(g, x)
    u, v, _ = g.cofactors(g.diff())
    n = u.degree()
    m = v.degree()
    A_coeffs = [Dummy('a' + str(n - i)) for i in range(0, n)]
    B_coeffs = [Dummy('b' + str(m - i)) for i in range(0, m)]
    C_coeffs = A_coeffs + B_coeffs
    A = Poly(A_coeffs, x, domain=ZZ[C_coeffs])
    B = Poly(B_coeffs, x, domain=ZZ[C_coeffs])
    H = f - A.diff() * v + A * (u.diff() * v).quo(u) - B * u
    result = solve(H.coeffs(), C_coeffs)
    A = A.as_expr().subs(result)
    B = B.as_expr().subs(result)
    rat_part = cancel(A / u.as_expr(), x)
    log_part = cancel(B / v.as_expr(), x)
    return (rat_part, log_part)

def ratint_logpart(f, g, x, t=None):
    f, g = (Poly(f, x), Poly(g, x))
    t = t or Dummy('t')
    a, b = (g, f - g.diff() * Poly(t, x))
    res, R = resultant(a, b, includePRS=True)
    res = Poly(res, t, composite=False)
    assert res, 'BUG: resultant(%s, %s) cannot be zero' % (a, b)
    R_map, H = ({}, [])
    for r in R:
        R_map[r.degree()] = r

    def _include_sign(c, sqf):
        if c.is_extended_real and (c < 0) == True:
            h, k = sqf[0]
            c_poly = c.as_poly(h.gens)
            sqf[0] = (h * c_poly, k)
    C, res_sqf = res.sqf_list()
    _include_sign(C, res_sqf)
    for q, i in res_sqf:
        _, q = q.primitive()
        if g.degree() == i:
            H.append((g, q))
        else:
            h = R_map[i]
            h_lc = Poly(h.LC(), t, field=True)
            c, h_lc_sqf = h_lc.sqf_list(all=True)
            _include_sign(c, h_lc_sqf)
            for a, j in h_lc_sqf:
                h = h.quo(Poly(a.gcd(q) ** j, x))
            inv, coeffs = (h_lc.invert(q), [S.One])
            for coeff in h.coeffs()[1:]:
                coeff = coeff.as_poly(inv.gens)
                T = (inv * coeff).rem(q)
                coeffs.append(T.as_expr())
            h = Poly(dict(list(zip(h.monoms(), coeffs))), x)
            H.append((h, q))
    return H

def log_to_atan(f, g):
    if f.degree() < g.degree():
        f, g = (-g, f)
    f = f.to_field()
    g = g.to_field()
    p, q = f.div(g)
    if q.is_zero:
        return 2 * atan(p.as_expr())
    else:
        s, t, h = g.gcdex(-f)
        u = (f * s + g * t).quo(h)
        A = 2 * atan(u.as_expr())
        return A + log_to_atan(s, t)

def _roots_real_complex(poly):
    from sympy.core.sorting import ordered
    rs = roots(poly)
    if sum(rs.values()) != poly.degree():
        return None
    reals = {}
    complexes = {}
    remaining = list(rs)
    while remaining:
        r = remaining.pop()
        r_c = r.conjugate()
        if r != r_c and r_c in rs:
            assert rs[r_c] == rs[r]
            remaining.remove(r_c)
            r_re, r_im = r.as_real_imag()
            _, r_im = ordered([r_im, -r_im])
            complexes[r_re, r_im] = rs[r]
        else:
            reals[r] = rs[r]
    return (reals, complexes)

def log_to_real(h, q, x, t):
    from sympy.simplify.radsimp import collect
    rs = _roots_real_complex(q)
    if rs is None:
        return None
    reals, complexes = rs
    u = Dummy('u')
    v = Dummy('v')
    H = h.as_expr().xreplace({t: u + I * v}).expand()
    H_map = collect(H, I, evaluate=False)
    a, b = (H_map.get(S.One, S.Zero), H_map.get(I, S.Zero))
    result = S.Zero
    for r_u, r_v in complexes:
        A = Poly(a.xreplace({u: r_u, v: r_v}), x)
        B = Poly(b.xreplace({u: r_u, v: r_v}), x)
        AB = (A ** 2 + B ** 2).as_expr()
        result += r_u * log(AB) + r_v * log_to_atan(A, B)
    for r in reals:
        result += r * log(h.as_expr().subs(t, r))
    return result