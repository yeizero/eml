from __future__ import annotations
from sympy.functions import SingularityFunction, DiracDelta
from sympy.integrals import integrate

def singularityintegrate(f, x):
    if not f.has(SingularityFunction):
        return None
    if isinstance(f, SingularityFunction):
        x, a, n = f.args
        if n.is_positive or n.is_zero:
            return SingularityFunction(x, a, n + 1) / (n + 1)
        elif n in (-1, -2, -3, -4):
            return SingularityFunction(x, a, n + 1)
    if f.is_Mul or f.is_Pow:
        expr = f.rewrite(DiracDelta)
        expr = integrate(expr, x)
        return expr.rewrite(SingularityFunction)
    return None