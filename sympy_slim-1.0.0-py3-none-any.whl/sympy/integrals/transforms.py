from __future__ import annotations
from functools import reduce, wraps
from itertools import repeat
from sympy.core import S, pi
from sympy.core.add import Add
from sympy.core.function import AppliedUndef, count_ops, expand, expand_mul, Function
from sympy.core.mul import Mul
from sympy.core.intfunc import igcd, ilcm
from sympy.core.sorting import default_sort_key
from sympy.core.symbol import Dummy
from sympy.core.traversal import postorder_traversal
from sympy.functions.combinatorial.factorials import factorial, rf
from sympy.functions.elementary.complexes import re, arg, Abs
from sympy.functions.elementary.exponential import exp, exp_polar
from sympy.functions.elementary.hyperbolic import cosh, coth, sinh, tanh
from sympy.functions.elementary.integers import ceiling
from sympy.functions.elementary.miscellaneous import Max, Min, sqrt
from sympy.functions.elementary.piecewise import piecewise_fold
from sympy.functions.elementary.trigonometric import cos, cot, sin, tan
from sympy.functions.special.bessel import besselj
from sympy.functions.special.delta_functions import Heaviside
from sympy.functions.special.gamma_functions import gamma
from sympy.functions.special.hyper import meijerg
from sympy.integrals import integrate, Integral
from sympy.integrals.meijerint import _dummy
from sympy.logic.boolalg import to_cnf, conjuncts, disjuncts, Or, And
from sympy.polys.polyroots import roots
from sympy.polys.polytools import factor, Poly
from sympy.polys.rootoftools import CRootOf
from sympy.utilities.iterables import iterable
from sympy.utilities.misc import debug

class IntegralTransformError(NotImplementedError):

    def __init__(self, transform, function, msg):
        super().__init__('%s Transform could not be computed: %s.' % (transform, msg))
        self.function = function

class IntegralTransform(Function):

    @property
    def function(self):
        return self.args[0]

    @property
    def function_variable(self):
        return self.args[1]

    @property
    def transform_variable(self):
        return self.args[2]

    @property
    def free_symbols(self):
        return self.function.free_symbols.union({self.transform_variable}) - {self.function_variable}

    def _compute_transform(self, f, x, s, **hints):
        raise NotImplementedError

    def _as_integral(self, f, x, s):
        raise NotImplementedError

    def _collapse_extra(self, extra):
        cond = And(*extra)
        if cond == False:
            raise IntegralTransformError(self.__class__.name, None, '')
        return cond

    def _try_directly(self, **hints):
        T = None
        try_directly = not any((func.has(self.function_variable) for func in self.function.atoms(AppliedUndef)))
        if try_directly:
            try:
                T = self._compute_transform(self.function, self.function_variable, self.transform_variable, **hints)
            except IntegralTransformError:
                debug('[IT _try ] Caught IntegralTransformError, returns None')
                T = None
        fn = self.function
        if not fn.is_Add:
            fn = expand_mul(fn)
        return (fn, T)

    def doit(self, **hints):
        needeval = hints.pop('needeval', False)
        simplify = hints.pop('simplify', True)
        hints['simplify'] = simplify
        fn, T = self._try_directly(**hints)
        if T is not None:
            return T
        if fn.is_Add:
            hints['needeval'] = needeval
            res = [self.__class__(*[x] + list(self.args[1:])).doit(**hints) for x in fn.args]
            extra = []
            ress = []
            for x in res:
                if not isinstance(x, tuple):
                    x = [x]
                ress.append(x[0])
                if len(x) == 2:
                    extra.append(x[1])
                elif len(x) > 2:
                    extra += [x[1:]]
            if simplify == True:
                res = Add(*ress).simplify()
            else:
                res = Add(*ress)
            if not extra:
                return res
            try:
                extra = self._collapse_extra(extra)
                if iterable(extra):
                    return (res,) + tuple(extra)
                else:
                    return (res, extra)
            except IntegralTransformError:
                pass
        if needeval:
            raise IntegralTransformError(self.__class__._name, self.function, 'needeval')
        coeff, rest = fn.as_coeff_mul(self.function_variable)
        return coeff * self.__class__(*[Mul(*rest)] + list(self.args[1:]))

    @property
    def as_integral(self):
        return self._as_integral(self.function, self.function_variable, self.transform_variable)

    def _eval_rewrite_as_Integral(self, *args, **kwargs):
        return self.as_integral

def _simplify(expr, doit):
    if doit:
        from sympy.simplify import simplify
        from sympy.simplify.powsimp import powdenest
        return simplify(powdenest(piecewise_fold(expr), polar=True))
    return expr

def _noconds_(default):

    def make_wrapper(func):

        @wraps(func)
        def wrapper(*args, noconds=default, **kwargs):
            res = func(*args, **kwargs)
            if noconds:
                return res[0]
            return res
        return wrapper
    return make_wrapper
_noconds = _noconds_(False)

def _default_integrator(f, x):
    return integrate(f, (x, S.Zero, S.Infinity))

@_noconds
def _mellin_transform(f, x, s_, integrator=_default_integrator, simplify=True):
    s = _dummy('s', 'mellin-transform', f)
    F = integrator(x ** (s - 1) * f, x)
    if not F.has(Integral):
        return (_simplify(F.subs(s, s_), simplify), (S.NegativeInfinity, S.Infinity), S.true)
    if not F.is_Piecewise:
        raise IntegralTransformError('Mellin', f, 'could not compute integral')
    F, cond = F.args[0]
    if F.has(Integral):
        raise IntegralTransformError('Mellin', f, 'integral in unexpected form')

    def process_conds(cond):
        from sympy.solvers.inequalities import _solve_inequality
        a = S.NegativeInfinity
        b = S.Infinity
        aux = S.true
        conds = conjuncts(to_cnf(cond))
        t = Dummy('t', real=True)
        for c in conds:
            a_ = S.Infinity
            b_ = S.NegativeInfinity
            aux_ = []
            for d in disjuncts(c):
                d_ = d.replace(re, lambda x: x.as_real_imag()[0]).subs(re(s), t)
                if not d.is_Relational or d.rel_op in ('==', '!=') or d_.has(s) or (not d_.has(t)):
                    aux_ += [d]
                    continue
                soln = _solve_inequality(d_, t)
                if not soln.is_Relational or soln.rel_op in ('==', '!='):
                    aux_ += [d]
                    continue
                if soln.lts == t:
                    b_ = Max(soln.gts, b_)
                else:
                    a_ = Min(soln.lts, a_)
            if a_ is not S.Infinity and a_ != b:
                a = Max(a_, a)
            elif b_ is not S.NegativeInfinity and b_ != a:
                b = Min(b_, b)
            else:
                aux = And(aux, Or(*aux_))
        return (a, b, aux)
    conds = [process_conds(c) for c in disjuncts(cond)]
    conds = [x for x in conds if x[2] != False]
    conds.sort(key=lambda x: (x[0] - x[1], count_ops(x[2])))
    if not conds:
        raise IntegralTransformError('Mellin', f, 'no convergence found')
    a, b, aux = conds[0]
    return (_simplify(F.subs(s, s_), simplify), (a, b), aux)

class MellinTransform(IntegralTransform):
    _name = 'Mellin'

    def _compute_transform(self, f, x, s, **hints):
        return _mellin_transform(f, x, s, **hints)

    def _as_integral(self, f, x, s):
        return Integral(f * x ** (s - 1), (x, S.Zero, S.Infinity))

    def _collapse_extra(self, extra):
        a = []
        b = []
        cond = []
        for (sa, sb), c in extra:
            a += [sa]
            b += [sb]
            cond += [c]
        res = ((Max(*a), Min(*b)), And(*cond))
        if (res[0][0] >= res[0][1]) == True or res[1] == False:
            raise IntegralTransformError('Mellin', None, 'no combined convergence.')
        return res

def mellin_transform(f, x, s, **hints):
    return MellinTransform(f, x, s).doit(**hints)

def _rewrite_sin(m_n, s, a, b):
    m, n = m_n
    m = expand_mul(m / pi)
    n = expand_mul(n / pi)
    r = ceiling(-m * a - n.as_real_imag()[0])
    return (gamma(m * s + n + r), gamma(1 - n - r - m * s), (-1) ** r * pi)

class MellinTransformStripError(ValueError):
    pass

def _rewrite_gamma(f, s, a, b):
    a_, b_ = S([a, b])

    def left(c, is_numer):
        c = expand(re(c))
        if a_ is None and b_ is S.Infinity:
            return True
        if a_ is None:
            return c < b_
        if b_ is None:
            return c <= a_
        if (c >= b_) == True:
            return False
        if (c <= a_) == True:
            return True
        if is_numer:
            return None
        if a_.free_symbols or b_.free_symbols or c.free_symbols:
            return None
        raise MellinTransformStripError('Pole inside critical strip?')
    s_multipliers = []
    for g in f.atoms(gamma):
        if not g.has(s):
            continue
        arg = g.args[0]
        if arg.is_Add:
            arg = arg.as_independent(s)[1]
        coeff, _ = arg.as_coeff_mul(s)
        s_multipliers += [coeff]
    for g in f.atoms(sin, cos, tan, cot):
        if not g.has(s):
            continue
        arg = g.args[0]
        if arg.is_Add:
            arg = arg.as_independent(s)[1]
        coeff, _ = arg.as_coeff_mul(s)
        s_multipliers += [coeff / pi]
    s_multipliers = [Abs(x) if x.is_extended_real else x for x in s_multipliers]
    common_coefficient = S.One
    for x in s_multipliers:
        if not x.is_Rational:
            common_coefficient = x
            break
    s_multipliers = [x / common_coefficient for x in s_multipliers]
    if not (all((x.is_Rational for x in s_multipliers)) and common_coefficient.is_extended_real):
        raise IntegralTransformError('Gamma', None, 'Nonrational multiplier')
    s_multiplier = common_coefficient / reduce(ilcm, [S(x.q) for x in s_multipliers], S.One)
    if s_multiplier == common_coefficient:
        if len(s_multipliers) == 0:
            s_multiplier = common_coefficient
        else:
            s_multiplier = common_coefficient * reduce(igcd, [S(x.p) for x in s_multipliers])
    f = f.subs(s, s / s_multiplier)
    fac = S.One / s_multiplier
    exponent = S.One / s_multiplier
    if a_ is not None:
        a_ *= s_multiplier
    if b_ is not None:
        b_ *= s_multiplier
    numer, denom = f.as_numer_denom()
    numer = Mul.make_args(numer)
    denom = Mul.make_args(denom)
    args = list(zip(numer, repeat(True))) + list(zip(denom, repeat(False)))
    facs = []
    dfacs = []
    numer_gammas = []
    denom_gammas = []
    exponentials = []

    def exception(fact):
        return IntegralTransformError('Inverse Mellin', f, "Unrecognised form '%s'." % fact)
    while args:
        fact, is_numer = args.pop()
        if is_numer:
            ugammas, lgammas = (numer_gammas, denom_gammas)
            ufacs = facs
        else:
            ugammas, lgammas = (denom_gammas, numer_gammas)
            ufacs = dfacs

        def linear_arg(arg):
            if not arg.is_polynomial(s):
                raise exception(fact)
            p = Poly(arg, s)
            if p.degree() != 1:
                raise exception(fact)
            return p.all_coeffs()
        if not fact.has(s):
            ufacs += [fact]
        elif fact.is_Pow or isinstance(fact, exp):
            if fact.is_Pow:
                base = fact.base
                exp_ = fact.exp
            else:
                base = exp_polar(1)
                exp_ = fact.exp
            if exp_.is_Integer:
                cond = is_numer
                if exp_ < 0:
                    cond = not cond
                args += [(base, cond)] * Abs(exp_)
                continue
            elif not base.has(s):
                a, b = linear_arg(exp_)
                if not is_numer:
                    base = 1 / base
                exponentials += [base ** a]
                facs += [base ** b]
            else:
                raise exception(fact)
        elif fact.is_polynomial(s):
            p = Poly(fact, s)
            if p.degree() != 1:
                coeff = p.LT()[1]
                rs = roots(p, s)
                if len(rs) != p.degree():
                    rs = CRootOf.all_roots(p)
                ufacs += [coeff]
                args += [(s - c, is_numer) for c in rs]
                continue
            a, c = p.all_coeffs()
            ufacs += [a]
            c /= -a
            if left(c, is_numer):
                ugammas += [(S.One, -c + 1)]
                lgammas += [(S.One, -c)]
            else:
                ufacs += [-1]
                ugammas += [(S.NegativeOne, c + 1)]
                lgammas += [(S.NegativeOne, c)]
        elif isinstance(fact, gamma):
            a, b = linear_arg(fact.args[0])
            if is_numer:
                if a > 0 and left(-b / a, is_numer) == False or (a < 0 and left(-b / a, is_numer) == True):
                    raise NotImplementedError('Gammas partially over the strip.')
            ugammas += [(a, b)]
        elif isinstance(fact, sin):
            a = fact.args[0]
            if is_numer:
                gamma1, gamma2, fac_ = (gamma(a / pi), gamma(1 - a / pi), pi)
            else:
                gamma1, gamma2, fac_ = _rewrite_sin(linear_arg(a), s, a_, b_)
            args += [(gamma1, not is_numer), (gamma2, not is_numer)]
            ufacs += [fac_]
        elif isinstance(fact, tan):
            a = fact.args[0]
            args += [(sin(a, evaluate=False), is_numer), (sin(pi / 2 - a, evaluate=False), not is_numer)]
        elif isinstance(fact, cos):
            a = fact.args[0]
            args += [(sin(pi / 2 - a, evaluate=False), is_numer)]
        elif isinstance(fact, cot):
            a = fact.args[0]
            args += [(sin(pi / 2 - a, evaluate=False), is_numer), (sin(a, evaluate=False), not is_numer)]
        else:
            raise exception(fact)
    fac *= Mul(*facs) / Mul(*dfacs)
    an, ap, bm, bq = ([], [], [], [])
    for gammas, plus, minus, is_numer in [(numer_gammas, an, bm, True), (denom_gammas, bq, ap, False)]:
        while gammas:
            a, c = gammas.pop()
            if a != -1 and a != +1:
                p = Abs(S(a))
                newa = a / p
                newc = c / p
                if not a.is_Integer:
                    raise TypeError('a is not an integer')
                for k in range(p):
                    gammas += [(newa, newc + k / p)]
                if is_numer:
                    fac *= (2 * pi) ** ((1 - p) / 2) * p ** (c - S.Half)
                    exponentials += [p ** a]
                else:
                    fac /= (2 * pi) ** ((1 - p) / 2) * p ** (c - S.Half)
                    exponentials += [p ** (-a)]
                continue
            if a == +1:
                plus.append(1 - c)
            else:
                minus.append(c)
    arg = Mul(*exponentials)
    an.sort(key=default_sort_key)
    ap.sort(key=default_sort_key)
    bm.sort(key=default_sort_key)
    bq.sort(key=default_sort_key)
    return ((an, ap), (bm, bq), arg, exponent, fac)

@_noconds_(True)
def _inverse_mellin_transform(F, s, x_, strip, as_meijerg=False):
    x = _dummy('t', 'inverse-mellin-transform', F, positive=True)
    F = F.rewrite(gamma)
    for g in [factor(F), expand_mul(F), expand(F)]:
        if g.is_Add:
            ress = [_inverse_mellin_transform(G, s, x, strip, as_meijerg, noconds=False) for G in g.args]
            conds = [p[1] for p in ress]
            ress = [p[0] for p in ress]
            res = Add(*ress)
            if not as_meijerg:
                res = factor(res, gens=res.atoms(Heaviside))
            return (res.subs(x, x_), And(*conds))
        try:
            a, b, C, e, fac = _rewrite_gamma(g, s, strip[0], strip[1])
        except IntegralTransformError:
            continue
        try:
            G = meijerg(a, b, C / x ** e)
        except ValueError:
            continue
        if as_meijerg:
            h = G
        else:
            try:
                from sympy.simplify import hyperexpand
                h = hyperexpand(G)
            except NotImplementedError:
                raise IntegralTransformError('Inverse Mellin', F, 'Could not calculate integral')
            if h.is_Piecewise and len(h.args) == 3:
                h = Heaviside(x - Abs(C)) * h.args[0].args[0] + Heaviside(Abs(C) - x) * h.args[1].args[0]
        cond = [Abs(arg(G.argument)) < G.delta * pi]
        cond += [And(Or(len(G.ap) != len(G.bq), 0 >= re(G.nu) + 1), Abs(arg(G.argument)) == G.delta * pi)]
        cond = Or(*cond)
        if cond == False:
            raise IntegralTransformError('Inverse Mellin', F, 'does not converge')
        return ((h * fac).subs(x, x_), cond)
    raise IntegralTransformError('Inverse Mellin', F, '')
_allowed = None

class InverseMellinTransform(IntegralTransform):
    _name = 'Inverse Mellin'
    _none_sentinel = Dummy('None')
    _c = Dummy('c')

    def __new__(cls, F, s, x, a, b, **opts):
        if a is None:
            a = InverseMellinTransform._none_sentinel
        if b is None:
            b = InverseMellinTransform._none_sentinel
        return IntegralTransform.__new__(cls, F, s, x, a, b, **opts)

    @property
    def fundamental_strip(self):
        a, b = (self.args[3], self.args[4])
        if a is InverseMellinTransform._none_sentinel:
            a = None
        if b is InverseMellinTransform._none_sentinel:
            b = None
        return (a, b)

    def _compute_transform(self, F, s, x, **hints):
        hints.pop('simplify', True)
        global _allowed
        if _allowed is None:
            _allowed = {exp, gamma, sin, cos, tan, cot, cosh, sinh, tanh, coth, factorial, rf}
        for f in postorder_traversal(F):
            if f.is_Function and f.has(s) and (f.func not in _allowed):
                raise IntegralTransformError('Inverse Mellin', F, 'Component %s not recognised.' % f)
        strip = self.fundamental_strip
        return _inverse_mellin_transform(F, s, x, strip, **hints)

    def _as_integral(self, F, s, x):
        c = self.__class__._c
        return Integral(F * x ** (-s), (s, c - S.ImaginaryUnit * S.Infinity, c + S.ImaginaryUnit * S.Infinity)) / (2 * S.Pi * S.ImaginaryUnit)

def inverse_mellin_transform(F, s, x, strip, **hints):
    return InverseMellinTransform(F, s, x, strip[0], strip[1]).doit(**hints)

@_noconds_(True)
def _fourier_transform(f, x, k, a, b, name, simplify=True):
    F = integrate(a * f * exp(b * S.ImaginaryUnit * x * k), (x, S.NegativeInfinity, S.Infinity))
    if not F.has(Integral):
        return (_simplify(F, simplify), S.true)
    integral_f = integrate(f, (x, S.NegativeInfinity, S.Infinity))
    if integral_f in (S.NegativeInfinity, S.Infinity, S.NaN) or integral_f.has(Integral):
        raise IntegralTransformError(name, f, 'function not integrable on real axis')
    if not F.is_Piecewise:
        raise IntegralTransformError(name, f, 'could not compute integral')
    F, cond = F.args[0]
    if F.has(Integral):
        raise IntegralTransformError(name, f, 'integral in unexpected form')
    return (_simplify(F, simplify), cond)

class FourierTypeTransform(IntegralTransform):

    def a(self):
        raise NotImplementedError('Class %s must implement a(self) but does not' % self.__class__)

    def b(self):
        raise NotImplementedError('Class %s must implement b(self) but does not' % self.__class__)

    def _compute_transform(self, f, x, k, **hints):
        return _fourier_transform(f, x, k, self.a(), self.b(), self.__class__._name, **hints)

    def _as_integral(self, f, x, k):
        a = self.a()
        b = self.b()
        return Integral(a * f * exp(b * S.ImaginaryUnit * x * k), (x, S.NegativeInfinity, S.Infinity))

class FourierTransform(FourierTypeTransform):
    _name = 'Fourier'

    def a(self):
        return 1

    def b(self):
        return -2 * S.Pi

def fourier_transform(f, x, k, **hints):
    return FourierTransform(f, x, k).doit(**hints)

class InverseFourierTransform(FourierTypeTransform):
    _name = 'Inverse Fourier'

    def a(self):
        return 1

    def b(self):
        return 2 * S.Pi

def inverse_fourier_transform(F, k, x, **hints):
    return InverseFourierTransform(F, k, x).doit(**hints)

@_noconds_(True)
def _sine_cosine_transform(f, x, k, a, b, K, name, simplify=True):
    F = integrate(a * f * K(b * x * k), (x, S.Zero, S.Infinity))
    if not F.has(Integral):
        return (_simplify(F, simplify), S.true)
    if not F.is_Piecewise:
        raise IntegralTransformError(name, f, 'could not compute integral')
    F, cond = F.args[0]
    if F.has(Integral):
        raise IntegralTransformError(name, f, 'integral in unexpected form')
    return (_simplify(F, simplify), cond)

class SineCosineTypeTransform(IntegralTransform):

    def a(self):
        raise NotImplementedError('Class %s must implement a(self) but does not' % self.__class__)

    def b(self):
        raise NotImplementedError('Class %s must implement b(self) but does not' % self.__class__)

    def _compute_transform(self, f, x, k, **hints):
        return _sine_cosine_transform(f, x, k, self.a(), self.b(), self.__class__._kern, self.__class__._name, **hints)

    def _as_integral(self, f, x, k):
        a = self.a()
        b = self.b()
        K = self.__class__._kern
        return Integral(a * f * K(b * x * k), (x, S.Zero, S.Infinity))

class SineTransform(SineCosineTypeTransform):
    _name = 'Sine'
    _kern = sin

    def a(self):
        return sqrt(2) / sqrt(pi)

    def b(self):
        return S.One

def sine_transform(f, x, k, **hints):
    return SineTransform(f, x, k).doit(**hints)

class InverseSineTransform(SineCosineTypeTransform):
    _name = 'Inverse Sine'
    _kern = sin

    def a(self):
        return sqrt(2) / sqrt(pi)

    def b(self):
        return S.One

def inverse_sine_transform(F, k, x, **hints):
    return InverseSineTransform(F, k, x).doit(**hints)

class CosineTransform(SineCosineTypeTransform):
    _name = 'Cosine'
    _kern = cos

    def a(self):
        return sqrt(2) / sqrt(pi)

    def b(self):
        return S.One

def cosine_transform(f, x, k, **hints):
    return CosineTransform(f, x, k).doit(**hints)

class InverseCosineTransform(SineCosineTypeTransform):
    _name = 'Inverse Cosine'
    _kern = cos

    def a(self):
        return sqrt(2) / sqrt(pi)

    def b(self):
        return S.One

def inverse_cosine_transform(F, k, x, **hints):
    return InverseCosineTransform(F, k, x).doit(**hints)

@_noconds_(True)
def _hankel_transform(f, r, k, nu, name, simplify=True):
    F = integrate(f * besselj(nu, k * r) * r, (r, S.Zero, S.Infinity))
    if not F.has(Integral):
        return (_simplify(F, simplify), S.true)
    if not F.is_Piecewise:
        raise IntegralTransformError(name, f, 'could not compute integral')
    F, cond = F.args[0]
    if F.has(Integral):
        raise IntegralTransformError(name, f, 'integral in unexpected form')
    return (_simplify(F, simplify), cond)

class HankelTypeTransform(IntegralTransform):

    def doit(self, **hints):
        return self._compute_transform(self.function, self.function_variable, self.transform_variable, self.args[3], **hints)

    def _compute_transform(self, f, r, k, nu, **hints):
        return _hankel_transform(f, r, k, nu, self._name, **hints)

    def _as_integral(self, f, r, k, nu):
        return Integral(f * besselj(nu, k * r) * r, (r, S.Zero, S.Infinity))

    @property
    def as_integral(self):
        return self._as_integral(self.function, self.function_variable, self.transform_variable, self.args[3])

class HankelTransform(HankelTypeTransform):
    _name = 'Hankel'

def hankel_transform(f, r, k, nu, **hints):
    return HankelTransform(f, r, k, nu).doit(**hints)

class InverseHankelTransform(HankelTypeTransform):
    _name = 'Inverse Hankel'

def inverse_hankel_transform(F, k, r, nu, **hints):
    return InverseHankelTransform(F, k, r, nu).doit(**hints)
import sympy.integrals.laplace as _laplace
LaplaceTransform = _laplace.LaplaceTransform
laplace_transform = _laplace.laplace_transform
laplace_correspondence = _laplace.laplace_correspondence
laplace_initial_conds = _laplace.laplace_initial_conds
InverseLaplaceTransform = _laplace.InverseLaplaceTransform
inverse_laplace_transform = _laplace.inverse_laplace_transform