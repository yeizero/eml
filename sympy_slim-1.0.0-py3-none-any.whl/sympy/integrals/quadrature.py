from __future__ import annotations
from sympy.core import S, Dummy, pi
from sympy.functions.combinatorial.factorials import factorial
from sympy.functions.elementary.trigonometric import sin, cos
from sympy.functions.elementary.miscellaneous import sqrt
from sympy.functions.special.gamma_functions import gamma
from sympy.polys.orthopolys import legendre_poly, laguerre_poly, hermite_poly, jacobi_poly
from sympy.polys.rootoftools import RootOf

def gauss_legendre(n, n_digits):
    x = Dummy('x')
    p = legendre_poly(n, x, polys=True)
    pd = p.diff(x)
    xi = []
    w = []
    for r in p.real_roots():
        if isinstance(r, RootOf):
            r = r.eval_rational(S.One / 10 ** (n_digits + 2))
        xi.append(r.n(n_digits))
        w.append((2 / ((1 - r ** 2) * pd.subs(x, r) ** 2)).n(n_digits))
    return (xi, w)

def gauss_laguerre(n, n_digits):
    x = Dummy('x')
    p = laguerre_poly(n, x, polys=True)
    p1 = laguerre_poly(n + 1, x, polys=True)
    xi = []
    w = []
    for r in p.real_roots():
        if isinstance(r, RootOf):
            r = r.eval_rational(S.One / 10 ** (n_digits + 2))
        xi.append(r.n(n_digits))
        w.append((r / ((n + 1) ** 2 * p1.subs(x, r) ** 2)).n(n_digits))
    return (xi, w)

def gauss_hermite(n, n_digits):
    x = Dummy('x')
    p = hermite_poly(n, x, polys=True)
    p1 = hermite_poly(n - 1, x, polys=True)
    xi = []
    w = []
    for r in p.real_roots():
        if isinstance(r, RootOf):
            r = r.eval_rational(S.One / 10 ** (n_digits + 2))
        xi.append(r.n(n_digits))
        w.append((2 ** (n - 1) * factorial(n) * sqrt(pi) / (n ** 2 * p1.subs(x, r) ** 2)).n(n_digits))
    return (xi, w)

def gauss_gen_laguerre(n, alpha, n_digits):
    x = Dummy('x')
    p = laguerre_poly(n, x, alpha=alpha, polys=True)
    p1 = laguerre_poly(n - 1, x, alpha=alpha, polys=True)
    p2 = laguerre_poly(n - 1, x, alpha=alpha + 1, polys=True)
    xi = []
    w = []
    for r in p.real_roots():
        if isinstance(r, RootOf):
            r = r.eval_rational(S.One / 10 ** (n_digits + 2))
        xi.append(r.n(n_digits))
        w.append((gamma(alpha + n) / (n * gamma(n) * p1.subs(x, r) * p2.subs(x, r))).n(n_digits))
    return (xi, w)

def gauss_chebyshev_t(n, n_digits):
    xi = []
    w = []
    for i in range(1, n + 1):
        xi.append(cos((2 * i - S.One) / (2 * n) * S.Pi).n(n_digits))
        w.append((S.Pi / n).n(n_digits))
    return (xi, w)

def gauss_chebyshev_u(n, n_digits):
    xi = []
    w = []
    for i in range(1, n + 1):
        xi.append(cos(i / (n + S.One) * S.Pi).n(n_digits))
        w.append((S.Pi / (n + S.One) * sin(i * S.Pi / (n + S.One)) ** 2).n(n_digits))
    return (xi, w)

def gauss_jacobi(n, alpha, beta, n_digits):
    x = Dummy('x')
    p = jacobi_poly(n, alpha, beta, x, polys=True)
    pd = p.diff(x)
    pn = jacobi_poly(n + 1, alpha, beta, x, polys=True)
    xi = []
    w = []
    for r in p.real_roots():
        if isinstance(r, RootOf):
            r = r.eval_rational(S.One / 10 ** (n_digits + 2))
        xi.append(r.n(n_digits))
        w.append((-(2 * n + alpha + beta + 2) / (n + alpha + beta + S.One) * (gamma(n + alpha + 1) * gamma(n + beta + 1)) / (gamma(n + alpha + beta + S.One) * gamma(n + 2)) * 2 ** (alpha + beta) / (pd.subs(x, r) * pn.subs(x, r))).n(n_digits))
    return (xi, w)

def gauss_lobatto(n, n_digits):
    x = Dummy('x')
    p = legendre_poly(n - 1, x, polys=True)
    pd = p.diff(x)
    xi = []
    w = []
    for r in pd.real_roots():
        if isinstance(r, RootOf):
            r = r.eval_rational(S.One / 10 ** (n_digits + 2))
        xi.append(r.n(n_digits))
        w.append((2 / (n * (n - 1) * p.subs(x, r) ** 2)).n(n_digits))
    xi.insert(0, -1)
    xi.append(1)
    w.insert(0, (S(2) / (n * (n - 1))).n(n_digits))
    w.append((S(2) / (n * (n - 1))).n(n_digits))
    return (xi, w)