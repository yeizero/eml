from __future__ import annotations
from sympy.core.mul import Mul
from sympy.core.singleton import S
from sympy.core.sorting import default_sort_key
from sympy.functions import DiracDelta, Heaviside
from .integrals import Integral, integrate

def change_mul(node, x):
    new_args = []
    dirac = None
    c, nc = node.args_cnc()
    sorted_args = sorted(c, key=default_sort_key)
    sorted_args.extend(nc)
    for arg in sorted_args:
        if arg.is_Pow and isinstance(arg.base, DiracDelta):
            new_args.append(arg.func(arg.base, arg.exp - 1))
            arg = arg.base
        if dirac is None and (isinstance(arg, DiracDelta) and arg.is_simple(x)):
            dirac = arg
        else:
            new_args.append(arg)
    if not dirac:
        new_args = []
        for arg in sorted_args:
            if isinstance(arg, DiracDelta):
                new_args.append(arg.expand(diracdelta=True, wrt=x))
            elif arg.is_Pow and isinstance(arg.base, DiracDelta):
                new_args.append(arg.func(arg.base.expand(diracdelta=True, wrt=x), arg.exp))
            else:
                new_args.append(arg)
        if new_args != sorted_args:
            nnode = Mul(*new_args).expand()
        else:
            nnode = None
        return (None, nnode)
    return (dirac, Mul(*new_args))

def deltaintegrate(f, x):
    if not f.has(DiracDelta):
        return None
    if f.func == DiracDelta:
        h = f.expand(diracdelta=True, wrt=x)
        if h == f:
            if f.is_simple(x):
                if len(f.args) <= 1 or f.args[1] == 0:
                    return Heaviside(f.args[0])
                else:
                    return DiracDelta(f.args[0], f.args[1] - 1) / f.args[0].as_poly().LC()
        else:
            fh = integrate(h, x)
            return fh
    elif f.is_Mul or f.is_Pow:
        g = f.expand()
        if f != g:
            fh = integrate(g, x)
            if fh is not None and (not isinstance(fh, Integral)):
                return fh
        else:
            deltaterm, rest_mult = change_mul(f, x)
            if not deltaterm:
                if rest_mult:
                    fh = integrate(rest_mult, x)
                    return fh
            else:
                from sympy.solvers import solve
                deltaterm = deltaterm.expand(diracdelta=True, wrt=x)
                if deltaterm.is_Mul:
                    deltaterm, rest_mult_2 = change_mul(deltaterm, x)
                    rest_mult = rest_mult * rest_mult_2
                point = solve(deltaterm.args[0], x)[0]
                n = 0 if len(deltaterm.args) == 1 else deltaterm.args[1]
                m = 0
                while n >= 0:
                    r = S.NegativeOne ** n * rest_mult.diff(x, n).subs(x, point)
                    if r.is_zero:
                        n -= 1
                        m += 1
                    elif m == 0:
                        return r * Heaviside(x - point)
                    else:
                        return r * DiracDelta(x, m - 1)
                return S.Zero
    return None